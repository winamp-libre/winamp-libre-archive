/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DynaMenus.cpp: implementation of the CDynaMenus class.
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/08/03 MZ  memory leaks fixed
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "TreeCtrlSer.h"
#include "DynaMenus.h"
#include "DlgHidden.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


int EnterSubMenu(tCurrMenu *pCurrMenu);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

extern t_DynaMenu	aAllFuncs[];

CDynaMenus::CDynaMenus()
{
	m_MenuStruct = NULL;
}

CDynaMenus::~CDynaMenus()
{
	if (m_MenuStruct != NULL) {
		DelChilds(m_MenuStruct);
	}
}

void CDynaMenus::DelChilds(t_menuitem *menu) 
{
	int i = 0;

	while (i < MAX_CHILDS && menu->childs[i] != NULL) {
		DelChilds(menu->childs[i]);
		
		i++;
	}
	
	free(menu);
}

static void Recurse_tree(CTreeCtrl *tree, t_menuitem *curmenu, HTREEITEM curitem)
{
	HTREEITEM child;
	t_menuitem *newmenu;
	int	i = 0;

	child = tree->GetChildItem(curitem);
	if (child)
	{
		do {
			newmenu = new t_menuitem;
			memset(newmenu->childs, 0, 32 * sizeof (t_menuitem*));
			newmenu->FuncID = tree->GetItemData(child);
			newmenu->Label = tree->GetItemText(child);
			curmenu->childs[i] = newmenu;
			Recurse_tree(tree, newmenu, child);
			i++;
		} while ((child = tree->GetNextItem(child, TVGN_NEXT)));
	}
}


bool CDynaMenus::BuildFromTreeview(CTreeCtrl *tree)
{
	if (m_MenuStruct != NULL) {
		DelChilds(m_MenuStruct);
		m_MenuStruct = NULL;
	}

	HTREEITEM root;
	t_menuitem *newmenu;

	root = tree->GetRootItem();
	newmenu = new t_menuitem;
	memset(newmenu->childs, 0, 32 * sizeof (t_menuitem*));
	newmenu->Label = tree->GetItemText(root);
	newmenu->FuncID = -1;
	m_MenuStruct = newmenu;
	Recurse_tree(tree, newmenu, root);
	return true;
}

int CDynaMenus::Write_Config()
{
	return 1;
}

int CDynaMenus::Read_Config()
{
	return 1;
}

int CDynaMenus::EnterMenu(tCurrMenu *pCurrMenu, t_menuitem *menu)
{
	tMenuLine	*pMenu = NULL;
	int iCount = 0;

	TRACE("CDynaMenus::EnterMenu() : Building menu '%s'", menu->Label.GetBuffer(1));
	menu->Label.ReleaseBuffer();

	Menu_Leave(pCurrMenu);
	for (int i = 0; menu->childs[i] != 0; i++)
	{
		pMenu = (tMenuLine*)realloc(pMenu, (i+1) * sizeof(tMenuLine));

		TRACE("CDynaMenus::EnterMenu() : Displaying submenu '%s'", menu->childs[i]->Label.GetBuffer(1));
		menu->childs[i]->Label.ReleaseBuffer();

		if (menu->childs[i]->FuncID == -1)
		{
			// Submenu
			pMenu[i].idText= 0;
			pMenu[i].iUserData = (int)menu->childs[i];
			pMenu[i].pActionFunc = EnterSubMenu;
			strcpy(pMenu[i].cTextBuff, menu->childs[i]->Label.GetBuffer(1));
			menu->childs[i]->Label.ReleaseBuffer();
		}
		else
		{
			// Function
			pMenu[i].idText= 0;
			for (int j = 0; aAllFuncs[j].Id != 0; j++)
			{
				if (aAllFuncs[j].Id == menu->childs[i]->FuncID)
					break;
			}
			pMenu[i].pActionFunc = aAllFuncs[j].pActionFunc;
			pMenu[i].iUserData = aAllFuncs[j].UserData;
			strcpy(pMenu[i].cTextBuff, menu->childs[i]->Label.GetBuffer(1));
			menu->childs[i]->Label.ReleaseBuffer();
		}
		iCount++;
	}
	
	if (iCount == 0)
	{
		 pMenu = (tMenuLine*)realloc(pMenu, sizeof(tMenuLine));
		 strcpy(pMenu[0].cTextBuff, "");
		 pMenu[0].idText = IDS_NO_ALBUMS;
		 pMenu[0].pActionFunc = NULL;
		 iCount++;
	}
	TRACE("CDynaMenus::EnterMenu() : Entering menu");
	Menu_Enter(pCurrMenu, pMenu, iCount, 1);
	TRACE("CDynaMenus::EnterMenu() : End");
	return 1;
}

int CDynaMenus::Init()
{
	return 1;
}
