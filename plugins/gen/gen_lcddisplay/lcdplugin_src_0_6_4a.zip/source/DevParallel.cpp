/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallel.cpp: implementation of the CDevParallel class.
// Keypad code taken from the Linux LCDProc project!
//
// TODO: - rethink design about keypad handling
// 
// Modifications:
// 2002/01/13 MZ  keypad is working
// 2002/01/29 MZ  moved 44780 specific code to derived class CDevParallel44780
// 2002/02/03 MZ  configurable keypad
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <conio.h>
#include "gen_lcddisplay.h"
#include "DevParallel.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// Autorepeat values
#define KEYPAD_AUTOREPEAT_DELAY 500
#define KEYPAD_AUTOREPEAT_FREQ 15

// @TODO test timeout value
#define KEYPAD_KEY_TIMEOUT  200

// @TODO define keypad somewhere else?
static char *defaultKeyMapDirect[KEYPAD_MAXX] = { "A", "B", "C", "D", "E" };

static char *defaultKeyMapMatrix[KEYPAD_MAXY][KEYPAD_MAXX] = {
		{ "1", "2", "3", "A", "E" },
		{ "4", "5", "6", "B", "F" },
		{ "7", "8", "9", "C", "G" },
		{ "*", "0", "#", "D", "H" },
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL },
		{ NULL, NULL, NULL, NULL, NULL }};


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevParallel::CDevParallel()
{
	m_hDriver = NULL;
	m_lpfnReadChar = NULL;
	m_lpfnWriteChar = NULL;
	m_DelayType = PORT_IO;
	m_iPort = 0;

	have_keypad = FALSE;
	delayMult = 1;
	m_delayShort = 40;
	m_delayMedium = 100;
	m_delayLong = 1600;
	m_delayInit = 4100;
}

CDevParallel::~CDevParallel()
{
	// in case close() hasn't been called...
	if (m_hDriver != NULL)
		FreeLibrary(m_hDriver);
}

/******************************************************************************
Function : Open
Purpose  : Opens the parallel port. When running under NT the Port IO driver
           is loaded.
Parameters : lpPort:  port number as string, e.g. "0x378" for LPT1
             lpParam: Extended cfg parameters, delimeted by a pipe ('|'):
			          NULL     = no further cfg parameters. 
			          "keypad" = has keypad, 
Returns : FALSE if the Port IO driver could not be loaded
Author  : Markus Zehnder	
******************************************************************************/
BOOL CDevParallel::Open(LPCSTR lpPort, LPCSTR lpParam)
{
	Close();

	if (m_bWinNT) {
		// load DriverLINX Port I/O Driver
		m_hDriver = LoadLibrary("dlportio.dll");

		if (m_hDriver == NULL) {
			TRACE("ERROR: loading of DriverLINX Port I/O Driver failed! %s\n", THIS_FILE);
			m_bOpen = FALSE;
			return FALSE;
		}

		m_lpfnReadChar = (READCHAR)GetProcAddress(m_hDriver, "DlPortReadPortUchar");
		m_lpfnWriteChar = (WRITECHAR)GetProcAddress(m_hDriver, "DlPortWritePortUchar");

		if (m_lpfnReadChar == NULL || m_lpfnWriteChar == NULL)
		{
			FreeLibrary(m_hDriver);
			m_hDriver = NULL;
			return FALSE;
		}

	}

	m_iPort = atoi(lpPort);

	// parse ext cfg params
	if (lpParam != NULL) {
		// at the moment there's only one cfg param:
		if (_stricmp(lpParam, "keypad") == 0) {
			have_keypad = TRUE;
		}
	}

	// Keypad ? 
	if (have_keypad) {
		int x, y;

		// Read keymap
		for (x=0; x < KEYPAD_MAXX; x++) {
			char buf[40];
			char s[20];

			// First fill with default value
			keyMapDirect[x] = defaultKeyMapDirect[x];

			// Read config value
			sprintf( buf, "keydirect_%1d", x+1 );
		    GetPrivateProfileString(SECTION_NAME_KEYPAD, buf, "", s, 20, g_szIniFile);

			// Was a key specified in the config file ?
			if (strlen(s) > 0) {
				keyMapDirect[x] = (char *) malloc( strlen(s)+1 );
				strcpy( keyMapDirect[x], s );
				TRACE( "HD44780: Direct key %d: \"%s\"", x, s );
			}
		}

		for (x=0; x < KEYPAD_MAXX; x++) {
			for (y=0; y < KEYPAD_MAXY; y++) {
				char buf[40];
				char s[20];

				// First fill with default value
				keyMapMatrix[y][x] = defaultKeyMapMatrix[y][x];

				// Read config value
				sprintf( buf, "keymatrix_%1d_%d", x+1, y+1 );
			    GetPrivateProfileString(SECTION_NAME_KEYPAD, buf, "", s, 20, g_szIniFile);

				// Was a key specified in the config file ?
				if (strlen(s) > 0) {
					keyMapMatrix[y][x] = (char *) malloc( strlen(s)+1 );
					strcpy( keyMapMatrix[y][x], s );
					TRACE( "HD44780: Matrix key %d %d: \"%s\"", x, y, s );
				}
			}
		}
	}

	return TRUE;
}

/******************************************************************************
Function : Close
Purpose  : Closes the parallel port and unloads the NT port IO driver (if loaded)
Parameters : -
Returns : Return of base class CDevice::Close()
Author  : Markus Zehnder	
******************************************************************************/
BOOL CDevParallel::Close()
{
	if (m_hDriver != NULL)
		FreeLibrary(m_hDriver);

	m_hDriver = NULL;

	return CDevice::Close();
}

/******************************************************************************
Function : HandleKeyPad
Purpose  : Reads and buffers keypad inputs. Must continiously be called by the 
           real LCD driver or the main loop that calls the LCD driver! (i.e. 
		   from one thread only!). Any other  'keypad client' must call ReadData
		   to get keypad inputs!
Parameters : - 
Returns : void
Author  : Markus Zehnder	
******************************************************************************/
void CDevParallel::HandleKeyPad()
{
	// make it simple: just buffer one key. 
	// the key ist stored in 'pressed_key' at time: pressed_key_time
	if (have_keypad) {
		getkey();
	}
}


/******************************************************************************
Function : ReadData
Purpose  : Returns pressed keypad keycode. This function must continuously be
           polled by a client, otherwise pressed keypad keys will be lost!
Parameters : buffer : output buffer for keycode
             size   : size of output buffer. MUST BE 1!
			 blocking: TRUE = waits until key is pressed. NOT SUPPORTED!
                       FALSE= poll if key was pressed.
Returns :  1 : keycode is stored in provided buffer
           0 : no key was pressed or timeout occured
          -1 : device is closed
		  -2 : invalid parameter
Author  : Markus Zehnder	
******************************************************************************/
int CDevParallel::ReadData(LPBYTE buffer, DWORD size, BOOL blocking /* = TRUE */)
{
	if (!m_bOpen) {
		return -1;
	}

	if (size > 1 || blocking || buffer == NULL) {
		return -2; // not supported (yet) but would be quite easy with SetEvent in getkey() and waiting here with WaitForSingleEvent...
	}

	DWORD curr_time = GetTickCount();

	if ((curr_time - pressed_key_time) > KEYPAD_KEY_TIMEOUT) {
		return 0; // sorry: timeout!
	}

	if (pressed_key == 0) {
		return 0;
	}

	buffer[0] = pressed_key;

	return 1;
}

/******************************************************************************
Function : port_in
Purpose  : Reads a BYTE value from the specified port
Parameters : port : which port to read
Returns : read BYTE value
Author  : Markus Zehnder	
******************************************************************************/
inline BYTE CDevParallel::port_in(unsigned short port)
{
	if (m_bWinNT)
		return (*m_lpfnReadChar)(port);
	else
		return _inp(port);
}

/******************************************************************************
Function : port_out
Purpose  : Most important function: writes a byte value to the specified port.
Parameters : port  : where...
             value : what...
Returns : void
Author  : Markus Zehnder	
******************************************************************************/
inline void CDevParallel::port_out(unsigned short port, BYTE value)
{
	if (m_bWinNT)
		(*m_lpfnWriteChar)(port, value);
	else
		_outp(port, value);
}

/******************************************************************************
Function : uPause
Purpose  : Microsecond delay function. Depending on the delay method this function
           is either very precise or not very predictible...
		   WARNING: this is a busy wait function! Use with caution!
Parameters : usecs : number of microseconds to wait
Returns : void
Author  : Markus Zehnder	
******************************************************************************/
void CDevParallel::uPause(int usecs)
{
  int i;

  usecs *= delayMult;

  if (m_DelayType == PORT_IO || !m_bMicroTiming) {
	  for (i = 0; i < usecs; ++i)
		port_in(m_iPort);		// assumption that a port read takes 1 us...
  } else {
	  m_cTiming.uPause(usecs);  // this is the way to go, but not supported by every system :(
  }

}

/******************************************************************************
Function : SetDelayType
Purpose  : Sets the delay method for uPause 
Parameters : type : PORT_IO    'port delay': assume that each port input takes 
                                1 us - can be quite inaccurate.
					VHR_TIMING	use very high resolution timing - not supported
					            by every system...
Returns : TRUE  = specified delay method is supported
          FALSE = delay method not supported
Author  : Markus Zehnder	
******************************************************************************/
BOOL CDevParallel::SetDelayType(DELAY_TYPES type)
{
	if (type == VHR_TIMING && !m_cTiming.Available()) {
		return FALSE;
	}

	m_DelayType = type;
	return TRUE;
}

// Get a key from the keypad (if there is one)
//
char CDevParallel::getkey()
{
	unsigned char scancode;
	char ch;
	DWORD curr_time, time_diff;

	curr_time = GetTickCount();

	scancode = scankeypad();
	if( scancode ) {
		if( scancode & 0xF0 ) {
			ch = ( keyMapMatrix[((scancode&0xF0)>>4)-1][(scancode&0x0F)-1] )[0];
		}
		else {
			ch = ( keyMapDirect[scancode - 1] )[0];
		}
	}
	else {
		ch = 0;
	}

	if (ch) {
		if (ch == pressed_key) {
			time_diff = curr_time - pressed_key_time;
			if ((time_diff - KEYPAD_AUTOREPEAT_DELAY) < 1000 * pressed_key_repetitions / KEYPAD_AUTOREPEAT_FREQ ) {
				// The key is already pressed quite some time
				// but it's not yet time to return a repeated keypress
				return 0;
			}
			// Otherwise a keypress will be returned
			pressed_key_repetitions ++;
		}
		else {
			// It's a new keypress
			pressed_key_time = curr_time;
			pressed_key_repetitions = 0;
			printf( "Key: %c  (%d,%d)\n", ch, scancode&0x0F, (scancode&0xF0)>>4 );
		}
	}

	// Store the key for the next round
	pressed_key = ch;

	return ch;
}

/////////////////////////////////////////////////////////////
// Scan the keypad
//
unsigned char CDevParallel::scankeypad()
{
	unsigned int keybits;
	unsigned int shiftcount;
	unsigned int shiftingbit;
	unsigned int Ypattern;
	unsigned int Yval;
	char exp;

	unsigned char scancode = 0;

	// First check if a directly connected key is pressed
	// Put all zeros on Y of keypad
	keybits = readkeypad (0);

	if (keybits) {
		// A directly connected key was pressed
		// Which key was it ?
		shiftingbit = 1;
		for (shiftcount=0; shiftcount<KEYPAD_MAXX && !scancode; shiftcount++) {
			if ( keybits & shiftingbit) {
				// Found !   Return from function.
				scancode = shiftcount+1;
			}
			shiftingbit <<= 1;
		}
	}
	else {
		// Now check the matrix
		// First check with all 1's
		Ypattern = (1 << KEYPAD_MAXY) - 1;
		if( readkeypad (Ypattern)) {
			// Yes, a key on the matrix is pressed

			// OK, now we know a key is pressed.
			// Determine which one it is

			// First determine the row
			// Do a 'binary search' to minimize I/O
			Ypattern = 0;
			Yval = 0;
			for (exp=3; exp>=0; exp--) {
				Ypattern = ((1 << (1 << exp)) - 1) << Yval;
				keybits = readkeypad (Ypattern);
				if (!keybits) {
					Yval += (1 << exp);
				}
			}

			// Which key is pressed in that row ?
			keybits = readkeypad (1<<Yval);
			shiftingbit=1;
			for (shiftcount=0; shiftcount<KEYPAD_MAXX && !scancode; shiftcount++) {
				if ( keybits & shiftingbit) {
					// Found !
					scancode = (Yval+1) << 4 | (shiftcount+1);
				}
				shiftingbit <<= 1;
			}
		}
	}
	return scancode;
}

void CDevParallel::SetDelays(WORD Short, WORD Medium, WORD Long, WORD Init, BYTE factor)
{
	m_delayShort = Short;
	m_delayMedium = Medium;	
	m_delayLong = Long;	
	m_delayInit = Init;	
	
	if (factor > 0)
		delayMult = factor;
}

