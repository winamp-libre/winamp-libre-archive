// DlgInputAddKeyboard.h: interface for the CDlgInputAddKeyboard class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DLGINPUTADDKEYBOARD_H__55DEFFF7_DE45_4B79_B3A1_1843ABB12B74__INCLUDED_)
#define AFX_DLGINPUTADDKEYBOARD_H__55DEFFF7_DE45_4B79_B3A1_1843ABB12B74__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DlgInputAdd.h"

class CDlgInputAddKeyboard : public CDlgInputAdd  
{
private:
	bool m_bWinampKeyboardMap;
public:
	int	m_iKeyCode;
	int m_lParam;

public:
	CDlgInputAddKeyboard(CDlgInput *pcDlgCfg, CWnd* pParent = NULL, bool bWinampKeyboardMap = false);
	virtual ~CDlgInputAddKeyboard();

protected:
	static LRESULT CALLBACK KeyboardHook(int code, WPARAM wParam, LPARAM lParam);

	// Generated message map functions
	//{{AFX_MSG(CDlgInputAddKeyboard)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_DLGINPUTADDKEYBOARD_H__55DEFFF7_DE45_4B79_B3A1_1843ABB12B74__INCLUDED_)
