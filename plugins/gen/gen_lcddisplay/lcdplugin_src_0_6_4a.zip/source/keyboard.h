// 01.04.01 - �nderungen f�r meinen CAR Player F. Verhamme

#ifndef KEYBOARD_H
#define KEYBOARD_H

#include "LCDMenuShow.h"

// IF you want to use this plugin in your car and you want to use the % key
// to step into the menu and select the items then define _CARUSE_
// #define _CARUSE_

extern int		   jump_to_number;
extern tCurrMenu   sCurrMenu;        // Variable f�r Menuestruktur
extern HHOOK       hHook;

LRESULT CALLBACK KeyboardHook(int code, WPARAM wParam, LPARAM lParam);

#endif