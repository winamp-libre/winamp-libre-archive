/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallelShiftRegEx.h: interface for the CDevParallelShiftRegEx44780 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVPARALLELSHIFTREGEX_H__F0BEC6D3_C2D2_4C71_B17E_CCF53E2EB027__INCLUDED_)
#define AFX_DEVPARALLELSHIFTREGEX_H__F0BEC6D3_C2D2_4C71_B17E_CCF53E2EB027__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DevParallelShiftReg.h"

class CDevParallelShiftRegEx44780 : public CDevParallelShiftReg44780  
{
public:
	CDevParallelShiftRegEx44780();
	virtual ~CDevParallelShiftRegEx44780();

	virtual BOOL Open(LPCSTR lpPort, LPCSTR lpParam);

	virtual void senddata (unsigned char displayID, unsigned char flags, unsigned char ch);
};

#endif // !defined(AFX_DEVPARALLELSHIFTREG_H__F0BEC6D3_C2D2_4C71_B17E_CCF53E2EB027__INCLUDED_)
