/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// MOrbitalLcd.cpp: implementation of the CLcdMOrbital class.
//
// TODO: - change write functions to accept custom char 0
//       - use defined lcd size for range checks
//       - implement and test H- and VBars
//
// Modifications:
// 2002/01/04 MZ  first implementation with overlapped IO and CSerialDevice class
// 2002/01/10 MZ  use of generic backlight timeout, generic getter methods are now in the base class
// 2002/02/19 MZ  renamed from CMOrbitalLcd to CLcdMOrbital
// 2003/01/26 MZ  allocating m_pcDev and setting m_pInstance for backlight timer in Open()
// 2003/07/13 MZ  custom character map added 
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MOrbitalLcd.h"
#include "gen_lcddisplay.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define MO_SECTION	"Matrix Orbital"
#define MO_CHARMAP  "MO_CHARMAP"

#define MAX_CUSTOM_CHARS		8

CCfgMO	 g_MOCfg;

CCfgMO::CCfgMO()
{
	Load(g_szIniFile);
}

CCfgMO::~CCfgMO()
{
	Save(g_szIniFile);
}

void CCfgMO::Load(LPCSTR lpIniFile)
{
	GetPrivateProfileString( MO_SECTION, "ComPort", DEF_COMPORT, szComPort, MAX_COMPORT_STRLEN, lpIniFile);
	GetPrivateProfileString( MO_SECTION, "BaudRate", DEF_BAUDRATE, szBaudRate, MAX_BAUDRATE_STRLEN, lpIniFile);
	bBlink =	   GetPrivateProfileInt(MO_SECTION,"SetBlink",0,lpIniFile); 
	bScroll =	   GetPrivateProfileInt(MO_SECTION,"SetScroll",0,lpIniFile); 
	bShowCursor = GetPrivateProfileInt(MO_SECTION,"Cursor",0,lpIniFile); 
	bWrap =	   GetPrivateProfileInt(MO_SECTION,"Wrap",1,lpIniFile); 	
	iCols =       GetPrivateProfileInt(MO_SECTION,"Columns",20,lpIniFile); 			 
	iRows =	   GetPrivateProfileInt(MO_SECTION,"Rows",4,lpIniFile); 
	byContrast = (BYTE)GetPrivateProfileInt(MO_SECTION,"Contrast", DEF_CONTRAST,lpIniFile); 
	byBrightness = (BYTE)GetPrivateProfileInt(MO_SECTION,"Brightness", DEF_BRIGHTNESS,lpIniFile); 
	bLCD = GetPrivateProfileInt(MO_SECTION,"LCD",1,lpIniFile);
	BuildCharMap(MO_CHARMAP, lpIniFile, charMap);
}

void CCfgMO::Save(LPCSTR lpIniFile)
{
	char string[32];

	WritePrivateProfileString( MO_SECTION, "ComPort", szComPort, lpIniFile);
	WritePrivateProfileString( MO_SECTION, "BaudRate", szBaudRate, lpIniFile);
	wsprintf(string,"%d",bBlink);
	WritePrivateProfileString(MO_SECTION,"SetBlink",string,lpIniFile);
	wsprintf(string,"%d",bScroll);
	WritePrivateProfileString(MO_SECTION,"SetScroll",string,lpIniFile);
	wsprintf(string,"%d",bShowCursor);
	WritePrivateProfileString(MO_SECTION,"Cursor",string,lpIniFile);
	wsprintf(string,"%d",bWrap);
	WritePrivateProfileString(MO_SECTION,"Wrap",string,lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(MO_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(MO_SECTION,"Rows",string,lpIniFile);
	wsprintf(string,"%d",byContrast);
	WritePrivateProfileString(MO_SECTION,"Contrast",string,lpIniFile);
	wsprintf(string,"%d",byBrightness);
	WritePrivateProfileString(MO_SECTION,"Brightness",string,lpIniFile);
	wsprintf(string,"%d",bLCD);
	WritePrivateProfileString(MO_SECTION,"LCD",string,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdMOrbital::CLcdMOrbital()
{
	m_byCmdPrefix = 0xfe;
	m_pcDev = NULL;
}

CLcdMOrbital::~CLcdMOrbital()
{
	Close();

	if (m_pcDev != NULL)
		delete m_pcDev;
}

void  CLcdMOrbital::SetBacklight(short nSeconds)
{
	if (nSeconds < 0)
	{
		WriteCommand( 'F' );
	}
	else
	{
		WriteCommand( 'B' );

		if (nSeconds % 60 == 0) {
			// use native minute timeout from LCD controller
			WriteData( (BYTE)(nSeconds / 60));
		} else {
			StartBacklightTimer(nSeconds);
			WriteData(0);
		}
	}

	m_nBackLight = nSeconds;
}

void  CLcdMOrbital::SetBlink(BOOL bOn)
{
	WriteCommand( bOn ? 'S' : 'T' );
	m_bBlink = bOn;
}

void  CLcdMOrbital::Clear()
{
	WriteCommand( 'X' );
}

void  CLcdMOrbital::Close()
{
	if (m_pcDev)
		m_pcDev->Close();
}

BOOL  CLcdMOrbital::IsOpen()
{
	if (m_pcDev == NULL)
		return FALSE;

	return m_pcDev->IsOpen();
}

void  CLcdMOrbital::SetContrast(short nLevel)
{
	if ((nLevel < 0) || (nLevel > 255))
		return;
	WriteCommand( 'P' );
	WriteData( (BYTE)nLevel );
	m_nContrast = nLevel;
}

void CLcdMOrbital::SetBrightness(short nLevel)
{
	if ((nLevel < 0) || (nLevel > 3))
		return;
	WriteCommand( 'Y' );
	WriteData( (BYTE)nLevel );
	m_nBrightness = nLevel;
}

void  CLcdMOrbital::Cursor(BOOL bOn)
{
	WriteCommand( bOn ? 'J' : 'K' );
	m_bCursor = bOn;
}

void  CLcdMOrbital::HBar(short nCol, short nRow, short nDir, short nLen)
{
	// not yet implemented
}

void  CLcdMOrbital::Home()
{
	WriteCommand( 'H' );
}

void  CLcdMOrbital::InitHorizontalBar()
{
	WriteCommand( 'h' );
}

void  CLcdMOrbital::InitLargeDigit()
{
	WriteCommand( 'n' );
}

void  CLcdMOrbital::InitVerticalBar()
{
	WriteCommand( 'v' );
}

void  CLcdMOrbital::LargeDigit(short nCol, short nNumber)
{
	WriteCommand( '#' );
	WriteData( (BYTE)nCol );
	WriteData( (BYTE)nNumber );
}

void  CLcdMOrbital::SetLineWrap(BOOL bOn)
{
	WriteCommand( bOn ? 'C' : 'D' );
	m_bLineWrap = bOn;
}

/******************************************************************************
Function : Open
Purpose  : Opens the comport and initilizes the display
Parameters : -
Returns : TRUE if successful, otherwise FALSE
Author  : Markus Zehnder	
******************************************************************************/
BOOL  CLcdMOrbital::Open()
{
	char szDef[20];

	if (m_pcDev == NULL) {
		m_pcDev = new CDevSerial();
	}

	sprintf(szDef, "%d,n,8,1", atoi(g_MOCfg.szBaudRate) );

	if (!m_pcDev->Open(g_MOCfg.szComPort, szDef))
	{
		Close();
		return FALSE;
	}		

	Clear();
	SetBlink( g_MOCfg.bBlink );
	Cursor( g_MOCfg.bShowCursor );
	SetLineWrap( g_MOCfg.bWrap );
	SetScroll( g_MOCfg.bScroll );

	if (g_MOCfg.bLCD)
		SetContrast(g_MOCfg.byContrast);
	else
		SetBrightness(g_MOCfg.byBrightness);

	m_charMap = g_MOCfg.charMap;

	return TRUE;
}

void  CLcdMOrbital::SetPosition(short nCol, short nRow)
{
	WriteCommand( 'G' );
	WriteData( (BYTE)nCol );
	WriteData( (BYTE)nRow );
}

void  CLcdMOrbital::SetScroll(BOOL bOn)
{
	WriteCommand( bOn ? 'Q' : 'R' );
	m_bScroll = bOn;
}

void  CLcdMOrbital::VBar(short nCol, short nLength)
{
	// not yet implemented
}

void  CLcdMOrbital::Write(LPCSTR lpText)
{
	CString csText = lpText;
	ConvertTextToLCDCharset(csText);
	m_pcDev->WriteData(csText);
}

void CLcdMOrbital::WriteData(BYTE byData)
{
	m_pcDev->WriteData(byData);
}

void CLcdMOrbital::WriteCommand(BYTE byData)
{
	WriteData( m_byCmdPrefix );
	WriteData( byData );
}

BOOL  CLcdMOrbital::CreateCustomChar(short nNumber, CCustomChar &cChar)
{
	if (nNumber > MAX_CUSTOM_CHARS)	// bugfix: last custom char didn't get set, MZ July 28 2k
		return FALSE;


	WriteCommand( 'N' );
	WriteData( (BYTE)nNumber );

	int iMax = __min(8, cChar.m_byDataSize);
	for (int i = 0; i < iMax; i++)
	{
		if (cChar.m_byarrData[i] > 31)
			cChar.m_byarrData[i] = 0;	
		WriteData( cChar.m_byarrData[i] );
	}

	for (; i < 8; i++)
	{
		WriteData( 0 );
	}

	return TRUE;
}

short CLcdMOrbital::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

LPCTSTR CLcdMOrbital::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( "%c1", ch );
	ch[0] = (char)2;
	csText.Replace( "%c2", ch );
	ch[0] = (char)3;
	csText.Replace( "%c3", ch );
	ch[0] = (char)4;
	csText.Replace( "%c4", ch );
	ch[0] = (char)5;
	csText.Replace( "%c5", ch );
	ch[0] = (char)6;
	csText.Replace( "%c6", ch );
	ch[0] = (char)7;
	csText.Replace( "%c7", ch );
	ch[0] = (char)8;
	csText.Replace( "%c8", ch );

	return csText;
}

LPCTSTR CLcdMOrbital::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( ch, "%c1" );
	ch[0] = (char)2;
	csText.Replace( ch, "%c2" );
	ch[0] = (char)3;
	csText.Replace( ch, "%c3" );
	ch[0] = (char)4;
	csText.Replace( ch, "%c4" );
	ch[0] = (char)5;
	csText.Replace( ch, "%c5" );
	ch[0] = (char)6;
	csText.Replace( ch, "%c6" );
	ch[0] = (char)7;
	csText.Replace( ch, "%c7" );
	ch[0] = (char)8;
	csText.Replace( ch, "%c8" );

	return csText;
}

int	CLcdMOrbital::GetRows()		// MZ, June 27
{
	return g_MOCfg.iRows;
}

int	CLcdMOrbital::GetColumns()	// MZ, June 27
{
	return g_MOCfg.iCols;
}

CDevSerial* CLcdMOrbital::GetSerialDevice()
{
	return m_pcDev;
}
