/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Device.h: interface for the CDevice class.
// Low level base class for serial and parallel devices. 
// Since this plugin is LCD related this device class is meant to be for LCDs. 
// But feel free to (ab)use it for other stuff...
//
// This class (should) defines a generic low level interface to communicate
// with LCD devices. 
// See subclasses CDevSerial, CDevParallel, CDevParallel8Bit etc.
//
//
// ATTENTION: INTERFACE IS *NOT* STABLE, JUST A FAST HACK...
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVICE_H__2B3057F4_7861_46CA_BFF4_D158B08CF083__INCLUDED_)
#define AFX_DEVICE_H__2B3057F4_7861_46CA_BFF4_D158B08CF083__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Timing.h"

class CInput;

class CDevice  
{
protected:
	BOOL	m_bWinNT;
	BOOL	m_bOpen;
	BOOL    m_bInit;
	BOOL    m_bMicroTiming;
	CTiming m_cTiming;
	CInput  *m_pcInput;

public:
	CDevice();
	virtual ~CDevice();

	// default implementations
	virtual BOOL IsOpen();
	virtual BOOL Close();

	// Methods that must be implemented

	// Opens the device
	// lpPort : device specific, for serial: "COMx", parallel: "0x378" - see specific device class
	// lpParam: device specific parameters
	virtual BOOL Open(LPCSTR lpPort, LPCSTR lpParam) = 0;

	// Reads data from the device. Data will be removed from the input queue.
	// For LCD devices this function is mapped to the keypad
	// buffer:   buffer to store read data
	// size:     how many bytes to read
	// blocking: TRUE  - waits until <size> bytes could be read
	//           FALSE - polls the device, if no data is ready 0 will be returned
	// return value: > 0 : number of read bytes.
	//                 0 : no data ready
	//                -1 : error (e.g. device is closed)
	//                -2 : parameter error / operation not supported
	virtual int ReadData(LPBYTE buffer, DWORD size, BOOL blocking = TRUE) = 0;

	virtual void SetInputDevice(CInput *pcIn);

	virtual void uPause (int usecs);


};

#endif // !defined(AFX_DEVICE_H__2B3057F4_7861_46CA_BFF4_D158B08CF083__INCLUDED_)
