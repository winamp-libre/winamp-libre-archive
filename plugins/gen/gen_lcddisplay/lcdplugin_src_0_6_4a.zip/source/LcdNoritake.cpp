/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LcdNoritake.cpp: implementation of the CLcdNoritake class.
// This is more of a hack than a clean implementation, but works fine ;)
// 
//
// Modifications:
// 2002/11/10 MZ  bugfix: don't call VFDxxx functions if low level driver 
//                (m_pcDev) is not instanciated!
// 2003/02/09 MZ  ConvertTagsToCustomChars now handles > 8 custom chars, some clean up
//                bugfix in the vfd library: the clear command needed a delay
// 2003/07/13 MZ  custom character map added 
//
// @TODO: 
// - make a clean implementation without the vfd library
// - custom fonts
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "LcdNoritake.h"

#include "vfdlib/vfdlib.h"
#include "vfdlib/vfdhw.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


CCfgNoritake	 g_NoritakeCfg;

// CONFIGURATION CLASS

// Custom chars in character map:
// 0 = space
// 1 = cursor
// 2 = start of user definable characters
#define CCHAR_START		  DEF_NO_CCHAR_START
#define CCHAR_END         DEF_NO_CCHAR_END 
#define MAX_CUSTOM_CHARS  CCHAR_END - CCHAR_START + 1

#define NORITAKE_SECTION  "Noritake"
#define NORITAKE_CHARMAP  "Noritake_CHARMAP"


// TEMPORARY HACK !!!!
CDevParallelNoritake *g_pcNoDev = NULL;

CCfgNoritake::CCfgNoritake()
{

	Load(g_szIniFile);

	// safety checks:
	if (iDelayInit > 100) {
		iDelayInit = DEF_NO_DELAY_INIT;
	}
}

CCfgNoritake::~CCfgNoritake()
{
	Save(g_szIniFile);
}

void CCfgNoritake::Load(LPCSTR lpIniFile)
{
	iPort = GetPrivateProfileInt(NORITAKE_SECTION,"Port",DEF_NO_PORT,lpIniFile); 
	iWidth = GetPrivateProfileInt(NORITAKE_SECTION,"Width",DEF_NO_WIDTH,lpIniFile); 			 
	iHeight = GetPrivateProfileInt(NORITAKE_SECTION,"Height",DEF_NO_HEIGHT,lpIniFile); 
	byCellW = (BYTE)GetPrivateProfileInt(NORITAKE_SECTION,"CellWidth", DEF_NO_CELL_W,lpIniFile); 
	byCellH = (BYTE)GetPrivateProfileInt(NORITAKE_SECTION,"CellHeight", DEF_NO_CELL_H,lpIniFile); 
	iDelayShort   = GetPrivateProfileInt(NORITAKE_SECTION,"DelayShort", DEF_NO_DELAY_SHORT,lpIniFile); 
	iDelayInit = GetPrivateProfileInt(NORITAKE_SECTION,"DelayInit", DEF_NO_DELAY_INIT,lpIniFile); 
	byBrightness = GetPrivateProfileInt(NORITAKE_SECTION,"Brightness", DEF_NO_BRIGHTNESS,lpIniFile); 
	bTurbo = GetPrivateProfileInt(NORITAKE_SECTION,"Turbo", 1,lpIniFile); 

	int type = GetPrivateProfileInt(NORITAKE_SECTION,"DelayType", 0,lpIniFile);
	DelayType = type ? VHR_TIMING : PORT_IO;
	BuildCharMap(NORITAKE_CHARMAP, lpIniFile, charMap);
}

void CCfgNoritake::Save(LPCSTR lpIniFile)
{
	char string[32];

	wsprintf(string,"%d",iPort);
	WritePrivateProfileString(NORITAKE_SECTION,"Port",string,lpIniFile);
	wsprintf(string,"%d",iWidth);
	WritePrivateProfileString(NORITAKE_SECTION,"Width",string,lpIniFile);
	wsprintf(string,"%d",iHeight);
	WritePrivateProfileString(NORITAKE_SECTION,"Height",string,lpIniFile);
	wsprintf(string,"%d",byCellW);
	WritePrivateProfileString(NORITAKE_SECTION,"CellWidth",string,lpIniFile);
	wsprintf(string,"%d",byCellH);
	WritePrivateProfileString(NORITAKE_SECTION,"CellHeight",string,lpIniFile);
	wsprintf(string,"%d",iDelayShort);
	WritePrivateProfileString(NORITAKE_SECTION,"DelayShort",string,lpIniFile);
	wsprintf(string,"%d",iDelayInit);
	WritePrivateProfileString(NORITAKE_SECTION,"DelayInit",string,lpIniFile);
	wsprintf(string,"%d",DelayType);
	WritePrivateProfileString(NORITAKE_SECTION,"DelayType",string,lpIniFile);
	wsprintf(string,"%d",byBrightness);
	WritePrivateProfileString(NORITAKE_SECTION,"Brightness",string,lpIniFile);
	wsprintf(string,"%d",bTurbo);
	WritePrivateProfileString(NORITAKE_SECTION,"Turbo",string,lpIniFile);
}


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdNoritake::CLcdNoritake()
{
	m_pcDev = NULL;
}

CLcdNoritake::~CLcdNoritake()
{
	Close();
}


BOOL  CLcdNoritake::Open()
{
	Close();

	// open low level communication driver
	m_pcDev = new CDevParallelNoritake();
	
	m_pcDev->SetDelayType(g_NoritakeCfg.DelayType);
	// attention: the 'delay long' value is abused as turbo switch!
	m_pcDev->SetDelays(g_NoritakeCfg.iDelayShort, 0, !g_NoritakeCfg.bTurbo,
		               g_NoritakeCfg.iDelayInit, 1);

	char szPort[10];
	wsprintf(szPort, "%d", g_NoritakeCfg.iPort);

	if (!m_pcDev->Open(szPort, NULL)) {
		return FALSE;
	}


	// initialize display
	// @HACK
	g_pcNoDev = m_pcDev;

    // start init sequence (see datasheet for more infos)
    Sleep(g_NoritakeCfg.iDelayInit);
    VFDWriteCommand(Init800A);
    Sleep(g_NoritakeCfg.iDelayInit);
        
    for (int n=0; n < 8; n++)
    {
        Sleep(g_NoritakeCfg.iDelayInit);
        VFDWriteCommand(Init800B);
        Sleep(g_NoritakeCfg.iDelayInit);
        VFDWriteCommand(Init800C);
        Sleep(g_NoritakeCfg.iDelayInit);
        VFDWriteData(Init800D);

    }
    // end of init sequence

	Sleep(g_NoritakeCfg.iDelayInit);
    VFDScreen1(1);                      /* layer1 on */
    VFDWriteCommand(ORON);              /* OR the screens */
    VFDWriteCommand(HSHIFT);            /* set horizontal shift */
    VFDWriteCommand(0x00);              /* no shift */
    VFDWriteCommand(VSHIFT);            /* Vertical shift =0 */

    VFDWriteCommand(AUTOINCOFF);        /* auto increm off   */
    VFDWriteCommand(SETX);              /* set x coord    */
    VFDWriteCommand(0x40);              /* to 0           */
    VFDWriteCommand(SETY);              /* set y coord    */
    VFDWriteCommand(0);                 /* to 0           */
    GlyphInit();                        /* init glyphs for WIN DEMO */

	
	// initialization done, set default values
	Clear();
	SetBrightness(g_NoritakeCfg.byBrightness);

	// create 'built-in' custom chars

    // custom chars for SA
	CCustomChar cChar;

	cChar.Set("0,0,0,0,0,0,0,31");
	CreateCustomChar(-1, cChar);
	cChar.Set("0,0,0,0,0,0,31,31");
	CreateCustomChar(-2, cChar);
	cChar.Set("0,0,0,0,0,31,31,31");
	CreateCustomChar(-3, cChar);
	cChar.Set("0,0,0,0,31,31,31,31");
	CreateCustomChar(-4, cChar);
	cChar.Set("0,0,0,31,31,31,31,31");
	CreateCustomChar(-5, cChar);
	cChar.Set("0,0,31,31,31,31,31,31");
	CreateCustomChar(-6, cChar);
	cChar.Set("0,31,31,31,31,31,31,31");
	CreateCustomChar(-7, cChar);
	cChar.Set("31,31,31,31,31,31,31,31");
	CreateCustomChar(-8, cChar);

	m_charMap = g_NoritakeCfg.charMap;

	m_bOpen = TRUE;
	return TRUE;
}

void  CLcdNoritake::Close()
{
	m_bOpen = FALSE;

	if (m_pcDev) {
		m_pcDev->Close();
		delete m_pcDev;
		m_pcDev = NULL;
	}
}

void  CLcdNoritake::Clear()
{
	if (m_pcDev) {
		VFDClearScreen(0);
	}
}

void  CLcdNoritake::SetBrightness(short nLevel)
{
	if (m_pcDev) {
		VFDLuminance((UCHAR)nLevel);
	}
}

void  CLcdNoritake::SetPosition(short x, short y)
{
	if (m_pcDev) {
		VFDSetGlyphCursor(y-1, x-1, 0);
	}
}

void  CLcdNoritake::Write(char c)
{
	if (m_pcDev) {
		VFDPutGlyphChar(c);
	}
}

void  CLcdNoritake::Write(LPCSTR lpText)
{
	if (m_pcDev) {

		static CString csText;
		csText = lpText;
		ConvertTextToLCDCharset(csText);
		LPCTSTR p = csText;

		while (*p != NULL) {
		  VFDPutGlyphChar(*p++);
		}
	}
}


BOOL  CLcdNoritake::CreateCustomChar(short n, CCustomChar &cChar)
{
	if (n > MAX_CUSTOM_CHARS)
		return FALSE;

	// @TODO remove memory leak below
	unsigned char *Glyph = new unsigned char[6];
	memset(Glyph, 0, 6);

	int iMax = __min(8, cChar.m_byDataSize);
	for (int i = 0; i < iMax; i++)
	{
		if (cChar.m_byarrData[i] > 31)
			cChar.m_byarrData[i] = 0;
		
		BYTE val = cChar.m_byarrData[iMax - i - 1];
		BYTE v2;

		v2 = (val & 1) << i;
		Glyph[5] |= v2;
		v2 = (val & 2) >> 1 << i;
		Glyph[4] |= v2;
		v2 = (val & 4) >> 2 << i;
		Glyph[3] |= v2;
		v2 = (val & 8) >> 3 << i;
		Glyph[2] |= v2;
		v2 = (val & 16) >> 4 << i;
		Glyph[1] |= v2;
		v2 = (val & 32) >> 5 << i;
		Glyph[0] |= v2;
	}

	// @BUG 'built-in block characters for spectrum analyser' doesn't work with mini-VU meter
	//       -> whole architecture of the visualization plugins needs to be changed anyway...
	short pos = n >= 0 ? CCHAR_START + n : -n;
    VFDSetGlyph(Glyph, (UCHAR)pos);     /* load characters */

	return FALSE;
}

short CLcdNoritake::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

LPCTSTR CLcdNoritake::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	char buf[6];
    int  number = MAX_CUSTOM_CHARS;

	ch[1] = '\0';

	for (int i = CCHAR_END; i >= CCHAR_START; i--) {
		ch[0] = (char)i;

	    wsprintf(buf, "%s%d", "%c", number--); 	
		csText.Replace( buf, ch );
	}

	return csText;
}

LPCTSTR CLcdNoritake::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	char buf[6];
    int  number = MAX_CUSTOM_CHARS;


	ch[1] = '\0';

	for (int i = CCHAR_END; i >= CCHAR_START; i--) {
		ch[0] = (char)i;

	    wsprintf(buf, "%s%d", "%c", number--); 	
		csText.Replace(ch, buf);
	}

	return csText;
}


int	CLcdNoritake::GetRows()
{
	return g_NoritakeCfg.iHeight / g_NoritakeCfg.byCellH;
}

int	CLcdNoritake::GetColumns()
{
	return g_NoritakeCfg.iWidth / g_NoritakeCfg.byCellW;
}

void CLcdNoritake::HandleKeyPad()
{
}

void  CLcdNoritake::SetBacklight(short nSeconds)
{
}

