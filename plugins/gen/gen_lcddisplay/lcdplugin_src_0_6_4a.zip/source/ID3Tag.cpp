/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// ID3Tag.cpp: Quick and dirty implementation of MP3-Tag accessing functions
//        
// Does now way more then it's name suggests, reads ID3v1 & v2, ogg vorbis and
// APE 1 & 2 tags
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2000/08/20 MZ  TrimTrailingSpaces added
// 2002/06/09 MZ  Ogg & APE tags added (code from Janne Hyv�rinen, thanx!)
// 2002/11/10 MZ  ID3v2 added (code from Douglas B., thanx!)
// 2002/11/12 MZ  ID3v2 hack added for simple tag check
// 2002/11/13 MZ  ID3v2 hack replaced with improved code from DB
// 2003/06/07 MZ  Read_ID3v2Tag:track tag added, year tag fixed 
// 2003/09/29 MZ  updated v1 tags
//
// @TODO more efficient file handling: open once and reuse!
//
/////////////////////////////////////////////////////////////////////////////

#define VORBIS_TAGS

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "ID3Tag.h"

#ifdef VORBIS_TAGS
	#include <vorbis/vorbisfile.h>
#endif

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

char *g_Genres[] = { 
	/* here goes the old genre definition...
"Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", \
"Hip-Hop", "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", \
"Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal", \
"Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", \
"Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", \
"Sound Clip", "Gospel", "Noise", "AlternRock", "Bass", "Soul", "Punk", "Space", \
"Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", \
"Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", \
"Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap", "Pop/Funk", \
"Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", \
"Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", \
"Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk/Rock", "National Folk", \
"Swing", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde", \
"Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", \
"Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", \
"Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", \
"Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore" 
	*/
	// and here comes the new one taken from the XBMP project ;) 
      "Blues","Classic Rock","Country","Dance","Disco","Funk","Grunge","Hip-Hop","Jazz",
      "Metal","New Age","Oldies","Other","Pop","R&B","Rap","Reggae","Rock","Techno",
      "Industrial","Alternative","Ska","Death Metal","Pranks","Soundtrack","Euro-Techno",
      "Ambient","Trip-Hop","Vocal","Jazz+Funk","Fusion","Trance","Classical","Instrumental",
      "Acid","House","Game","Sound Clip","Gospel","Noise","AlternRock","Bass","Soul","Punk",
      "Space","Meditative","Instrumental Pop","Instrumental Rock","Ethnic","Gothic",
      "Darkwave","Techno-Industrial","Electronic","Pop-Folk","Eurodance","Dream",
      "Southern Rock","Comedy","Cult","Gangsta","Top 40","Christian Rap","Pop/Funk","Jungle",
      "Native American","Cabaret","New Wave","Psychadelic","Rave","Showtunes","Trailer",
      "Lo-Fi","Tribal","Acid Punk","Acid Jazz","Polka","Retro","Musical","Rock & Roll",
      "Hard Rock","Folk","Folk-Rock","National Folk","Swing","Fast Fusion","Bebob","Latin",
      "Revival","Celtic","Bluegrass","Avantgarde","Gothic Rock","Progressive Rock",
      "Psychedelic Rock","Symphonic Rock","Slow Rock","Big Band","Chorus","Easy Listening",
      "Acoustic","Humour","Speech","Chanson","Opera","Chamber Music","Sonata","Symphony",
      "Booty Bass","Primus","Porn Groove","Satire","Slow Jam","Club","Tango","Samba",
      "Folklore","Ballad","Power Ballad","Rhythmic Soul","Freestyle","Duet","Punk Rock",
      "Drum Solo","Acapella","Euro-House","Dance Hall"
  };

// convert UTF-8 to Windows ANSI
int ConvertUTF8ToANSI ( char* buffer, const int buf_len )
{
    WCHAR*  wszValue;          // Unicode value
    size_t  utf8_len = strlen ( buffer );
    size_t  len;

    if ( (wszValue = (WCHAR *)malloc ( (utf8_len + 1) * 2 )) == NULL )
        return 1;

    // Convert UTF-8 value to Unicode
    if ( (len = MultiByteToWideChar ( CP_UTF8, 0, buffer, utf8_len + 1, wszValue, (utf8_len + 1) * 2 )) == 0 ) {
        free ( wszValue );
        return 1;
    }

    // Convert Unicode value to ANSI
    if ( (len = WideCharToMultiByte ( CP_ACP, 0, wszValue, -1, buffer, buf_len, NULL, NULL )) == 0 ) {
        free ( wszValue );
        return 1;
    }

    free ( wszValue );
    return 0;
}

int GenreToInteger ( const char* GenreStr )
{
    size_t  i;

    for ( i = 0; i < sizeof(g_Genres) / sizeof(*g_Genres); i++ ) {
        if ( 0 == _stricmp ( GenreStr, g_Genres [i] ) )
            return i;
    }

    return 255;
}

unsigned long Read_LE_Uint32 ( const unsigned char *p )
{
    return ((unsigned long)p[0] <<  0) |
           ((unsigned long)p[1] <<  8) |
           ((unsigned long)p[2] << 16) |
           ((unsigned long)p[3] << 24);
}

struct APETagFooterStruct
{
    unsigned char   ID       [8];    // should equal 'APETAGEX'
    unsigned char   Version  [4];    // currently 1000 (version 1.000)
    unsigned char   Length   [4];    // the complete size of the tag, including this footer
    unsigned char   TagCount [4];    // the number of fields in the tag
    unsigned char   Flags    [4];    // the tag flags (none currently defined)
    unsigned char   Reserved [8];    // reserved for later use
};

BOOL CID3Tag::Read_APE1Tag ( const char* filename )
{
    unsigned long              len;
    unsigned long              tl;
    unsigned long              flags;
    unsigned char*             buff;
    unsigned char*             p;
    unsigned char*             end;
    struct APETagFooterStruct  T;
    unsigned long              TagLen;
    unsigned long              TagCount;
    FILE*                      fp;

    if ( (fp = fopen (filename, "rb")) == NULL )
        return FALSE;

    buff = NULL;
    if ( fseek ( fp, -(long)sizeof T, SEEK_END ) != NULL )
        goto notag;
    if ( sizeof T != fread ( &T, 1, sizeof T, fp ) )
        goto notag;
    if ( memcmp ( T.ID, "APETAGEX", sizeof T.ID ) != 0 )
        goto notag;
    if ( Read_LE_Uint32 (T.Version) != 1000 )
        goto notag;
    TagLen = Read_LE_Uint32 (T.Length);
    if ( TagLen <= sizeof T )
        goto notag;
    if ( fseek ( fp, -(long)TagLen, SEEK_END ) != NULL )
        goto notag;
    if ( (buff = (unsigned char *)malloc ( TagLen + 1 )) == NULL )
        goto notag;
    if ( TagLen - sizeof T != fread ( buff, 1, TagLen - sizeof T, fp ) )
        goto notag;

    TagCount = Read_LE_Uint32 (T.TagCount);
    end = buff + TagLen - sizeof (T);

    for ( p = buff; p < end && TagCount--; ) {
        len   = Read_LE_Uint32 ( p ); p += 4;
        flags = Read_LE_Uint32 ( p ); p += 4;

        if ( 0 == memicmp (p, "Title", 6 ) ) {
            tl = len < sizeof(m_szSongName) ? len : sizeof(m_szSongName)-1;
            p += 6;
            memcpy ( m_szSongName, p, tl );
            m_szSongName[tl] = '\0';
            p += len;
        } else
        if ( 0 == memicmp (p, "Artist", 7 ) ) {
            tl = len < sizeof(m_szArtist) ? len : sizeof(m_szArtist)-1;
            p += 7;
            memcpy ( m_szArtist, p, tl );
            m_szArtist[tl] = '\0';
            p += len;
        } else
        if ( 0 == memicmp (p, "Album", 6 ) ) {
            tl = len < sizeof(m_szAlbum) ? len : sizeof(m_szAlbum)-1;
            p += 6;
            memcpy ( m_szAlbum, p, tl );
            m_szAlbum[tl] = '\0';
            p += len;
        } else
        if ( 0 == memicmp (p, "Comment", 8 ) ) {
            tl = len < sizeof(m_szComment) ? len : sizeof(m_szComment)-1;
            p += 8;
            memcpy ( m_szComment, p, tl );
            m_szComment[tl] = '\0';
            p += len;
        } else
        if ( 0 == memicmp (p, "Year", 5 ) ) {
            tl = len < sizeof(m_szYear) ? len : sizeof(m_szYear)-1;
            p += 5;
            memcpy ( m_szYear, p, tl );
            m_szYear[tl] = '\0';
            p += len;
        } else
        if ( 0 == memicmp (p, "Track", 6 ) ) {
            tl = len < sizeof(m_szTrack) ? len : sizeof(m_szTrack)-1;
            p += 6;
            memcpy ( m_szTrack, p, tl );
            m_szTrack[tl] = '\0';
            p += len;
        } else
        if ( 0 == memicmp (p, "Genre", 6 ) ) {
            tl = len < sizeof(m_szGenre) ? len : sizeof(m_szGenre)-1;
            p += 6;
            memcpy ( m_szGenre, p, tl );
            m_szGenre[tl] = '\0';
            p += len;
            m_byGenre = GenreToInteger ( m_szGenre );
        } else
        {
            p += strlen((char *)p) + 1 + len;
        }
    }

    free ( buff );
    fclose (fp);
    m_bTag = TRUE;
    return TRUE;

notag:
    free ( buff );
    fclose (fp);
    return FALSE;
}

BOOL CID3Tag::Read_APE2Tag ( const char* filename )
{
    unsigned long              len;
    unsigned long              tl;
    unsigned long              flags;
    unsigned char*             buff;
    unsigned char*             p;
    unsigned char*             end;
    struct APETagFooterStruct  T;
    unsigned long              TagLen;
    unsigned long              TagCount;
    FILE*                      fp;

    if ( (fp = fopen (filename, "rb")) == NULL )
        return FALSE;

    buff = NULL;
    if ( fseek ( fp, -(long)sizeof T, SEEK_END ) != NULL )
        goto notag;
    if ( sizeof T != fread ( &T, 1, sizeof T, fp ) )
        goto notag;
    if ( memcmp ( T.ID, "APETAGEX", sizeof T.ID ) != 0 )
        goto notag;
    if ( Read_LE_Uint32 (T.Version) != 2000 )
        goto notag;
    TagLen = Read_LE_Uint32 (T.Length);
    if ( TagLen <= sizeof T )
        goto notag;
    if ( fseek ( fp, -(long)TagLen, SEEK_END ) != NULL )
        goto notag;
    if ( (buff = (unsigned char *)malloc ( TagLen + 1 )) == NULL )
        goto notag;
    if ( TagLen - sizeof T != fread ( buff, 1, TagLen - sizeof T, fp ) )
        goto notag;

    TagCount = Read_LE_Uint32 (T.TagCount);
    end = buff + TagLen - sizeof (T);

    for ( p = buff; p < end && TagCount--; ) {
        len   = Read_LE_Uint32 ( p ); p += 4;
        flags = Read_LE_Uint32 ( p ); p += 4;

        if ( 0 == memicmp (p, "Title", 6 ) ) {
            tl = len < sizeof(m_szSongName) ? len : sizeof(m_szSongName)-1;
            p += 6;
            memcpy ( m_szSongName, p, tl );
            m_szSongName[tl] = '\0';
            p += len;
            ConvertUTF8ToANSI ( m_szSongName, sizeof (m_szSongName) );
        } else
        if ( 0 == memicmp (p, "Artist", 7 ) ) {
            tl = len < sizeof(m_szArtist) ? len : sizeof(m_szArtist)-1;
            p += 7;
            memcpy ( m_szArtist, p, tl );
            m_szArtist[tl] = '\0';
            p += len;
            ConvertUTF8ToANSI ( m_szArtist, sizeof (m_szArtist) );
        } else
        if ( 0 == memicmp (p, "Album", 6 ) ) {
            tl = len < sizeof(m_szAlbum) ? len : sizeof(m_szAlbum)-1;
            p += 6;
            memcpy ( m_szAlbum, p, tl );
            m_szAlbum[tl] = '\0';
            p += len;
            ConvertUTF8ToANSI ( m_szAlbum, sizeof (m_szAlbum) );
        } else
        if ( 0 == memicmp (p, "Comment", 8 ) ) {
            tl = len < sizeof(m_szComment) ? len : sizeof(m_szComment)-1;
            p += 8;
            memcpy ( m_szComment, p, tl );
            m_szComment[tl] = '\0';
            p += len;
            ConvertUTF8ToANSI ( m_szComment, sizeof (m_szComment) );
        } else
        if ( 0 == memicmp (p, "Year", 5 ) ) {
            tl = len < sizeof(m_szYear) ? len : sizeof(m_szYear)-1;
            p += 5;
            memcpy ( m_szYear, p, tl );
            m_szYear[tl] = '\0';
            p += len;
            ConvertUTF8ToANSI ( m_szYear, sizeof (m_szYear) );
        } else
        if ( 0 == memicmp (p, "Track", 6 ) ) {
            tl = len < sizeof(m_szTrack) ? len : sizeof(m_szTrack)-1;
            p += 6;
            memcpy ( m_szTrack, p, tl );
            m_szTrack[tl] = '\0';
            p += len;
            ConvertUTF8ToANSI ( m_szTrack, sizeof (m_szTrack) );
        } else
        if ( 0 == memicmp (p, "Genre", 6 ) ) {
            tl = len < sizeof(m_szGenre) ? len : sizeof(m_szGenre)-1;
            p += 6;
            memcpy ( m_szGenre, p, tl );
            m_szGenre[tl] = '\0';
            p += len;
            ConvertUTF8ToANSI ( m_szGenre, sizeof (m_szGenre) );
            m_byGenre = GenreToInteger ( m_szGenre );
        } else
        {
            p += strlen((char *)p) + 1 + len;
        }
    }

    free ( buff );
    fclose (fp);
    m_bTag = TRUE;
    return TRUE;

notag:
    free ( buff );
    fclose (fp);
    return FALSE;
}


#ifdef VORBIS_TAGS
BOOL CID3Tag::Read_OggTag ( const char* filename )
{
    OggVorbis_File      vf;
    vorbis_comment*     vc;
    FILE*               fp;
    size_t              i;

    if ( (fp = fopen ( filename, "rb" )) == NULL )
        return FALSE;
    if ( ov_open (fp, &vf, NULL, 0 ) != 0 ) {
        fclose (fp);
        return FALSE;
    }
    if ( (vc = ov_comment ( &vf, -1 )) == NULL ) {
        ov_clear (&vf);
        return FALSE;
    }

    for ( i = 0; i < (size_t)vc->comments; i++ ) {
        if ( vc->user_comments[i] == NULL || vc->user_comments[i][0] == '\0' )  // empty field
            continue;

        if ( strnicmp ( vc->user_comments[i], "DATE=", 5 ) == 0 ) {
            strncpy ( m_szYear, vc->user_comments[i] + 5, sizeof(m_szYear)-1 );
            m_szYear[sizeof(m_szYear)-1] = '\0';
            ConvertUTF8ToANSI ( m_szYear, sizeof (m_szYear) );
        }
        else if ( strnicmp ( vc->user_comments[i], "TITLE=", 6 ) == 0 ) {
            strncpy ( m_szSongName, vc->user_comments[i] + 6, sizeof(m_szSongName)-1 );
            m_szSongName[sizeof(m_szSongName)-1] = '\0';
            ConvertUTF8ToANSI ( m_szSongName, sizeof (m_szSongName) );
        }
        else if ( strnicmp ( vc->user_comments[i], "ARTIST=", 7 ) == 0 ) {
            strncpy ( m_szArtist, vc->user_comments[i] + 7, sizeof(m_szArtist)-1 );
            m_szArtist[sizeof(m_szArtist)-1] = '\0';
            ConvertUTF8ToANSI ( m_szArtist, sizeof (m_szArtist) );
        }
        else if ( strnicmp ( vc->user_comments[i], "ALBUM=", 6 ) == 0 ) {
            strncpy ( m_szAlbum, vc->user_comments[i] + 6, sizeof(m_szAlbum)-1 );
            m_szAlbum[sizeof(m_szAlbum)-1] = '\0';
            ConvertUTF8ToANSI ( m_szAlbum, sizeof (m_szAlbum) );
        }
        else if ( strnicmp ( vc->user_comments[i], "COMMENT=", 8 ) == 0 ) {
            strncpy ( m_szComment, vc->user_comments[i] + 8, sizeof(m_szComment)-1 );
            m_szComment[sizeof(m_szComment)-1] = '\0';
            ConvertUTF8ToANSI ( m_szComment, sizeof (m_szComment) );
        }
        else if ( strnicmp ( vc->user_comments[i], "GENRE=", 6 ) == 0 ) {
            strncpy ( m_szGenre, vc->user_comments[i] + 6, sizeof(m_szGenre)-1 );
            m_szGenre[sizeof(m_szGenre)-1] = '\0';
            ConvertUTF8ToANSI ( m_szGenre, sizeof (m_szGenre) );
            m_byGenre = GenreToInteger ( m_szGenre );
        }
        else if ( strnicmp ( vc->user_comments[i], "TRACKNUMBER=", 12 ) == 0 ) {
            strncpy ( m_szTrack, vc->user_comments[i] + 12, sizeof(m_szTrack)-1 );
            m_szTrack[sizeof(m_szTrack)-1] = '\0';
            ConvertUTF8ToANSI ( m_szTrack, sizeof (m_szTrack) );
        }
    }

    ov_clear (&vf);

    m_bTag = TRUE;
    return TRUE;
}
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CID3Tag::CID3Tag()
{
	Reset();
}

CID3Tag::CID3Tag(LPCSTR lpFileName)
{
	ReadTag(lpFileName);
}

CID3Tag::~CID3Tag()
{

}


void CID3Tag::Reset()
{
	m_bTag = FALSE;
	m_byGenre = 255;

    memset ( &m_szYear    , 0, sizeof (m_szYear    ) );
    memset ( &m_szTrack   , 0, sizeof (m_szTrack   ) );
    memset ( &m_szAlbum   , 0, sizeof (m_szAlbum   ) );
    memset ( &m_szGenre   , 0, sizeof (m_szGenre   ) );
    memset ( &m_szArtist  , 0, sizeof (m_szArtist  ) );
    memset ( &m_szComment , 0, sizeof (m_szComment ) );
    memset ( &m_szSongName, 0, sizeof (m_szSongName) );
}

BOOL CID3Tag::ReadTag(LPCSTR lpFileName)
{
    BOOL tag;

	Reset();

	if (lpFileName == NULL)
		return FALSE;

	// MZ @TODO make tag preferences configurable, e.g. only read ID3v1 and ignore ID3v2 etc.
    tag = Read_APE2Tag ( lpFileName );
    if ( !tag ) 
		tag = Read_APE1Tag ( lpFileName );
    if ( !tag ) 
		tag = Read_ID3v2Tag ( lpFileName );
    if ( !tag ) 
		tag = Read_ID3v1Tag ( lpFileName );

#ifdef VORBIS_TAGS
	if ( !tag ) 
		tag = Read_OggTag ( lpFileName );
#endif

	return tag;
}

BOOL CID3Tag::Read_ID3v2Tag(LPCSTR lpFileName)
{
	char	szTemp[ID3TAG_BUFFER_SIZE];

	if (lpFileName == NULL)
		return FALSE;
	try
	{
		CFile cFile(lpFileName, CFile::modeRead | CFile::shareDenyNone);

        cFile.Read(szTemp, 3);                  // Is this an ID3v2 file?
		if (strncmp(szTemp, "ID3", 3) != 0)
			return FALSE;	// no tag available

		int  Size ;
		int  HeaderSize ;
		DWORD dwFileLen = cFile.GetLength();

		strcpy( m_szSongName, "" ) ;
		strcpy( m_szArtist,   "" ) ;
		strcpy( m_szAlbum,    "" ) ;
		strcpy( m_szYear,     "" ) ;
		strcpy( m_szComment,  "" ) ;
		strcpy( m_szGenre,    "" ) ;
		strcpy( m_szTrack,    "" ) ;

		cFile.Read(szTemp, 2);              // Read the Revision
		if( szTemp[0] == 0x03 )             // handle rev3 only
		{
			cFile.Read(szTemp, 1) ;         // Configuration Bits
			cFile.Read(szTemp, 4) ;         // Header Length
			HeaderSize = ( (szTemp[3]&0x7F)     +
						  ((szTemp[2]&0x7F)<<7) +
						  ((szTemp[1]&0x7F)<<14)+
						  ((szTemp[0]&0x7F)<<21)
						 )-1 ;

			cFile.Read(szID, 4) ;           // Frame Name
			szID[4] = '\0';

			while(	( ( szID[0] + szID[1] + szID[2] + szID[3] ) != 0 )
					&& ( HeaderSize > 7 ) // Still more info?
				 )
			{
				cFile.Read(szTemp, 4) ;    // Frame Size
				Size = ( (((unsigned int)szTemp[3])&0x000000FF)     +
					    ((((unsigned int)szTemp[2])&0x000000FF)<<8 )+
						((((unsigned int)szTemp[1])&0x000000FF)<<16)+
						((((unsigned int)szTemp[0])&0x000000FF)<<24)
					   ) ;
				cFile.Read(szTemp, 3) ;    // Frame Flags
				HeaderSize -= (7+Size) ;   // subtract bytes read from total header size

                if( Size > 0 ) // Do we even need to read this block?
				{
					Size -= 1 ;
					if( Size < ID3TAG_BUFFER_SIZE ) // can we handle the block size?
					{
						if( strncmp(szID, "TIT2", 4) == 0 )
						{
							cFile.Read(m_szSongName, Size);
							m_szSongName[Size]='\0' ;
						}
						else if( strncmp(szID, "TALB", 4) == 0 )
						{
						   cFile.Read(m_szAlbum, Size);
						   m_szAlbum[Size]='\0' ;
						}
						else if( strncmp(szID, "TCON", 4) == 0 )
						{
						   cFile.Read(m_szGenre, Size);
						   m_szGenre[Size]='\0' ;
						}
						else if( strncmp(szID, "TPE1", 4) == 0 )
						{
						   cFile.Read(m_szArtist, Size);
						   m_szArtist[Size]='\0' ;
						}
						else if( strncmp(szID, "COMM", 4) == 0 )
						{
						   cFile.Read(m_szComment, Size);
						   m_szComment[Size]='\0' ;
						}
						else if( strncmp(szID, "TYER", 4) == 0 )	// tag name fixed MZ 2003/06/07
						{
						   cFile.Read(m_szYear, Size);
						   m_szYear[Size]='\0' ;
						}
						else if( strncmp(szID, "TRCK", 4) == 0 )	// added MZ 2003/06/07
						{
						   cFile.Read(m_szTrack, Size);
						   m_szTrack[Size]='\0' ;
						}
						else
						{
							cFile.Read(szTemp, Size);
						}
					}
					else  // very large block, so toss all the data
					{
						cFile.Seek( Size, CFile::current ) ;
					}
				}
				else // Size 0 Block... OK. I don't get this at all, but I need to back up here!
				{
					cFile.Seek( -1, CFile::current ) ;
				}


				memset(szID, 5, 0);
				if (cFile.GetPosition() < dwFileLen - 4) {
					cFile.Read(szID, 4) ;      // Read Next Frame Name
				}
			}
		}
		else  // Not ID3V2.3
		{
			cFile.Close();
			return FALSE ;
		}
	}
	catch (CFileException* e)	
	{
		#ifdef _DEBUG
			afxDump << "File error: " << e->m_cause << "\n";   
		#endif
		return FALSE;
	}
	catch (...) 
	{
		#ifdef _DEBUG
			afxDump << "FATAL ERROR IN CID3Tag::Read_ID3v2Tag\n";   
		#endif
		return FALSE;
	}

	m_bTag = TRUE;
	return TRUE;
}

BOOL CID3Tag::Read_ID3v1Tag(LPCSTR lpFileName)
{
	char	szTemp[4];

	if (lpFileName == NULL)
		return FALSE;

	try
	{
		CFile cFile(lpFileName, CFile::modeRead | CFile::shareDenyNone);

		cFile.Seek(-128, CFile::end);

		cFile.Read(szTemp, 3);
		if (strncmp(szTemp, "TAG", 3) != 0)
			return FALSE;	// no tag available

		cFile.Read(m_szSongName, 30);
		TrimTrailingSpaces(m_szSongName);
		cFile.Read(m_szArtist, 30);
		TrimTrailingSpaces(m_szArtist);
		cFile.Read(m_szAlbum, 30);
		TrimTrailingSpaces(m_szAlbum);
		cFile.Read(m_szYear, 4);
		TrimTrailingSpaces(m_szYear);
		cFile.Read(m_szComment, 30);
		TrimTrailingSpaces(m_szComment);
		cFile.Read(&m_byGenre, 1);

		if (m_szComment[28] == 0)
			wsprintf( m_szTrack, "%02d", (int)(BYTE)m_szComment[29] );
		else
			strcpy( m_szTrack, "--" );	// M.Z. 26.12.99

	}
	catch (CFileException* e)	
	{
		#ifdef _DEBUG
			afxDump << "File error: " << e->m_cause << "\n";   
		#endif
		return FALSE;
	}

	m_bTag = TRUE;
	return TRUE;
}

BOOL CID3Tag::hasID3Tag()
{
	return m_bTag;
}

LPCSTR CID3Tag::GetTitle()
{
	return m_szSongName;
}

LPCSTR CID3Tag::GetArtist()
{
	return m_szArtist;
}


LPCSTR CID3Tag::GetAlbum()
{
	return m_szAlbum;
}

LPCSTR CID3Tag::GetYear()
{
	return m_szYear;
}

LPCSTR CID3Tag::GetComment()
{
	return m_szComment;
}

LPCSTR CID3Tag::GetTrackNumber()
{
	return m_szTrack;
}

LPCSTR CID3Tag::GetGenre()
{
    if (m_szGenre[0] != '\0' )
        return m_szGenre;

	if (m_byGenre == 255)				// no genre defined
		return "";

	if (m_byGenre > sizeof(g_Genres))	// undefined genre
		return "?";

	return g_Genres[m_byGenre];
}

LPSTR CID3Tag::TrimTrailingSpaces(LPSTR lpString)
{
	int iEnd = strlen(lpString) - 1;
	if (iEnd > 0)
		while (lpString[iEnd] == ' ')
			lpString[iEnd--] = '\0';
	return lpString;
}
