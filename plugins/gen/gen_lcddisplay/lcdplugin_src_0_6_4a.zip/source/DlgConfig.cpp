/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgConfig.cpp:   Configuration property sheet dialog
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgConfig.h"
#include "DlgInputWinLIRC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgConfig

IMPLEMENT_DYNAMIC(CDlgConfig, CPropertySheet)

CDlgConfig::CDlgConfig(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	cDisplayPage.Construct( IDD_PAGE_DISPLAY );
	cConfigPage.Construct( IDD_PAGE_CONFIG );
	cVariablePage.Construct( IDD_PAGE_VARIABLES );
	cOutputPage.Construct(  IDD_PAGE_OUTPUT );
//	cDlgPageAbout.Construct( IDD_PAGE_ABOUT );

//	pcInputPage = new CComboPage(IDD_PAGE_INPUT);
//	CDlgInputWinLIRC cInWinLirc;

//	pcInputPage->AddPage(&cInWinLirc, cInWinLirc.IDD);
	
	AddPage( &cDisplayPage );
	AddPage( &cConfigPage );
	AddPage( &cVariablePage );
	AddPage( &cOutputPage );
//	AddPage( &cDlgPageKeys );
//	AddPage( pcInputPage );
//	AddPage( &cDlgPageAbout );
}

CDlgConfig::~CDlgConfig()
{
//	delete pcInputPage;
}


BEGIN_MESSAGE_MAP(CDlgConfig, CPropertySheet)
	//{{AFX_MSG_MAP(CDlgConfig)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


