/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallel.h: interface for the CDevParallel class.
// Provides basic parallel port functionality like reading and writing from
// ports. Supports Windows NT!
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVPARALLEL_H__ACE4631B_0EAB_44B0_A02B_14A1A44965E7__INCLUDED_)
#define AFX_DEVPARALLEL_H__ACE4631B_0EAB_44B0_A02B_14A1A44965E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Device.h"
#include "lpt-port.h"

// Maximum sizes of the keypad
// DO NOT CHANGE THESE 2 VALUES, unless you change the functions too
#define KEYPAD_MAXX 5
#define KEYPAD_MAXY 11


class CDevParallel : public CDevice  
{

protected:
	typedef UCHAR (CALLBACK *READCHAR)(ULONG);
	typedef void  (CALLBACK *WRITECHAR)(ULONG, UCHAR);

	int			m_iPort;
	DELAY_TYPES m_DelayType;

	READCHAR    m_lpfnReadChar;
	WRITECHAR	m_lpfnWriteChar;

	HINSTANCE	m_hDriver; 

	// Keypad, backlight extended interface and delay options
	BOOL have_keypad;	 // off by default

	// delays
	int  delayMult;	 // Delay multiplier for slow displays
	WORD m_delayShort;
	WORD m_delayMedium;
	WORD m_delayLong;
	WORD m_delayInit;

	// keyMapDirect contains an array of the ascii-codes that should be generated
	// when a directly connected key is pressed (not in matrix).
	char *keyMapDirect[KEYPAD_MAXX];

	// keyMapMatrix contrains an array with arrays of the ascii-codes that should be generated
	// when a key in the matrix is pressed.
	char *keyMapMatrix[KEYPAD_MAXY][KEYPAD_MAXX];

	char pressed_key;
	DWORD pressed_key_repetitions;
	DWORD pressed_key_time;



public:
	CDevParallel();
	virtual ~CDevParallel();
	virtual void SetDelays(WORD Short, WORD Medium, WORD Long, WORD Init, BYTE factor);

	// custom (overriden) implementations of the base driver
	virtual BOOL Open(LPCSTR lpPort, LPCSTR lpParam);
	virtual BOOL Close();
	virtual BOOL SetDelayType(DELAY_TYPES type);

	// returns keypad input
	virtual int  ReadData(LPBYTE buffer, DWORD size, BOOL blocking = TRUE);

	// reads and buffers keypad inputs.
	// must continiously be called by the real LCD driver or the main loop that calls
	// the LCD driver! (i.e. from one thread only!)
	// --> synchronization of port IO, to avoid implementing port access synchronization...
	// Any other  'keypad client' must call ReadData to get keypad inputs!
	virtual void HandleKeyPad();

	// custom (overriden) implementations of the base driver
	virtual void uPause (int usecs);

protected:
	// methods each parallel driver has to implement:
	virtual unsigned char readkeypad (unsigned int YData) = 0;

	// utility methods with a default implementation
	virtual void port_out(unsigned short port, BYTE value);
	virtual BYTE port_in(unsigned short port);
	virtual char getkey();
	virtual unsigned char scankeypad();

};

#endif // !defined(AFX_DEVPARALLEL_H__ACE4631B_0EAB_44B0_A02B_14A1A44965E7__INCLUDED_)
