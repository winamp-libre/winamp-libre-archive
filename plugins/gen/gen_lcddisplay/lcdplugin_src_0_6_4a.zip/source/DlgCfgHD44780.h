/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DLGCFGHD44780_H__74FAA1A2_C077_11D3_8F31_0000E871C360__INCLUDED_)
#define AFX_DLGCFGHD44780_H__74FAA1A2_C077_11D3_8F31_0000E871C360__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgCfgHD44780.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgHD44780 dialog

class CDlgCfgHD44780 : public CDialog
{
// Construction
public:
	CDlgCfgHD44780(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgCfgHD44780)
	enum { IDD = IDD_CFG_HD44780 };
	CString m_csPort;
	CString	m_csRows;
	CString	m_csCols;
	BOOL	m_bSplitScreens;
	BYTE	m_byCellWidth;
	BYTE	m_byCellHeight;
	int		m_iBus;
	int		m_iInit;
	int		m_iLong;
	int		m_iMedium;
	int		m_iMulitplier;
	int		m_iShort;
	BOOL	m_bBacklight;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCfgHD44780)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgCfgHD44780)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDefBtn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCFGHD44780_H__74FAA1A2_C077_11D3_8F31_0000E871C360__INCLUDED_)
