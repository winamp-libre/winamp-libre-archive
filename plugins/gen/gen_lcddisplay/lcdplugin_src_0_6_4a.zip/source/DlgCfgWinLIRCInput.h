#if !defined(AFX_DLGCFGWINLIRCINPUT_H__5F17F9EE_AC9B_4EB1_8744_9F8415D6E57D__INCLUDED_)
#define AFX_DLGCFGWINLIRCINPUT_H__5F17F9EE_AC9B_4EB1_8744_9F8415D6E57D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgCfgWinLIRCInput.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgWinLIRCInput dialog

class CDlgCfgWinLIRCInput : public CDialog
{
// Construction
public:
	CDlgCfgWinLIRCInput(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgCfgWinLIRCInput)
	enum { IDD = IDD_INPUT_WINLIRC_CFG };
	BYTE	m_byRepCount;
	int		m_iRepDelay;
	int		m_iPort;
	CString	m_csServer;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCfgWinLIRCInput)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgCfgWinLIRCInput)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDefault();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCFGWINLIRCINPUT_H__5F17F9EE_AC9B_4EB1_8744_9F8415D6E57D__INCLUDED_)
