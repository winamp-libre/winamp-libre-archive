/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgCfgCrystalfontz.cpp:   LCD display configuration property page
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/08/03 MZ  replaced hard coded LCD driver access with dynamic methods through CLCDFactory 
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgCfgCrystalfontz.h"
#include "LcdCrystalFontz.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgCrystalfontz property page

IMPLEMENT_DYNCREATE(CDlgCfgCrystalfontz, CDialog)

CDlgCfgCrystalfontz::CDlgCfgCrystalfontz(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCfgCrystalfontz::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCfgCrystalfontz)
	m_bBlink = FALSE;
	m_bCursor = FALSE;
	m_bScroll = FALSE;
	m_bWrap = FALSE;
	m_csCols = _T("");
	m_csRows = _T("");
	m_csBaudRate = _T("");
	m_csComPort = _T("");
	//}}AFX_DATA_INIT
}

CDlgCfgCrystalfontz::~CDlgCfgCrystalfontz()
{
}

void CDlgCfgCrystalfontz::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCfgCrystalfontz)
	DDX_Control(pDX, IDC_BRIGHTNESS_SLIDER, m_cBrightnessSlider);
	DDX_Control(pDX, IDC_CONTRAST_SLIDER, m_cContrastSlider);
	DDX_Check(pDX, IDC_CHECK_BLINK, m_bBlink);
	DDX_Check(pDX, IDC_CHECK_CURSOR, m_bCursor);
	DDX_Check(pDX, IDC_CHECK_SCROLL, m_bScroll);
	DDX_Check(pDX, IDC_CHECK_WRAP, m_bWrap);
	DDX_CBString(pDX, IDC_COMBO_COLS, m_csCols);
	DDV_MaxChars(pDX, m_csCols, 3);
	DDX_CBString(pDX, IDC_COMBO_ROWS, m_csRows);
	DDV_MaxChars(pDX, m_csRows, 3);
	DDX_CBString(pDX, IDC_COMBO_BAUDRATE, m_csBaudRate);
	DDX_CBString(pDX, IDC_COMBO_COMPORT, m_csComPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCfgCrystalfontz, CDialog)
	//{{AFX_MSG_MAP(CDlgCfgCrystalfontz)
	ON_BN_CLICKED(IDC_DEF_BTN, OnDefBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgCrystalfontz message handlers

BOOL CDlgCfgCrystalfontz::OnInitDialog() 
{
	char	szTemp[10];

	CDialog::OnInitDialog();
	
	m_csOldComPort = m_csComPort  = g_CFCfg.szComPort;
	m_csOldBaudRate = m_csBaudRate = g_CFCfg.szBaudRate;

	m_bBlink = g_CFCfg.bBlink;
	m_bCursor = g_CFCfg.bShowCursor;
	m_bScroll = g_CFCfg.bScroll;
	m_bWrap = g_CFCfg.bWrap;
	m_csCols = itoa( g_CFCfg.iCols, szTemp, 10 );
	m_csRows = itoa( g_CFCfg.iRows, szTemp, 10 );

	m_cContrastSlider.SetRange(0, 100);
	m_cContrastSlider.SetPos(g_CFCfg.byContrast);

	m_cBrightnessSlider.SetRange(0, 100);
	m_cBrightnessSlider.SetPos(g_CFCfg.byBrightness);


	UpdateData( FALSE );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCfgCrystalfontz::OnOK() 
{	
  char szBuffer1[512];

	UpdateData();

	strncpy( g_CFCfg.szComPort, m_csComPort, sizeof(g_CFCfg.szComPort) );
	strncpy( g_CFCfg.szBaudRate, m_csBaudRate, sizeof(g_CFCfg.szBaudRate) );

	m_csOldComPort = m_csComPort, m_csOldBaudRate = m_csBaudRate;
	g_CFCfg.bBlink = m_bBlink;
	g_CFCfg.bShowCursor = m_bCursor;
	g_CFCfg.bScroll = m_bScroll;
	g_CFCfg.bWrap = m_bWrap;
	g_CFCfg.iCols = atoi( m_csCols );
	g_CFCfg.iRows = atoi( m_csRows );
	g_CFCfg.byContrast = m_cContrastSlider.GetPos();
	g_CFCfg.byBrightness = m_cBrightnessSlider.GetPos();

    LCD_DRIVER *pDrv = g_LCDFactory.GetDriver(DRV_CRYSTALFONTZ);

	if (pDrv && (g_LCD == pDrv->pcLcd) && (pDrv->pcLcd != NULL))
	{
		if (m_csOldComPort != m_csComPort || m_csOldBaudRate != m_csBaudRate)
		{
		    LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_MO1, szBuffer1, sizeof(szBuffer1));
			if (MessageBox( szBuffer1, g_szAppName, MB_YESNO | MB_ICONQUESTION ) == IDYES)
			{
				g_LCDFactory.OpenLCD(pDrv->pcLcd);

				UpdateData(FALSE);
			}
		}
		pDrv->pcLcd->SetBlink(m_bBlink);
		pDrv->pcLcd->Cursor(m_bCursor);
		pDrv->pcLcd->SetScroll(m_bScroll);
		pDrv->pcLcd->SetLineWrap(m_bWrap);
		pDrv->pcLcd->SetContrast(g_CFCfg.byContrast);
		pDrv->pcLcd->SetBrightness(g_CFCfg.byBrightness);
	}

	CDialog::OnOK();
}

void CDlgCfgCrystalfontz::OnDefBtn() 
{
	m_csComPort  = DEF_COMPORT_CF;
	m_csBaudRate = DEF_BAUDRATE_CF;
	m_bBlink = m_bCursor = FALSE;
	m_bScroll = FALSE;
	m_bWrap = TRUE;
	m_csCols = "20";
	m_csRows = "4";
	m_cContrastSlider.SetPos(DEF_CONTRAST_CF);
	m_cBrightnessSlider.SetPos(DEF_BRIGHTNESS_CF);

	UpdateData( FALSE );
}
