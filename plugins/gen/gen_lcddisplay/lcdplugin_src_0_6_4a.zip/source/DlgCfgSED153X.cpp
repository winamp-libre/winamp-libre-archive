/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2002 TSchirme. All Rights Reserved.
//  tobias.schirmer@foni.net
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
// Modifications:
// 2002 Original version by Tobias Schirmer
// 2002/06/09 MZ  driver index changed
// 2003/08/03 MZ  replaced hard coded LCD driver access with dynamic methods through CLCDFactory 
//
/////////////////////////////////////////////////////////////////////////////
// DlgCfgSED153X.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgCfgSED153X.h"
#include "LcdSED153X.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgSED153X dialog

IMPLEMENT_DYNCREATE(CDlgCfgSED153X, CDialog)

CDlgCfgSED153X::CDlgCfgSED153X(CWnd* pParent /*=NULL*/)
  : CDialog(CDlgCfgSED153X::IDD, pParent)
{

  //{{AFX_DATA_INIT(CDlgCfgSED153X)
	m_iPort = -1;
	//}}AFX_DATA_INIT
}

CDlgCfgSED153X::~CDlgCfgSED153X()
{
}

void CDlgCfgSED153X::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
  //{{AFX_DATA_MAP(CDlgCfgSED153X)
	DDX_Control(pDX, IDC_CONTRAST_SLIDER, m_cContrastSlider);
	DDX_CBIndex(pDX, IDC_COMBO_LPTPORT, m_iPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCfgSED153X, CDialog)
  //{{AFX_MSG_MAP(CDlgCfgSED153X)
	ON_BN_CLICKED(IDC_DEF_BTN, OnDefBtn)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgSED153X message handlers

BOOL CDlgCfgSED153X::OnInitDialog()
{
	CDialog::OnInitDialog();

	/*
	{
		char temp[30];
		sprintf(temp,"Auswahl: %i",i);
		MessageBox(_T(temp),"OnCfgBtn",MB_OK);
	}

	*/
	m_iPort = g_SEDCfg.iLPTPort == 0x278 ? 1 : 0;

	m_cContrastSlider.SetRange(0, 31);
	m_cContrastSlider.SetPos(g_SEDCfg.byContrast);

	UpdateData( FALSE );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCfgSED153X::OnOK()
{
//  char szBuffer1[512];

	UpdateData();

	g_SEDCfg.iLPTPort = m_iPort == 0 ? 0x378 : 0x278;
	g_SEDCfg.byContrast = m_cContrastSlider.GetPos();

    LCD_DRIVER *pDrv = g_LCDFactory.GetDriver(DRV_SED153X);

	if (pDrv) {
		pDrv->pcLcd->SetContrast(g_SEDCfg.byContrast);
	}

	CDialog::OnOK();
}

void CDlgCfgSED153X::OnDefBtn() 
{
	m_iPort  = DEF_LPTPORT_SED;
	m_cContrastSlider.SetPos(DEF_CONTRAST_SED);

	UpdateData( FALSE );
}
