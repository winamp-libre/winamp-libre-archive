/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DlgPageDisplay_H__460106D3_C052_11D3_8F31_0000E871C360__INCLUDED_)
#define AFX_DlgPageDisplay_H__460106D3_C052_11D3_8F31_0000E871C360__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgPageDisplay.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgPageDisplay dialog

class CDlgPageDisplay : public CPropertyPage
{
// Construction
public:
	CDlgPageDisplay();   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgPageDisplay)
	enum { IDD = IDD_PAGE_DISPLAY };
	CComboBox	m_cLCDCombo;
	BOOL	m_bAutoOpen;
	CString	m_csActive;
	CString	m_csStatus;
	BOOL	m_bFalloff;
	BOOL	m_bAutoAnalyser;
	int		m_iSAcol;
	int		m_iSAheight;
	int		m_iSArow;
	int		m_iSAwidth;
	UINT	m_iVBwidth;
	UINT	m_iVBrow;
	UINT	m_iVBcol;
	BOOL	m_bVolBar;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgPageDisplay)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgPageDisplay)
	virtual BOOL OnInitDialog();
	afx_msg void OnCfgBtn();
	afx_msg void OnSelchangeLcdCombo();
	afx_msg void OnStartBtn();
	afx_msg void OnStopBtn();
	afx_msg void OnModified();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DlgPageDisplay_H__460106D3_C052_11D3_8F31_0000E871C360__INCLUDED_)
