/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallel44780.h: interface for the CDevParallel44780 class.
// Provides basic parallel port functionality for HD44780 controllers, extends
// CDevParallel
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVPARALLEL44780_H__AFC918FF_C71B_4B89_88F0_D9DB63F5C3A3__INCLUDED_)
#define AFX_DEVPARALLEL44780_H__AFC918FF_C71B_4B89_88F0_D9DB63F5C3A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DevParallel.h"

// commands for senddata
#define RS_DATA     0x00
#define RS_INSTR    0x01

#define CLEAR       0x01

#define HOMECURSOR  0x02

#define ENTRYMODE   0x04
#define E_MOVERIGHT 0x02
#define E_MOVELEFT  0x00
#define EDGESCROLL  0x01
#define NOSCROLL    0x00

#define ONOFFCTRL   0x08
#define DISPON      0x04
#define DISPOFF     0x00
#define CURSORON    0x02
#define CURSOROFF   0x00
#define CURSORBLINK 0x01
#define CURSORNOBLINK 0x00

#define CURSORSHIFT 0x10
#define SCROLLDISP  0x08
#define MOVECURSOR  0x00
#define MOVERIGHT   0x04
#define MOVELEFT    0x00

#define FUNCSET     0x20

// do NOT CHANGE the values of IF_8BIT and IF_4BIT !!!
#define IF_8BIT     0x10
#define IF_4BIT     0x00
// the shiftreg id's can be choosen freely...
#define IF_SHIFTREG		2
#define IF_SHIFTREG_EX	4

#define TWOLINE     0x08
#define ONELINE     0x00
#define LARGECHAR   0x04		  /* 5x11 characters */
#define SMALLCHAR   0x00		  /* 5x8 characters */

#define SETCHAR     0x40

#define POS         0x80

class CDevParallel44780 : public CDevParallel  
{
protected:

	// from driver_private_data in LCDPROC
	// Keypad, backlight extended interface and delay options
	BOOL have_backlight; // off by default
	BOOL extIF;		 // off by default
	BYTE delayBus;	 // Delay if the computer can send data too fast over
					 // its bus to LPT port

	int stuckinputs;
	int backlight_bit;

public:
	void SetBacklight(BOOL available);
	CDevParallel44780();
	virtual ~CDevParallel44780();
	virtual void SetBusDelay(BYTE delay);

	// methods each parallel driver has to implement:
	virtual void senddata (unsigned char displayID, unsigned char flags, unsigned char ch) = 0;
	virtual void backlight (unsigned char state) = 0;

protected:
	// utility methods with a default implementation
	virtual void common_init();


};

#endif // !defined(AFX_DEVPARALLEL44780_H__AFC918FF_C71B_4B89_88F0_D9DB63F5C3A3__INCLUDED_)
