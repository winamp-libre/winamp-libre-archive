/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LcdScottEdwards.cpp: implementation of the CLcdScottEdwards class.
// Authors: Calvin Streeting and Kynko / Markus Zehnder
//
// Modifications:
// 2002/06/09 MZ  initial implementation
// 2003/01/26 MZ  allocating m_pcDev and setting m_pInstance for backlight timer in Open()
// 2003/07/13 MZ  custom character map added 
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LcdScottEdwards.h"
#include "gen_lcddisplay.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define SE_SECTION	"ScottEdwards"
#define SE_CHARMAP  "ScottEdwards_CHARMAP"

// note: Only 7 out of the 8 custom chars are used, char 0 is not used.
// This needs some changes in the lcd interface, the char 0 is currently 
// treated as the \0 string terminator!
#define MAX_CUSTOM_CHARS		7

CCfgSE	 g_SECfg;

CCfgSE::CCfgSE()
{
	Load(g_szIniFile);
}

CCfgSE::~CCfgSE()
{
	Save(g_szIniFile);
}

void CCfgSE::Load(LPCSTR lpIniFile)
{
	GetPrivateProfileString( SE_SECTION, "ComPort", DEF_COMPORT, szComPort, MAX_COMPORT_STRLEN, lpIniFile);
	GetPrivateProfileString( SE_SECTION, "BaudRate", DEF_BAUDRATE, szBaudRate, MAX_BAUDRATE_STRLEN, lpIniFile);
	iCols =       GetPrivateProfileInt(SE_SECTION,"Columns",20,lpIniFile); 			 
	iRows =	   GetPrivateProfileInt(SE_SECTION,"Rows",4,lpIniFile); 
	BuildCharMap(SE_CHARMAP, lpIniFile, charMap);
}

void CCfgSE::Save(LPCSTR lpIniFile)
{
	char string[32];

	WritePrivateProfileString( SE_SECTION, "ComPort", szComPort, lpIniFile);
	WritePrivateProfileString( SE_SECTION, "BaudRate", szBaudRate, lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(SE_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(SE_SECTION,"Rows",string,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdScottEdwards::CLcdScottEdwards()
{
	m_pcDev = NULL;
}

CLcdScottEdwards::~CLcdScottEdwards()
{
	Close();

	if (m_pcDev != NULL)
		delete m_pcDev;
}

void  CLcdScottEdwards::SetBacklight(short nMinutes)
{
	if (nMinutes < 0)
	{
		WriteCommand(char(14));
	}
	else
	{
		WriteCommand(char(14));
		// @todo use backlight timer fctn in CLcd to switch off backlight

		//neads external time loop
		//WriteData( (BYTE)nMinutes );
	}

	m_nBackLight = nMinutes;
}

void  CLcdScottEdwards::SetBlink(BOOL bOn)
{
	WriteCommand( bOn ? char(6) : (	m_bCursor ? char(5) : char(4) ));
	m_bBlink = bOn;
}

void  CLcdScottEdwards::Clear()
{
	WriteCommand(char(12));
}

void  CLcdScottEdwards::Close()
{
	if (m_pcDev != NULL)
		m_pcDev->Close();
}

BOOL  CLcdScottEdwards::IsOpen()
{
	if (m_pcDev == NULL)
		return FALSE;

	return m_pcDev->IsOpen();
}

void  CLcdScottEdwards::SetContrast(short nLevel)
{
	//not implemented see back of unit
}

void CLcdScottEdwards::SetBrightness(short nLevel)
{
	//not implemented
}

void  CLcdScottEdwards::Cursor(BOOL bOn)
{
	WriteCommand( bOn ? char(5): char(4) );
	m_bCursor = bOn;
}

void  CLcdScottEdwards::HBar(short nCol, short nRow, short nDir, short nLen)
{
	// not yet implemented
}

void  CLcdScottEdwards::Home()
{
	WriteCommand(char(1));
}

void  CLcdScottEdwards::InitHorizontalBar()
{
	//not implemented (SEE MAXORBTAIL COMMAND 'h')
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(129));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(130));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);

	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(131));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);

	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(132));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(133));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(134));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(135));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);

	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(136));

	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
}

void  CLcdScottEdwards::InitLargeDigit()
{
	//nead to reset carictors for large char
	WriteCommand(char(2));
}

void  CLcdScottEdwards::InitVerticalBar()
{
		//not implemented (SEE MAXORBTAL COMMAND 'v')
}

void  CLcdScottEdwards::LargeDigit(short nCol, short nNumber)
{
	// Reset Custom Char
	WriteCommand(char(27));
	WriteCommand(char(69));
	WriteCommand(char(49));
	
	// set mode large
	WriteCommand(char(16));
	WriteData( (BYTE)nCol );
	WriteCommand(char(2));
	WriteData( (BYTE)nNumber );
	WriteCommand(char(3));
}

void  CLcdScottEdwards::SetLineWrap(BOOL bOn)
{
	
	//not implemented (All ways on)
	m_bLineWrap = true;
}

/******************************************************************************
Function : Open
Purpose  : Opens the comport and initilizes the display
Parameters : -
Returns : TRUE if successful, otherwise FALSE
Author  : Markus Zehnder	
******************************************************************************/
BOOL  CLcdScottEdwards::Open()
{
	char szDef[20];

	// hack for backlight timer
	m_pInstance = this;

	if (m_pcDev == NULL) {
		m_pcDev = new CDevSerial();
	}

	sprintf(szDef, "%d,n,8,1", atoi(g_SECfg.szBaudRate) );

	if (!m_pcDev->Open(g_SECfg.szComPort, szDef))
	{
		Close();
		return FALSE;
	}		
	Clear();
	SetBlink(FALSE);
	Cursor(FALSE);

	m_charMap = g_SECfg.charMap;

	return TRUE;
}

void  CLcdScottEdwards::SetPosition(short nCol, short nRow)
{
	WriteCommand(char(16));
	WriteData( (BYTE) ( ((nRow - 1) * g_SECfg.iCols) + (nCol - 1) ) + 64);
}

void  CLcdScottEdwards::SetScroll(BOOL bOn)
{
		//not implemented (SEE MAXORBTAIL COMMAND 'Q' 'R'
	m_bScroll = false;
}

void  CLcdScottEdwards::VBar(short nCol, short nLength)
{
	char map[9] = {char(32), char(129), char(130), char(131), char(132), char(133), char(134), char(135), char(255) };

	int y;
	for (y=g_SECfg.iRows; y > 0 && nLength>0; y--) 
	{
		SetPosition(nCol,y);
		WriteData((BYTE)( nLength >= g_SECfg.iCols ? 255 : map[nLength] ));
		nLength -= g_SECfg.iCols;
	}
}

void  CLcdScottEdwards::Write(LPCSTR lpText)
{
	CString csText = lpText;
	ConvertTextToLCDCharset(csText);
	m_pcDev->WriteData(csText);
}

void CLcdScottEdwards::WriteData(BYTE byData)
{
	m_pcDev->WriteData(byData);
}

void CLcdScottEdwards::WriteCommand(BYTE byData)
{
	WriteData( byData );
	
}

BOOL  CLcdScottEdwards::CreateCustomChar(short nNumber, CCustomChar &cChar)
{
	if (nNumber > MAX_CUSTOM_CHARS)	// bugfix: last custom char didn't get set, MZ July 28 2k
		return FALSE;


	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(nNumber + 48));

	int iMax = __min(8, cChar.m_byDataSize);
	for (int i = 0; i < iMax; i++)
	{
		if (cChar.m_byarrData[i] > 31)
			cChar.m_byarrData[i] = 0;	
		WriteData((cChar.m_byarrData[i] + 128));
	}

	for (; i < 8; i++)
	{
		WriteData( 128 );
	}

	return TRUE;
}

short CLcdScottEdwards::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

LPCTSTR CLcdScottEdwards::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( "%c1", ch );
	ch[0] = (char)2;
	csText.Replace( "%c2", ch );
	ch[0] = (char)3;
	csText.Replace( "%c3", ch );
	ch[0] = (char)4;
	csText.Replace( "%c4", ch );
	ch[0] = (char)5;
	csText.Replace( "%c5", ch );
	ch[0] = (char)6;
	csText.Replace( "%c6", ch );
	ch[0] = (char)7;
	csText.Replace( "%c7", ch );

	return csText;
}

LPCTSTR CLcdScottEdwards::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( ch, "%c1" );
	ch[0] = (char)2;
	csText.Replace( ch, "%c2" );
	ch[0] = (char)3;
	csText.Replace( ch, "%c3" );
	ch[0] = (char)4;
	csText.Replace( ch, "%c4" );
	ch[0] = (char)5;
	csText.Replace( ch, "%c5" );
	ch[0] = (char)6;
	csText.Replace( ch, "%c6" );
	ch[0] = (char)7;
	csText.Replace( ch, "%c7" );

	return csText;
}

int	CLcdScottEdwards::GetRows()		// MZ, June 27
{
	return g_SECfg.iRows;
}

int	CLcdScottEdwards::GetColumns()	// MZ, June 27
{
	return g_SECfg.iCols;
}

LPCSTR CLcdScottEdwards::ConvertTextToLCDCharset( CString &csText )
{
	// quick and dirty special char replacement
	csText.Replace( char(0),char(128));

	return CLcd::ConvertTextToLCDCharset(csText);
}

CDevSerial* CLcdScottEdwards::GetSerialDevice()
{
	return m_pcDev;
}
