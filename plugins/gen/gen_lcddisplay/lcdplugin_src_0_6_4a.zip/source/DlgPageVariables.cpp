/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgPageVariables.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 28.11.99 - new variables: volume, time/date, custom characters added, M.Zehnder
// 18.11.99 - Scroll Separator Field added, F. Verhamme
// 18.10.00 - Add Repeat Field
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgPageVariables.h"
#include "Volume.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPageVariables property page

IMPLEMENT_DYNCREATE(CDlgPageVariables, CPropertyPage)

CDlgPageVariables::CDlgPageVariables() : CPropertyPage(CDlgPageVariables::IDD)
{
	//{{AFX_DATA_INIT(CDlgPageVariables)
	m_iVariable = 0;
	m_bTrimTrailing = TRUE;
	m_bTrimLeading = TRUE;
	m_bTimeBlink = TRUE;
	m_csPause = _T("");
	m_csPlay = _T("");
	m_csStop = _T("");
	m_csTimeFormat = _T("");
	m_csDateTimeFormat = _T("");
	m_csDateTimeOpt = _T("");
	m_csRepOff = _T("");
	m_csRepOn = _T("");
	m_csShuffleOff = _T("");
	m_csShuffleOn = _T("");
	m_VolBarLen = 0;
	//}}AFX_DATA_INIT
	m_iOldCCharIndex = 0;
	m_iMaxCustomChars = 0;
}

CDlgPageVariables::~CDlgPageVariables()
{
}

void CDlgPageVariables::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPageVariables)
	DDX_Control(pDX, IDC_CHARNBR_COMBO, m_cCustomCharCombo);
	DDX_Control(pDX, IDC_CHAR_DEF, m_cCustomCharDef);
	DDX_CBIndex(pDX, IDC_VAR_COMBO, m_iVariable);
	DDX_Check(pDX, IDC_CHECK_TRIMTRAILING, m_bTrimTrailing);
	DDX_Check(pDX, IDC_CHECK_TRIMLEADING, m_bTrimLeading);
	DDX_Check(pDX, IDC_CHECK_BLINK, m_bTimeBlink);
	DDX_Text(pDX, IDC_PAUSE_EDIT, m_csPause);
	DDV_MaxChars(pDX, m_csPause, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_PLAY_EDIT, m_csPlay);
	DDV_MaxChars(pDX, m_csPlay, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_STOP_EDIT, m_csStop);
	DDV_MaxChars(pDX, m_csStop, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_TIMEFORMAT_EDIT, m_csTimeFormat);
	DDV_MaxChars(pDX, m_csTimeFormat, MAX_TIME_STRLEN);
	DDX_Text(pDX, IDC_TIME_EDIT, m_csDateTimeFormat);
	DDV_MaxChars(pDX, m_csDateTimeFormat, MAX_TIME_STRLEN);
	DDX_Text(pDX, IDC_TIME_OPT, m_csDateTimeOpt);
	DDX_Text(pDX, IDC_REP_OFF, m_csRepOff);
	DDV_MaxChars(pDX, m_csRepOff, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_REP_ON, m_csRepOn);
	DDV_MaxChars(pDX, m_csRepOn, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_SHUFFLE_OFF, m_csShuffleOff);
	DDV_MaxChars(pDX, m_csShuffleOff, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_SHUFFLE_ON, m_csShuffleOn);
	DDV_MaxChars(pDX, m_csShuffleOn, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_BARLEN_EDIT, m_VolBarLen);
	DDV_MinMaxInt(pDX, m_VolBarLen, 0, 40);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPageVariables, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgPageVariables)
	ON_CBN_SELCHANGE(IDC_VAR_COMBO, OnSelchangeVariable)
	ON_BN_CLICKED(IDC_DEF_BTN, OnDefBtn)
	ON_BN_CLICKED(IDC_ALLOFF_BTN, OnAlloffBtn)
	ON_BN_CLICKED(IDC_ALLON_BTN, OnAllonBtn)
	ON_EN_CHANGE(IDC_TIMEFORMAT_EDIT, OnSetModified)
	ON_EN_CHANGE(IDC_PLAY_EDIT, OnSetModified)
	ON_EN_CHANGE(IDC_PAUSE_EDIT, OnSetModified)
	ON_EN_CHANGE(IDC_STOP_EDIT, OnSetModified)
	ON_BN_CLICKED(IDC_CHECK_TRIMLEADING, OnSetModified)
	ON_BN_CLICKED(IDC_CHECK_TRIMTRAILING, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_UPPER, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_LOWER, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_FIRST_UPPER, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_DONT_CHANGE, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_ONLYFIRST_UPPER, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_FWD, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_BACK, OnSetModified)
	ON_BN_CLICKED(IDC_CHECK_BLINK, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_VOL_MASTER, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_VOL_WAVE, OnSetModified)
	ON_BN_CLICKED(IDC_RADIO_VOL_COMBINE, OnSetModified)
	ON_EN_CHANGE(IDC_TIME_EDIT, OnSetModified)
	ON_CBN_SELCHANGE(IDC_CHARNBR_COMBO, OnSelchangeCharnbrCombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPageVariables message handlers

BOOL CDlgPageVariables::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	OnSelchangeVariable();

	m_csPause = g_Config.szPause;
	m_csPlay = g_Config.szPlay;
	m_csStop = g_Config.szStop;

	m_VolBarLen = g_Config.iVolBarLen;

	m_csTimeFormat = g_Config.szTimeFormat;

	m_bTrimLeading = g_Config.bTrimLeading;
	m_bTrimTrailing = g_Config.bTrimTrailing;

	int iCheck;
	switch (g_Config.byTxtConv)
	{
		case CONV_UPPERCASE  : iCheck = IDC_RADIO_UPPER; break;
		case CONV_LOWERCASE  : iCheck = IDC_RADIO_LOWER; break;
		case CONV_FIRSTUPPER : iCheck = IDC_RADIO_FIRST_UPPER; break;
		case CONV_UPPERCASE_FIRST : iCheck = IDC_RADIO_ONLYFIRST_UPPER; break;
		default:  iCheck = IDC_RADIO_DONT_CHANGE; break;
	}
	CheckRadioButton(IDC_RADIO_UPPER, IDC_RADIO_DONT_CHANGE, iCheck);

	m_bTimeBlink = g_Config.bTimeBlink;
	CheckRadioButton(IDC_RADIO_FWD,IDC_RADIO_BACK, g_Config.bTimeFwd ? IDC_RADIO_FWD : IDC_RADIO_BACK);

	CheckRadioButton(IDC_RADIO_VOL_MASTER,IDC_RADIO_VOL_DISABLE, 
		g_Config.byVolSource == VOLUME_MASTER ? IDC_RADIO_VOL_MASTER : 
		g_Config.byVolSource == VOLUME_WAVE ? IDC_RADIO_VOL_WAVE : 
		g_Config.byVolSource == VOLUME_COMBINE ? IDC_RADIO_VOL_COMBINE :
		IDC_RADIO_VOL_DISABLE);

	m_csDateTimeFormat = g_Config.szDateTimeFormat;
	m_csDateTimeOpt.LoadString(IDS_TIMEFORMAT_HELP);
	m_csDateTimeOpt.Replace("\n", "\r\n");

	CString csBuff1;
	CComboBox *cbox = (CComboBox*)GetDlgItem(IDC_VAR_COMBO);

	cbox->ResetContent();	// MZ 23 Oct 00
	csBuff1.LoadString(IDS_VAR_SELECT);

	while (csBuff1.GetLength())
	{
		if (csBuff1.Find('\n') > -1)
		{
		  cbox->AddString(csBuff1.Left(csBuff1.Find('\n')));
		  csBuff1 = csBuff1.Right(csBuff1.GetLength() - csBuff1.Find('\n') - 1);
		}
		else
		{
		  cbox->AddString(csBuff1);
		  csBuff1 = "";
		}
	}

	// shuffle and repeat strings, MZ 2001/12/30
	m_csShuffleOff = g_Config.szShuffleOff;
	m_csShuffleOn = g_Config.szShuffleOn;
	m_csRepOff = g_Config.szRepeatOff;
	m_csRepOn = g_Config.szRepeatOn;

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgPageVariables::OnSetActive() 
{
	char szTemp[10];
	m_iMaxCustomChars = 0;

	if (g_LCD)
		m_iMaxCustomChars = g_LCD->GetMaxCustomChar();

	m_cCustomCharCombo.ResetContent();
	for (int i = 1; i <= m_iMaxCustomChars; i++)
		m_cCustomCharCombo.AddString(itoa(i, szTemp, 10));
	m_cCustomCharCombo.SetCurSel(m_iOldCCharIndex);
	m_cCustomCharDef.SetChar(g_Config.carrCustomChar[m_iOldCCharIndex]);
	
	return CPropertyPage::OnSetActive();
}

BOOL CDlgPageVariables::OnApply() 
{
	strcpy(g_Config.szPause, m_csPause);
	strcpy(g_Config.szPlay, m_csPlay);
	strcpy(g_Config.szStop, m_csStop);

	strcpy(g_Config.szTimeFormat, m_csTimeFormat);

	g_Config.bTrimLeading = m_bTrimLeading;
	g_Config.bTrimTrailing = m_bTrimTrailing;

	switch (GetCheckedRadioButton(IDC_RADIO_UPPER, IDC_RADIO_DONT_CHANGE))
	{
		case IDC_RADIO_UPPER : g_Config.byTxtConv = CONV_UPPERCASE; break;
		case IDC_RADIO_LOWER : g_Config.byTxtConv = CONV_LOWERCASE; break;
		case IDC_RADIO_FIRST_UPPER : g_Config.byTxtConv = CONV_FIRSTUPPER; break;
		case IDC_RADIO_ONLYFIRST_UPPER : g_Config.byTxtConv = CONV_UPPERCASE_FIRST; break;
		default : g_Config.byTxtConv = CONV_DONTCHANGE; break;
	}

	g_Config.bTimeBlink = m_bTimeBlink;
	g_Config.bTimeFwd = GetCheckedRadioButton(IDC_RADIO_FWD,IDC_RADIO_BACK) == IDC_RADIO_FWD;

	switch (GetCheckedRadioButton(IDC_RADIO_VOL_MASTER,IDC_RADIO_VOL_COMBINE))
	{
		case IDC_RADIO_VOL_MASTER  : g_Config.byVolSource = VOLUME_MASTER; break;
		case IDC_RADIO_VOL_WAVE    : g_Config.byVolSource = VOLUME_WAVE; break;
		case IDC_RADIO_VOL_COMBINE : g_Config.byVolSource = VOLUME_COMBINE; break;
		default : g_Config.byVolSource = -1; 
	}

	g_Config.iVolBarLen = m_VolBarLen;

	strcpy(g_Config.szDateTimeFormat, m_csDateTimeFormat);

	int iIndex = m_cCustomCharCombo.GetCurSel();
	if (iIndex < m_iMaxCustomChars)
		m_cCustomCharDef.GetChar(g_Config.carrCustomChar[iIndex]);
	SetCustomChars();

	strcpy(g_Config.szShuffleOff, m_csShuffleOff);
	strcpy(g_Config.szShuffleOn, m_csShuffleOn);
	strcpy(g_Config.szRepeatOff, m_csRepOff);
	strcpy(g_Config.szRepeatOn, m_csRepOn);

	return CPropertyPage::OnApply();
}

void CDlgPageVariables::OnSelchangeVariable() 
{
	BOOL bNoConfig   = FALSE;
	BOOL bTimeFormat = FALSE;
	BOOL bPlayStatus = FALSE;
	BOOL bTxtConv    = FALSE;
	BOOL bSongPos    = FALSE;
	BOOL bVolume     = FALSE;
	BOOL bTimeDate   = FALSE;
	BOOL bCustomChar = FALSE;
	BOOL bShuffle	 = FALSE;
	BOOL bRepeat     = FALSE;
	BOOL bVolBar     = FALSE;
	BOOL bSleepTimer = FALSE;

	UpdateData();

	switch (m_iVariable)
	{
		case SONGTITLE_VAR		:
			bNoConfig = TRUE;
			break;
		case PLAYBACKSTATUS_VAR	:
			bPlayStatus = TRUE;
			break;
		case PLAYLISTPOS_VAR	:
			bNoConfig = TRUE;
			break;
		case PLAYLISTLENGTH_VAR	:
			bNoConfig = TRUE;
			break;
		case SONGLEN_VAR		:
			bTimeFormat = TRUE;
			break;
		case SONGPOS_VAR		:
			bSongPos = TRUE;
			break;
		case CHANNELS_VAR		:
			bNoConfig = TRUE;
			break;
		case SAMPLERATE_VAR		:
			bNoConfig = TRUE;
			break;
		case BITRATE_VAR		:
			bNoConfig = TRUE;
			break;
		case VOLUME_VAR			:
			bVolume = TRUE;
			break;
		case TIMEDATE_VAR		:
			bTimeDate = TRUE;
			break;
		case TXT_CONV_VAR		:
			bTxtConv = TRUE;
			break;
		case CUSTOM_CHAR_VAR	:
			bCustomChar = TRUE;
			break;
		case SHUFFLE_VAR		:
			bShuffle = TRUE;
			break;
		case REPEAT_VAR :
			bRepeat = TRUE;
			break;
		case SPINNING_VAR :
			bNoConfig = TRUE;
			break;
		case CPUUSAGE_VAR :
			bNoConfig = TRUE;
			break;
		case MEMUSAGE_VAR :
			bNoConfig = TRUE;
			break;
		case VOLUMEBAR_VAR :
			bVolume = TRUE;
			bVolBar = TRUE;
			break;
		case SLEEPTIMER_VAR :
			bSleepTimer = TRUE;
			break;
	}

	GetDlgItem(IDC_NO_CONFIG)->ShowWindow(bNoConfig);

	GetDlgItem(IDC_TIME_FORMAT)->ShowWindow(bTimeFormat);
	GetDlgItem(IDC_TIMEFORMAT_EDIT)->ShowWindow(bTimeFormat);
	GetDlgItem(IDC_TIME_FORMAT2)->ShowWindow(bTimeFormat);

	GetDlgItem(IDC_STATUS_TITLE)->ShowWindow(bPlayStatus || bShuffle || bRepeat);
	GetDlgItem(IDC_PLAY)->ShowWindow(bPlayStatus);
	GetDlgItem(IDC_PLAY_EDIT)->ShowWindow(bPlayStatus);
	GetDlgItem(IDC_PAUSE)->ShowWindow(bPlayStatus);
	GetDlgItem(IDC_PAUSE_EDIT)->ShowWindow(bPlayStatus);
	GetDlgItem(IDC_STOP)->ShowWindow(bPlayStatus);
	GetDlgItem(IDC_STOP_EDIT)->ShowWindow(bPlayStatus);

	GetDlgItem(IDC_CHECK_TRIMLEADING)->ShowWindow(bTxtConv);
	GetDlgItem(IDC_CHECK_TRIMTRAILING)->ShowWindow(bTxtConv);
	GetDlgItem(IDC_RADIO_UPPER)->ShowWindow(bTxtConv);
	GetDlgItem(IDC_RADIO_LOWER)->ShowWindow(bTxtConv);
	GetDlgItem(IDC_RADIO_FIRST_UPPER)->ShowWindow(bTxtConv);
	GetDlgItem(IDC_RADIO_DONT_CHANGE)->ShowWindow(bTxtConv);
	GetDlgItem(IDC_RADIO_ONLYFIRST_UPPER)->ShowWindow(bTxtConv);

	GetDlgItem(IDC_RADIO_FWD)->ShowWindow(bSongPos);
	GetDlgItem(IDC_RADIO_BACK)->ShowWindow(bSongPos);
	GetDlgItem(IDC_CHECK_BLINK)->ShowWindow(bSongPos);

	GetDlgItem(IDC_RADIO_VOL_MASTER)->ShowWindow(bVolume);
	GetDlgItem(IDC_RADIO_VOL_WAVE)->ShowWindow(bVolume);
	GetDlgItem(IDC_RADIO_VOL_COMBINE)->ShowWindow(bVolume);
	GetDlgItem(IDC_RADIO_VOL_DISABLE)->ShowWindow(bVolume);
	GetDlgItem(IDC_VOL_NOTE)->ShowWindow(bVolume);
	GetDlgItem(IDC_BARLEN)->ShowWindow(bVolBar);
	GetDlgItem(IDC_BARLEN_EDIT)->ShowWindow(bVolBar);

	GetDlgItem(IDC_TIME_1)->ShowWindow(bTimeDate);
	GetDlgItem(IDC_TIME_2)->ShowWindow(bTimeDate);
	GetDlgItem(IDC_TIME_EDIT)->ShowWindow(bTimeDate);
	GetDlgItem(IDC_TIME_OPT)->ShowWindow(bTimeDate);

	GetDlgItem(IDC_DEF_BTN)->ShowWindow(bPlayStatus||bTimeFormat||bVolume||bTimeDate||bTxtConv);

	GetDlgItem(IDC_CHAR_FRAME)->ShowWindow(bCustomChar);
	GetDlgItem(IDC_CHAR_DEF)->ShowWindow(bCustomChar);
	GetDlgItem(IDC_CHARNBR)->ShowWindow(bCustomChar);
	GetDlgItem(IDC_CHARNBR_COMBO)->ShowWindow(bCustomChar);
	GetDlgItem(IDC_ALLON_BTN)->ShowWindow(bCustomChar);
	GetDlgItem(IDC_ALLOFF_BTN)->ShowWindow(bCustomChar);

	GetDlgItem(IDC_SHUFFLE_ON)->ShowWindow(bShuffle);
	GetDlgItem(IDC_SHUFFLE_OFF)->ShowWindow(bShuffle);
	GetDlgItem(IDC_REP_ON)->ShowWindow(bRepeat);
	GetDlgItem(IDC_REP_OFF)->ShowWindow(bRepeat);
	GetDlgItem(IDC_LABEL_ON)->ShowWindow(bShuffle || bRepeat);
	GetDlgItem(IDC_LABEL_OFF)->ShowWindow(bShuffle || bRepeat);	
}

void CDlgPageVariables::OnSetModified() 
{
	this->SetModified();	
}

void CDlgPageVariables::OnDefBtn()
{
	switch (m_iVariable)
	{
		case SONGTITLE_VAR		:
			break;
		case PLAYBACKSTATUS_VAR	:
			m_csPause.LoadString(IDS_STATUS_PAUSE);
			m_csPlay.LoadString(IDS_STATUS_PLAY);
			m_csStop.LoadString(IDS_STATUS_STOP);
			break;
		case PLAYLISTPOS_VAR	:
			break;
		case PLAYLISTLENGTH_VAR	:
			break;
		case SONGLEN_VAR		:
			m_csTimeFormat = DEF_TIME_FORMAT;
			break;
		case SONGPOS_VAR		:
			break;
		case CHANNELS_VAR		:
			break;
		case SAMPLERATE_VAR		:
			break;
		case BITRATE_VAR		:
			break;
		case VOLUME_VAR			:
			CheckRadioButton(IDC_RADIO_VOL_MASTER,IDC_RADIO_VOL_COMBINE,IDC_RADIO_VOL_COMBINE);
			break;
		case TIMEDATE_VAR		:
			m_csDateTimeFormat = DEF_SYSTIME_FORMAT;
			break;
		case TXT_CONV_VAR		:
			m_bTrimLeading = m_bTrimTrailing = TRUE;
			CheckRadioButton(IDC_RADIO_UPPER, IDC_RADIO_DONT_CHANGE, IDC_RADIO_FIRST_UPPER);
			break;
		case VOLUMEBAR_VAR:
			break;
		case SHUFFLE_VAR:
		case REPEAT_VAR:
		case SPINNING_VAR:
			break;
		case SLEEPTIMER_VAR:
			break;
	}
	UpdateData(FALSE);
}

void CDlgPageVariables::OnAlloffBtn() 
{
	m_cCustomCharDef.SetAllDots(FALSE);
}

void CDlgPageVariables::OnAllonBtn() 
{
	m_cCustomCharDef.SetAllDots(TRUE);
}

void CDlgPageVariables::OnSelchangeCharnbrCombo() 
{
	int iIndex = m_cCustomCharCombo.GetCurSel();

	m_cCustomCharDef.GetChar(g_Config.carrCustomChar[m_iOldCCharIndex]);

	if (iIndex < m_iMaxCustomChars)
	{
		m_cCustomCharDef.SetChar(g_Config.carrCustomChar[iIndex]);
		m_iOldCCharIndex = iIndex;
	}
}
