//=========================================================================
//
// Copyright � Dundas Software Ltd. 1998, All Rights Reserved
//
// tbtremfc.h : header file
//
//==========================================================================

// conditional compilation to avoid multiple defintions
#ifndef _tbtremfc_h_
#define _tbtremfc_h_

#ifndef _tbtreed_h_
#include "tbtreed.h"
#endif

//==========================================================================
// MFC Derived tree class: string key, string data
//==========================================================================
class EXT_CLASS CtStringToString : public CObject, public tStringToString
{
public:
    DECLARE_SERIAL(CtStringToString)
    virtual ~CtStringToString();
    virtual void Serialize(CArchive& ar);
protected:
    virtual int onStore(void* where, POSITION node);
};

//==========================================================================
// MFC Derived tree class: string key, unsigned long data
//==========================================================================
class EXT_CLASS CtStringToULong : public CObject, public tStringToULong
{
public:
    DECLARE_SERIAL(CtStringToULong)
    virtual ~CtStringToULong();
    virtual void Serialize(CArchive& ar);
protected:
    virtual int onStore(void* where, POSITION node);
};

//==========================================================================
// MFC Derived tree class: string key, CObject data
//==========================================================================
class EXT_CLASS CtStringToCObject : public CObject, public tStringToULong
{
public:
    DECLARE_SERIAL(CtStringToCObject)
    virtual ~CtStringToCObject();
    virtual void Serialize(CArchive& ar);
    
    inline int Set(const char* key, CObject* data);
    inline CObject* Get(const char* key);
    inline CObject* GetData(POSITION pos);
    inline int SetData(POSITION pos, CObject* data);
    
protected:
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual int onStore(void* where, POSITION node);
    
    // CObject does not support serialization to streams:
    virtual int Store(NQ ostream* ostrm){return 0;}
    virtual int Load(NQ istream* istrm){return 0;}
};

//==========================================================================
// MFC Derived tree class: unsigned long key, string data
//==========================================================================
class EXT_CLASS CtULongToString : public CObject, public tULongToString
{
public:
    DECLARE_SERIAL(CtULongToString)
    virtual ~CtULongToString();
    virtual void Serialize(CArchive& ar);
protected:
    virtual int onStore(void* where, POSITION node);
};

//==========================================================================
// MFC Derived tree class: unsigned long key, unsigned long data
//==========================================================================
class EXT_CLASS CtULongToULong : public CObject, public tULongToULong
{
public:
    DECLARE_SERIAL(CtULongToULong)
    virtual ~CtULongToULong();
    virtual void Serialize(CArchive& ar);
protected:
    virtual int onStore(void* where, POSITION node);
};

//==========================================================================
// MFC Derived tree class: unsigned long key, CObject data
//==========================================================================
class EXT_CLASS CtULongToCObject : public CObject, public tULongToULong
{
public:
    DECLARE_SERIAL(CtULongToCObject)
    virtual ~CtULongToCObject();
    virtual void Serialize(CArchive& ar);
    
    inline int Set(unsigned long key, CObject* data);
    inline CObject* Get(unsigned long key);
    inline CObject* GetData(POSITION pos);
    inline int SetData(POSITION pos, CObject* data);
    
protected:
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual int onStore(void* where, POSITION node);
    
    // CObject does not support serialization to streams:
    virtual int Store(NQ ostream* ostrm){return 0;}
    virtual int Load(NQ istream* istrm){return 0;}
};

//==========================================================================
// MFC Derived tree class: long key, string data
//==========================================================================
class EXT_CLASS CtLongToString : public CObject, public tLongToString
{
public:
    DECLARE_SERIAL(CtLongToString)
    virtual ~CtLongToString();
    virtual void Serialize(CArchive& ar);
protected:
    virtual int onStore(void* where, POSITION node);
};

//==========================================================================
// MFC Derived tree class: long key, unsigned long data
//==========================================================================
class EXT_CLASS CtLongToULong : public CObject, public tLongToULong
{
public:
    DECLARE_SERIAL(CtLongToULong)
    virtual ~CtLongToULong();
    virtual void Serialize(CArchive& ar);
protected:
    virtual int onStore(void* where, POSITION node);
};

//==========================================================================
// MFC Derived tree class: long key, CObject data
//==========================================================================
class EXT_CLASS CtLongToCObject : public CObject, public tLongToULong
{
public:
    DECLARE_SERIAL(CtLongToCObject)
    virtual ~CtLongToCObject();
    virtual void Serialize(CArchive& ar);
    
    inline int Set(long key, CObject* data);
    inline CObject* Get(long key);
    inline CObject* GetData(POSITION pos);
    inline int SetData(POSITION pos, CObject* data);
    
protected:
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual int onStore(void* where, POSITION node);
    
    // CObject does not support serialization to streams:
    virtual int Store(NQ ostream* ostrm){return 0;}
    virtual int Load(NQ istream* istrm){return 0;}
};

//--------------------------------------------------------------------------
// INLINE members for all classes defined here.
//--------------------------------------------------------------------------

// CtStringToCObject
inline int CtStringToCObject::Set(const char* key, CObject* data)
{
    return set((void*)key, (void*)data);
}

inline CObject* CtStringToCObject::Get(const char* key)
{
    return (CObject*)getData(find((void*)key));
}

inline CObject* CtStringToCObject::GetData(POSITION pos)
{
    return (CObject*)getData(pos);
}

inline int CtStringToCObject::SetData(POSITION node, CObject* data)
{
    return setData(node, (void*)data);
}

// CtULongToCObject
inline int CtULongToCObject::Set(unsigned long key, CObject* data)
{
    return set((void*)key, (void*)data);
}

inline CObject* CtULongToCObject::Get(unsigned long key)
{
    return (CObject*)getData(find((void*)key));
}

inline CObject* CtULongToCObject::GetData(POSITION pos)
{
    return (CObject*)getData(pos);
}

inline int CtULongToCObject::SetData(POSITION node, CObject* data)
{
    return setData(node, (void*)data);
}

// CtLongToCObject
inline int CtLongToCObject::Set(long key, CObject* data)
{
    return set((void*)key, (void*)data);
}

inline CObject* CtLongToCObject::Get(long key)
{
    return (CObject*)getData(find((void*)key));
}

inline CObject* CtLongToCObject::GetData(POSITION pos)
{
    return (CObject*)getData(pos);
}

inline int CtLongToCObject::SetData(POSITION node, CObject* data)
{
    return setData(node, (void*)data);
}

#endif
//// end ///////////////////////////////////////////////////////////////////
