/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LcdMilfordBPK.cpp: implementation of the CLcdMilfordBPK class.
//
// Modifications:
// 2002/11/10 MZ  initial version, coded by Calvin Streeting and Kynko, thanx!
// 2003/01/26 MZ  allocating m_pcDev and setting m_pInstance for backlight timer in Open()
// 2003/07/13 MZ  custom character map added 
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LcdMilfordBPK.h"
#include "gen_lcddisplay.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define MF_SECTION	"Milford bpk+"
#define MF_CHARMAP  "Milford_CHARMAP"

// note: Only 7 out of the 8 custom chars are used, char 0 is not used.
// This needs some changes in the lcd interface, the char 0 is currently 
// treated as the \0 string terminator!
#define MAX_CUSTOM_CHARS		7

CCfgMilford	 g_MilfordCfg;

CCfgMilford::CCfgMilford()
{
	Load(g_szIniFile);
}

CCfgMilford::~CCfgMilford()
{
	Save(g_szIniFile);
}

void CCfgMilford::Load(LPCSTR lpIniFile)
{
	GetPrivateProfileString( MF_SECTION, "ComPort", DEF_COMPORT, szComPort, MAX_COMPORT_STRLEN, lpIniFile);
	GetPrivateProfileString( MF_SECTION, "BaudRate", DEF_BAUDRATE, szBaudRate, MAX_BAUDRATE_STRLEN, lpIniFile);
	bBlink =	   GetPrivateProfileInt(MF_SECTION,"SetBlink",0,lpIniFile); 
	bScroll =	   GetPrivateProfileInt(MF_SECTION,"SetScroll",0,lpIniFile); 
	bShowCursor = GetPrivateProfileInt(MF_SECTION,"Cursor",0,lpIniFile); 
	bWrap =	   GetPrivateProfileInt(MF_SECTION,"Wrap",1,lpIniFile); 	
	iCols =       GetPrivateProfileInt(MF_SECTION,"Columns",20,lpIniFile); 			 
	iRows =	   GetPrivateProfileInt(MF_SECTION,"Rows",4,lpIniFile); 
	byContrast = (BYTE)GetPrivateProfileInt(MF_SECTION,"Contrast", DEF_CONTRAST,lpIniFile); 
	byBrightness = (BYTE)GetPrivateProfileInt(MF_SECTION,"Brightness", DEF_BRIGHTNESS,lpIniFile); 
	bLCD = GetPrivateProfileInt(MF_SECTION,"LCD",1,lpIniFile);
	BuildCharMap(MF_CHARMAP, lpIniFile, charMap);
}

void CCfgMilford::Save(LPCSTR lpIniFile)
{
	char string[32];

	WritePrivateProfileString( MF_SECTION, "ComPort", szComPort, lpIniFile);
	WritePrivateProfileString( MF_SECTION, "BaudRate", szBaudRate, lpIniFile);
	wsprintf(string,"%d",bBlink);
	WritePrivateProfileString(MF_SECTION,"SetBlink",string,lpIniFile);
	wsprintf(string,"%d",bScroll);
	WritePrivateProfileString(MF_SECTION,"SetScroll",string,lpIniFile);
	wsprintf(string,"%d",bShowCursor);
	WritePrivateProfileString(MF_SECTION,"Cursor",string,lpIniFile);
	wsprintf(string,"%d",bWrap);
	WritePrivateProfileString(MF_SECTION,"Wrap",string,lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(MF_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(MF_SECTION,"Rows",string,lpIniFile);
	wsprintf(string,"%d",byContrast);
	WritePrivateProfileString(MF_SECTION,"Contrast",string,lpIniFile);
	wsprintf(string,"%d",byBrightness);
	WritePrivateProfileString(MF_SECTION,"Brightness",string,lpIniFile);
	wsprintf(string,"%d",bLCD);
	WritePrivateProfileString(MF_SECTION,"LCD",string,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdMilfordBPK::CLcdMilfordBPK()
{
	m_pcDev = NULL;
}

CLcdMilfordBPK::~CLcdMilfordBPK()
{
	Close();

	if (m_pcDev != NULL)
		delete m_pcDev;
}

void  CLcdMilfordBPK::SetBacklight(short nMinutes)
{
	if (nMinutes < 0)
	{
		WriteCommand(char(14));
	}
	else
	{
		// @todo use backlight timer fctn in CLcd
		WriteCommand(char(14));
		//neads external time loop
		//WriteData( (BYTE)nMinutes );
	}

	m_nBackLight = nMinutes;
}

void  CLcdMilfordBPK::SetBlink(BOOL bOn)
{
	WriteCommand( bOn ? char(6) : (	m_bCursor ? char(5) : char(4) ));
	m_bBlink = bOn;
}

void  CLcdMilfordBPK::Clear()
{
	WriteCommand(char(12));
}

void  CLcdMilfordBPK::Close()
{
	if (m_pcDev)
		m_pcDev->Close();
}

BOOL  CLcdMilfordBPK::IsOpen()
{
	if (m_pcDev == NULL)
		return FALSE;

	return m_pcDev->IsOpen();
}

void  CLcdMilfordBPK::SetContrast(short nLevel)
{
	//not implemented see back of unit
}

void CLcdMilfordBPK::SetBrightness(short nLevel)
{
	//not implemented
}

void  CLcdMilfordBPK::Cursor(BOOL bOn)
{
	WriteCommand( bOn ? char(5): char(4) );
	m_bCursor = bOn;
}

void  CLcdMilfordBPK::HBar(short nCol, short nRow, short nDir, short nLen)
{
	// not yet implemented
}

void  CLcdMilfordBPK::Home()
{
	WriteCommand(char(1));
}

void  CLcdMilfordBPK::InitHorizontalBar()
{
	//not implemented (SEE MAXORBTAIL COMMAND 'h')
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(129));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(130));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);

	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(131));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);

	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(132));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(133));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(134));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	
	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(135));

	WriteData( (BYTE)128);
	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);

	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(136));

	WriteData( (BYTE)128);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
	WriteData( (BYTE)159);
}

void  CLcdMilfordBPK::InitLargeDigit()
{
	//nead to reset carictors for large char
	WriteCommand(char(2));
}

void  CLcdMilfordBPK::InitVerticalBar()
{
		//not implemented (SEE MAXORBTAIL COMMAND 'v')
}

void  CLcdMilfordBPK::LargeDigit(short nCol, short nNumber)
{
	// Reset Custom Char
	WriteCommand(char(27));
	WriteCommand(char(69));
	WriteCommand(char(49));
	
	// set mode large
	WriteCommand(char(16));
	WriteData( (BYTE)nCol );
	WriteCommand(char(2));
	WriteData( (BYTE)nNumber );
	WriteCommand(char(3));
}

void  CLcdMilfordBPK::SetLineWrap(BOOL bOn)
{
	
	//not implemented (All ways on)
	m_bLineWrap = true;
}

/******************************************************************************
Function : Open
Purpose  : Opens the comport and initilizes the display
Parameters : -
Returns : TRUE if successful, otherwise FALSE
Author  : Markus Zehnder	
******************************************************************************/
BOOL  CLcdMilfordBPK::Open()
{
	char szDef[20];

	// hack for backlight timer
	m_pInstance = this;

	if (m_pcDev == NULL) {
		m_pcDev = new CDevSerial();
	}

	sprintf(szDef, "%d,n,8,1", atoi(g_MilfordCfg.szBaudRate) );

	if (!m_pcDev->Open(g_MilfordCfg.szComPort, szDef))
	{
		Close();
		return FALSE;
	}		

	Clear();
	SetBlink( g_MilfordCfg.bBlink );
	Cursor( g_MilfordCfg.bShowCursor );
	//SetLineWrap( g_MilfordCfg.bWrap );
	//SetScroll( g_MilfordCfg.bScroll );

	//if (g_MilfordCfg.bLCD)
	//	SetContrast(g_MilfordCfg.byContrast);
	//else
	//	SetBrightness(g_MilfordCfg.byBrightness);

	m_charMap = g_MilfordCfg.charMap;

	return TRUE;
}

void  CLcdMilfordBPK::SetPosition(short nCol, short nRow)
{
	WriteCommand(char(16));
	WriteData( (BYTE) ( ((nRow - 1) * g_MilfordCfg.iCols) + (nCol - 1) ) + 64);
}

void  CLcdMilfordBPK::SetScroll(BOOL bOn)
{
		//not implemented (SEE MAXORBTAIL COMMAND 'Q' 'R'
	m_bScroll = false;
}

void  CLcdMilfordBPK::VBar(short nCol, short nLength)
{
	char map[9] = {(char)32, (char)129, (char)130, (char)131, (char)132, (char)133, (char)134, (char)135, char(255) };

	int y;
	for (y=g_MilfordCfg.iRows; y > 0 && nLength>0; y--) 
	{
		SetPosition(nCol,y);
		WriteData((BYTE)( nLength >= g_MilfordCfg.iCols ? 255 : map[nLength] ));
		nLength -= g_MilfordCfg.iCols;
	}
}

void  CLcdMilfordBPK::Write(LPCSTR lpText)
{
	m_pcDev->WriteData(lpText);
}

void CLcdMilfordBPK::WriteData(BYTE byData)
{
	m_pcDev->WriteData(byData);
}

void CLcdMilfordBPK::WriteCommand(BYTE byData)
{
	WriteData( byData );
	
}

BOOL  CLcdMilfordBPK::CreateCustomChar(short nNumber, CCustomChar &cChar)
{
	if (nNumber > MAX_CUSTOM_CHARS)	// bugfix: last custom char didn't get set, MZ July 28 2k
		return FALSE;


	WriteCommand(char(27));
	WriteCommand(char(68));
	WriteData( (BYTE)(nNumber + 48));

	int iMax = __min(8, cChar.m_byDataSize);
	for (int i = 0; i < iMax; i++)
	{
		if (cChar.m_byarrData[i] > 31)
			cChar.m_byarrData[i] = 0;	
		WriteData((cChar.m_byarrData[i] + 128));
	}

	for (; i < 8; i++)
	{
		WriteData( 128 );
	}

	return TRUE;
}

short CLcdMilfordBPK::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

LPCTSTR CLcdMilfordBPK::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( "%c1", ch );
	ch[0] = (char)2;
	csText.Replace( "%c2", ch );
	ch[0] = (char)3;
	csText.Replace( "%c3", ch );
	ch[0] = (char)4;
	csText.Replace( "%c4", ch );
	ch[0] = (char)5;
	csText.Replace( "%c5", ch );
	ch[0] = (char)6;
	csText.Replace( "%c6", ch );
	ch[0] = (char)7;
	csText.Replace( "%c7", ch );

	return csText;
}

LPCTSTR CLcdMilfordBPK::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( ch, "%c1" );
	ch[0] = (char)2;
	csText.Replace( ch, "%c2" );
	ch[0] = (char)3;
	csText.Replace( ch, "%c3" );
	ch[0] = (char)4;
	csText.Replace( ch, "%c4" );
	ch[0] = (char)5;
	csText.Replace( ch, "%c5" );
	ch[0] = (char)6;
	csText.Replace( ch, "%c6" );
	ch[0] = (char)7;
	csText.Replace( ch, "%c7" );

	return csText;
}

int	CLcdMilfordBPK::GetRows()		// MZ, June 27
{
	return g_MilfordCfg.iRows;
}

int	CLcdMilfordBPK::GetColumns()	// MZ, June 27
{
	return g_MilfordCfg.iCols;
}


LPCSTR CLcdMilfordBPK::ConvertTextToLCDCharset( CString &csText )
{
	// quick and dirty special char replacement
	csText.Replace( char(0),char(128));

	return CLcd::ConvertTextToLCDCharset(csText);
}

CDevSerial* CLcdMilfordBPK::GetSerialDevice()
{
	return m_pcDev;
}
