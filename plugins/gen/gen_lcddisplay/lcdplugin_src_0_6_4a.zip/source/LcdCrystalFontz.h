// LcdCrystalFontz.h: interface for the CLcdCrystalFontz class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LCDCRYSTALFONTZ_H__5A5F8D30_4DE4_499B_9640_13722C3027D6__INCLUDED_)
#define AFX_LCDCRYSTALFONTZ_H__5A5F8D30_4DE4_499B_9640_13722C3027D6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Lcd.h"
#include "SerialDevice.h"

#define	DEF_COMPORT_CF		"COM2"
#define DEF_BAUDRATE_CF		"9600"
#define DEF_CONTRAST_CF		50
#define DEF_BRIGHTNESS_CF	100

#define MAX_BAUDRATE_STRLEN 10
#define MAX_COMPORT_STRLEN   7

class CCfgCF
{
public:
	CCfgCF();
	~CCfgCF();
	void Load(LPCSTR lpIniFile);
	void Save(LPCSTR lpIniFile);

public:
	char	szComPort[10];
	char	szBaudRate[7];
	BYTE	byContrast;
	BYTE	byBrightness;
	BOOL	bShowCursor;
	BOOL	bWrap;
	BOOL	bScroll;
	BOOL	bBlink;
	int		iRows;
	int		iCols;
	tULongToULong charMap;
};

extern	CCfgCF	 g_CFCfg; 



class CLcdCrystalFontz : public CLcd  
{
public:
	CLcdCrystalFontz();
	virtual ~CLcdCrystalFontz();

	virtual void  SetBacklight(short nSeconds);
	virtual void  SetBlink(BOOL On);
	virtual void  Clear();
	virtual void  Close();
	virtual BOOL  IsOpen();
	virtual void  SetContrast(short nLevel);
	virtual void  SetBrightness(short nLevel);
	virtual void  Cursor(BOOL bOn);
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen);
	virtual void  Home();
	virtual void  InitHorizontalBar();
	virtual void  InitLargeDigit();
	virtual void  InitVerticalBar();
	virtual void  LargeDigit(short nCol, short nNumber);
	virtual void  SetLineWrap(BOOL bOn);
	virtual BOOL  Open();
	virtual void  SetPosition(short nCol, short nRow);
	virtual void  SetScroll(BOOL bOn);
	virtual void  VBar(short nCol, short nLength);
	virtual void  Write(LPCSTR lpText);
	virtual BOOL  CreateCustomChar(short nNumber, CCustomChar &cChar);
	virtual short GetMaxCustomChar();
	virtual LPCTSTR ConvertTagsToCustomChars(CString &csText);
	virtual LPCTSTR ConvertCustomCharsToTags(CString &csText);
	virtual int		GetRows();		
	virtual int		GetColumns();	
	virtual CDevSerial* GetSerialDevice();

private:
	void WriteData(BYTE byData);

private:
	BYTE	m_byCmdPrefix;

	CDevSerial	*m_pcDev;
};

#endif // !defined(AFX_LCDCRYSTALFONTZ_H__5A5F8D30_4DE4_499B_9640_13722C3027D6__INCLUDED_)
