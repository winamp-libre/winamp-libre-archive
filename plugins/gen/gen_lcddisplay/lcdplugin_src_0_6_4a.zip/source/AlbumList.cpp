// AlbumList.cpp: implementation of the CAlbumList class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "AlbumList.h"
#include "alfront.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAlbumList::CAlbumList()
{

}

CAlbumList::~CAlbumList()
{

}

BOOL CAlbumList::PlayAlbum(int index)
{
	if (m_hAlbumlist == NULL)
		return FALSE;
	return SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_PLAYALBUM,index);
}

BOOL CAlbumList::EnqueueAlbum(int index)
{
	if (m_hAlbumlist == NULL)
		return FALSE;
	return SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_ENQUEUEALBUM,index);
}


int CAlbumList::GetCount()
{
	if (m_hAlbumlist == NULL)
		return 0;

	return SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_GETALBUMSIZE,0);
}

BOOL CAlbumList::PlayRandomAlbum()
{
	if (m_hAlbumlist == NULL)
		return FALSE;

	return SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_PLAYRANDOMALBUM,0);
}

BOOL CAlbumList::GetAlbumName(int index, LPSTR lpBuffer, int iBufLen)
{
	if (m_hAlbumlist == NULL)
		return FALSE;

	return CopyString(lpBuffer,
					 (LPCSTR)SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_GETALBUMNAME,index),
					 iBufLen);
}

int CAlbumList::GetAlbumIndex()
{
	if (m_hAlbumlist == NULL)
		return -1;

	return SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_GETALBUMINDEX,0);
}

int CAlbumList::GetAlbumYear(int index)
{
	if (m_hAlbumlist == NULL)
		return -1;

	return SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_GETALBUMYEAR,index);
}

BOOL CAlbumList::GetAlbumTitle(int index, LPSTR lpBuffer, int iBufLen)
{
	if (m_hAlbumlist == NULL)
		return FALSE;

	return CopyString(lpBuffer,
					 (LPCSTR)SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_GETALBUMTITLE,index),
					 iBufLen);
}

BOOL CAlbumList::GetAlbumArtist(int index, LPSTR lpBuffer, int iBufLen)
{
	if (m_hAlbumlist == NULL)
		return FALSE;

	return CopyString(lpBuffer,
					 (LPCSTR)SendMessage(m_hAlbumlist,WM_AL_IPC,IPC_GETALBUMARTIST,index),
					 iBufLen);
}

BOOL CAlbumList::Init()
{
	m_hAlbumlist = ::FindWindow("Winamp AL",NULL);

	//@TODO check version

	return (m_hAlbumlist != NULL);
}

BOOL CAlbumList::CopyString(LPSTR dest, LPCSTR source, int iBufLen)
{
	if (dest == NULL || source == NULL)
		return FALSE;

	int iLen = strlen(source);
	iBufLen--;
	iLen = __min(iBufLen, iLen);
	strncpy(dest, source, iLen);
	dest[iLen] = '\0';

	return TRUE;
}
