#include "lcdsim.h"
#include "resource.h"
#include <stdio.h>
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>

// ------------------------------------------------------------------------
// Definitionen
// ------------------------------------------------------------------------

// Benutzerdefinierte Nachrichten die in der Messagequeue verarbeitet werden
#define WM_USER_DEFSIZE  WM_USER+10
#define WM_USER_CALLBACK WM_USER+11

#define TIM_LIGHT_OFF    10

#define DISPWNDCLASS  "SpeedyDisplayWindowClass"
#define DISPWNDEXTRA  (10 * sizeof(long)); //MEHR ALS 10 GEHT NICHT MEHR!!!!!!

#define DispWnd_GetCursorPos(hwnd) \
  ((ULONG)GetWindowLong((hwnd),0*sizeof(long)))

#define DispWnd_SetCursorPos(hwnd,ulPos) \
  (SetWindowLong((hwnd),0*sizeof(long),(LONG)(ulPos)))

#define DispWnd_GetTextPtr(hwnd) \
  ((char**)GetWindowLong((hwnd),1*sizeof(long)))

#define DispWnd_SetTextPtr(hwnd,ppText) \
  (SetWindowLong((hwnd),1*sizeof(long),(LONG)(ppText)))

#define DispWnd_GetLcdBmp(hwnd) \
  ((HBITMAP)GetWindowLong((hwnd),2*sizeof(long)))

#define DispWnd_SetLcdBmp(hwnd,hBmp) \
  (SetWindowLong((hwnd),2*sizeof(long),(LONG)(hBmp)))

#define DispWnd_GetLcdCharWidth(hwnd) \
  (LOWORD(GetWindowLong((hwnd),3*sizeof(long))))

#define DispWnd_GetLcdCharHeight(hwnd) \
  (HIWORD(GetWindowLong((hwnd),3*sizeof(long))))

#define DispWnd_SetLcdCharDimensions(hwnd,cxChar,cyChar) \
  (SetWindowLong((hwnd),3*sizeof(long),MAKELONG((cxChar),(cyChar))))

#define DispWnd_GetFgColorOn(hwnd) \
  ((COLORREF)GetWindowLong((hwnd),4*sizeof(long)))

#define DispWnd_SetFgColorOn(hwnd,cFgCol) \
  (SetWindowLong((hwnd),4*sizeof(long),(LONG)(cFgCol)))

#define DispWnd_GetFgColorOff(hwnd) \
  ((COLORREF)GetWindowLong((hwnd),5*sizeof(long)))

#define DispWnd_SetFgColorOff(hwnd,cFgCol) \
  (SetWindowLong((hwnd),5*sizeof(long),(LONG)(cFgCol)))

#define DispWnd_GetBkColorOn(hwnd) \
  ((COLORREF)GetWindowLong((hwnd),6*sizeof(long)))

#define DispWnd_SetBkColorOn(hwnd,cBkCol) \
  (SetWindowLong((hwnd),6*sizeof(long),(LONG)(cBkCol)))

#define DispWnd_GetBkColorOff(hwnd) \
  ((COLORREF)GetWindowLong((hwnd),7*sizeof(long)))

#define DispWnd_SetBkColorOff(hwnd,cBkCol) \
  (SetWindowLong((hwnd),7*sizeof(long),(LONG)(cBkCol)))

#define DispWnd_GetBkColor(hwnd) \
  DispWnd_GetLightState(hwnd) ? DispWnd_GetBkColorOn(hwnd) : DispWnd_GetBkColorOff(hwnd)

#define DispWnd_GetFgColor(hwnd) \
  DispWnd_GetLightState(hwnd) ? DispWnd_GetFgColorOn(hwnd) : DispWnd_GetFgColorOff(hwnd)

#define DispWnd_GetLightState(hwnd) \
  (GetWindowLong((hwnd),8*sizeof(long)))

#define DispWnd_SetLightState(hwnd,iState) \
  (SetWindowLong((hwnd),8*sizeof(long),(LONG)(iState)))

#define DispWnd_GetCustomChar(hwnd) \
  (tCustomLcdChar*)(GetWindowLong((hwnd),9*sizeof(long)))

#define DispWnd_SetCustomChar(hwnd,pChars) \
  (SetWindowLong((hwnd),9*sizeof(long),(LONG)(pChars)))

#define LCD_INIT_LINE \
  "\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F" \
  "\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x7F\x00"


// ------------------------------------------------------------------------
// Lokale Typ-Definitionen
// ------------------------------------------------------------------------

typedef struct sCustomLcdChar
{
  int cCharNum;
  char* pCharData;
  int iCharDataLen;
}
tCustomLcdChar;

// ------------------------------------------------------------------------
// Lokale Funktionstypen
// ------------------------------------------------------------------------
LRESULT CALLBACK LcdDisplaySim_Proc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

int LoadLcdSimCharSet(HWND hwnd);
int PaintLcdDisplay(HWND hwnd, PAINTSTRUCT* pPaint);
void GenerateCustomChars(HWND hwndDisplay);
void InitDisplay(HWND hwndDisp, int cxChar, int chChar);
void TermDisplay(HWND hwndDisp);


// ------------------------------------------------------------------------
// Lokale Variablen
// ------------------------------------------------------------------------
static HINSTANCE xAppInst;


// ------------------------------------------------------------------------
// Function: LcdDisplaySim_Open
// Info    : LCD-display erzeugen
// Params  : Zeiger auf LcdSimParam Struktur
// Result  : fenster-handle des LCD-displays
// ------------------------------------------------------------------------
HWND LcdDisplaySim_Open(tLcdSimParams* pParams)
{
  HWND hwnd;
  WNDCLASS sWndCls;
  static ATOM aClass = 0;

  xAppInst = pParams->hInstance;

  if(!aClass)
  {
    sWndCls.style = 0;
    sWndCls.lpfnWndProc = (WNDPROC)LcdDisplaySim_Proc;
    sWndCls.cbClsExtra = 0;
    sWndCls.cbWndExtra = DISPWNDEXTRA; // Platz f�r 10 Long Werte reservieren
    sWndCls.hInstance = pParams->hInstance;
    sWndCls.hIcon = 0;
    sWndCls.hCursor = LoadCursor(0, IDC_ARROW);
    sWndCls.hbrBackground = 0;
    sWndCls.lpszMenuName = 0;
    sWndCls.lpszClassName = DISPWNDCLASS;

    aClass = RegisterClass(&sWndCls); // Eindeutige Identifizierung der Klasse merken
  }

  //Fenster erstellen
  hwnd = CreateWindowEx(WS_EX_CLIENTEDGE|WS_EX_TOOLWINDOW,
						DISPWNDCLASS,
						pParams->pTitle,
						WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_THICKFRAME|WS_VSCROLL,
						pParams->xPos,
						pParams->yPos,
						0, 0, 0, 0,
						pParams->hInstance, pParams);
   // pParams => Zeiger auf die Parameterstruktur der Initialisierungswerte //
   // Dieser Wert kann dann in WM_CREATE ausgelesen werden                  //
	  
  return hwnd;
}

// ------------------------------------------------------------------------
// Function: LcdDisplaySim_Close
// Info    : LCD-Display Simulationsfenster schliessen
// Params  : Handle des Simulationsfenster
// Result  : keins
// ------------------------------------------------------------------------
void LcdDisplaySim_Close(HWND hwndDisplay)
{
  DestroyWindow(hwndDisplay);
}

// ------------------------------------------------------------------------
// Function: LcdDisplaySim_Clear
// Info    : loescht den inhalt des LCD-displays und setzt die Cursor 
//           Poistion nach oben links
// Params  : Handle des Simulationsfenster
// Result  : keins
// ------------------------------------------------------------------------
void LcdDisplaySim_Clear(HWND hwndDisplay)
{
  int iLine;
  char** ppText;

  DispWnd_SetCursorPos(hwndDisplay, MAKELONG(0,0)); // CursorPosition 0,0 setzen
  ppText = DispWnd_GetTextPtr(hwndDisplay);  
  
  for(iLine = 0; ppText[iLine]; iLine++)
  {
    free(ppText[iLine]);
    ppText[iLine] = strdup("");
  }
  
  InvalidateRect(hwndDisplay, 0, 0);  
}

// ------------------------------------------------------------------------
// Function: LcdDisplaySim_SetCursorPos
// Info    : setzt den Cursor in der Simulation auf die angegebene Position
// Params  : Handle auf das Simulationsfenster, neue X- und Y-Position
// Result  : keins
// ------------------------------------------------------------------------
void LcdDisplaySim_SetCursorPos(HWND hwndDisplay, int xPos, int yPos)
{
	// Wir machen aus den Werten von X und Y einen Long Wert und speichern
	// diesen in einen resevierten Bereich des Simulationsfenster
  DispWnd_SetCursorPos(hwndDisplay, MAKELONG(xPos,yPos));
}

/* ------------------------------------------------------------------------
 * @Function: LcdDisplaySim_PrintString
 * @Info    : gibt einen string an der aktuellen cursor-position aus
 * @Result  : keins
 * ------------------------------------------------------------------------ */
void LcdDisplaySim_PrintString(HWND hwndDisplay, const char* pText)
{
  ULONG ulPos;
  char** ppText;
  int xPos, yPos, iLines;
  
  ulPos = DispWnd_GetCursorPos(hwndDisplay);
  xPos = LOWORD(ulPos);
  yPos = HIWORD(ulPos);
 
  ppText = DispWnd_GetTextPtr(hwndDisplay);  
  for(iLines = 0; ppText[iLines]; iLines++) ;
  
  if(yPos >= iLines) return;
  
  if(strlen(pText) + xPos > strlen(ppText[yPos]))
  {
    ppText[yPos] = realloc(ppText[yPos], strlen(pText) + xPos + 1);
    
    if(xPos > (int)strlen(ppText[yPos]))
      memset(ppText[yPos] + strlen(ppText[yPos]), (int)' ', xPos - strlen(ppText[yPos]));
    
    strcpy(ppText[yPos] + xPos, pText);
  }
  else
  {    
    strncpy(ppText[yPos] + xPos, pText, strlen(pText));
  }
  
  xPos += strlen(pText);
  ulPos = MAKELONG(xPos, yPos);
  DispWnd_SetCursorPos(hwndDisplay, ulPos);
  
  InvalidateRect(hwndDisplay, 0, 0);
}




void LcdDisplaySim_SetCustomChar(HWND hwndDisplay, char cChar, char* pCharData, int iCharDataLen)
{
  int iCnt;
  tCustomLcdChar* pCustCharLst, * pCustChar;

  pCustCharLst = DispWnd_GetCustomChar(hwndDisplay);

  for(iCnt = 0, pCustChar = 0; pCustCharLst[iCnt].cCharNum; iCnt++)
  {
    if(pCustCharLst[iCnt].cCharNum == cChar)
	  pCustChar = &pCustCharLst[iCnt];
  }

  if(!pCustChar)
  {
	pCustCharLst = realloc(pCustCharLst, sizeof(tCustomLcdChar) * (iCnt+2));
	DispWnd_SetCustomChar(hwndDisplay, pCustCharLst);

	pCustChar = &pCustCharLst[iCnt];
	memset(&pCustChar[1], 0, sizeof(tCustomLcdChar));
  }

  pCustChar->cCharNum = cChar;
  pCustChar->pCharData = calloc(1, iCharDataLen);
  memcpy(pCustChar->pCharData, pCharData, iCharDataLen);
  pCustChar->iCharDataLen = iCharDataLen;

  GenerateCustomChars(hwndDisplay);
  InvalidateRect(hwndDisplay, 0, 0);

  return;
}


/* ------------------------------------------------------------------------
 * @Function: LcdDisplaySim_LightOn
 * @Info    : schaltet die Hintergrundbeleuchtung an und setzt einen Timer
 *            an dem das Licht wieder ausgeschaltet wird
 * @Result  : keins
 * ------------------------------------------------------------------------ */
void LcdDisplaySim_LightOn(HWND hwndDisplay, int iTurnOffSeconds)
{
  DispWnd_SetLightState(hwndDisplay, 1);
  DeleteObject(DispWnd_GetLcdBmp(hwndDisplay));
  LoadLcdSimCharSet(hwndDisplay);

  InvalidateRect(hwndDisplay, 0, 0);

  if(iTurnOffSeconds)
    SetTimer(hwndDisplay, TIM_LIGHT_OFF, iTurnOffSeconds*1000, 0);
}

/* ------------------------------------------------------------------------
 * @Function: LcdDisplaySim_LightOff
 * @Info    : schaltet die Hintergrundbeleuchtung aus
 * @Result  : keins
 * ------------------------------------------------------------------------ */
void LcdDisplaySim_LightOff(HWND hwndDisplay)
{
  DispWnd_SetLightState(hwndDisplay, 0);
  DeleteObject(DispWnd_GetLcdBmp(hwndDisplay));
  LoadLcdSimCharSet(hwndDisplay);

  InvalidateRect(hwndDisplay, 0, 0);
}

/* ------------------------------------------------------------------------
 * @Function: LcdDisplaySim_SetContrast
 * @Info    : ver�ndert die Hintergrundfarbe und speichert den Wert
 * @Result  : keins
 * ------------------------------------------------------------------------ */
void LcdDisplaySim_SetContrast(HWND hwndDisplay, COLORREF cNewColor)
{
  DispWnd_SetBkColorOn(hwndDisplay, cNewColor);
  DeleteObject(DispWnd_GetLcdBmp(hwndDisplay));
  LoadLcdSimCharSet(hwndDisplay);

  InvalidateRect(hwndDisplay, 0, 0);

}
// ------------------------------------------------------------------------
// Function: LcdDisplaySim_Proc
// Info    : fensterprozedur des LCD-Display-Fensters
// Result  : abhaengig von der zu bearbeitenden message
// ------------------------------------------------------------------------ 
LRESULT CALLBACK LcdDisplaySim_Proc(HWND hwnd,// fensterhandle              //
                          UINT uMsg,          // message                    // 
                          WPARAM wParam,      // erster message-parameter   //
                          LPARAM lParam)      // zweiter message-parameter  //
{
  switch(uMsg)
  {
    case WM_CREATE:                           // fenster wird erzeugt       //
    {
      HMENU hMenu;
      tLcdSimParams* pParams;                 // Zeigervariable f�r die Ini-//
                                              // tialisierungsparameter     //
      pParams = (tLcdSimParams*)((CREATESTRUCT*)lParam)->lpCreateParams;
	                                  // Zeiger aus lpCreateParams auslesen //
      
      hMenu = GetSystemMenu(hwnd, 0);       // nicht benoetigte punkte aus  //
      DeleteMenu(hMenu, SC_RESTORE, 0);     // dem system-menu loeschen     //
      DeleteMenu(hMenu, SC_MAXIMIZE, 0);
      DeleteMenu(hMenu, SC_MINIMIZE, 0);

      DispWnd_SetBkColorOn(hwnd, pParams->sLightOn.cBkCol); // Hintergrundfarbe setzen //
      DispWnd_SetFgColorOn(hwnd, pParams->sLightOn.cFgCol); // Vordergrundfarbe setzen //
      DispWnd_SetBkColorOff(hwnd, pParams->sLightOff.cBkCol); // Hintergrundfarbe setzen //
      DispWnd_SetFgColorOff(hwnd, pParams->sLightOff.cFgCol); // Vordergrundfarbe setzen //
      InitDisplay(hwnd, pParams->cxChars, pParams->cyChars); // Display initialisieren//

      LoadLcdSimCharSet(hwnd);                   // Simulationsfenster auf die //
	                                             // benuterdeninierten Farben setzen//
      SendMessage(hwnd, WM_USER_DEFSIZE, pParams->cxChars, 0);  // Benutzerdefinierte Fenstergr��e setzen//
      ShowWindow(hwnd, SW_SHOW);                  /* anzeigen               */

      break;
    }

	case WM_TIMER:

	  if(wParam == TIM_LIGHT_OFF)
	  {
	    LcdDisplaySim_LightOff(hwnd);
		KillTimer(hwnd, TIM_LIGHT_OFF);
		return 0;
	  }
	  break;

    case WM_PAINT:                          /* fenster-update noetig        */
    {
      PAINTSTRUCT sPaint;

      BeginPaint(hwnd, &sPaint);            /* paint-struktur holen         */
      PaintLcdDisplay(hwnd, &sPaint);       /* lcd-display malen            */
      EndPaint(hwnd, &sPaint);              /* paint-struktur freigeben     */

      return 0;
    }      

    case WM_SIZING:                         /* korrigiert groesse           */
    {
      RECT sRcWnd, * pRect;
      int cxChar, cyChar, iLines, iSBar, iHlp;
      char** ppText = DispWnd_GetTextPtr(hwnd);

      cxChar = DispWnd_GetLcdCharWidth(hwnd);     /* hoehe und breite der   */
      cyChar = DispWnd_GetLcdCharHeight(hwnd);    /* lcd-zeichen abfragen   */
      for(iLines = 0; ppText[iLines]; iLines++) ; /* display-zeilen zaehlen */
      iSBar = GetSystemMetrics(SM_CXVSCROLL);     /* breite der scroll-bar  */
      
      SetRectEmpty(&sRcWnd);                /* minimales client-rect        */
      InflateRect(&sRcWnd, 1, 1);           /* zusammenbauen                */
      AdjustWindowRectEx(&sRcWnd,           /* window-rect errechnen        */
        WS_CAPTION|WS_THICKFRAME, 0, WS_EX_CLIENTEDGE|WS_EX_TOOLWINDOW);
        
      pRect = (RECT*)lParam;

      if(wParam == WMSZ_TOP ||              /* obere kante korrigieren      */
        wParam == WMSZ_TOPLEFT || wParam == WMSZ_TOPRIGHT)
      {
        pRect->top -= cyChar / 2;
        iHlp = pRect->bottom - pRect->top - sRcWnd.bottom + sRcWnd.top;
        if(iHlp < cyChar * iLines) pRect->top += iHlp % cyChar;
        else pRect->top += iHlp - cyChar * iLines, iSBar = 0;
      }
      else if(wParam == WMSZ_BOTTOM ||      /* untere kante korrigieren     */
        wParam == WMSZ_BOTTOMLEFT || wParam == WMSZ_BOTTOMRIGHT)
      {
        pRect->bottom += cyChar / 2;
        iHlp = pRect->bottom - pRect->top - sRcWnd.bottom + sRcWnd.top;
        if(iHlp < cyChar * iLines) pRect->bottom -= iHlp % cyChar;
        else pRect->bottom -= iHlp - cyChar * iLines, iSBar = 0;
      }
      else                                  /* pruefen, ob scrollbar noetig */
      {
        iHlp = pRect->bottom - pRect->top - sRcWnd.bottom + sRcWnd.top;
        if(iHlp >= cyChar * iLines) iSBar = 0;
      }
      
      if(wParam == WMSZ_LEFT ||             /* linke kante korrigieren      */
        wParam == WMSZ_TOPLEFT || wParam == WMSZ_BOTTOMLEFT)
      {
        pRect->left -= cxChar / 2;
        iHlp = pRect->right - pRect->left - sRcWnd.right + sRcWnd.left - iSBar;        
        if(iHlp > cxChar * 2) pRect->left += iHlp % cxChar;
        else pRect->left -= cxChar * 2 - iHlp;
      }
      else if(wParam == WMSZ_RIGHT ||       /* rechte kante korrigieren     */
        wParam == WMSZ_TOPRIGHT || wParam == WMSZ_BOTTOMRIGHT)
      {
        pRect->right += cxChar / 2;
        iHlp = pRect->right - pRect->left - sRcWnd.right + sRcWnd.left - iSBar;
        if(iHlp > cxChar * 2) pRect->right -= iHlp % cxChar;
        else pRect->right += cxChar * 2 - iHlp;
      }
      else                                  /* korrektur nur fuer scrollbar */
      {
        pRect->right += iSBar / 2;
        iHlp = pRect->right - pRect->left - sRcWnd.right + sRcWnd.left - iSBar;
        if(iHlp > cxChar * 2) pRect->right -= iHlp % cxChar;
        else pRect->right += cxChar * 2 - iHlp;
      }

      return 1;
    }
    
    case WM_SIZE:
    {
      SCROLLINFO sInf;
      int cyChar, iLines, iPos, iMax;
      char** ppText = DispWnd_GetTextPtr(hwnd);

      cyChar = DispWnd_GetLcdCharHeight(hwnd);    /* breite der lcd-zeichen */
      if(!cyChar) return 0;                       /* lcd nicht initialisert */
      for(iLines = 0; ppText[iLines]; iLines++) ; /* display-zeilen zaehlen */
      
      memset(&sInf, 0, sizeof(sInf));       /* scroll-bar-info struktur     */
      sInf.cbSize = sizeof(sInf);           /* initialisieren               */
      sInf.fMask = SIF_PAGE|SIF_RANGE;
      sInf.nMin = 1;                        /* scroll-bereich und groesse   */
      sInf.nMax = iLines;                   /* einer scroll-seite setzen    */
      sInf.nPage = (GET_Y_LPARAM(lParam) - 2) / cyChar;
      
      iPos = GetScrollPos(hwnd, SB_VERT);   /* aktuelle scroll-position     */
      iMax = sInf.nMax - sInf.nPage + 1;    /* pruefen, ob scroll-position  */
      if(iPos > iMax)                       /* angepasst werden muss        */
        SendMessage(hwnd, WM_VSCROLL, MAKEWPARAM(SB_THUMBTRACK,iMax), 0);

      SetScrollInfo(hwnd, SB_VERT, &sInf, 1); /* scroll-bar aktualisieren   */

      return 0;
    }
    
    case WM_KEYDOWN:
    {
      WORD wScrollNotify = 0xFFFF;
      
      switch(wParam)
      {
        case VK_UP: wScrollNotify = SB_LINEUP; break;
        case VK_DOWN: wScrollNotify = SB_LINEDOWN; break;
        case VK_PRIOR: wScrollNotify = SB_PAGEUP; break;
        case VK_NEXT: wScrollNotify = SB_PAGEDOWN; break;  
        case VK_HOME: wScrollNotify = SB_TOP; break;
        case VK_END: wScrollNotify = SB_BOTTOM; break;
      }
      
      if(wScrollNotify != 0xFFFF)
        SendMessage(hwnd, WM_VSCROLL, MAKELONG(wScrollNotify,0), 0);  
      
      break;
    }
        
    case WM_VSCROLL:
    {
      SCROLLINFO sInf;
      int cyChar, iPos, iMax;
      
      cyChar = DispWnd_GetLcdCharHeight(hwnd); /* breite der lcd-zeichen    */

      memset(&sInf, 0, sizeof(sInf));       /* scroll-bar-info struktur     */
      sInf.cbSize = sizeof(sInf);           /* initialisieren               */
      sInf.fMask = SIF_PAGE|SIF_POS|SIF_RANGE;
      
      GetScrollInfo(hwnd, SB_VERT, &sInf);  /* scroll-bar-info holen        */
      iMax = sInf.nMax - sInf.nPage + 1;    /* maximale end-pos. berechnen  */
      
      switch(LOWORD(wParam))                /* je nach scroll-event,        */
      {                                     /* scroll-position anpassen     */
        case SB_LINEUP: iPos = sInf.nPos - 1; break;
        case SB_LINEDOWN: iPos = sInf.nPos + 1; break;
        case SB_PAGEUP: iPos = sInf.nPos - sInf.nPage; break;
        case SB_PAGEDOWN: iPos = sInf.nPos + sInf.nPage; break;
        case SB_TOP: iPos = sInf.nMin; break;
        case SB_BOTTOM: iPos = iMax; break;
        case SB_THUMBTRACK: iPos = HIWORD(wParam); break;
        default: iPos = sInf.nPos; break;
      }
      
      if(iPos < sInf.nMin) iPos = sInf.nMin; /* pruefen, ob der scroll-     */
      else if(iPos > iMax) iPos = iMax;      /* bereich noch passt          */

      if(iPos == sInf.nPos) return 0;       /* keine aenderung? abbrechen   */
      
      ScrollWindowEx(hwnd, 0,               /* fenster scrollen             */
        (sInf.nPos - iPos) * cyChar, 0, 0, 0, 0, SW_INVALIDATE);
      SetScrollPos(hwnd, SB_VERT, iPos, 1); /* scroll-bar aktualisieren     */
      UpdateWindow(hwnd);                   /* fenster aktualisieren        */

      return 0;
    }

    case WM_USER_DEFSIZE:                   /* stellt default-groesse her   */
    {
      RECT rcWnd;
      int cxChar, cyChar, iLines = 0;
      char** ppText = DispWnd_GetTextPtr(hwnd);

      cxChar = DispWnd_GetLcdCharWidth(hwnd);
      cyChar = DispWnd_GetLcdCharHeight(hwnd);

      while(ppText[iLines]) iLines++;       /* anzahl zeilen im display     */

      rcWnd.left = 0;                       /* client-rect                  */
      rcWnd.right = cxChar * wParam + 2;        /* zusammenbauen                */
      rcWnd.top = 0;
      rcWnd.bottom = cyChar * iLines + 2;

      AdjustWindowRectEx(&rcWnd,            /* window-rect errechnen        */
        WS_CAPTION|WS_THICKFRAME, 0, WS_EX_CLIENTEDGE|WS_EX_TOOLWINDOW);

      SetWindowPos(hwnd, 0, 0, 0,           /* position setzen              */
        rcWnd.right - rcWnd.left, rcWnd.bottom - rcWnd.top,
        SWP_NOMOVE|SWP_NOZORDER|SWP_NOACTIVATE);

      return 0;
    }

    case WM_DESTROY:
	  TermDisplay(hwnd);
      DeleteObject(DispWnd_GetLcdBmp(hwnd));
      break;
  }

  return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

// ------------------------------------------------------------------------
// Function: LoadLcdSimCharSet
// Info    : Ersetzt die Farben des original Bitmap durch die benutzerdefinierten Farben.
//           Errechnet die Gr��e eines Displayzeichens.
//           Das Handle auf das ver�nderte Bitmap und die Gr��eninfo's werden im 
//           Simulationsfenster abgelegt !!
// Params  : Handle auf das LCDSimulationsfenster
// Result  : TRUE wenn gut, FALSE wenn schlecht
// ------------------------------------------------------------------------
int LoadLcdSimCharSet(HWND hwnd)           // handle des display-fensters//
{
  BITMAP sBmp; //Anlegen einer BITMAP Struktur
  // Diese Struktur definiert den Typ, Breite, H�he, Farbformat, und Bitwerte des Bildes

  COLORREF cFgCol, cBkCol;
  // Dies COLORREF Werte sind zur spezifikation einer RGB Farbe

  HBRUSH hFgBrush, hBkBrush; 
  
  HBITMAP hBmpSrc, hBmpTmp, hBmpTgt;
  // Handle auf Bitmaps

  HDC hdcWnd, hdcSrc, hdcTmp, hdcTgt;
  // Handle auf Device Kontext

  HGDIOBJ hOldBmp1, hOldBmp2, hOldBmp3, hOldBrush;
  // Variablen f�r alte Objekte im DC

  cFgCol = DispWnd_GetFgColor(hwnd); // Vordergrundfarbe auslesen
  if(cFgCol == CLR_DEFAULT) cFgCol = GetSysColor(COLOR_BTNTEXT);

  cBkCol = DispWnd_GetBkColor(hwnd);  // Hintergrundfarbe auslesen
  if(cBkCol == CLR_DEFAULT) cBkCol = GetSysColor(COLOR_3DFACE);

  hBmpSrc = LoadBitmap(xAppInst, MAKEINTRESOURCE(ID_BMP_LCDCHARS));
  if(!hBmpSrc) return 0;                    // original-bitmap laden

  hdcWnd = GetDC(hwnd);                     // dc des Simulationsfensters holen
										    // Nur f�r CreateCOMPAtible* ben�tigt !

  hFgBrush = CreateSolidBrush(cFgCol);      // brushes erzeugen
  hBkBrush = CreateSolidBrush(cBkCol);

  hdcSrc = CreateCompatibleDC(hdcWnd);      // temporaer-dc's erzeugen
  hdcTmp = CreateCompatibleDC(hdcWnd);
  hdcTgt = CreateCompatibleDC(hdcWnd);

  GetObject(hBmpSrc, sizeof(sBmp), &sBmp);  // neues bitmap erzeugen
  hBmpTmp = CreateCompatibleBitmap(hdcWnd, sBmp.bmWidth, sBmp.bmHeight);
  hBmpTgt = CreateCompatibleBitmap(hdcWnd, sBmp.bmWidth, sBmp.bmHeight);

  hOldBmp1 = SelectObject(hdcSrc, hBmpSrc); // bitmaps in die dc's setzen
  hOldBmp2 = SelectObject(hdcTmp, hBmpTmp); // Als Ergebnis bekommt man das Handle
  hOldBmp3 = SelectObject(hdcTgt, hBmpTgt); // auf vom alten Objekt

  // Hier wird jetzt ein geiles GDI-Geh�nsel vollbracht
  hOldBrush = SelectObject(hdcTmp, hBkBrush);
  BitBlt(hdcTmp, 0, 0, sBmp.bmWidth, sBmp.bmHeight, hdcSrc, 0, 0, MERGECOPY);
  SelectObject(hdcTmp, hOldBrush);
  PatBlt(hdcSrc, 0, 0, sBmp.bmWidth, sBmp.bmHeight, DSTINVERT);
  hOldBrush = SelectObject(hdcTgt, hFgBrush);
  BitBlt(hdcTgt, 0, 0, sBmp.bmWidth, sBmp.bmHeight, hdcSrc, 0, 0, MERGECOPY);
  SelectObject(hdcTgt, hOldBrush);
  BitBlt(hdcTgt, 0, 0, sBmp.bmWidth, sBmp.bmHeight, hdcTmp, 0, 0, SRCPAINT);

  SelectObject(hdcSrc, hOldBmp1);           // bitmaps aus den dc's loesen
  SelectObject(hdcTmp, hOldBmp2);
  SelectObject(hdcTgt, hOldBmp3);
 
  DeleteObject(hBmpSrc);                    // temporaer-bitmap's loeschen
  DeleteObject(hBmpTmp);
  DeleteObject(hdcSrc);                     // temporaer-dc's loeschen
  DeleteObject(hdcTmp);
  DeleteObject(hdcTgt);
  DeleteObject(hFgBrush);                   // brushes loeschen
  DeleteObject(hBkBrush);

  ReleaseDC(hwnd, hdcWnd);                  // fenster-dc zurueckgeben

  DispWnd_SetLcdBmp(hwnd, hBmpTgt);
  DispWnd_SetLcdCharDimensions(hwnd, sBmp.bmWidth / 128, sBmp.bmHeight / 2);

  GenerateCustomChars(hwnd);

  return 1;
}                    

/* ------------------------------------------------------------------------
 * @Function: PaintLcdDisplay
 * @Info    : macht die WM_PAINT-behandlung fuer das lcd-display
 * @Result  : TRUE wenn gut, FALSE wenn schlecht
 * ------------------------------------------------------------------------ */
int PaintLcdDisplay(HWND hwnd,              /* handle des fensters          */
                    PAINTSTRUCT* pPaint)    /* paint-struktur               */
{
  HPEN hPen;
  HDC hdcTmp;
  RECT sRcLcd;
  HBRUSH hBrush;
  COLORREF cBkCol;
  HGDIOBJ hOldBmp, hOldPen, hOldBrush;
  char* pLine, ** ppText, cChar;
  int xChar, yChar, yOffset, cxChar, cyChar;

  ppText = DispWnd_GetTextPtr(hwnd);
  cxChar = DispWnd_GetLcdCharWidth(hwnd);
  cyChar = DispWnd_GetLcdCharHeight(hwnd);  

  cBkCol = DispWnd_GetBkColor(hwnd);  
  if(cBkCol == CLR_DEFAULT) cBkCol = GetSysColor(COLOR_3DFACE);
  
  GetClientRect(hwnd, &sRcLcd);             /* groesse des lcd-bereichs     */

  hPen = CreatePen(PS_SOLID, 1, cBkCol);    /* pen erzeugen                 */
  hBrush = GetStockObject(NULL_BRUSH);      /* null-brush holen             */
  hOldPen = SelectObject(pPaint->hdc, hPen);
  hOldBrush = SelectObject(pPaint->hdc, hBrush);

  Rectangle(pPaint->hdc, 0, 0, sRcLcd.right, sRcLcd.bottom); /* ramen malen */

  SelectObject(pPaint->hdc, hOldPen);
  SelectObject(pPaint->hdc, hOldBrush);
  DeleteObject(hPen);                       /* pen wieder loeschen          */

  hdcTmp = CreateCompatibleDC(pPaint->hdc); /* temporaer-dc erzeugen        */
  hOldBmp = SelectObject(hdcTmp, DispWnd_GetLcdBmp(hwnd)); /* bitmap in dc  */
  
  yOffset = GetScrollPos(hwnd,SB_VERT) - 1; /* scroll-offset berechnen      */
  for(yChar = 0; yChar * cyChar < sRcLcd.bottom-2; yChar++)
  {
    if(!(pLine = ppText[yChar+yOffset]))
      break;
    for(xChar = 0; xChar * cxChar < sRcLcd.right-2; xChar++)
    {    
      cChar = *pLine ? *pLine++ : ' ';
      BitBlt(pPaint->hdc, xChar * cxChar + 1, 
        yChar * cyChar + 1, cxChar, cyChar, hdcTmp,
        cxChar * (cChar & 0x7F), (cChar & 0x80) ? cyChar : 0, SRCCOPY);
    }
  }

  SelectObject(hdcTmp, hOldBmp);            /* bitmap aus dc loesen         */
  DeleteDC(hdcTmp);                         /* temporaer-dc loeschen        */
  
  return 1;
}

/* ------------------------------------------------------------------------
 * @Function: GenerateCustomChars
 * @Info    : gibt einen string an der aktuellen cursor-position aus
 * @Result  : keins
 * ------------------------------------------------------------------------ */
void GenerateCustomChars(HWND hwndDisplay)
{
  RECT sRect;
  HGDIOBJ hOldBmp;
  HDC hDcWnd, hDcTmp;
  char cCharLineData;
  HBRUSH hBrushFg, hBrushBk;
  tCustomLcdChar* pCustomChar;
  int cxChar, cyChar, iPixLine, iPixCol;

  pCustomChar = DispWnd_GetCustomChar(hwndDisplay);
  if(!pCustomChar) return;

  cxChar = DispWnd_GetLcdCharWidth(hwndDisplay);
  cyChar = DispWnd_GetLcdCharHeight(hwndDisplay);

  hDcWnd = GetDC(hwndDisplay);
  hDcTmp = CreateCompatibleDC(hDcWnd); /* temporaer-dc erzeugen        */
  hOldBmp = SelectObject(hDcTmp, DispWnd_GetLcdBmp(hwndDisplay));
  hBrushBk = CreateSolidBrush(DispWnd_GetBkColor(hwndDisplay));
  hBrushFg = CreateSolidBrush(DispWnd_GetFgColor(hwndDisplay));

  for( ; pCustomChar->cCharNum; pCustomChar++)
  {    
    sRect.left = cxChar * (pCustomChar->cCharNum & 0x7F);
    sRect.top = (pCustomChar->cCharNum & 0x80) ? cyChar : 0;
    sRect.right = sRect.left + cxChar;
    sRect.bottom = sRect.top + cyChar;
  
    FillRect(hDcTmp, &sRect, hBrushBk);
  
    for(iPixLine = 0; iPixLine < 8; iPixLine++)
	{
      cCharLineData = (iPixLine < pCustomChar->iCharDataLen) ? pCustomChar->pCharData[iPixLine] : 0;
      for(iPixCol = 0; iPixCol < 5; iPixCol++)
	  {
        if(!(cCharLineData & (1 << (4-iPixCol)))) continue;
      
        sRect.left = (cxChar * (pCustomChar->cCharNum & 0x7F)) + (iPixCol * 2) + 1;
        sRect.top = ((pCustomChar->cCharNum & 0x80) ? cyChar : 0) + (iPixLine * 2) + 1;
        sRect.right = sRect.left + 2;
        sRect.bottom = sRect.top + 2;
      
        FillRect(hDcTmp, &sRect, hBrushFg);
	  }
	}
  }

  DeleteObject(hBrushFg);
  DeleteObject(hBrushBk);  
  SelectObject(hDcTmp, hOldBmp);
  DeleteDC(hDcTmp);
  ReleaseDC(hwndDisplay, hDcWnd);
  
  return;
}


// ------------------------------------------------------------------------
// Function: InitDisplay
// Info    : initialisiert aktualisierung des displays
// Params  : Handle auf das Simulationsfenster, x & y Werte der Simulation
//           als Zeichen ( z.b. 20 Zeichen breit, 4 Zeilen hoch)
// Result  : keins
// ------------------------------------------------------------------------
void InitDisplay(HWND hwndDisp, int cxChar, int cyChar)
{
  char** ppText;
  tCustomLcdChar* pCustChar;

  // Speicher reservieren
  // Die Anzahl von Zeilen * der G��e eines Integerwert
  ppText = (char**)calloc(cyChar+1, sizeof(char*));
  // Den Zeiger auf diesen Adressvbereich im Fenster ablegen
  DispWnd_SetTextPtr(hwndDisp, ppText);

  // Speicher resevieren
  // Anzahl der Zeilen +1 (f�r NULL Pointer) * Gr��e eines CharPointer
  ppText = (char**)calloc(cyChar+1, sizeof(char*));
  // Den Zeiger auf diesen Adressvbereich im Fenster ablegen
  DispWnd_SetTextPtr(hwndDisp, ppText);


  // Jetzt wird das Array von Zeigern gef�llt. Das letzte Element ist ja bereits
  // 0 und wird nicht ver�ndert.
  // Jede Zeiger dieses Array zeigt auf den eigentlichen Text.

  while(cyChar--)
	  ppText[cyChar] = strdup(LCD_INIT_LINE);
  // strdup wird der Initstring �bergeben. Es reserviert den ben�tigten Speicher
  // kopiert den Text und liefert den Zeiger auf diesen Bereich zur�ck

  pCustChar = calloc(1, sizeof(tCustomLcdChar));
  DispWnd_SetCustomChar(hwndDisp, pCustChar);
  
  return;
}

/* ------------------------------------------------------------------------
 * @Function: TermDisplay
 * @Info    : stopt aktualisierung des displays
 * @Result  : keins
 * ------------------------------------------------------------------------ */
void TermDisplay(HWND hwndDisp)
{
  char** ppText;
  int iLines, iCnt;
  tCustomLcdChar* pCustChar;

  ppText = DispWnd_GetTextPtr(hwndDisp);
  for(iLines = 0; ppText[iLines]; iLines++) free(ppText[iLines]);
  free(ppText);

  pCustChar = DispWnd_GetCustomChar(hwndDisp);
  for(iCnt = 0; pCustChar[iCnt].cCharNum; iCnt++)
  {
	if(pCustChar[iCnt].pCharData) free(pCustChar[iCnt].pCharData);
  }
  free(pCustChar);
  
  return;
}
