/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2001 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgPageAbout.cpp:   About property page
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 14.11.99 - hard coded plugin name and version removed, M.Zehnder
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgPageAbout.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPageAbout property page

IMPLEMENT_DYNCREATE(CDlgPageAbout, CPropertyPage)

CDlgPageAbout::CDlgPageAbout() : CPropertyPage(CDlgPageAbout::IDD)
{
	//{{AFX_DATA_INIT(CDlgPageAbout)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CDlgPageAbout::~CDlgPageAbout()
{
}

void CDlgPageAbout::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPageAbout)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPageAbout, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgPageAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPageAbout message handlers

BOOL CDlgPageAbout::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CString csText;
  CString buffer1, buffer2;
  buffer1.LoadString(IDS_APPNAME);
  buffer2.LoadString(IDS_APPVER);

	csText.Format( "%s - %s", buffer1, buffer2);
	SetDlgItemText( IDC_PLUGIN_NAME, csText );	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
