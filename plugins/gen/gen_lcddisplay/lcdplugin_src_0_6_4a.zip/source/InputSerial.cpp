/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Serial port input driver implementation, derived from CInputLCD.
// 
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/01/12 MZ  setting input length, start- and end-characters
// 2003/02/09 MZ  extended input (default/menu/set actions)
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "InputSerial.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInputSerial::CInputSerial()
{
	m_pmapInput = &g_Config.mapInSerial;
}

CInputSerial::~CInputSerial()
{
}

BOOL CInputSerial::InitDevice()
{
	CloseDevice();

	m_bUseLCDport = g_Config.bInSerialLCDport;

	if (m_bUseLCDport) {

		// use existing COM port
		m_pcDev = g_LCD->GetSerialDevice();

		if (m_pcDev == NULL) {
			AfxMessageBox(IDS_ERR_NO_SERIAL_IN_SUPPORT);
			return FALSE;
		}

	} else {
		char szDev[20];
		wsprintf(szDev, "%s,n,8,1", g_Config.szInSerialBaud);

		m_pcDev = new CDevSerial();

		if (!m_pcDev->Open(g_Config.szInSerialPort, szDev)) {
			return FALSE;
		}
	}

	SetInputLen(g_Config.bInSerialStatic ? g_Config.byInSerialLen : 0);
	SetStartCharacter(g_Config.byInSerialStartChar);
	SetEndCharacter(g_Config.byInSerialEndChar);

	m_pcDev->SetInputDevice(this);

	m_bExit = FALSE;
	m_hThread = CreateThread(NULL, 0, ReaderThread, (LPVOID)this, 0, &m_dwThreadID);

	m_bInitialized = (m_hThread != NULL);

	return m_bInitialized;
}


BOOL CInputSerial::WriteConfig(LPCSTR lpIniFile)
{
    char string[32];
    CString csBuffer;

	wsprintf(string,"%d",g_Config.bInSerialEnabled);
    WritePrivateProfileString(SECTION_NAME,"Serial_enabled",string,lpIniFile);
	wsprintf(string,"%d",g_Config.bInSerialLCDport);
    WritePrivateProfileString(SECTION_NAME,"Serial_LCDport",string,lpIniFile);
	WritePrivateProfileString(SECTION_NAME,"Serial_port",g_Config.szInSerialPort,lpIniFile);
	WritePrivateProfileString(SECTION_NAME,"Serial_baud",g_Config.szInSerialBaud,lpIniFile);
	wsprintf(string,"%d",g_Config.byInSerialLen);
    WritePrivateProfileString(SECTION_NAME,"Serial_length",string,lpIniFile);
	wsprintf(string,"%d",g_Config.bInSerialStatic);
    WritePrivateProfileString(SECTION_NAME,"Serial_static",string,lpIniFile);
	wsprintf(string,"%d",g_Config.byInSerialStartChar);
    WritePrivateProfileString(SECTION_NAME,"Serial_start",string,lpIniFile);
	wsprintf(string,"%d",g_Config.byInSerialEndChar);
    WritePrivateProfileString(SECTION_NAME,"Serial_end",string,lpIniFile);

    CString csTemp;
    csBuffer = "";
	int i = 0;
	CString   key;
	INPUT_BTN *btn;

	for (POSITION pos = g_Config.mapInSerial.GetStartPosition(); pos != NULL; ){
		g_Config.mapInSerial.GetNextAssoc( pos, key, (void*&)btn );

        if (i++ > 0) {
            csBuffer+="|";
		}

		csTemp.Format("%s %i,%i,%i", key, acts[btn->defAction].msgNbr, acts[btn->menuAction].msgNbr, acts[btn->setAction].msgNbr );
        csBuffer+=csTemp;
	}

    WritePrivateProfileString(SECTION_NAME, "Serial_cmds", csBuffer, lpIniFile);

	return TRUE;
}

BOOL CInputSerial::ReadConfig(LPCSTR lpIniFile)
{
    char    *p;
    char    szBuffer[10000];
	CString csBtnName;

	g_Config.bInSerialEnabled = GetPrivateProfileInt(SECTION_NAME,"Serial_enabled", 0, lpIniFile);
	g_Config.bInSerialLCDport = GetPrivateProfileInt(SECTION_NAME,"Serial_LCDport", 0, lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Serial_port", "COM2", g_Config.szInSerialPort, sizeof(g_Config.szInSerialPort), lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Serial_baud", "9600", g_Config.szInSerialBaud, sizeof(g_Config.szInSerialBaud), lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Serial_commands", "", szBuffer, sizeof(szBuffer), lpIniFile);

	g_Config.byInSerialLen = GetPrivateProfileInt(SECTION_NAME,"Serial_length", 1, lpIniFile);
	g_Config.bInSerialStatic = GetPrivateProfileInt(SECTION_NAME,"Serial_static", 1, lpIniFile);
	g_Config.byInSerialStartChar = GetPrivateProfileInt(SECTION_NAME,"Serial_start", 'b', lpIniFile);
	g_Config.byInSerialEndChar = GetPrivateProfileInt(SECTION_NAME,"Serial_end", 13, lpIniFile);

	// read new cfg
	char szBtn[20];
	unsigned int defCmd, menuCmd, setCmd;
	INPUT_BTN *btn;

	GetPrivateProfileString( SECTION_NAME, "Serial_cmds", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");
    while (p != NULL)
    {
		// set to 'no action'
		defCmd = menuCmd = setCmd = acts[0].msgNbr;

		int nbr = sscanf(p, "%s %d,%d,%d", szBtn, &defCmd, &menuCmd, &setCmd);

		if (nbr > 1) {
			btn = new INPUT_BTN;
			btn->defAction = btn->menuAction = btn->setAction = 0;

			for (int i=0; i < TOTAL_ACTIONS; i++)
			{
				if (acts[i].msgNbr == defCmd)
					btn->defAction = i;
				if (acts[i].msgNbr == menuCmd)
					btn->menuAction = i;
				if (acts[i].msgNbr == setCmd)
					btn->setAction = i;
			}
			CString csKey = szBtn;
			g_Config.mapInSerial.SetAt(csKey, btn);
		}

        p = strtok(NULL, "|");
    }

	return TRUE;
}

