/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgPageConfig.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgPageConfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPageConfig property page

IMPLEMENT_DYNCREATE(CDlgPageConfig, CPropertyPage)

CDlgPageConfig::CDlgPageConfig() : CPropertyPage(CDlgPageConfig::IDD)
{
	//{{AFX_DATA_INIT(CDlgPageConfig)
	m_byWinAmpPoll = DEF_WINAMPPOLL;
	m_byLCDRefresh = DEF_LCDREFRESH;
	m_csScrollSeparator = _T("");
	m_csScrollSeparator2 = _T("");
    m_csPlaylistPathUser = _T("");
	m_bBackLight = FALSE;
	m_uiTimeout = 0;
	m_iTimeoutType = 0;
	m_bPLRecursive = FALSE;
	m_bPLSort = FALSE;
	//}}AFX_DATA_INIT
}

CDlgPageConfig::~CDlgPageConfig()
{
}

void CDlgPageConfig::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPageConfig)
	DDX_Text(pDX, IDC_WINAMP_POLL, m_byWinAmpPoll);
	DDV_MinMaxByte(pDX, m_byWinAmpPoll, 1, 99);
	DDX_Text(pDX, IDC_LCD_REFRESH, m_byLCDRefresh);
	DDV_MinMaxByte(pDX, m_byLCDRefresh, 1, 99);
	DDX_Control(pDX, IDC_SCROLL_SLIDER, m_cScrollSlider);
	DDX_Text(pDX, IDC_SCROLLSEPARATOR_EDIT, m_csScrollSeparator);
	DDV_MaxChars(pDX, m_csScrollSeparator, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_SCROLLSEPARATOR2_EDIT, m_csScrollSeparator2);
	DDV_MaxChars(pDX, m_csScrollSeparator2, MAX_STATUS_STRLEN);
	DDX_Text(pDX, IDC_PLAYLISTPATH_USER, m_csPlaylistPathUser);
	DDV_MaxChars(pDX, m_csPlaylistPathUser, MAX_PATH);
	DDX_Check(pDX, IDC_CHECK_BACKLIGHT, m_bBackLight);
	DDX_Text(pDX, IDC_TIMEOUT, m_uiTimeout);
	DDV_MinMaxUInt(pDX, m_uiTimeout, 0, 180);
	DDX_CBIndex(pDX, IDC_TIMEOUT_COMBO, m_iTimeoutType);
	DDX_Check(pDX, IDC_CHECK_PL_RECURSIVE, m_bPLRecursive);
	DDX_Check(pDX, IDC_CHECK_PL_SORT, m_bPLSort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPageConfig, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgPageConfig)
	ON_BN_CLICKED(IDC_LOAD_BTN, OnLoadBtn)
	ON_BN_CLICKED(IDC_SAVE_BTN, OnSaveBtn)
	ON_BN_CLICKED(IDC_DEF_BTN, OnDefBtn)
	ON_EN_CHANGE(IDC_LCD_REFRESH, OnSetModified)
	ON_EN_CHANGE(IDC_WINAMP_POLL, OnSetModified)
	ON_EN_CHANGE(IDC_SCROLLSEPARATOR_EDIT, OnSetModified)
	ON_EN_CHANGE(IDC_SCROLLSEPARATOR2_EDIT, OnSetModified)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPageConfig message handlers

BOOL CDlgPageConfig::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_byLCDRefresh = g_Config.byLCDRefresh;
	m_byWinAmpPoll = g_Config.byWinAmpPoll;

	m_cScrollSlider.SetRange(1, g_Config.byScrollSteps);
	m_cScrollSlider.SetPos(g_Config.byScrollSpeed);

	m_bBackLight = g_Config.bBacklight;
	m_uiTimeout = g_Config.iBacklightTimeout;
	m_iTimeoutType = g_Config.byTimeoutType;

	// FVerhamme
	m_csScrollSeparator = g_Config.szScrollSeparator;
	m_csScrollSeparator2 = g_Config.szScrollSeparator2;

    m_csPlaylistPathUser = g_Config.szPlaylistPathUser;
	m_bPLRecursive = g_Config.bPLrecursive;
	m_bPLSort = g_Config.bPLsort;

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgPageConfig::OnApply() 
{
	char *p; //FVerhamme
	short	sLight = -1;	// light off

	// MZ 2003/01/19 refresh rate changes will be reflected immediatly: 
	//               output handling is now in a thread and no longer in a Windows Timer function
	g_Config.byLCDRefresh = m_byLCDRefresh;
	g_Config.byWinAmpPoll = m_byWinAmpPoll;

	if (g_Config.byScrollSpeed != m_cScrollSlider.GetPos())
	{
		g_Config.byScrollSpeed = m_cScrollSlider.GetPos();
		if (::KillTimer( NULL, g_uiScrollTimer ))
			g_uiScrollTimer = ::SetTimer(NULL, NULL, g_Config.iScrollTimeStart + 
				(g_Config.byScrollSteps - g_Config.byScrollSpeed + 1) * g_Config.iScrollTimeStep,
				(TIMERPROC)ScrollTimerFunc);
	}

	g_Config.bBacklight = m_bBackLight;
	g_Config.iBacklightTimeout = m_uiTimeout;
	g_Config.byTimeoutType = (BYTE)m_iTimeoutType;
	if (m_bBackLight)
		sLight = (short)m_uiTimeout;
	if (g_LCD != NULL)
	{
		g_LCD->SetBacklight(sLight);
	}

	// FVerhamme
	strcpy(g_Config.szScrollSeparator, m_csScrollSeparator);
	strcpy(g_Config.szScrollSeparator2, m_csScrollSeparator2);

	// playlist path must end with a back slash
	strcpy(g_Config.szPlaylistPathUser, m_csPlaylistPathUser);
	p = g_Config.szPlaylistPathUser + lstrlen(g_Config.szPlaylistPathUser) -1;
	if( *p != '\\')
		strcat(g_Config.szPlaylistPathUser, "\\");

	g_Config.bPLrecursive = m_bPLRecursive;
	g_Config.bPLsort = m_bPLSort;
	
	return CPropertyPage::OnApply();
}

void CDlgPageConfig::OnLoadBtn() 
{
    CFileDialog fileDlg( TRUE, "ini", NULL, OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, 
		"Ini Files (*.ini)|*.ini|All Files (*.*)|*.*||" );
	
	if (fileDlg.DoModal() == IDOK)
	{
		config_read(fileDlg.GetPathName());
		g_InWinLIRC.ReadConfig(fileDlg.GetPathName());
		g_InKeyboard.ReadConfig(fileDlg.GetPathName());
		g_InWinampKeyboard.ReadConfig(fileDlg.GetPathName());
		g_InSerial.ReadConfig(fileDlg.GetPathName());

		EndDialog(IDCANCEL);
	}
}

void CDlgPageConfig::OnSaveBtn() 
{
    CFileDialog fileDlg( FALSE, "ini", NULL, OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY,
		"Ini Files (*.ini)|*.ini|All Files (*.*)|*.*||" );
	
	if (fileDlg.DoModal() == IDOK)
	{
		OnApply();

		config_write(fileDlg.GetPathName());
		g_InWinLIRC.WriteConfig(fileDlg.GetPathName());
		g_InKeyboard.WriteConfig(fileDlg.GetPathName());
		g_InWinampKeyboard.WriteConfig(fileDlg.GetPathName());
		g_InSerial.WriteConfig(fileDlg.GetPathName());
	}
}

void CDlgPageConfig::OnDefBtn() 
{
	m_byWinAmpPoll = DEF_WINAMPPOLL;
	m_byLCDRefresh = DEF_LCDREFRESH;
	m_csScrollSeparator = DEF_SCROLL_SEPARATOR;
	m_csScrollSeparator2 = DEF_SCROLL_SEPARATOR2;
	m_cScrollSlider.SetRange(1, DEF_SCROLLSTEPS);
	m_cScrollSlider.SetPos(DEF_SCROLLSPEED);
	m_csPlaylistPathUser = DEF_PLAYLISTPATHUSER;

	UpdateData(FALSE);	
}

void CDlgPageConfig::OnSetModified() 
{
	this->SetModified();	
}

