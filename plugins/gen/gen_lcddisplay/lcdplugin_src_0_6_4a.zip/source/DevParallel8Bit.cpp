/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallel8Bit44780.cpp: implementation of the CDevParallel8Bit44780 class.
//
// BASED ON THE WINAMP LPT DRIVER FROM LCDPROC (hd44780-winamp.c)
// 
// Modifications:
// [no history yet - still working on the inital working version]
// 
// Original header file:
/*
 * "Winamp" 8-bit driver module for Hitachi HD44780 based LCD displays.
 * The LCD is operated in it's 8 bit-mode to be connected to a single
 * PC parallel port.
 *
 * Copyright (c)  1999 Andrew McMeikan <andrewm@engineer.com>
 *		  modular driver 1999-2000 Benjamin Tse <blt@Comports.com>
 *
 *		  Modified July 2000 by Charles Steinkuehler for enhanced
 *		  performance and reduced CPU usage
 *		    - provided required setup time for RS valid to E high
 *		    - 1 uS call to uPause removed as it is unnecessary
 *
 *                2001 Joris Robijn <joris@robijn.net>
 *                  - Keypad support
 *
 * The connections are:
 * printer port   LCD
 * D0 (2)	  D0 (7)
 * D1 (3)	  D1 (8)
 * D2 (4)	  D2 (9)
 * D3 (5)	  D3 (10)
 * D4 (6)	  D4 (11)
 * D5 (7)	  D5 (12)
 * D6 (8)	  D6 (13)
 * D7 (9)	  D7 (14)
 * nSTRB (1)      EN (6)
 * nLF   (14)     nRW (5) (EN3 6 - LCD 3) (optional)
 * INIT  (16)     RS (4)
 * nSEL  (17)     EN2 (6 - LCD 2) (optional)
 *
 * Backlight
 * SEL  (17)	  backlight (optional, see documentation)
 *
 * Keypad connection (optional):
 * Some diodes and resistors are needed, see further documentation.
 * printer port   keypad
 * D0 (2)	  Y0
 * D1 (3)	  Y1
 * D2 (4)	  Y2
 * D3 (5)	  Y3
 * D4 (6)	  Y4
 * D5 (7)	  Y5
 * D6 (7)	  Y6
 * D7 (7)	  Y7
 * nLF    (14)    Y8
 * INIT   (16)    Y9
 * nSEL   (17)    Y10
 * nACK   (10)    X0
 * BUSY   (11)    X1
 * PAPEREND (12)  X2
 * SELIN  (13)    X3
 * nFAULT (15)    X4
 *
 * Created modular driver Dec 1999, Benjamin Tse <blt@Comports.com>
 *
 * This file is released under the GNU General Public License. Refer to the
 * COPYING file distributed with this package.
 */

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DevParallel8Bit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define EN1	STRB
#define EN2	SEL
#define EN3	LF
#define RW	LF
#define RS	INIT
#define BL	SEL

static const unsigned char EnMask[] = { EN1, EN2, EN3 };

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevParallel8Bit44780::CDevParallel8Bit44780()
{

}

CDevParallel8Bit44780::~CDevParallel8Bit44780()
{

}

BOOL CDevParallel8Bit44780::Close()
{
	// ...

	return CDevParallel::Close();
}

BOOL CDevParallel8Bit44780::Open(LPCSTR lpPort, LPCSTR lpParam)
{
	if (!CDevParallel::Open(lpPort, lpParam))
		return FALSE;

	// setup the lcd in 8 bit mode
	senddata (0, RS_INSTR, FUNCSET | IF_8BIT);
	uPause (m_delayInit);
	senddata (0, RS_INSTR, FUNCSET | IF_8BIT);
	uPause (m_delayMedium);
	senddata (0, RS_INSTR, FUNCSET | IF_8BIT | TWOLINE | SMALLCHAR);
	uPause (m_delayShort);

	common_init();

	if (have_keypad) {
		// Remember which input lines are stuck
		stuckinputs = readkeypad (0);
	}

	m_bOpen = TRUE;

	return TRUE;
}


void CDevParallel8Bit44780::senddata (unsigned char displayID, unsigned char flags, unsigned char ch)
{
	unsigned char enableLines = 0, portControl;

	if (flags == RS_DATA)
		portControl = RS;
	else
		portControl = 0;

	portControl |= backlight_bit;

	if (displayID == 0)
		enableLines = EnMask[0] | EnMask[1] | ((extIF) ? EnMask[2] : 0);
	else
		enableLines = EnMask[displayID - 1];

	// 40 nS setup time for RS valid to EN high, so set RS
	port_out (m_iPort + 2, portControl ^ OUTMASK);

	// Output the actual data
	port_out (m_iPort, ch);

	if (delayBus)
		uPause (delayBus);

	// then set EN high
	port_out (m_iPort + 2, (enableLines|portControl) ^ OUTMASK);

	if (delayBus) 
		uPause (delayBus);

	// 80 nS setup from valid data to EN low will be met without any delay
	// unless you are running a REALLY FAST ISA bus (like 75 MHZ!)
	// 230 nS minimum E high time provided by ISA bus delays as well...

	// ABOVE TEXT ignored now, using delays if delayBus is specified

	// Set EN low and we're done...
	port_out (m_iPort + 2, portControl ^ OUTMASK);

	// 10 nS data hold time provided by the length of ISA write for EN
}

void CDevParallel8Bit44780::backlight (unsigned char state)
{
	if (have_backlight) {
		backlight_bit = (state?0:nSEL);

		port_out (m_iPort + 2, backlight_bit ^ OUTMASK);
	}
}

unsigned char CDevParallel8Bit44780::readkeypad (unsigned int YData)
{
	unsigned char readval;

	// 8 bits output
	// Convert the positive logic to the negative logic on the LPT port
	port_out (m_iPort, ~YData & 0x00FF );

	if (delayBus) 
		uPause (delayBus);

	// Read inputs
	readval = ~ port_in (m_iPort + 1) ^ INMASK;

	// Set output back to idle state for backlight
	port_out (m_iPort + 2, backlight_bit ^ OUTMASK );

	// And convert value back.
	return ( (readval >> 4 & 0x03) | (readval >> 5 & 0x04) | (readval >> 3 & 0x08) | (readval << 1 & 0x10) ) & ~stuckinputs;
}
