#if !defined(AFX_DLGINPUTWINLIRC_H__7F331E05_C006_4F57_A26E_F4F807DEA7AA__INCLUDED_)
#define AFX_DLGINPUTWINLIRC_H__7F331E05_C006_4F57_A26E_F4F807DEA7AA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInputWinLIRC.h : header file
//

#include "DlgInput.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgInputWinLIRC dialog

class CDlgInputWinLIRC : public CDlgInput
{
	DECLARE_DYNCREATE(CDlgInputWinLIRC)

// Construction
public:
	CDlgInputWinLIRC();
	~CDlgInputWinLIRC();

// Dialog Data
	//{{AFX_DATA(CDlgInputWinLIRC)
	enum { IDD = IDD_INPUT_WINLIRC };
	CString	m_csState;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDlgInputWinLIRC)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDlgInputWinLIRC)
	virtual BOOL OnInitDialog();
	afx_msg void OnAdd();
	afx_msg void OnDelete();
	afx_msg void OnConnect();
	afx_msg void OnDisconnect();
	afx_msg void OnBtNEdit();
	afx_msg void OnCfg();
	afx_msg void OnDblclkListWinlirc(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINPUTWINLIRC_H__7F331E05_C006_4F57_A26E_F4F807DEA7AA__INCLUDED_)
