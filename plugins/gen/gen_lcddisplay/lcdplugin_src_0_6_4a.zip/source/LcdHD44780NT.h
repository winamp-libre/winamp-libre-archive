// LcdHD44780NT.h: interface for the CLcdHD44780NT class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LCDHD44780NT_H__6D62CFE0_6633_4C40_BB9A_8A63E72DFCD1__INCLUDED_)
#define AFX_LCDHD44780NT_H__6D62CFE0_6633_4C40_BB9A_8A63E72DFCD1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LcdHD44780.h"

class CLcdHD44780NT : public CLcdHD44780  
{
protected:
	typedef UCHAR (CALLBACK *READCHAR)(ULONG);
	typedef void  (CALLBACK *WRITECHAR)(ULONG, UCHAR);


	READCHAR    m_lpfnReadChar;
	WRITECHAR	m_lpfnWriteChar;

	HINSTANCE	m_hDriver; 

public:
	CLcdHD44780NT();
	virtual ~CLcdHD44780NT();
	virtual BOOL  Open();
	virtual void Close();

};

#endif // !defined(AFX_LCDHD44780NT_H__6D62CFE0_6633_4C40_BB9A_8A63E72DFCD1__INCLUDED_)
