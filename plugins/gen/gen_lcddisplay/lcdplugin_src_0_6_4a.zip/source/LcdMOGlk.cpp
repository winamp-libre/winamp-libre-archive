// LcdMOGlk.cpp: implementation of the CLcdMOGlk class.
//
// 2003/07/13 MZ  custom character map added 
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "LcdMOGlk.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define MO_GLK_SECTION	"Matrix Orbital GLK"
#define MO_GLK_CHARMAP  "MO_GLK_CHARMAP"

#define MAX_CUSTOM_CHARS		8


CCfgMOGlk	 g_MOGlkCfg;

CCfgMOGlk::CCfgMOGlk()
{
	Load(g_szIniFile);
}

CCfgMOGlk::~CCfgMOGlk()
{
	Save(g_szIniFile);
}

void CCfgMOGlk::Load(LPCSTR lpIniFile)
{
	GetPrivateProfileString( MO_GLK_SECTION, "ComPort", DEF_COMPORT, szComPort, MAX_COMPORT_STRLEN, lpIniFile);
	GetPrivateProfileString( MO_GLK_SECTION, "BaudRate", DEF_BAUDRATE, szBaudRate, MAX_BAUDRATE_STRLEN, lpIniFile);
	bBlink =	   GetPrivateProfileInt(MO_GLK_SECTION,"SetBlink",0,lpIniFile); 
	bScroll =	   GetPrivateProfileInt(MO_GLK_SECTION,"SetScroll",0,lpIniFile); 
	bShowCursor = GetPrivateProfileInt(MO_GLK_SECTION,"Cursor",0,lpIniFile); 
	bWrap =	   GetPrivateProfileInt(MO_GLK_SECTION,"Wrap",1,lpIniFile); 	
	iCols =       GetPrivateProfileInt(MO_GLK_SECTION,"Columns",20,lpIniFile); 			 
	iRows =	   GetPrivateProfileInt(MO_GLK_SECTION,"Rows",4,lpIniFile); 
	byContrast = (BYTE)GetPrivateProfileInt(MO_GLK_SECTION,"Contrast", DEF_CONTRAST,lpIniFile); 
	byBrightness = (BYTE)GetPrivateProfileInt(MO_GLK_SECTION,"Brightness", DEF_BRIGHTNESS,lpIniFile); 
	bLCD = GetPrivateProfileInt(MO_GLK_SECTION,"LCD",1,lpIniFile);
	BuildCharMap(MO_GLK_CHARMAP, lpIniFile, charMap);
}

void CCfgMOGlk::Save(LPCSTR lpIniFile)
{
	char string[32];

	WritePrivateProfileString( MO_GLK_SECTION, "ComPort", szComPort, lpIniFile);
	WritePrivateProfileString( MO_GLK_SECTION, "BaudRate", szBaudRate, lpIniFile);
	wsprintf(string,"%d",bBlink);
	WritePrivateProfileString(MO_GLK_SECTION,"SetBlink",string,lpIniFile);
	wsprintf(string,"%d",bScroll);
	WritePrivateProfileString(MO_GLK_SECTION,"SetScroll",string,lpIniFile);
	wsprintf(string,"%d",bShowCursor);
	WritePrivateProfileString(MO_GLK_SECTION,"Cursor",string,lpIniFile);
	wsprintf(string,"%d",bWrap);
	WritePrivateProfileString(MO_GLK_SECTION,"Wrap",string,lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(MO_GLK_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(MO_GLK_SECTION,"Rows",string,lpIniFile);
	wsprintf(string,"%d",byContrast);
	WritePrivateProfileString(MO_GLK_SECTION,"Contrast",string,lpIniFile);
	wsprintf(string,"%d",byBrightness);
	WritePrivateProfileString(MO_GLK_SECTION,"Brightness",string,lpIniFile);
	wsprintf(string,"%d",bLCD);
	WritePrivateProfileString(MO_GLK_SECTION,"LCD",string,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdMOGlk::CLcdMOGlk()
{

}

CLcdMOGlk::~CLcdMOGlk()
{

}


/******************************************************************************
Function : Open
Purpose  : Opens the comport and initilizes the display
Parameters : -
Returns : TRUE if successful, otherwise FALSE
Author  : Markus Zehnder	
******************************************************************************/
BOOL  CLcdMOGlk::Open()
{
	char szDef[20];

	sprintf(szDef, "%d,n,8,1", atoi(g_MOGlkCfg.szBaudRate) );

	if (!m_pcDev->Open(g_MOGlkCfg.szComPort, szDef))
	{
		Close();
		return FALSE;
	}		

	// Set baudrate
	WriteCommand( '9' );
	WriteData( 0x95 );

	// Set current font
	WriteCommand( '1' );
	WriteData( 1 );

	// Set font metrics
	WriteCommand( '2' );
	WriteData( 1 );	// left margin
	WriteData( 1 ); // top margin
	WriteData( 1 ); // x space
	WriteData( 1 ); // y space
	WriteData( 32 ); // scroll row


	Clear();
	SetBlink( g_MOGlkCfg.bBlink );
	Cursor( g_MOGlkCfg.bShowCursor );
	SetLineWrap( g_MOGlkCfg.bWrap );
	SetScroll( g_MOGlkCfg.bScroll );

	if (g_MOGlkCfg.bLCD)
		SetContrast(g_MOGlkCfg.byContrast);
	else
		SetBrightness(g_MOGlkCfg.byBrightness);

	m_charMap = g_MOGlkCfg.charMap;

	return TRUE;
}



int	CLcdMOGlk::GetRows()
{
	return g_MOGlkCfg.iRows;
}

int	CLcdMOGlk::GetColumns()
{
	return g_MOGlkCfg.iCols;
}

void  CLcdMOGlk::Write(LPCSTR lpText)
{
	CString csText = lpText;
	ConvertTextToLCDCharset(csText);
	LPTSTR lpTxt = (LPTSTR)(LPCTSTR)csText;

	// additional safty check...
	for (char *p = lpTxt; *p != '\0'; p++) {
		if (*p == (char)0xFE)
			*p = '?';
	}

	m_pcDev->WriteData(lpText);
}

void  CLcdMOGlk::SetBlink(BOOL bOn)
{
	// not supported
}

void CLcdMOGlk::SetBrightness(short nLevel)
{
	// not supported
}

void  CLcdMOGlk::Cursor(BOOL bOn)
{
}

void  CLcdMOGlk::InitHorizontalBar()
{
}

void  CLcdMOGlk::HBar(short nCol, short nRow, short nDir, short nLen)
{
	// not yet implemented
}

void  CLcdMOGlk::InitVerticalBar()
{
}

void  CLcdMOGlk::VBar(short nCol, short nLength)
{
	// not yet implemented
}

void  CLcdMOGlk::InitLargeDigit()
{
}

void  CLcdMOGlk::LargeDigit(short nCol, short nNumber)
{
}


