// TreeCtrlSer.cpp : implementation file
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "TreeCtrlSer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreeCtrlSer

CTreeCtrlSer::CTreeCtrlSer()
{
}

CTreeCtrlSer::~CTreeCtrlSer()
{
}


BEGIN_MESSAGE_MAP(CTreeCtrlSer, CTreeCtrl)
	//{{AFX_MSG_MAP(CTreeCtrlSer)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeCtrlSer message handlers

void CTreeCtrlSer::Serialize(CArchive& ar) 
{
	if (ar.IsStoring())
	{	
		CString	tmp;
		// storing code
		HTREEITEM hti = GetRootItem();
		while( hti )
		{
			int indent = GetIndentLevel( hti );
			while( indent-- )
				ar.WriteString( "\t" );
			ar.WriteString( GetItemText( hti ) + "\r\n");
			tmp.Format("%d\r\n", GetItemData( hti ));
			ar.WriteString( tmp.GetBuffer(1) );
			tmp.ReleaseBuffer();
			hti = GetNextItem( hti );
		}
	}
	else
	{
		// loading code
		CString sLine;
		CString sLine2;
		if( !ar.ReadString( sLine ) )
			return;

		HTREEITEM hti = NULL;
		int indent, baseindent = 0;
		while( sLine[baseindent] == '\t' )
			baseindent++;
		do
		{
			ar.ReadString(sLine2);
			if( sLine.GetLength() == 0 )
				continue;
			for( indent = 0; sLine[indent] == '\t'; indent++ )
				;		// We don't need a body
			sLine = sLine.Right( sLine.GetLength() - indent );
			indent -= baseindent;

			HTREEITEM parent;
			int previndent = GetIndentLevel( hti );
			if( indent ==  previndent)
				parent = GetParentItem( hti );
			else if( indent > previndent )
				parent = hti;
			else
			{
				int nLevelsUp = previndent - indent;
				parent = GetParentItem( hti );
				while( nLevelsUp-- )
					parent = GetParentItem( parent );
			}
			hti = InsertItem( sLine, parent ? parent : TVI_ROOT, TVI_LAST );
//			if (hti == NULL)
//				::MessageBox(0, "FAILED !!", "FAILED !!", 0);
			SetItemData(hti, atoi(sLine2));
		} while (ar.ReadString(sLine));
	}
}

int CTreeCtrlSer::GetIndentLevel(HTREEITEM hItem)
{
	int iIndent = 0;

	while( (hItem = GetParentItem( hItem )) != NULL )
		iIndent++;
	return iIndent;

}

HTREEITEM CTreeCtrlSer::GetNextItem(HTREEITEM hItem)
{
	HTREEITEM	hti;

	if( ItemHasChildren( hItem ) )
		return GetChildItem( hItem );		// return first child
	else{
		// return next sibling item
		// Go up the tree to find a parent's sibling if needed.
		while( (hti = GetNextSiblingItem( hItem )) == NULL ){
			if( (hItem = GetParentItem( hItem ) ) == NULL )
				return NULL;
		}
	}
	return hti;

}
void CTreeCtrlSer::SelectAll(HTREEITEM hItem, UINT uSelState)
{
   while (hItem) {
      SelectAll(GetChildItem(hItem), uSelState);
      SetItemState(hItem, uSelState, TVIS_SELECTED);
      hItem = GetNextSiblingItem(hItem);
   }
}

void CTreeCtrlSer::SelectAll(UINT uSelState) 
{
      SelectAll(GetRootItem(), uSelState);
}

afx_msg void CTreeCtrlSer::OnLButtonDown( UINT nFlags, CPoint point )
{
	CTreeCtrl::OnLButtonDown( nFlags, point );
}