/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Dlg for adding a new input key for the keyboard input driver.
// Custom implementation with keyboard hook function, derived from CDlgInputAdd
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/02/09 MZ  extended input (default/menu/set actions), taken from TiTi's T5 version
// 2003/06/06 MZ  keyboard must be unhooked when user cancels dlg -> OnCancel() added
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgInputAddKeyboard.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

static HHOOK       hHook;

// @HACK !
static CDlgInputAddKeyboard *pDlg;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDlgInputAddKeyboard::CDlgInputAddKeyboard(CDlgInput *pcDlgCfg, CWnd* pParent /*=NULL*/, 
										   bool bWinampKeyboardMap /*=false*/ )
	: CDlgInputAdd(pcDlgCfg, pParent)
{
	pDlg = this;
	m_iKeyCode = -1;
	m_bWinampKeyboardMap = bWinampKeyboardMap;

    hHook = SetWindowsHookEx(WH_KEYBOARD, CDlgInputAddKeyboard::KeyboardHook, 0, GetCurrentThreadId());
}

CDlgInputAddKeyboard::~CDlgInputAddKeyboard()
{
}

BEGIN_MESSAGE_MAP(CDlgInputAddKeyboard, CDialog)
	//{{AFX_MSG_MAP(CDlgInputAddKeyboard)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



BOOL CDlgInputAddKeyboard::OnInitDialog() 
{
	CDlgInputAdd::OnInitDialog();

	if (m_iKeyCode != 0)
	{
		KB_KEY* pe;
		int idx;

		pe = m_bWinampKeyboardMap ? 
			 (struct KB_KEY*)g_Config.mapWAKBcfg[m_iKeyCode] :
			 (struct KB_KEY*)g_Config.mapKBcfg[m_iKeyCode];
		if (pe)
		{
			TCHAR	szBuf[30];
			GetKeyNameText(pe->lParam, szBuf, 30);

			pDlg->m_id = szBuf;
			m_lParam = pe->lParam;
			idx = m_act.FindString(0, acts[pe->action].name);
			m_act.SetCurSel(idx);
		}
		pe = m_bWinampKeyboardMap ? 
			 (struct KB_KEY*)g_Config.mapWAKBcfg_menu[m_iKeyCode] :
			 (struct KB_KEY*)g_Config.mapKBcfg_menu[m_iKeyCode];
		if (pe)
		{
			m_lParam = pe->lParam;
			idx = m_act_menu.FindString(0, acts[pe->action].name);
			m_act_menu.SetCurSel(idx);
		}
		pe = m_bWinampKeyboardMap ?  
			(struct KB_KEY*)g_Config.mapWAKBcfg_set[m_iKeyCode] :
			(struct KB_KEY*)g_Config.mapKBcfg_set[m_iKeyCode];
		if (pe)
		{
			m_lParam = pe->lParam;
			idx = m_act_set.FindString(0, acts[pe->action].name);
			m_act_set.SetCurSel(idx);
		}
		UpdateData(FALSE);
	}

	GetDlgItem(IDC_ID)->EnableWindow(FALSE);

	return FALSE;
}

void CDlgInputAddKeyboard::OnCancel() 
{
    if (hHook)
        UnhookWindowsHookEx(hHook);

	CDialog::OnCancel();
}

void CDlgInputAddKeyboard::OnOK() 
{
	if(m_id.IsEmpty())
	{
		MessageBox("You need to press a key.");
		return;
	}
	
	if (m_act.GetCurSel() == CB_ERR || m_act_menu.GetCurSel() == CB_ERR || m_act_set.GetCurSel() == CB_ERR)
	{
		MessageBox("You need to select all 3 actions.");
		return;
	}

	KB_KEY* pe;
	int act;

	act = m_act.GetItemData(m_act.GetCurSel());
	pe = new KB_KEY;
	pe->action = act;
	pe->lParam = m_lParam;
	if( m_bWinampKeyboardMap )
		g_Config.mapWAKBcfg.SetAt(m_iKeyCode, pe);
	else
		g_Config.mapKBcfg.SetAt(m_iKeyCode, pe);


	act = m_act_menu.GetItemData(m_act_menu.GetCurSel());
	pe = new KB_KEY;
	pe->action = act;
	pe->lParam = m_lParam;
	if( m_bWinampKeyboardMap )
		g_Config.mapWAKBcfg_menu.SetAt(m_iKeyCode, pe);
	else
		g_Config.mapKBcfg_menu.SetAt(m_iKeyCode, pe);

	act = m_act_set.GetItemData(m_act_set.GetCurSel());
	pe = new KB_KEY;
	pe->action = act;
	pe->lParam = m_lParam;
	if( m_bWinampKeyboardMap )
		g_Config.mapWAKBcfg_set.SetAt(m_iKeyCode, pe);
	else
		g_Config.mapKBcfg_set.SetAt(m_iKeyCode, pe);
	
	pDlg = NULL;

    if (hHook)
        UnhookWindowsHookEx(hHook);

	CDialog::OnOK();
}

LRESULT CALLBACK CDlgInputAddKeyboard::KeyboardHook(int code, WPARAM wParam, LPARAM lParam)
{
  if(code == HC_ACTION && !(0x80000000 & lParam))
  {
	  TCHAR	szBuf[30];
	  GetKeyNameText(lParam, szBuf, 30);

	  if (pDlg != NULL)
	  {
		pDlg->m_id = szBuf;
		pDlg->m_iKeyCode = wParam;
		pDlg->m_lParam = lParam;
		pDlg->UpdateData(FALSE);
	  }
	  return 1;// 'eat' the pressed key...  
  } else {
	  return CallNextHookEx(hHook, code, wParam, lParam);	
  }
}
