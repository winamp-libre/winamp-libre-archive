// DevParallelNoritake.h: interface for the CDevParallelNoritake class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEVPARALLELNORITAKE_H__9432F006_B283_4603_9E4D_71830F3EA6EE__INCLUDED_)
#define AFX_DEVPARALLELNORITAKE_H__9432F006_B283_4603_9E4D_71830F3EA6EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DevParallel.h"

class CDevParallelNoritake : public CDevParallel
{
public:
	CDevParallelNoritake();
	virtual ~CDevParallelNoritake();

	virtual unsigned char ReadData();
	virtual int WriteData(unsigned char Data);
	virtual int WriteCommand(unsigned char Command);

	// custom (overriden) implementations of the base driver
	virtual BOOL Open(LPCSTR lpPort, LPCSTR lpParam);

protected:
	virtual int  Init();

	// methods each parallel driver has to implement:
	virtual unsigned char readkeypad (unsigned int YData) { return 0; };	// no keypad!

};

#endif // !defined(AFX_DEVPARALLELNORITAKE_H__9432F006_B283_4603_9E4D_71830F3EA6EE__INCLUDED_)
