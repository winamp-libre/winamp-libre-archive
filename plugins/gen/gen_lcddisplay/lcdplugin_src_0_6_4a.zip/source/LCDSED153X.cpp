/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2002 TSchirme. All Rights Reserved.
//  tobias.schirmer@foni.net
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
//////////////////////////////////////////////////////////////////////
// Modifications:
//  - 2002/06/08 MZ  Renamed font file 'font.h' to 'LcdSED153XFont.h'
// 2003/07/13 MZ  custom character map added 
//
/////////////////////////////////////////////////////////////////////////////
// LCDSED153X.cpp: implementation of the CCfgSED class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "LCDSED153X.h"

#include "LcdSED153XFont.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define SED_SECTION	"SED153x"
#define SED_CHARMAP "SED153x_CHARMAP"
#define MAX_CUSTOM_CHARS		7

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCfgSED	 g_SEDCfg;

CCfgSED::CCfgSED()
{
	Load(g_szIniFile);
}

CCfgSED::~CCfgSED()
{
	Save(g_szIniFile);
}

void CCfgSED::Load(LPCSTR lpIniFile)
{
	iLPTPort = (short)GetPrivateProfileInt(SED_SECTION,"LPTPort",DEF_LPTPORT_SED,lpIniFile); 
	byContrast = (BYTE)GetPrivateProfileInt(SED_SECTION,"Contrast", DEF_CONTRAST_SED,lpIniFile); 
	BuildCharMap(SED_CHARMAP, lpIniFile, charMap);
}

void CCfgSED::Save(LPCSTR lpIniFile)
{
	char string[32];

	wsprintf(string,"%d",iLPTPort);
	WritePrivateProfileString( SED_SECTION, "LPTPort", string, lpIniFile);
	wsprintf(string,"%d",byContrast);
	WritePrivateProfileString(SED_SECTION,"Contrast",string,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define HANDLE_OPEN  1
#define HANDLE_CLOSE 0

CLcdSED153X::CLcdSED153X()
{
	// check if we're running under NT
	OSVERSIONINFO versionInfo;
	versionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	::GetVersionEx(&versionInfo);
	m_bWinNT = (versionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT);

	m_hLPTPort  = HANDLE_CLOSE;
	g_SEDCfg.iBacklight = 1;
	m_act_col = 1;
	m_act_row = 1;

	m_hDriver = NULL;
}

CLcdSED153X::~CLcdSED153X()
{
	Close();
}

BOOL  CLcdSED153X::Open()
{
	m_hLPTPort = HANDLE_OPEN;

	if (m_bWinNT == TRUE)
	{
		// load DriverLINX Port I/O Driver
		m_hDriver = LoadLibrary("dlportio.dll");

		if (m_hDriver == NULL)
		{
			MessageBox(NULL,"dlportio.dll: driver load failed !","LCDSED153X WinNT support",MB_OK);
			return FALSE;
		}

		
		m_lpfnWriteChar = (WRITECHAR)GetProcAddress(m_hDriver, "DlPortWritePortUchar");

		if (m_lpfnWriteChar == NULL)
		{
			FreeLibrary(m_hDriver);
			m_hDriver = NULL;
			MessageBox(NULL,"dlportio.dll: m_lpfnWriteChar not mapped!","LCDSED153X WinNT support",MB_OK);
			return FALSE;
		}
		// ok, driver loaded, go on...
	}


	Clear();
	InitDisplay();
	SetContrast(g_SEDCfg.byContrast);

	m_charMap = g_SEDCfg.charMap;

	return TRUE;
}

void  CLcdSED153X::Close()
{
	if (IsOpen()) {
		LPTWrite(0);			// RESET aktiv, Display off

		if (m_hDriver != NULL)
			FreeLibrary(m_hDriver);

		m_hDriver = NULL;
		m_hLPTPort  = HANDLE_CLOSE;
	}
}

BOOL  CLcdSED153X::IsOpen()
{
	return (m_hLPTPort != HANDLE_CLOSE);
}

void  CLcdSED153X::Clear()
{
	ClearSEDBitmap();
}


void CLcdSED153X::LPTWrite(unsigned char data)
// ein Byte ins Datenregister des gew�hlten Druckerports schreiben
{
	unsigned short adr;
	unsigned char bdata;

	adr = g_SEDCfg.iLPTPort;
	bdata = (unsigned char)(data & 0xff);

	if (m_bWinNT == FALSE)
	{
		// Win9x conmpatible IO with asm
		__asm
		{
			mov dx,adr
			mov al,bdata
			out dx,al
		}
	}
	else
	{
		// WinNT compatible IO with dlportio.dll
		if (m_hDriver != NULL)
			(*m_lpfnWriteChar)(adr, bdata);
	}

}

void CLcdSED153X::WriteSED(unsigned char adr, unsigned char data)
// ein Byte seriell in Steuer- oder Datenregister des SED1531 schreiben
{
	unsigned char zae;
	unsigned char td;
	// helper variables
	unsigned char cRES      = 32; // -RESET
	unsigned char cNCS      = 16; // -CS
	unsigned char cCS     = 8;  // CS
	unsigned char cA0     = 4;  // A0
	unsigned char cSCL      = 2;  // SCL
	unsigned char cSI     = 1;  // SI
	unsigned char cBACKLIGHT  = 128;// Hintergrundbeleuchtung an



  if(g_SEDCfg.iBacklight== 1)
  {
    td = (cRES | cBACKLIGHT); // Reset inaktiv und Backlight an
  }
  else
  {
    td = cRES; // Reset inaktiv und Backlight aus
  }
  
  td = td | cCS; // CS=1 und /CS=0 => SED1531 ausgew�hlt
  if (adr>0)
    td = td | cA0; // A0

  // Datenbits rausschieben, MSB zuerst
  for (zae=0;zae <=7;zae++)
  {
    if ((data & 0x80) !=0)
    {
      td = td | cSI;
    }
    else
    {
      td = td & ~cSI;
    }
    LPTWrite(td);
    LPTWrite(td | cSCL); // Takt ausgeben
    LPTWrite(td);
    // Daten weiterschieben
    data = data << 1;
  }
  // CS zur�cknehmen
  td = td & (~cCS)| cNCS;
  LPTWrite(td);
}

void CLcdSED153X::WriteSEDControl(unsigned char data)
// ein Byte ins Steuerregister des SED1531 schreiben
{
  WriteSED(0,data);
}

void CLcdSED153X::WriteSEDCustomData(unsigned char data)
{
// ein Byte ins Datenregister des SED1531 schreiben
	int column;

    for (column = 0;column <= 5;column++)
    {
	    WriteSED(1,custom_font6x8[(data * 6) + column]);
    }
}

void CLcdSED153X::WriteSEDData(unsigned char data)
{
// ein Byte ins Datenregister des SED1531 schreiben
	int column;

    for (column = 0;column <= 5;column++)
    {
	    WriteSED(1,font6x8[(data * 6) + column]);
    }
}

void  CLcdSED153X::InitDisplay()
{
	unsigned char cRES      = 32; // -RESET

	LPTWrite(0);			// RESET aktiv
	LPTWrite(cRES);			// RESET inaktiv
	WriteSEDControl(0x40);	// Start Display Line = 0
	WriteSEDControl(0xA1);	// ADC = invers (gespiegelte Anzeigerichtung)
	WriteSEDControl(0xA2);	// LCD-Bias = 1/6
	WriteSEDControl(0x2F);	// LCD-Spannungserzeugung/Regelung ein

	WriteSEDControl(0x80 | g_SEDCfg.byContrast); // Contrast

	WriteSEDControl(0xA4);	// Displaytest aus, damit nicht irgendein StandBy-Mode aktiviert wird
	WriteSEDControl(0xAF);	// Display EIN
	ClearSEDBitmap();
}

void CLcdSED153X::ClearSEDBitmap(void)
{
  // Das angezeigte Bild �bertragen
  int page,column;

  //Das Display hat einen Kernbereich aus
  //115x54 Pixeln = Column 0..114 und Page 0..5/6
  //oben und unten einen Rand aus jeweils 4 Zeilen (Page 6/7)
  //links und rechts einen Rand aus je 3 Spalten
  //= Column 115-120, wobei die ersten und letzten
  //beiden Spalten doppelt breit angezeigt werden
  for(page=0;page <=7;page++)
  {
    // Seitenadresse w�hlen
    WriteSEDControl(0xB0 | page);
    // Spaltenadresse = 0 (ganz links)
    WriteSEDControl(0x10);
    WriteSEDControl(0x00);
    // Daten eine Page ausgeben

    // Kernbereich
    for (column=3;column <= 117;column++)
    {
      WriteSEDData(0x00);
    }

    // Linker Rand
    for (column=0;column <= 2;column++)
    {
      WriteSEDData(0x00);
    }

    // Rechter Rand
    for (column=118;column <= 120;column++)
    {
      WriteSEDData(0x00);
    }
  }
}

void  CLcdSED153X::SetContrast(short nLevel)
{
	if (nLevel < 0)
		nLevel = 0;

	if (nLevel > 31)
		nLevel = 31;
	
	//nLevel = (nLevel & 0x1f);

	WriteSEDControl(0x80 | nLevel); // Contrast set to 0xF

	m_nContrast = nLevel;
}

short CLcdSED153X::GetContrast()
{
	return m_nContrast;
}

long CLcdSED153X::GetLastError()
{
	return m_lLastError;
}

int	CLcdSED153X::GetRows()	
{
	return g_SEDCfg.iRows;
}

int	CLcdSED153X::GetColumns()
{
	return g_SEDCfg.iCols;
}

short CLcdSED153X::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

void  CLcdSED153X::Home()
{
	SetPosition( 1,1 );
}

void  CLcdSED153X::SetPosition(short nCol, short nRow)
{
	int x;
	
	if (nCol < 1)
		nCol = 1;
	if (nRow < 1)
		nRow = 1;
	
	m_act_col = nCol;
	m_act_row = nRow;


    x = (nCol-1)*6;
    
    // x-start position higher nibble and lower nibble
    WriteSEDControl(0x10|((x & 0xf0)>>4));
    WriteSEDControl(0x00| (x & 0x0f)   );

    // y-start position (page number 0..7)
    WriteSEDControl(0xB0|nRow-1);
}


void  CLcdSED153X::Write(LPCSTR lpText)
{
	// writes text to the display

	if (m_hLPTPort == HANDLE_CLOSE)
		return;

	try
	{
		static CString csText;
		TCHAR lpText2[30];
		int index;

		csText = lpText;
		ConvertTextToLCDCharset(csText);
		
		lstrcpy(lpText2,csText);
		
		index = 0;
		while (lpText2[index]!='\0')
		{
			if( (lpText2[index] == 10)||
				(lpText2[index] == 13) )
			{
				// new line char
				m_act_col = 0;
				m_act_row ++;
				SetPosition(m_act_col,m_act_row);
				if( (lpText2[index+1] == 10)||
					(lpText2[index+1] == 13) )
				{
					index++;
				}
			}
			else if( (lpText2[index] >= 1)&&
					 (lpText2[index] <= 8) )
			{
				// custom char's
				WriteSEDCustomData(lpText2[index]);
			}
			else
			{
				// fixed charset
				WriteSEDData(lpText2[index]);
			}
			index++;
		}

	}
	catch(...)
	{
		#ifdef _DEBUG
			MessageBeep(-1);
		#endif
	}
}

void CLcdSED153X::WriteData(BYTE byData)
{
	// writes control bytes to the display

	if (m_hLPTPort == HANDLE_CLOSE)
		return;

	try
	{
		WriteSEDControl(byData);
	}
	catch(...)
	{
		#ifdef _DEBUG
			MessageBeep(-1);
		#endif
	}
}

// quick & dirty implemented functions below this line
//
// ToDo:



BOOL  CLcdSED153X::CreateCustomChar(short nNumber, CCustomChar &cChar)
{
//	int i,j,k;

	if (nNumber > MAX_CUSTOM_CHARS)	
		return FALSE;

	// cCharBit = i
	// customFontBit = j

	// preset to zero
/*
// forget it for now ...
	for (j=0;j<=7;j++)
	{
		custom_font6x8[(nNumber*6) + j] = 0;
	}

	// convert char
 	for (i=0;i <=5;i++)
	{
		for (j=0;j<=7;j++)
		{
			k = (nNumber*6) + j;

			if (1==(cChar.m_byarrData[5-i]&&(1<<i)))
				custom_font6x8[k] |= (1<<(7-j));	// add bit
			else
				custom_font6x8[k] &= ~(1<<(7-j)); // remove bit
		}
	}


*/
	return TRUE;
}

LPCTSTR CLcdSED153X::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( "%c1", ch );
	ch[0] = (char)2;
	csText.Replace( "%c2", ch );
	ch[0] = (char)3;
	csText.Replace( "%c3", ch );
	ch[0] = (char)4;
	csText.Replace( "%c4", ch );
	ch[0] = (char)5;
	csText.Replace( "%c5", ch );
	ch[0] = (char)6;
	csText.Replace( "%c6", ch );
	ch[0] = (char)7;
	csText.Replace( "%c7", ch );
	ch[0] = (char)8;
	csText.Replace( "%c8", ch );
	ch[0] = (char)9;
	csText.Replace( "%c9", ch );
	ch[0] = (char)10;
	csText.Replace( "%c10", ch );

	return csText;
}

LPCTSTR CLcdSED153X::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( ch, "%c1" );
	ch[0] = (char)2;
	csText.Replace( ch, "%c2" );
	ch[0] = (char)3;
	csText.Replace( ch, "%c3" );
	ch[0] = (char)4;
	csText.Replace( ch, "%c4" );
	ch[0] = (char)5;
	csText.Replace( ch, "%c5" );
	ch[0] = (char)6;
	csText.Replace( ch, "%c6" );
	ch[0] = (char)7;
	csText.Replace( ch, "%c7" );
	ch[0] = (char)8;
	csText.Replace( ch, "%c8" );
	ch[0] = (char)9;
	csText.Replace( ch, "%c9" );
	ch[0] = (char)10;
	csText.Replace( ch, "%c10" );

	return csText;
}

// unimplemented function below this line
//
// ToDo: ...add implementation


void  CLcdSED153X::SetScroll(BOOL bOn)
{
	// not yet implemented
}

BOOL  CLcdSED153X::GetScroll()
{
	return FALSE;
}


BOOL  CLcdSED153X::GetLineWrap()
{
	return FALSE;
}

void  CLcdSED153X::SetLineWrap(BOOL bOn)
{
	// not yet implemented
}

void  CLcdSED153X::InitLargeDigit()
{
	// not yet implemented
}

void  CLcdSED153X::LargeDigit(short nCol, short nNumber)
{
	// not yet implemented
}

void  CLcdSED153X::InitHorizontalBar()
{
	// not yet implemented
}

void  CLcdSED153X::HBar(short nCol, short nRow, short nDir, short nLen)
{
	// not yet implemented
}

void  CLcdSED153X::InitVerticalBar()
{
	// not yet implemented
}
void  CLcdSED153X::VBar(short nCol, short nLength)
{
	// not yet implemented
}

void  CLcdSED153X::Cursor(BOOL bOn)
{
	// not yet implemented
}

BOOL  CLcdSED153X::IsCursorOn()
{
	return FALSE;
}

void  CLcdSED153X::SetBlink(BOOL bOn)
{
	// not yet implemented
}

BOOL  CLcdSED153X::GetBlink()
{
	return FALSE;
}

void  CLcdSED153X::SetBacklight(short nMinutes)
{
}

short CLcdSED153X::GetBacklight()
{
	return TRUE;
}
