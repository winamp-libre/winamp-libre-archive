/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgCfgMOrbital.cpp:   LCD display configuration property page
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 18.11.99 - 
// 2003/08/03 MZ  replaced hard coded LCD driver access with dynamic methods through CLCDFactory 
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgCfgMOrbital.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgMOrbital property page

IMPLEMENT_DYNCREATE(CDlgCfgMOrbital, CDialog)

CDlgCfgMOrbital::CDlgCfgMOrbital(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCfgMOrbital::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCfgMOrbital)
	m_bBlink = FALSE;
	m_bCursor = FALSE;
	m_bScroll = FALSE;
	m_bWrap = FALSE;
	m_csCols = _T("");
	m_csRows = _T("");
	m_csBaudRate = _T("");
	m_csComPort = _T("");
	//}}AFX_DATA_INIT
}

CDlgCfgMOrbital::~CDlgCfgMOrbital()
{
}

void CDlgCfgMOrbital::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCfgMOrbital)
	DDX_Control(pDX, IDC_BRIGHTNESS_SLIDER, m_cBrightnessSlider);
	DDX_Control(pDX, IDC_CONTRAST_SLIDER, m_cContrastSlider);
	DDX_Check(pDX, IDC_CHECK_BLINK, m_bBlink);
	DDX_Check(pDX, IDC_CHECK_CURSOR, m_bCursor);
	DDX_Check(pDX, IDC_CHECK_SCROLL, m_bScroll);
	DDX_Check(pDX, IDC_CHECK_WRAP, m_bWrap);
	DDX_CBString(pDX, IDC_COMBO_COLS, m_csCols);
	DDV_MaxChars(pDX, m_csCols, 3);
	DDX_CBString(pDX, IDC_COMBO_ROWS, m_csRows);
	DDV_MaxChars(pDX, m_csRows, 3);
	DDX_CBString(pDX, IDC_COMBO_BAUDRATE, m_csBaudRate);
	DDX_CBString(pDX, IDC_COMBO_COMPORT, m_csComPort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCfgMOrbital, CDialog)
	//{{AFX_MSG_MAP(CDlgCfgMOrbital)
	ON_BN_CLICKED(IDC_LCD_RADIO, OnLcdRadio)
	ON_BN_CLICKED(IDC_VFD_RADIO, OnVfdRadio)
	ON_BN_CLICKED(IDC_DEF_BTN, OnDefBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgMOrbital message handlers

BOOL CDlgCfgMOrbital::OnInitDialog() 
{
	char	szTemp[10];

	CDialog::OnInitDialog();
	
	m_csOldComPort = m_csComPort  = g_MOCfg.szComPort;
	m_csOldBaudRate = m_csBaudRate = g_MOCfg.szBaudRate;

	m_bBlink = g_MOCfg.bBlink;
	m_bCursor = g_MOCfg.bShowCursor;
	m_bScroll = g_MOCfg.bScroll;
	m_bWrap = g_MOCfg.bWrap;
	m_csCols = itoa( g_MOCfg.iCols, szTemp, 10 );
	m_csRows = itoa( g_MOCfg.iRows, szTemp, 10 );

	m_cContrastSlider.SetRange(0, 255);
	m_cContrastSlider.SetPos(g_MOCfg.byContrast);

	m_cBrightnessSlider.SetRange(3, 0);
	m_cBrightnessSlider.SetPos(g_MOCfg.byBrightness);

	// MZ, June 27th 2k
	CheckRadioButton(IDC_LCD_RADIO,IDC_VFD_RADIO, g_MOCfg.bLCD ? IDC_LCD_RADIO : IDC_VFD_RADIO);

	g_MOCfg.bLCD ? OnLcdRadio() : OnVfdRadio();

	UpdateData( FALSE );

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCfgMOrbital::OnOK() 
{	
  char szBuffer1[512];

	UpdateData();

	strncpy( g_MOCfg.szComPort, m_csComPort, sizeof(g_MOCfg.szComPort) );
	strncpy( g_MOCfg.szBaudRate, m_csBaudRate, sizeof(g_MOCfg.szBaudRate) );

	m_csOldComPort = m_csComPort, m_csOldBaudRate = m_csBaudRate;
	g_MOCfg.bBlink = m_bBlink;
	g_MOCfg.bShowCursor = m_bCursor;
	g_MOCfg.bScroll = m_bScroll;
	g_MOCfg.bWrap = m_bWrap;
	g_MOCfg.iCols = atoi( m_csCols );
	g_MOCfg.iRows = atoi( m_csRows );
	g_MOCfg.byContrast = m_cContrastSlider.GetPos();
	g_MOCfg.byBrightness = m_cBrightnessSlider.GetPos();

    LCD_DRIVER *pDrv = g_LCDFactory.GetDriver(DRV_MORBITAL);

	if (pDrv && (g_LCD == pDrv->pcLcd) && (pDrv->pcLcd != NULL))
	{
		if (m_csOldComPort != m_csComPort || m_csOldBaudRate != m_csBaudRate)
		{
      LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_MO1, szBuffer1, sizeof(szBuffer1));
			if (MessageBox( szBuffer1, g_szAppName, MB_YESNO | MB_ICONQUESTION ) == IDYES)
			{
				g_LCDFactory.OpenLCD(pDrv->pcLcd);

				UpdateData(FALSE);
			}
		}
		pDrv->pcLcd->SetBlink(m_bBlink);
		pDrv->pcLcd->Cursor(m_bCursor);
		pDrv->pcLcd->SetScroll(m_bScroll);
		pDrv->pcLcd->SetLineWrap(m_bWrap);
		if (g_MOCfg.bLCD)
			pDrv->pcLcd->SetContrast(g_MOCfg.byContrast);
		else
			pDrv->pcLcd->SetBrightness(g_MOCfg.byBrightness);
	}

	CDialog::OnOK();
}

void CDlgCfgMOrbital::OnLcdRadio() 
{
	GetDlgItem(IDC_CONTRAST_SLIDER)->EnableWindow(TRUE);
	GetDlgItem(IDC_BRIGHTNESS_SLIDER)->EnableWindow(FALSE);
}

void CDlgCfgMOrbital::OnVfdRadio() 
{
	GetDlgItem(IDC_CONTRAST_SLIDER)->EnableWindow(FALSE);
	GetDlgItem(IDC_BRIGHTNESS_SLIDER)->EnableWindow(TRUE);		
}

void CDlgCfgMOrbital::OnDefBtn() 
{
	m_csComPort  = DEF_COMPORT;
	m_csBaudRate = DEF_BAUDRATE;
	m_bBlink = m_bCursor = FALSE;
	m_bScroll = FALSE;
	m_bWrap = TRUE;
	m_csCols = "20";
	m_csRows = "4";
	m_cContrastSlider.SetPos(DEF_CONTRAST);
	m_cBrightnessSlider.SetPos(DEF_BRIGHTNESS);
	CheckRadioButton(IDC_LCD_RADIO,IDC_VFD_RADIO, IDC_LCD_RADIO);	// MZ, June 27th 2k

	UpdateData( FALSE );
}
