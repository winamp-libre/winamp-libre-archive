/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// CustomChar.cpp: implementation of the CCustomChar class.
//
// This class contains the datastructure for a custom character: an array of
// byte. Each byte represents a row of the character. See Matrix Orbital 
// user manuel for more details.
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/01/26 MZ  Uninitialize() added for a hack to free memory when the plugin terminates (see quit() in gen_lcddisplay.cpp)
//
/////////////////////////////////////////////////////////////////////////////
//
// TODO: add copy constructor
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "CustomChar.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define DEF_DATA_SIZE	8

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCustomChar::CCustomChar()
{
	m_byDataSize = DEF_DATA_SIZE;

	m_byarrData = new BYTE[m_byDataSize];
	memset(m_byarrData, 0, m_byDataSize);
}

CCustomChar::CCustomChar(BYTE byDataSize)
{
	m_byDataSize = byDataSize;

	m_byarrData = new BYTE[m_byDataSize];
	memset(m_byarrData, 0, m_byDataSize);
}

CCustomChar::~CCustomChar()
{
	Uninitialize();
}

void CCustomChar::Set(LPCSTR lpCharStr)
{
	char *szTmp = _strdup(lpCharStr);
	char *p;
	int  i = 0;

	p = strtok(szTmp, ",");

	while ((p != NULL) && (i < m_byDataSize))
	{
		m_byarrData[i++] = atoi(p);
		p = strtok(NULL, ",");
	}

	free(szTmp);
}

LPCTSTR CCustomChar::GetAsString(CString &csString)
{
	char szTemp[10];

	csString = "";
	for (int i = 0; i < m_byDataSize; i++)
	{
		if (i > 0)
			csString += ",";
		csString += itoa(m_byarrData[i], szTemp, 10);
	}
	return csString;
}

void CCustomChar::Uninitialize()
{
	if (m_byarrData) {
		delete []m_byarrData;
	}

	m_byarrData = NULL;
}
