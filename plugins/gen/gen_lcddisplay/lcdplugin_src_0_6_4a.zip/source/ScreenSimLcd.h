#if !defined(__SCREENSIMLCD__)
#define __SCREENSIMLCD__

#if _MSC_VER > 1000
#pragma once
#endif

#include "Lcd.h"

#define DEF_CONTRAST		140

class CCfgSim
{
public:
	CCfgSim();
	~CCfgSim();
	void Load(LPCSTR lpIniFile);
	void Save(LPCSTR lpIniFile);

public:
  BYTE	byContrast;
	BOOL	bShowCursor;
	BOOL	bWrap;
	BOOL	bScroll;
	BOOL	bBlink;
	int iRows;
	int iCols;
	tULongToULong charMap;
};

extern CCfgSim  g_SimCfg;

class CLcdSim : public CLcd
{
public:
	CLcdSim();
	virtual ~CLcdSim();

	virtual void  SetBacklight(short nSeconds);
	virtual void  SetBlink(BOOL On);
	virtual void  Clear();
	virtual void  Close();
	virtual BOOL  IsOpen();
	virtual void  SetContrast(short nLevel);
	virtual void  Cursor(BOOL bOn);
	virtual BOOL  IsCursorOn();
	virtual long  GetLastError();
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen);
	virtual void  Home();
	virtual void  InitHorizontalBar();
	virtual void  InitLargeDigit();
	virtual void  InitVerticalBar();
	virtual void  LargeDigit(short nCol, short nNumber);
	virtual void  SetLineWrap(BOOL bOn);
	virtual BOOL  Open();
	virtual void  SetPosition(short nCol, short nRow);
	virtual void  SetScroll(BOOL bOn);
	virtual void  VBar(short nCol, short nLength);
	virtual void  Write(LPCSTR lpText);
	virtual BOOL  CreateCustomChar(short nNumber, CCustomChar &cChar);
	virtual short GetMaxCustomChar();
	virtual LPCTSTR ConvertTagsToCustomChars(CString &csText);
	virtual LPCTSTR ConvertCustomCharsToTags(CString &csText);
	virtual int		GetRows();		// MZ, July 20 2k
	virtual int		GetColumns();	// MZ, July 20

private:
	long    m_lLastError;
	HANDLE  m_hScreen;
};


#endif