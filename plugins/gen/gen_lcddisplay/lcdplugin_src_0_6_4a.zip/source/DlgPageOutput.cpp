/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2001 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgPageOutput.cpp:   Ouput configuration property page
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 27.02.01 - multiple output sets, M.Zehnder
// 28.11.99 - save & load functionality, M.Zehnder
// 14.11.99 - added drop down list boxes in list control, M.Zehnder
// 2003/07/13 MZ  allowing only one empty set
//
/////////////////////////////////////////////////////////////////////////////
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgPageOutput.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPageOutput property page

IMPLEMENT_DYNCREATE(CDlgPageOutput, CPropertyPage)

CDlgPageOutput::CDlgPageOutput() : CPropertyPage(CDlgPageOutput::IDD)
{
	//{{AFX_DATA_INIT(CDlgPageOutput)
	m_iSet = -1;
	m_dwSetIntervall = 0;
	//}}AFX_DATA_INIT

	m_iOldSet = -1;
	m_pcHlpDlg = NULL;
}

CDlgPageOutput::~CDlgPageOutput()
{
	if (m_pcHlpDlg != NULL)
	{
		m_pcHlpDlg->EndDialog(IDOK);

		delete m_pcHlpDlg;
	}
}

void CDlgPageOutput::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPageOutput)
	DDX_Control(pDX, IDC_SET_COMBO, m_cSetCBox);
	DDX_Control(pDX, IDC_LIST, m_cListCtrl);
	DDX_CBIndex(pDX, IDC_SET_COMBO, m_iSet);
	DDX_Text(pDX, IDC_EDIT_INTERVALL, m_dwSetIntervall);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPageOutput, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgPageOutput)
	ON_BN_CLICKED(IDC_BTN_ADD, OnBtnAdd)
	ON_BN_CLICKED(IDC_BTN_DELETE, OnBtnDelete)
	ON_BN_CLICKED(IDC_HELP_BTN, OnHelpBtn)
	ON_CBN_SELCHANGE(IDC_SET_COMBO, OnSelchangeSetCombo)
	ON_BN_CLICKED(IDC_BTN_DELSET, OnBtnDeleteSet)
	ON_BN_CLICKED(IDC_BTN_COPYSET, OnBtnCopySet)
	ON_BN_CLICKED(IDC_BTN_ADDSET, OnBtnAddSet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPageOutput message handlers

BOOL CDlgPageOutput::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	char		 szBuffer1[512];
	CStringArray carrItems;

	
	// add checkbox style
	ListView_SetExtendedListViewStyle 
		(m_cListCtrl.m_hWnd, LVS_EX_CHECKBOXES | LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT );

	// add columns
	LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_OUTP_ACTIVE, szBuffer1, sizeof(szBuffer1));
	m_cListCtrl.InsertColumn( 0, szBuffer1);

	LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_OUTP_ROW, szBuffer1, sizeof(szBuffer1));
	m_cListCtrl.InsertColumn( 1, szBuffer1);

	LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_OUTP_COL, szBuffer1, sizeof(szBuffer1));
	m_cListCtrl.InsertColumn( 2, szBuffer1);

	LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_OUTP_TXT, szBuffer1, sizeof(szBuffer1));
	m_cListCtrl.InsertColumn( 3, szBuffer1);

	LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_OUTP_LENGTH, szBuffer1, sizeof(szBuffer1));
	m_cListCtrl.InsertColumn( 4, szBuffer1);

	LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_OUTP_ALIGN, szBuffer1, sizeof(szBuffer1));
	m_cListCtrl.InsertColumn( 5, szBuffer1);

	LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_OUTP_SCROLL, szBuffer1, sizeof(szBuffer1));
	m_cListCtrl.InsertColumn( 6, szBuffer1);

	// add drop down list boxes
	LoadString(g_Plugin.hDllInstance, IDS_LEFT, szBuffer1, sizeof(szBuffer1));
	carrItems.Add( szBuffer1 );

	LoadString(g_Plugin.hDllInstance, IDS_CENTER, szBuffer1, sizeof(szBuffer1));
	carrItems.Add( szBuffer1 );

	LoadString(g_Plugin.hDllInstance, IDS_RIGHT, szBuffer1, sizeof(szBuffer1));
	carrItems.Add( szBuffer1 );
	m_cListCtrl.SetDropDownListCol( 5, carrItems );

	carrItems.RemoveAll();

	LoadString(g_Plugin.hDllInstance, IDS_OFF, szBuffer1, sizeof(szBuffer1));
	carrItems.Add( szBuffer1 );
	LoadString(g_Plugin.hDllInstance, IDS_SCROLL_FWD, szBuffer1, sizeof(szBuffer1));
	carrItems.Add( szBuffer1 );
	LoadString(g_Plugin.hDllInstance, IDS_SCROLL_BOUNCE, szBuffer1, sizeof(szBuffer1));
	carrItems.Add( szBuffer1 );
	LoadString(g_Plugin.hDllInstance, IDS_SCROLL_BACK, szBuffer1, sizeof(szBuffer1));
	carrItems.Add( szBuffer1 );
	m_cListCtrl.SetDropDownListCol( 6, carrItems );

	
	int iTotSets = g_Config.cOutputFields.GetSetCount();
	m_cSetCBox.ResetContent();
	for (int i = 0; i < iTotSets; i++)
		m_cSetCBox.AddString(itoa(i, szBuffer1, 10));

	m_cSetCBox.SetCurSel(0);
	OnSelchangeSetCombo();

	m_dwSetIntervall = g_Config.dwSwitchSetTimeout;

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgPageOutput::OnOK() 
{
	CPropertyPage::OnOK();
}

void CDlgPageOutput::OnBtnAdd() 
{
	int iCount = m_cListCtrl.GetItemCount();
	m_cListCtrl.SetItemCount( iCount + 1 );

	for (int i = 0; i < m_cListCtrl.GetColumnCount(); i++)
		m_cListCtrl.AddItem( "", iCount, i );

	OnSetModified();
}

void CDlgPageOutput::OnBtnDelete() 
{
    char szBuffer1[512];

	int		iCol = m_cListCtrl.GetNextItem( -1, LVNI_SELECTED );

	if (iCol >= 0)
	{
	  LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_OUTP_DEL, szBuffer1, sizeof(szBuffer1));
	  if (MessageBox( szBuffer1, g_szAppName, MB_YESNO | MB_ICONQUESTION ) == IDYES)
		  m_cListCtrl.DeleteItem( iCol );
	}

	OnSetModified();
}

void CDlgPageOutput::OnSetModified() 
{
	this->SetModified();	
}

BOOL CDlgPageOutput::OnApply() 
{
	UpdateData();

	m_iOldSet = m_iSet;
	SaveCurrentSet();

	g_Config.dwSwitchSetTimeout = m_dwSetIntervall;

	return CPropertyPage::OnApply();
}

void CDlgPageOutput::OnHelpBtn() 
{
	m_pcHlpDlg = new CDlgVarHelp();

	m_pcHlpDlg->Create(IDD_VAR_HELP);
	m_pcHlpDlg->ShowWindow(SW_SHOW);
}


void CDlgPageOutput::OnSelchangeSetCombo() 
{
	char		 szTemp[10], szBuffer1[512];
	int			 iID;

	UpdateData(true);

	if (m_iSet == m_iOldSet)
		return;

	if (m_iOldSet != -1)
		SaveCurrentSet();


	m_iOldSet = m_iSet;

	// load selected output set
	m_cListCtrl.DeleteAllItems();

	for (int iField = 0, iRow = 0; iField < g_Config.cOutputFields.GetTotalFieldCount(); iField++) 
	{
		COutputField *pcField = g_Config.cOutputFields.GetField(iField);

		if (pcField->m_bySet != m_iSet)
			continue;

		m_cListCtrl.AddItem( "", iRow, 0 );
		m_cListCtrl.SetCheck( iRow, pcField->m_bActive );
		m_cListCtrl.AddItem( itoa(pcField->m_iRow,szTemp,10), iRow, 1 );
		m_cListCtrl.AddItem( itoa(pcField->m_iCol,szTemp,10), iRow, 2 );
		m_cListCtrl.AddItem( pcField->m_csText, iRow, 3 );
		m_cListCtrl.AddItem( itoa(pcField->m_iLength,szTemp,10), iRow, 4 );
		switch (pcField->m_iAlignment)
		{
			case ALIGNMENT_CENTER :
				iID = IDS_CENTER;
				break;
			case ALIGNMENT_RIGHT  :
				iID = IDS_RIGHT;
				break;
			default :
				iID = IDS_LEFT;
		}
		LoadString(g_Plugin.hDllInstance, iID, szBuffer1, sizeof(szBuffer1));
		m_cListCtrl.AddItem( szBuffer1, iRow, 5 );

		// enhanced scrolling types, MZ 2002/01/09
		int id;
		switch (pcField->m_ScrollType) {
			case pcField->FORWARD : id = IDS_SCROLL_FWD;     break;
			case pcField->BOUNCE  : id = IDS_SCROLL_BOUNCE;  break;
			case pcField->BACKWARD: id = IDS_SCROLL_BACK;    break;
			default: id = IDS_OFF;
		}
		LoadString(g_Plugin.hDllInstance, id, szBuffer1, sizeof(szBuffer1));
		m_cListCtrl.AddItem(szBuffer1, iRow, 6 );

		iRow++;
	}

	m_cListCtrl.SetItemCount(iRow);
	m_cListCtrl.AutoSizeColumns();		
}

void CDlgPageOutput::OnBtnDeleteSet() 
{
	UpdateData();
	g_Config.cOutputFields.DeleteSet(m_iSet);
	
	m_iOldSet = -1;
	m_cSetCBox.ResetContent();
	char szBuffer[10];
	for (int i=0; i < g_Config.cOutputFields.GetSetCount(); i++)
		m_cSetCBox.AddString(itoa(i, szBuffer, 10));

	m_cSetCBox.SetCurSel(0);
	OnSelchangeSetCombo();
}

void CDlgPageOutput::OnBtnCopySet() 
{
	UpdateData();

	SaveCurrentSet();
	BYTE byNewSet = g_Config.cOutputFields.CopySet(m_iSet);

	char szBuffer[10];
	m_cSetCBox.AddString(itoa(byNewSet, szBuffer, 10));

	m_iOldSet = m_iSet = byNewSet;
	m_cSetCBox.SetCurSel(byNewSet);
}

void CDlgPageOutput::OnBtnAddSet() 
{
	UpdateData();

	SaveCurrentSet();
	BYTE byNewSet = g_Config.cOutputFields.GetSetCount();


	char szBuffer[10];
	itoa(byNewSet, szBuffer, 10);
	if (m_cSetCBox.FindString(-1, szBuffer) != CB_ERR) {
		return;
	}

	m_cSetCBox.AddString(szBuffer);

	m_cSetCBox.SetCurSel(byNewSet);
	OnSelchangeSetCombo();
}

void CDlgPageOutput::SaveCurrentSet()
{
	COutputField *pcField = NULL;
	char		 szBuffer1[512];


	if (m_iOldSet == -1)
		return;

	// 20030706 MZ bugfix only aquire write lock if there's a display device!
	if (g_LCD != NULL) {
		while (!AcquireWriteLock(&g_OutputLock));
	}

	// clear old configuration
	g_Config.cOutputFields.ClearSet(m_iOldSet);

	// store fields
	for (int iRow = 0; iRow < m_cListCtrl.GetItemCount(); iRow++)
	{
	  pcField = new COutputField;

	  for (int i = 0; i < m_cListCtrl.GetColumnCount(); i++)
	  {
		CString csText = m_cListCtrl.GetItemText( iRow, i );

		switch (i)
		{
			case 0 : pcField->m_bActive = m_cListCtrl.GetCheck(iRow); break;
			case 1 : pcField->m_iRow = atoi(csText);                  break;
			case 2 : pcField->m_iCol = atoi(csText);				  break;
			case 3 : pcField->m_csText = csText;                      break;
			case 4 : pcField->m_iLength = atoi(csText);			      break;
			case 5 :
				LoadString(g_Plugin.hDllInstance, IDS_CENTER, szBuffer1, sizeof(szBuffer1));
				if (csText.Compare( szBuffer1 ) == 0)
					pcField->m_iAlignment = ALIGNMENT_CENTER;
				else
				{	// bugfix: no brakes = center doesn't work...  MZ 23 Oct 00
					LoadString(g_Plugin.hDllInstance, IDS_RIGHT, szBuffer1, sizeof(szBuffer1));
					if (csText.Compare( szBuffer1 ) == 0)
						pcField->m_iAlignment = ALIGNMENT_RIGHT;
					else
						pcField->m_iAlignment = ALIGNMENT_LEFT;
				}
				break;
			case 6 :
				// getting the scroll type is a bit annoying, but nothing's perfect...
				LoadString(g_Plugin.hDllInstance, IDS_SCROLL_FWD, szBuffer1, sizeof(szBuffer1));
				if (strcmp(csText, szBuffer1) == 0) {
					pcField->m_ScrollType = pcField->FORWARD;
				} else {
					LoadString(g_Plugin.hDllInstance, IDS_SCROLL_BOUNCE, szBuffer1, sizeof(szBuffer1));
					if (strcmp(csText, szBuffer1) == 0) {
						pcField->m_ScrollType = pcField->BOUNCE;
					} else {
						LoadString(g_Plugin.hDllInstance, IDS_SCROLL_BACK, szBuffer1, sizeof(szBuffer1));
						if (strcmp(csText, szBuffer1) == 0) {
							pcField->m_ScrollType = pcField->BACKWARD;
						} else {
							pcField->m_ScrollType = pcField->OFF;
						}
					}
				}

				break;
		}
	  }
	  pcField->m_bySet = m_iOldSet;
	  g_Config.cOutputFields.Add( pcField );
	}

	if (g_LCD != NULL) {
		ReleaseWriteLock(&g_OutputLock);
	}
}

