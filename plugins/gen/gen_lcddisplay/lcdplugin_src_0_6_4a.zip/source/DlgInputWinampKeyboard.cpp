// DlgInputWinampKeyboard.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgInputWinampKeyboard.h"
#include "DlgInputAddKeyboard.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CDlgInputWinampKeyboard 

IMPLEMENT_DYNCREATE(CDlgInputWinampKeyboard, CPropertyPage)

CDlgInputWinampKeyboard::CDlgInputWinampKeyboard(CWnd* pParent /*=NULL*/)
	: CDlgInput(CDlgInputWinampKeyboard::IDD)
{
	//{{AFX_DATA_INIT(CDlgInputWinampKeyboard)
	m_bEnabled = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgInputWinampKeyboard::DoDataExchange(CDataExchange* pDX)
{
	CDlgInput::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInputWinampKeyboard)
	DDX_Control(pDX, IDC_LIST_KB, m_cList);
	DDX_Check(pDX, IDC_KB_ENABLED, m_bEnabled);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInputWinampKeyboard, CDlgInput)
	//{{AFX_MSG_MAP(CDlgInputWinampKeyboard)
	ON_BN_CLICKED(IDC_BTN_KB_ADD, OnAdd)
	ON_BN_CLICKED(IDC_BTN_KB_EDIT, OnEdit)
	ON_BN_CLICKED(IDC_BTN_KB_DEL, OnDelete)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_KB, OnDblclkListKb)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CDlgInputWinampKeyboard 

void CDlgInputWinampKeyboard::OnAdd() 
{
    CDlgInputAddKeyboard cDlg(this, NULL, true);

	cDlg.m_iKeyCode = 0;

	if(cDlg.DoModal() == IDOK)
	{
		RefreshList();
		m_cList.AutoSizeColumns();
		SetModified();
	}	
}

void CDlgInputWinampKeyboard::OnEdit() 
{
	CDlgInputAddKeyboard cDlg(this, NULL, true);

	cDlg.m_iKeyCode = m_cList.GetItemData(m_cList.GetSelectionMark());

	if(cDlg.DoModal() == IDOK)
	{
		RefreshList();
		m_cList.AutoSizeColumns();
		SetModified();
	}	
}

BOOL CDlgInputWinampKeyboard::OnApply() 
{
	g_Config.bEnableWinampKeypad = m_bEnabled;

	return CDlgInput::OnApply();
}


void CDlgInputWinampKeyboard::OnDelete() 
{
	int index = m_cList.GetSelectionMark();

	if (index == -1)
	{
		MessageBox("Select a button first.");
		return;
	}

	int key = m_cList.GetItemData(index);

	KB_KEY* pe;
	if (g_Config.mapWAKBcfg.Lookup(key, (void *&)pe))
	{
		if (g_Config.mapWAKBcfg.RemoveKey(key))
		{
			delete pe;

			g_Config.mapWAKBcfg_menu.RemoveKey(key);
			g_Config.mapWAKBcfg_set.RemoveKey(key);
			m_cList.DeleteItem(index);
			m_cList.SetSelectionMark(index);
			m_cList.AutoSizeColumns();
			SetModified();
			return;
		}
	}

	MessageBox("Couldn't find that button, doh!");
	
}

BOOL CDlgInputWinampKeyboard::OnInitDialog() 
{
		CDlgInput::OnInitDialog();
		
	CString  csBuf;

	m_bEnabled = g_Config.bEnableWinampKeypad;

	ListView_SetExtendedListViewStyle 
		(m_cList.m_hWnd, LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT );

	// add columns
	csBuf.LoadString(IDS_CFG_WL_BUTTON);
	m_cList.InsertColumn(0, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION);
	m_cList.InsertColumn(1, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_MENU);
	m_cList.InsertColumn(2, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_SET);
	m_cList.InsertColumn(3, csBuf);
	
	UpdateData(FALSE);

	RefreshList();
	m_cList.AutoSizeColumns();		

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CDlgInputWinampKeyboard::RefreshList()
{		
	int item;
	POSITION pos;
	WORD key;
	KB_KEY* pe;
	TCHAR	szBuf[30];
	LV_FINDINFO lvf;

 	m_cList.DeleteAllItems();

	for (pos = g_Config.mapWAKBcfg.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapWAKBcfg.GetNextAssoc(pos, key, (void *&)pe);
		
		if (GetKeyNameText(pe->lParam, szBuf, 30) == 0)
			continue;

		item = m_cList.InsertItem(0, szBuf);

		if (item < 0)
			continue;

		m_cList.SetItem(item, 1, LVIF_TEXT, acts[pe->action].name,0,0,0,0);
		m_cList.SetItemData(item, key);
	}

	for (pos = g_Config.mapWAKBcfg_menu.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapWAKBcfg_menu.GetNextAssoc(pos, key, (void *&)pe);
		
		lvf.flags = LVFI_PARAM;
		lvf.lParam = key;
		if ((item = m_cList.FindItem(&lvf)) == -1)
		{
			// Create New item
			if (GetKeyNameText(pe->lParam, szBuf, 30) == 0)
				continue;
			item = m_cList.InsertItem(0, szBuf);
			if (item < 0)
				continue;
		}

		m_cList.SetItem(item, 2, LVIF_TEXT, acts[pe->action].name,0,0,0,0);
		m_cList.SetItemData(item, key);
	}

	for (pos = g_Config.mapWAKBcfg_set.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapWAKBcfg_set.GetNextAssoc(pos, key, (void *&)pe);

		lvf.flags = LVFI_PARAM;
		lvf.lParam = key;
		if ((item = m_cList.FindItem(&lvf)) == -1)
		{
			// Create New item
			if (GetKeyNameText(pe->lParam, szBuf, 30) == 0)
				continue;
			item = m_cList.InsertItem(0, szBuf);
			if (item < 0)
				continue;
		}

		m_cList.SetItem(item, 3, LVIF_TEXT, acts[pe->action].name,0,0,0,0);
		m_cList.SetItemData(item, key);
	}
}

void CDlgInputWinampKeyboard::OnDblclkListKb(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnEdit();
	
	*pResult = 0;
}
