// LcdMOGlk.h: interface for the CLcdMOGlk class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LCDMOGLK_H__5D920BCA_F753_4F7B_AC17_DE519EA2C6A8__INCLUDED_)
#define AFX_LCDMOGLK_H__5D920BCA_F753_4F7B_AC17_DE519EA2C6A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MOrbitalLcd.h"

class CCfgMOGlk
{
public:
	CCfgMOGlk();
	~CCfgMOGlk();
	void Load(LPCSTR lpIniFile);
	void Save(LPCSTR lpIniFile);

public:
	char	szComPort[10];
	char	szBaudRate[7];
	BYTE	byContrast;
	BYTE	byBrightness;
	BOOL	bShowCursor;
	BOOL	bWrap;
	BOOL	bScroll;
	BOOL	bBlink;
	BOOL	bLCD;
	int		iRows;
	int		iCols;
	tULongToULong charMap;
};

extern	CCfgMOGlk	 g_MOGlkCfg; 


class CLcdMOGlk : public CLcdMOrbital  
{
public:
	CLcdMOGlk();
	virtual ~CLcdMOGlk();

	virtual BOOL    Open();
	virtual int		GetRows();		
	virtual int		GetColumns();
	virtual void  SetBrightness(short nLevel);
	virtual void  SetBlink(BOOL On);
	virtual void  Cursor(BOOL bOn);
	virtual void  Write(LPCSTR lpText);

	virtual void  InitHorizontalBar();
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen);
	virtual void  InitVerticalBar();
	virtual void  VBar(short nCol, short nLength);
	virtual void  InitLargeDigit();
	virtual void  LargeDigit(short nCol, short nNumber);

};

#endif // !defined(AFX_LCDMOGLK_H__5D920BCA_F753_4F7B_AC17_DE519EA2C6A8__INCLUDED_)
