/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2001 Frank Verhamme. All Rights Reserved.
//
//  This file is part of the WinAmp Serial LCD Display Plugin.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
/////////////////////////////////////////////////////////////////////////////
//
// spec_analyser.c:   Spectrum Analyser for LCD plugin
//
/////////////////////////////////////////////////////////////////////////////
// Modifications:
// 06.09.2000 - FVerhamme: first release
// 04.08.2001 - JMattila: little improvement for render(Not linear)
// 18.08.2001 - Spectrum Analyser Falloff (Zlatko Novak)
// 21.10.2001 - MZ: merged versions from JMattilla and Zlatko and made generic
//              helper functions
/////////////////////////////////////////////////////////////////////////////
//
// TODO: - make # of rows dynamic, it should work with 1 to 4 row heights
// 


#include <windows.h>
#include <stdio.h>
#include "spec_analyser.h"
#include "renderer.h"

char line1[40];  //max 40 Zeichen
char line2[40];  //max 40 Zeichen
char line3[40];  //max 40 Zeichen
char line4[40];  //max 40 Zeichen
double  darrFalloff[40];

int iRunning, iRendering;					// renedering vu meter
const int lcdCharWidth = 5;					// a single LCD Character in pixel
static char gcVUString[40];					// VU bar chars (max.40 )

// @todo make falloff value configurable
double  dFalloffValue = 1.5;

static int rows = 0;  // Reihen des Display
static int columns = 0;  // Spalten des Display
static int width = 0;  // Breite f�r Spectrum Analyser
static int height = 0;  // H�he f�r Spectrum Analyser (max 4 Reihen)
BOOL falloff;

// returns a winampVisModule when requested. Used in hdr, below
winampVisModule *getModule(int which);

// "member" functions
void config(struct winampVisModule *this_mod); // configuration dialog
void config2(struct winampVisModule *this_mod); // configuration dialog
void config3(struct winampVisModule *this_mod); // configuration dialog
//void config4(struct winampVisModule *this_mod); // configuration dialog

int init(struct winampVisModule *this_mod);	   // initialization for module
void quit(struct winampVisModule *this_mod);   // deinitialization for module
int renderLinearSA(struct winampVisModule *this_mod);  // rendering for module
int renderNonLinearSA(struct winampVisModule *this_mod);  // rendering for module
int renderVuMeter(struct winampVisModule *this_mod);  // rendering for module

int AdjustFalloff(int x, double value);
void MapToLCD(int x, int value);

// Module header, includes version, description, and address of the module retriever function
winampVisHeader hdr = { VIS_HDRVER, "Spectrum Analyser LCD", getModule };

winampVisModule mod1 =
{
	"Linear spectrum analyser",
	NULL,   // hwndParent
	NULL,   // hDllInstance
	0,      // sRate
	0,      // nCh
	25,     // latencyMS
	25,     // delayMS
	2,      // spectrumNch
	0,      // waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config,
	init,
	renderLinearSA, 
	quit
};

winampVisModule mod2 =
{
	"Non-linear spectrum analyser",
	NULL,   // hwndParent
	NULL,   // hDllInstance
	0,      // sRate
	0,      // nCh
	25,     // latencyMS
	25,     // delayMS
	2,      // spectrumNch
	0,      // waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config2,
	init,
	renderNonLinearSA, 
	quit
};

winampVisModule mod3 =
{
	"Mini VU Meter",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	0,		// sRate
	0,		// nCh
	50,		// latencyMS
	45,		// delayMS
	0,		// spectrumNch
	2,		// waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config3,
	init,
	renderVuMeter,
	quit,
	(void *) 2
};
/* FV: In Vorbereitung
winampVisModule mod4 =
{
	"Mini Oscillioscope",
	NULL,
	NULL,
	0,
	0,
	150,
	125,
	0,
	2,
	{ 0, },
	{ 0, },
	config,
	init,
	renderVuMeter,
	quit,
	(void *) 1
};
*/

// This is the handle to gen_lcd.dll
static HMODULE hGenLcdDll;

// This function will be loaded from gen_lcd.dll
void (*spec_analyser_data_func)(char *string1, char *string2, char *string3, char *string4);
void (*spec_analyser_stop_func)(void);
void (*spec_analyser_init_func)(int *rows, int *columns, int *width, int *height, int *falloff);
void (*spec_analyser_vudata_func)(char *string1);

// this is the only exported symbol. returns our main header.
// if you are compiling C++, the extern "C" { is necessary, so we just #ifdef it
#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) winampVisHeader *winampVisGetHeader()
{
  return &hdr;
}
#ifdef __cplusplus
}
#endif

// getmodule routine from the main header. Returns NULL if an invalid module was requested,
// otherwise returns either mod1, mod2 or mod3 depending on 'which'.s
winampVisModule *getModule(int which)
{
  switch (which)
	{
	    case 0: return &mod1;
		case 1: return &mod2;
		case 2: return &mod3;
		//case 3: return &mod4;  // FV: In Vorbereitung
		default: return NULL;
	}
}

// configuration.
// Passed this_mod, as a "this" parameter.
// Allows you to make one configuration function
// that shares code for all your modules
void config(struct winampVisModule *this_mod)
{
	MessageBox(this_mod->hwndParent,"This plugin is part of the gen_lcddisplay plugin.\n"
									"This part was coded by Speedy.\n"
									"Falloff code by Zlatko.",
									"Configuration",MB_OK);
}

void config2(struct winampVisModule *this_mod)
{
	MessageBox(this_mod->hwndParent,"This plugin is part of the gen_lcddisplay plugin.\n"
									"This part was coded by JMattila.\n"
									"Falloff code by Zlatko.",
									"Configuration",MB_OK);
}

void config3(struct winampVisModule *this_mod)
{
	MessageBox(this_mod->hwndParent,"This plugin is part of the gen_lcddisplay plugin.\n"
									"This part was coded by Speedy.\n"
									"No further configuration needed",
									"Configuration",MB_OK | MB_ICONINFORMATION);
}
/*
void config4(struct winampVisModule *this_mod)
{
	MessageBox(this_mod->hwndParent,"This plugin is part of the gen_lcddisplay plugin.\n"
									"This part was coded by Speedy.\n"
									"No further configuration needed",
									"Configuration",MB_OK | MB_ICONINFORMATION);
}
*/
// initialization.
// returns 0 on success, 1 on failure.
int init(struct winampVisModule *this_mod)
{
  char cDllPath[MAX_PATH];
  GetModuleFileName(this_mod->hDllInstance, cDllPath, sizeof(cDllPath));
  if(strrchr(cDllPath,'\\'))
    strcpy(strrchr(cDllPath,'\\')+1, "gen_lcddisplay.dll");
  else
    strcpy(cDllPath, "gen_lcddisplay.dll");

  hGenLcdDll = LoadLibrary(cDllPath);
  
  if(hGenLcdDll == INVALID_HANDLE_VALUE)
    return 1;

  spec_analyser_data_func = (void(*)(char*, char*, char*, char *))GetProcAddress(hGenLcdDll, "spec_analyser_data");
  spec_analyser_stop_func = (void(*)(void))GetProcAddress(hGenLcdDll, "spec_analyser_stop");
  spec_analyser_init_func = (void(*)(int*, int*, int*, int*, int*))GetProcAddress(hGenLcdDll, "spec_analyser_init");
  spec_analyser_vudata_func = (void(*)(char*))GetProcAddress(hGenLcdDll, "spec_analyser_vudata");

  if(!spec_analyser_data_func && !spec_analyser_stop_func && !spec_analyser_init_func && !spec_analyser_vudata_func)
  {
    FreeLibrary(hGenLcdDll);
	iRendering = iRunning = 0;
    return 1;
  }

  iRendering = 0;
  iRunning = 1;

  spec_analyser_init_func(&rows, &columns, &width, &height, &falloff); // Get the display size
  if(rows < 1)  // Wenn keine Zeile dann hat das alles keinen Sinn !
  {
    FreeLibrary(hGenLcdDll);
	iRendering = iRunning = 0;
    return 1;
  }

  // Vorbelegen der max. 4 Reihen
  memset(line1,' ',width);
  memset(line2,' ',width);
  memset(line3,' ',width);
  memset(line4,' ',width);
  line1[width]='\0';
  line2[width]='\0';
  line3[width]='\0';
  line4[width]='\0';
	return 0;
}

/******************************************************************************
Function : renderLinearSA
Purpose  : Renders the linear spectrum analyser
Parameters : pointer to visualisation module
Returns : 0 if successful, 1 if visualization should end.
Author  : Frank Verhamme    
******************************************************************************/
int renderLinearSA(struct winampVisModule *this_mod)
{
	
	int x,amo;

	int step = 400 / width; // vorher columns;
	double left_ch, right_ch;

	for (x = 0; x < width; x++)  // columns
	{
		// get data for left and right channel
		left_ch = (this_mod->spectrumData[0][x*step]) / 3;

		right_ch = (this_mod->spectrumData[1][x*step]) / 3;

		// mix them together...
		amo = AdjustFalloff(x, left_ch + right_ch);

		// ... and distribute it to the 2 lines of our spec analyser
		MapToLCD(x, amo);
	}

	line1[width] = '\0';
	line2[width] = '\0';
	line3[width] = '\0';
	line4[width] = '\0';

	// pass data to LCD plugin
	spec_analyser_data_func(line1, line2, line3, line4);
	
	return 0;
}

/******************************************************************************
Function : renderNonLinearSA
Purpose  : Renders the non linear spectrum analyser
Parameters : pointer to visualisation module
Returns : 0 if successful, 1 if visualization should end.
Author  : JMattila    
******************************************************************************/
int renderNonLinearSA(struct winampVisModule *this_mod)
{
	
	int x,i,amo;
	double left_ch,right_ch,y;

	unsigned int equalizer[20] = {9,11,12,13,20,23,28,36,52,60,70,90,110,140,140,150,150,150,150,160}; 
	unsigned int analyzer[20]={1,3,5,7,9,13,19,25,38,58,78,116,156,195,235,274,313,352,391,430};		//analyzer frequency table
	
	// this renderer is hard coded to 20 columns...
	// columns = 20;

/*	Tested SPECTRUM ANALYZER data:  

	<-90hz = 1
	120hz = 3
	185hz = 5
	250hz = 7
	375hz = 9
	500hz = 13
	750hz = 19
	1000hz = 25
	1500hz = 38
	2250hz = 58
	3000hz = 78
	4500hz = 116
	6000hz = 156
	7500hz = 195
	9000hz = 235
	10500hz = 274
	12000hz = 313
	13500hz = 352
	15000hz = 391
	16500hz = 430
*/
    // spectrum analyser
	for (x = 0; x < width; x++)
	{
		left_ch = 0;
		right_ch = 0;

		for (i = -1; i < 2; i++) //little smooth for analyzer -> compute average
		{
			left_ch = left_ch + (this_mod->spectrumData[0][analyzer[x]+i]);   //check both channels
			right_ch = right_ch + (this_mod->spectrumData[1][analyzer[x]+i]);  
		}

		left_ch = left_ch / 3;
		right_ch = right_ch / 3;
		
		if (left_ch > right_ch)				//select higher value
			y = left_ch * equalizer[x]/100*1.1;
		else
			y = right_ch * equalizer[x]/100*1.1;

											//FUTURE:
											//check previous data value if big fall
											//draw --> Fall off

		amo = AdjustFalloff(x, y);
		
		MapToLCD(x, amo);
	}

	line1[width] = '\0';
	line2[width] = '\0';
	line3[width] = '\0';
	line4[width] = '\0';

	spec_analyser_data_func(line1, line2, line3, line4);

	return 0;
}


/******************************************************************************
Function : AdjustFalloff
Purpose  : Spectrum Analyser Falloff Code  
Parameters : x     : column position
             value : spectrum analyser value at position x
Returns : adjusted value as integer
Author  : Zlatko Novak / Markus Zehnder
******************************************************************************/
int AdjustFalloff(int x, double value)
{
	double adjusted;

	if (!falloff) {
		return (int)value;
	}

	if (darrFalloff[x] - dFalloffValue > value)
	{
		adjusted = darrFalloff[x] - dFalloffValue;
	} else {
		adjusted = value;
	}

	//Check to see if the previous falloff was huge. - James Maher 2002/01/15
	//if so cut off the huge values. (bars seem stuck on max otherwise) 
	//(takes a long time to change back to <= 16)
	// Added by James Maher
	if (darrFalloff[x] >= 26)
	{ 
		darrFalloff[x] = 25; 
	} else { 
		//isn't hugely out of range, update to correct value
		darrFalloff[x] = adjusted;
	}

	return (int)adjusted;
}

/******************************************************************************
Function : MapToLCD
Purpose  : Map data value of current x position to LCD output lines and convert 
           min and max values to existing character in LCD char map (0 = space,
		   8 = 0xff (=block graphic))
Parameters : x     : column position
             value : spectrum analyser value at position x
Returns : -
Author  : JMattila
******************************************************************************/
void MapToLCD(int x, int value)
{
	char cBlock = '\xff';
	char *linebuffer[4];  // buffer for 4 char*
	int  i;

	linebuffer[0] = line1;
	linebuffer[1] = line2;
	linebuffer[2] = line3;
	linebuffer[3] = line4;

	cBlock = 8;

	switch (height)
	{
	case 1:
		if (value > 8)
		{ value = 8;}
		break;
	case 2:
		if (value > 16)
		{ value = 16;}
		break;
	case 3:
		if (value > 24)
		{ value = 24;}
		break;
	default:
		if (value > 32)
		{ value = 32;}
		break;
	}


	switch (value / 8)
	{
	case 0:
		if (value == 0)
			linebuffer[0][x] = ' ';
		else
			linebuffer[0][x] = value;
		
		for(i=1; i < height; i++)
		{
			linebuffer[i][x] = ' ';
		}
		break;
	case 1:
		linebuffer[0][x] = cBlock;
		if (value == 8)
			linebuffer[1][x] = ' ';
		else
			linebuffer[1][x] = value - 8;

		for(i=2; i<height; i++)
		{
			linebuffer[i][x] = ' ';
		}
		break;
	case 2:
		linebuffer[0][x] = cBlock;
		linebuffer[1][x] = cBlock;
		if (value == 16)
			linebuffer[2][x] = ' ';
		else
			linebuffer[2][x] = value - 16;

		for(i=3; i<height; i++)
		{
			linebuffer[i][x] = ' ';
		}
		break;
	case 3:
		linebuffer[0][x] = cBlock;
		linebuffer[1][x] = cBlock;
		linebuffer[2][x] = cBlock;
		if (value == 24)
			linebuffer[3][x] = ' ';
		else
			linebuffer[3][x] = value - 24;

		break;
	case 4:
		linebuffer[0][x] = cBlock;
		linebuffer[1][x] = cBlock;
		linebuffer[2][x] = cBlock;
		linebuffer[3][x] = cBlock;
		break;
	}
}

//****************************************************************************
// Internal Functions for VUMeter
//****************************************************************************
int renderVUChars(struct winampVisModule *this_mod)
{
	int iChan, iSpace, iBar, ivuwidth;
	
	// 2 Zeichen weniger als Spaltenbreite, da wir noch die eckigen Klammern haben
	if (width > 40)	{ ivuwidth = 40-2; }
	else { ivuwidth = width - 2; }

	// Wipe the old VU table.
	for (iSpace = 0; iSpace < ivuwidth; iSpace++)  { gcVUString[iSpace] = ' '; }
	
	// Get waveform data and combine it into a single channel if needed.
	// The function getVULevel() returns a level from 0 to (4*cwidth) in
	// iSpace, which is then divided into a bar position and the number of
	// "space" characters before it.

	for (iChan = 0; iChan < 2; iChan++)
	{
		//getVULevel(iChan, 4 * lcdCharWidth, &iSpace, this_mod);		
		getVULevel(iChan, (ivuwidth / 2) * lcdCharWidth, &iSpace, this_mod);		
		iBar = iSpace % lcdCharWidth;
		iSpace = (iSpace - iBar) / lcdCharWidth;
		
		if (0 == iChan)
		{
			gcVUString[(ivuwidth / 2 - 1) - iSpace] = (char) iBar;
		}
		else
		{
			switch( iBar ) // Balken tauschen
			{
				case 1:
					iBar = 5;
					break;
				case 2:
					iBar = 4;
					break;
				case 4:
					iBar = 2;
					break;
				case 5:
					iBar = 1;
					break;
			}
			gcVUString[(ivuwidth/2) + iSpace] = (char) iBar;
		}
	}

	return 0;
}

/* FV: in Vorbereitung 
int renderOChars(struct winampVisModule *this_mod)
{
	unsigned char cRawData[2][48], cCustom[8];
	int iChar, iData, iRow, iBase, iBitmap[48][8];
	int iCWidth = lcdCharWidth;

	int x, y=0;
	unsigned char tmp[16];

	// Get waveform data and combine it into a single channel if needed.

	getWaveData(0, 8 * iCWidth, 6, cRawData[0], this_mod);
	getWaveData(1, 8 * iCWidth, 6, cRawData[1], this_mod);
	if (this_mod->nCh > 1)
	{
		for (iData = 0; iData < 8 * iCWidth; iData++)
		{
			cRawData[0][iData] = (char) ((cRawData[0][iData] + cRawData[1][iData]) / 2);
		}
	}

	// Generate a 1s-and-0s bitmap of the wave.  Since it's only 8 characters
	// tall, I don't bother connecting extremes - if I started supporting
	// graphical LCDs, however, this could get more interesting.

	for (iData = 0; iData < (iCWidth * 8); iData++)
	{
		iBitmap[iData][0] = (cRawData[0][iData] == 7) ? 1 : 0;
		iBitmap[iData][1] = (cRawData[0][iData] == 6) ? 1 : 0;
		iBitmap[iData][2] = (cRawData[0][iData] == 5) ? 1 : 0;
		iBitmap[iData][3] = (cRawData[0][iData] == 4) ? 1 : 0;
		iBitmap[iData][4] = (cRawData[0][iData] == 3) ? 1 : 0;
		iBitmap[iData][5] = (cRawData[0][iData] == 2) ? 1 : 0;
		iBitmap[iData][6] = (cRawData[0][iData] == 1) ? 1 : 0;
		iBitmap[iData][7] = (cRawData[0][iData] == 0) ? 1 : 0;
	}

	// Break the bitmap down into 8 custom chars and upload them.

	for (iChar = 0; iChar < 8; iChar++)
	{
		for (iRow = 0; iRow < 8; iRow++)
		{
			iBase = iChar * iCWidth;
			if (5 == iCWidth)
			{
				cCustom[iRow] = (char) (
					(iBitmap[iBase][iRow] << 4) |
					(iBitmap[iBase + 1][iRow] << 3) |
					(iBitmap[iBase + 2][iRow] << 2) |
					(iBitmap[iBase + 3][iRow] << 1) |
					(iBitmap[iBase + 4][iRow])
					);
			}
			else
			{
				cCustom[iRow] = (char) (
					(iBitmap[iBase][iRow] << 5) |
					(iBitmap[iBase + 1][iRow] << 4) |
					(iBitmap[iBase + 2][iRow] << 3) |
					(iBitmap[iBase + 3][iRow] << 2) |
					(iBitmap[iBase + 4][iRow] << 1) |
					(iBitmap[iBase + 5][iRow])
					);
			}
		}
		// ToDo FV: Set the custom characters
	}

	return 0;
}
*/

/******************************************************************************
Function : renderVuMeter
Purpose  : Renders the linear spectrum analyser
Parameters : pointer to visualisation module
Returns : 0 if successful, 1 if visualization should end.
Author  : Frank Verhamme    
******************************************************************************/
int renderVuMeter(struct winampVisModule *this_mod)
{
	char buffer[40]; // max. 40 Spalten
	int ivuwidth, iSpace;
	
	if (width > 40)
		ivuwidth = 40;
	else
		ivuwidth = width;

	iRendering = 1;

	buffer[0] = '[';
	buffer[ivuwidth-1] = ']';
	buffer[ivuwidth] = '\0';
	for (iSpace = 1; iSpace <= ivuwidth-2; iSpace++)  { buffer[iSpace] = ' '; }
/* FV: In Vorbereitung
	if ( 1 == (int)this_mod->userData)
	{
		if (0 != renderOChars(this_mod))
		{
			MessageBox(this_mod->hwndParent, "renderVUChars() failed in renderVUMeter()", "vis_spac_analyser error", MB_OK | MB_ICONEXCLAMATION);
			return 1;
		}
	}
*/
	if( 2 == (int)this_mod->userData)
	{
		if (0 == renderVUChars(this_mod))
		{
			memmove(&(buffer[1]), gcVUString, (ivuwidth - 2) * sizeof(char));
		}
	}
	
	strncpy(line1,buffer,ivuwidth);
	line1[ivuwidth] = '\0';

	spec_analyser_vudata_func(line1);

	iRendering = 0;

	return ((1 == iRunning) ? 0 : 1);
}

// quit.
// Destroys the window, unregisters the window class
void quit(struct winampVisModule *this_mod)
{
  spec_analyser_stop_func();
  FreeLibrary(hGenLcdDll);
  iRunning = 0;
}

