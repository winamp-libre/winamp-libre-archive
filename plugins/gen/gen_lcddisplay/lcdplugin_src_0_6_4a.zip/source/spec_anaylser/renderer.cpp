//****************************************************************************
// vis_lcdriver: A Winamp 2.x Visualization plugin to display visualizations
//               info on an LCDriver 1.2b-compatible external display.
// Code (C) 2000 Ryan Myers <borisian@planetquake.com>.  All rights reserved.
//****************************************************************************

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <math.h>
#include "spec_analyser.h"

#include "renderer.h"

//----------------------------------------------------------------------------
// void getSpectData(int iChannel, int iSections, int iRange,
//				  unsigned char *cHeights, const winampVisModule *data)
//
// Parses through the spectrum data for channel iChannel (0 = Left, 1 = Right)
// and averages a fraction of the spectrum down to iSections levels of height
// 0 to 7, stored in the array cHeights.  iRange sets how much of the spectrum
// is sampled per section - 1 does the full 576 units, 2 does 288, 4 for 144,
// and so on.  iAmp sets what height the channels are averaged to - all values
// are multiplied by it.  1 is equivalent to an unaltered average.
//----------------------------------------------------------------------------

void getSpectData(int iChannel, int iSections, int iRange,
				  unsigned char *cHeights, const winampVisModule *data)
{
	int i, j, step;
	double sum;
	unsigned char max;

	if (NULL == data)  { return; }

	max = 0;
	step = 576 / (iRange * iSections);
	for (i = 0; i < iSections; i++)
	{
		sum = 0.0;
		for (j = i * step; j < (i + 1) * step; j++)
		{
			sum += (double) data->spectrumData[iChannel][j];
		}
		cHeights[i] = (unsigned char) (sum / ((double) step));
		if (cHeights[i] > max)  { max = cHeights[i]; }
	}
	
	if (max != 0)
	{
		for (i = 0; i < iSections; i++)
		{
			cHeights[i] = (unsigned char) (cHeights[i] * 7 / max);
		}
	}

}

//----------------------------------------------------------------------------
// void getWaveData(int iChannel, int iSections, int iRange, int iAmp, 
//				    unsigned char *cHeights, const winampVisModule *data)
//
// Parses through the spectrum data for channel iChannel (0 = Left, 1 = Right)
// and averages a fraction of the spectrum down to iSections levels of height
// 0 to 7, stored in the array cHeights.  iRange sets how much of the spectrum
// is sampled per section - 1 does the full 576 units, 2 does 288, 4 for 144,
// and so on.  iAmp sets what height the channels are averaged to - all values
// are multiplied by it.  1 is equivalent to an unaltered average.
//----------------------------------------------------------------------------

void getWaveData(int iChannel, int iSections, int iRange,
				 unsigned char *cHeights, const winampVisModule *data)
{
	int i, j, step;
	double sum;
	unsigned char max;

	if (NULL == data)  { return; }

	max = 0;
	step = 576 / (iRange * iSections);
	for (i = 0; i < iSections; i++)
	{
		sum = 0.0;
		for (j = i * step; j < (i + 1) * step; j++)
		{
			sum += (double) (data->waveformData[iChannel][j]);
		}
		cHeights[i] = (unsigned char) (sum / ((double) step));
		if (cHeights[i] > max)  { max = cHeights[i]; }
	}
	
	if (max != 0)
	{
		for (i = 0; i < iSections; i++)
		{
			cHeights[i] = (unsigned char) (cHeights[i] * 7 / max);
		}
	}

}

//----------------------------------------------------------------------------
// void getVULevel(int iChannel, int iMaxLevel, const winampVisModule *data)
//
// Parses through the spectrum data for channel iChannel (0 = Left, 1 = Right)
// and returns the VU meter level for that channel represented as a range from
// 0 to iMaxLevel.  iMaxLevel should be no greater than 128!
//----------------------------------------------------------------------------

void getVULevel(int iChannel, int iMaxLevel, int *iResult, const winampVisModule *data)
{
	int iData, iTotal, iLast;

	if (NULL == data)  { return; }

	iTotal = 0;
	iLast = data->waveformData[iChannel][0];

	for (iData = 0; iData < 576; iData++)
	{
		iTotal += abs(iLast - data->waveformData[iChannel][iData]);
		iLast = data->waveformData[iChannel][iData];
	}
	if ((iTotal = iTotal / 288) > 127)  { iTotal = 127; }

	// Scale it down to the range of the characters and choose the
	// custom character to use.  Set the appropriate location.

	if (NULL != iResult)
	{
		*iResult = (int) (((double) iTotal) / (128.0 / (double) iMaxLevel) + 1);
		// Die + 1 ben�tigen wir, da wir die Zeichen 1-8 verwenden!!!
	}
}
