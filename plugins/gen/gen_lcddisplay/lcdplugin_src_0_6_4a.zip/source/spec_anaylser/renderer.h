//****************************************************************************
// vis_lcdriver: A Winamp 2.x Visualization plugin to display visualizations
//               info on an LCDriver 1.2b-compatible external display.
// Code (C) 2000 Ryan Myers <borisian@planetquake.com>.  All rights reserved.
//****************************************************************************

#ifndef  _RENDERER_H_
#define  _RENDERER_H_

#include "spec_analyser.h"

#ifdef __cplusplus
extern "C" {
#endif

extern void getSpectData(int iChannel, int iSections, int iRange,
						 unsigned char *cHeights, const winampVisModule *data);
extern void getWaveData(int iChannel, int iSections, int iRange,
						unsigned char *cHeights, const winampVisModule *data);
extern void getVULevel(int iChannel, int iMaxLevel, int *iResult,
					   const winampVisModule *data);

#ifdef __cplusplus
}
#endif

#endif //_RENDERER_H_