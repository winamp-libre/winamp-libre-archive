// InputSerial.h: interface for the CInputSerial class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUTSERIAL_H__3EE303AD_E12A_4466_B99A_9CF605400712__INCLUDED_)
#define AFX_INPUTSERIAL_H__3EE303AD_E12A_4466_B99A_9CF605400712__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "InputLCD.h"


class CInputSerial : public CInputLCD 
{

public:
	CInputSerial();
	virtual ~CInputSerial();

// Overrides
public:
	virtual BOOL ReadConfig(LPCSTR lpIniFile);
	virtual BOOL WriteConfig(LPCSTR lpIniFile);
	virtual BOOL InitDevice();
};

#endif // !defined(AFX_INPUTSERIAL_H__3EE303AD_E12A_4466_B99A_9CF605400712__INCLUDED_)
