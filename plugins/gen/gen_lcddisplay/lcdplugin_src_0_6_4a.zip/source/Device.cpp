/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Device.cpp: implementation of the CDevice class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "Device.h"
#include "Input.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevice::CDevice()
{
	m_bOpen = FALSE;
	m_bInit = FALSE;

	// check if we're running under NT: some devices need special handling for NT!
	OSVERSIONINFO versionInfo;
	versionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	::GetVersionEx(&versionInfo);
	m_bWinNT = (versionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT);

	m_bMicroTiming = m_cTiming.Available();
	m_pcInput = NULL;
}

CDevice::~CDevice()
{

}

BOOL CDevice::IsOpen()
{
	return m_bOpen;
}

BOOL CDevice::Close()
{
	m_bOpen = FALSE;
	
	if (m_pcInput) {
		m_pcInput->CloseDevice();
	}

	return TRUE;
}

void CDevice::uPause(int usecs)
{
	m_cTiming.uPause(usecs);
}

void CDevice::SetInputDevice(CInput *pcIn)
{
	m_pcInput = pcIn;
}
