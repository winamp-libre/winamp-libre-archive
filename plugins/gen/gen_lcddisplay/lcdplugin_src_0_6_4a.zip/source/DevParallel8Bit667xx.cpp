/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallel.cpp: implementation of the CDevParallel8Bit667xx class.
//
// Modifications:
// 2002/11/10 MZ  initial version. Init sequence provided by Rene Donner
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DevParallel8Bit667xx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

// commands for WriteData
#define RS_DATA     0x00
#define RS_INSTR    0x01

#define HD667xx_CLEAR       0x01
#define HD667xx_HOMECURSOR  0x02
#define HD667xx_MODESET     0x04
#define HD667xx_ONOFF       0x08
#define HD667xx_EXTFUNC     0x08          
#define HD667xx_CURSORSHIFT 0x10
#define HD667xx_SCROLL_EN   0x10
#define HD667xx_SETCGRAM    0x40
#define HD667xx_SETSEGRAM   0x40
#define HD667xx_SETDDRAM    0x80

#define HD667xx_FUNCSET     0x20
#define HD667xx_IF_8BIT     0x10



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevParallel8Bit667xx::CDevParallel8Bit667xx()
{
}

CDevParallel8Bit667xx::~CDevParallel8Bit667xx()
{

}

BOOL CDevParallel8Bit667xx::Open(LPCSTR lpPort, LPCSTR lpParam)
{
	if (!CDevParallel::Open(lpPort, lpParam))
		return FALSE;

	// setup the lcd in 8 bit mode
	uPause(m_delayInit);
	senddata (0, RS_INSTR, HD667xx_FUNCSET | HD667xx_IF_8BIT);
	uPause(m_delayInit);
	senddata (0, RS_INSTR, HD667xx_FUNCSET | HD667xx_IF_8BIT);
	uPause (m_delayLong);
	senddata (0, RS_INSTR, HD667xx_FUNCSET | HD667xx_IF_8BIT);
	uPause (m_delayLong);
	senddata (0, RS_INSTR, HD667xx_FUNCSET | HD667xx_IF_8BIT | 0x08);
	uPause (m_delayLong);
	senddata (0, RS_INSTR, HD667xx_ONOFF);
	uPause (m_delayLong);
	senddata (0, RS_INSTR, HD667xx_ONOFF | 0x04);  //cursor off
	uPause (m_delayLong);
	senddata (0, RS_INSTR, HD667xx_MODESET | 0x02);
	uPause (m_delayLong);
	senddata (0, RS_INSTR, HD667xx_FUNCSET | HD667xx_IF_8BIT | 0x07 | 0x04);
	uPause (m_delayLong);
	senddata (0, RS_INSTR, HD667xx_EXTFUNC | 0x01);
	uPause (m_delayLong);
	senddata (0, RS_INSTR, HD667xx_FUNCSET | HD667xx_IF_8BIT | 0x08);
	uPause (m_delayLong);

	senddata (0, RS_INSTR, HD667xx_CLEAR);
	uPause (m_delayLong);

	if (have_keypad) {
		// Remember which input lines are stuck
		stuckinputs = readkeypad (0);
	}

	m_bOpen = TRUE;

	return TRUE;
}