#if !defined(AFX_DLGHIDDEN_H__EF44B0DA_BF9D_4520_9682_2F4B24608837__INCLUDED_)
#define AFX_DLGHIDDEN_H__EF44B0DA_BF9D_4520_9682_2F4B24608837__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgHidden.h : header file
//

#include "TreeCtrlSer.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgHidden dialog

class CDlgHidden : public CDialog
{
// Construction
public:
	CDlgHidden(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgHidden)
	enum { IDD = IDD_HIDDENDIALOG };
	CTreeCtrlSer	m_Tree;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgHidden)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgHidden)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGHIDDEN_H__EF44B0DA_BF9D_4520_9682_2F4B24608837__INCLUDED_)
