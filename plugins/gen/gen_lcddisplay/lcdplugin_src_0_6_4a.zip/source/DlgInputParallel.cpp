/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Parallel port input driver configuration dialog
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/02/09 MZ  extended input (default/menu/set actions)
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgInputParallel.h"
#include "DlgInputAdd.h"
#include "DevParallel44780.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInputParallel property page

IMPLEMENT_DYNCREATE(CDlgInputParallel, CPropertyPage)

CDlgInputParallel::CDlgInputParallel() : CDlgInput(CDlgInputParallel::IDD)
{
	//{{AFX_DATA_INIT(CDlgInputParallel)
	m_bLCDPort = FALSE;
	m_csPort = _T("");
	//}}AFX_DATA_INIT
}

CDlgInputParallel::~CDlgInputParallel()
{
}

void CDlgInputParallel::DoDataExchange(CDataExchange* pDX)
{
	CDlgInput::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInputParallel)
	DDX_Control(pDX, IDC_COMBO_TYPE, m_TypeCB);
	DDX_Check(pDX, IDC_CHECK_LCDPA_PORT, m_bLCDPort);
	DDX_CBString(pDX, IDC_COMBO_PORT, m_csPort);
	DDX_Check(pDX, IDC_PARALLEL_ENABLED, m_bEnabled);
	DDX_Control(pDX, IDC_LIST, m_cList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInputParallel, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgInputParallel)
	ON_BN_CLICKED(IDC_CHECK_LCDPA_PORT, OnCheckLcdPort)
	ON_BN_CLICKED(IDC_BTN_ADD, OnBtnAdd)
	ON_BN_CLICKED(IDC_BTN_DEL, OnBtnDel)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, OnButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_OPEN, OnButtonOpen)
	ON_BN_CLICKED(IDC_BTN_PAR_EDIT, OnBtnEdit)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST, OnDblclkList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInputParallel message handlers

BOOL CDlgInputParallel::OnInitDialog() 
{
	CDlgInput::OnInitDialog();

	CString  csBuf;
	
	ListView_SetExtendedListViewStyle 
		(m_cList.m_hWnd, LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT );

	// add columns
	csBuf.LoadString(IDS_CFG_SERIAL_BUTTON);
	m_cList.InsertColumn( 0, csBuf);

	csBuf.LoadString(IDS_CFG_SERIAL_ACTION);
	m_cList.InsertColumn( 1, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_MENU);
	m_cList.InsertColumn(2, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_SET);
	m_cList.InsertColumn(3, csBuf);

	m_bEnabled = g_Config.bInParallelEnabled;
	m_bLCDPort = g_Config.bInParallelLCDport;
	m_csPort = g_Config.szInParallelPort;

	csBuf.LoadString(IDS_PTYPE_8B);
	m_TypeCB.AddString(csBuf);
	csBuf.LoadString(IDS_PTYPE_4B);
	m_TypeCB.AddString(csBuf);
	csBuf.LoadString(IDS_PTYPE_SREG);
	m_TypeCB.AddString(csBuf);

	switch (g_Config.byInParallelInterface) {
	  case IF_SHIFTREG :
		m_TypeCB.SetCurSel(2);
		break;
	  case IF_4BIT :
		m_TypeCB.SetCurSel(1);
		break;
	  default :
		m_TypeCB.SetCurSel(0);
	}
	
	// check if active driver supports key pads
	if (g_LCD->GetParallelDevice() == NULL) {
		GetDlgItem(IDC_CHECK_LCDPA_PORT)->EnableWindow(FALSE);
		m_bLCDPort = FALSE;
	}

	UpdateData(FALSE);

	CString   key;
	INPUT_BTN *btn;

	for (POSITION pos = g_Config.mapInParallel.GetStartPosition(); pos != NULL; ){
		g_Config.mapInParallel.GetNextAssoc( pos, key, (void*&)btn );
		m_mapInput.SetAt(key, btn);
	}


	RefreshList();
	m_cList.AutoSizeColumns();		

	OnCheckLcdPort();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgInputParallel::OnApply() 
{
	g_Config.bInParallelEnabled = m_bEnabled;
	g_Config.bInParallelLCDport = m_bLCDPort;
	strcpy(g_Config.szInParallelPort, m_csPort);

	int i = m_TypeCB.GetCurSel();

	if (i != CB_ERR) {
		switch (i) {
			case 2: g_Config.byInParallelInterface = IF_SHIFTREG; break;
			case 1: g_Config.byInParallelInterface = IF_4BIT; break;
			default: g_Config.byInParallelInterface = IF_8BIT; 
		}
	}

	CString   key;
	INPUT_BTN *btn;

	// @todo check for memory leak
	g_Config.mapInParallel.RemoveAll();

	for (POSITION pos = m_mapInput.GetStartPosition(); pos != NULL; ){
		m_mapInput.GetNextAssoc( pos, key, (void*&)btn );
		g_Config.mapInParallel.SetAt(key, btn);
	}

	return CDlgInput::OnApply();
}

void CDlgInputParallel::OnBtnAdd() 
{
	CDlgInput::OnAdd();
}

void CDlgInputParallel::OnBtnDel() 
{
	CDlgInput::OnDelete();
}

void CDlgInputParallel::OnButtonClose() 
{
	g_InParallel.CloseDevice();	
}

void CDlgInputParallel::OnButtonOpen() 
{
	OnApply();

	g_InParallel.InitDevice();	
}

void CDlgInputParallel::OnCheckLcdPort() 
{
	UpdateData(TRUE);

	GetDlgItem(IDC_COMBO_PORT)->EnableWindow(!m_bLCDPort);
	GetDlgItem(IDC_COMBO_TYPE)->EnableWindow(!m_bLCDPort);
//	GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(!m_bLCDPort);
//	GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(!m_bLCDPort);

	if (m_bLCDPort && g_LCD->GetParallelDevice() == NULL) {
		AfxMessageBox(IDS_ERR_NO_PARALLEL_IN_SUPPORT);
	}
}


void CDlgInputParallel::OnBtnEdit() 
{
	CDlgInput::OnEdit();
}

void CDlgInputParallel::OnDblclkList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnEdit();
	
	*pResult = 0;
}
