// InputKeyboard.h: interface for the CInputKeyboard class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUTKEYBOARD_H__4A835842_B81B_461D_8CD9_92A170F97F45__INCLUDED_)
#define AFX_INPUTKEYBOARD_H__4A835842_B81B_461D_8CD9_92A170F97F45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Input.h"

#define DEF_LONGKEYPRESS_TIME  200

class CInputKeyboard : public CInput  
{
protected:
	int   m_iLastKey;
	long  m_lKeypressTime;
	long  m_lTimeoutLong;
	BOOL  m_bLongProcessed;

public:
	CInputKeyboard();
	virtual ~CInputKeyboard();

// Overrides
public:
	virtual BOOL CloseDevice();
	virtual BOOL ReadConfig(LPCSTR lpIniFile);
	virtual BOOL WriteConfig(LPCSTR lpIniFile);
	virtual BOOL InitDevice();

protected:
	virtual BOOL HandleKey(int key, long lHoldTime);
	void ClearMap();
	static LRESULT CALLBACK KeyboardHook(int code, WPARAM wParam, LPARAM lParam);
};

#endif // !defined(AFX_INPUTKEYBOARD_H__4A835842_B81B_461D_8CD9_92A170F97F45__INCLUDED_)
