/////////////////////////////////////////////////////////////////////////////
//
// Volume.h: interface for the CVolume class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VOLUME_H__45923F81_BC59_11D3_8F31_0000E871C360__INCLUDED_)
#define AFX_VOLUME_H__45923F81_BC59_11D3_8F31_0000E871C360__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "VolumeOutMaster.h"
#include "VolumeOutWave.h"


#define VOLUME_MASTER		0
#define VOLUME_WAVE			1
#define VOLUME_COMBINE		2


class CVolume  
{
public:
	static BYTE   m_bySource, m_byMaster, m_byWave;
	static PBYTE  m_pbyVolume;
	static DWORD  m_dwMasterVolume;
	static DWORD  m_dwWaveVolume;
	static DWORD  m_dwMasterMin, m_dwMasterMax, m_dwWaveMin, m_dwWaveMax;

protected:
	BYTE	m_byMasterVol, m_byWaveVol;
	IVolume *m_pcMasterVolume;
	IVolume *m_pcWaveVolume;

public:
	void SetCallbackVar(PBYTE pbyVolume, BYTE type);
	CVolume();
	virtual ~CVolume();

	void setType( BYTE type );
	BYTE getVolume();

	static void CALLBACK VolumeChanged( DWORD dwCurrentVolume, DWORD dwUserValue );
};

#endif // !defined(AFX_VOLUME_H__45923F81_BC59_11D3_8F31_0000E871C360__INCLUDED_)
