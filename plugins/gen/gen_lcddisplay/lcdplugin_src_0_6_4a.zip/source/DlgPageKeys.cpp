/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2000 Frank Verhamme. All Rights Reserved.
//
//  This file is part of the WinAmp Serial LCD Display Plugin.
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgPageKeys.cpp:   Keys property page
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgPageKeys.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPageKeys property page

IMPLEMENT_DYNCREATE(CDlgPageKeys, CPropertyPage)

CDlgPageKeys::CDlgPageKeys() : CPropertyPage(CDlgPageKeys::IDD)
{
	//{{AFX_DATA_INIT(CDlgPageKeys)
  m_bEnableKeypad = TRUE;
	//}}AFX_DATA_INIT
}

CDlgPageKeys::~CDlgPageKeys()
{
}

void CDlgPageKeys::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPageKeys)
  DDX_Check(pDX, IDC_ENABLE_KEYPAD, m_bEnableKeypad);
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPageKeys, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgPageKeys)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPageKeys message handlers

BOOL CDlgPageKeys::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

  m_bEnableKeypad  = g_Config.bEnableKeypad;

  UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgPageKeys::OnApply() 
{
	g_Config.bEnableKeypad = m_bEnableKeypad;
	
	return CPropertyPage::OnApply();
}
