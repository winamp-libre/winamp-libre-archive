// InputLCD.h: interface for the CInputLCD class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUTLCD_H__213A6D34_48C0_456B_AA05_19474FFB7885__INCLUDED_)
#define AFX_INPUTLCD_H__213A6D34_48C0_456B_AA05_19474FFB7885__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Input.h"
#include "Device.h"

class CInputLCD : public CInput  
{
protected:
	BYTE			m_InpLen;
	BOOLEAN			m_bExit;
	BYTE			m_byStart;
	BYTE			m_byEnd;
	HANDLE			m_hThread;
	DWORD			m_dwThreadID;
	DWORD			m_dwPollIntervall;
	BOOL			m_bUseLCDport;
	CDevice		    *m_pcDev;
//	CStringArray	*m_pInputs;
//	CDWordArray		*m_pActions;
	CMapStringToPtr *m_pmapInput;

public:
	virtual void SetInputLen(BYTE length);
	virtual void SetEndCharacter(BYTE end);
	virtual void SetStartCharacter(BYTE start);
	CInputLCD();
	virtual ~CInputLCD();

	virtual BOOL CloseDevice();

protected:
	virtual BOOL HandleInput(LPCSTR lpInput);
	static DWORD WINAPI ReaderThread(LPVOID);

};

#endif // !defined(AFX_INPUTLCD_H__213A6D34_48C0_456B_AA05_19474FFB7885__INCLUDED_)
