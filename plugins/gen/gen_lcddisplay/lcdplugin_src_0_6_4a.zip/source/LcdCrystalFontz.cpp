/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2001 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//

/////////////////////////////////////////////////////////////////////////////
//
// LcdCrystalFontz.cpp: implementation of the CLcdCrystalFontz class.
//
//////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2002/01/10 MZ  backlight timeout added, generic getter methods are now in the base class
// 2003/01/26 MZ  allocating m_pcDev and setting m_pInstance for backlight timer in Open()
// 2003/07/13 MZ  custom character map added 
// 2003/11/02 MZ  saving cfg in Close(), correct line feed handling
//
// CVS: $Author: mrzed $, $Revision: 1.8 $, $Date: 2003/11/03 00:04:01 $
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "LcdCrystalFontz.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define CF_SECTION	"Crystalfontz"
#define CF_CHARMAP  "Crystalfontz_CHARMAP"

#define MAX_CUSTOM_CHARS		8

CCfgCF	 g_CFCfg;

CCfgCF::CCfgCF()
{
	Load(g_szIniFile);
}

CCfgCF::~CCfgCF()
{
	Save(g_szIniFile);
}

void CCfgCF::Load(LPCSTR lpIniFile)
{
	GetPrivateProfileString( CF_SECTION, "ComPort", DEF_COMPORT_CF, szComPort, MAX_COMPORT_STRLEN, lpIniFile);
	GetPrivateProfileString( CF_SECTION, "BaudRate", DEF_BAUDRATE_CF, szBaudRate, MAX_BAUDRATE_STRLEN, lpIniFile);
	bBlink =	   GetPrivateProfileInt(CF_SECTION,"SetBlink",0,lpIniFile); 
	bScroll =	   GetPrivateProfileInt(CF_SECTION,"SetScroll",0,lpIniFile); 
	bShowCursor = GetPrivateProfileInt(CF_SECTION,"Cursor",0,lpIniFile); 
	bWrap =	   GetPrivateProfileInt(CF_SECTION,"Wrap",1,lpIniFile); 	
	iCols =       GetPrivateProfileInt(CF_SECTION,"Columns",20,lpIniFile); 			 
	iRows =	   GetPrivateProfileInt(CF_SECTION,"Rows",4,lpIniFile); 
	byContrast = (BYTE)GetPrivateProfileInt(CF_SECTION,"Contrast", DEF_CONTRAST_CF,lpIniFile); 
	byBrightness = (BYTE)GetPrivateProfileInt(CF_SECTION,"Brightness", DEF_BRIGHTNESS_CF,lpIniFile); 
	BuildCharMap(CF_CHARMAP, lpIniFile, charMap);
}

void CCfgCF::Save(LPCSTR lpIniFile)
{
	char string[32];

	WritePrivateProfileString( CF_SECTION, "ComPort", szComPort, lpIniFile);
	WritePrivateProfileString( CF_SECTION, "BaudRate", szBaudRate, lpIniFile);
	wsprintf(string,"%d",bBlink);
	WritePrivateProfileString(CF_SECTION,"SetBlink",string,lpIniFile);
	wsprintf(string,"%d",bScroll);
	WritePrivateProfileString(CF_SECTION,"SetScroll",string,lpIniFile);
	wsprintf(string,"%d",bShowCursor);
	WritePrivateProfileString(CF_SECTION,"Cursor",string,lpIniFile);
	wsprintf(string,"%d",bWrap);
	WritePrivateProfileString(CF_SECTION,"Wrap",string,lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(CF_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(CF_SECTION,"Rows",string,lpIniFile);
	wsprintf(string,"%d",byContrast);
	WritePrivateProfileString(CF_SECTION,"Contrast",string,lpIniFile);
	wsprintf(string,"%d",byBrightness);
	WritePrivateProfileString(CF_SECTION,"Brightness",string,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdCrystalFontz::CLcdCrystalFontz()
{
	m_pcDev = NULL;
}

CLcdCrystalFontz::~CLcdCrystalFontz()
{
	Close();

	if (m_pcDev != NULL)
		delete m_pcDev;
}

void  CLcdCrystalFontz::SetBacklight(short nSeconds)
{
	short nBrightness = m_nBrightness;

	WriteData(14);

	if (nSeconds < 0)
	{
		nBrightness = 0;
	}
	else 
	{
		// TODO test timer functions !!!
		if (nSeconds > 0)
			StartBacklightTimer(nSeconds);
	}

	WriteData( (BYTE)nBrightness );
	m_nBackLight = nSeconds;
}

void  CLcdCrystalFontz::SetBlink(BOOL bOn)
{
	WriteData( bOn ? 5 : 4 );
	m_bBlink = bOn;
}

void  CLcdCrystalFontz::Clear()
{
	WriteData( 12 );
}

void  CLcdCrystalFontz::Close()
{
	if (m_pcDev != NULL)
		m_pcDev->Close();
	g_CFCfg.Save(g_szIniFile);
}

BOOL  CLcdCrystalFontz::IsOpen()
{
	if (m_pcDev == NULL)
		return FALSE;

	return m_pcDev->IsOpen();
}

void  CLcdCrystalFontz::SetContrast(short nLevel)
{
	if ((nLevel < 0) || (nLevel > 100))
		return;
	WriteData( 15 );
	WriteData( (BYTE)nLevel );
	m_nContrast = nLevel;
}

void CLcdCrystalFontz::SetBrightness(short nLevel)
{
	if ((nLevel < 0) || (nLevel > 100))
		return;
	WriteData( 14 );
	WriteData( (BYTE)nLevel );
	m_nBrightness = nLevel;
}

void  CLcdCrystalFontz::Cursor(BOOL bOn)
{
	WriteData( bOn ? 5 : 4 );
	m_bCursor = bOn;
}

void  CLcdCrystalFontz::HBar(short nCol, short nRow, short nDir, short nLen)
{
	// not yet implemented
}

void  CLcdCrystalFontz::Home()
{
	WriteData( 1 );
}

void  CLcdCrystalFontz::InitHorizontalBar()
{
//	WriteData( 'h' );
}

void  CLcdCrystalFontz::InitLargeDigit()
{
//	WriteData( 'n' );
}

void  CLcdCrystalFontz::InitVerticalBar()
{
//	WriteData( 'v' );
}

void  CLcdCrystalFontz::LargeDigit(short nCol, short nNumber)
{
//	WriteData( '#' );
//	WriteData( (BYTE)nCol );
//	WriteData( (BYTE)nNumber );
}

void  CLcdCrystalFontz::SetLineWrap(BOOL bOn)
{
	WriteData( bOn ? 23 : 24 );
	m_bLineWrap = bOn;
}

/******************************************************************************
Function : Open
Purpose  : Opens the comport and initilizes the display
Parameters : -
Returns : TRUE if successful, otherwise FALSE
Author  : Markus Zehnder	
******************************************************************************/
BOOL  CLcdCrystalFontz::Open()
{
	char szDef[20];

	// hack for backlight timer
	m_pInstance = this;

	if (m_pcDev == NULL) {
		m_pcDev = new CDevSerial();
	}

	sprintf(szDef, "%d,n,8,1", atoi(g_CFCfg.szBaudRate) );

	if (!m_pcDev->Open(g_CFCfg.szComPort, szDef))
	{
		Close();
		return FALSE;
	}		

	Sleep(2000);
	Clear();
	SetBlink( g_CFCfg.bBlink );
	Cursor( g_CFCfg.bShowCursor );
	SetLineWrap( g_CFCfg.bWrap );
	SetScroll( g_CFCfg.bScroll );

	SetContrast(g_CFCfg.byContrast);
	SetBrightness(g_CFCfg.byBrightness);

	m_charMap = g_CFCfg.charMap;

	return TRUE;
}

void  CLcdCrystalFontz::SetPosition(short nCol, short nRow)
{
	if (nCol < 1 || nRow < 1)
		return;

	nCol--;
	nRow--;

	WriteData( 17 );
	WriteData( (BYTE)nCol );
	WriteData( (BYTE)nRow );
}

void  CLcdCrystalFontz::SetScroll(BOOL bOn)
{
	WriteData( bOn ? 19 : 20 );
	m_bScroll = bOn;
}

void  CLcdCrystalFontz::VBar(short nCol, short nLength)
{
	// not yet implemented
}

void  CLcdCrystalFontz::Write(LPCSTR lpText)
{
	static CString csText;
	csText = lpText;
	ConvertTextToLCDCharset(csText);
	//m_pcDev->WriteData(csText);

	LPCSTR p = (LPCTSTR)csText;
	int len = strlen(p);
	for(int i=0; i<len; i++) {
	  // newlines need special handling MZ 20031102
	  if ((byte)p[i] == 13 || (byte)p[i] == 10) {
		if ((byte)p[i] == 10 && i > 0 && (byte)p[i-1] != 13) {
			m_pcDev->WriteData(13);
		}
		m_pcDev->WriteData(p[i]);
	  } else {
		m_pcDev->WriteData(p[i]);
	  }
	}
}

void CLcdCrystalFontz::WriteData(BYTE byData)
{
	m_pcDev->WriteData(byData);
}

BOOL  CLcdCrystalFontz::CreateCustomChar(short nNumber, CCustomChar &cChar)
{
	if (nNumber > MAX_CUSTOM_CHARS)	
		return FALSE;


	WriteData( 25 );
	WriteData( (BYTE)nNumber );

	int iMax = __min(8, cChar.m_byDataSize);
	for (int i = 0; i < iMax; i++)
	{
		if (cChar.m_byarrData[i] > 31)
			cChar.m_byarrData[i] = 0;	
		WriteData( cChar.m_byarrData[i] );
	}

	for (; i < 8; i++)
	{
		WriteData( 0 );
	}

	return TRUE;
}

short CLcdCrystalFontz::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

LPCTSTR CLcdCrystalFontz::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	
	ch[0] = (char)128;
	csText.Replace( "%c1", ch );
	ch[0] = (char)129;
	csText.Replace( "%c2", ch );
	ch[0] = (char)130;
	csText.Replace( "%c3", ch );
	ch[0] = (char)131;
	csText.Replace( "%c4", ch );
	ch[0] = (char)132;
	csText.Replace( "%c5", ch );
	ch[0] = (char)133;
	csText.Replace( "%c6", ch );
	ch[0] = (char)134;
	csText.Replace( "%c7", ch );
	ch[0] = (char)135;
	csText.Replace( "%c8", ch );

	//added by James Maher
	//check to replace weird analyser data with the correct custom chars
	// otherwise it seems to barf. :)
	csText.Replace( char(1), (char)128 );
	csText.Replace( char(2), (char)129 );
	csText.Replace( char(3), (char)130 );
	csText.Replace( char(4), (char)131 );
	csText.Replace( char(5), (char)132 );
	csText.Replace( char(6), (char)133 );
	csText.Replace( char(7), (char)134 );
	csText.Replace( char(8), (char)135 );
	csText.Replace( '\xff', (char)135 );

	return csText;
}

LPCTSTR CLcdCrystalFontz::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)128;
	csText.Replace( ch, "%c1" );
	ch[0] = (char)129;
	csText.Replace( ch, "%c2" );
	ch[0] = (char)130;
	csText.Replace( ch, "%c3" );
	ch[0] = (char)131;
	csText.Replace( ch, "%c4" );
	ch[0] = (char)132;
	csText.Replace( ch, "%c5" );
	ch[0] = (char)133;
	csText.Replace( ch, "%c6" );
	ch[0] = (char)134;
	csText.Replace( ch, "%c7" );
	ch[0] = (char)135;
	csText.Replace( ch, "%c8" );

	return csText;
}

int	CLcdCrystalFontz::GetRows()	
{
	return g_CFCfg.iRows;
}

int	CLcdCrystalFontz::GetColumns()
{
	return g_CFCfg.iCols;
}


CDevSerial* CLcdCrystalFontz::GetSerialDevice()
{
	return m_pcDev;
}
