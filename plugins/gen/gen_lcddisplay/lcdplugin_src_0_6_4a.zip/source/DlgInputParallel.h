#if !defined(AFX_DLGINPUTPARALLEL_H__0F6AEE0B_C0CC_4D2F_96AC_AA34C52A98E2__INCLUDED_)
#define AFX_DLGINPUTPARALLEL_H__0F6AEE0B_C0CC_4D2F_96AC_AA34C52A98E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInputParallel.h : header file
//

#include "DlgInput.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgInputParallel dialog

class CDlgInputParallel : public CDlgInput
{
	DECLARE_DYNCREATE(CDlgInputParallel)

// Construction
public:
	CDlgInputParallel();
	~CDlgInputParallel();

// Dialog Data
	//{{AFX_DATA(CDlgInputParallel)
	enum { IDD = IDD_INPUT_PARALLEL };
	CComboBox	m_TypeCB;
	BOOL	m_bLCDPort;
	CString	m_csPort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDlgInputParallel)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDlgInputParallel)
	afx_msg void OnCheckLcdPort();
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnAdd();
	afx_msg void OnBtnDel();
	afx_msg void OnButtonClose();
	afx_msg void OnButtonOpen();
	afx_msg void OnBtnEdit();
	afx_msg void OnDblclkList(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINPUTPARALLEL_H__0F6AEE0B_C0CC_4D2F_96AC_AA34C52A98E2__INCLUDED_)
