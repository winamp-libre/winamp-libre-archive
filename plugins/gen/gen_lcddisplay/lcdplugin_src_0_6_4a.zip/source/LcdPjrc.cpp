/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LcdPjrc.cpp: implementation of the CLcdPjrc class.
//
//
// Modifications:
// 2003/01/11 MZ  first basic implementation 
// 2003/01/21 MZ  custom characters implemented (needs latest LCD firmware!)
// 2003/01/25 MZ  switched off wrap & scroll (problems with LCD menu!), backlight implemented
// 2003/01/26 MZ  allocating m_pcDev and setting m_pInstance for backlight timer in Open()
// 2003/07/13 MZ  custom character map added 
// 2003/11/02 MZ  special newline handling
//
// CVS: $Author: mrzed $, $Revision: 1.8 $, $Date: 2003/11/02 21:23:04 $
// 
/////////////////////////////////////////////////////////////////////////////
//
// @todo: better custom char handling: use another font set to allow more than just 8 custom chars!
// 

#include "stdafx.h"
#include "LcdPjrc.h"
#include "gen_lcddisplay.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define PJRC_SECTION	 "PJRC"
#define PJRC_SECTION_MAP "PJRC_CHARMAP"


CCfgPjrc	 g_PjrcCfg;

CCfgPjrc::CCfgPjrc()
{
	//Load(g_szIniFile);
}

CCfgPjrc::~CCfgPjrc()
{
	Save(g_szIniFile);
}

void CCfgPjrc::Load(LPCSTR lpIniFile)
{
	GetPrivateProfileString( PJRC_SECTION, "ComPort", DEF_COMPORT_PJRC, szComPort, MAX_COMPORT_STRLEN, lpIniFile);
	GetPrivateProfileString( PJRC_SECTION, "BaudRate", DEF_BAUDRATE_PJRC, szBaudRate, MAX_BAUDRATE_STRLEN, lpIniFile);
	iCols  =  GetPrivateProfileInt(PJRC_SECTION,"Columns",24,lpIniFile); 			 
	iRows  =  GetPrivateProfileInt(PJRC_SECTION,"Rows",8,lpIniFile); 
	byFont =  (BYTE)GetPrivateProfileInt(PJRC_SECTION,"Font",0,lpIniFile); 
	// default: "0" = use control led on front panel
	// command = '1' control pin 7 on CPU (use with care, may crash non-modified hardware)
	// command = '2' control pin 8 on CPU (use with care, may crash non-modified hardware)
	GetPrivateProfileString( PJRC_SECTION, "BacklightOutCmd", "0", szBackLightOutCmd, 1, lpIniFile);

	BuildCharMap(PJRC_SECTION_MAP, lpIniFile, charMap);
}

void CCfgPjrc::Save(LPCSTR lpIniFile)
{
	char string[32];

	WritePrivateProfileString( PJRC_SECTION, "ComPort", szComPort, lpIniFile);
	WritePrivateProfileString( PJRC_SECTION, "BaudRate", szBaudRate, lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(PJRC_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(PJRC_SECTION,"Rows",string,lpIniFile);
	wsprintf(string,"%d",byFont);
	WritePrivateProfileString(PJRC_SECTION,"Font",string,lpIniFile);
	WritePrivateProfileString(PJRC_SECTION,"BacklightOutCmd",szBackLightOutCmd,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdPjrc::CLcdPjrc()
{
	m_byCmdPrefix = 0x5c; // = '\\'
	m_pcDev = NULL;
}

CLcdPjrc::~CLcdPjrc()
{
	Close();

	if (m_pcDev != NULL)
		delete m_pcDev;
}

void  CLcdPjrc::SetBacklight(short nSeconds)
{
	// use external input/output control for backlight function (protocol version 1 and later only)
	char state = '1';

	WriteCommand(0x4A);

	WriteData(g_PjrcCfg.szBackLightOutCmd[0]);

	if (nSeconds < 0) {
		state = '0';
	} else {
		if (nSeconds > 0)
			StartBacklightTimer(nSeconds);
	}

	WriteData(state);
	m_nBackLight = nSeconds;
}


void  CLcdPjrc::Clear()
{
	WriteCommand( 0x40 );
	WriteData(g_PjrcCfg.byFont + 32);
	WriteData(0x30);
}

void  CLcdPjrc::Close()
{
	if (m_pcDev)
		m_pcDev->Close();

	g_PjrcCfg.Save(g_szIniFile);
}

BOOL  CLcdPjrc::IsOpen()
{
	if (m_pcDev == NULL)
		return FALSE;

	return m_pcDev->IsOpen();
}

void  CLcdPjrc::Home()
{
	SetPosition(1, 1);
}

/******************************************************************************
Function : Open
Purpose  : Opens the comport and initilizes the display
Parameters : -
Returns : TRUE if successful, otherwise FALSE
Author  : Markus Zehnder	
******************************************************************************/
BOOL  CLcdPjrc::Open()
{
	char szDef[20];

	// hack for backlight timer
	m_pInstance = this;

	if (m_pcDev == NULL) {
		m_pcDev = new CDevSerial();
	}

	sprintf(szDef, "%d,n,8,1", atoi(g_PjrcCfg.szBaudRate));

	if (!m_pcDev->Open(g_PjrcCfg.szComPort, szDef))	{
		Close();
		return FALSE;
	}		

	// set wrap and scroll off
	WriteCommand(0x41);
	WriteData(0x30);

	Clear();

	m_charMap = g_PjrcCfg.charMap;

	return TRUE;
}

void  CLcdPjrc::SetPosition(short nCol, short nRow)
{
	WriteCommand( 0x42 );
	WriteData( (BYTE)nCol + 32 - 1);
	WriteData( (BYTE)nRow + 32 - 1);
}

void  CLcdPjrc::Write(LPCSTR lpText)
{
	CString csText = lpText;
	ConvertTextToLCDCharset(csText);
	LPCSTR p = (LPCTSTR)csText;

	int len = strlen(p);

	for(int i=0; i<len; i++) {
		if ((byte)p[i] < 32) {
		  // newlines need special handling MZ 20031102
		  if ((byte)p[i] == 13 || (byte)p[i] == 10) {
			if ((byte)p[i] == 10 && i > 0 && (byte)p[i-1] != 13) {
				m_pcDev->WriteData(13);
			}
			m_pcDev->WriteData(p[i]);
		  } else {
			WriteCommand(p[i] + 32);
		  }
		} else if ((byte)p[i] == 127) {
			WriteCommand(0x5F);
		} else if ((byte)p[i] >= 128 && (byte)p[i] <= 159) {
			WriteCommand(p[i] - 32);
		} else {
			m_pcDev->WriteData(p[i]);
		}
	}
}

void CLcdPjrc::WriteData(BYTE byData)
{
	if (m_pcDev != NULL)
		m_pcDev->WriteData(byData);
}

void CLcdPjrc::WriteCommand(BYTE byData)
{
	WriteData( m_byCmdPrefix );
	WriteData( byData );
}

BOOL  CLcdPjrc::CreateCustomChar(short nNumber, CCustomChar &cChar)
{
	if (nNumber > MAX_CUSTOM_CHARS_PJRC)	// bugfix: last custom char didn't get set, MZ July 28 2k
		return FALSE;

	byte start = 1;

	byte index = start + nNumber;

	WriteCommand(0x44);
	WriteData('0' + index / 10);
	WriteData('0' + index % 10);

	WriteData(g_PjrcCfg.byFont + 32);

	int iMax = __min(8, cChar.m_byDataSize);
	for (int i = 0; i < iMax; i++) {
		if (cChar.m_byarrData[i] > 31)
			cChar.m_byarrData[i] = 0;	
		WriteData( cChar.m_byarrData[i] + 32 );
	}

	for (; i < 8; i++) {
		WriteData( 0 );
	}

	return TRUE;
}

short CLcdPjrc::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS_PJRC;
}

LPCTSTR CLcdPjrc::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( "%c1", ch );
	ch[0] = (char)2;
	csText.Replace( "%c2", ch );
	ch[0] = (char)3;
	csText.Replace( "%c3", ch );
	ch[0] = (char)4;
	csText.Replace( "%c4", ch );
	ch[0] = (char)5;
	csText.Replace( "%c5", ch );
	ch[0] = (char)6;
	csText.Replace( "%c6", ch );
	ch[0] = (char)7;
	csText.Replace( "%c7", ch );
	ch[0] = (char)8;
	csText.Replace( "%c8", ch );

	return csText;
}

LPCTSTR CLcdPjrc::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( ch, "%c1" );
	ch[0] = (char)2;
	csText.Replace( ch, "%c2" );
	ch[0] = (char)3;
	csText.Replace( ch, "%c3" );
	ch[0] = (char)4;
	csText.Replace( ch, "%c4" );
	ch[0] = (char)5;
	csText.Replace( ch, "%c5" );
	ch[0] = (char)6;
	csText.Replace( ch, "%c6" );
	ch[0] = (char)7;
	csText.Replace( ch, "%c7" );
	ch[0] = (char)8;
	csText.Replace( ch, "%c8" );

	return csText;
}

int	CLcdPjrc::GetRows()
{
	return g_PjrcCfg.iRows;
}

int	CLcdPjrc::GetColumns()
{
	return g_PjrcCfg.iCols;
}


LPCSTR CLcdPjrc::ConvertTextToLCDCharset( CString &csText )
{
	csText.Replace( "\\", "\\\\");

	return CLcd::ConvertTextToLCDCharset(csText);
}

CDevSerial* CLcdPjrc::GetSerialDevice()
{
	return m_pcDev;
}
