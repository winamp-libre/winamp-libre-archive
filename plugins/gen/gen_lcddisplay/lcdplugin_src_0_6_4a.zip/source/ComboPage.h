#if !defined(AFX_COMBOPAGE_H__FA3744A4_BD6D_11D4_896D_00105ACCEAFE__INCLUDED_)
#define AFX_COMBOPAGE_H__FA3744A4_BD6D_11D4_896D_00105ACCEAFE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ComboPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CComboPage Property Page

#include <afxtempl.h>       // MFC support for templates like CList

class CComboPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CComboPage)

// Construction
public:
	// Adds a property page to this combo page.  Provide a pointer to the page and its ID.
	// Specifying IDD will work in most cases, for example
	//    CMyPage   pageMy;
	//    comboPage.AddPage( &pageMy, pageMy.IDD );
	// Be sure your page has been created in the resource manager with a style of
	// child, a border of thin, and on More Styles check the Control checkbox.
	void AddPage( CPropertyPage* pPage, UINT nIDTemplate );

	// Sets the first page to be displayed.  Can only be called before DoModal.
	void SetInitialPage(int index);

	// Returns the number of property pages that have been added to this combo page
	int GetPageCount();

	// Returns the property page at the specified index.  The pages are stored in the order
	// in which they were added.  Passing a negative value or a value greater than the
	// number of pages will return NULL.
	CPropertyPage* GetPage( int index );

	// Returns the currently selected property page.  This method is useful for when the pages
	// are mutually exclusive, that is the user is picking one of them.  This method also
	// return the ID of the selected page.
	CPropertyPage* GetSelectedPage(UINT& nIDTemplate);

// Dialog Data
	//{{AFX_DATA(CComboPage)
	int		m_combo;
	//}}AFX_DATA

	// Use this constructor to pass in your own property page with a combo box.  The droplist
	// combo box must have an ID of IDC_COMBOPAGE_COMBO and sorting turned off.  Also add a
	// picture frame with an ID of IDC_DLG_AREA and not visible.
	CComboPage(UINT nIDTemplate);
	~CComboPage();


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CComboPage)
	public:
	virtual BOOL OnKillActive();
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnApply();
	virtual void OnReset();
	virtual BOOL OnQueryCancel();
	virtual LRESULT OnWizardBack();
	virtual LRESULT OnWizardNext();
	virtual BOOL OnWizardFinish();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CComboPage();

	// An array of pages that are attached to this combo page
	CArray< CPropertyPage*, CPropertyPage* > m_arrayPages;

	// An array of page IDs that correspond to the array of pages
	CArray< UINT, UINT > m_arrayPageIDs;

	// Indicates whether OnInitDialog has been called
	BOOL m_bInitialized;

	// Generated message map functions
	//{{AFX_MSG(CComboPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelChangeMainCombo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMBOPAGE_H__FA3744A4_BD6D_11D4_896D_00105ACCEAFE__INCLUDED_)
