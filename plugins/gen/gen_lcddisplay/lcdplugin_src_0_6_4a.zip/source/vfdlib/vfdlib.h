/***********************************************************************
/
/ Company: Noritake Co., Inc.
/
/ Copyright 1999 by Noritake Co., Inc. and Critical Link, LLC
/                    All rights reserved.
/
/ Program: VFD Library
/
/ Author: David A. Rice / Critical Link, LLC, 404 Oak St., Syracuse, NY
/
/ Description:
/
/ Revision History:
/      DAR   3/7/99  Original Version
/		 ASF   8/17/99 -800 version
/
/***********************************************************************/
#ifndef VFDLIB_H
#define VFDLIB_H

/* Noritake 800 Series defines */

/* end of Noritake 800 Series defines */

char VFDLibInit(int iDelayInit);

unsigned char VFDReadByte(int Col, int Row);

int VFDWriteByte(unsigned char Value, int Col, int Row);

char VFDClearScreen(unsigned char ScreenNo);

char VFDLine(int X0, int Y0, int X1, int Y1, char Color);

char VFDPixel(int X, int Y, char Color);

char VFDRect (int X0, int Y0, int X1, int Y1, char Color);

char VFDBlt (int X, int Y, int W, int H, unsigned char *Bitmap);

char VFDSetupGlyphText(char Width, char Height,
                           char Gap, char ScreenNumber);

char VFDSetGlyph (unsigned char *Glyph, unsigned char Code);

char VFDClearGlyphScreen(void);

char VFDSetGlyphCursor(char Row, char Col, unsigned char CursorChar);

char VFDPutGlyphChar(unsigned char Char);

char VFDPutGlyphText(char *Text);

char VFDClearGlyphRect(char Row0, char Col0, char Row1, char Col1);

char VFDScreen1(char On);

char VFDScreen2(char On);

char VFDOrScreens(void);

char VFDAndScreens(void);

char VFDXorScreens(void);

char VFDLuminance(unsigned char Luminance);

char VFDHScrollScreens(unsigned char value) ;

void VFDSetActiveScreen(char ScreenNo);

char VFDWriteGlyphCursor(char Row, char Col)  ;

char VFDWriteCommand(unsigned char Command);

char VFDWriteData(unsigned char Data);

unsigned char VFDReadData(void);

void GlyphInit(void);
#endif
