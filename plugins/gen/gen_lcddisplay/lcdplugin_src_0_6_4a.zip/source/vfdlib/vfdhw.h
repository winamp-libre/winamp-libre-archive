/***********************************************************************
/
/ Company: Noritake Co., Inc.
/
/ Copyright 1999 by Noritake Co., Inc. and Critical Link, LLC
/                    All rights reserved.
/
/ Program: VFD Library
/
/ Author: David A. Rice / Critical Link, LLC, 404 Oak St., Syracuse, NY
/
/ Description:
/
/ Revision History:
/      DAR   3/7/99  Original Version
/      ASF   8/17/99 -800 version
/
/***********************************************************************/


#ifndef VFDHW_H
#define VFDHW_H

/* graphic screen size in pixels */
#define GRAPHICS_SCREEN_WIDTH 256       /*  screen size */
#define GRAPHICS_SCREEN_HEIGHT 64       /* in pixels     */

#define VFD_BLACK 0
#define VFD_WHITE 1

/* Command set for this display */
#define ANDCNTL 0x03
#define ORCNTL 0x01
#define XORCNTL 0x02

#define Init800A 0x5F       /* initialization code sequence 5f */
#define Init800B 0x62
#define Init800C 0x00+n
#define Init800D 0xFF
#define CLEARSCREENS 0x5e   /* clear all screens (layers) */
#define LAYER0ON 0x24       /* screen0 both on */
#define LAYER1ON 0x28       /* screen1 both on */
#define LAYERSON 0x2c       /* both screens both on */
#define LAYERSOFF 0x20      /* screens both off */
#define ORON 0x40           /* OR screens */
#define ANDON 0x48          /* AND screens */
#define XORON 0x44          /* XOR screens */
#define SETX 0x64           /* set X position */
#define SETY 0x60           /* set Y position */
#define HSHIFT 0x70         /* set horizontal shift */
#define VSHIFT 0xB0
#define AUTOINCOFF 0x80     /* address auto increment off */
#define SETPOSITION 0xff

#endif
