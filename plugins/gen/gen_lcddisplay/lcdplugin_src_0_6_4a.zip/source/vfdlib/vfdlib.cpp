/***********************************************************************
/
/ Company: Noritake Co., Inc.
/
/ Copyright 1999 by Noritake Co., Inc. and Critical Link, LLC
/                    All rights reserved.
/
/ Program: VFD Library
/
/ Author: David A. Rice / Critical Link, LLC, 404 Oak St., Syracuse, NY
/
/ Description:
/
/ Revision History:
/      DAR   3/7/99  Original Version
/      ASF	 8/17/99 -800 version
/      2003/02/09 MZ stripped to minimum code
/
/***********************************************************************/


#include "..\stdafx.h"
#include "vfdlib.h"
#include <stdlib.h>

#include "vfdhw.h"

                                    /* character font */
// @TODO make dynamic, option to load different char set!
unsigned char CharMap[256][6]=
#include "..\vfdlib\noritake.txt"
;


/* shadowed screen data */
// @TODO make screen size dynamic, allocate actual size!
static unsigned char LPTScreen1_data[GRAPHICS_SCREEN_WIDTH][GRAPHICS_SCREEN_HEIGHT/8];
static unsigned char LPTScreen2_data[GRAPHICS_SCREEN_WIDTH][GRAPHICS_SCREEN_HEIGHT/8];
static unsigned char LastCmd;
static unsigned char lptlX,lptlY;

/* Screen Control */
static char Screen1On = 0;
static char Screen2On = 0;
static char ActiveScreen = 0;           /* Sets active Graphic Screen    */
                                        /* ActiveScreen = 0 -- Screen 1  */
                                        /* ActiveScreen = 1 -- Screen 2  */


// BEGIN TEMPORARY HACKS !!!!
#include "..\DevParallelNoritake.h"
 
extern CDevParallelNoritake *g_pcNoDev;


char VFDHWriteCommand(unsigned char Command) {
	return g_pcNoDev->WriteCommand(Command);
}

char VFDHWriteData(unsigned char Data) {
	return g_pcNoDev->WriteData(Data);
}

// END OF HACKS

/***************************************************************************/
/*                                                                         */
/* Function:       unsigned char VFDReadByte(int Col, int Row,             */
/*                               int StartAddress, unsigned char Text);    */
/*                                                                         */
/* Arguments:      Row, Col - position of byte in buffer                   */
/*                 StartAddress - address of beginning of display buffer   */
/*                 Text - flag indicating that this read is for text       */
/*                                                                         */
/* Return Value:   pixel value                                             */
/*                                                                         */
/* Description:    This function is used to read a byte of data from the   */
/*                 shadowed display buffer.                                         */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
unsigned char VFDReadByte(int Col, int Row)
{
   unsigned char pixel,tmask=0,imask=0;
                                    /* set cursor to desired address */
    VFDWriteCommand(SETX);          // set x coord
    VFDWriteCommand(Col);          // to 0
    if(ActiveScreen==0)
    {
        VFDWriteCommand(0x60);      /* set lower cursor address */
        VFDWriteCommand(Row/8);     /*layer0 */
    }
    else if(ActiveScreen==1)
    {
        VFDWriteCommand(SETY);      /* set lower cursor address */
        VFDWriteCommand((Row/8)+8) ;  /* 32 bit screen#2 starts at same place */

    }
   pixel = VFDReadData();           /* */

   tmask = pixel ;
   imask = 0;

                                    //used to invert mask
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;

   pixel =imask;
   return(pixel);
}

/***************************************************************************/
/*                                                                         */
/* Function:       char VFDWriteByte(unsigned char Value, int Col, int Row,*/
/*                               int StartAddress, unsigned char Text);    */
/*                                                                         */
/* Arguments:      Row, Col - position of byte in buffer                   */
/*                 StartAddress - address of beginning of display buffer   */
/*                 Text - flag indicating that this read is for text       */
/*                                                                         */
/* Return Value:   0 = success, -1 = failure                               */
/*                                                                         */
/* Description:    This function is used to write a byte of data to the    */
/*                 display buffer and shadowed display buffer.             */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
int VFDWriteByte(unsigned char Value, int Col, int Row)
{
    int error;
    char imask=0,tmask=0;
                                    /* set cursor to desired address */
   VFDWriteCommand(0x64);           /* set upper cursor address */
   VFDWriteCommand(Col);

   if(ActiveScreen==0)
   {
        VFDWriteCommand(SETY);      /* set lower cursor address */
        VFDWriteCommand(Row/8);     /*layer0 */
   }
   else if(ActiveScreen==1)
   {
        VFDWriteCommand(SETY);      /* set lower cursor address */
        VFDWriteCommand((Row/8)+8); /* layer 1 */
   }

    tmask = Value ;
    imask = 0;

                            //used to invert byte
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;
   imask <<= 1;
   tmask >>= 1;
   imask |= tmask & 0x01;

   Value =imask;

   error = VFDWriteData(Value);

   return(error);
}



/***************************************************************************/
/*                                                                         */
/* Function:       char VFDClearScreen(unsigned char ScreenNo);           */
/*                                                                         */
/* Arguments:      None                                                    */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function is used to clear the entire               */
/*                 graphics screen indicated by ScreenNo.                 */
/*                                                                         */
/*                                                                         */
/***************************************************************************/

char VFDClearScreen(unsigned char ScreenNo)
{
    char error=0;
    unsigned char command;
    unsigned int i,j;
    
    command = CLEARSCREENS & 0xf0;

    if(ScreenNo ==0)
    {
        command |= 0x4;
        for(i=0;i<GRAPHICS_SCREEN_WIDTH;i++)
            for(j=0;j<GRAPHICS_SCREEN_HEIGHT/8;j++)
                LPTScreen1_data[i][j]=0;
    }
    else if(ScreenNo==1)
    {
        command |= 0x8;
        for(i=0;i<GRAPHICS_SCREEN_WIDTH;i++)
            for(j=0;j<GRAPHICS_SCREEN_HEIGHT/8;j++)
                LPTScreen2_data[i][j]=0;
    }
    else if(ScreenNo==3)        /* erase both screens */
    {
        command |= 0xC;
        for(i=0;i<GRAPHICS_SCREEN_WIDTH;i++)
            for(j=0;j<GRAPHICS_SCREEN_HEIGHT/8;j++)
            {   LPTScreen1_data[i][j]=0;
                LPTScreen2_data[i][j]=0;
            }
    }
    else
        return -1;

    VFDWriteCommand(command);

	// bugfix: according to the data sheet the display doesn't accept any 
	// commands in the period of 1ms following this command. MZ 2003/03/09
	Sleep(1);

    return(error);
}



/***************************************************************************/
/*                                                                         */
/* Function:       char VFDPixel(int X, int Y, char Color);                */
/*                                                                         */
/* Arguments:      X, Y - coordinates of pixel to be illuminated           */
/*                 Color - if 0, pixel is black, else, pixel is white      */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function sets or clears a pixel at location X,     */
/*                 Y, depending on the value of Color.                     */
/*                                                                         */
/***************************************************************************/
char VFDPixel(int X, int Y, char Color) {
    unsigned char pixel=0;

    pixel = VFDReadByte(X, Y);

/* set or reset pixel, depending on color */
   if (Color == VFD_WHITE) {
      pixel |= 1 << (7 -(Y & 7));
   } else {
      pixel &= ~(1 << (7 -(Y & 7)));
   } /* endif */

/* write modified byte back to display */
   return(VFDWriteByte(pixel, X, Y));

}

/* glyph parameters */
static char gGlyphWidth = 0;
static char gGlyphHeight = 0;
static char gGlyphGap = 0;

static unsigned char *gGlyphTable[256] =
{
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL
};

/***************************************************************************/
/*                                                                         */
/* Function:       char VFDSetupGlyphText(char Width, char Height,         */
/*                           char Gap, char ScreenNumber);                 */
/*                                                                         */
/* Arguments:      Width - width of glyphs in pixels                       */
/*                 Height - vertical size of glyphs in pixels.             */
/*                          Must be a multiple of eight                    */
/*                 Gap - number of pixels spacing between glyphs           */
/*                 ScreenNumber - which graphics screen to use             */
/*                                for glyph text                           */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function is used to set the size of glyphs         */
/*                 in pixels.  This function should be called only         */
/*                 once.  If called multiple times with different          */
/*                 values, results are unpredictable.                      */
/*                                                                         */
/***************************************************************************/
char VFDSetupGlyphText(char Width, char Height,
                           char Gap, char ScreenNumber) {

/* store glyph character parameters */
   gGlyphWidth = Width;
   gGlyphHeight = Height;
   gGlyphGap = Gap;

   return(0);
}




/***************************************************************************/
/*                                                                         */
/* Function:       char VFDSetGlyph (char *Glyph, unsigned char Code);     */
/*                                                                         */
/* Arguments:      Glyph - pointer to a glyph                              */
/*                 Code - character value which the glyph will             */
/*                        represent.                                       */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function is used to install a glyph and            */
/*                 associate a code with it.  The storage for the          */
/*                 glyph must permanent, since the library does            */
/*                 not make a copy of installed glyphs.  The glyph         */
/*                 must be allocated to be an array of size                */
/*                 Width * Height / 8.                                     */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
char VFDSetGlyph (unsigned char *Glyph, unsigned char Code) {

/* set up glyph in table */
   gGlyphTable[Code] = Glyph;

   return(0);
}


/***************************************************************************/
/*                                                                         */
/* Function:       char VFDClearGlyphScreen(void);                         */
/*                                                                         */
/* Arguments:      None                                                    */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    use VFDClearScreen() instead                            */
/*                                                                         */
/***************************************************************************/
char VFDClearGlyphScreen(void)
{
		/* use VFDClearScreen() instead */

	return 0;
}

/* glyph parameters */
static char gGlyphRow = 0;
static char gGlyphCol = 0;
static char gGlyphCursor = 1;

/***************************************************************************/
/*                                                                         */
/* Function:       char VFDSetGlyphCursor(char Row, char Col,              */
/*                                   unsigned char CursorChar);            */
/*                                                                         */
/* Arguments:      Row, Column - position of cursor                        */
/*                 CursorChar - any valid character can be used for        */
/*                     the cursor.  If no cursor is desired, set to 0.     */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function is used to set the position of            */
/*                 the cursor for the next write to the screen.            */
/*                 If the CursorChar is non-zero, an actual                */
/*                 cursor character will be drawn on the screen.           */
/*                 Otherwise, an invisible cursor is positioned at         */
/*                 the specified location and is used only to locate       */
/*                 the coordinated for the next put character functions.   */
/*                                                                         */
/***************************************************************************/
char VFDSetGlyphCursor(char Row, char Col, unsigned char CursorChar) {
   char error = 0;

/* update cursor */
   gGlyphRow = Row;
   gGlyphCol = Col;
   gGlyphCursor = CursorChar;
   return(error);
}

/***************************************************************************/
/*                                                                         */
/* Function:       char VFDPutGlyphChar(unsigned char Char);               */
/*                                                                         */
/* Arguments:      Char - character to be displayed                        */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function is used to display a single               */
/*                 character to the screen.  This interface is             */
/*                 similar to a terminal.  Each character written          */
/*                 advances the cursor.  If the character is a             */
/*                 carriage return (CR), the cursor moves back             */
/*                 to the beginning of the current row.  If it             */
/*                 is a line feed (LF), it will advance to the             */
/*                 next row.  If at the bottom of the screen, a            */
/*                 LF will result in the display scrolling one line.       */
/*                                                                         */
/***************************************************************************/
char VFDPutGlyphChar(unsigned char Char) {
   unsigned char glyph_index;
   char i, j;
   char error = 0;
   char row, col;


   /* write cursor character, if used */
//   VFDWriteGlyphCursor(gGlyphRow, gGlyphCol);


/* parse some control codes */
   if (Char == '\r') {
      gGlyphCol = 0;
   } else if (Char == '\n') {
      if ((gGlyphRow+1)*gGlyphHeight == GRAPHICS_SCREEN_HEIGHT) {
         gGlyphRow = 0;
         gGlyphCol = 0;
      } else {
         gGlyphRow++;
         gGlyphCol = 0;
      } /* endif */
   } else {
      if (gGlyphTable[Char] != 0) {
      /* write character */
         glyph_index = 0;
         for (i=0; i<(gGlyphHeight>>3); i++) {
            for (j=0; j<gGlyphWidth; j++) {
               row = gGlyphRow*gGlyphHeight + (i<<3);
               col = gGlyphCol*(gGlyphWidth + gGlyphGap) + j;
               error = VFDWriteByte(gGlyphTable[Char][glyph_index],
                     col, row);
               glyph_index++;
            } /* endfor */
         } /* endfor */
      } /* endif */

/* handle screen wrap */
      if ((gGlyphCol+1)*(gGlyphWidth+gGlyphGap) == GRAPHICS_SCREEN_WIDTH) {
         gGlyphCol = 0;
         gGlyphRow++;
      } else {
         gGlyphCol++;
      }
   } /* endif */

//   error = VFDWriteGlyphCursor(gGlyphRow, gGlyphCol);

   return(error);

}


/***************************************************************************/
/*                                                                         */
/* Function:       char VFDScreen1(char On);                               */
/*                                                                         */
/* Arguments:      On - 1 => On, 0 => Off                                  */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function is used to enable or disable              */
/*                 screen 1.  On most displays, screen 1 is a              */
/*                 graphics screen.                                        */
/*                                                                         */
/***************************************************************************/
char VFDScreen1(char On) {

   unsigned char command=0;

   if (On) {
      Screen1On = 1;
   } else {
      Screen1On = 0;
   } /* endif */

    command = 0x20 | ((Screen1On<<2) + (Screen2On<<3));
    VFDWriteCommand(command);
    command = 0x40 ;
    VFDWriteCommand(command);

   return( 0);
}
/***************************************************************************/
/*                                                                         */
/* Function:       char VFDScreen2(char On);                               */
/*                                                                         */
/* Arguments:      On - 1 => On, 0 => Off                                  */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function is used to enable or disable              */
/*                 screen 2.  On most displays, screen 2 is a text         */
/*                 or graphics screen.                                     */
/*                                                                         */
/***************************************************************************/
char VFDScreen2(char On) {

   unsigned char command;

   if (On) {
      Screen2On = 1;
   } else {
      Screen2On = 0;
   } /* endif */

    command = 0x20 | ((Screen1On<<2) + (Screen2On<<3));
    VFDWriteCommand(command);
    command = 0x40 ;
    VFDWriteCommand(command);

   return( 0);

}

/***************************************************************************/
/*                                                                         */
/* Function:       char VFDLuminance(char Luminance);                      */
/*                                                                         */
/* Arguments:      Luminance -  0 => full brightness,                      */
/*                             >0 => reduced brightness.                   */
/*                                                                         */
/*                                                                         */
/* Return Value:   0 if success, -1 if failure                             */
/*                                                                         */
/* Description:    This function is used to set the brightness of the      */
/*                 VFD display.                                            */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
char VFDLuminance(unsigned char Luminance) {

   unsigned char command;

   command = 0x40 + (Luminance & 0xf);

   return(VFDWriteCommand(command));

}

/***************************************************************************/
/*                                                                         */
/* Function:       char VFDWriteCommand(unsigned char Command)             */
/*                                                                         */
/* Arguments:      Command                                                 */
/*                                                                         */
/* Return Value:   none                                                    */
/*                                                                         */
/* Description:    This function is used to write commands to the shadowed */
/*                  display entity, and then to the hardware.              */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
char VFDWriteCommand(unsigned char Command)
{

    if(LastCmd == SETX)
    {
        lptlX = Command;
        LastCmd = SETPOSITION;
    }
    else if (LastCmd == SETY)
    {
        lptlY = Command;
        LastCmd = SETPOSITION;
    }
    else
    {
        LastCmd = Command;
    }

    VFDHWriteCommand(Command);
    return 0;
}
/***************************************************************************/
/*                                                                         */
/* Function:       char VFDWriteData(unsigned char Data)                   */
/*                                                                         */
/* Arguments:      Data                                                    */
/*                                                                         */
/* Return Value:   none                                                    */
/*                                                                         */
/* Description:    This function is used to write data to the shadowed     */
/*                  display buffer, and then to the hardware.              */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
char VFDWriteData(unsigned char Data)
{
    if(LastCmd==SETPOSITION && lptlY<(GRAPHICS_SCREEN_HEIGHT/8))            //screen height *8
    {
        LPTScreen1_data[lptlX][lptlY]=Data;
    }
    else if(LastCmd==SETPOSITION && lptlY>(GRAPHICS_SCREEN_HEIGHT/8)-1)
    {
        LPTScreen2_data[lptlX][lptlY-(GRAPHICS_SCREEN_HEIGHT/8)]=Data;
    }

    VFDHWriteData(Data);    /* Write to hardware */
    return 0;
}
/***************************************************************************/
/*                                                                         */
/* Function:       unsigned char VFDReadData(void)                         */
/*                                                                         */
/* Arguments:      none                                                    */
/*                                                                         */
/* Return Value:   data                                                    */
/*                                                                         */
/* Description:    This function is used to read from shadowed display     */ 
/*                 buffer.                                                 */
/*                                                                         */
/***************************************************************************/
unsigned char VFDReadData(void)
{
    unsigned char Data;
    if(LastCmd==SETPOSITION &&  lptlY<(GRAPHICS_SCREEN_HEIGHT/8))
    {
        Data=LPTScreen1_data[lptlX][lptlY];
    }
    else if(LastCmd==SETPOSITION && lptlY>(GRAPHICS_SCREEN_HEIGHT/8)-1)
    {
        Data=LPTScreen2_data[lptlX][lptlY-(GRAPHICS_SCREEN_HEIGHT/8)];
    }

    return(Data);
}


/***************************************************************************/
/*                                                                         */
/* Function:       void GlyphInit(void)                         */
/*                                                                         */
/* Arguments:      none                                                    */
/*                                                                         */
/* Return Value:   nonee                                                    */
/*                                                                         */
/* Description:    This function is used to configure glyphs               */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
void GlyphInit(void)
{
    unsigned int i;

    VFDSetupGlyphText(6, 8, 0, 2);       /* set gap to 0 */

    for(i=0;i<256;i++)
    {
        VFDSetGlyph(&CharMap[i][0], i);     /* load characters */
    }
}


