// ComboPage.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "combopage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComboPage property page

IMPLEMENT_DYNCREATE(CComboPage, CPropertyPage)


CComboPage::CComboPage(UINT nIDTemplate) : CPropertyPage(nIDTemplate)
{
	//{{AFX_DATA_INIT(CComboPage)
	m_combo = 0;
	//}}AFX_DATA_INIT

	m_bInitialized = FALSE;
}


CComboPage::CComboPage() : CPropertyPage( (UINT) 0 )
{
	// This constructor shouldn't be used, but is required for DECLARE_DYNCREATE
	ASSERT( 0 );
}

CComboPage::~CComboPage()
{
}

void CComboPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComboPage)
	DDX_CBIndex(pDX, IDC_COMBOPAGE_COMBO, m_combo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CComboPage, CPropertyPage)
	//{{AFX_MSG_MAP(CComboPage)
	ON_CBN_SELCHANGE(IDC_COMBOPAGE_COMBO, OnSelChangeMainCombo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComboPage message handlers

BOOL CComboPage::OnInitDialog() 
{
	CPropertyPage* pPage;
	CComboBox* pCombo;
	CString string;
	CRect rcCombo;

	CPropertyPage::OnInitDialog();
	
	// Get a pointer to the combo box
	pCombo = (CComboBox*) GetDlgItem(IDC_COMBOPAGE_COMBO);

	// Set the height so that it will display all of the strings that will be added
	pCombo->GetWindowRect( rcCombo );
	ScreenToClient( &rcCombo );
	rcCombo.bottom += 100;
	pCombo->MoveWindow( rcCombo );

	// Create all of the embedded pages and use the combo page as their parents
	for ( int i = 0; i < m_arrayPages.GetSize(); i++ )
		{
		pPage = static_cast<CPropertyPage*>( m_arrayPages[i] );

		pPage->Create( m_arrayPageIDs[i], this );

		// Add this page's caption to the combo box
		pPage->GetWindowText( string );
		pCombo->AddString( string );
		}

	// Set the combo box selection
	pCombo->SetCurSel( m_combo );

	// Set the initial page
	OnSelChangeMainCombo();

	UpdateData(FALSE);

	m_bInitialized = TRUE;

	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}


void CComboPage::OnSelChangeMainCombo()
{
	CRect rcDlgArea;
	CPropertyPage* pOldPage;
	CPropertyPage* pNewPage;

	// Get the current page and update its data
	pOldPage = static_cast<CPropertyPage*>( m_arrayPages[m_combo] );
	if ( !pOldPage->UpdateData() )
		{
		// Restore the combo box to its original setting
		UpdateData( FALSE );
		return;
		}

	// If not called from InitDialog, then have the page validate its data
	if ( m_bInitialized && !pOldPage->OnKillActive() )
		{
		// Restore the combo box to its original setting
		UpdateData( FALSE );
		return;
		}

	// Get the current selection
	CComboBox* pCombo = (CComboBox*) GetDlgItem(IDC_COMBOPAGE_COMBO);
	m_combo = pCombo->GetCurSel();

	// Tell the page it will be the active page
	pNewPage = static_cast<CPropertyPage*>( m_arrayPages[m_combo] );
	if ( !pNewPage->OnSetActive() )
		{
		// Restore the combo box to its original setting
		UpdateData( FALSE );
		return;
		}

	// Hide the current page
	pOldPage->ShowWindow( SW_HIDE );

	// Show the newly selected page
	pNewPage->ShowWindow( SW_SHOW );

	// Position the newly selected page
	GetDlgItem( IDC_DLG_AREA )->GetWindowRect( &rcDlgArea );
	ScreenToClient( &rcDlgArea );
	pNewPage->SetWindowPos( NULL, rcDlgArea.left, rcDlgArea.top, 0, 0, 
			SWP_NOSIZE | SWP_NOACTIVATE );
	
	// Put the tab order of the controls in the page after the combo box
	pNewPage->SetWindowPos( pCombo, 0, 0, 0, 0, SWP_SHOWWINDOW | SWP_NOSIZE | SWP_NOMOVE );
}


void CComboPage::AddPage(CPropertyPage* pPage, UINT nIDTemplate)
{
	if ( NULL != pPage )
		{
		m_arrayPages.Add( pPage );
		m_arrayPageIDs.Add( nIDTemplate );
		}
}


void CComboPage::SetInitialPage(int index)
{
	if ( ( index < 0 ) ||
		 ( index > m_arrayPages.GetUpperBound() ) )
		return;

	m_combo = index;
}


int CComboPage::GetPageCount()
{
	return m_arrayPages.GetSize();
}


CPropertyPage* CComboPage::GetPage(int index)
{
	if ( ( index < 0 ) ||
		 ( index > m_arrayPages.GetUpperBound() ) )
		return NULL;

	return m_arrayPages[index];
}


CPropertyPage* CComboPage::GetSelectedPage(UINT& nIDTemplate)
{
	if ( ( m_combo < 0 ) ||
		 ( m_combo > m_arrayPages.GetUpperBound() ) )
		return NULL;

	nIDTemplate = m_arrayPageIDs[m_combo];

	return m_arrayPages[m_combo];
}


BOOL CComboPage::OnKillActive() 
{
	CPropertyPage* pPage;

	// Update the data on the current page and have it validate its data
	pPage = static_cast<CPropertyPage*>( m_arrayPages[m_combo] );
	if ( !pPage->UpdateData() )
		return FALSE;

	// Have the page validate its data
	if ( !pPage->OnKillActive() )
		return FALSE;
	
	return CPropertyPage::OnKillActive();
}

void CComboPage::OnCancel() 
{
	CPropertyPage* pPage;

	// Call OnCancel on all child pages
	for ( int i = 0; i < m_arrayPages.GetSize(); i++ )
		{
		// Get the indexed page and invoke OnCancel
		pPage = static_cast<CPropertyPage*>( m_arrayPages[i] );
		pPage->OnCancel();
		}
	
	CPropertyPage::OnCancel();
}


void CComboPage::OnOK() 
{
	CPropertyPage* pPage;

	// Call OnOK on all child pages
	for ( int i = 0; i < m_arrayPages.GetSize(); i++ )
		{
		// Get the indexed page and invoke OnOK
		pPage = static_cast<CPropertyPage*>( m_arrayPages[i] );
		pPage->OnOK();
		}
	
	CPropertyPage::OnOK();
}


BOOL CComboPage::OnApply() 
{
	CPropertyPage* pPage;

	// Call OnApply on all child pages
	for ( int i = 0; i < m_arrayPages.GetSize(); i++ )
		{
		// Get the indexed page and invoke OnApply
		pPage = static_cast<CPropertyPage*>( m_arrayPages[i] );
		pPage->OnApply();
		}
	
	return CPropertyPage::OnApply();
}


void CComboPage::OnReset() 
{
	CPropertyPage* pPage;

	// Call OnReset on all child pages
	for ( int i = 0; i < m_arrayPages.GetSize(); i++ )
		{
		// Get the indexed page and invoke OnReset
		pPage = static_cast<CPropertyPage*>( m_arrayPages[i] );
		pPage->OnReset();
		}
	
	CPropertyPage::OnReset();
}


BOOL CComboPage::OnQueryCancel() 
{
	CPropertyPage* pPage;

	// Update the data on all of the child pages and call OnQueryCancel on them
	for ( int i = 0; i < m_arrayPages.GetSize(); i++ )
		{
		// Get the indexed page and update its data
		pPage = static_cast<CPropertyPage*>( m_arrayPages[i] );
		if ( !pPage->UpdateData() )
			return FALSE;

		// Invoke OnQueryCancel
		if ( !pPage->OnQueryCancel() )
			return FALSE;
		}
	
	return CPropertyPage::OnQueryCancel();
}


LRESULT CComboPage::OnWizardBack() 
{
	CPropertyPage* pPage;
	LRESULT lResult = 0;

	// Invoke OnWizardBack only on the selected child page
	if ( ( m_combo >= 0 ) &&
		 ( m_combo <= m_arrayPages.GetUpperBound() ) )
		{
		pPage = m_arrayPages[m_combo];

		lResult = pPage->OnWizardBack();

		return lResult;
		}

	return CPropertyPage::OnWizardBack();
}


LRESULT CComboPage::OnWizardNext() 
{
	CPropertyPage* pPage;
	LRESULT lResult = 0;

	// Invoke OnWizardNext only on the selected child page
	if ( ( m_combo >= 0 ) &&
		 ( m_combo <= m_arrayPages.GetUpperBound() ) )
		{
		pPage = m_arrayPages[m_combo];

		lResult = pPage->OnWizardNext();

		return lResult;
		}

	return CPropertyPage::OnWizardNext();
}


BOOL CComboPage::OnWizardFinish() 
{
	CPropertyPage* pPage;
	LRESULT lResult = 0;

	// Invoke OnWizardFinish only on the selected child page
	if ( ( m_combo >= 0 ) &&
		 ( m_combo <= m_arrayPages.GetUpperBound() ) )
		{
		pPage = m_arrayPages[m_combo];

		lResult = pPage->OnWizardFinish();

		return lResult;
		}

	return CPropertyPage::OnWizardFinish();
}
