#if !defined(AFX_DLGINPUT_H__8FBFA991_CEE4_4CD4_8122_E4F10BC6725C__INCLUDED_)
#define AFX_DLGINPUT_H__8FBFA991_CEE4_4CD4_8122_E4F10BC6725C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInput.h : header file
//

#include "ListCtrlEx.h"

class CDlgInputAdd;

/////////////////////////////////////////////////////////////////////////////
// CDlgInput dialog

class CDlgInput : public CPropertyPage
{
friend class CDlgInputAdd;

protected:
	CStringArray m_buttons;
	CDWordArray	 m_actions;
	CMapStringToPtr m_mapInput;


// Construction
public:
	virtual void OnAdd();
	CDlgInput(int id);

// Dialog Data
	//{{AFX_DATA(CDlgInput)
	CListCtrlEx	m_cList;
	BOOL	m_bEnabled;
	//}}AFX_DATA

// Implementation
protected:
	virtual void OnEdit();
	virtual void SetModified();
	virtual void RefreshList();

	virtual void OnDelete();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINPUT_H__8FBFA991_CEE4_4CD4_8122_E4F10BC6725C__INCLUDED_)
