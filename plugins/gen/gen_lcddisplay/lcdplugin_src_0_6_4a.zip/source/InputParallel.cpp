/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Parallel port input driver implementation. Uses the HD44780 device drivers
// for the low level functions. Derived from CInputLCD.
// 
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/02/09 MZ  extended input (default/menu/set actions)
// 2003/07/16 MZ  IF_SHIFTREG_EX interface option added
// 
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "InputParallel.h"
#include "DevParallel8Bit.h"
#include "DevParallel4Bit.h"
#include "DevParallelShiftReg.h"
#include "DevParallelShiftRegEx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define POLL_INTERVALL 125


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInputParallel::CInputParallel()
{
	m_pmapInput = &g_Config.mapInParallel;

	m_dwPollIntervall = POLL_INTERVALL;
}

CInputParallel::~CInputParallel()
{

}

BOOL CInputParallel::InitDevice()
{
	CloseDevice();

	m_bUseLCDport = g_Config.bInParallelLCDport;

	if (m_bUseLCDport) {

		// use existing COM port
		m_pcDev = g_LCD->GetParallelDevice();

		if (m_pcDev == NULL) {
			AfxMessageBox(IDS_ERR_NO_PARALLEL_IN_SUPPORT);
			return FALSE;
		}

	} else {

		switch (g_Config.byInParallelInterface) {
		  case IF_SHIFTREG_EX :
			m_pcDev = new CDevParallelShiftRegEx44780();
			break;
		  case IF_SHIFTREG :
			m_pcDev = new CDevParallelShiftReg44780();
			break;
		  case IF_4BIT :
			m_pcDev = new CDevParallel4Bit44780();
			break;
		  default :
			m_pcDev = new CDevParallel8Bit44780();
		}

		if (!m_pcDev->Open(g_Config.szInParallelPort, "keypad")) {
			return FALSE;
		}
	}

	m_pcDev->SetInputDevice(this);

	m_bExit = FALSE;
	m_hThread = CreateThread(NULL, 0, ReaderThread, (LPVOID)this, 0, &m_dwThreadID);

	m_bInitialized = (m_hThread != NULL);

	return m_bInitialized;
}


BOOL CInputParallel::WriteConfig(LPCSTR lpIniFile)
{
    char string[32];
    CString csBuffer;

	wsprintf(string,"%d",g_Config.bInParallelEnabled);
    WritePrivateProfileString(SECTION_NAME,"Parallel_enabled",string,lpIniFile);
	wsprintf(string,"%d",g_Config.bInParallelLCDport);
    WritePrivateProfileString(SECTION_NAME,"Parallel_LCDport",string,lpIniFile);
	WritePrivateProfileString(SECTION_NAME,"Parallel_port",g_Config.szInParallelPort,lpIniFile);
	wsprintf(string,"%d",g_Config.byInParallelInterface);
	WritePrivateProfileString(SECTION_NAME,"Parallel_type",string,lpIniFile);

    CString csTemp;
    csBuffer = "";
	int i = 0;
	CString   key;
	INPUT_BTN *btn;

	for (POSITION pos = g_Config.mapInParallel.GetStartPosition(); pos != NULL; ){
		g_Config.mapInParallel.GetNextAssoc( pos, key, (void*&)btn );

        if (i++ > 0) {
            csBuffer+="|";
		}

		csTemp.Format("%s %i,%i,%i", key, acts[btn->defAction].msgNbr, acts[btn->menuAction].msgNbr, acts[btn->setAction].msgNbr );
        csBuffer+=csTemp;
	}

    WritePrivateProfileString(SECTION_NAME, "Parallel_cmds", csBuffer, lpIniFile);

	return TRUE;
}

BOOL CInputParallel::ReadConfig(LPCSTR lpIniFile)
{
    char    *p;
    char    szBuffer[10000];
	CString csBtnName;

	g_Config.bInParallelEnabled = GetPrivateProfileInt(SECTION_NAME,"Parallel_enabled", 0, lpIniFile);
	g_Config.bInParallelLCDport = GetPrivateProfileInt(SECTION_NAME,"Parallel_LCDport", 0, lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Parallel_port", "0x378", g_Config.szInParallelPort, sizeof(g_Config.szInParallelPort), lpIniFile);
	g_Config.byInParallelInterface = GetPrivateProfileInt(SECTION_NAME,"Parallel_type", 0, lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Parallel_commands", "", szBuffer, sizeof(szBuffer), lpIniFile);
	// read new cfg
	char szBtn[20];
	unsigned int defCmd, menuCmd, setCmd;
	INPUT_BTN *btn;

	GetPrivateProfileString( SECTION_NAME, "Parallel_cmds", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");
    while (p != NULL)
    {
		// set to 'no action'
		defCmd = menuCmd = setCmd = acts[0].msgNbr;

		int nbr = sscanf(p, "%s %d,%d,%d", szBtn, &defCmd, &menuCmd, &setCmd);

		if (nbr > 1) {
			btn = new INPUT_BTN;
			btn->defAction = btn->menuAction = btn->setAction = 0;

			for (int i=0; i < TOTAL_ACTIONS; i++)
			{
				if (acts[i].msgNbr == defCmd)
					btn->defAction = i;
				if (acts[i].msgNbr == menuCmd)
					btn->menuAction = i;
				if (acts[i].msgNbr == setCmd)
					btn->setAction = i;
			}

			CString csKey = szBtn;
			g_Config.mapInParallel.SetAt(csKey, btn);
		}

        p = strtok(NULL, "|");
    }

	return TRUE;
}

