/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgCfgHD667xx.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2002/11/10 MZ  initial version
// 2003/08/03 MZ  replaced hard coded LCD driver access with dynamic methods through CLCDFactory 
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgCfgHD667xx.h"
#include "LcdHD667xx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgHD667xx dialog


CDlgCfgHD667xx::CDlgCfgHD667xx(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCfgHD667xx::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCfgHD667xx)
	m_csPort = _T("");
	m_csRows = _T("");
	m_csCols = _T("");
	m_bSplitScreens = FALSE;
	m_byCellWidth = 0;
	m_byCellHeight = 0;
	m_iBus = 0;
	m_iInit = 0;
	m_iLong = 0;
	m_iMedium = 0;
	m_iMulitplier = 0;
	m_iShort = 0;
	m_bBacklight = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgCfgHD667xx::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCfgHD667xx)
	DDX_CBString(pDX, IDC_COMBO_PORT, m_csPort);
	DDX_CBString(pDX, IDC_COMBO_ROWS, m_csRows);
	DDV_MaxChars(pDX, m_csRows, 2);
	DDX_CBString(pDX, IDC_COMBO_COLS, m_csCols);
	DDV_MaxChars(pDX, m_csCols, 2);
	DDX_Check(pDX, IDC_CHECK_SPLIT, m_bSplitScreens);
	DDX_Text(pDX, IDC_CELLW_EDIT, m_byCellWidth);
	DDV_MinMaxByte(pDX, m_byCellWidth, 4, 8);
	DDX_Text(pDX, IDC_CELLH_EDIT, m_byCellHeight);
	DDX_Text(pDX, IDC_EDIT_BUS, m_iBus);
	DDV_MinMaxInt(pDX, m_iBus, 0, 10000);
	DDX_Text(pDX, IDC_EDIT_INIT, m_iInit);
	DDV_MinMaxInt(pDX, m_iInit, 0, 10000);
	DDX_Text(pDX, IDC_EDIT_LONG, m_iLong);
	DDV_MinMaxInt(pDX, m_iLong, 0, 10000);
	DDX_Text(pDX, IDC_EDIT_MED, m_iMedium);
	DDV_MinMaxInt(pDX, m_iMedium, 0, 10000);
	DDX_Text(pDX, IDC_EDIT_MULT, m_iMulitplier);
	DDV_MinMaxInt(pDX, m_iMulitplier, 1, 100);
	DDX_Text(pDX, IDC_EDIT_SHORT, m_iShort);
	DDV_MinMaxInt(pDX, m_iShort, 0, 10000);
	DDX_Check(pDX, IDC_BACKLIGHT, m_bBacklight);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCfgHD667xx, CDialog)
	//{{AFX_MSG_MAP(CDlgCfgHD667xx)
	ON_BN_CLICKED(IDC_DEF_BTN, OnDefBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgHD667xx message handlers

BOOL CDlgCfgHD667xx::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	char	szTemp[10];
	
	wsprintf(szTemp, "%x", g_667xxCfg.iPort);
	m_csPort = szTemp;
	m_csCols = itoa(g_667xxCfg.iCols, szTemp, 10);
	m_csRows = itoa(g_667xxCfg.iRows, szTemp, 10);

	m_bBacklight   = g_667xxCfg.bBacklight;
	m_byCellHeight = g_667xxCfg.byCellH;
	m_byCellWidth  = g_667xxCfg.byCellW;
	m_bSplitScreens = g_667xxCfg.bSplitScreens;

	int iRadio = IDC_RADIO_8B;
	switch (g_667xxCfg.byInterface) {
		case IF_4BIT : iRadio = IDC_RADIO_4B; break;
//		case IF_SHIFTREG : iRadio = IDC_RADIO_SHIFTREG; break;
	}
	CheckRadioButton(IDC_RADIO_8B,IDC_RADIO_SHIFTREG, iRadio);

	m_iShort = g_667xxCfg.iDelayShort;
	m_iMedium = g_667xxCfg.iDelayMed;
	m_iLong = g_667xxCfg.iDelayLong;
	m_iInit = g_667xxCfg.iDelayInit;
	m_iBus = g_667xxCfg.iDelayBus;
	m_iMulitplier = g_667xxCfg.iDelayMultiplier;

	switch (g_667xxCfg.DelayType) {
		case PORT_IO : iRadio = IDC_RADIO_PORT; break;
		default      : iRadio = IDC_RADIO_VHR;
	}
	CheckRadioButton(IDC_RADIO_PORT, IDC_RADIO_VHR, iRadio);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCfgHD667xx::OnOK() 
{
	UpdateData();

	BOOL bOpen = FALSE;
    LCD_DRIVER *pDrv = g_LCDFactory.GetDriver(DRV_HD667xx);

	if (pDrv && (g_LCD == pDrv->pcLcd))
	{
		g_LCDFactory.CloseLCD();
		bOpen = TRUE;
	}

	g_667xxCfg.iCols = atoi( m_csCols );
	g_667xxCfg.iRows = atoi( m_csRows );
    g_667xxCfg.bBacklight = m_bBacklight;
	g_667xxCfg.byCellH = m_byCellHeight;
	g_667xxCfg.byCellW = m_byCellWidth;
	g_667xxCfg.bSplitScreens = m_bSplitScreens;
	sscanf(m_csPort, "%x", &g_667xxCfg.iPort);
	if (g_667xxCfg.iPort <= 0) {
		g_667xxCfg.iPort = 0x378;
	}

	switch (GetCheckedRadioButton(IDC_RADIO_8B, IDC_RADIO_SHIFTREG))
	{
		case IDC_RADIO_4B : g_667xxCfg.byInterface = IF_4BIT; break;
		case IDC_RADIO_SHIFTREG   : g_667xxCfg.byInterface = IF_SHIFTREG; break;
		default : g_667xxCfg.byInterface = IF_8BIT; break;
	}

	g_667xxCfg.iDelayShort = m_iShort;
	g_667xxCfg.iDelayMed = m_iMedium;
	g_667xxCfg.iDelayLong = m_iLong;
	g_667xxCfg.iDelayInit = m_iInit;
	g_667xxCfg.iDelayBus = m_iBus;
	g_667xxCfg.iDelayMultiplier = m_iMulitplier;

	switch (GetCheckedRadioButton(IDC_RADIO_PORT, IDC_RADIO_VHR))
	{
		case IDC_RADIO_PORT : g_667xxCfg.DelayType = PORT_IO; break;
		default : g_667xxCfg.DelayType = VHR_TIMING;
	}

	if (bOpen)
		g_LCDFactory.OpenLCD(pDrv->pcLcd);

	CDialog::OnOK();
}

void CDlgCfgHD667xx::OnDefBtn() 
{
	m_csPort = "378";
	m_csRows = "4";
	m_csCols = "20";
	m_bSplitScreens = FALSE;
	m_byCellHeight = 8;
	m_byCellWidth = 5;
	CheckRadioButton(IDC_RADIO_8B,IDC_RADIO_SHIFTREG, IDC_RADIO_8B);

	m_iShort = DEF_DELAY_SHORT;
	m_iMedium = DEF_DELAY_MED;
	m_iLong = DEF_DELAY_LONG;
	m_iInit = DEF_DELAY_INIT;
	m_iBus = DEF_DELAY_BUS;
	m_iMulitplier = DEF_DELAY_MULTIPLIER;
	CheckRadioButton(IDC_RADIO_PORT, IDC_RADIO_VHR, IDC_RADIO_VHR);

	UpdateData(FALSE);
}
