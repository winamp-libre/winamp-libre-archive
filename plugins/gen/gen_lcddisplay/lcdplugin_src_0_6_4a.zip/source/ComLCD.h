/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// ComLCD.h: interface for the CComLCD class.
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMLCD_H__0CC5AD40_5999_11D3_B63C_0010A4F5373D__INCLUDED_)
#define AFX_COMLCD_H__0CC5AD40_5999_11D3_B63C_0010A4F5373D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Lcd.h"
#include "lcdserver.h"

//class ILCDServer;

class CComLCD : public CLcd  
{
public:
	BOOL Create();
	CComLCD();
	virtual ~CComLCD();

	virtual void  SetBacklight(short nSeconds);
	virtual short GetBacklight();
	virtual void  SetBlink(BOOL On);
	virtual BOOL  GetBlink();
	virtual void  Clear();
	virtual void  Close();
	virtual BOOL  IsOpen();
	virtual void  SetContrast(short nLevel);
	virtual short GetContrast();
	virtual void  Cursor(BOOL bOn);
	virtual BOOL  IsCursorOn();
	virtual long  GetLastError();
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen);
	virtual void  Home();
	virtual void  InitHorizontalBar();
	virtual void  InitLargeDigit();
	virtual void  InitVerticalBar();
	virtual void  LargeDigit(short nCol, short nNumber);
	virtual void  SetLineWrap(BOOL bOn);
	virtual BOOL  GetLineWrap();
	virtual BOOL  Open();
	virtual void  SetPosition(short nCol, short nRow);
	virtual void  SetScroll(BOOL bOn);
	virtual BOOL  GetScroll();
	virtual void  VBar(short nCol, short nLength);
	virtual void  Write(LPCSTR lpText);
	virtual BOOL  CreateCustomChar(short nNumber, CCustomChar &cChar);
	virtual short GetMaxCustomChar();
	virtual LPCTSTR ConvertTagsToCustomChars(CString &csText);
	virtual LPCTSTR ConvertCustomCharsToTags(CString &csText);
	virtual int		GetRows() { return 0;};		// MZ, June 27
	virtual int		GetColumns() { return 0;};	// MZ, June 27
	virtual LPCSTR  ConvertTextToLCDCharset( CString &csText ) {return csText;};	// MZ, August 16 2k
	virtual LPCSTR  ConvertTextToLCDCharset( LPSTR lpText ) {return lpText;};		// MZ, August 16 2k


private:
	ILCDServer	  m_cLCDServer;
};

#endif // !defined(AFX_COMLCD_H__0CC5AD40_5999_11D3_B63C_0010A4F5373D__INCLUDED_)
