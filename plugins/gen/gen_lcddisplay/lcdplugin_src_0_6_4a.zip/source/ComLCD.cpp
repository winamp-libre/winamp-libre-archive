/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// ComLCD.cpp: implementation of the CComLCD class.
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "ComLCD.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CComLCD::CComLCD()
{
}

CComLCD::~CComLCD()
{
}

void  CComLCD::SetBacklight(short nSeconds)
{
	m_cLCDServer.SetBacklight(nSeconds);
}

short CComLCD::GetBacklight()
{
	return m_cLCDServer.GetBacklight();
}

void  CComLCD::SetBlink(BOOL bOn)
{
	m_cLCDServer.SetBlink(bOn);
}

BOOL  CComLCD::GetBlink()
{
	return m_cLCDServer.GetBlink();
}

void  CComLCD::Clear()
{
	m_cLCDServer.Clear();
}

void  CComLCD::Close()
{
	m_cLCDServer.Close();	
}

BOOL  CComLCD::IsOpen()
{
	return 	m_cLCDServer.IsOpen();
}

void  CComLCD::SetContrast(short nLevel)
{
	m_cLCDServer.SetContrast(nLevel);
}

short CComLCD::GetContrast()
{
	return m_cLCDServer.GetContrast();
}

void  CComLCD::Cursor(BOOL bOn)
{
	m_cLCDServer.SetCursor(bOn);
}

BOOL  CComLCD::IsCursorOn()
{
	return m_cLCDServer.GetCursor();
}

long CComLCD::GetLastError()
{
	return	m_cLCDServer.GetLastError();
}

void  CComLCD::HBar(short nCol, short nRow, short nDir, short nLen)
{
	m_cLCDServer.HBar(nCol, nRow, nDir, nLen);
}

void  CComLCD::Home()
{
	m_cLCDServer.Home();
}

void  CComLCD::InitHorizontalBar()
{
	m_cLCDServer.InitHorizontalBar();
}

void  CComLCD::InitLargeDigit()
{
	m_cLCDServer.InitLargeDigit();
}

void  CComLCD::InitVerticalBar()
{
	m_cLCDServer.InitVerticalBar();
}

void  CComLCD::LargeDigit(short nCol, short nNumber)
{
	m_cLCDServer.LargeDigit(nCol,nNumber);
}

void  CComLCD::SetLineWrap(BOOL bOn)
{
	m_cLCDServer.SetLineWrap(bOn);
}

BOOL  CComLCD::GetLineWrap()
{
	return	m_cLCDServer.GetLineWrap();
}

BOOL  CComLCD::Open()
{
	return m_cLCDServer.Open(NULL);
}

void  CComLCD::SetPosition(short nCol, short nRow)
{
	m_cLCDServer.SetPosition(nCol,nRow);
}

void  CComLCD::SetScroll(BOOL bOn)
{
	m_cLCDServer.SetScroll(bOn);
}

BOOL  CComLCD::GetScroll()
{
	return m_cLCDServer.GetScroll();
}

void  CComLCD::VBar(short nCol, short nLength)
{
	m_cLCDServer.VBar(nCol,nLength);
}

void  CComLCD::Write(LPCSTR lpText)
{
	m_cLCDServer.Write(lpText);
}

BOOL  CComLCD::CreateCustomChar(short nNumber, CCustomChar &cChar)
{
	return  FALSE;
}
short CComLCD::GetMaxCustomChar()
{
	return 0;
}

LPCTSTR CComLCD::ConvertTagsToCustomChars(CString &csText)
{
	return NULL;
}

LPCTSTR CComLCD::ConvertCustomCharsToTags(CString &csText)
{
	return NULL;
}

BOOL CComLCD::Create()
{
   CLSID clsid;
   
   // Get the CLSID with the given ProgID
   if(!SUCCEEDED(CLSIDFromProgID(OLESTR("LCDServer.Application"),
                                 &clsid)))
   {
	 // print error msg...
     return FALSE;
   }
 
   IUnknown *unk;
   IDispatch *disp;
   HRESULT hr;
 
   // object already running ?
   if(SUCCEEDED(GetActiveObject(clsid,0,&unk)))
   {
     hr=unk->QueryInterface(IID_IDispatch,(void**)&disp);
     unk->Release();
     if(SUCCEEDED(hr))
       m_cLCDServer.AttachDispatch(disp,1);
   }
 
   if(!m_cLCDServer.m_lpDispatch)
   {
     // if not, create it!
     if(!m_cLCDServer.CreateDispatch("LCDServer.Application"))
     {
	   // error msg...
       return FALSE;
     }
   }

   return TRUE;
}
