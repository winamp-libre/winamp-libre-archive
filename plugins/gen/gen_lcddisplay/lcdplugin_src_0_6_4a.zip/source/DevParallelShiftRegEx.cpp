/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallelShiftRegEx.cpp: implementation of the CDevParallelShiftRegEx44780 class.
//
// BASED ON THE SERIAL LPT DRIVER FROM LCDPROC (hd44780-serialLpt.c)
// tweaked and expanded by Andrew Kibler
//
// Modifications:
// 2003/07/16 MZ, AK  initial version
// 2003/07/29 AK  reset power command & delays in senddata
// 

/*
 * Serial LPT driver module for Hitachi HD44780 based LCD displays by
 * Andrew McMeikan. The LCD is operated in it's 4 bit-mode through a
 * 4094 shift register and supports a keypad.
 *
 * Copyright (c)  1999 Andrew McMeikan <andrewm@engineer.com>
 *		modular driver 1999 Benjamin Tse <blt@Comports.com>
 *
 *              2001 Joris Robijn <joris@robijn.net>
 *                - Keypad support
 *                - Changed for 2 line wire control
 *
 *              2003 Andrew Kibler
 *                updated the shiftreg code to make it work with 4 row,
 *                2-EN 2-controller modules
 *
 * Full connection details at http://markuszehnder.ch/projects/lcdplugin/images/shiftregex.jpg
 *
 * Basic connection schema, EN1/EN2 circuit omitted:
 *
 * printer port   4094/LCD
 * 	          EN  (6 - LCD)
 * D3 (5)	  D   (2 - 4094)
 * D4 (6)	  CLK (3 - 4094)
 * +Vcc	   	  OE, STR (15, 1 - 4094)
 *            EN2 (6 - LCD2) (optional)
 *
 * 4094	   	  LCD
 * Q1 (3)	  D4 (11)
 * Q2 (4)	  D5 (12)
 * Q3 (5)	  D6 (13)
 * Q4 (6)	  D7 (14)
 * Q6 (11)	  RS (4)
 * Gnd	          nRW (5)
 *
 * Keypad connection (optional):
 * This is connected on the 4094 parallel to the LCD.
 * Some diodes and resistors are needed, see further documentation.
 * Q1 (4)	  Y0
 * Q2 (5)	  Y1
 * Q3 (6)	  Y2
 * Q4 (7)	  Y3
 * Q5 (14)	  Y4
 * Q6 (13)	  Y5
 * Q7 (12)	  Y6
 * The 'output' of the keys should be connected to the following LPT pins:
 * nACK   (10)    X0
 * BUSY   (11)    X1
 * PAPEREND (12)  X2
 * SELIN  (13)    X3
 * nFAULT (15)    X4
 * If you want to use as few LPT lines as possible, only use X0.
 *
 * This file is released under the GNU General Public License. Refer to the
 * COPYING file distributed with this package.
 */

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DevParallelShiftRegEx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//define shiftreg bts
#define	RST		 16
#define RS       32
#define	ENSEL    64
//define parallel bits
#define EN1       4
#define EN2      32
//define delay for shift reg clearing
#define	LTCHDLY	 25

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevParallelShiftRegEx44780::CDevParallelShiftRegEx44780()
{

}

CDevParallelShiftRegEx44780::~CDevParallelShiftRegEx44780()
{

}

BOOL CDevParallelShiftRegEx44780::Open(LPCSTR lpPort, LPCSTR lpParam)
{
	if (!CDevParallel::Open(lpPort, lpParam))
		return FALSE;

	// ...
	unsigned char enableLines = EN1 | EN2;


	shiftreg (enableLines, RST);	//shift out the reset power command to the 555
	uPause (300000);				//wait till power returns + at least 15 ms


	// setup the lcd in 4 bit mode (first controller)
	shiftreg (EN1, 3);
	uPause (15000);

	shiftreg (EN1, 3);
	uPause (5000);

	shiftreg (EN1, 3);
	uPause (150);

	shiftreg (EN1, 2);
	uPause (m_delayMedium);

	// setup the lcd in 4 bit mode (second controller)
	shiftreg (EN2, ENSEL | 3);
	uPause (15000);

	shiftreg (EN2, ENSEL | 3);
	uPause (5000);

	shiftreg (EN2, ENSEL | 3);
	uPause (150);

	shiftreg (EN2, ENSEL | 2);
	uPause (m_delayMedium);

	//set up both lcds the rest of the way now 
	//(don't know if 3 line lcds exist where second controller is 1 line, but this won't work with them probably)
	senddata (0, RS_INSTR, FUNCSET | IF_4BIT | TWOLINE | SMALLCHAR);
	uPause (m_delayShort);

	common_init();

	m_bOpen = TRUE;

	return TRUE;
}


void CDevParallelShiftRegEx44780::senddata (unsigned char displayID, unsigned char flags, unsigned char ch)
{
	unsigned char enableLines;
	unsigned char portControl = 0;
	unsigned char h = ch >> 4, l = ch & 15;

	if (flags == RS_DATA)
		portControl = RS;
	else
		portControl = 0;

	if (displayID == 1) {
		enableLines = EN1;
		shiftreg (enableLines, portControl | h);
		uPause (LTCHDLY);
		shiftreg (enableLines, portControl | l);
		uPause (LTCHDLY);
		}
	else if (displayID == 2) {
		enableLines = EN2;
		shiftreg (enableLines, ENSEL | portControl | h);
		uPause (LTCHDLY);
		shiftreg (enableLines, ENSEL | portControl | l);
		uPause (LTCHDLY);
		}
	else {
		//Send data to both controllers on EN1 and EN2
		shiftreg (EN1, portControl | h);
		uPause (LTCHDLY);
		shiftreg (EN1, portControl | l);
		uPause (m_delayShort);
		shiftreg (EN2, ENSEL | portControl | h);
		uPause (LTCHDLY);
		shiftreg (EN2, ENSEL | portControl | l);
		uPause (LTCHDLY);
		}

	// Restore line status for backlight
	port_out (m_iPort, backlight_bit);
}

