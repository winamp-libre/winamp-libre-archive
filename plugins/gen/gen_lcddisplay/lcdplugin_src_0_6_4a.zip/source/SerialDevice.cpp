/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// SerialDevice.cpp: implementation of the CDevSerial class.
// 
// Serial port code taken from Ties Bos Winamp Universal Infrared Plugin 
//
//////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2002/07/07 MZ  DTR and RTS must be enabled to power Crystalfontz LCD
// 
//
/////////////////////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "SerialDevice.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevSerial::CDevSerial()
{
	m_comPort = INVALID_HANDLE_VALUE;
	m_Rov.hEvent = INVALID_HANDLE_VALUE;
	m_Wov.hEvent = INVALID_HANDLE_VALUE;
}

CDevSerial::~CDevSerial()
{
	Close();
}


BOOL CDevSerial::Open(LPCSTR lpPort, LPCSTR lpParam)
{
	DCB comState;
	DCB newComState;
	char *errmsg=NULL;

	Close();
	
		m_Rov.Internal=m_Rov.InternalHigh=m_Rov.Offset=m_Rov.OffsetHigh=0;
		m_Rov.hEvent=INVALID_HANDLE_VALUE;
		// create event for overlapped I/O
		m_Rov.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
		if (m_Rov.hEvent == INVALID_HANDLE_VALUE)
			return FALSE;

		m_Wov.Internal=m_Wov.InternalHigh=m_Wov.Offset=m_Wov.OffsetHigh=0;
		m_Wov.hEvent=INVALID_HANDLE_VALUE;
		// create event for overlapped I/O
		m_Wov.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
		if (m_Wov.hEvent == INVALID_HANDLE_VALUE) {
			CloseHandle(m_Rov.hEvent);
			return FALSE;
		}

		m_comPort = CreateFile(lpPort,GENERIC_READ | GENERIC_WRITE,0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED,NULL);
		
		if (m_comPort != INVALID_HANDLE_VALUE)
		{
			if (GetCommState(m_comPort,&comState))
			{
				newComState = comState;
				BuildCommDCB(lpParam, &newComState);
				// DTR and RTS must be enabled to power Crystalfontz LCD, MZ 2002/07/07
				newComState.fDtrControl = DTR_CONTROL_ENABLE;
				newComState.fRtsControl = RTS_CONTROL_ENABLE;

				if (SetCommState(m_comPort,&newComState))
				{
					PurgeComm(m_comPort,PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
				}
				else
				{
					errmsg="Could not open comport: SetCommState returned an Error";
					CloseHandle(m_comPort);
					m_comPort = INVALID_HANDLE_VALUE;
				}
			}
			else
			{
				errmsg="Could not open comport: GetCommState returned an Error";
				CloseHandle(m_comPort);
				m_comPort = INVALID_HANDLE_VALUE;
			}
		}
		else {
			errmsg="Could not initialize COM-port.\nMake sure you set the COM-port correct.";
		}

		switch (GetLastError()) {
			case 2: errmsg="Could not open comport : port does not exist.\nMake sure the port is enabled in the BIOS and exists in\nControl Panel -> System -> Ports."; break;
			case 5: errmsg="Could not open comport : Windows denied access.\nMake sure you set the COM-port correct."; break;
		}

		if (m_comPort == INVALID_HANDLE_VALUE) {

			// @TODO change error handling, it's not a good idea to display an error msg here MZ 2002/01/10
			if (errmsg) 
				MessageBox(g_Plugin.hwndParent,errmsg,"Error",MB_ICONEXCLAMATION|MB_OK);
			else 
				MessageBox(g_Plugin.hwndParent,"Could not initialize COM-port.\nMake sure you set the COM-port correct.","Error",MB_ICONEXCLAMATION|MB_OK);

			CloseHandle(m_Rov.hEvent);
			m_Rov.hEvent = INVALID_HANDLE_VALUE;
			CloseHandle(m_Wov.hEvent);
			m_Wov.hEvent = INVALID_HANDLE_VALUE;
			return FALSE;
		} 

	m_bOpen = TRUE;
	return TRUE;
}

BOOL CDevSerial::Close()
{
	m_bOpen = FALSE;

	if (m_comPort != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_comPort);
		m_comPort = INVALID_HANDLE_VALUE;
	}

	if (m_Rov.hEvent != INVALID_HANDLE_VALUE) {
		CloseHandle(m_Rov.hEvent);
		m_Rov.hEvent = INVALID_HANDLE_VALUE;
	}

	if (m_Wov.hEvent != INVALID_HANDLE_VALUE) {
		CloseHandle(m_Wov.hEvent);
		m_Wov.hEvent = INVALID_HANDLE_VALUE;
	}

	return TRUE;
}

BOOL CDevSerial::WriteData(BYTE data)
{
	DWORD write;
	int x;
    
	if (m_comPort == INVALID_HANDLE_VALUE) {
		TRACE("CDevSerial::WriteData failed! COM-port is closed");
		return FALSE;
	}

	if (!WriteFile(m_comPort,&data,1,&write,&m_Wov)) {
		x = GetLastError();
		if (x == ERROR_IO_PENDING) {
			while (!GetOverlappedResult(m_comPort,&m_Wov,&write,TRUE)) // wait until write completes!
			{
               if(GetLastError() != ERROR_IO_INCOMPLETE) // "incomplete" is normal result if not finished
               {	// an error occurred, try to recover
		   		   return FALSE;
               }
			}
		}
		else {
			return FALSE;
		}
	}

	return TRUE;
}

BOOL CDevSerial::WriteData(const BYTE *buf, int length)
{
	DWORD write;
	int x;
    
	if (m_comPort == INVALID_HANDLE_VALUE) {
		TRACE("CDevSerial::WriteData failed! COM-port is closed");
		return FALSE;
	}

	if (!WriteFile(m_comPort, buf, length, &write, &m_Wov)) {
		x = GetLastError();
		if (x == ERROR_IO_PENDING) {
			while (!GetOverlappedResult(m_comPort,&m_Wov,&write,TRUE)) // wait until write completes!
			{
               if(GetLastError() != ERROR_IO_INCOMPLETE) // "incomplete" is normal result if not finished
               {	// an error occurred, try to recover
		   		   return FALSE;
               }
			}
		}
		else {
			return FALSE;
		}
	}

	return TRUE;
}

int CDevSerial::ReadData(LPBYTE buffer, DWORD size, BOOL blocking)
{
	DWORD read = 0;
	int x;

	if (ReadFile(m_comPort,buffer,size,&read,&m_Rov))
	{
		return read;
	}
	else
	{
		switch (x=GetLastError())
		{
		case ERROR_IO_PENDING:
			if (blocking)
			{
				while (!GetOverlappedResult(m_comPort,&m_Rov,&read,TRUE)) // wait until read completes!
				{
					if(GetLastError() != ERROR_IO_INCOMPLETE)	// "incomplete" is normal result if not finished
					{
						break;	// an error occurred, try to recover
					}
				}
				return read;
			}
			else 
			{
				return FALSE;
			}

		default:
			return FALSE;
		}
	}
}

