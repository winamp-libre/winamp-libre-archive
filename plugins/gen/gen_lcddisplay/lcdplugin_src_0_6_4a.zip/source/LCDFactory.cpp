/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LCDFactory.cpp: implementation of the CLCDFactory class.
//
//
// Modifications:
// 2000/07/28 MZ  initialization bug fixes (g_LCD null test etc.)
// 2000/07/30 MZ  try/catch sections for LCD init & close -> catches illegal HD44780 driver execution under NT
// 2003/01/19 MZ  replaced Windows Timer functions 'WinampTimerFunc' and 'OutputTimerFunc' with threads. (Didn't work with the input design...)
//                Method EnableOutput added
// 2003/01/21 MZ  bugfix: restarting LCD drivers works again
// 2003/02/09 MZ  improved shutdown procedure
// 2003/08/03 MZ  dynamic driver handling with RegisterDriver: no longer hard coded driver indexes!
//
// TODO: - release COM server (very low priority)
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "LCDServer.h"
#include "LCDFactory.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "MOrbitalLcd.h"
#include "LcdMOGlk.h"
#include "ComLCD.h"
#include "LcdHD44780.h"
//FVerhamm
#include "ScreenSimLcd.h"
//FVerhamm
#include "LcdCrystalFontz.h"
#include "LcdNoritake.h"
#include "LcdScottEdwards.h"
#include "LcdHD667xx.h"
//TSchirme
#include "LcdSED153X.h"

#include "LcdMilfordBPK.h"
#include "LcdPjrc.h"


extern BOOL g_bOutput;
extern CRITICAL_SECTION critSecLCDWrite;

volatile BOOL CLCDFactory::m_bTerminate = FALSE;

#include "MOrbitalLcd.h"
#include "LcdHD44780.h"
#include "LcdHD44780NT.h"
#include "DlgCfgMOrbital.h"
#include "DlgCfgHD44780.h"
#include "DlgCfgScreenSim.h"
#include "ScreenSimLcd.h"
#include "LcdCrystalFontz.h"
#include "DlgCfgCrystalfontz.h"
#include "LcdNoritake.h"
#include "DlgCfgNoritake.h"
#include "LcdHD667xx.h"
#include "LcdScottEdwards.h"
#include "DlgCfgScottEdwards.h"
#include "LcdSED153X.h"
#include "DlgCfgSED153X.h"
#include "LcdMOGlk.h"
#include "LcdMilfordBPK.h"
#include "DlgCfgHD667xx.h"
#include "LcdPjrc.h"
#include "DlgCfgPJRC.h"

//LCD_DRIVER	drivers[DRV_COUNT];

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CLCDFactory::CLCDFactory()
{
	m_bTerminate = FALSE;
	g_LCD = NULL;
	m_hLCDOutput = NULL;
	m_hWinampPoll = NULL;

	m_bClosed = TRUE;

	RegisterDriver(DRV_SIM,          "Onscreen Simulation",		new CLcdSim(), new CDlgCfgScreenSim());
	RegisterDriver(DRV_MORBITAL,     "Matrix Orbital LCD / VFD", new CLcdMOrbital(), new CDlgCfgMOrbital());
	RegisterDriver(DRV_HD44780,      "HD44780 (Win9x only!)",	new CLcdHD44780(), new CDlgCfgHD44780());
	RegisterDriver(DRV_HD44780NT,    "HD44780 (Windows NT)",		new CLcdHD44780NT(), new CDlgCfgHD44780());
	RegisterDriver(DRV_CRYSTALFONTZ, "Crystalfontz 632/634 Serial LCD's", new CLcdCrystalFontz(), new CDlgCfgCrystalfontz());
	RegisterDriver(DRV_NORITAKE,     "Noritake VFD 800",			  new CLcdNoritake(), new CDlgCfgNoritake());
	RegisterDriver(DRV_SCOTTEDWARDS, "Scott Edwards Serial LCD's", new CLcdScottEdwards(), new CDlgCfgScottEdwards());
	RegisterDriver(DRV_SED153X,      "Optrex SED153x LCD",         new CLcdSED153X(), new CDlgCfgSED153X());
	RegisterDriver(DRV_MILFORDBPK,   "Milford Inst 4x20 bpk+ Serial LCD", new CLcdMilfordBPK(), NULL);
	RegisterDriver(DRV_HD667xx,      "HD667xx (9x & NT)",		new CLcdHD667xx(), new CDlgCfgHD667xx());
	RegisterDriver(DRV_PJRC,         "PJRC",		                new CLcdPjrc(), new CDlgCfgPJRC());
// future drivers:
//	RegisterDriver(DRV_MORBITALGLK,  "Matrix Orbital GLK",		new CLcdMOGlk(), NULL);

}

CLCDFactory::~CLCDFactory()
{
	Terminate();

   POSITION pos;
   LCD_DRIVER *pDrv;
      
   for (pos = m_mapDrv.First(); pos != NULL; )
   {
		pDrv = (LCD_DRIVER *)m_mapDrv.GetData(pos);

		if (pDrv != NULL) {
			delete pDrv->pcLcd;
			if (pDrv->pcCfgDlg)
				delete pDrv->pcCfgDlg;
			delete pDrv;
		}

		pos = m_mapDrv.Next(pos);
   }
}

void CLCDFactory::RegisterDriver(LCD_DRIVER *drv)
{
	m_mapDrv.Set(drv->szID, (ULONG)drv);
}

void CLCDFactory::RegisterDriver(char *szID, char *szName, CLcd *pcLcd,	CDialog *pcCfgDlg)
{
	LCD_DRIVER *drv = new LCD_DRIVER;
	drv->szID = szID;
	drv->szName = szName;
	drv->pcLcd = pcLcd;
	drv->pcCfgDlg = pcCfgDlg;

	RegisterDriver(drv);
}

CLcd * CLCDFactory::GetLCDDriver()
{
	// load cfg
	g_44780Cfg.Load(g_szIniFile);
	g_667xxCfg.Load(g_szIniFile);
	g_MOCfg.Load(g_szIniFile);
	g_MOGlkCfg.Load(g_szIniFile);
	g_SimCfg.Load(g_szIniFile);
	g_CFCfg.Load(g_szIniFile);
	g_NoritakeCfg.Load(g_szIniFile);
	g_SECfg.Load(g_szIniFile);
	g_SEDCfg.Load(g_szIniFile);
	g_MilfordCfg.Load(g_szIniFile);
	g_PjrcCfg.Load(g_szIniFile);

	if (g_Config.bLocal) {
		LCD_DRIVER *pDrv = GetDriver(g_Config.szDriver);

		if (pDrv == NULL) {
			return NULL;
		}

		return pDrv->pcLcd;
	} else {
		// Initialize COM
		CoInitialize(NULL);

		CComLCD *pcLCD = new CComLCD;
		if (!pcLCD->Create()) {
			delete pcLCD;
			return NULL;
		} else {
			return pcLCD;
		}
	}
}

LCD_DRIVER * CLCDFactory::GetDriver(char *szID) {

	return (LCD_DRIVER *)m_mapDrv.Get(szID);
}

POSITION CLCDFactory::FirstDriver() {
	return m_mapDrv.First();
}

POSITION CLCDFactory::NextDriver(POSITION pos) {
	return m_mapDrv.Next(pos);
}

LCD_DRIVER * CLCDFactory::GetDriver(POSITION pos) {

	return (LCD_DRIVER *)m_mapDrv.GetData(pos);
}

BOOL CLCDFactory::OpenLCD(CLcd *pcLcd)
{
	if (pcLcd == NULL)
		return FALSE;

	try
	{
		if (g_LCD && g_LCD->IsOpen())	// bugfix: g_LCD might be null, MZ July 28 2k
			CloseLCD();

		m_bClosed = FALSE;

		if (pcLcd->Open())
		{
			m_bTerminate = FALSE;

			if (g_Config.bBacklight)
				pcLcd->SetBacklight( g_Config.iBacklightTimeout );
			else
				pcLcd->SetBacklight( -1 );

			CString csMsg;
			TCHAR  szBuf[100];
			// CString.LoadString cannot be used if called by an input driver (missing hInstance!) MZ 20030803
			LoadString(g_Plugin.hDllInstance, IDS_COPYRIGHT_MSG, szBuf, 100);
			csMsg.Format(szBuf, COPYRIGHTOWNER);
			pcLcd->Clear();
			pcLcd->Home();
			pcLcd->Write(csMsg);

			// here we go!
			g_LCD = pcLcd;
			SetCustomChars();

			// start winamp polling thread (MZ 2003/01/19 replaced timer with thread)
			if (g_Config.byWinAmpPoll == 0)
				g_Config.byWinAmpPoll = DEF_WINAMPPOLL;
		    
			m_hWinampPoll = CreateThread(NULL, 0, WinampPollThread, (LPVOID)&m_bTerminate, 0, &m_dwThreadIDWinampPoll);
			SetThreadPriority(m_hWinampPoll, THREAD_PRIORITY_ABOVE_NORMAL);


			// wait a second for reading the intro text on the display :-)
			Sleep(1000);
			pcLcd->Clear();

			// start output thread (MZ 2003/01/19 replaced timer with thread)
			if (g_Config.byLCDRefresh == 0)
				g_Config.byLCDRefresh = DEF_LCDREFRESH;

			m_hLCDOutput = CreateThread(NULL, 0, LCDOutputThread, (LPVOID)&m_bTerminate, 0, &m_dwThreadIDLCDOutput);
			SetThreadPriority(m_hLCDOutput, THREAD_PRIORITY_ABOVE_NORMAL);
			
			g_bOutput = TRUE;

			// start scroll timer function
			g_uiScrollTimer = SetTimer(NULL, NULL, g_Config.iScrollTimeStart + 
				(g_Config.byScrollSteps - g_Config.byScrollSpeed + 1) * g_Config.iScrollTimeStep,
				(TIMERPROC)ScrollTimerFunc);
			return TRUE;
		}
		else
		{
			CString warning;
			warning.LoadString(IDS_WARN6);
			MessageBox( g_Plugin.hwndParent, warning, g_szAppName, MB_ICONSTOP );
		}
	} catch (...)
	{
		CString warning1;
		warning1.LoadString(IDS_WARN7);
		MessageBox( g_Plugin.hwndParent, warning1, g_szAppName, MB_ICONSTOP );
		CloseLCD();
	}
	return FALSE;
}

BOOL CLCDFactory::CloseLCD()
{
	if (m_bClosed) {
		return TRUE;
	}
	m_bClosed = TRUE;

	KillTimer( NULL, g_uiScrollTimer );

	EnableOutput(FALSE);

	// terminate all threads  MZ 2002/01/19
	m_bTerminate = TRUE;

	if (m_hLCDOutput) {
		if (WaitForSingleObject(m_hLCDOutput, 1000) == WAIT_FAILED) {
			TRACE0("Error waiting for LCDOutputThread.\n");
		}

		CloseHandle(m_hLCDOutput);
		m_hLCDOutput = NULL;
	}

	if (m_hWinampPoll) {
		if (WaitForSingleObject(m_hWinampPoll, 1000) == WAIT_FAILED) {
			TRACE0("Error waiting for WinampPollThread.\n");
		}

		CloseHandle(m_hWinampPoll);
		m_hWinampPoll = NULL;
	}

	if (g_LCD == NULL)
		return FALSE;

	try
	{
		// MZ 2002/02/18 clear must be called before backlight for the 44780 driver otherwise the cells of the 2nd controller won't clear! bug ???
		g_LCD->Clear();
		g_LCD->SetBacklight(-1);
		g_LCD->Close();
	} catch (...) {
		g_LCD = NULL;
	}

	return TRUE;
}

void CLCDFactory::Terminate()
{
	g_44780Cfg.Save(g_szIniFile);
	g_667xxCfg.Save(g_szIniFile);
	g_MOCfg.Save(g_szIniFile);
	g_MOGlkCfg.Save(g_szIniFile);
	g_SimCfg.Save(g_szIniFile);
	g_CFCfg.Save(g_szIniFile);
	g_NoritakeCfg.Save(g_szIniFile);
	g_SECfg.Save(g_szIniFile);
	g_SEDCfg.Save(g_szIniFile);
	g_MilfordCfg.Save(g_szIniFile);
	g_PjrcCfg.Save(g_szIniFile);


	CloseLCD();

	g_LCD = NULL;
}

void CLCDFactory::EnableOutput(BOOL state)
{

	// 20030706 MZ bugfix only aquire write lock if there's a display device!
	if (g_LCD != NULL) {
		// wait until all input and output threads finished the current loop
		while(!AcquireWriteLock(&g_OutputLock));

		// now it's safe to change the output flag 
		g_bOutput = state;

		// clear display
		EnterCriticalSection(&critSecLCDWrite);

		g_LCD->Clear();

		LeaveCriticalSection(&critSecLCDWrite);
	}

	if (g_bOutput) {
		// redraw all fields
		g_bUpdateAll = TRUE;
	}

	if (g_LCD != NULL) {
		ReleaseWriteLock(&g_OutputLock);
	}

	// now the caller either has total control over the LCD or just released it
}
