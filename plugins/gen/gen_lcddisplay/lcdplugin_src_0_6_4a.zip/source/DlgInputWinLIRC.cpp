/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// WinLIRC input driver configuration dialog
// Most bits of this code has been taken from the WinLIRC WinAmp plugin by Jim Paris
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/02/09 MZ  extended input (default/menu/set actions)
// 2003/06/03 MZ  bugfix: serial map was clear instead winlirc map!
// 2003/06/06 MZ  cfg dlg added, moved server and port cfg into cfg dialog
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgInputWinLIRC.h"
#include "DlgInputAdd.h"
#include "InputWinLIRC.h"
#include "DlgCfgWinLIRCInput.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInputWinLIRC property page

IMPLEMENT_DYNCREATE(CDlgInputWinLIRC, CPropertyPage)

CDlgInputWinLIRC::CDlgInputWinLIRC() : CDlgInput(CDlgInputWinLIRC::IDD)
{
	//{{AFX_DATA_INIT(CDlgInputWinLIRC)
	m_bEnabled = FALSE;
	m_csState = _T("");
	//}}AFX_DATA_INIT
}

CDlgInputWinLIRC::~CDlgInputWinLIRC()
{
}

void CDlgInputWinLIRC::DoDataExchange(CDataExchange* pDX)
{
	CDlgInput::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInputWinLIRC)
	DDX_Control(pDX, IDC_LIST_WINLIRC, m_cList);
	DDX_Check(pDX, IDC_WL_ENABLED, m_bEnabled);
	DDX_Text(pDX, IDC_STATE, m_csState);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInputWinLIRC, CDlgInput)
	//{{AFX_MSG_MAP(CDlgInputWinLIRC)
	ON_BN_CLICKED(IDC_BTN_WL_ADD, OnAdd)
	ON_BN_CLICKED(IDC_BTN_WL_DEL, OnDelete)
	ON_BN_CLICKED(IDC_BTN_WL_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_BTN_WL_DISCONNECT, OnDisconnect)
	ON_BN_CLICKED(IDC_BTN_WL_EDIT, OnBtNEdit)
	ON_BN_CLICKED(IDC_BTN_WL_CFG, OnCfg)
	ON_EN_CHANGE(IDC_WINLIRC_SERVER, SetModified)
	ON_EN_CHANGE(IDC_WINLIRC_PORT, SetModified)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_WINLIRC, OnDblclkListWinlirc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInputWinLIRC message handlers

BOOL CDlgInputWinLIRC::OnInitDialog() 
{
	CDlgInput::OnInitDialog();
	
	CString  csBuf;

	m_bEnabled = g_Config.bWLEnabled;

	ListView_SetExtendedListViewStyle 
		(m_cList.m_hWnd, LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT );

	// add columns
	csBuf.LoadString(IDS_CFG_WL_BUTTON);
	m_cList.InsertColumn( 0, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION);
	m_cList.InsertColumn( 1, csBuf);
	
	csBuf.LoadString(IDS_CFG_WL_ACTION_MENU);
	m_cList.InsertColumn(2, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_SET);
	m_cList.InsertColumn(3, csBuf);

	m_csState.LoadString(g_InWinLIRC.IsConnected() ? IDS_WL_CONNECT_YES : IDS_WL_CONNECT_NO);

	UpdateData(FALSE);

	// make our copy
	CString   key;
	INPUT_BTN *btn;

	for (POSITION pos = g_Config.mapInWinLirc.GetStartPosition(); pos != NULL; ){
		g_Config.mapInWinLirc.GetNextAssoc( pos, key, (void*&)btn );
		m_mapInput.SetAt(key, btn);
	}

	RefreshList();
	m_cList.AutoSizeColumns();		

	return TRUE;
}

void CDlgInputWinLIRC::OnAdd() 
{
	CDlgInput::OnAdd();
}

void CDlgInputWinLIRC::OnBtNEdit() 
{
	CDlgInput::OnEdit();
}

void CDlgInputWinLIRC::OnDelete() 
{
	CDlgInput::OnDelete();
}

BOOL CDlgInputWinLIRC::OnApply() 
{
	g_Config.bWLEnabled = m_bEnabled;

	CString   key;
	INPUT_BTN *btn;

	// @todo check for memory leak
	g_Config.mapInWinLirc.RemoveAll();

	for (POSITION pos = m_mapInput.GetStartPosition(); pos != NULL; ){
		m_mapInput.GetNextAssoc( pos, key, (void*&)btn );
		g_Config.mapInWinLirc.SetAt(key, btn);
	}

	return CDlgInput::OnApply();
}

void CDlgInputWinLIRC::OnConnect() 
{
	int id = IDS_WL_CONNECT_YES;

	if (!g_InWinLIRC.IsConnected()) {
		if (!g_InWinLIRC.InitDevice()) {
			MessageBox("Error connecting to server.","WinLIRC", MB_OK);
			id = IDS_WL_CONNECT_NO;
		}
	}

	m_csState.LoadString(id);
	UpdateData(FALSE);
}

void CDlgInputWinLIRC::OnDisconnect() 
{
	g_InWinLIRC.CloseDevice();
	
	m_csState.LoadString(IDS_WL_CONNECT_NO);
	UpdateData(FALSE);
}


void CDlgInputWinLIRC::OnCfg() 
{
	CDlgCfgWinLIRCInput	cDlg;

	cDlg.DoModal();
}

void CDlgInputWinLIRC::OnDblclkListWinlirc(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnEdit();
	
	*pResult = 0;
}
