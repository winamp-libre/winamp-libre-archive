/////////////////////////////////////////////////////////////////////////////
//
// ScreenSimLcd.cpp: implementation of the CLcdSim class.
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
//
// 2001/01/27 MZ  Made sim LCD window parent of Winamp
// 2002/01/10 MZ  use of generic backlight timeout, generic getter methods are now in the base class
// 2003/07/13 MZ  custom character map added 
//

#include "stdafx.h"
#include "ScreenSimLcd.h"
#include "gen_lcddisplay.h"
#include "lcdsim.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

#define SIM_SECTION	"Simulation"
#define SIM_CHARMAP "Simulation_CHARMAP"

#define MAX_CUSTOM_CHARS 8

#define BGCOLORON_RED    180
#define BGCOLORON_GREEN  205
#define BGCOLORON_BLUE   101
#define BGCOLOROFF_RED   84
#define BGCOLOROFF_GREEN 96
#define BGCOLOROFF_BLUE  48
#define FGCOLOR_RED      52
#define FGCOLOR_GREEN    78
#define FGCOLOR_BLUE     30

#define DispWnd_SetFgColor(hwnd,cFgCol) \
  (SetWindowLong((hwnd),5*sizeof(long),(LONG)(cFgCol)))

#define DispWnd_SetBkColor(hwnd,cBkCol) \
  (SetWindowLong((hwnd),6*sizeof(long),(LONG)(cBkCol)))

CCfgSim   g_SimCfg;

CCfgSim::CCfgSim()
{
	Load(g_szIniFile);
}

CCfgSim::~CCfgSim()
{
	Save(g_szIniFile);
}

void CCfgSim::Load(LPCSTR lpIniFile)
{
	bBlink =	  GetPrivateProfileInt(SIM_SECTION,"SetBlink",0,lpIniFile); 
	bScroll =	  GetPrivateProfileInt(SIM_SECTION,"SetScroll",0,lpIniFile); 
	bShowCursor = GetPrivateProfileInt(SIM_SECTION,"Cursor",0,lpIniFile); 
	bWrap =	      GetPrivateProfileInt(SIM_SECTION,"Wrap",1,lpIniFile);
	iRows =       GetPrivateProfileInt(SIM_SECTION, "Rows", 4, lpIniFile);
	iCols =       GetPrivateProfileInt(SIM_SECTION, "Columns", 20, lpIniFile);
	byContrast = (BYTE)GetPrivateProfileInt(SIM_SECTION,"Contrast", DEF_CONTRAST,lpIniFile); 
	BuildCharMap(SIM_CHARMAP, lpIniFile, charMap);
}

void CCfgSim::Save(LPCSTR lpIniFile)
{
	char string[32];

	wsprintf(string,"%d",bBlink);
	WritePrivateProfileString(SIM_SECTION,"SetBlink",string,lpIniFile);
	wsprintf(string,"%d",bScroll);
	WritePrivateProfileString(SIM_SECTION,"SetScroll",string,lpIniFile);
	wsprintf(string,"%d",bShowCursor);
	WritePrivateProfileString(SIM_SECTION,"Cursor",string,lpIniFile);
	wsprintf(string,"%d",bWrap);
	WritePrivateProfileString(SIM_SECTION,"Wrap",string,lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(SIM_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(SIM_SECTION,"Rows",string,lpIniFile);
	wsprintf(string,"%d",byContrast);
	WritePrivateProfileString(SIM_SECTION,"Contrast",string,lpIniFile);
}

/////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
/////////////////////////////////////////////////////////////////////////////
CLcdSim::CLcdSim()
{
	m_lLastError = 0;
	m_hScreen = INVALID_HANDLE_VALUE;
}

CLcdSim::~CLcdSim()
{
	Close();
}

void CLcdSim::SetBacklight(short nSeconds)
{
  StopBacklightTimer();

  if (m_hScreen != INVALID_HANDLE_VALUE)
  {
	if (nSeconds < 0)
	{
		LcdDisplaySim_LightOff((HWND)m_hScreen);
	}
	else 
	{
		if (nSeconds > 0)
			StartBacklightTimer(nSeconds);
	  
		LcdDisplaySim_LightOn((HWND)m_hScreen);
	}

	m_nBackLight = nSeconds;
  }
}

void  CLcdSim::SetBlink(BOOL bOn)
{
	m_bBlink = bOn;
}

void CLcdSim::Clear()
{
  if(m_hScreen != INVALID_HANDLE_VALUE)
	  LcdDisplaySim_Clear((HWND)m_hScreen);
}

void CLcdSim::Close()
{
	if(m_hScreen != INVALID_HANDLE_VALUE)
		LcdDisplaySim_Close((HWND) m_hScreen);

	m_hScreen = INVALID_HANDLE_VALUE;
}

BOOL CLcdSim::IsOpen()
{
	return(m_hScreen != INVALID_HANDLE_VALUE);
}

void  CLcdSim::SetContrast(short nLevel)
{
  int iDiffRed, iDiffGreen, iDiffBlue;
  int iResRed, iResGreen, iResBlue;

  if ((nLevel < 0) || (nLevel > 255))
		return;

  //umrechnen der Farbwerte
  // nLevel / 255 * (Differenz von Start-Endfarbe) + Startfarbe
  iDiffRed = BGCOLORON_RED - BGCOLOROFF_RED;
  iDiffGreen = BGCOLORON_GREEN - BGCOLOROFF_GREEN;
  iDiffBlue = BGCOLORON_BLUE - BGCOLOROFF_BLUE;

  iResRed   = (((nLevel*100)/255) * iDiffRed)/100   + BGCOLOROFF_RED;
  iResGreen = (((nLevel*100)/255) * iDiffGreen)/100 + BGCOLOROFF_GREEN;
  iResBlue  = (((nLevel*100)/255) * iDiffBlue)/100  + BGCOLOROFF_BLUE;

  LcdDisplaySim_SetContrast((HWND)m_hScreen, RGB(iResRed, iResGreen, iResBlue));

	m_nContrast = nLevel;
}

void  CLcdSim::Cursor(BOOL bOn)
{
	m_bCursor = bOn;
}

BOOL  CLcdSim::IsCursorOn()
{
	return m_bCursor;
}

long CLcdSim::GetLastError()
{
	return m_lLastError;
}

void CLcdSim::HBar(short nCol, short nRow, short nDir, short nLen)
{
}

void  CLcdSim::Home()
{
	LcdDisplaySim_SetCursorPos((HWND)m_hScreen,0,0);
}

void CLcdSim::InitHorizontalBar()
{
}

void CLcdSim::InitLargeDigit()
{
}

void CLcdSim::InitVerticalBar()
{
}

void CLcdSim::LargeDigit(short nCol, short nNumber)
{
}

void CLcdSim::SetLineWrap(BOOL bOn)
{
	m_bLineWrap = bOn;
}

// Function : Open
// Purpose  : Opens the Window and initializes the window
// Parameter: -
// Return   : TRUE if successful, otherwise FALSE
// Author   : Frank Verhamme
/////////////////////////////////////////////////////////////////////////////
BOOL CLcdSim::Open()
{
	HWND          hwndLCDSim = NULL;
	tLcdSimParams sParams; // Variable f�r die LCDSimulation

	// hack for backlight timer
	m_pInstance = this;

	sParams.hwndOwner = g_Plugin.hwndParent;	// set parent wnd, M.Zehnder Jan 27, 01
	sParams.hInstance = g_Plugin.hDllInstance;
	sParams.pTitle = "LCD Display";
	sParams.xPos = sParams.yPos = CW_USEDEFAULT;
	sParams.cxChars = g_LCD->GetColumns(); // MZ, July 20 2k g_Config.iCols;
	sParams.cyChars = g_LCD->GetRows();    // MZ, July 20 2k g_Config.iRows;
	sParams.sLightOn.cBkCol  = RGB(BGCOLORON_RED, BGCOLORON_GREEN, BGCOLORON_BLUE);
	sParams.sLightOn.cFgCol  = RGB(FGCOLOR_RED, FGCOLOR_GREEN, FGCOLOR_BLUE);
	sParams.sLightOff.cBkCol = RGB(BGCOLOROFF_RED, BGCOLOROFF_GREEN, BGCOLOROFF_BLUE);
	sParams.sLightOff.cFgCol = RGB(FGCOLOR_RED, FGCOLOR_GREEN, FGCOLOR_BLUE);

	hwndLCDSim = LcdDisplaySim_Open(&sParams);

	if(!hwndLCDSim)
	{
		m_hScreen = INVALID_HANDLE_VALUE;
		return FALSE;
	}
	else
	{
		m_hScreen = hwndLCDSim;
		SetContrast(g_SimCfg.byContrast);
	}

	//Clear();
	
	m_charMap = g_SimCfg.charMap;

	return TRUE;
}

void CLcdSim::SetPosition(short nCol, short nRow)
{
  if(m_hScreen != INVALID_HANDLE_VALUE)
	  LcdDisplaySim_SetCursorPos((HWND)m_hScreen,nCol-1,nRow-1);
}

void CLcdSim::SetScroll(BOOL bOn)
{
}

void CLcdSim::VBar(short nCol, short nLength)
{
}

void CLcdSim::Write(LPCSTR lpText)
{
	if(m_hScreen == INVALID_HANDLE_VALUE)
		return;

  try
  {
	static CString csText;
	csText = lpText;
	ConvertTextToLCDCharset(csText);

    LcdDisplaySim_PrintString((HWND)m_hScreen,csText);
  }
	catch(...)
	{
		#ifdef _DEBUG
			MessageBeep(-1);
		#endif
	}
}

BOOL CLcdSim::CreateCustomChar(short nNumber, CCustomChar &cChar)
{
	// MrMP3: Z�hler vor der benutzung um eins erh�hen,
	// dadurch verwenden wir die Zeichen 1 - 8
	// das sollte auch OK sein ;-)
	if((++nNumber > MAX_CUSTOM_CHARS) || (m_hScreen == INVALID_HANDLE_VALUE)) // >=
		return FALSE;

	LcdDisplaySim_SetCustomChar((HWND) m_hScreen,
		                        (int)nNumber,
								(char*)cChar.m_byarrData,
								(int)cChar.m_byDataSize);

	return TRUE;
}

short CLcdSim::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

LPCTSTR CLcdSim::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( "%c1", ch );
	ch[0] = (char)2;
	csText.Replace( "%c2", ch );
	ch[0] = (char)3;
	csText.Replace( "%c3", ch );
	ch[0] = (char)4;
	csText.Replace( "%c4", ch );
	ch[0] = (char)5;
	csText.Replace( "%c5", ch );
	ch[0] = (char)6;
	csText.Replace( "%c6", ch );
	ch[0] = (char)7;
	csText.Replace( "%c7", ch );
	ch[0] = (char)8;
	csText.Replace( "%c8", ch );

	return csText;
}

LPCTSTR CLcdSim::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( ch, "%c1" );
	ch[0] = (char)2;
	csText.Replace( ch, "%c2" );
	ch[0] = (char)3;
	csText.Replace( ch, "%c3" );
	ch[0] = (char)4;
	csText.Replace( ch, "%c4" );
	ch[0] = (char)5;
	csText.Replace( ch, "%c5" );
	ch[0] = (char)6;
	csText.Replace( ch, "%c6" );
	ch[0] = (char)7;
	csText.Replace( ch, "%c7" );
	ch[0] = (char)8;
	csText.Replace( ch, "%c8" );

	return csText;
}

int	CLcdSim::GetRows()		// MZ, July 20 2k
{
	return g_SimCfg.iRows;
}

int	CLcdSim::GetColumns()	// MZ, July 20 2k
{
	return g_SimCfg.iCols;
}

