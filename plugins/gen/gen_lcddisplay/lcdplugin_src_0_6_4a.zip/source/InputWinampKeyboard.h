// InputKeyboard.h: interface for the CInputWinampKeyboard class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUTWINAMPKEYBOARD_H__4A835842_B81B_461D_8CD9_92A170F97F45__INCLUDED_)
#define AFX_INPUTWINAMPKEYBOARD_H__4A835842_B81B_461D_8CD9_92A170F97F45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Input.h"

#define DEF_LONGKEYPRESS_TIME  200

class CInputWinampKeyboard : public CInput  
{
private:

protected:
	int   m_iLastKey;
	long  m_lKeypressTime;
	long  m_lTimeoutLong;
	BOOL  m_bLongProcessed;

public:
	CInputWinampKeyboard();
	virtual ~CInputWinampKeyboard();

// Overrides
public:
	virtual BOOL CloseDevice();
	virtual BOOL ReadConfig(LPCSTR lpIniFile);
	virtual BOOL WriteConfig(LPCSTR lpIniFile);
	virtual BOOL InitDevice();

protected:
	virtual BOOL HandleKey(int key, long lHoldTime);
	void ClearMap();
	static LRESULT CALLBACK HookWinampWnd(
						  HWND hwnd,      // handle to window
						  UINT uMsg,      // message identifier
						  WPARAM wParam,  // first message parameter
						  LPARAM lParam   // second message parameter
						);
};

#endif // !defined(AFX_INPUTWINAMPKEYBOARD_H__4A835842_B81B_461D_8CD9_92A170F97F45__INCLUDED_)
