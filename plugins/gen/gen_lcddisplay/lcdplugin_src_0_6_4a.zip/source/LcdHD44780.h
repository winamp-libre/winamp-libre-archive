/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LcdHD44780.h: interface for the CLcdHD44780 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LCDHD44780_H__284FE561_BF2B_11D3_8F31_0000E871C360__INCLUDED_)
#define AFX_LCDHD44780_H__284FE561_BF2B_11D3_8F31_0000E871C360__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Lcd.h"
#include "DevParallel44780.h"

#ifdef  FONTSIZE
	#undef  FONTSIZE
#endif
#define FONTSIZE 0
   // 4= 7line font 0=10 line font  (default was 0=10 line andrewm)


// !!! DEVELOPMENT SWITCH TO ENABLE AND TEST NEW DRIVER ARCHITECTURE !!!
#define USE_NEW_DRIVER


#define LCDCLOCK 16
#define LCDDATA 8

// commands for WriteData
#define RS_DATA     0x00
#define RS_INSTR    0x01

#define CLEAR       0x01

#define HOMECURSOR  0x02

#define ENTRYMODE   0x04
#define E_MOVERIGHT 0x02
#define E_MOVELEFT  0x00
#define EDGESCROLL  0x01
#define NOSCROLL    0x00

#define ONOFFCTRL   0x08
#define DISPON      0x04
#define DISPOFF     0x00
#define CURSORON    0x02
#define CURSOROFF   0x00
#define CURSORBLINK 0x01
#define CURSORNOBLINK 0x00

#define CURSORSHIFT 0x10
#define SCROLLDISP  0x08
#define MOVECURSOR  0x00
#define MOVERIGHT   0x04
#define MOVELEFT    0x00

#define FUNCSET     0x20
#define IF_8BIT     0x10
#define IF_4BIT     0x00
#define TWOLINE     0x08
#define ONELINE     0x00
#define LARGECHAR   0x04		  /* 5x11 characters */
#define SMALLCHAR   0x00		  /* 5x8 characters */

#define SETCHAR     0x40

#define POS         0x80

// default delay values in us
#define DEF_DELAY_SHORT		  40
#define DEF_DELAY_MED		 100
#define DEF_DELAY_LONG		1600
#define DEF_DELAY_INIT		4100
#define DEF_DELAY_BUS		  17
#define DEF_DELAY_MULTIPLIER   1


/* Control output lines
 * Write to baseaddress+2
 */
#define nSTRB 	0x01	/* negative logic */
#define STRB 	0x01
#define nLF 	0x02
#define LF 		0x02
#define INIT 	0x04	/* the only positive logic output line */
#define nSEL 	0x08
#define SEL 	0x08
#define ENIRQ	0x10	/* Enable IRQ via ACK line */
#define ENBI	0x20	/* Enable bi-directional port */

#define OUTMASK	0x0B	/* SEL, LF and STRB are hardware inverted */
			/* Use this mask only for the control output lines */
			/* XOR with this mask ( ^ OUTMASK ) */


/* Control input lines
 * Read from baseaddress+1
 */
#define nFAULT		0x08
#define FAULT		0x08
#define SELIN		0x10
#define PAPEREND	0x20
#define nACK		0x40
#define ACK			0x40
#define BUSY		0x80
#define IRQ			0x02

#define INMASK	0x84	/* BUSY input and the IRQ indicator are inverted */
			/* Use this mask only for the control input lines */
			/* XOR with this mask ( ^ OUTMASK ) */


class CCfg44780
{
public:
	CCfg44780();
	~CCfg44780();
	void Load(LPCSTR lpIniFile);
	void Save(LPCSTR lpIniFile);

public:
	int		iPort;
	int		iRows;
	int		iCols;
	BYTE    byInterface;
	BOOL    bBacklight;
	BYTE	byCellW, byCellH;
	BOOL	bSplitScreens;
	int		iDelayShort;
	int     iDelayMed;
	int		iDelayLong;
	int		iDelayInit;
	int		iDelayBus;
	int		iDelayMultiplier;
	DELAY_TYPES   DelayType;
	tULongToULong charMap;
};

extern	CCfg44780	 g_44780Cfg; 

class CLcdHD44780 : public CLcd  
{
public:
	CLcdHD44780();
	virtual ~CLcdHD44780();

	virtual void  SetBacklight(short nSeconds);
	virtual void  SetBlink(BOOL On);
	virtual void  Clear();
	virtual void  Close();
	virtual void  SetContrast(short nLevel);
	virtual void  Cursor(BOOL bOn);
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen);
	virtual void  InitHorizontalBar();
	virtual void  InitLargeDigit();
	virtual void  InitVerticalBar();
	virtual void  LargeDigit(short nCol, short nNumber);
	virtual void  SetLineWrap(BOOL bOn);
	virtual BOOL  Open();
	virtual void  SetPosition(short nCol, short nRow);
	virtual void  SetScroll(BOOL bOn);
	virtual void  VBar(short nCol, short nLength);
	virtual void  Write(char c);
	virtual void  Write(LPCSTR lpText);
	virtual BOOL  CreateCustomChar(short nNumber, CCustomChar &cChar);
	virtual short GetMaxCustomChar();
	virtual LPCTSTR ConvertTagsToCustomChars(CString &csText);
	virtual LPCTSTR ConvertCustomCharsToTags(CString &csText);
	virtual int		GetRows();		// MZ, June 27
	virtual int		GetColumns();	// MZ, June 27
	virtual CDevParallel* GetParallelDevice();
	virtual void HandleKeyPad();

protected:
	BYTE	SECONDLCDEN, RS, LCDEN;
	BOOL	m_bSplitScreens;
	BOOL	m_bInit;
	int		lcd_x, lcd_y;

	CDevParallel44780 *m_pcDev;


	virtual void SetChar(int n, char *dat);
	virtual void WriteData(unsigned char displayID, unsigned char flags, unsigned char ch);
};

#endif // !defined(AFX_LCDHD44780_H__284FE561_BF2B_11D3_8F31_0000E871C360__INCLUDED_)
