//=========================================================================
//
// Copyright � Dundas Software Ltd. 1998, All Rights Reserved
//
// zserial.h : header file
//
//==========================================================================

// conditional compilation to avoid multiple defintions
#ifndef _zserial_h_
#define _zserial_h_

#ifndef _zlib_h
#include "zlib.h"
#endif

//==========================================================================
// zSerial - Base class for all classes serializable to standard iostreams.
//==========================================================================

class EXT_CLASS zSerial
{
public:
    zSerial();
    virtual ~zSerial();

    // serialization using standard streams
    virtual int Store(NQ ostream* ostrm);              // 1 if success, else 0
    virtual int Load(NQ istream* istrm);               // 1 if success, else 0

protected:    
    // serialization helpers for derived classes
    int streamWrite(NQ ostream* strm, void* addr, long len);   // structs etc.
    int streamWrite(NQ ostream* strm, const char* addr);       // null-terminated
    int streamRead(NQ istream* strm, void* buf, long bufSize); // structs etc.
    int streamRead(NQ istream* strm, char* buf, long bufSize, long& bytesRead);    // null-terminated
};

#endif
//// end ///////////////////////////////////////////////////////////////////
