//=========================================================================
//
// Copyright � Dundas Software Ltd. 1998, All Rights Reserved
//
// zserial.cpp : implementation file
//
//=========================================================================

#include "stdafx.h"

#include "zserial.h"                      // class header


//==========================================================================
// zSerial - Base class for all classes serializable to standard iostreams.
//==========================================================================


// default ctor.
zSerial::zSerial()
{
}

// default dtor.
zSerial::~zSerial()
{
}

// store the object into the stream.
int zSerial::Store(NQ ostream* ostrm)
{
    return 1;       // indicate success unless overridden
}

// load the object from the stream.
int zSerial::Load(NQ istream* istrm)
{
    return 1;       // indicate success unless overridden
}

// variable-length write for strings.
int zSerial::streamWrite(NQ ostream* strm, const char* addr)
{
    long len = strlen(addr) + 1;    // write null terminator too
    return streamWrite(strm, (void*)addr, len);
}

// fixed-length write for structs etc.
int zSerial::streamWrite(NQ ostream* strm, void* addr, long len)
{
    strm->write((const char*)addr, (int)len);
    return strm->good();
}

// fixed-length read for structs etc.
int zSerial::streamRead(NQ istream* strm, void* buf, long bufSize)
{
    strm->read((char*)buf, (int)bufSize);
    return (strm->good() && !strm->eof()) ? 1 : 0;
}

// variable-length read for strings.
// (note: getline() appears buggy for zero delimiter.)
int zSerial::streamRead(NQ istream* strm, char* buf, long bufSize, long& bytesRead)
{
    char* ptr = (char*)buf;
    bytesRead = 0;
    int success = 1;
    int c;
    while (bufSize && success)
    {
        c = strm->get();
        success = (strm->good() && !strm->eof()) ? 1 : 0;
        if (success)
        {
            *ptr++ = c;
            bufSize--;
            bytesRead++;
            if (!c)
                break;          // encountered null terminator
        }
    }
    return success;
}
