/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Serial port input driver configuration dialog
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/01/12 MZ  additional cfg button
// 2003/02/09 MZ  extended input (default/menu/set actions)
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgInputSerial.h"
#include "DlgCfgSerialInput.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInputSerial property page

IMPLEMENT_DYNCREATE(CDlgInputSerial, CPropertyPage)

CDlgInputSerial::CDlgInputSerial() : CDlgInput(CDlgInputSerial::IDD)
{
	//{{AFX_DATA_INIT(CDlgInputSerial)
	m_bLCDPort = FALSE;
	m_csBaud = _T("");
	m_csPort = _T("");
	m_bEnabled = FALSE;
	//}}AFX_DATA_INIT
}

CDlgInputSerial::~CDlgInputSerial()
{
}

void CDlgInputSerial::DoDataExchange(CDataExchange* pDX)
{
	CDlgInput::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInputSerial)
	DDX_Check(pDX, IDC_CHECK_LCD_PORT, m_bLCDPort);
	DDX_CBString(pDX, IDC_COMBO_BAUDRATE, m_csBaud);
	DDX_CBString(pDX, IDC_COMBO_COMPORT, m_csPort);
	DDX_Control(pDX, IDC_LIST_MOKEYPAD, m_cList);
	DDX_Check(pDX, IDC_SERIAL_ENABLED, m_bEnabled);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInputSerial, CDlgInput)
	//{{AFX_MSG_MAP(CDlgInputSerial)
	ON_BN_CLICKED(IDC_BTN_MO_ADD, OnAdd)
	ON_BN_CLICKED(IDC_BTN_MO_DEL, OnDelete)
	ON_BN_CLICKED(IDC_CHECK_LCD_PORT, OnCheckMOKeypad)
	ON_BN_CLICKED(IDC_BUTTON_OPEN, OnButtonOpen)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, OnButtonClose)
	ON_BN_CLICKED(IDC_BTN_SER_CFG, OnBtnConfig)
	ON_BN_CLICKED(IDC_BTN_SER_EDIT, OnBtnEdit)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_MOKEYPAD, OnDblclkList)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInputSerial message handlers

BOOL CDlgInputSerial::OnInitDialog() 
{
	CDlgInput::OnInitDialog();

	CString  csBuf;
	
	ListView_SetExtendedListViewStyle 
		(m_cList.m_hWnd, LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT );

	// add columns
	csBuf.LoadString(IDS_CFG_SERIAL_BUTTON);
	m_cList.InsertColumn( 0, csBuf);

	csBuf.LoadString(IDS_CFG_SERIAL_ACTION);
	m_cList.InsertColumn( 1, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_MENU);
	m_cList.InsertColumn(2, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_SET);
	m_cList.InsertColumn(3, csBuf);

	m_bEnabled = g_Config.bInSerialEnabled;
	m_bLCDPort = g_Config.bInSerialLCDport;
	m_csPort = g_Config.szInSerialPort;
	m_csBaud = g_Config.szInSerialBaud;
	
	// check if active driver supports key pads
	if (g_LCD->GetSerialDevice() == NULL) {
		GetDlgItem(IDC_CHECK_LCD_PORT)->EnableWindow(FALSE);
		m_bLCDPort = FALSE;
	}

	UpdateData(FALSE);
	
	// make our copy
	CString   key;
	INPUT_BTN *btn;

	for (POSITION pos = g_Config.mapInSerial.GetStartPosition(); pos != NULL; ){
		g_Config.mapInSerial.GetNextAssoc( pos, key, (void*&)btn );
		m_mapInput.SetAt(key, btn);
	}

	RefreshList();
	m_cList.AutoSizeColumns();		

	OnCheckMOKeypad();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CDlgInputSerial::OnApply() 
{
	g_Config.bInSerialEnabled = m_bEnabled;
	g_Config.bInSerialLCDport = m_bLCDPort;
	strcpy(g_Config.szInSerialPort, m_csPort);
	strcpy(g_Config.szInSerialBaud, m_csBaud);


	CString   key;
	INPUT_BTN *btn;

	// @todo check for memory leak
	g_Config.mapInSerial.RemoveAll();

	for (POSITION pos = m_mapInput.GetStartPosition(); pos != NULL; ){
		m_mapInput.GetNextAssoc( pos, key, (void*&)btn );
		g_Config.mapInSerial.SetAt(key, btn);
	}

	return CDlgInput::OnApply();
}

void CDlgInputSerial::OnAdd() 
{
	CDlgInput::OnAdd();
}

void CDlgInputSerial::OnDelete() 
{
	CDlgInput::OnDelete();
}

void CDlgInputSerial::OnCheckMOKeypad() 
{
	UpdateData(TRUE);

	GetDlgItem(IDC_COMBO_COMPORT)->EnableWindow(!m_bLCDPort);
	GetDlgItem(IDC_COMBO_BAUDRATE)->EnableWindow(!m_bLCDPort);
//	GetDlgItem(IDC_BUTTON_OPEN)->EnableWindow(!m_bLCDPort);
//	GetDlgItem(IDC_BUTTON_CLOSE)->EnableWindow(!m_bLCDPort);

	if (m_bLCDPort && g_LCD->GetSerialDevice() == NULL) {
		AfxMessageBox(IDS_ERR_NO_SERIAL_IN_SUPPORT);
	}
}

void CDlgInputSerial::OnButtonOpen() 
{
	OnApply();

	g_InSerial.InitDevice();	
}

void CDlgInputSerial::OnButtonClose() 
{
	g_InSerial.CloseDevice();	
}

void CDlgInputSerial::OnBtnConfig() 
{
	CDlgCfgSerialInput dlg;

	dlg.DoModal();
}

void CDlgInputSerial::OnBtnEdit() 
{
	CDlgInput::OnEdit();
}

void CDlgInputSerial::OnDblclkList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnEdit();	
	*pResult = 0;
}
