/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2000 Frank Verhamme. All Rights Reserved.
//
//  This file is part of the WinAmp Serial LCD Display Plugin.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
/////////////////////////////////////////////////////////////////////////////
//
// LCDMenuShow.h:   LCD display benutzerdefinierte Menue
//
/////////////////////////////////////////////////////////////////////////////
// Modifications:
// 24.07.2000 - FVerhamme: first release
// 06.08.2000 - FVerhamme: Add some Menu
// 01.04.2001 - FVerhamme: Add scrolling in Playlist, Sorting the Playlist
/////////////////////////////////////////////////////////////////////////////

#include "LCDMenuFunc.h"

/* ----------------------------------------------------------------------------
 * LCDMenuShow.h
 * Diese Datei stellt die Funktionsprototypen f�r die Angezeigeten Menues zur
 * Verf�gung
 * ----------------------------------------------------------------------------
*/

#ifndef _LCDMENUESHOW_H
#define _LCDMENUESHOW_H

// ----------------------------------------------------------------------------
// Hier stehen die Funktionsprototypen f�r die Angezeigeten Menues
// ----------------------------------------------------------------------------
int PlaylistMenuFunc(tCurrMenu* pCurrMenu);
int PlaySelectedPlaylistTitleFunc(tCurrMenu* pCurrMenu);

int WinampMenuFunc  (tCurrMenu* pCurrMenu);
int SystemMenuFunc  (tCurrMenu* pCurrMenu);
int WinampMenuShuffleFunc(tCurrMenu* pCurrMenu);
int WinampMenuRepeatFunc(tCurrMenu* pCurrMenu);
int WinampMenuEquaFunc(tCurrMenu* pCurrMenu);

int WinampMenuSelectPlaylistFunc(tCurrMenu* pCurrMenu);
int WinampMenuSelectAlbumsFunc(tCurrMenu* pCurrMenu);
int WinampMenuSelectArtistsFunc(tCurrMenu* pCurrMenu);
int GetSelectedPlaylistFunc(tCurrMenu* pCurrMenu);
int WinampMenuPlayAll(tCurrMenu* pCurrMenu);
int WinampMenuBrowse(tCurrMenu* pCurrMenu);
int WinampMenuBrowseDir(tCurrMenu* pCurrMenu);
int	WinampMenuEqualizer(tCurrMenu* pCurrMenu);
int PlayAlbum(tCurrMenu* pCurrMenu);
int WinampMenuToogleSpecAnalyserOnOff(tCurrMenu* pCurrMenu);
int WinampMenuToogleLyricsOnOff(tCurrMenu* pCurrMenu);

int WinampMenuStartTitleFunc(tCurrMenu* pCurrMenu);
int WinampMenuStopTitleFunc(tCurrMenu* pCurrMenu);
int WinampMenuPauseTitleFunc(tCurrMenu* pCurrMenu);
int WinampMenuNextTitleFunc(tCurrMenu* pCurrMenu);
int WinampMenuLastTitleFunc(tCurrMenu* pCurrMenu);

int SystemMenuExitFunc(tCurrMenu* pCurrMenu);
int SystemMenuShutdownFunc(tCurrMenu* pCurrMenu);
int SystemShutdownFunc(int pTyp);
//Sleep-Timer
int SystemSleepFunc(tCurrMenu* pCurrMenu);
int SystemSleep(tCurrMenu* pCurrMenu);
void SetSleepTimer(int pSleepTime);
void ResetSleepTimer();
VOID CALLBACK SleepTimer( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );

void PlaySong(HWND hwnd, char* song,bool enq);

int GenerateEqualizerLine(int band, char *dest, int width);

extern tMenuLine aMainMenu[6]; 
// Da wir sp�ter ein sizeof machen, muss hier die Anzahl der Menuepunkte des
// Hauptmenues angegeben werden !

#endif