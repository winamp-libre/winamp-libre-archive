/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Keyboard input driver configuration dialog
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/02/09 MZ  extended input (default/menu/set actions), taken from TiTi's T5 version
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgInputKeyboard.h"
#include "DlgInputAddKeyboard.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInputKeyboard property page

IMPLEMENT_DYNCREATE(CDlgInputKeyboard, CPropertyPage)

CDlgInputKeyboard::CDlgInputKeyboard() : CDlgInput(CDlgInputKeyboard::IDD)
{
	//{{AFX_DATA_INIT(CDlgInputKeyboard)
	m_bEnabled = FALSE;
	//}}AFX_DATA_INIT
}

CDlgInputKeyboard::~CDlgInputKeyboard()
{
}

void CDlgInputKeyboard::DoDataExchange(CDataExchange* pDX)
{
	CDlgInput::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgInputKeyboard)
	DDX_Control(pDX, IDC_LIST_KB, m_cList);
	DDX_Check(pDX, IDC_KB_ENABLED, m_bEnabled);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgInputKeyboard, CDlgInput)
	//{{AFX_MSG_MAP(CDlgInputKeyboard)
	ON_BN_CLICKED(IDC_BTN_KB_ADD, OnAdd)
	ON_BN_CLICKED(IDC_BTN_KB_DEL, OnDelete)
	ON_BN_CLICKED(IDC_BTN_KB_EDIT, OnEdit)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_KB, OnDblclkListKb)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgInputKeyboard message handlers

BOOL CDlgInputKeyboard::OnInitDialog() 
{
	CDlgInput::OnInitDialog();
		
	CString  csBuf;

	m_bEnabled = g_Config.bEnableKeypad;

	ListView_SetExtendedListViewStyle 
		(m_cList.m_hWnd, LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT );

	// add columns
	csBuf.LoadString(IDS_CFG_WL_BUTTON);
	m_cList.InsertColumn(0, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION);
	m_cList.InsertColumn(1, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_MENU);
	m_cList.InsertColumn(2, csBuf);

	csBuf.LoadString(IDS_CFG_WL_ACTION_SET);
	m_cList.InsertColumn(3, csBuf);
	
	UpdateData(FALSE);

	RefreshList();
	m_cList.AutoSizeColumns();		
	return TRUE;
}

void CDlgInputKeyboard::OnAdd() 
{
	CDlgInputAddKeyboard cDlg(this);

	cDlg.m_iKeyCode = 0;

	if(cDlg.DoModal() == IDOK)
	{
		RefreshList();
		m_cList.AutoSizeColumns();
		SetModified();
	}
}

BOOL CDlgInputKeyboard::OnApply() 
{
	g_Config.bEnableKeypad = m_bEnabled;

	return CDlgInput::OnApply();
}

void CDlgInputKeyboard::OnDelete() 
{
	int index = m_cList.GetSelectionMark();

	if (index == -1)
	{
		MessageBox("Select a button first.");
		return;
	}

	int key = m_cList.GetItemData(index);

	KB_KEY* pe;
	if (g_Config.mapKBcfg.Lookup(key, (void *&)pe))
	{
		if (g_Config.mapKBcfg.RemoveKey(key))
		{
			delete pe;

			g_Config.mapKBcfg_menu.RemoveKey(key);
			g_Config.mapKBcfg_set.RemoveKey(key);
			m_cList.DeleteItem(index);
			m_cList.SetSelectionMark(index);
			m_cList.AutoSizeColumns();
			SetModified();
			return;
		}
	}

	MessageBox("Couldn't find that button, doh!");
}

void CDlgInputKeyboard::RefreshList()
{		
	int item;
	POSITION pos;
	WORD key;
	KB_KEY* pe;
	TCHAR	szBuf[30];
	LV_FINDINFO lvf;

 	m_cList.DeleteAllItems();

	for (pos = g_Config.mapKBcfg.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapKBcfg.GetNextAssoc(pos, key, (void *&)pe);
		
		if (GetKeyNameText(pe->lParam, szBuf, 30) == 0)
			continue;

		item = m_cList.InsertItem(0, szBuf);

		if (item < 0)
			continue;

		m_cList.SetItem(item, 1, LVIF_TEXT, acts[pe->action].name,0,0,0,0);
		m_cList.SetItemData(item, key);
	}

	for (pos = g_Config.mapKBcfg_menu.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapKBcfg_menu.GetNextAssoc(pos, key, (void *&)pe);
		
		lvf.flags = LVFI_PARAM;
		lvf.lParam = key;
		if ((item = m_cList.FindItem(&lvf)) == -1)
		{
			// Create New item
			if (GetKeyNameText(pe->lParam, szBuf, 30) == 0)
				continue;
			item = m_cList.InsertItem(0, szBuf);
			if (item < 0)
				continue;
		}

		m_cList.SetItem(item, 2, LVIF_TEXT, acts[pe->action].name,0,0,0,0);
		m_cList.SetItemData(item, key);
	}

	for (pos = g_Config.mapKBcfg_set.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapKBcfg_set.GetNextAssoc(pos, key, (void *&)pe);

		lvf.flags = LVFI_PARAM;
		lvf.lParam = key;
		if ((item = m_cList.FindItem(&lvf)) == -1)
		{
			// Create New item
			if (GetKeyNameText(pe->lParam, szBuf, 30) == 0)
				continue;
			item = m_cList.InsertItem(0, szBuf);
			if (item < 0)
				continue;
		}

		m_cList.SetItem(item, 3, LVIF_TEXT, acts[pe->action].name,0,0,0,0);
		m_cList.SetItemData(item, key);
	}
}

void CDlgInputKeyboard::OnEdit() 
{
	CDlgInputAddKeyboard cDlg(this);

	cDlg.m_iKeyCode = m_cList.GetItemData(m_cList.GetSelectionMark());

	if(cDlg.DoModal() == IDOK)
	{
		RefreshList();
		m_cList.AutoSizeColumns();
		SetModified();
	}
}

void CDlgInputKeyboard::OnDblclkListKb(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnEdit();
	
	*pResult = 0;
}
