/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Timing.h: interface for the CTiming class.
// Initial version by Rick York: http://codeguru.earthweb.com/misc/HighResolutionTimer.shtml
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMING_H__593C932B_7C11_4CE4_9792_4A2C89D97A99__INCLUDED_)
#define AFX_TIMING_H__593C932B_7C11_4CE4_9792_4A2C89D97A99__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

typedef 	enum	{PORT_IO,		// assume that each port input takes 1 us - can be quite inaccurate.
					VHR_TIMING		// use very high resolution timing - not supported by every CPU...
					} DELAY_TYPES;

class CTiming  
{
protected:
	 int		m_bInitialized;
      __int64	Frequency;
	  __int64 BeginTime;

public:
	CTiming();
	virtual ~CTiming();

	void uPause (int usecs);
	__int64 GetFreq();
	BOOL Available();
	BOOL Begin();
	int  End();
};

#endif // !defined(AFX_TIMING_H__593C932B_7C11_4CE4_9792_4A2C89D97A99__INCLUDED_)
