// Developer : Alex Chmut

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "Volume.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DWORD  CVolume::m_dwMasterVolume = 0;
DWORD  CVolume::m_dwWaveVolume = 0;
DWORD  CVolume::m_dwMasterMin = 0;
DWORD  CVolume::m_dwMasterMax = 0;
DWORD  CVolume::m_dwWaveMin = 0;
DWORD  CVolume::m_dwWaveMax = 0;
PBYTE  CVolume::m_pbyVolume = NULL;
BYTE   CVolume::m_bySource = VOLUME_MASTER;
BYTE   CVolume::m_byMaster = 0;
BYTE   CVolume::m_byWave = 0;

CVolume::CVolume()
{
	m_byMasterVol = m_byWaveVol = 0;

	m_pcMasterVolume = (IVolume*)new CVolumeOutMaster();
	if ( !m_pcMasterVolume || !m_pcMasterVolume->IsAvailable() )
	{
 		// handle error
		delete m_pcMasterVolume;
		m_pcMasterVolume = NULL;
	}
	else
	{
		m_dwMasterMin = m_pcMasterVolume->GetMinimalVolume();
		m_dwMasterMax = m_pcMasterVolume->GetMaximalVolume();
		VolumeChanged(m_pcMasterVolume->GetCurrentVolume(), 0);
		m_pcMasterVolume->RegisterNotificationSink( CVolume::VolumeChanged, 0 );	
	}

	m_pcWaveVolume = (IVolume*)new CVolumeOutWave();
	if ( !m_pcWaveVolume || !m_pcWaveVolume->IsAvailable() )
	{
 		// handle error
		delete m_pcWaveVolume;
		m_pcWaveVolume = NULL;
	}
	else
	{
		m_dwWaveMin = m_pcWaveVolume->GetMinimalVolume();
		m_dwWaveMax = m_pcWaveVolume->GetMaximalVolume();
		VolumeChanged(m_pcWaveVolume->GetCurrentVolume(), 1);
		m_pcWaveVolume->RegisterNotificationSink( CVolume::VolumeChanged, 1 );	
	}

}

CVolume::~CVolume()
{
	if (m_pcMasterVolume != NULL)
		delete m_pcMasterVolume;

	if (m_pcWaveVolume != NULL)
		delete m_pcWaveVolume;
}

void CALLBACK CVolume::VolumeChanged( DWORD dwCurrentVolume, DWORD dwUserValue )
{
	DWORD dwMax;

	if (dwUserValue == 0)
	{
		m_dwMasterVolume = dwCurrentVolume;

		dwMax = m_dwMasterMax - m_dwMasterMin;
		if (dwMax == 0)
			dwMax = 1;
		m_byMaster = (BYTE)(m_dwMasterVolume * 100 / dwMax);
	}
	else
	{
		m_dwWaveVolume = dwCurrentVolume;

		dwMax = m_dwWaveMax - m_dwWaveMin;
		if (dwMax == 0)
			dwMax = 1;
		m_byWave = (BYTE)(m_dwWaveVolume * 100 / dwMax);
	}

	// set callback variable
	if (m_pbyVolume != NULL)
	{
		switch (m_bySource)
		{
			case VOLUME_MASTER : *m_pbyVolume = m_byMaster; break;
			case VOLUME_WAVE   : *m_pbyVolume = m_byWave;   break;
			default :  *m_pbyVolume = (m_byMaster * m_byWave) / 100;
		}
	}
}

void CVolume::setType( BYTE type )
{
	m_bySource = type;
}

BYTE CVolume::getVolume()
{
	switch (m_bySource)
	{
		case VOLUME_MASTER : return m_byMaster; break;
		case VOLUME_WAVE   : return m_byWave;   break;
		default :  return (m_byMaster * m_byWave) / 100;
	}
}

void CVolume::SetCallbackVar(PBYTE pbyVolume, BYTE type)
{
	m_pbyVolume = pbyVolume;
	m_bySource = type;

	if (pbyVolume == NULL)
		return;

	if (m_pcMasterVolume != NULL)
		VolumeChanged(m_pcMasterVolume->GetCurrentVolume(), 0);
	if (m_pcWaveVolume != NULL)
		VolumeChanged(m_pcWaveVolume->GetCurrentVolume(), 1);
}
