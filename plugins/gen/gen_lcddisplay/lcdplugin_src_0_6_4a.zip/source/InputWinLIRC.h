#if !defined(AFX_MYSOCK_H__D55A1698_CC1B_11D2_8C7F_004005637418__INCLUDED_)
#define AFX_MYSOCK_H__D55A1698_CC1B_11D2_8C7F_004005637418__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxsock.h>
#include "Input.h"

#define MAXLEN 4096


/////////////////////////////////////////////////////////////////////////////
// CInputWinLIRC command target

class CInputWinLIRC : public CInput, protected CAsyncSocket
{
// Attributes
public:

protected:
	int		curr;
	char	buf[MAXLEN];
	BOOL	m_bConnected;

// Operations
public:
	CInputWinLIRC();
	virtual ~CInputWinLIRC();

// Overrides
public:
	virtual BOOL CloseDevice();
	virtual BOOL IsConnected();
	virtual BOOL ReadConfig(LPCSTR lpIniFile);
	virtual BOOL WriteConfig(LPCSTR lpIniFile);
	virtual BOOL InitDevice();

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInputWinLIRC)
	public:
	virtual void OnConnect(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CInputWinLIRC)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
	virtual void HandleButton(LPCTSTR lpButton, UINT repeat);

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSOCK_H__D55A1698_CC1B_11D2_8C7F_004005637418__INCLUDED_)
