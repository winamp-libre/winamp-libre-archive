/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Keyboard input driver implementation.
//
//////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2002/06/16 MZ 'long key press' detection added
// 2003/01/25 MZ Included TiTi's version T5 changes (http://www.poulpy.com/lcdplugin/)
// 2003/07/06 MZ sscanf bugfixes (debug mode with VS processor pack)
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "InputKeyboard.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

static HHOOK       hHook;

// @HACK !
static CInputKeyboard *pcIn;


extern bool   g_bEqua;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInputKeyboard::CInputKeyboard()
{
	hHook = NULL;
	pcIn = NULL;
	m_iLastKey = 0;
	m_lTimeoutLong = DEF_LONGKEYPRESS_TIME;
	m_bLongProcessed = FALSE;
}

CInputKeyboard::~CInputKeyboard()
{
	CloseDevice();
	ClearMap();
}


BOOL CInputKeyboard::InitDevice()
{
	pcIn = this;
    hHook = SetWindowsHookEx(WH_KEYBOARD, CInputKeyboard::KeyboardHook, 0, GetCurrentThreadId());

	m_bInitialized = (hHook != NULL);

	return m_bInitialized;
}

BOOL CInputKeyboard::CloseDevice()
{
	m_bInitialized = false;

    if (hHook) {
        UnhookWindowsHookEx(hHook);
		hHook = NULL;
	}

	pcIn = NULL;

	return TRUE;
}

BOOL CInputKeyboard::WriteConfig(LPCSTR lpIniFile)
{
    char string[32];
    CString csBuffer;

	wsprintf(string,"%d",g_Config.bEnableKeypad);
    WritePrivateProfileString(SECTION_NAME,"Keyboard_enabled",string,lpIniFile);


	POSITION pos;
	WORD key;
	KB_KEY* pe;   
    CString csTemp;
	int i;
    
	csBuffer = "";
	i = 0;
	// Iterate through the entire map
	for (pos = g_Config.mapKBcfg.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapKBcfg.GetNextAssoc( pos, key, (void *&)pe );

		if (i++ > 0)
			csBuffer+="|";
		csTemp.Format("%i,%i,%i", key, pe->lParam, acts[pe->action].msgNbr);
		csBuffer+=csTemp;
	}
    WritePrivateProfileString(SECTION_NAME, "Keyboard_commands", csBuffer, lpIniFile);

	csBuffer = "";
	i = 0;
	for (pos = g_Config.mapKBcfg_menu.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapKBcfg_menu.GetNextAssoc( pos, key, (void *&)pe );

		if (i++ > 0)
			csBuffer+="|";
		csTemp.Format("%i,%i,%i", key, pe->lParam, acts[pe->action].msgNbr);
		csBuffer+=csTemp;
	}
    WritePrivateProfileString(SECTION_NAME, "Keyboard_commands_menu", csBuffer, lpIniFile);

	csBuffer = "";
	i = 0;
	for (pos = g_Config.mapKBcfg_set.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapKBcfg_set.GetNextAssoc( pos, key, (void *&)pe );

		if (i++ > 0)
			csBuffer+="|";
		csTemp.Format("%i,%i,%i", key, pe->lParam, acts[pe->action].msgNbr);
		csBuffer+=csTemp;
	}
    WritePrivateProfileString(SECTION_NAME, "Keyboard_commands_set", csBuffer, lpIniFile);

	return TRUE;
}

BOOL CInputKeyboard::ReadConfig(LPCSTR lpIniFile)
{
    char    *p;
    char    szBuffer[10000];
	int     iKey;
	UINT    iCmd;
	long	lParam;
	CString csBtnName, csTemp;
    KB_KEY* pe;
	POSITION pos;
   

	ClearMap();

	g_Config.bEnableKeypad = GetPrivateProfileInt(SECTION_NAME,"Keyboard_enabled", 0, lpIniFile);
    
	// Load 'Default' Commands
	GetPrivateProfileString( SECTION_NAME, "Keyboard_commands", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");
    while (p != NULL)
    {
		if (_stscanf(p, "%d,%ld,%u", &iKey, &lParam, &iCmd) != 3)
			break;

		for (int i=0; i < TOTAL_ACTIONS; i++)
		{
			if (acts[i].msgNbr == iCmd)
			{
				pe = new KB_KEY;

				pe->action = i;
				pe->lParam = lParam;

				g_Config.mapKBcfg.SetAt(iKey, pe);

				break;
			}
		}

        p = strtok(NULL, "|");
    }

	// Load 'In-Menu' Commands
	GetPrivateProfileString( SECTION_NAME, "Keyboard_commands_menu", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");
    while (p != NULL)
    {
		if (_stscanf(p, "%d,%ld,%u", &iKey, &lParam, &iCmd) != 3)
			break;

		for (int i=0; i < TOTAL_ACTIONS; i++)
		{
			if (acts[i].msgNbr == iCmd)
			{
				pe = new KB_KEY;

				pe->action = i;
				pe->lParam = lParam;

				g_Config.mapKBcfg_menu.SetAt(iKey, pe);

				break;
			}
		}
        p = strtok(NULL, "|");
    }

	// Load 'In-Set' Commands
	GetPrivateProfileString( SECTION_NAME, "Keyboard_commands_set", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");
    while (p != NULL)
    {
		if (_stscanf(p, "%d,%ld,%u", &iKey, &lParam, &iCmd) != 3)
			break;

		for (int i=0; i < TOTAL_ACTIONS; i++)
		{
			if (acts[i].msgNbr == iCmd)
			{
				pe = new KB_KEY;

				pe->action = i;
				pe->lParam = lParam;

				g_Config.mapKBcfg_set.SetAt(iKey, pe);

				break;
			}
		}
        p = strtok(NULL, "|");
    }


	// Filly empty entries (for backward compatibility)
	for (pos = g_Config.mapKBcfg.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapKBcfg.GetNextAssoc(pos, (WORD &)iKey, (void *&)pe);

		if (!g_Config.mapKBcfg_menu[iKey])
		{
			KB_KEY *newpe = new KB_KEY;

			newpe->action = 0;
			newpe->keyCode = pe->keyCode;
			newpe->lParam = pe->lParam;
			g_Config.mapKBcfg_menu.SetAt(iKey, (void*&)newpe);
		}
		if (!g_Config.mapKBcfg_set[iKey])
		{
			KB_KEY *newpe = new KB_KEY;

			newpe->action = 0;
			newpe->keyCode = pe->keyCode;
			newpe->lParam = pe->lParam;
			g_Config.mapKBcfg_set.SetAt(iKey, (void*&)newpe);
		}
	}



	return TRUE;
}


void CInputKeyboard::ClearMap()
{
   POSITION pos;
   WORD key;
   KB_KEY* pe;

   for (pos = g_Config.mapKBcfg.GetStartPosition(); pos != NULL; )
   {
		g_Config.mapKBcfg.GetNextAssoc( pos, key, (void *&)pe );
		delete pe;
   }
   g_Config.mapKBcfg.RemoveAll();


   for (pos = g_Config.mapKBcfg_menu.GetStartPosition(); pos != NULL; )
   {
		g_Config.mapKBcfg_menu.GetNextAssoc( pos, key, (void *&)pe );
		delete pe;
   }
   g_Config.mapKBcfg_menu.RemoveAll();

   for (pos = g_Config.mapKBcfg_set.GetStartPosition(); pos != NULL; )
   {
		g_Config.mapKBcfg_set.GetNextAssoc( pos, key, (void *&)pe );
		delete pe;
   }
   g_Config.mapKBcfg_set.RemoveAll();
}

LRESULT CALLBACK CInputKeyboard::KeyboardHook(int code, WPARAM wParam, LPARAM lParam)
{
// bit 0 - 15: Specifies the repeat count. The value is the number of times the keystroke is repeated as a result of the user's holding down the key.
	int iRepCount    = lParam & 0x0000FFFF; 
// bit 30: Specifies the previous key state. The value is 1 if the key is down before the message is sent; it is 0 if the key is up.
	int iPrevState   = lParam & 0x40000000; 
// bit 31: Specifies the transition state. The value is 0 if the key is being pressed and 1 if it is being released.
	BOOL bPressed = (lParam & 0x80000000) == 0; 

	KB_KEY* pe;

	if (code == HC_ACTION && pcIn != NULL)
	{
		// is a new key pressed?
		if (pcIn->m_iLastKey != (int)wParam)
		{
			TRACE("New key: %d Last key: %d\n", wParam, pcIn->m_iLastKey);

			// remember 'start key press' time
			pcIn->m_lKeypressTime = GetTickCount();
			pcIn->m_bLongProcessed = FALSE;
			pcIn->m_iLastKey = wParam;
		}

		// for how long?
		long lHoldTime = GetTickCount() - pcIn->m_lKeypressTime;
		if (bPressed)
		{
			// key pressed, if key is being hold down we'll get this event until the key is released

			// a small hack...
			lHoldTime++;

			// handle long key presses
			if (lHoldTime >= pcIn->m_lTimeoutLong)
			{
				TRACE("Long keypress detected: %d\n", wParam);
				if (pcIn->HandleKey(wParam, lHoldTime))
				{
					return 1; // 'eat' the pressed key...  
				}
			}
			// Added by TiTi : eat key if it is bound
			if (g_Config.mapKBcfg.Lookup(wParam, (void *&)pe))
			{
				return 1;
			}
		}
		else
		{
			TRACE("Key released: %d\n", wParam);

			// key released
			pcIn->m_iLastKey = 0;
			
			// handle short key presses
			if (lHoldTime < pcIn->m_lTimeoutLong)
			{
				if (pcIn->HandleKey(wParam, 0))
				{
					return 1; // 'eat' the pressed key...  
				}
			}
		}
	}
	return CallNextHookEx(hHook, code, wParam, lParam);	
}

BOOL CInputKeyboard::HandleKey(int key, long lHoldTime)
{
	KB_KEY* pe;
	int ret;

	if (HandleSongPosInput(key))
	{
		return TRUE;
	}

	if (sCurrMenu.pFirstLine || g_bEqua)
	{
		// We are in a menu
		ret = g_Config.mapKBcfg_menu.Lookup(key, (void *&)pe);
		if (!ret || (ret && pe->action == 0))
		{
			if (!g_Config.mapKBcfg.Lookup(key, (void *&)pe))
			{
				return FALSE;
			}
		}
	}
	else
	{
		// We are in a Set
		ret = g_Config.mapKBcfg_set.Lookup(key, (void *&)pe);
		if (!ret || (ret && pe->action == 0))
		{
			if (!g_Config.mapKBcfg.Lookup(key, (void *&)pe))
			{
				return FALSE;
			}
		}
	}

	BOOL bLongPress = FALSE;

	if (lHoldTime > 0)
	{
		// determine if it's a repeatable key or if it has a 'long key press' action 
		if (!acts[pe->action].repeatable)
		{
			if (pcIn->m_bLongProcessed)
			{
				// ignore, action has already been executed
				TRACE("Ignoring long keypress, already processed...\n");
				return TRUE;
			}
			bLongPress = TRUE;
			pcIn->m_bLongProcessed = TRUE;
		} else {
			bLongPress = TRUE;
		}
	}

	ExecuteAction(acts[pe->action], bLongPress);

	return TRUE;
}
