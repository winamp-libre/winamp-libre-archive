/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LcdMilfordBPK.h: interface for the CLcdMilfordBPK class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MILFORDLCD_H__3F195070_54CC_11D3_B633_0010A4F5373D__INCLUDED_)
#define AFX_MILFORDLCD_H__3F195070_54CC_11D3_B633_0010A4F5373D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Lcd.h"
#include "SerialDevice.h"


#define	DEF_COMPORT			"COM2"
#define DEF_BAUDRATE		"19200"
#define DEF_CONTRAST		140
#define DEF_BRIGHTNESS		0

#define MAX_BAUDRATE_STRLEN 10
#define MAX_COMPORT_STRLEN   7

class CCfgMilford
{
public:
	CCfgMilford();
	~CCfgMilford();
	void Load(LPCSTR lpIniFile);
	void Save(LPCSTR lpIniFile);

public:
	char	szComPort[10];
	char	szBaudRate[7];
	BYTE	byContrast;
	BYTE	byBrightness;
	BOOL	bShowCursor;
	BOOL	bWrap;
	BOOL	bScroll;
	BOOL	bBlink;
	BOOL	bLCD;
	int		iRows;
	int		iCols;
	tULongToULong charMap;
};

extern	CCfgMilford	 g_MilfordCfg; 

class CLcdMilfordBPK : public CLcd  
{
public:
	virtual CDevSerial* GetSerialDevice();
	CLcdMilfordBPK();
	virtual ~CLcdMilfordBPK();

	virtual void  SetBacklight(short nSeconds);
	virtual void  SetBlink(BOOL On);
	virtual void  Clear();
	virtual void  Close();
	virtual BOOL  IsOpen();
	virtual void  SetContrast(short nLevel);
	virtual void  SetBrightness(short nLevel);
	virtual void  Cursor(BOOL bOn);
	virtual void  Home();
	virtual void  SetLineWrap(BOOL bOn);
	virtual BOOL  Open();
	virtual void  SetPosition(short nCol, short nRow);
	virtual void  SetScroll(BOOL bOn);
	virtual void  Write(LPCSTR lpText);
	virtual BOOL  CreateCustomChar(short nNumber, CCustomChar &cChar);
	virtual short GetMaxCustomChar();
	virtual LPCTSTR ConvertTagsToCustomChars(CString &csText);
	virtual LPCTSTR ConvertCustomCharsToTags(CString &csText);
	virtual int		GetRows();		// MZ, June 27
	virtual int		GetColumns();	// MZ, June 27
	virtual LPCSTR  ConvertTextToLCDCharset( CString &csText );	// MZ, August 16 2k

	virtual void  InitHorizontalBar();
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen);
	virtual void  InitVerticalBar();
	virtual void  VBar(short nCol, short nLength);
	virtual void  InitLargeDigit();
	virtual void  LargeDigit(short nCol, short nNumber);

protected:
	void WriteCommand(BYTE byData);
	void WriteData(BYTE byData);

protected:
	BYTE	m_byCmdPrefix;

	CDevSerial	*m_pcDev;
};

#endif // !defined(AFX_MILFORDLCD_H__3F195070_54CC_11D3_B633_0010A4F5373D__INCLUDED_)
