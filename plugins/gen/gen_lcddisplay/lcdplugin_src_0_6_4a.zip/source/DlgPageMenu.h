#if !defined(AFX_DLGPAGEMENU_H__8561ABFC_E7A1_458A_8C4F_D2E14D370E70__INCLUDED_)
#define AFX_DLGPAGEMENU_H__8561ABFC_E7A1_458A_8C4F_D2E14D370E70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TreeCtrlSer.h"
// DlgPageMenu.h : header file
//

#define MENU_ROOT_TEXT "Main LCD Menu"

/////////////////////////////////////////////////////////////////////////////
// CDlgPageMenu dialog

class CDlgPageMenu : public CPropertyPage
{
	DECLARE_DYNCREATE(CDlgPageMenu)

// Construction
public:
	CDlgPageMenu();
	~CDlgPageMenu();

// Dialog Data
	//{{AFX_DATA(CDlgPageMenu)
	enum { IDD = IDD_PAGE_MENU };
	CTreeCtrlSer	m_MenuTree;
	CButton	m_DeleteButton;
	CButton	m_InsertButton;
	CButton	m_InsertChildButton;
	CComboBox	m_ComboFuncs;
	CString	m_MenuCaption;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDlgPageMenu)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDlgPageMenu)
	virtual BOOL OnInitDialog();
	afx_msg void OnInsertItem();
	afx_msg void OnInsertSubItem();
	afx_msg void OnSelchangeComboFuncs();
	afx_msg void OnSelchangedTreemenu(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMenuapply();
	afx_msg void OnButDelete();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPAGEMENU_H__8561ABFC_E7A1_458A_8C4F_D2E14D370E70__INCLUDED_)
