#if !defined(AFX_DLGCFGNORITAKE_H__C07068CC_691A_49D0_8864_8B86DDDA4337__INCLUDED_)
#define AFX_DLGCFGNORITAKE_H__C07068CC_691A_49D0_8864_8B86DDDA4337__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgCfgNoritake.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgNoritake dialog

class CDlgCfgNoritake : public CDialog
{
// Construction
public:
	CDlgCfgNoritake(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgCfgNoritake)
	enum { IDD = IDD_CFG_NORITAKE };
	CSliderCtrl	m_cBrightness;
	CString	m_csHeight;
	CString m_csPort;
	CString	m_csWidth;
	BYTE	m_byCCharEnd;
	BYTE	m_byCCharStart;
	BYTE	m_byCellHeight;
	BYTE	m_byCellWidth;
	CString	m_csFontFile;
	int		m_iDelayInit;
	BOOL	m_bTurbo;
	int		m_iDelayWrite;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCfgNoritake)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgCfgNoritake)
	virtual BOOL OnInitDialog();
	afx_msg void OnDefBtn();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCFGNORITAKE_H__C07068CC_691A_49D0_8864_8B86DDDA4337__INCLUDED_)
