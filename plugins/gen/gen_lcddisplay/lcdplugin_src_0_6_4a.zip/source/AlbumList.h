// AlbumList.h: interface for the CAlbumList class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ALBUMLIST_H__B084D60F_DC5A_4F6D_B0CB_8D4E59FEC86A__INCLUDED_)
#define AFX_ALBUMLIST_H__B084D60F_DC5A_4F6D_B0CB_8D4E59FEC86A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CAlbumList  
{
protected:
	BOOL CopyString(LPSTR dest, LPCSTR source, int iLen);
	HWND	m_hAlbumlist;

public:
	CAlbumList();
	virtual ~CAlbumList();


	BOOL Init();
	BOOL GetAlbumArtist(int index, LPSTR lpBuffer, int iBufLen);
	BOOL GetAlbumTitle(int index, LPSTR lpBuffer, int iBufLen);
	int GetAlbumYear(int index);
	int GetAlbumIndex();
	BOOL GetAlbumName(int index, LPSTR lpBuffer, int iBufLen);
	BOOL PlayRandomAlbum();
	int GetCount();
	BOOL PlayAlbum(int index);
	BOOL EnqueueAlbum(int index);
};

#endif // !defined(AFX_ALBUMLIST_H__B084D60F_DC5A_4F6D_B0CB_8D4E59FEC86A__INCLUDED_)
