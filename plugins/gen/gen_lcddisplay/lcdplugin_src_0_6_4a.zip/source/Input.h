/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Input.h: interface for the CInput class.
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2002/06/16 MZ  Additional menu options, action structure enhanced for long
//                keypress actions
// 2003/01/23 MZ Included TiTi's version T4 changes (http://www.poulpy.com/lcdplugin/)
// 2003/01/25 MZ Included TiTi's version T5 changes (http://www.poulpy.com/lcdplugin/)
// 2003/01/26 MZ ReAdded some old functions that were no longer present in TiTi's version
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUT_H__C69BA809_0F7B_46D8_88D2_8EAC0A31DE3A__INCLUDED_)
#define AFX_INPUT_H__C69BA809_0F7B_46D8_88D2_8EAC0A31DE3A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#undef _WAFE_H_
#include "winamp.h"
#include "LCDMenuFunc.h"
#include "LCDMenuShow.h"

#define SYSTEM_SHUTDOWN   0
#define SYSTEM_REBOOT     1
#define SYSTEM_STANDBY    2
#define SYSTEM_HIBERNATE  3

extern tCurrMenu   sCurrMenu;

enum t_inputtype {IT_DEFAULT, IT_MENU, IT_SET};

const struct action {
	char   *name;		// Action name for drop down list box in cfg dlg
	bool   repeatable;  // 
	int    count;       // Number of times to execute action
	UINT   message;     // 0 for internal function, WM_COMMAND for WinAmp message
	WPARAM msgNbr;      // internal function number or WinAmp msg number for short key presses  (also used to save cfg entries)
	LPARAM fct;         // internal function or 0 if WinAmp message for short key presses
	LPARAM fctLong;     // internal function or 0 if WinAmp message for long key presses
	WPARAM msgLong;     // WinAmp msg number for long key presses
	t_inputtype itype;  // Input Type : menu, set or default
};

typedef BOOL(*ActionFctn)(void);

// timout in ms for direct song number input. The timeout is between key inputs.
#define INPUT_TIMEOUT	4000

class CInput  
{
protected:
	virtual BOOL HandleSongPosInput(int key);
	BOOL	     m_bInitialized;
	static int   m_iJump2Number;
	static DWORD m_dwLastInput;
	static BOOL  m_bBacklight;

	virtual void ExecuteAction(const action &act, BOOL bLongPress);
	const action* GetCommand(LPCTSTR lpButtonName, CStringArray &buttons, CDWordArray &actions);

public:
	static BOOL ClearPlaylist();
	static BOOL ShowBrowser();
	static BOOL Nothing();
	static BOOL MenuLeft();
	static BOOL MenuRight();
	static BOOL SelectAll();
	// methods that each input driver must implement
	virtual BOOL CloseDevice() = 0;
	virtual BOOL ReadConfig(LPCSTR lpIniFile) = 0;
	virtual BOOL WriteConfig(LPCSTR lpIniFile) = 0;
	virtual BOOL InitDevice() = 0;

	CInput();
	virtual ~CInput();
	
	// internal LCD related function calls
	static BOOL ShowAnalyzer();
	static BOOL MenuDown();
	static BOOL MenuUp();
	static BOOL SwitchOutputSet();
	static BOOL SwitchBacklight();
	static BOOL DoReInit();
	static BOOL MenuSelect();
	static BOOL ShowMenu();
	static BOOL Jump2Number();
	static BOOL Jump10Forward();
	static BOOL Previous();
	static BOOL Next();
	static BOOL PlayPause();
	static BOOL PreviousLetter();
	static BOOL NextLetter();
	static BOOL SystemShutdown();
	static BOOL SystemStandby();
	static BOOL SystemReboot();
	static BOOL SystemHibernate();
	static BOOL SystemSleepTimer();
};

/*****************/
/* ACTIONS below */
/*****************/

#define TOTAL_ACTIONS 71
const action acts[TOTAL_ACTIONS] = {
//    NAME                             REPEATABLE,COUNT,MSG,MSGNBR, FUNCTION,       FCT LONG KEY,MSG LONG KEY, INPUT TYPE
	{ "NONE",								false,	1,	0,	1022,	(LPARAM)CInput::Nothing,		0, 0, IT_DEFAULT},
	{ "Show/hide Menu",						false,	1,	0,	1000,	(LPARAM)CInput::ShowMenu,		0, 0, IT_DEFAULT},
	{ "Menu: Select",						false,	1,	0,	1001,	(LPARAM)CInput::MenuSelect,		0, 0, IT_MENU},
	{ "Menu: Up",							true,	1,	0,	1002,	(LPARAM)CInput::MenuUp,			0, 0, IT_MENU},
	{ "Menu: Down",							true,	1,	0,	1003,	(LPARAM)CInput::MenuDown,		0, 0, IT_MENU},
	{ "Menu: -10",							true,	1,	0,	1032,	(LPARAM)CInput::Previous,		0, 0, IT_DEFAULT},
	{ "Menu: +10",							true,	1,	0,	1033,	(LPARAM)CInput::Next,			0, 0, IT_DEFAULT},
	{ "Menu: Next letter",					false,	1,	0,	1017,	(LPARAM)CInput::NextLetter,		0, 0, IT_MENU},
	{ "Menu: Previous letter",				false,	1,	0,	1018,	(LPARAM)CInput::PreviousLetter,	0, 0, IT_MENU},
	{ "Show Browser",						false,	1,	0,	1023,	(LPARAM)CInput::ShowBrowser,	0, 0, IT_DEFAULT},
	{ "Browser: Select",					false,	1,	0,	1030,	(LPARAM)CInput::MenuRight,		0, 0, IT_MENU},
	{ "Browser: Back",						false,	1,	0,	1031,	(LPARAM)CInput::MenuLeft,		0, 0, IT_MENU},
	{ "Browser: (De)Select All",			false,	1,	0,	1019,	(LPARAM)CInput::SelectAll,		0, 0, IT_MENU},
	
	{ "Show/hide spectrum analyzer",		false,	1,	0,	1004,	(LPARAM)CInput::ShowAnalyzer,	0, 0, IT_SET},
	{ "Switch Set",							true,	1,	0,	1005,	(LPARAM)CInput::SwitchOutputSet,0, 0, IT_SET},
	{ "Jump to number: KEY###KEY",			false,	1,	0,	1006,	(LPARAM)CInput::Jump2Number,	0, 0, IT_DEFAULT},

	{ "Backlight On/Off",					false,	1,	0,	1008,	(LPARAM)CInput::SwitchBacklight,0, 0, IT_DEFAULT},
	{ "Re Initialize LCD",					false,	1,	0,	1009,   (LPARAM)CInput::DoReInit,		0, 0, IT_DEFAULT},

	{ "Previous | Rewind",	                true,	1,	WM_COMMAND,	WINAMP_PREV,	0,				0, WINAMP_REW, IT_DEFAULT},
	{ "Next | FF",	                        true,	1,	WM_COMMAND,	WINAMP_NEXT,	0,				0, WINAMP_FF, IT_DEFAULT},
	{ "Play / Pause",	                    false,	1,	0,	1014,	(LPARAM)CInput::PlayPause,		0, WINAMP_STOP, IT_DEFAULT},	// @todo fix long key press 
	
	{ "Winamp: Clear Playlist",				true,	1,	0,	1024,	(LPARAM)CInput::ClearPlaylist , 0, 0, IT_DEFAULT},
	{ "Winamp: Volume Up",					true,	1,	WM_COMMAND,	WINAMP_VOLUMEUP,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Volume Down",				true,	1,	WM_COMMAND,	WINAMP_VOLUMEDOWN,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Play",						false,	1,	WM_COMMAND, WINAMP_PLAY,				0, 0, 0, IT_DEFAULT},
	{ "Winamp: Stop",						false,	1,	WM_COMMAND,	WINAMP_STOP,				0, 0, 0, IT_DEFAULT},
	{ "Winamp: Previous Track",				false,	1,	WM_COMMAND,	WINAMP_PREV,				0, 0, 0, IT_DEFAULT},
	{ "Winamp: Next Track",					false,	1,	WM_COMMAND, WINAMP_NEXT,				0, 0, 0, IT_DEFAULT},
	{ "Winamp: FastForward",				true,	1,	WM_COMMAND, WINAMP_FF,					0, 0, 0, IT_DEFAULT},
	{ "Winamp: FastRewind",    				true,	1,	WM_COMMAND, WINAMP_REW,					0, 0, 0, IT_DEFAULT},
	{ "Winamp: Pause",						false,	1,	WM_COMMAND,	WINAMP_PAUSE,				0, 0, 0, IT_DEFAULT},
																						
	{ "Winamp: Forward 5s",					true,	1,	WM_COMMAND,	WINAMP_FF_5S,				0, 0, 0, IT_DEFAULT},
	{ "Winamp: Rewind 5s",					true,	1,	WM_COMMAND,	WINAMP_REW_5S,				0, 0, 0, IT_DEFAULT},
	{ "Winamp: Fade out and Stop",			false,	1,	WM_COMMAND,	WINAMP_FADEOUTSTOP,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Stop after current Track",	false,	1,	WM_COMMAND,	WINAMP_STOPAFTCURTRK,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Start current Vis-PlugIn",	false,	1,	WM_COMMAND,	WINAMP_STARTVISPLUGIN,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Close Winamp",				false,	1,	WM_COMMAND,	WINAMP_CLOSEWINAMP,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Current track as bookmark",	false,	1,	WM_COMMAND,	WINAMP_ADDCURBOOKMARK,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Play Audio-CD",				false,	1,	WM_COMMAND,	WINAMP_PLAYCD,				0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle Playlist-Editor",		false,	1,	WM_COMMAND,	WINAMP_PLAYLIST_TOGGLE,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Go to Top of Playlist",		false,	1,	WM_COMMAND,	WINAMP_PLAYLISTTOP,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Go to End of Playlist",		false,	1,	WM_COMMAND,	WINAMP_PLAYLISTEND,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Move back 10 tracks",		false,	1,	WM_COMMAND,	WINAMP_PREV10,				0, 0, 0, IT_DEFAULT},
	{ "Winamp: Move forward 10 tracks",		false,	1,	0,  1007,	(LPARAM)CInput::Jump10Forward, 0, 0, IT_DEFAULT},
																						
	{ "Winamp: Open URL Dialog",			false,	1,	WM_COMMAND,	WINAMP_DLG_OPENURL,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Load File Dialog",			false,	1,	WM_COMMAND,	WINAMP_DLG_OPENFILE,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle Preferences Dialog",	false,	1,	WM_COMMAND,	WINAMP_DLG_PREFS_TOGGLE,	0, 0, 0, IT_DEFAULT},
	{ "Winamp: Open File Info Dialog",		false,	1,	WM_COMMAND,	WINAMP_DLG_FILEINFO,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Open Visualization options", false,	1,	WM_COMMAND,	WINAMP_DLG_VISOPTIONS,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Open Vis-PlugIn options",	false,	1,	WM_COMMAND,	WINAMP_DLG_VISPLUGIN,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle About Box",			false,	1,	WM_COMMAND,	WINAMP_DLG_ABOUT_TOGGLE,	0, 0, 0, IT_DEFAULT},
	{ "Winamp: Open 'Jump to time'-Dialog", false,	1,	WM_COMMAND,	WINAMP_DLG_JUMPTOTIME,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Open 'Jump to file'-Dialog", false,	1,	WM_COMMAND,	WINAMP_DLG_JUMPTOFILE,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Open 'Select Skin'-Dialog",	false,	1,	WM_COMMAND,	WINAMP_DLG_SELECTSKIN,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Configure current Vis-PlugIn",false,	1,	WM_COMMAND,	WINAMP_DLG_VISPLUGINCFG,	0, 0, 0, IT_DEFAULT},
	{ "Winamp: Load an Equalizer-Preset",	false,	1,	WM_COMMAND,	WINAMP_DLG_EQLOADPRESET,	0, 0, 0, IT_DEFAULT},
	{ "Winamp: Save Equalizer as",			false,	1,	WM_COMMAND,	WINAMP_DLG_EQSAVEAS,		0, 0, 0, IT_DEFAULT},

	{ "Winamp: Toggle always on top",		false,	1,	WM_COMMAND,	WINAMP_AOT_TOGGLE,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Display: Elapsed Time",		false,	1,	WM_COMMAND,	WINAMP_DISPLAYELAPSED,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Display: Remaining Time",	false,	1,	WM_COMMAND,	WINAMP_DISPLAYREMAIN,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle DoubleSize-Mode",		false,	1,	WM_COMMAND,	WINAMP_DOUBLESIZE_TOGGLE,	0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle Equalizer",			false,	1,	WM_COMMAND,	WINAMP_EQ_TOGGLE,			0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle main window visible", false,	1,	WM_COMMAND,	WINAMP_VISIBLE_TOGGLE,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle Minibrowser",			false,	1,	WM_COMMAND,	WINAMP_BROWSER_TOGGLE,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle Repeat Mode",			false,	1,	WM_COMMAND,	WINAMP_REPEAT_TOGGLE,		0, 0, 0, IT_DEFAULT},
	{ "Winamp: Toggle Shuffle Mode",		false,	1,	WM_COMMAND,	WINAMP_SHUFFLE_TOGGLE,		0, 0, 0, IT_DEFAULT},

	{ "System: Shutdown",					false,	1,	0,	62,	(LPARAM)CInput::SystemShutdown, 0, 0, IT_DEFAULT},
	{ "System: Standby",					false,	1,	0,	63,	(LPARAM)CInput::SystemStandby, 0, 0, IT_DEFAULT},
	{ "System: Reboot",						false,	1,	0,	64,	(LPARAM)CInput::SystemReboot, 0, 0, IT_DEFAULT},
	{ "System: Hibernate",					false,	1,	0,	65,	(LPARAM)CInput::SystemHibernate, 0, 0, IT_DEFAULT},
	{ "System: Sleep Timer",				false,	1,	0,	90,	(LPARAM)CInput::SystemSleepTimer, 0, 0, IT_DEFAULT},

};

/*****************/
/* ACTIONS above */
/*****************/


#endif // !defined(AFX_INPUT_H__C69BA809_0F7B_46D8_88D2_8EAC0A31DE3A__INCLUDED_)
