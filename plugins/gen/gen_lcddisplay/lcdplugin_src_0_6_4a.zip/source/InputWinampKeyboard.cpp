/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Keyboard input driver implementation.
//
//////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/05/15 TA Receive *real* Keyboard Inputs from Winamp main window
// 2003/07/06 MZ sscanf bugfixes (debug mode with VS processor pack)
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "InputWinampKeyboard.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


// @HACK !
static CInputWinampKeyboard *pcIn;
static 	WNDPROC pOrigWndProc;


extern bool   g_bEqua;
extern winampGeneralPurposePlugin g_Plugin;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInputWinampKeyboard::CInputWinampKeyboard()
{
	pcIn = NULL;
	m_iLastKey = 0;
	m_lTimeoutLong = DEF_LONGKEYPRESS_TIME;
	m_bLongProcessed = FALSE;
	pOrigWndProc = NULL;
}

CInputWinampKeyboard::~CInputWinampKeyboard()
{
	CloseDevice();
	ClearMap();
}


BOOL CInputWinampKeyboard::InitDevice()
{
	pcIn = this;
        pOrigWndProc = (WNDPROC)SetWindowLong(g_Plugin.hwndParent, GWL_WNDPROC, (LONG)HookWinampWnd);

	m_bInitialized = (pOrigWndProc != NULL);

	if( !m_bInitialized )
	{
	   DWORD dw = GetLastError();
	   char sz[255];
	   sprintf( sz, "%ld", dw );
        OutputDebugString( sz );
		
	}

	return m_bInitialized;
}

BOOL CInputWinampKeyboard::CloseDevice()
{
	m_bInitialized = false;

	if ( pOrigWndProc) 
	{
		SetWindowLong(g_Plugin.hwndParent, GWL_WNDPROC, (LONG)pOrigWndProc);
		pOrigWndProc = NULL;
	}

	pcIn = NULL;

	return TRUE;
}

BOOL CInputWinampKeyboard::WriteConfig(LPCSTR lpIniFile)
{
    char string[32];
    CString csBuffer;

	wsprintf(string,"%d",g_Config.bEnableWinampKeypad);
    WritePrivateProfileString(SECTION_NAME,"WinampKeyboard_enabled",string,lpIniFile);


	POSITION pos;
	WORD key;
	KB_KEY* pe;   
    CString csTemp;
	int i;
    
	csBuffer = "";
	i = 0;
	// Iterate through the entire map
	for (pos = g_Config.mapWAKBcfg.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapWAKBcfg.GetNextAssoc( pos, key, (void *&)pe );

		if (i++ > 0)
			csBuffer+="|";
		csTemp.Format("%i,%i,%i", key, pe->lParam, acts[pe->action].msgNbr);
		csBuffer+=csTemp;
	}
	WritePrivateProfileString(SECTION_NAME, "WinampKeyboard_commands", csBuffer, lpIniFile);

	csBuffer = "";
	i = 0;
	for (pos = g_Config.mapWAKBcfg_menu.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapWAKBcfg_menu.GetNextAssoc( pos, key, (void *&)pe );

		if (i++ > 0)
			csBuffer+="|";
		csTemp.Format("%i,%i,%i", key, pe->lParam, acts[pe->action].msgNbr);
		csBuffer+=csTemp;
	}
	WritePrivateProfileString(SECTION_NAME, "WinampKeyboard_commands_menu", csBuffer, lpIniFile);

	csBuffer = "";
	i = 0;
	for (pos = g_Config.mapWAKBcfg_set.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapWAKBcfg_set.GetNextAssoc( pos, key, (void *&)pe );

		if (i++ > 0)
			csBuffer+="|";
		csTemp.Format("%i,%i,%i", key, pe->lParam, acts[pe->action].msgNbr);
		csBuffer+=csTemp;
	}
    WritePrivateProfileString(SECTION_NAME, "WinampKeyboard_commands_set", csBuffer, lpIniFile);

	return TRUE;
}

BOOL CInputWinampKeyboard::ReadConfig(LPCSTR lpIniFile)
{
    char    *p;
    char    szBuffer[10000];
	int     iKey;
	UINT    iCmd;
	long	lParam;
	CString csBtnName, csTemp;
    KB_KEY* pe;
	POSITION pos;
   

	ClearMap();

	g_Config.bEnableWinampKeypad = GetPrivateProfileInt(SECTION_NAME,"WinampKeyboard_enabled", 0, lpIniFile);
    
	// Load 'Default' Commands
	GetPrivateProfileString( SECTION_NAME, "WinampKeyboard_commands", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");
    while (p != NULL)
    {
		if (_stscanf(p, "%d,%ld,%u", &iKey, &lParam, &iCmd) != 3)
			break;

		for (int i=0; i < TOTAL_ACTIONS; i++)
		{
			if (acts[i].msgNbr == iCmd)
			{
				pe = new KB_KEY;

				pe->action = i;
				pe->lParam = lParam;

				g_Config.mapWAKBcfg.SetAt(iKey, pe);

				break;
			}
		}

        p = strtok(NULL, "|");
    }

	// Load 'In-Menu' Commands
	GetPrivateProfileString( SECTION_NAME, "WinampKeyboard_commands_menu", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");
    while (p != NULL)
    {
		if (_stscanf(p, "%d,%ld,%u", &iKey, &lParam, &iCmd) != 3)
			break;

		for (int i=0; i < TOTAL_ACTIONS; i++)
		{
			if (acts[i].msgNbr == iCmd)
			{
				pe = new KB_KEY;

				pe->action = i;
				pe->lParam = lParam;

				g_Config.mapWAKBcfg_menu.SetAt(iKey, pe);

				break;
			}
		}
        p = strtok(NULL, "|");
    }

	// Load 'In-Set' Commands
	GetPrivateProfileString( SECTION_NAME, "WinampKeyboard_commands_set", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");
    while (p != NULL)
    {
		if (_stscanf(p, "%d,%ld,%u", &iKey, &lParam, &iCmd) != 3)
			break;

		for (int i=0; i < TOTAL_ACTIONS; i++)
		{
			if (acts[i].msgNbr == iCmd)
			{
				pe = new KB_KEY;

				pe->action = i;
				pe->lParam = lParam;

				g_Config.mapWAKBcfg_set.SetAt(iKey, pe);

				break;
			}
		}
        p = strtok(NULL, "|");
    }


	// Filly empty entries (for backward compatibility)
	for (pos = g_Config.mapWAKBcfg.GetStartPosition(); pos != NULL; )
	{
		g_Config.mapWAKBcfg.GetNextAssoc(pos, (WORD &)iKey, (void *&)pe);

		if (!g_Config.mapWAKBcfg_menu[iKey])
		{
			KB_KEY *newpe = new KB_KEY;

			newpe->action = 0;
			newpe->keyCode = pe->keyCode;
			newpe->lParam = pe->lParam;
			g_Config.mapWAKBcfg_menu.SetAt(iKey, (void*&)newpe);
		}
		if (!g_Config.mapWAKBcfg_set[iKey])
		{
			KB_KEY *newpe = new KB_KEY;

			newpe->action = 0;
			newpe->keyCode = pe->keyCode;
			newpe->lParam = pe->lParam;
			g_Config.mapWAKBcfg_set.SetAt(iKey, (void*&)newpe);
		}
	}



	return TRUE;
}


void CInputWinampKeyboard::ClearMap()
{
   POSITION pos;
   WORD key;
   KB_KEY* pe;

   for (pos = g_Config.mapWAKBcfg.GetStartPosition(); pos != NULL; )
   {
		g_Config.mapWAKBcfg.GetNextAssoc( pos, key, (void *&)pe );
		delete pe;
   }
   g_Config.mapWAKBcfg.RemoveAll();


   for (pos = g_Config.mapWAKBcfg_menu.GetStartPosition(); pos != NULL; )
   {
		g_Config.mapWAKBcfg_menu.GetNextAssoc( pos, key, (void *&)pe );
		delete pe;
   }
   g_Config.mapWAKBcfg_menu.RemoveAll();

   for (pos = g_Config.mapWAKBcfg_set.GetStartPosition(); pos != NULL; )
   {
		g_Config.mapWAKBcfg_set.GetNextAssoc( pos, key, (void *&)pe );
		delete pe;
   }
   g_Config.mapWAKBcfg_set.RemoveAll();
}


LRESULT CALLBACK CInputWinampKeyboard::HookWinampWnd(
								  HWND hwnd,      // handle to window
								  UINT uMsg,      // message identifier
								  WPARAM wParam,  // first message parameter
								  LPARAM lParam   // second message parameter
								)
{
//  Specifies the repeat count. The value is the number of times the keystroke is repeated as a result of the user's holding down the key.
	int iRepCount    = 0; 
//  Specifies the previous key state. The value is 1 if the key is down before the message is sent; it is 0 if the key is up.
	int iPrevState   = 0; 
//  Specifies the transition state. The value is 0 if the key is being pressed and 1 if it is being released.
	

	KB_KEY* pe;
    
	if( pcIn != NULL )
	{
		switch(uMsg) 
		{ 
			case WM_KEYDOWN:
			case WM_KEYUP:
			{
				BOOL bPressed = (uMsg == WM_KEYDOWN);
				
				if ( pcIn != NULL)
				{
					// is a new key pressed?
					if (pcIn->m_iLastKey != (int)wParam)
					{
						TRACE("New key: %d Last key: %d\n", wParam, pcIn->m_iLastKey);
			
						// remember 'start key press' time
						pcIn->m_lKeypressTime = GetTickCount();
						pcIn->m_bLongProcessed = FALSE;
						pcIn->m_iLastKey = wParam;
					}
			
					// for how long?
					long lHoldTime = GetTickCount() - pcIn->m_lKeypressTime;
					if (bPressed)
					{
						// key pressed, if key is being hold down we'll get this event until the key is released
			
						// a small hack...
						lHoldTime++;
			
						// handle long key presses
						if (lHoldTime >= pcIn->m_lTimeoutLong)
						{
							TRACE("Long keypress detected: %d\n", wParam);
							if (pcIn->HandleKey(wParam, lHoldTime))
							{
								return 1; // 'eat' the pressed key...  
							}
						}

						// Added by TiTi : eat key if it is bound
						if (g_Config.mapWAKBcfg.Lookup(wParam, (void *&)pe))
						{
							return 1;
						}
					}
					else
					{
						TRACE("Key released: %d\n", wParam);
			
						// key released
						pcIn->m_iLastKey = 0;
						
						// handle short key presses
						if (lHoldTime < pcIn->m_lTimeoutLong)
						{
							if (pcIn->HandleKey(wParam, 0))
							{
								return 1; // 'eat' the pressed key...  
							}
						}
					}
				}
				break;	
			}	
		}
	}		
	return CallWindowProc(pOrigWndProc, hwnd, uMsg, wParam, lParam); 	
}

BOOL CInputWinampKeyboard::HandleKey(int key, long lHoldTime)
{
	KB_KEY* pe;
	int ret;

	if (HandleSongPosInput(key))
	{
		return TRUE;
	}

	if (sCurrMenu.pFirstLine || g_bEqua)
	{
		// We are in a menu
		ret = g_Config.mapWAKBcfg_menu.Lookup(key, (void *&)pe);
		if (!ret || (ret && pe->action == 0))
		{
			if (!g_Config.mapWAKBcfg.Lookup(key, (void *&)pe))
			{
				return FALSE;
			}
		}
	}
	else
	{
		// We are in a Set
		ret = g_Config.mapWAKBcfg_set.Lookup(key, (void *&)pe);
		if (!ret || (ret && pe->action == 0))
		{
			if (!g_Config.mapWAKBcfg.Lookup(key, (void *&)pe))
			{
				return FALSE;
			}
		}
	}

	BOOL bLongPress = FALSE;

	if (lHoldTime > 0)
	{
		// determine if it's a repeatable key or if it has a 'long key press' action 
		if (!acts[pe->action].repeatable)
		{
			if (pcIn->m_bLongProcessed)
			{
				// ignore, action has already been executed
				TRACE("Ignoring long keypress, already processed...\n");
				return TRUE;
			}
			bLongPress = TRUE;
			pcIn->m_bLongProcessed = TRUE;
		} else {
			bLongPress = TRUE;
		}
	}

	ExecuteAction(acts[pe->action], bLongPress);

	return TRUE;
}
