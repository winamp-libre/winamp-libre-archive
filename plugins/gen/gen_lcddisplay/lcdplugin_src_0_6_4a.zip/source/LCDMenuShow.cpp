/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2000 Frank Verhamme. All Rights Reserved.
//
//  This file is part of the WinAmp Serial LCD Display Plugin.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
/////////////////////////////////////////////////////////////////////////////
//
// LCDMenushow.cpp:   LCD display benutzerdefinierte Menue
//
/////////////////////////////////////////////////////////////////////////////
// Modifications:
//
// 24.07.2000 - FVerhamme: first release
// 06.08.2000 - FVerhamme: Add some Menu
// 12.08.2000 - M.Zehnder: Get display width from LCD driver
// 18.10.2000 - FVerhamme: Changes to the Shuffle function
//            - FVerhamme: Add Repeat function
// 28.01.2001 - M.Zehnder: songname format function improved
// 01.04.2001 - FVerhamme: Add scrolling in Playlist, Sorting the Playlist
// 21.09.2001 - WGauch:    Scrolling improved, Loading of long named Playlists works now.
// 2002/01/04 MZ  Recursive playlist loading and sort option
// 2002/02/12 MZ  System menu added: Winamp exit, system standby/hibernate/shutdown/reboot
//                Enhanced root menu with Albums and Artists
// 2003/01/23 MZ  Included TiTi's version T4 changes (http://www.poulpy.com/lcdplugin/)
// 2003/01/26 MZ  Reason code for ExitWindowsEx - required for Win XP, send stop to Winamp before shutdown/hibernate etc.
// 2003/06/06 MZ  Checking if AlbumList plugin is installed, if not print msg in menu
// 2003/07/10 MZ  bugfix & enhancements in SystemMenuShutdownFunc
// 2003/07/11 MZ  .MP2 & .OGG added in disk browser
// 2003/07/12 MZ  Replaced hard coded custom chars in file browser, works now with every display 
// 2003/07/30 MZ  Integrated sleep timer by Daniel Moos
// 2003/08/03 MZ  SystemShutdownFunc: terminate plugin for standby and hibernation (requires some testing!)
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LCDMenuShow.h"
#include "LCDMenuFunc.h"
#include "gen_lcddisplay.h"
#include "frontend.h"
#include "Albumlist.h"
#include "DynaMenus.h"
#include "Reason.h"

#include <string.h>
#include <windows.h>

#include "tbtremfc.h"

#define PLAYLIST_FILEMASK ".m3u"

// specifies if the playlist is sorted or not - TODO: MAKE THIS CONFIGURABLE!
#define SORT_PLAYLIST 0

tMenuLine*	g_pPlayListMenu;
tMenuLine*	g_pEquaMenu;
int			g_iIdx;

extern bool	g_bEqua;

extern CDynaMenus   g_DynaMenus;

// --------------------------------------------------------------------
// Funktion zum Vergleichen von zwei Strings
// --------------------------------------------------------------------
int compare( const void *arg1, const void *arg2 )
{
  const tMenuLine* pArg1, * pArg2;

  pArg1 = (const tMenuLine *)arg1;
  pArg2 = (const tMenuLine *)arg2;

   /* Compare all of both strings: */
   return _stricmp( pArg1->cTextBuff , pArg2->cTextBuff );
}

int compare2( const void *arg1, const void *arg2 )
{
	const tMenuLine* pArg1, * pArg2;

	pArg1 = (const tMenuLine *)arg1;
	pArg2 = (const tMenuLine *)arg2;

	if (pArg1->cTextBuff[0] < 6 && pArg2->cTextBuff[0] > 6)
		return (1);
	if (pArg1->cTextBuff[0] > 6 && pArg2->cTextBuff[0] < 6)
		return (-1);
	if (pArg1->cTextBuff[0] < 6 && pArg2->cTextBuff[0] < 6)
		return _stricmp( pArg1->cTextBuff + 1, pArg2->cTextBuff + 1);

	return _stricmp(pArg1->cTextBuff , pArg2->cTextBuff);
}


// dynamic Menus thx titi
t_DynaMenu  aAllFuncs[] = 
{
    {-2, "--Root--",            NULL, 0},
	{-1, "--SubMenu--",         NULL, 0},
    { 1, "Playlists...",        WinampMenuSelectPlaylistFunc, 0},
    //{ 2, "Genres...",         WinampMenuSelectGenresFunc, 0},
    { 2, "Artists...",          WinampMenuSelectArtistsFunc, 0},
    { 3, "Albums...",           WinampMenuSelectAlbumsFunc, 0},
    { 4, "Songs...",            PlaylistMenuFunc, 0},

    { 5, "Shuffle On/Off",      WinampMenuShuffleFunc, 0},
    { 6, "Repeat On/Off",       WinampMenuRepeatFunc, 0},
    { 7, "Equalizer On/Off",    WinampMenuEquaFunc, 0},
    { 8, "Play All",            WinampMenuPlayAll, 0},
//    { 9, "Clear Playlist",     WinampMenuEmptyPlaylist, 0},
//    { 9, "Equalizer...",       WinampMenuEqualizer, 0},
    { 10, "Browser...",         WinampMenuBrowse, 0},
    { 11, "Spectrum On/Off",    WinampMenuToogleSpecAnalyserOnOff, 0},
    { 12, "Start Title",        WinampMenuStartTitleFunc, 0},
    { 13, "Stop Title",         WinampMenuStopTitleFunc, 0},
    { 14, "Pause Title",        WinampMenuPauseTitleFunc, 0},
    { 15, "Next Title",         WinampMenuNextTitleFunc, 0},
    { 16, "Prev Title",         WinampMenuLastTitleFunc, 0},

    { 17, "Exit Winamp",        SystemMenuExitFunc, 0},
    { 18, "System Standby",     SystemMenuShutdownFunc, 2},
    { 19, "Hibernate",          SystemMenuShutdownFunc, 3},
    { 20, "Shutdown",           SystemMenuShutdownFunc, 0},
    { 21, "Reboot",             SystemMenuShutdownFunc, 1},
//Sleep-Timer
	{ 22, "Sleep Timer",		SystemSleepFunc, 0},
    { 0, "", 0, 0},
};


/*
// ------ hier definieren wir ein paar statische menues ------------ //

// Definieren eines Menues mit Namen aMainMenu
// Dieses Menue stellt das Hauptmenue dar und hat 3 Zeilen.
// Da dieses Menue nicht nur hier bekannt sein muss (sondern auch im
// Main-C File, darf hier kein static stehen. !!!
// Wenn man Menuepunkte hinzuf�gt oder entfernt, muss die neue Gr��e
// in LCDMenuShow.h angegeben werden !!!!!

tMenuLine aMainMenu[6] =
{
  { IDS_MENU_PLAYLISTS, "", WinampMenuSelectPlaylistFunc, 0, ""}, // aktion aufrufen
  { IDS_MENU_ARTISTS, "",   WinampMenuSelectArtistsFunc, 0, ""}, // aktion aufrufen
  { IDS_MENU_SONGS, "",     PlaylistMenuFunc, 0, "" }, // Playlist Untermenue aufrufen
  { IDS_MENU_ALBUMS, "",    WinampMenuSelectAlbumsFunc, 0, ""}, // aktion aufrufen
  { IDS_PLAYER_FNC, "",     WinampMenuFunc, 0, "" }, // Winamp Untermenue aufrufen
  { IDS_SYSTEM_FNC, "",     SystemMenuFunc, 0, "" }, // call system sub menu
};

// Definieren eines Menues mit Namen aWinampMenu
// Aufbau: ID der RC Datei oder 0, fester text oder "", funktion
static tMenuLine aWinampMenu[] =
{
  { IDS_TOOGLE_SHUFFLE, "", WinampMenuShuffleFunc, 0, "" },
  { IDS_TOOGLE_REPEAT, "",  WinampMenuRepeatFunc, 0, "" },
  { IDS_TOOGLE_REPEAT, "",  WinampMenuEquaFunc, 0, "" },
  { IDS_PLAY_ALL,"",		WinampMenuPlayAll, 0, "" },
  { IDS_EQUALIZER,"",		WinampMenuEqualizer, 0, "" },
  { IDS_BROWSE,"",			WinampMenuBrowse, 0, "" },
  { IDS_SPEC_ANALYSER, "",  WinampMenuToogleSpecAnalyserOnOff, 0, ""},
  { IDS_START_TITLE, "",    WinampMenuStartTitleFunc, 0, ""},
  { IDS_STOP_TITLE, "",     WinampMenuStopTitleFunc, 0, ""},
  { IDS_PAUSE_TITLE, "",    WinampMenuPauseTitleFunc, 0, ""},
  { IDS_NEXT_TITLE, "",     WinampMenuNextTitleFunc, 0, ""},
  { IDS_PREV_TITLE, "",     WinampMenuLastTitleFunc, 0, ""},
};

// System Function sub menu
static tMenuLine aSystemMenu[] =
{
  { IDS_SYSTEM_EXIT, "",      SystemMenuExitFunc, 0, "" }, 
  { IDS_SYSTEM_STANDBY, "",   SystemMenuShutdownFunc, 2, ""}, 
  { IDS_SYSTEM_HIBERNATE, "", SystemMenuShutdownFunc, 3, ""}, 
  { IDS_SYSTEM_SHUTDOWN, "",  SystemMenuShutdownFunc, 0, "" }, 
  { IDS_SYSTEM_REBOOT, "",    SystemMenuShutdownFunc, 1, "" }, 
};
*/

static int SearchAlbums(tMenuLine* &pPlayListMenu);
static int PlayArtist(tCurrMenu* pCurrMenu);
static int SearchArtists(tMenuLine* &pPlayListMenu);


// ----------------------------------------------------------------------------
// Hier stehen die Funktionen der Display-Menuefunktionen
// Diese Funktionen werden von dem jeweiligen Menuepunkt aufgerufen
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Menue Playlist
// ----------------------------------------------------------------------------
int PlaylistMenuFunc(tCurrMenu* pCurrMenu) // Playlist Untermenue
{
  tMenuLine* pPlayListMenu;
  int iPlaylistLength, iIdx = 0, iWidth;
  char cTitle[256];
  char *	pszSongName = NULL;

  // L�nge der Winampplayliste in Tracks
  iPlaylistLength = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETLISTLENGTH);

  // Platz f�r die Playliste besorgen
  pPlayListMenu = (tMenuLine*)calloc(iPlaylistLength, sizeof(tMenuLine));

  iWidth = g_LCD->GetColumns() * 3;  //WG: *3 damit die scrollfkt einen sinn macht....

  //  iWidth = g_LCD->GetColumns() - 1;
  // dynamic menu width MZ, August 12 2k
   
  
  // Sollte die Playliste leer sein, dann eine Meldung anzeigen
  if(!iPlaylistLength)
  {
    pPlayListMenu = (tMenuLine*)calloc(1, sizeof(tMenuLine));

    LoadString(g_Plugin.hDllInstance, IDS_NO_TITLE, cTitle, sizeof(cTitle));
		//cTitle[iWidth - 2] = '~'; //WG:  Damit man wei�, da� der Text noch weiter geht.. ~ ergibt -> auf LCD
		//cTitle[iWidth - 1] = ' '; 
		cTitle[iWidth] = 0;
    strcpy(pPlayListMenu[0].cTextBuff, cTitle);
    pPlayListMenu[0].idText=0;
    pPlayListMenu[0].pActionFunc = PlaySelectedPlaylistTitleFunc;
    pPlayListMenu[0].iUserData = 1;

    Menu_Enter(pCurrMenu, pPlayListMenu, 1, 1);
  }

  // Playliste mit den Werten f�llen
  for(; iIdx < iPlaylistLength; iIdx++)
  {
    // get song name from playlist and copy it to cTitel
  	pszSongName = (char *)SendMessage(g_Plugin.hwndParent,WM_WA_IPC,iIdx,IPC_GETPLAYLISTTITLE);

	// NOTE: the songname should be in the format "%1: %2" (Winamp ID3 v1 title formating)
  	if (pszSongName != NULL)
    {
		LPSTR p = pszSongName + lstrlen(pszSongName);             // Zeiger p ans Ende setzen
		while (p >= pszSongName && *p != ':')           // Position des : suchen
			p--;

		// check if the songname is correctly formatted, MZ Jan 24, 2001
		if ((*p == ':') && (*(p+1) == ' '))
			strncpy(cTitle, p+2, iWidth);                     // iwith Zeichen des Titel kopieren
		else
			strncpy(cTitle, pszSongName, iWidth);
		//cTitle[iWidth - 2] = '~'; //WG:  Damit man wei�, da� der Text noch weiter geht.. 
		//// '~' ergibt kleinen '->' auf LCD (nur auf echtem LCDs [zumindest bei Hitachi..], bei Onscreen Sim. wird ein graues K�stchen angezeigt.
		//cTitle[iWidth - 1] = ' '; 
		cTitle[iWidth] = 0;   // Null terminieren
    }

    // Nun aus Titel und Aktion einen Menueeintrag erzeugen
    strcpy(pPlayListMenu[iIdx].cTextBuff, cTitle);
    pPlayListMenu[iIdx].idText=0;
    pPlayListMenu[iIdx].pActionFunc = PlaySelectedPlaylistTitleFunc;
    pPlayListMenu[iIdx].iUserData = iIdx;
  }

    if (SORT_PLAYLIST)
		qsort( (void *)pPlayListMenu, (size_t)iPlaylistLength, sizeof( tMenuLine ), compare );

    Menu_Enter(pCurrMenu, pPlayListMenu, iPlaylistLength, 1);

  return 1;
}

// ----------------------------------------------------------------------------
// Funktion zur auswahl eines Songs aus der Playlist
// ----------------------------------------------------------------------------
int PlaySelectedPlaylistTitleFunc(tCurrMenu* pCurrMenu) // aktion
{
  int iSelectedEntry;
  int iWidth;
  char cBuffer1[256], cBuffer2[256];
  
  iSelectedEntry = pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].iUserData;

  iWidth = g_LCD->GetColumns() * 3;  //WG: *3 for scroll effect / damit die scrollfkt einen sinn macht...
  //  iWidth = g_LCD->GetColumns() - 1;
  // dynamic menu width MZ, August 12 2k

  LoadString(g_Plugin.hDllInstance, IDS_NO_TITLE, cBuffer1, sizeof(cBuffer1));
  cBuffer1[iWidth] = 0;
  strcpy(cBuffer2, pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].cTextBuff);
  cBuffer2[iWidth] = 0;

  Menu_Leave(pCurrMenu);                     // Menue l�schen
  
  if(compare(cBuffer1, cBuffer2) != 0)
  {
    // Winampplaylist auf die gemerkte Stelle stellen und Track wiedergeben
    SendMessage(g_Plugin.hwndParent,WM_WA_IPC,iSelectedEntry,IPC_SETPLAYLISTPOS);
    SendMessage(g_Plugin.hwndParent,WM_COMMAND,40045,0);		// Den aus der Liste ausgewaehlte Wert
  }

  return 1;
}
/*
void Prepare_WinampMenu()
{
	bool bShuffle, bRepeat, bEqua;

	bShuffle = (SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GET_SHUFFLE) ? TRUE : FALSE);
	bRepeat = (SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GET_REPEAT) ? TRUE : FALSE);
	bEqua = (SendMessage(g_Plugin.hwndParent, WM_USER, (WPARAM)11, (LPARAM)127) ? TRUE : FALSE);

	aWinampMenu[0].idText = 0;
	if (bShuffle)
		strcpy(aWinampMenu[0].cTextBuff, "Shuffle : ON ");
	else
		strcpy(aWinampMenu[0].cTextBuff, "Shuffle : OFF");
	
	aWinampMenu[1].idText = 0;
	if (bRepeat)
		strcpy(aWinampMenu[1].cTextBuff, "Repeat : ON ");
	else
		strcpy(aWinampMenu[1].cTextBuff, "Repeat : OFF");

	aWinampMenu[2].idText = 0;
	if (bEqua)
		strcpy(aWinampMenu[2].cTextBuff, "Equalizer : ON ");
	else
		strcpy(aWinampMenu[2].cTextBuff, "Equalizer : OFF");
}

// ----------------------------------------------------------------------------
// Submenu Winamp
// ----------------------------------------------------------------------------
int WinampMenuFunc(tCurrMenu* pCurrMenu) // Winamp Untermenue
{
  Prepare_WinampMenu();
  Menu_Enter(pCurrMenu, aWinampMenu, sizeof(aWinampMenu) / sizeof(tMenuLine), 0);
  return 1;
}

// ----------------------------------------------------------------------------
// Submenu System Functions
// ----------------------------------------------------------------------------
int SystemMenuFunc(tCurrMenu* pCurrMenu) // Winamp Untermenue
{
  Menu_Enter(pCurrMenu, aSystemMenu, sizeof(aSystemMenu) / sizeof(tMenuLine), 0);
  return 1;
}
*/

int EnterSubMenu(tCurrMenu *pCurrMenu)
{
	t_menuitem	*menu;

	menu = (t_menuitem*)pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].iUserData;
	g_DynaMenus.EnterMenu(pCurrMenu, menu);
	return 1;
}


int WinampMenuEquaFunc(tCurrMenu* pCurrMenu) // aktion
{
	int ret;

	ret = SendMessage(g_Plugin.hwndParent, WM_USER, (WPARAM)11, (LPARAM)127);
	ret = (ret) ? 0 : 1;
	ret = SendMessage(g_Plugin.hwndParent, WM_USER, (WPARAM)ret, (LPARAM)128);
	
//	Prepare_WinampMenu();
	Menu_Update(pCurrMenu);

	return (1);
}

// ----------------------------------------------------------------------------
// Funktion - Toggle Shuffle
// ----------------------------------------------------------------------------
int WinampMenuShuffleFunc(tCurrMenu* pCurrMenu) // aktion
{
	int	toggle;

	// Erstmal den aktuellen Shuffle Status  holen und Togglen
	toggle = (SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GET_SHUFFLE) ? 0 : 1);

	// Winamp informieren
	SendMessage(g_Plugin.hwndParent, WM_WA_IPC, toggle, IPC_SET_SHUFFLE);
	
//	Prepare_WinampMenu();
	Menu_Update(pCurrMenu);

	return 1;
}


// ----------------------------------------------------------------------------

int SearchPlaylists(CString sDirName, tMenuLine* &pPlayListMenu, BOOL bFirst = FALSE, BOOL bRecursive = TRUE) 
{
	static int		iIdx;
	WIN32_FIND_DATA wfd;
	HANDLE			hFind;
	CString			sDirText;


	if (bFirst) {
		iIdx = 0;
	}

	if (sDirName.Right(1) != _T("\\")) {
		sDirName += _T("\\");
	}

	sDirText = sDirName;
	sDirText += _T("*");


	// Iterate through dirs
	hFind = FindFirstFile(sDirText, &wfd);

	if (hFind != INVALID_HANDLE_VALUE)
	{
		do
		{
			if ((wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
				((strcmp(wfd.cFileName,_T(".")) != 0) && (strcmp(wfd.cFileName,_T("..")) != 0)))
			{
				if (bRecursive) 
				{
					CString sTemp;
					sTemp = sDirName;
					sTemp += wfd.cFileName;
					SearchPlaylists(sTemp, pPlayListMenu);
				}
			}
			else
			{
				CString csFile = wfd.cFileName;
				if (csFile.Right(4).CompareNoCase(PLAYLIST_FILEMASK) == 0) 
				{
					iIdx ++;

					// allocate new entry in playlist menu
					pPlayListMenu = (tMenuLine*)realloc( pPlayListMenu, iIdx * sizeof(tMenuLine));

					// remove file type
					CString csTitle = wfd.cFileName; 
					csTitle.Delete(csTitle.GetLength() - 4, 4);

					strcpy(pPlayListMenu[iIdx-1].cTextBuff, csTitle);
					pPlayListMenu[iIdx-1].idText= 0;
					pPlayListMenu[iIdx-1].pActionFunc = GetSelectedPlaylistFunc;
					strcpy(pPlayListMenu[iIdx-1].cTextBuff2, sDirName);
				}

			}
		} while (FindNextFile(hFind, &wfd));

		FindClose(hFind);
	}

	return iIdx;
}

// ----------------------------------------------------------------------------
// Funktion - Select Playlist
// ----------------------------------------------------------------------------
int WinampMenuSelectPlaylistFunc(tCurrMenu* pCurrMenu) // aktion
{
	// Changed by TiTi : Now playlists list is constructed at startup
	//                  see init() function.
	
	Menu_Leave(pCurrMenu);
	Menu_Enter(pCurrMenu, g_pPlayListMenu, g_iIdx, 0);

	return (0);
/*
	int iIdx;
	tMenuLine* pPlayListMenu;


	Menu_Leave(pCurrMenu);

   pPlayListMenu = NULL;

   iIdx = SearchPlaylists(g_Config.szPlaylistPathUser, pPlayListMenu, TRUE, g_Config.bPLrecursive);

   if (iIdx == 0)
   {
     pPlayListMenu = (tMenuLine*)realloc( pPlayListMenu, sizeof(tMenuLine));
     strcpy(pPlayListMenu[0].cTextBuff, "");
     pPlayListMenu[0].idText = IDS_NO_PLAYLIST;
     pPlayListMenu[0].pActionFunc = NULL;
     iIdx++;
   }

   
   if (g_Config.bPLsort) {
		qsort( (void *)pPlayListMenu, (size_t)iIdx, sizeof( tMenuLine ), compare );
   }

	Menu_Enter(pCurrMenu, pPlayListMenu, iIdx, 1);

	return 0;
*/
}

// ----------------------------------------------------------------------------
// Funktion zur auswahl einer Playlist
// ----------------------------------------------------------------------------
int GetSelectedPlaylistFunc(tCurrMenu* pCurrMenu) // aktion
{
	int		iSelectedEntry;
	char	filename[512], cTitle[MAX_PATH];

	int		iWidth;
	char	cBuffer1[256], cBuffer2[256];

	iWidth = g_LCD->GetColumns() * 3;  //WG: *3 damit die scrollfkt einen sinn macht...
	// dynamic menu width MZ, August 12 2k
  
	LoadString(g_Plugin.hDllInstance, IDS_NO_PLAYLIST, cBuffer1, sizeof(cBuffer1));
	cBuffer1[iWidth] = 0;
	strcpy(cBuffer2, pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].cTextBuff);
	cBuffer2[iWidth] = 0;

	iSelectedEntry = pCurrMenu->iLineSelected; // gew�hlte Playlist merken

	if (compare(cBuffer1, cBuffer2) != 0)
	{
		strcpy(cTitle, pCurrMenu->pFirstLine[iSelectedEntry].cTextBuff);
		strcat(cTitle, PLAYLIST_FILEMASK);

		// get playlist directory from menu structure, MZ 2001/12/30
		strcpy(filename, pCurrMenu->pFirstLine[iSelectedEntry].cTextBuff2);
		strcat(filename, cTitle);
   
		PlaySong(g_Plugin.hwndParent, filename, 0);
	}

	Menu_Leave(pCurrMenu);

	return 1;
}

int GetSelectedSongsFunc(tCurrMenu* pCurrMenu)
{
	bool queue = FALSE;

	for (int i = 0; i < pCurrMenu->iLineCnt; ++i)
	{
		if (pCurrMenu->pFirstLine[i].cTextBuff2[0] == (char)0xFD && 
			pCurrMenu->pFirstLine[i].cTextBuff[0] == g_cCBox_Checked)  // MZ 2003/07/12 hard coded custom char replaced
		{
			PlaySong(g_Plugin.hwndParent, pCurrMenu->pFirstLine[i].cTextBuff2 + 1, queue);
			if (queue == FALSE)
				queue = TRUE;
		}
	}
	Menu_Leave(pCurrMenu);
	return (1);
}

int WinampMenuEmptyPlaylist(tCurrMenu* pCurrMenu)
{
	SendMessage(g_Plugin.hwndParent, WM_WA_IPC, 0, IPC_DELETE);
	return (1);
}

int WinampMenuPlayAll(tCurrMenu* pCurrMenu)
{
	char	filename[512], cTitle[MAX_PATH];

	int		ret;
	char	cBuffer1[256], cBuffer2[256];

	LoadString(g_Plugin.hDllInstance, IDS_NO_PLAYLIST, cBuffer1, sizeof(cBuffer1));

	// First clear Winamp internal playlist
	ret = SendMessage(g_Plugin.hwndParent, WM_USER, NULL, 101);

	for (int i = 0; i < g_iIdx; ++i)
	{
		strcpy(cBuffer2, g_pPlayListMenu[i].cTextBuff);

		if (compare(cBuffer1, cBuffer2) != 0)
		{
			strcpy(cTitle, g_pPlayListMenu[i].cTextBuff);
			strcat(cTitle, PLAYLIST_FILEMASK);

			strcpy(filename, g_pPlayListMenu[i].cTextBuff2);
			strcat(filename, cTitle);
   
			PlaySong(g_Plugin.hwndParent, filename, TRUE);
		}
	}
	Menu_Leave(pCurrMenu);

	return 1;
}

// ----------------------------------------------------------------------------
//
// Creates and shows the Albums menu
//
int WinampMenuSelectAlbumsFunc(tCurrMenu* pCurrMenu) 
{
	int iIdx = 0;
	tMenuLine* pPlayListMenu;


	Menu_Leave(pCurrMenu);

    pPlayListMenu = NULL;

	iIdx = SearchAlbums(pPlayListMenu);

	if (iIdx < 1)
	{
		 pPlayListMenu = (tMenuLine*)realloc( pPlayListMenu, sizeof(tMenuLine));
		 strcpy(pPlayListMenu[0].cTextBuff, "");
		 pPlayListMenu[0].idText = (iIdx == -1 ? IDS_NO_ALBUMLIST_PLUGIN : IDS_NO_ALBUMS);
		 pPlayListMenu[0].pActionFunc = NULL;
		 iIdx = 1;
	}

	Menu_Enter(pCurrMenu, pPlayListMenu, iIdx, 1);

	return 1;
}

//
// Builds the Album list
//
int SearchAlbums(tMenuLine* &pPlayListMenu)
{
	int   iCount = 0;

	CAlbumList cAlbum;

	if (!cAlbum.Init())
		return -1;

	iCount = cAlbum.GetCount();


	for (int i=0; i < iCount; i++) {
		// allocate new entry in playlist menu
		pPlayListMenu = (tMenuLine*)realloc( pPlayListMenu, (i+1) * sizeof(tMenuLine));

		pPlayListMenu[i].idText= 0;
		pPlayListMenu[i].iUserData = i;
		pPlayListMenu[i].pActionFunc = PlayAlbum;

		if (!cAlbum.GetAlbumName(i, pPlayListMenu[i].cTextBuff, _MAX_PATH)) {
			strcpy(pPlayListMenu[i].cTextBuff, "[error]");
			break;
		}
	}

	return iCount;
}

//
// Menu callback function to playback the selected album
//
int PlayAlbum(tCurrMenu* pCurrMenu) 
{
	CAlbumList cAlbum;

	cAlbum.Init();
	cAlbum.PlayAlbum(pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].iUserData);

	Menu_Leave(pCurrMenu);

	return 1;
}

// ----------------------------------------------------------------------------

//
// Creates and shows the Artists menu
//
int WinampMenuSelectArtistsFunc(tCurrMenu* pCurrMenu) 
{
	int iIdx = 0;
	tMenuLine* pPlayListMenu;


	Menu_Leave(pCurrMenu);

    pPlayListMenu = NULL;

	iIdx = SearchArtists(pPlayListMenu);

	if (iIdx < 1)
	{
		 pPlayListMenu = (tMenuLine*)realloc( pPlayListMenu, sizeof(tMenuLine));
		 strcpy(pPlayListMenu[0].cTextBuff, "");
		 pPlayListMenu[0].idText = (iIdx == -1 ? IDS_NO_ALBUMLIST_PLUGIN : IDS_NO_ARTISTS);
		 pPlayListMenu[0].pActionFunc = NULL;
		 iIdx = 1;
	}
   
	Menu_Enter(pCurrMenu, pPlayListMenu, iIdx, 1);

	return 1;
}

//
// Builds the Artist list from the AlbumList plugin
//
// @TODO Implement a better version...
//
int SearchArtists(tMenuLine* &pPlayListMenu)
{
	int   iCount = 0;

	char  szName[_MAX_PATH];
	//CMapStringToPtr cMap;
	CtStringToULong cMap;

	CAlbumList cAlbum;

	if (!cAlbum.Init())
		return -1;

	iCount = cAlbum.GetCount();

	// abuse a map to get rid of dups
	for (int i=0; i < iCount; i++) {
		if(cAlbum.GetAlbumArtist(i, szName, _MAX_PATH)) {
			CString csTmp(szName);
			csTmp.TrimRight();
			csTmp.TrimLeft();
			if (csTmp.GetLength() > 0) {
				// map the artist name to the album list index
				cMap.Set(csTmp, (ULONG) i);
			}
		}
	}

// @TODO sort artist list

   POSITION pos;
   CString key;
   ULONG ulIndex;
   
   i = 0;
   
   for( pos = cMap.First(); pos != NULL; )
   {
		ulIndex = cMap.GetData( pos );
		key = cMap.GetKey( pos );

		// allocate new entry in playlist menu
		pPlayListMenu = (tMenuLine*)realloc( pPlayListMenu, (i+1) * sizeof(tMenuLine));

		pPlayListMenu[i].idText= 0;
		pPlayListMenu[i].iUserData = (int)ulIndex;		// index in AlbumList
		pPlayListMenu[i].pActionFunc = PlayArtist;

		strcpy(pPlayListMenu[i].cTextBuff, key);

		pos = cMap.Next( pos );

		i++;
	}

	return i;
}

//
// Menu callback function to playback the selected artist
//
int PlayArtist(tCurrMenu* pCurrMenu) 
{
	CAlbumList cAlbum;

	cAlbum.Init();

	BOOL bFirst = TRUE;
	// Search for all Albums of this Artist, play the first, enqueue the rest

	int iCount = cAlbum.GetCount();
	char  szName[_MAX_PATH];

    
	for (int i=0; i < iCount; i++) 
	{
		if(cAlbum.GetAlbumArtist(i, szName, _MAX_PATH)) 
		{
			CString csTmp(szName);
			csTmp.TrimRight();
			csTmp.TrimLeft();
	     	if ( csTmp == pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].cTextBuff ) 
			{
				if( bFirst )
				{
		    		cAlbum.PlayAlbum(i);
				}
				else
				{
					cAlbum.EnqueueAlbum(i);
				}
				bFirst = false;
			}
		}
	}
	
	Menu_Leave(pCurrMenu);

	return 1;
}


// ----------------------------------------------------------------------------


// ----------------------------------------------------------------------------
// Funktion zum Starten des Spectrum Analyser
// ----------------------------------------------------------------------------
int WinampMenuToogleSpecAnalyserOnOff(tCurrMenu* pCurrMenu) //aktion
{
	Menu_Leave(pCurrMenu);
	g_Spectrum_Analyser.active = (g_Spectrum_Analyser.active ? 0 : 1);
	if(g_Spectrum_Analyser.active == 0)     // Wenn der Apectrum Analyser ausgeschaltet wird,
		g_Spectrum_Analyser.char_loaded = 0;  // muessen die Characters auch ausgeschaltet werden.
	return 1;
}

// ----------------------------------------------------------------------------
// Funktion zum Starten des Songs
// ----------------------------------------------------------------------------
void PlaySong(HWND hwnd, char* song,bool enq)    //enq = play / enqueue flag //
{
	//this works with single songs as well as with playlists //
	char	TmpSongname[512]; //need for short filenames //

	if (strlen(song) == 0)
	  return;

    GetShortPathName(song, TmpSongname, sizeof(TmpSongname));

	if (hwnd)
	{
		COPYDATASTRUCT cds;

		if (!enq)
			SendMessage(hwnd, WM_WA_IPC, 0 , IPC_DELETE); //Delete current Playlist

		// Fill COPYDATA structure 
		cds.dwData = 100;
		cds.cbData = strlen(TmpSongname) + 1;
		cds.lpData = TmpSongname;
    
		//SendMessage(hwnd,WM_COPYDATA,0,(long)&cds);
		SendMessage(hwnd, WM_COPYDATA, (WPARAM)NULL, (LPARAM)&cds);

		if (!enq)
			SendMessage(hwnd,WM_WA_IPC,0,IPC_STARTPLAY);
	}
}

// ----------------------------------------------------------------------------
// Funktion zur auswahl einer Playlist
// ----------------------------------------------------------------------------
int WinampMenuStartTitleFunc(tCurrMenu* pCurrMenu)
{
	Menu_Leave(pCurrMenu);
	SendMessage(g_Plugin.hwndParent, WM_COMMAND, 40045, 0);
	return 1;
}

int WinampMenuStopTitleFunc(tCurrMenu* pCurrMenu)
{
	Menu_Leave(pCurrMenu);
	SendMessage(g_Plugin.hwndParent, WM_COMMAND, 40047, 0);
	return 1;
}

int WinampMenuPauseTitleFunc(tCurrMenu* pCurrMenu)
{
	Menu_Leave(pCurrMenu);
	SendMessage(g_Plugin.hwndParent, WM_COMMAND, 40046, 0);
	return 1;
}

int WinampMenuNextTitleFunc(tCurrMenu* pCurrMenu)
{
	Menu_Leave(pCurrMenu);
	SendMessage(g_Plugin.hwndParent, WM_COMMAND, 40048, 0);
	return 1;
}

int WinampMenuLastTitleFunc(tCurrMenu* pCurrMenu)
{
	Menu_Leave(pCurrMenu);
	SendMessage(g_Plugin.hwndParent, WM_COMMAND, 40044, 0);
	return 1;
}


// ----------------------------------------------------------------------------
// System Menu functions
// ----------------------------------------------------------------------------

int SystemMenuExitFunc(tCurrMenu* pCurrMenu)
{
	Menu_Leave(pCurrMenu);
	SendMessage(g_Plugin.hwndParent,WM_COMMAND,WINAMP_CLOSEWINAMP,0);
	return 1;
}

int SystemMenuShutdownFunc(tCurrMenu* pCurrMenu)
{
	int iRet = SystemShutdownFunc(pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].iUserData);
	Menu_Leave(pCurrMenu);

	return iRet;
}

extern void quit();
extern int init();
int SystemShutdownFunc(int pTyp)
{
	BOOL	bRet = TRUE;
	HANDLE	hToken;              // handle to process token 
	TOKEN_PRIVILEGES tkp;        // pointer to token structure 


	// @test stop WinAmp, might fix some hibernation problems, MZ 2003/01/26
	SendMessage(g_Plugin.hwndParent, WM_COMMAND, 40047, 0);

	g_LCD->Clear();
	g_LCD->Home();

	// Get the current process token handle so we can get shutdown 
	// privilege. --> only necessary for Windows NT!
	OSVERSIONINFO versionInfo;
	versionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	::GetVersionEx(&versionInfo);
	BOOL bWinNT = (versionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT);

	if (bWinNT) {
		if (!OpenProcessToken(GetCurrentProcess(), 
				TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) 
			TRACE("OpenProcessToken failed."); 
 
		// Get the LUID for shutdown privilege. 
		LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, 
				&tkp.Privileges[0].Luid); 
 
		tkp.PrivilegeCount = 1;  // one privilege to set    
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
 
		// Get shutdown privilege for this process. 
		AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
			(PTOKEN_PRIVILEGES) NULL, 0); 
 
		// Cannot test the return value of AdjustTokenPrivileges. 
		if (GetLastError() != ERROR_SUCCESS) 
			TRACE("AdjustTokenPrivileges enable failed."); 
	}	

	// MZ 2003/01/26 according to MSDN WinXP expects a reason for shutting down, otherwise the shutdown might be delayed..
	//               http://msdn.microsoft.com/library/default.asp?url=/library/en-us/sysinfo/base/exitwindowsex.asp
	DWORD dwReason = SHTDN_REASON_MAJOR_OTHER | SHTDN_REASON_MINOR_OTHER | SHTDN_REASON_FLAG_PLANNED;

	switch (pTyp) {
	case SYSTEM_REBOOT :
		g_LCD->Write(g_Config.szLCDMsgReboot);
		// @HACK MZ 2002/06/09 WinLirc client must be shut down before server otherwise user gets an error msg and shutdown process is interrupted :(
		g_InWinLIRC.CloseDevice();
		bRet = ExitWindowsEx(EWX_REBOOT, dwReason);
		break;
	case SYSTEM_STANDBY :
		g_LCD->Write(g_Config.szLCDMsgStandby);

		quit();
		// bugfix MZ 2003/07/10 first parameter switched in case 2 & 3
		bRet = SetSystemPowerState(TRUE, g_Config.bShutdownForce);
		break;
	case SYSTEM_HIBERNATE :
		g_LCD->Write(g_Config.szLCDMsgHibernate);
		quit();
		// @todo add option to close and reinitialize lcd driver
		bRet = SetSystemPowerState(FALSE, g_Config.bShutdownForce);
		break;
	default:
		g_LCD->Write(g_Config.szLCDMsgShutdown);
		// @HACK MZ 2002/06/09 WinLirc client must be shut down before server otherwise user gets an error msg and shutdown process is interrupted :(
		g_InWinLIRC.CloseDevice();
		// MZ 2003/08/03 changed EWX_SHUTDOWN to EWX_POWEROFF
		bRet = ExitWindowsEx(EWX_POWEROFF, dwReason);
		break;
	}

	if (!bRet) {
		char szBuf[300];
		GetLastErrorMsg(szBuf, 300);
		TRACE(szBuf);
	}

	// we only end up here after hibernation or standby wakeup!
	// first we need to disable shutdown privilege...
	if (bWinNT) {
		tkp.Privileges[0].Attributes = 0; 
		AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, 
				(PTOKEN_PRIVILEGES) NULL, 0); 
 
		if (GetLastError() != ERROR_SUCCESS) {
			TRACE("AdjustTokenPrivileges disable failed."); 
		} 
	}

	// ...then to re-initialize everything else!
	// @todo add option to close & reinitialize lcd driver
	if (pTyp == SYSTEM_STANDBY || pTyp == SYSTEM_HIBERNATE) {
		init();
	}

	return 1;
}

// Sleep-Timer
int SystemSleepFunc(tCurrMenu* pCurrMenu)	// Untermenu Sleep-Timer
{
	tMenuLine* pSleepTimerMenu;

	if(!g_bSleepActive)	// Sleep-Timer inaktiv!
	{
		// Platz besorgen
		pSleepTimerMenu = (tMenuLine*)calloc(6, sizeof(tMenuLine));

		// Menu erstellen
		pSleepTimerMenu[0].idText = IDS_SLEEP_MENU_1;
		pSleepTimerMenu[0].pActionFunc = SystemSleep;
		pSleepTimerMenu[0].iUserData = 15;

		pSleepTimerMenu[1].idText = IDS_SLEEP_MENU_2;
		pSleepTimerMenu[1].pActionFunc = SystemSleep;
		pSleepTimerMenu[1].iUserData = 30;

		pSleepTimerMenu[2].idText = IDS_SLEEP_MENU_3;
		pSleepTimerMenu[2].pActionFunc = SystemSleep;
		pSleepTimerMenu[2].iUserData = 45;

		pSleepTimerMenu[3].idText = IDS_SLEEP_MENU_4;
		pSleepTimerMenu[3].pActionFunc = SystemSleep;
		pSleepTimerMenu[3].iUserData = 60;

		pSleepTimerMenu[4].idText = IDS_SLEEP_MENU_5;
		pSleepTimerMenu[4].pActionFunc = SystemSleep;
		pSleepTimerMenu[4].iUserData = 75;

		pSleepTimerMenu[5].idText = IDS_SLEEP_MENU_6;
		pSleepTimerMenu[5].pActionFunc = SystemSleep;
		pSleepTimerMenu[5].iUserData = 90;

		Menu_Enter(pCurrMenu, pSleepTimerMenu, 6, 1);
	}
	else	// Sleep-Timer aktiv!
	{
		// Platz besorgen
		pSleepTimerMenu = (tMenuLine*)calloc(1, sizeof(tMenuLine));

		// Menu erstellen
		pSleepTimerMenu[0].idText = IDS_SLEEP_MENU_CANCEL;
		pSleepTimerMenu[0].pActionFunc = SystemSleep;
		pSleepTimerMenu[0].iUserData = 0;

		Menu_Enter(pCurrMenu, pSleepTimerMenu, 1, 1);
	}

	return 1;
}

int SystemSleep(tCurrMenu* pCurrMenu)
{
	int iTyp;

	iTyp = pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].iUserData;
	if(iTyp > 0)
	{
		SetSleepTimer(iTyp);
	}
	else
	{
		ResetSleepTimer();
	}

	Menu_Leave(pCurrMenu);
	return 1;
}

void SetSleepTimer(int pSleepTime)
{
	g_bSleepActive = true;
	g_iSleepTime = pSleepTime * 60;	//pSleepTime(Minuten) * 60 = Total in Sekunden
	g_uiSleepTimer = SetTimer(NULL, NULL, 1000, (TIMERPROC)SleepTimer);
}

void ResetSleepTimer()
{
	KillTimer(NULL, g_uiSleepTimer);
	g_bSleepActive = false;
	g_iSleepTime = 0;
}

VOID CALLBACK SleepTimer( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
	g_iSleepTime--;
	if(g_iSleepTime <= 0)
	{
		//Sleep abgelaufen
		ResetSleepTimer();
		SystemShutdownFunc(g_Config.bySleepFunction);
	}
}

// ----------------------------------------------------------------------------
// Funktion - Toggle Repeat
// ----------------------------------------------------------------------------
int WinampMenuRepeatFunc(tCurrMenu* pCurrMenu)
{
	int	toggle;

	// Erstmal den aktuellen Shuffle Status  holen und Togglen
	toggle = (SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GET_REPEAT) ? 0 : 1);

	// Winamp informieren
	SendMessage(g_Plugin.hwndParent, WM_WA_IPC, toggle, IPC_SET_REPEAT);

//	Prepare_WinampMenu();
	Menu_Update(pCurrMenu);

	return 1;
}

int WinampMenuEqualizer(tCurrMenu* pCurrMenu)
{
	g_bEqua = TRUE;
	
	Menu_Leave(pCurrMenu);
	
	g_LCD->Clear();

	return (1);
}

int WinampMenuBrowse(tCurrMenu* pCurrMenu)
{
	char c;
	char path[4];
	int	 ret, nb;
	char *mytype;
	tMenuLine *mline = NULL;

	nb = 0;
	for (c = 'A'; c <= 'Z'; ++c)
	{
		sprintf(path, "%c:\\", c);
		ret = GetDriveType(path);
		switch (ret)
		{
		case DRIVE_REMOVABLE:
			mytype = "Removeable";
			break;
		case DRIVE_REMOTE:
			mytype = "Network";
			break;
		case DRIVE_FIXED:
			mytype = "Fixed";
			break;
		case DRIVE_CDROM:
			mytype = "CDROM";
			break;
		case DRIVE_RAMDISK:
			mytype = "RamDisk";
			break;
		case DRIVE_UNKNOWN:
		case DRIVE_NO_ROOT_DIR:
		default:
			mytype = NULL;
			break;
		}

		if (mytype)
		{
			mline = (tMenuLine*)realloc(mline, ++nb * sizeof (tMenuLine));
			sprintf(mline[nb - 1].cTextBuff, "%s  (%s)", path, mytype);
			mline[nb - 1].idText = 0;
			mline[nb - 1].iUserData = 0;
			mline[nb - 1].pActionFunc = WinampMenuBrowseDir;
			mline[nb - 1].cTextBuff2[0] = (char)0xFE;
			strcpy(mline[nb - 1].cTextBuff2 + 1, path);
		}
	}

	Menu_Enter(pCurrMenu, mline, nb, TRUE);

	return (1);
}


int WinampMenuBrowseDir(tCurrMenu* pCurrMenu)
{
	WIN32_FIND_DATA wfd;
	HANDLE			hFind;
	CString			sDirText, sDirName;
	tMenuLine		*mline = NULL;
	int				nb = 0;

	sDirName = _T(pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].cTextBuff2 + 1);
	sDirText = sDirName;
	sDirText += _T("*");

	// Iterate through dirs
	hFind = FindFirstFile(sDirText, &wfd);
	if (hFind != INVALID_HANDLE_VALUE)
	{
		do
		{
			if ((wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
				((strcmp(wfd.cFileName,_T(".")) != 0) != 0) &&
				((strcmp(wfd.cFileName,_T("..")) != 0) != 0))
			{
				mline = (tMenuLine*)realloc(mline, ++nb * sizeof (tMenuLine));
				mline[nb - 1].idText = 0;
				mline[nb - 1].iUserData = 0;
				sprintf(mline[nb - 1].cTextBuff, "%s\\", wfd.cFileName);
				mline[nb - 1].cTextBuff2[0] = (char)0xFE;
				sprintf(mline[nb - 1].cTextBuff2 + 1, "%s%s\\", sDirName, wfd.cFileName);
				mline[nb - 1].pActionFunc = WinampMenuBrowseDir;
				//mline[nb - 1].pActionFunc = GetSelectedSongsFunc;
			}
			else
			{
				CString csFile = wfd.cFileName;
				
				if (csFile.Right(4).CompareNoCase(".MP3") == 0 ||
					csFile.Right(4).CompareNoCase(".M3U") == 0 ||
					csFile.Right(4).CompareNoCase(".MP2") == 0 ||
					csFile.Right(4).CompareNoCase(".OGG") == 0 ||
					csFile.Right(4).CompareNoCase(".WAV") == 0)
				{
					mline = (tMenuLine*)realloc(mline, ++nb * sizeof (tMenuLine));
					mline[nb - 1].idText = 0;
					mline[nb - 1].iUserData = 0;

					// MZ 2003/07/12 hard coded custom char replaced
					sprintf(mline[nb - 1].cTextBuff, "%c%s", g_cCBox_Unchecked, wfd.cFileName);
				
					mline[nb - 1].cTextBuff2[0] = (char)0xFD;
					sprintf(mline[nb - 1].cTextBuff2 + 1, "%s%s", sDirName, wfd.cFileName);
					mline[nb - 1].pActionFunc = GetSelectedSongsFunc;
				}
			}
		} while (FindNextFile(hFind, &wfd));

		FindClose(hFind);
	}

	if (nb == 0)
	{
		mline = (tMenuLine*)realloc(mline, ++nb * sizeof (tMenuLine));
		mline[0].idText = 0;
		mline[0].iUserData = 0;
		mline[0].pActionFunc = NULL;
		mline[0].cTextBuff2[0] = (char)0xFE;
		strcpy(mline[0].cTextBuff, "No files in folder.");
		sprintf(mline[0].cTextBuff2 + 1, "%s%s", sDirName, "NOFILE");
	}

	qsort((void*)mline, (size_t)nb, sizeof (tMenuLine), compare2);
	Menu_Enter(pCurrMenu, mline, nb, 1);

	return (1);
}