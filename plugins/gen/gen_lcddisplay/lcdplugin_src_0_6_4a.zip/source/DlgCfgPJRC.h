#if !defined(AFX_DLGCFGPJRC_H__B8E7E44A_6519_4351_A43E_09E0CCEA8980__INCLUDED_)
#define AFX_DLGCFGPJRC_H__B8E7E44A_6519_4351_A43E_09E0CCEA8980__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgCfgPJRC.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgPJRC dialog

class CDlgCfgPJRC : public CDialog
{
// Construction
public:
	CDlgCfgPJRC(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlgCfgPJRC)
	enum { IDD = IDD_CFG_PJRC };
	CString	m_csPort;
	int		m_iFont;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgCfgPJRC)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgCfgPJRC)
	afx_msg void OnDefBtn();
	afx_msg void OnBtnFont1();
	afx_msg void OnBtnFont2();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCFGPJRC_H__B8E7E44A_6519_4351_A43E_09E0CCEA8980__INCLUDED_)
