/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
// 
// WinLIRC input driver implementation.
// Most bits of this code has been taken from the WinLIRC WinAmp plugin by Jim Paris
//
// ATTENTION: THIS CODE IS MORE OR LESS UNTESTED !!!
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/02/09 MZ  extended input (default/menu/set actions)
// 2003/06/03 MZ  tested with 1st real device -> fixed key repeat issue :-)
// 
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "InputWinLIRC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInputWinLIRC

CInputWinLIRC::CInputWinLIRC()
{	
	curr=0;
	m_bInitialized = FALSE;
	m_bConnected = FALSE;
}

CInputWinLIRC::~CInputWinLIRC()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CInputWinLIRC, CAsyncSocket)
	//{{AFX_MSG_MAP(CInputWinLIRC)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CInputWinLIRC member functions

void CInputWinLIRC::OnConnect(int nErrorCode) 
{
	CAsyncSocket::OnConnect(nErrorCode);
	
	if(nErrorCode!=0) {
		m_bInitialized=false;
		//MessageBox(NULL,"Failed to connect to WinLIRC server.","WinLIRC",MB_OK);
		Close();
	} else {
		m_bConnected=true;
	}
}

void CInputWinLIRC::OnReceive(int nErrorCode) 
{
	CAsyncSocket::OnReceive(nErrorCode);

	if(nErrorCode!=0) {
		m_bInitialized=m_bConnected=false;
		MessageBox(NULL,"Network connection failed.","WinLIRC",MB_OK);
		Close();
	} else {	
		if(curr>=MAXLEN) // too much data, lose it
			curr=0;
		int res;
		res=Receive(buf,MAXLEN-curr);
		if(res==SOCKET_ERROR || res==0) return;
		curr+=res;

		// find a newline
		for(int i=0;i<curr;i++) {
			if(buf[i]=='\n') {
				break;
			}
		}

		if(i==curr) // no newline
			return;
		int loc=i;
		// found a newline: copy that much of buf into tmp
		char tmp[MAXLEN+1];
		for(i=0;i<=loc;i++)
			tmp[i]=buf[i];
		// null terminate it
		tmp[i]=0;
		// move buf back
		for(i=loc;i<curr;i++)
			buf[i-loc]=buf[i];

		unsigned __int64 keycode;
		unsigned int repeat;
		char keyname[MAXLEN];
		char remotename[MAXLEN];
		if(sscanf(tmp,"%I64x %x %s %[^\n]",&keycode,&repeat,keyname,remotename)!=4)
			return;

		// send it to the app
		HandleButton(keyname, repeat);
	}
}

void CInputWinLIRC::OnClose(int nErrorCode) 
{
	CAsyncSocket::OnClose(nErrorCode);

	if (m_bInitialized && nErrorCode != 0)
		MessageBox(NULL,"Connection to WinLIRC server lost.","LCD plugin - WinLIRC",MB_OK);

	m_bConnected = m_bInitialized = false;
}

void CInputWinLIRC::HandleButton(LPCTSTR lpButtonName, UINT repeat)
{
	static ULONG lastKeypress;


	TRACE2("WinLIRC: %s %d\n", lpButtonName, repeat);

	if (repeat > 0 && repeat < g_Config.byWLRepeat) {
		if (GetTickCount() - lastKeypress < (ULONG)g_Config.iWLRepDelay)
			return;
	}

	lastKeypress = GetTickCount();

	if (strlen(lpButtonName) == 1) {
		if (HandleSongPosInput(lpButtonName[0])) {
			return;
		}
	}

	INPUT_BTN* btn;

	if (!g_Config.mapInWinLirc.Lookup(lpButtonName, (void *&)btn)) {
		return;
	}

	int iAction = btn->defAction;

	if (sCurrMenu.pFirstLine /*|| g_bEqua*/) {
		// We are in a menu
		if (btn->menuAction != 0) {
			iAction = btn->menuAction;
		}
	} else {
		// We are in a Set
		if (btn->setAction != 0) {
			iAction = btn->setAction;
		}
	}

	ExecuteAction(acts[iAction], repeat > 0);
}

BOOL CInputWinLIRC::InitDevice()
{
	m_bConnected = false;
	m_bInitialized = false;
	
	
	if (Create() == 0) {
		MessageBox(NULL,"Error creating client socket.","WinLIRC",MB_OK);
		return FALSE;
	}

	m_bInitialized=true;

	if (Connect(g_Config.szWLServer, g_Config.iWLPort) == 0) {
		if (GetLastError() != WSAEWOULDBLOCK) {
			m_bInitialized = false;
			Close();

			//MessageBox(NULL,"Error connecting to server.","WinLIRC",MB_OK);
			return FALSE;
		}
	}

	return TRUE;
}

BOOL CInputWinLIRC::WriteConfig(LPCSTR lpIniFile)
{
    char string[32];
    CString csBuffer;

	wsprintf(string,"%d",g_Config.bWLEnabled);
    WritePrivateProfileString(SECTION_NAME_WINLIRC,"enabled",string,lpIniFile);
	WritePrivateProfileString(SECTION_NAME_WINLIRC,"server",g_Config.szWLServer,lpIniFile);
	wsprintf(string,"%d",g_Config.iWLPort);
    WritePrivateProfileString(SECTION_NAME_WINLIRC,"port",string,lpIniFile);
	wsprintf(string,"%d",g_Config.byWLRepeat);
    WritePrivateProfileString(SECTION_NAME_WINLIRC,"repeat",string,lpIniFile);
	wsprintf(string,"%d",g_Config.iWLRepDelay);
    WritePrivateProfileString(SECTION_NAME_WINLIRC,"repeat_delay",string,lpIniFile);

    // actions
    CString csTemp;
    csBuffer = "";
	int i = 0;
	CString   key;
	INPUT_BTN *btn;

	for (POSITION pos = g_Config.mapInWinLirc.GetStartPosition(); pos != NULL; ){
		g_Config.mapInWinLirc.GetNextAssoc( pos, key, (void*&)btn );

        if (i++ > 0) {
            csBuffer+="|";
		}

		csTemp.Format("%s %i,%i,%i", key, acts[btn->defAction].msgNbr, acts[btn->menuAction].msgNbr, acts[btn->setAction].msgNbr );
        csBuffer+=csTemp;
	}

    WritePrivateProfileString(SECTION_NAME_WINLIRC, "cmds", csBuffer, lpIniFile);

	return TRUE;
}

BOOL CInputWinLIRC::ReadConfig(LPCSTR lpIniFile)
{
    char    *p;
    char    szBuffer[10000];
	CString csBtnName;

	g_Config.bWLEnabled = GetPrivateProfileInt(SECTION_NAME_WINLIRC,"enabled", 0, lpIniFile);
    GetPrivateProfileString(SECTION_NAME_WINLIRC, "server", "localhost", g_Config.szWLServer, sizeof(g_Config.szWLServer), lpIniFile);
	g_Config.iWLPort = GetPrivateProfileInt(SECTION_NAME_WINLIRC,"port",8765, lpIniFile);
    GetPrivateProfileString(SECTION_NAME_WINLIRC, "commands", "", szBuffer, sizeof(szBuffer), lpIniFile);
	g_Config.byWLRepeat = (BYTE)GetPrivateProfileInt(SECTION_NAME_WINLIRC,"repeat",5, lpIniFile);
	g_Config.iWLRepDelay = GetPrivateProfileInt(SECTION_NAME_WINLIRC,"repeat_delay",1000, lpIniFile);
	
	// read new cfg
	char szBtn[20];
	unsigned int defCmd, menuCmd, setCmd;
	INPUT_BTN *btn;

	GetPrivateProfileString(SECTION_NAME_WINLIRC, "cmds", "", szBuffer, sizeof(szBuffer), lpIniFile);
    p = strtok(szBuffer, "|");

    while (p != NULL) {
		// set to 'no action'
		defCmd = menuCmd = setCmd = acts[0].msgNbr;

		int nbr = sscanf(p, "%s %d,%d,%d", szBtn, &defCmd, &menuCmd, &setCmd);

		if (nbr > 1) {
			btn = new INPUT_BTN;
			btn->defAction = btn->menuAction = btn->setAction = 0;

			for (int i=0; i < TOTAL_ACTIONS; i++) {
				if (acts[i].msgNbr == defCmd)
					btn->defAction = i;
				if (acts[i].msgNbr == menuCmd)
					btn->menuAction = i;
				if (acts[i].msgNbr == setCmd)
					btn->setAction = i;
			}

			CString csKey = szBtn;
			g_Config.mapInWinLirc.SetAt(csKey, btn);
		}

        p = strtok(NULL, "|");
    }

	return TRUE;
}

BOOL CInputWinLIRC::IsConnected()
{
	return m_bConnected;
}

BOOL CInputWinLIRC::CloseDevice()
{
	ShutDown(CAsyncSocket::both);
	Close();

	m_bConnected = m_bInitialized = false;

	return TRUE;
}
