/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// ID3Tag.h: interface for the CID3Tag class.
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ID3TAG_H__E389AAE0_9D49_11D3_A83D_0010A4F5373D__INCLUDED_)
#define AFX_ID3TAG_H__E389AAE0_9D49_11D3_A83D_0010A4F5373D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define ID3TAG_BUFFER_SIZE 512

class CID3Tag  
{
private:
	LPSTR TrimTrailingSpaces(LPSTR lpString);
	char	m_szSongName[ID3TAG_BUFFER_SIZE];
	char	m_szArtist  [ID3TAG_BUFFER_SIZE];
	char	m_szAlbum   [ID3TAG_BUFFER_SIZE];
	char	m_szYear    [ID3TAG_BUFFER_SIZE];
	char	m_szComment [ID3TAG_BUFFER_SIZE];
	char	m_szTrack   [ID3TAG_BUFFER_SIZE];
	char	m_szGenre   [ID3TAG_BUFFER_SIZE];
	char    szID        [5] ;
	BOOL	m_bTag;

	BYTE	m_byGenre;


public:
	CID3Tag();
	CID3Tag(LPCSTR lpFileName);
	virtual ~CID3Tag();

	BOOL   ReadTag(LPCSTR lpFileName);
    BOOL   Read_ID3v1Tag(LPCSTR lpFileName);
    BOOL   Read_ID3v2Tag(LPCSTR lpFileName);
    BOOL   Read_APE1Tag(const char* filename);
    BOOL   Read_APE2Tag(const char* filename);
    BOOL   Read_OggTag(const char* filename);
	BOOL   hasID3Tag();
	LPCSTR GetGenre();
	LPCSTR GetTrackNumber();
	LPCSTR GetComment();
	LPCSTR GetYear();
	LPCSTR GetAlbum();
	LPCSTR GetArtist();
	LPCSTR GetTitle();

	// MZ 2002/11/20 changed to public for future 'smart tag handling' by external class
	void	Reset();
};

#endif // !defined(AFX_ID3TAG_H__E389AAE0_9D49_11D3_A83D_0010A4F5373D__INCLUDED_)
