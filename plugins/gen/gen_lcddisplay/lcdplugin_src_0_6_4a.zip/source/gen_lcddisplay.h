/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// gen_lcddisplay.h : main header file for the GEN_LCDDISPLAY DLL
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 13.11.99 - text alignment definitions added, M.Zehnder
// 18.11.99 - Sroll Separator Field added, F. Verhamme
// 20.11.99 - ID3-tag definitions added, M.Zehnder
// 20.07.00 - LCD Menu functions to control Winamp over LCD, F. Verhamme
// 24.07.00 - Get & Set Winamp Shuffle status, F. Verhamme
// 01.08.00 - Select Userdefined Playlists via LCD Menu, F. Verhamme
// 18.10.00 - Aktuelle FRONTEND.H eingebaut
// 18.10.00 - Aenderungen am Shuffle, Repeat hinzugefuegt
// 08.07.01 - KEY_CFG added, MZ

// 2002/01/04 MZ  Input driver cfg's added
// 2002/11/10 MZ  integrations made by TiTi: new output vars (cpu, mem, volbar)
// 2003/01/12 MZ  new vars for serial input
// 2003/01/21 MZ  DYNAMIC_FIELD bugfix
// 2003/01/25 MZ  new vars for ext keyboard input (TiTi T5)
// 2003/02/09 MZ  some cleanup & commented out unused variables for the next major cleanup
//
/////////////////////////////////////////////////////////////////////////////
//
// TODO: move lcd specific stuff into the lcd driver
//       
//

#if !defined(AFX_GEN_LCDDISPLAY_H__26D7E903_3EDF_11D3_B5FB_0010A4F5373D__INCLUDED_)
#define AFX_GEN_LCDDISPLAY_H__26D7E903_3EDF_11D3_B5FB_0010A4F5373D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include <afxtempl.h>
#include "ReadWrit.h"
#include "LCDFactory.h"
#include "Lcd.h"
#include "ID3Tag.h"
#include "Volume.h"
#include "CustomChar.h"
#include "LCDMenuFunc.h"
#include "OutputFields.h"
#include "InputWinLIRC.h"
#include "InputKeyboard.h"
#include "InputWinampKeyboard.h"
#include "InputSerial.h"
#include "InputParallel.h"


// ---------------  D E F I N E S  --------------------------------------------

// WARNING: don't change GPPHDR_VER! This defines the winampGeneralPurposePlugin
//          structure, but I have no clue in which way...
#define GPPHDR_VER 0x10

#define CONFIG_FILE			 "gen_LCD.ini"
#define MENU_FILE		     "lcdmenu.ini"
#define SECTION_NAME		 "Settings"
#define SECTION_NAME_KEYPAD	 "Keypad"
#define SECTION_NAME_WINLIRC "WinLIRC"
#define WINAMPINI_FILE		 "winamp.ini"
#define WINAMP_SECTION		 "Winamp"

#define LIST_SEPARATOR          "�"
#define FIELD_SEPARATOR         "$�"
#define DEFAULT_RAW_FIELD       "1�0�0�%1�0�0"

#define REQ_WINAMP_VERSION      0x2400 //required Version 2.4+
#define MAJOR_VER(x) ((int)(((x) & 0x0000F000) >> 12))
#define MINOR_VER(x) ((int)(((x) & 0x00000F00) >> 8) * 10 + ((x) & 0x000000FF))

#define MAX_STATUS_STRLEN       20
#define MAX_TIME_STRLEN         20
#define MAX_INIT_STRLEN         50
#define MAX_VB_CHAR             10
#define MAX_SERVER_STRLEN       50
#define MAX_LCD_MSG_STRLEN      40

// TODO: make max number of custom chars dynamic
#define MAX_CUSTOM_CHAR         8 // changed by FV
#define MAX_SYSTEM_CCHAR        256

#define TIMEOUT_GLOBAL          0
#define TIMEOUT_TRACKCHANGE     1
#define TIMEOUT_TRACKPLAYCHANGE 2

// field types
#define SONG_POS                0x0000001
#define PLAYBACK_STATUS         0x0000002
#define PLAYLIST_LEN            0x0000004
#define SONG_LENGTH             0x0000008
#define SONG_TITLE              0x0000010
#define SAMPLE_RATE             0x0000020
#define BIT_RATE                0x0000040
#define CHANNELS                0x0000080
#define PLAYLIST_POS            0x0000100
#define PLAYLIST_LENGTH         0x0000200
#define ID3_ARTIST              0x0000400
#define ID3_TITLE               0x0000800
#define ID3_ALBUM               0x0001000
#define ID3_YEAR                0x0002000
#define ID3_COMMENT             0x0004000
#define ID3_GENRE               0x0008000
#define ID3_TRACK               0x0010000
#define VOLUME                  0x0020000
#define SYS_TIME                0x0040000
#define SHUFFLE                 0x0080000
#define REPEAT                  0x0100000
#define SLEEPTIMER				0x0200000
#define CPUUSAGE				0x0400000
#define MEMUSAGE				0x0800000
#define VOLUMEBAR				0x1000000


// fields that will always be checked in the output timer fct WinampTimerFunc. bugfix MZ 2003/01/21: must be enclosed in brackets!
#define DYNAMIC_FIELD	(VOLUME | SYS_TIME | SONG_POS | SHUFFLE | REPEAT | SAMPLE_RATE | SLEEPTIMER | CPUUSAGE | MEMUSAGE)

// output variable tags
#define SONGTITLE_TAG           "%1"
#define PLAYBACKSTATUS_TAG      "%2"
#define PLAYLISTPOS_TAG         "%3"
#define PLAYLISTLENGTH_TAG      "%4"
#define SONGLEN_TAG             "%5"
#define SONGPOS_TAG             "%6"
#define CHANNELS_TAG            "%7"
#define SAMPLERATE_TAG          "%8"
#define BITRATE_TAG             "%9"
#define ID3_ARTIST_TAG          "%i1"
#define ID3_TITLE_TAG           "%i2"
#define ID3_ALBUM_TAG           "%i3"
#define ID3_YEAR_TAG            "%i4"
#define ID3_COMMENT_TAG         "%i5"
#define ID3_GENRE_TAG           "%i6"
#define ID3_TRACK_TAG           "%i7"
#define VOLUME_TAG              "%v"
#define SYS_TIME_TAG            "%t"
#define SHUFFLE_TAG             "%s"
#define HOUR_TAG                "hh"
#define MINUTE_TAG              "mm"
#define EXT_MINUTE_TAG          "mmm"
#define SECOND_TAG              "ss"
#define REPEAT_TAG              "%rep"
#define SPINNING_TAG			"%S"
#define CPUUSAGE_TAG			"%cpu"
#define MEMUSAGE_TAG			"%mem"
#define SLEEPTIMER_TAG			"%Timer"
#define VOLUMEBAR_TAG			"%V"


// position of the output variable in the configuration dlg
#define SONGTITLE_VAR           0
#define PLAYBACKSTATUS_VAR      1
#define PLAYLISTPOS_VAR         2
#define PLAYLISTLENGTH_VAR      3
#define SONGLEN_VAR             4
#define SONGPOS_VAR             5
#define CHANNELS_VAR            6
#define SAMPLERATE_VAR          7
#define BITRATE_VAR             8
#define VOLUME_VAR              9
#define TIMEDATE_VAR            10
#define TXT_CONV_VAR            11
#define CUSTOM_CHAR_VAR         12
#define SHUFFLE_VAR             13
#define REPEAT_VAR              14
#define SPINNING_VAR			15
#define CPUUSAGE_VAR			16
#define MEMUSAGE_VAR			17
#define VOLUMEBAR_VAR           18
#define SLEEPTIMER_VAR			19

#define CONV_UPPERCASE          1
#define CONV_LOWERCASE          2
#define CONV_FIRSTUPPER         3
#define CONV_DONTCHANGE         4
#define CONV_UPPERCASE_FIRST	5

// default values
#define DEF_LCDREFRESH          10
#define DEF_WINAMPPOLL          5
#define DEF_SCROLLSTEPS         10
#define DEF_SCROLLSPEED         (DEF_SCROLLSTEPS / 2)
#define DEF_SCROLLTIMESTART     200
#define DEF_SCROLLTIMESTEP      (1000 - DEF_SCROLLTIMESTART) / DEF_SCROLLSPEED
#define DEF_SCROLL_SEPARATOR    "-*-"
#define DEF_SCROLL_SEPARATOR2   " � "
#define DEF_TXT_CONV            CONV_FIRSTUPPER
#define DEF_TIME_FORMAT         "mm:ss"
#define DEF_SYSTIME_FORMAT      "%H:%M:%S"

// text alignment definitions
#define ALIGNMENT_LEFT          1
#define ALIGNMENT_CENTER        2
#define ALIGNMENT_RIGHT         3
#define DEF_PLAYLISTPATHUSER    "C:\\"

// ---------------  G L O B A L   D E F I N I T I O N S  ----------------------

typedef struct {
	int version;
	char *description;
	int (*init)();
	void (*config)();
	void (*quit)();
	HWND hwndParent;
	HINSTANCE hDllInstance;
} winampGeneralPurposePlugin;


struct KB_KEY
{
	int		keyCode;
	int		lParam;
	int		action;
};

struct INPUT_BTN
{
	int		defAction;
	int		menuAction;
	int		setAction;
};

enum  	INITSTATUS {		// changed to enum value for different scroll effects, MZ 2002/01/09
			IN_PROGRESS,
			OK,
			FAILED
		};

struct CONFIG
{
	char	szPlay[MAX_STATUS_STRLEN + 1];
	char	szStop[MAX_STATUS_STRLEN + 1];
	char	szPause[MAX_STATUS_STRLEN + 1];
	char	szTimeFormat[MAX_TIME_STRLEN + 1];
	char	szDateTimeFormat[MAX_TIME_STRLEN + 1];
	char	szDriver[20];
	char	szScrollSeparator[MAX_STATUS_STRLEN + 1];
	char	szScrollSeparator2[MAX_STATUS_STRLEN + 1];
	char	szPlaylistPathUser[MAX_PATH];
	char	szShuffleOn[MAX_STATUS_STRLEN + 1];
	char	szShuffleOff[MAX_STATUS_STRLEN + 1];
	char	szRepeatOn[MAX_STATUS_STRLEN + 1];
	char	szRepeatOff[MAX_STATUS_STRLEN + 1];
	BYTE	byTimeoutType;
	volatile BYTE	byLCDRefresh;		// volatile: directly accessed in output thread
	BYTE	byWinAmpPoll;
	BYTE	byScrollSpeed;
	BYTE	byScrollSteps;
	int		iScrollTimeStart;
	int		iScrollTimeStep;
	int		iSwitchStop;
	int		iSwitchPause;
	int		iSaveSet;
	int		iEquaType;
	BOOL	bTempVB;
	BOOL	bSpinCharOK;
	BOOL	bAutoOpen;
	BOOL	bBacklight;
	BOOL	bOutput;
	BOOL	bRowMode;
	BOOL	bCheckSize;
	BOOL	bLocal;
	BOOL	bTrimLeading;
	BOOL	bTrimTrailing;
	BYTE	byTxtConv;
	BOOL	bTimeFwd;
	BOOL	bTimeBlink;
	BYTE	byVolSource;

	int		iBacklightTimeout;
	DWORD   dwSwitchSetTimeout;
	CCustomChar	 carrCustomChar[MAX_SYSTEM_CCHAR];	// TODO: make dynamic
	CCustomChar  carrMenueChar[MAX_CUSTOM_CHAR+1];	// bugfix: +1 since we don't use custom char 0 in the other drivers...
    BOOL    bEnableKeypad;
    BOOL    bEnableWinampKeypad;

	COutputFieldHandler	cOutputFields;
	CVolume				*pcVolume;

	// volume bar settings
	int		iVolBarLen;
	int		iVBcol;
	int		iVBrow;
	int		iVBwidth;
	char    szVBchar[MAX_VB_CHAR];

	// spectrum analyser settings
	BOOL	bAutoAnalyser;
	BOOL	bFalloff;
	int     iSAcol;
	int		iSArow;
	int		iSAwidth;
	int		iSAheight;

	// playlist settings
	BOOL    bPLsort;
	BOOL	bPLrecursive;

	// WinLIRC input
	BOOL    bWLEnabled;
	char    szWLServer[MAX_SERVER_STRLEN+1];
	int		iWLPort;
	BYTE	byWLRepeat;    
	int     iWLRepDelay;
	CMapStringToPtr mapInWinLirc;

	// Serial input
	BOOL		 bInSerialEnabled;
	BOOL         bInSerialLCDport;
	char		 szInSerialPort[7];
	char         szInSerialBaud[8];
	BYTE		 byInSerialStartChar;
	BYTE         byInSerialEndChar;
	BOOL         bInSerialStatic;
	BYTE         byInSerialLen;
	CMapStringToPtr mapInSerial;

	// keyboard input
	CMapWordToPtr mapKBcfg;
	CMapWordToPtr mapKBcfg_menu;
	CMapWordToPtr mapKBcfg_set;

	// Winamp keyboard input
	CMapWordToPtr mapWAKBcfg;
	CMapWordToPtr mapWAKBcfg_menu;
	CMapWordToPtr mapWAKBcfg_set;


	// Parallel input
	BOOL		 bInParallelEnabled;
	BOOL         bInParallelLCDport;
	// @TODO change port to int
	char		 szInParallelPort[7];
	BYTE         byInParallelInterface;
	CMapStringToPtr mapInParallel;

	// initialization status, MZ 2002/06/15
	INITSTATUS eInitStatus;
	
	// Performance Monitoring, only supported by Windows NT (might work with 98 and optional resource kit?)
	BOOL    bWinNT;
	BOOL	bPerfMonEnabled;	// option to disable
	BOOL	bPerfMonForce;		// force loading, don't check OS version

	// shutdown & hibernation features
	char    szLCDMsgHibernate[MAX_LCD_MSG_STRLEN+1];
	char    szLCDMsgStandby[MAX_LCD_MSG_STRLEN+1];
	char    szLCDMsgShutdown[MAX_LCD_MSG_STRLEN+1];
	char    szLCDMsgReboot[MAX_LCD_MSG_STRLEN+1];
	BOOL    bShutdownForce;

	// sleep timer
	BYTE    bySleepFunction;
};	

struct WINAMP_INFO
{
	int     iVersion;
	int     iPlaybackStatus;
	int     iSongLength;
	int     iSongPosition;
	int     iPlaylistLength;
	int     iPlaylistPos;
	int     iSampleRate;
	int     iBitRate;
	int     iChannels;
	BOOL    bSongChange;
	BOOL    bPlayStatusChange;
	BYTE    byVolume;
	CString	csFileName;
	CString	csTitleName;
	CID3Tag cID3Tag;
};	

struct SPECTRUM_ANALYSER
{
	int     active;
	int     char_loaded;
    int     in_menu;	// Status merken, wenn in Menue
	int		falloff;
};

// ---------------  G L O B A L   F U N C T I O N S  --------------------------

void ClearOutputFields();
void config_write(LPCSTR lpIniFile);
void config_read(LPCSTR lpIniFile);
VOID CALLBACK ScrollTimerFunc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );

DWORD WINAPI LCDOutputThread(LPVOID pVoid);
DWORD WINAPI WinampPollThread(LPVOID pVoid);

void setFieldTypes();
LPCSTR FormatTime(int iSeconds, BOOL bBlink = FALSE);
LPCSTR FormatOutputText(COutputField *pcField);
void   SetCustomChars();
void SetMenueChars();
int CalculatePlayNo(int iCurrentNo, int iAddValue);
LPCTSTR GetLastErrorMsg( LPTSTR lpBuffer, int iBufLen);

extern winampGeneralPurposePlugin *gen_plugins[256];
typedef winampGeneralPurposePlugin * (*winampGeneralPurposePluginGetter)();

// ---------------  G L O B A L   V A R I A B L E S  --------------------------

extern char         g_szAppName[];
extern char         g_szIniFile[MAX_PATH];
extern BYTE			g_byCurrSet, g_byMaxSets;
extern BOOL         g_bComPortOpen;
extern BOOL         g_bUpdateAll;
extern UINT         g_uiScrollTimer;
extern CONFIG       g_Config;
extern WINAMP_INFO  g_WinAmpInfo;
extern RWLock       g_OutputLock;
extern CLCDFactory  g_LCDFactory;
extern CLcd         *g_LCD;
extern winampGeneralPurposePlugin g_Plugin;
extern SPECTRUM_ANALYSER g_Spectrum_Analyser;
extern UINT         g_uiMenuTimer1, g_uiMenuTimer2;
extern CInputWinLIRC	   g_InWinLIRC;
extern CInputKeyboard	   g_InKeyboard;
extern CInputWinampKeyboard	   g_InWinampKeyboard;
extern CInputSerial		   g_InSerial;
extern CInputParallel	   g_InParallel;
// extern CRITICAL_SECTION critSecLCDWrite; MZ to be checked...
//Sleep-Timer
extern UINT			g_uiSleepTimer;
extern BOOL			g_bSleepActive;
extern int			g_iSleepTime;


/////////////////////////////////////////////////////////////////////////////
// CGen_lcddisplayApp
// See gen_lcddisplay.cpp for the implementation of this class
//
// WARNING: don't delete this class unless you know exactly what and how to 
//          initialize at startup! (as you see, I don't know it...)
//
class CGen_lcddisplayApp : public CWinApp
{
public:
	CGen_lcddisplayApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGen_lcddisplayApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CGen_lcddisplayApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GEN_LCDDISPLAY_H__26D7E903_3EDF_11D3_B5FB_0010A4F5373D__INCLUDED_)
