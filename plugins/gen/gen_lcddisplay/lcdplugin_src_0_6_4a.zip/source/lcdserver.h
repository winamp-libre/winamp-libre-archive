/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Machine generated IDispatch wrapper class(es) created with ClassWizard
//
/////////////////////////////////////////////////////////////////////////////

// ILCDServer wrapper class
#ifndef ILCDSERVER_H
#define ILCDSERVER_H

class ILCDServer : public COleDispatchDriver
{
public:
	ILCDServer() {}		// Calls COleDispatchDriver default constructor
	ILCDServer(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	ILCDServer(const ILCDServer& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:
	short GetBacklight();
	void SetBacklight(short);
	BOOL GetBlink();
	void SetBlink(BOOL);
	short GetContrast();
	void SetContrast(short);
	BOOL GetLineWrap();
	void SetLineWrap(BOOL);
	BOOL GetScroll();
	void SetScroll(BOOL);
	BOOL GetCursor();
	void SetCursor(BOOL);

// Operations
public:
	void Clear();
	void Close();
	BOOL IsOpen();
	void Home();
	BOOL GetLastError();
	void HBar(short nCol, short nRow, short nDir, short nLen);
	void InitHorizontalBar();
	void InitLargeDigit();
	void InitVerticalBar();
	void LargeDigit(short nCol, short nNumber);
	BOOL Open(LPCTSTR lpComPort);
	void SetPosition(short nCol, short nRow);
	void VBar(short nCol, short nLength);
	void Write(LPCTSTR lpText);
};

#endif