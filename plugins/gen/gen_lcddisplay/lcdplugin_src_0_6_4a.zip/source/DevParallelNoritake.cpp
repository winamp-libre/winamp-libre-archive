/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallelNoritake.cpp: implementation of the CDevParallelNoritake class.
//
// Low level functions for Noritake VFD displays. Taken from the VFD library
// provided by Noritake Co., Inc., file: lptioacc.cpp
// Origianal authors: David A. Rice / Critical Link, LLC, 404 Oak St., Syracuse, NY
//
// Modifications:
// 2003/02/09 MZ  configurable delay value & turbo option
// 
//
//	THIS IS THE VERY FIRST IMPLEMENTATION! EVERYTHING CAN CHANGE...
//  ESPECIALLY WITH THE INTEGRATION OF THE VFD LIBRARY
//
/////////////////////////////////////////////////////////////////////////////


/***********************************************************************/
/*                                                                     */
/*  This set of access routines is used to drive the Noritake VFD      */
/*  using a Extended Capabilities Port (ECP) on an IBM PC compatible   */
/*  machine.  The ECP port is a full function printer port and is      */
/*  required by Microsoft for running current versions of Windows.     */
/*                                                                     */
/*  The pinout for the port used for this program is shown here:       */
/*                                                                     */
/*  LPT             VFD                                                */
/*                                                                     */
/*  D0 - D7         D0 - D7                                            */
/*  /Strobe         /WR                                                */
/*  /Autofeed       /RD                                                */
/*  Select In       C/D                                                */
/*  Init            unused                                             */
/*                                                                     */
/*  This results in a register set that looks like this:               */
/*                                                                     */
/*  LPT Data Port:  D7-D0                                              */
/*  LPT Control Port:  Res, Res, Dir, IRQ Enable, C/D, 0, /RD, /WR     */
/*                                                                     */
/*                                                                     */
/***********************************************************************/


#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DevParallelNoritake.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//#define NORITAKE_CHECK_ECP

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevParallelNoritake::CDevParallelNoritake()
{

}

CDevParallelNoritake::~CDevParallelNoritake()
{

}

BOOL CDevParallelNoritake::Open(LPCSTR lpPort, LPCSTR lpParam)
{
	if (!CDevParallel::Open(lpPort, lpParam)) {
		return FALSE;
	}

	if (Init() != 0) {
		Close();
		return FALSE;
	}

    m_bOpen = TRUE;

	return TRUE;
}

/***************************************************************************/
/*                                                                         */
/* Function:       char VFDIOInit(void)                                    */
/*                                                                         */
/* Arguments:      None                                                    */
/*                                                                         */
/* Return Value:   0 = success;  -1 = error                                */
/*                                                                         */
/* Description:    This function is used to initialize the printer port    */
/*                 for the VFD display.                                    */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
int CDevParallelNoritake::Init() {
   unsigned char Byte;
   char ValidECPPort = 1;


/* test the printer port to see if it is an ECP port */
/* On an ECP port, bit 0 of the control reg is fifo empty, */
/* and bit 1 is fifo full.  Normally these should be set */
/* to 1 and 0, respectively. */

/* get the current value of the ECP control register */
   Byte = port_in(m_iPort + 0x402);

#ifdef NORITAKE_CHECK_ECP
   if ((Byte & 3) != 1) {  /* not an ECP port */
      ValidECPPort = 0;
   } /* endif */

/* write 0x35 to port and check for 0x35 */
   port_out(m_iPort + 0x402, 0x34);

/* get the current value of the ECP control register */
   Byte = port_in(m_iPort + 0x402);

   if (Byte != 0x35) {   /* not an ECP port */
      ValidECPPort = 0;
   } /* endif */


   if (!ValidECPPort) {
      printf("LPT port at 0x%x is not an ECP port\n");
      return(-1);
   } /* endif */
#endif

/* write 0x75 to port to put it into byte mode */
   port_out(m_iPort + 0x402, (port_in(m_iPort + 0x402) & 0x1f) + 0x20);

/* clear port to idle state */
   port_out(m_iPort + 2, 0x20);

   return(0);
}


/***************************************************************************/
/*                                                                         */
/* Function:       char VFDWriteCommand(unsigned char Command)             */
/*                                                                         */
/* Arguments:      Command - command value to write                        */
/*                                                                         */
/* Return Value:   0 = success;  -1 = error                                */
/*                                                                         */
/* Description:    This function is used to write a command word to the    */
/*                 VFD display.                                            */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
int CDevParallelNoritake::WriteCommand(unsigned char Command)
{
   if (!m_bOpen) {
      return(-1);
   } /* endif */

	// attention: the 'delay long' value is abused as turbo switch!
   if (m_delayLong > 0) {
		// set direction to "port_output", C/D to C
	   port_out(m_iPort+2, 0x00);
   }

   // write data port
   port_out(m_iPort, Command);

   if (m_delayShort > 0) {
	   uPause(m_delayShort);
   }

   // set /WR
   port_out(m_iPort+2, 0x01);

   // reset /WR
   port_out(m_iPort+2, 0x00);


   if (m_delayLong > 0) {
		// set direction to "port_input"
		port_out(m_iPort+2, 0x20);
   }

   return 0;
}

/***************************************************************************/
/*                                                                         */
/* Function:       char VFDWriteData(unsigned char Data)                   */
/*                                                                         */
/* Arguments:      Data - data value to write                              */
/*                                                                         */
/* Return Value:   0 = success;  -1 = error                                */
/*                                                                         */
/* Description:    This function is used to write a data word to the       */
/*                 VFD display.                                            */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
int CDevParallelNoritake::WriteData(unsigned char Data)
{
   if (!m_bOpen) {
      return(-1);
   }

	// attention: the 'delay long' value is abused as turbo switch!
   if (m_delayLong > 0) {
		// set direction to "port_output", C/D to C
	   port_out(m_iPort+2, 0x08);
   }

   // write data port
   port_out(m_iPort, Data);

   // set /WR
   port_out(m_iPort+2, 0x09);

   // reset /WR
   port_out(m_iPort+2, 0x08);

   if (m_delayLong > 0) {
		// set direction to "port_input"
		port_out(m_iPort+2, 0x20);
   }

   return 0;
}

/***************************************************************************/
/*                                                                         */
/* Function:       unsigned char VFDReadData(void)                         */
/*                                                                         */
/* Arguments:      None                                                    */
/*                                                                         */
/* Return Value:   value read                                              */
/*                                                                         */
/* Description:    This function is used to read a data word from the      */
/*                 VFD display.                                            */
/*                                                                         */
/*                                                                         */
/***************************************************************************/
unsigned char CDevParallelNoritake::ReadData()
{
   int i;
   int nBadReads;
   unsigned char Data;

   unsigned int OldData;

   if (!m_bOpen) {
      return(-1);
   } /* endif */


/* set direction to "port_input", C/D to D */
   port_out(m_iPort+2, 0x28);

/* set /RD */
   port_out(m_iPort+2, 0x2A);

   nBadReads = 0;
   OldData = 0x55;
   for (i=0; i<3; i++) {
   /* read port */
      Data = port_in(m_iPort);
      if (Data != OldData) {
         OldData = Data;
         nBadReads++;
      } /* endif */
   } /* endfor */

/* reset /RD */
    port_out(m_iPort+2, 0x2A);

    if (nBadReads > 1) printf("nBadReads = %d\n", nBadReads);

   return(Data);
}
