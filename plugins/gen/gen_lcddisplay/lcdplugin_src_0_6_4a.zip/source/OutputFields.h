// OutputFields.h: interface for the COutputFields class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OUTPUTFIELDS_H__9FAD0190_5EA9_4B54_A33C_3C80CE6705A4__INCLUDED_)
#define AFX_OUTPUTFIELDS_H__9FAD0190_5EA9_4B54_A33C_3C80CE6705A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// TODO: add copy constructor !!!
class COutputField
{
public:
	int		m_iRow;
	int		m_iCol;
	int		m_iLength;
	int		m_iType;
	int     m_iScrollIndex;
	int		m_iAlignment;
	BYTE	m_bySet;		// future enhancement: multiple output sets, specifies set #
	enum  	SCROLLING {		// changed to enum value for different scroll effects, MZ 2002/01/09
				OFF,
				FORWARD,
				BOUNCE,
				BACKWARD
				} m_ScrollType;		
	BOOL	m_bScrollForwards; //added by James Maher. Keeps track of forward or reverse scrolling for the Bounce Scroll
	BOOL	m_bActive;
	BOOL	m_bUpdate;
	CString	m_csText;
	CString	m_csLCDText;

	COutputField()
	{   
		m_bActive = FALSE; //add the m_bScroll by James Maher
		m_ScrollType = OFF;
		m_bScrollForwards = TRUE; //added by James Maher
		m_iRow = m_iCol = m_iLength = m_iScrollIndex = 0;
	}

	COutputField( LPCTSTR lpText, int iLength = 0, BOOL bActive = TRUE, int iRow = 0 , int iCol = 0, SCROLLING Scroll = OFF )
	{
		m_bActive = bActive;
		m_iRow = iRow;
		m_iCol = iCol, m_csText = lpText;
		m_iLength = iLength;
		m_ScrollType = Scroll;
		m_iScrollIndex = 0;
	}

	COutputField(COutputField &field)
	{
		m_iRow = field.m_iRow;
		m_iCol = field.m_iCol;
		m_iLength = field.m_iLength;
		m_iType = field.m_iType;
		m_iScrollIndex = field.m_iScrollIndex;
		m_iAlignment = field.m_iAlignment;
		m_bySet = field.m_bySet;
		m_ScrollType = field.m_ScrollType;
		m_bActive = field.m_bActive;
		m_bUpdate = field.m_bUpdate;
		m_csText = field.m_csText;
		m_csLCDText = field.m_csLCDText;
	}
};


class COutputFieldHandler  
{
private:
	BYTE	     m_bySets;
	BYTE		 m_byCurrSet;
    CPtrArray    m_cptrarrField;

public:
	COutputFieldHandler();
	virtual ~COutputFieldHandler();

	BYTE SwitchSet();
	BYTE GetCurrentSet();
	void SetCurrentSet(BYTE bySet);
	BYTE CopySet(BYTE bySet);
	BYTE GetSetCount();
	void Add(COutputField *pcField);
	COutputField * GetField(int iIndex);
	int GetFieldCount(BYTE bySet);
	int GetTotalFieldCount();
	void LoadFromCfgString(LPSTR lpString);
	CString GetCfgString();
	void Init();
	void DeleteSet(BYTE byNbr);
	void ClearSet(BYTE byNbr);
	void Clear();

};

#endif // !defined(AFX_OUTPUTFIELDS_H__9FAD0190_5EA9_4B54_A33C_3C80CE6705A4__INCLUDED_)
