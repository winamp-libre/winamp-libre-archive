// DlgPageAdditional.cpp : implementation file
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgPageAdditional.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPageAdditional property page

IMPLEMENT_DYNCREATE(CDlgPageAdditional, CPropertyPage)

CDlgPageAdditional::CDlgPageAdditional() : CPropertyPage(CDlgPageAdditional::IDD)
{
	//{{AFX_DATA_INIT(CDlgPageAdditional)
	m_bOnPause = FALSE;
	m_bOnStop = FALSE;
	m_cOnStop = _T("");
	m_cOnPause = _T("");
	//}}AFX_DATA_INIT
}

CDlgPageAdditional::~CDlgPageAdditional()
{
}

void CDlgPageAdditional::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPageAdditional)
	DDX_Check(pDX, IDC_RAD_EQ1, m_bEq1);
	DDX_Check(pDX, IDC_RAD_EQ2, m_bEq2);
	DDX_Check(pDX, IDC_CHECK_ONPAUSE, m_bOnPause);
	DDX_Check(pDX, IDC_CHECK_ONSTOP, m_bOnStop);
	DDX_Text(pDX, IDC_EDIT_STOP, m_cOnStop);
	DDX_Text(pDX, IDC_EDIT_PAUSE, m_cOnPause);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPageAdditional, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgPageAdditional)
	ON_BN_CLICKED(IDC_CHECK_ONPAUSE, OnCheckOnpause)
	ON_BN_CLICKED(IDC_CHECK_ONSTOP, OnCheckOnstop)
	ON_EN_CHANGE(IDC_EDIT_PAUSE, OnChangeEditPause)
	ON_EN_CHANGE(IDC_EDIT_STOP, OnChangeEditStop)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPageAdditional message handlers

BOOL CDlgPageAdditional::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_bOnPause = (g_Config.iSwitchPause == -1) ? FALSE : TRUE;
	m_bOnStop = (g_Config.iSwitchStop == -1) ? FALSE : TRUE;

	if (m_bOnPause)
		m_cOnPause.Format("%d", g_Config.iSwitchPause);
	if (m_bOnStop)
		m_cOnStop.Format("%d", g_Config.iSwitchStop);
	
	if (g_Config.iEquaType == 0)
		m_bEq1 = TRUE;
	else if (g_Config.iEquaType == 1)
		m_bEq2 = TRUE;
	//	m_EquaExtend = g_Config.bEquaExtend;
//	m_EquaWidth.Format("%d", g_Config.iEquaWidth + 7);
	
	UpdateData(FALSE);

	return TRUE;
}

void CDlgPageAdditional::OnCheckOnpause() 
{
	this->SetModified();
}

void CDlgPageAdditional::OnCheckOnstop() 
{
	this->SetModified();
}

BOOL CDlgPageAdditional::OnApply() 
{
	UpdateData(TRUE);

	if (m_bOnPause == FALSE)
		g_Config.iSwitchPause = -1;
	else
	{
		g_Config.iSwitchPause = atoi(m_cOnPause.GetBuffer(1));
		m_cOnPause.ReleaseBuffer();
	}

	if (m_bOnStop == FALSE)
		g_Config.iSwitchStop = -1;
	else
	{
		g_Config.iSwitchStop = atoi(m_cOnStop.GetBuffer(1));
		m_cOnStop.ReleaseBuffer();
	}
//	g_Config.bEquaExtend = m_EquaExtend;
//	g_Config.iEquaWidth = atoi(m_EquaWidth.GetBuffer(1)) - 7;
//	m_EquaWidth.ReleaseBuffer();

	if (m_bEq1 == TRUE)
		g_Config.iEquaType = 0;
	else if (m_bEq2 == TRUE)
		g_Config.iEquaType = 1;

	return CPropertyPage::OnApply();
}

void CDlgPageAdditional::OnChangeEditPause() 
{
	this->SetModified();
}

void CDlgPageAdditional::OnChangeEditStop() 
{
	this->SetModified();
}
