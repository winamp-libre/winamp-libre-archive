// DlgCfgPJRC.cpp : implementation file
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "LcdPjrc.h"
#include "DlgCfgPJRC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgPJRC dialog


CDlgCfgPJRC::CDlgCfgPJRC(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCfgPJRC::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCfgPJRC)
	m_csPort = _T("");
	m_iFont = 0;
	//}}AFX_DATA_INIT
}


void CDlgCfgPJRC::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCfgPJRC)
	DDX_CBString(pDX, IDC_COMBO_COMPORT, m_csPort);
	DDX_Text(pDX, IDC_EDIT_FONT, m_iFont);
	DDV_MinMaxInt(pDX, m_iFont, 0, 31);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCfgPJRC, CDialog)
	//{{AFX_MSG_MAP(CDlgCfgPJRC)
	ON_BN_CLICKED(IDC_DEF_BTN, OnDefBtn)
	ON_BN_CLICKED(IDC_BTN_FONT1, OnBtnFont1)
	ON_BN_CLICKED(IDC_BTN_FONT2, OnBtnFont2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgPJRC message handlers

BOOL CDlgCfgPJRC::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_iFont = g_PjrcCfg.byFont;

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCfgPJRC::OnDefBtn() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgCfgPJRC::OnBtnFont1() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgCfgPJRC::OnBtnFont2() 
{
	// TODO: Add your control notification handler code here
	
}

void CDlgCfgPJRC::OnOK() 
{
	UpdateData();

	g_PjrcCfg.byFont = m_iFont;
	strncpy(g_PjrcCfg.szComPort, m_csPort, sizeof(g_PjrcCfg.szComPort));

	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

