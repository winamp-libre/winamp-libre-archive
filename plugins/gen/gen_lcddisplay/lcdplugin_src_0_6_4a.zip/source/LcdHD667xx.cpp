/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// HD667xx display driver - most of the code has been taken from LcdHD44780.cpp
// Initialization codes, init & write method provided by Ren� Donner, thanx!
// 
// 
// Modifications:
//
// 2002/06/03 MZ  Initial version
// 2003/07/13 MZ  custom character map added 
//

#include "stdafx.h"
#include <conio.h>
#include "gen_lcddisplay.h"
#include "LcdHD667xx.h"

//#include "DevParallel4Bit.h"
#include "DevParallel8Bit667xx.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define DEF_PORT 0x378
#define MAX_CUSTOM_CHARS 8
#define HD667xx_SECTION	"HD667xx"
#define HD667xx_CHARMAP "HD667xx_CHARMAP"


CCfg667xx	 g_667xxCfg;

CCfg667xx::CCfg667xx()
{
	iPort = DEF_PORT;
	iCols = 20;
	iRows =	4;
    bBacklight = FALSE;
	byCellW = 5;
	byCellH = 8;
	byInterface = IF_8BIT;
	bSplitScreens= 0;
	iDelayShort = DEF_DELAY_SHORT;
	iDelayMed  = DEF_DELAY_MED;
	iDelayLong = DEF_DELAY_LONG;
	iDelayInit = DEF_DELAY_INIT;
	iDelayBus  = DEF_DELAY_BUS;
	iDelayMultiplier =  DEF_DELAY_MULTIPLIER;
	DelayType = PORT_IO;
}

CCfg667xx::~CCfg667xx()
{
}

void CCfg667xx::Load(LPCSTR lpIniFile)
{
	iPort = GetPrivateProfileInt(HD667xx_SECTION,"Port",DEF_PORT,lpIniFile); 
	iCols = GetPrivateProfileInt(HD667xx_SECTION,"Columns",20,lpIniFile); 			 
	iRows =	GetPrivateProfileInt(HD667xx_SECTION,"Rows",4,lpIniFile); 
	bBacklight = GetPrivateProfileInt(HD667xx_SECTION,"BacklightCircuit", 0,lpIniFile); 
	byCellW = (BYTE)GetPrivateProfileInt(HD667xx_SECTION,"CellWidth", 5,lpIniFile); 
	byCellH = (BYTE)GetPrivateProfileInt(HD667xx_SECTION,"CellHeight", 8,lpIniFile); 
	byInterface  = (BYTE)GetPrivateProfileInt(HD667xx_SECTION,"Interface", IF_8BIT,lpIniFile); 
	bSplitScreens= (BYTE)GetPrivateProfileInt(HD667xx_SECTION,"SplitScreens", DEF_CONTRAST,lpIniFile); 
	iDelayShort   = GetPrivateProfileInt(HD667xx_SECTION,"DelayShort", DEF_DELAY_SHORT,lpIniFile); 
	iDelayMed = GetPrivateProfileInt(HD667xx_SECTION,"DelayMed", DEF_DELAY_MED,lpIniFile); 
	iDelayLong = GetPrivateProfileInt(HD667xx_SECTION,"DelayLong", DEF_DELAY_LONG,lpIniFile); 
	iDelayInit = GetPrivateProfileInt(HD667xx_SECTION,"DelayInit", DEF_DELAY_INIT,lpIniFile); 
	iDelayBus = GetPrivateProfileInt(HD667xx_SECTION,"DelayBus", DEF_DELAY_BUS,lpIniFile); 
	iDelayMultiplier = GetPrivateProfileInt(HD667xx_SECTION,"DelayMultiplier", DEF_DELAY_MULTIPLIER,lpIniFile); 

	int type = GetPrivateProfileInt(HD667xx_SECTION,"DelayType", 0,lpIniFile);
	DelayType = type ? VHR_TIMING : PORT_IO;
	
	BuildCharMap(HD667xx_CHARMAP, lpIniFile, charMap);
}

void CCfg667xx::Save(LPCSTR lpIniFile)
{
	char string[32];

	wsprintf(string,"%d",iPort);
	WritePrivateProfileString(HD667xx_SECTION,"Port",string,lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(HD667xx_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(HD667xx_SECTION,"Rows",string,lpIniFile);
	wsprintf(string,"%d",bBacklight);
	WritePrivateProfileString(HD667xx_SECTION,"BacklightCircuit",string,lpIniFile);
	wsprintf(string,"%d",byCellW);
	WritePrivateProfileString(HD667xx_SECTION,"CellWidth",string,lpIniFile);
	wsprintf(string,"%d",byCellH);
	WritePrivateProfileString(HD667xx_SECTION,"CellHeight",string,lpIniFile);
	wsprintf(string,"%d",byInterface);
	WritePrivateProfileString(HD667xx_SECTION,"Interface",string,lpIniFile);
	wsprintf(string,"%d",bSplitScreens);
	WritePrivateProfileString(HD667xx_SECTION,"SplitScreens",string,lpIniFile);
	wsprintf(string,"%d",iDelayShort);
	WritePrivateProfileString(HD667xx_SECTION,"DelayShort",string,lpIniFile);
	wsprintf(string,"%d",iDelayMed);
	WritePrivateProfileString(HD667xx_SECTION,"DelayMed",string,lpIniFile);
	wsprintf(string,"%d",iDelayLong);
	WritePrivateProfileString(HD667xx_SECTION,"DelayLong",string,lpIniFile);
	wsprintf(string,"%d",iDelayInit);
	WritePrivateProfileString(HD667xx_SECTION,"DelayInit",string,lpIniFile);
	wsprintf(string,"%d",iDelayBus);
	WritePrivateProfileString(HD667xx_SECTION,"DelayBus",string,lpIniFile);
	wsprintf(string,"%d",iDelayMultiplier);
	WritePrivateProfileString(HD667xx_SECTION,"DelayMultiplier",string,lpIniFile);
	wsprintf(string,"%d",DelayType);
	WritePrivateProfileString(HD667xx_SECTION,"DelayType",string,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdHD667xx::CLcdHD667xx()
{
	lcd_x=0;
	lcd_y=0;

	m_bOpen = FALSE;
	m_bInit = FALSE;
	m_bScroll = m_bBlink = m_bCursor = m_bLineWrap = m_bScroll = FALSE;

	m_bSplitScreens = FALSE;

	m_pcDev = NULL;
}

CLcdHD667xx::~CLcdHD667xx()
{
	Close();
}

void  CLcdHD667xx::Clear()
{
	WriteData(0, RS_INSTR, 1);
	if (m_pcDev) 
		m_pcDev->uPause(g_667xxCfg.iDelayLong);
}


void  CLcdHD667xx::HBar(short x, short y, short nDir, short len)
{
	char map[6] = { 32, 1, 2, 3, 4, (char)255  };

	for (; x<=g_667xxCfg.iCols && len>0; x++) {
		SetPosition(x,y);
		CLcdHD44780::Write( len >= g_667xxCfg.byCellW ? (char)255 : map[len] );
		len -= g_667xxCfg.byCellW;
	}
}

void  CLcdHD667xx::VBar(short x, short len)
{
	char map[9] = {32, 1, 2, 3, 4, 5, 6, 7, (char)255 };

	int y;
	for (y=g_667xxCfg.iRows; y > 0 && len>0; y--) 
	{
		SetPosition(x,y);
		CLcdHD44780::Write( len >= g_667xxCfg.byCellH ? (char)255 : map[len] );
		len -= g_667xxCfg.byCellH;
	}
}


BOOL  CLcdHD667xx::Open()
{
	// init HD667xx
	m_bInit = TRUE;

	LCDEN = 1;
	SECONDLCDEN = 2;
	m_bSplitScreens = g_667xxCfg.bSplitScreens;

	Close();

	switch (g_667xxCfg.byInterface) {
/*
	  case IF_SHIFTREG :
		m_pcDev = new CDevParallelShiftReg();
		break;

	  case IF_4BIT :
		m_pcDev = new CDevParallel4Bit667xx();
		break;
*/
	  default :
		m_pcDev = new CDevParallel8Bit667xx();
	}

	m_pcDev->SetDelayType(g_667xxCfg.DelayType);
	m_pcDev->SetDelays(g_667xxCfg.iDelayShort, g_667xxCfg.iDelayMed, g_667xxCfg.iDelayLong,
		               g_667xxCfg.iDelayInit, g_667xxCfg.iDelayMultiplier);
	m_pcDev->SetBusDelay((BYTE)g_667xxCfg.iDelayBus);
	m_pcDev->SetBacklight(g_667xxCfg.bBacklight);

	char szPort[10];
	wsprintf(szPort, "%d", g_667xxCfg.iPort);

	LPCSTR keypad = g_Config.bInParallelLCDport && g_Config.bInParallelEnabled ? "keypad" : NULL;
	if (!m_pcDev->Open(szPort, keypad)) {
		m_bInit = FALSE;
		return FALSE;
	}

	m_bInit = FALSE;
	m_bOpen = TRUE;

	m_charMap = g_667xxCfg.charMap;

	return TRUE;
}

void  CLcdHD667xx::SetPosition(short x, short y)
{
	x -= 1;
	y -= 1;
	int DDaddr = x + (y % 2) * 0x40;

	if ((y % 4) >= 2)
		DDaddr += g_667xxCfg.iCols;

	if (g_667xxCfg.iRows == 1)
		DDaddr += (x % 8) * (0x40 - 8);      //cope with 16x1 display

	if (!m_bSplitScreens)
	{
		WriteData(LCDEN, RS_INSTR, POS | DDaddr);
	}
	else
	{
		if (y < (g_667xxCfg.iRows / 2))
		{	// 1st controller / LCD

			if (g_667xxCfg.iRows == 2) 
			DDaddr += (x % 8) * (0x40 - 8);// two 16x1 displays

			WriteData(LCDEN, RS_INSTR, POS | DDaddr);
		}
		else
		{	// 2nd controller / LCD

			DDaddr = x + ((y - (g_667xxCfg.iRows / 2)) % 2) * 0x40;

			if (((y - (g_667xxCfg.iRows / 2)) % 4) >= 2) 
				DDaddr += g_667xxCfg.iCols;
	
			if (g_667xxCfg.iRows == 2) 
				DDaddr += (x % 8) * (0x40 - 8);// two 16x1 displays
			
			WriteData(SECONDLCDEN, RS_INSTR, POS | DDaddr);		
		}
	}

	lcd_x = x;
	lcd_y = y;
}

void  CLcdHD667xx::Write(LPCSTR lpText)
{
	if (!lpText) 
		return;

	int x,y;
	CString csText = lpText;
	ConvertTextToLCDCharset(csText);
	LPCSTR p = (LPCTSTR)csText;


	y = lcd_y;
	int iMax = __min(g_667xxCfg.iCols, (int)(lcd_x + strlen(lpText)));	// M.Z.

	for (x = lcd_x; (x < iMax) && *p != '\0'; x++, p++)
	{
	  if (*p == '\n')
	  {
		  x = 0;
		  y++;
		  if (y >= g_44780Cfg.iRows)
			  return;
		  SetPosition(x+1,y+1);
		  p++;
		  iMax = __min(g_44780Cfg.iCols, (int)strlen(p));
	  }
	

	  if ((g_667xxCfg.iRows==1) && (x==8))
		  SetPosition(x+1,y+1);//for  16x1 

	  UCHAR  outChar;
	  switch( *p )
	  {
		  case 1:
		  case 2:
	      case 3:
	      case 4:
	      case 5:
	      case 6:
	      case 7:
	      case 8:
			  // adjust custom chars
		      outChar = *p - 1;
			  break;
          default :
			  outChar = *p;
	  }

	  if (m_bSplitScreens)
	  {
		  if ((g_667xxCfg.iRows == 2) && (x == 8)) 
			  SetPosition(x+1,y+1);// two 16x1's

		  if (y < (g_667xxCfg.iRows / 2)) 
			WriteData(LCDEN, RS_DATA, outChar);
		  else
			WriteData(SECONDLCDEN, RS_DATA, outChar);
	  }
	  else			
	  {
		  WriteData(LCDEN, RS_DATA, outChar);
	  }

	}
}



BOOL  CLcdHD667xx::CreateCustomChar(short n, CCustomChar &cChar)
{
	if (n > MAX_CUSTOM_CHARS)
		return FALSE;

	// @todo: 
	WriteData(0, RS_INSTR, 64 | n*8);

	int iMax = __min(g_667xxCfg.byCellH, cChar.m_byDataSize);
	for (int i = 0; i < iMax; i++)
	{
		if (cChar.m_byarrData[i] > 31)
			cChar.m_byarrData[i] = 0;	
		WriteData(0, RS_DATA, cChar.m_byarrData[i]);
	}

	for (; i < g_667xxCfg.byCellH; i++)
		WriteData(0, RS_DATA, 0);

	return TRUE;
}

short CLcdHD667xx::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

/////////////////////////////////////////////////////////////////
// Sets a custom character from 0-7...
//
// For input, values > 0 mean "on" and values <= 0 are "off".
//
// The input is just an array of characters...
//
void CLcdHD667xx::SetChar(int n, char *dat)
{
	int row, col;
	int letter;

	if (n < 0 || n > 7)
		return;
	if (!dat) 
		return;

	WriteData(0, RS_INSTR, 64 | n*8);

	for(row=0; row<g_667xxCfg.byCellH; row++) {
		letter = 0;
		for(col=0; col<g_667xxCfg.byCellW; col++) {
			letter <<= 1;
			letter |= (dat[(row*g_667xxCfg.byCellW) + col] > 0);
		}
		WriteData(0, RS_DATA, letter);
	}
}

int	CLcdHD667xx::GetRows()		// MZ, June 27
{
	return g_667xxCfg.iRows;
}

int	CLcdHD667xx::GetColumns()	// MZ, June 27
{
	return g_667xxCfg.iCols;
}

