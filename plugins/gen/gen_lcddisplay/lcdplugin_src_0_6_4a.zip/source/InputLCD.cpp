/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Base class of all LCD input related drivers, i.e. LCD's with keypads.
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/01/12 MZ  Added start- and end-character handling
// 2003/02/09 MZ  static buffer in reader thread, don't close thread handle if wait fct failed
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "InputLCD.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CInputLCD::CInputLCD()
{
	m_InpLen = 1;
	m_pcDev = NULL;

	m_bUseLCDport = FALSE;
//	m_pInputs = NULL;
//	m_pActions = NULL;
	m_pmapInput = NULL;

	m_dwPollIntervall = 0; // use read function in blocking mode
}

CInputLCD::~CInputLCD()
{
	CloseDevice();

	if (!m_bUseLCDport && m_pcDev != NULL) {
		delete m_pcDev;
	}
}

BOOL CInputLCD::CloseDevice()
{
	m_bInitialized = FALSE;

	// terminate input read thread
	m_bExit = TRUE;

	if (m_hThread) {
		if (WaitForSingleObject( m_hThread, 1000 ) == WAIT_FAILED) {
			TRACE0("Error waiting for Input Reader Thread.\n");
		} else {
			CloseHandle(m_hThread);
			m_hThread = NULL;
		}
	}

	if (m_pcDev) {
		if (m_bUseLCDport) {
			// 'disconnect' from LCD port owner
			m_pcDev = NULL;
		} else {
			m_pcDev->Close();
			
			delete m_pcDev;
			m_pcDev = NULL;
		}
	}

	return TRUE;
}

#define IN_BUF_LEN  255

DWORD WINAPI CInputLCD::ReaderThread(LPVOID pVoid)
{
	CInputLCD* pIn = (CInputSerial*)pVoid;

	DWORD  inLen = pIn->m_InpLen;
	char buffer[IN_BUF_LEN];

	DWORD read;
	DWORD DataRead,ReadRequested=0;


	while (!pIn->m_bExit)
	{
		memset(buffer, 0, IN_BUF_LEN);

		// Get data from serial port
		BOOL bBlock = (pIn->m_dwPollIntervall == 0);

		if (!bBlock) {
			Sleep(pIn->m_dwPollIntervall);
		}

		// one never knows...
		if (pIn->m_bExit || pIn->m_pcDev == NULL || !pIn->m_pcDev->IsOpen()) {
			break;
		}

		// wait for start character, if defined
		if (pIn->m_byStart != 0) {
			read = pIn->m_pcDev->ReadData((BYTE *)buffer, 1, bBlock);

			if (buffer[0] != pIn->m_byStart) {
				continue;
			}
		}

		// wait for button input

		// if end character has been specified read until that character,
		// otherwise wait for exact input data length

		if (pIn->m_byEnd != 0) {
			int i = 0;
			do {
				read = pIn->m_pcDev->ReadData((BYTE *)(buffer + i++), 1, bBlock);
			} while (i < IN_BUF_LEN && buffer[i-1] != pIn->m_byEnd);
			buffer[i-1] = '\0';
			DataRead = TRUE;
		} else {
			read = pIn->m_pcDev->ReadData((BYTE *)buffer, inLen, bBlock);
			buffer[inLen] = '\0';
			DataRead = (read == inLen);
		}

		// check status, we might have slept for a long time :)
		if (pIn->m_bExit || pIn->m_pcDev == NULL || !pIn->m_pcDev->IsOpen()) {
			break;
		}

		// Process data if any
		if(DataRead)
		{
			pIn->HandleInput(buffer);	
		}

	}		

	return 0;
}

BOOL CInputLCD::HandleInput(LPCSTR lpInput)
{
//	int max;

	if (strlen(lpInput) == 1) {
		if (HandleSongPosInput(lpInput[0])) {
			return TRUE;
		}
	}
/*
	if ((max = m_pInputs->GetSize()) != m_pActions->GetSize()) {
		TRACE("CInputSerial::HandleInput ERROR: mismatch between buttons and actions!");
		return FALSE;
	}
*/
	// new code
	if (m_pmapInput == NULL) {
		return FALSE;
	}

	INPUT_BTN* btn;

	if (!m_pmapInput->Lookup(lpInput, (void *&)btn)) {
		return FALSE;
	}

	int iAction = btn->defAction;

	if (sCurrMenu.pFirstLine /*|| g_bEqua*/)
	{
		// We are in a menu
		if (btn->menuAction != 0) {
			iAction = btn->menuAction;
		}
	}
	else
	{
		// We are in a Set
		if (btn->setAction != 0) {
			iAction = btn->setAction;
		}
	}

	// @TODO handle long press events
	ExecuteAction(acts[iAction], FALSE);

/*
	old code

	// find the button
	for (int i = 0; i < max; i++) {
		if (strcmp((*m_pInputs)[i], lpInput) == 0)
			break;
	}

	if (i == max)
		return FALSE;

	// @TODO handle long press events
	ExecuteAction(acts[(*m_pActions)[i]], FALSE);
*/
	return TRUE;
}

/******************************************************************************
Function : SetStartCharacter
Purpose  : Sets the optional start character
Parameters : start: character or 0 for not using a start character
Returns : void
Author  : Markus Zehnder, 2003/01/12
******************************************************************************/
void CInputLCD::SetStartCharacter(BYTE start)
{
	m_byStart = start;
}

/******************************************************************************
Function : SetEndCharacter
Purpose  : Sets the end character
Parameters : end: character
Returns : void
Author  : Markus Zehnder, 2003/01/12
******************************************************************************/
void CInputLCD::SetEndCharacter(BYTE end)
{
	m_byEnd = end;
}

/******************************************************************************
Function : SetInputLen
Purpose  : Sets the static input length or switches to dynamic input length if
           the length parameter is set 0.
Parameters : length: length of static input or 0 to use dynamic input length
Returns : void
Author  : Markus Zehnder, 2003/01/12
******************************************************************************/
void CInputLCD::SetInputLen(BYTE length)
{
	m_InpLen = length;
}
