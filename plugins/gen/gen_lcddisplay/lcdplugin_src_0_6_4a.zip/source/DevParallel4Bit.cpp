/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DevParallel4Bit44780.cpp: implementation of the CDevParallel4Bit44780 class.
//
// BASED ON THE 4BIT LPT DRIVER FROM LCDPROC (hd44780-4bit.c)
// 
// Modifications:
// [no history yet - still working on the inital working version]
// 
// Original header file:
/*
 * 4-bit driver module for Hitachi HD44780 based LCD displays.
 * The LCD is operated in it's 4 bit-mode to be connected to a single
 * 8 bit-port.
 *
 * Copyright (c)  2000, 1999, 1995 Benjamin Tse <blt@Comports.com>
 *		  2001 Joris Robijn <joris@robijn.net>
 *		  1999 Andrew McMeikan <andrewm@engineer.com>
 *		  1998 Richard Rognlie <rrognlie@gamerz.net>
 *		  1997 Matthias Prinke <m.prinke@trashcan.mcnet.de>
 *
 * The connections are:
 * printer port   LCD
 * D0 (2)	  D4 (11)
 * D1 (3)	  D5 (12)
 * D2 (4)	  D6 (13)
 * D3 (5)	  D7 (14)
 * D4 (6)	  RS (4)
 * D5 (7)	  RW (5) (LCD3 - 6) (optional - pull all LCD RW low)
 * D6 (8)	  EN (6)
 * D7 (9)	  EN2 (LCD2 - 6) (optional)
 *
 * Backlight
 * D5 (7)	  backlight (optional, see documentation)
 *
 * Extended interface (including LCD3 above)
 * D5 (7)	  EN3
 * STR (1)	  EN4
 * LF (14)	  EN5
 * INIT (16)      EN6
 * SEL (17)       EN7
 *
 * Keypad connection (optional):
 * Some diodes and resistors are needed, see further documentation.
 * printer port   keypad
 * D0 (2)	  Y0
 * D1 (3)	  Y1
 * D2 (4)	  Y2
 * D3 (5)	  Y3
 * D4 (6)	  Y4
 * D5 (7)	  Y5
 * nSTRB (1)      Y6
 * nLF  (14)      Y7
 * INIT (16)      Y8
 * nSEL (17)      Y9
 * nACK (10)      X0
 * BUSY (11)      X1
 * PAPEREND (12   X2
 * SELIN (13)     X3
 * nFAULT (15)    X4
 *
 * Added support for up to 7 LCDs Jan 2000, Benjamin Tse
 * Created modular driver Dec 1999, Benjamin Tse <blt@Comports.com>
 *
 * Based on Matthias Prinke's <m.prinke@trashcan.mcnet.de> lcd4.c module
 * in lcdstat. This was in turn based on Benjamin Tse's lcdtime package
 * which uses the LCD controller in its 8-bit mode.
 *
 * This file is released under the GNU General Public License. Refer to the
 * COPYING file distributed with this package.
 */


#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DevParallel4Bit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define RS	0x10
#define RW	0x20
#define EN1	0x40
#define EN2	0x80
#define EN3	0x20
#define BL	0x20
// note that the above bits are all meant for the data port of LPT

static const unsigned char EnMask[] = { EN1, EN2, EN3, STRB, LF, INIT, SEL };

#define ALLEXT  (STRB|LF|INIT|SEL)
// The above bits are on the control port of LPT


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDevParallel4Bit44780::CDevParallel4Bit44780()
{

}

CDevParallel4Bit44780::~CDevParallel4Bit44780()
{

}

BOOL CDevParallel4Bit44780::Close()
{
	// ...

	return CDevParallel::Close();
}

BOOL CDevParallel4Bit44780::Open(LPCSTR lpPort, LPCSTR lpParam)
{
	if (!CDevParallel::Open(lpPort, lpParam))
		return FALSE;

	int enableLines = EN1 | EN2;

/*
	// Reserve the port registers
	port_access(m_iPort);
	port_access(m_iPort+1);
	port_access(m_iPort+2);
*/
	// powerup the lcd now
	if (extIF) {
		enableLines |= EN3;
		port_out (m_iPort + 2, 0 ^ OUTMASK);
	}
	port_out (m_iPort, 0x03);
	if( delayBus ) uPause (delayBus);

	port_out (m_iPort, enableLines | 0x03);
	if (extIF)
		port_out (m_iPort + 2, ALLEXT ^ OUTMASK);
	if( delayBus ) uPause (delayBus);
	port_out (m_iPort, 0x03);
	if (extIF)
		port_out (m_iPort + 2, 0 ^ OUTMASK);
	uPause (m_delayInit);

	port_out (m_iPort, enableLines | 0x03);
	if (extIF)
		port_out (m_iPort + 2, ALLEXT ^ OUTMASK);
	if( delayBus ) uPause (delayBus);
	port_out (m_iPort, 0x03);
	if (extIF)
		port_out (m_iPort + 2, 0 ^ OUTMASK);
	uPause (m_delayMedium);

	port_out (m_iPort, enableLines | 0x03);
	if (extIF)
		port_out (m_iPort + 2, ALLEXT ^ OUTMASK);
	if( delayBus ) uPause (delayBus);
	port_out (m_iPort, 0x03);
	if (extIF)
		port_out (m_iPort + 2, 0 ^ OUTMASK);
	uPause (m_delayShort);

	// now in 8-bit mode...  set 4-bit mode
	port_out (m_iPort, 0x02);
	if( delayBus ) uPause (delayBus);

	port_out (m_iPort, enableLines | 0x02);
	if (extIF)
		port_out (m_iPort + 2, ALLEXT ^ OUTMASK);
	if( delayBus ) uPause (delayBus);
	port_out (m_iPort, 0x02);
	if (extIF)
		port_out (m_iPort + 2, 0 ^ OUTMASK);
	uPause (m_delayShort);

	// Set up two-line, small character (5x8) mode
	senddata (0, RS_INSTR, FUNCSET | TWOLINE | SMALLCHAR );
	uPause (m_delayShort);

	common_init();

	if (have_keypad) {
		// Remember which input lines are stuck
		stuckinputs = readkeypad (0);
	}

	m_bOpen = TRUE;

	return TRUE;
}


// lcdstat_HD44780_senddata
void CDevParallel4Bit44780::senddata (unsigned char displayID, unsigned char flags, unsigned char ch)
{
	unsigned char enableLines = 0, portControl = 0;
	unsigned char h = (ch >> 4) & 0x0f;     // high and low nibbles
	unsigned char l = ch & 0x0f;

	if (flags == RS_INSTR)
		portControl = 0;
	else //if (flags == RS_DATA)
		portControl = RS;

	portControl |= backlight_bit;

	if (displayID <= 3) {
		if (displayID == 0)
			enableLines = EnMask[0] | EnMask[1] | EnMask[2];
		else
			enableLines = EnMask[displayID - 1];

		port_out (m_iPort, portControl | h);
		if( delayBus ) uPause (delayBus);
		port_out (m_iPort, enableLines | portControl | h);
		if( delayBus ) uPause (delayBus);
		port_out (m_iPort, portControl | h);

		port_out (m_iPort, portControl | l);
		if( delayBus ) uPause (delayBus);
		port_out (m_iPort, enableLines | portControl | l);
		if( delayBus ) uPause (delayBus);
		port_out (m_iPort, portControl | l);
	}

	if (extIF && (displayID == 0 || displayID >= 4)) {
		if (displayID == 0)
			enableLines = ALLEXT;
		else
			enableLines = EnMask[(displayID - 1)];

		port_out (m_iPort, portControl | h);
		if( delayBus ) uPause (delayBus);
		port_out (m_iPort + 2, enableLines ^ OUTMASK);
		if( delayBus ) uPause (delayBus);
		port_out (m_iPort + 2, 0 ^ OUTMASK);

		port_out (m_iPort, portControl | l);
		if( delayBus ) uPause (delayBus);
		port_out (m_iPort + 2, enableLines ^ OUTMASK);
		if( delayBus ) uPause (delayBus);
		port_out (m_iPort + 2, 0 ^ OUTMASK);
	}
}

void CDevParallel4Bit44780::backlight (unsigned char state)
{
	if (have_backlight) {
		backlight_bit = (state?0:0x20);	// D5 line

		port_out (m_iPort, backlight_bit);
	}
}

unsigned char CDevParallel4Bit44780::readkeypad (unsigned int YData)
{
	unsigned char readval;

	// 10 bits output or 6 bits if >=3 displays
	// Convert the positive logic to the negative logic on the LPT m_iPort
	port_out (m_iPort, ~YData & 0x003F );
	if (!extIF) {
		port_out (m_iPort + 2, ( ((~YData & 0x03C0) << 6 )) ^ OUTMASK);
	}
	if( delayBus ) uPause (delayBus);

	// Read inputs
	readval = ~ port_in (m_iPort + 1) ^ INMASK;

	// Put m_iPort back into idle state for backlight
	port_out (m_iPort, backlight_bit);

	// And convert value back.
	return ( (readval >> 4 & 0x03) | (readval >> 5 & 0x04) | (readval >> 3 & 0x08) | (readval << 1 & 0x10) ) & ~stuckinputs;
}
