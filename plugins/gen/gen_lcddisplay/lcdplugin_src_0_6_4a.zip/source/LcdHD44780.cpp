/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// HD44780 display driver - most of the code has been taken from the corresponding
// lcdproc driver <hd44780.c> and ported to Windows.
// 
// Modifications:
//
// 05.08.01 - delays after LCD commands configurable, MZ
// 08.07.01 - rewrote Open and WriteData according to the changes in the LCDProc project, MZ
// 17.08.2k - WinNT check, MZ
// 28.06.2k - use defined lcd settings instead of hard coded values, MZ
//
// 2002/01/06 MZ  new bus & multiplier delays added, additional delay option, saving back delay values
// 2002/01/10 MZ  generic getter methods are now in the base class
// 2002/01/11 MZ  start integrating new driver concept...
// 2002/02/16 MZ  Made the new driver concept working! Now it's time for some serious code clean up!
// 2003/07/13 MZ  custom character map added 
// 2003/07/16 MZ  IF_SHIFTREG_EX interface option added

// Original file header: 
//
/* Driver module for Hitachi HD44780 based Optrex DMC-20481 LCD display 
 * The module is operated in it's 4 bit-mode to be connected to a single
 * 8 bit-port
 *
 * Modified 22-24 Dec 1999 Andrew McmMeikan
 *	Added support for '8-Bit WinAmp' Style of wiring
 *
 * Modified 16-19 Nov 1999 Andrew McMeikan
 *	fixed hard coded geometry issues, finished support for split screens
 *
 * Modified 10 Nov 1999 Andrew McMeikan
 *		put back in Benjamin Tse's LCD_Pause to avoid timing errors
 *		13 Nov, fixed delay times in old 4 bit code
 * Modified 19-26 Oct 1999 Andrew McMeikan <andrewm@engineer.com>
 *      to support connection via a shift register with keypad
 * 	4094 conection details at http://members.xoom.com/andrewmuck/LCD.htm
 *	TODO: document connections 
 *	also started mods for two lcd enable lines (40x4) or 2x(2x20)
 *
 * Copyright (c) 1998 Richard Rognlie       GNU Public License  
 *                    <rrognlie@gamerz.net>
 *
 * Large quantities of this code lifted (nearly verbatim) from
 * the lcd4.c module of lcdtext.  Copyright (C) 1997 Matthias Prinke
 * <m.prinke@trashcan.mcnet.de> and covered by GNU's GPL.
 * In particular, this program is free software and comes WITHOUT
 * ANY WARRANTY.
 *
 * Matthias stole (er, adapted) the code from the package lcdtime by
 * Benjamin Tse (blt@mundil.cs.mu.oz.au), August/October 1995
 * which uses the LCD-controller's 8 bit-mode.
 * References: port.h             by <damianf@wpi.edu>
 *             Data Sheet LTN211, Philips
 *             Various FAQs and TXTs about Hitachi's LCD Controller HD44780 -
 *                www.paranoia.com/~filipg is a good starting point  ???   
 */


/* TODO:
 - testing!
 - clean up the fast windows port
 - common cfg setting access
*/

#include "stdafx.h"
#include <conio.h>
#include "gen_lcddisplay.h"
#include "LcdHD44780.h"

#include "DevParallel4Bit.h"
#include "DevParallel8Bit.h"
#include "DevParallelShiftReg.h"
#include "DevParallelShiftRegEx.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define DEF_PORT 0x378
#define MAX_CUSTOM_CHARS 8
#define HD44780_SECTION	"HD44780"
#define HD44780_CHARMAP "HD44780_CHARMAP"


CCfg44780	 g_44780Cfg;

CCfg44780::CCfg44780()
{
	iPort = DEF_PORT;
	iCols = 20;
	iRows =	4;
    bBacklight = FALSE;
	byCellW = 5;
	byCellH = 8;
	byInterface = IF_8BIT;
	bSplitScreens= 0;
	iDelayShort = DEF_DELAY_SHORT;
	iDelayMed  = DEF_DELAY_MED;
	iDelayLong = DEF_DELAY_LONG;
	iDelayInit = DEF_DELAY_INIT;
	iDelayBus  = DEF_DELAY_BUS;
	iDelayMultiplier =  DEF_DELAY_MULTIPLIER;
	DelayType = PORT_IO;
}

CCfg44780::~CCfg44780()
{
}

void CCfg44780::Load(LPCSTR lpIniFile)
{
	iPort = GetPrivateProfileInt(HD44780_SECTION,"Port",DEF_PORT,lpIniFile); 
	iCols = GetPrivateProfileInt(HD44780_SECTION,"Columns",20,lpIniFile); 			 
	iRows =	GetPrivateProfileInt(HD44780_SECTION,"Rows",4,lpIniFile); 
	bBacklight = GetPrivateProfileInt(HD44780_SECTION,"BacklightCircuit", 0,lpIniFile); 
	byCellW = (BYTE)GetPrivateProfileInt(HD44780_SECTION,"CellWidth", 5,lpIniFile); 
	byCellH = (BYTE)GetPrivateProfileInt(HD44780_SECTION,"CellHeight", 8,lpIniFile); 
	byInterface  = (BYTE)GetPrivateProfileInt(HD44780_SECTION,"Interface", IF_8BIT,lpIniFile); 
	bSplitScreens= (BYTE)GetPrivateProfileInt(HD44780_SECTION,"SplitScreens", DEF_CONTRAST,lpIniFile); 
	iDelayShort   = GetPrivateProfileInt(HD44780_SECTION,"DelayShort", DEF_DELAY_SHORT,lpIniFile); 
	iDelayMed = GetPrivateProfileInt(HD44780_SECTION,"DelayMed", DEF_DELAY_MED,lpIniFile); 
	iDelayLong = GetPrivateProfileInt(HD44780_SECTION,"DelayLong", DEF_DELAY_LONG,lpIniFile); 
	iDelayInit = GetPrivateProfileInt(HD44780_SECTION,"DelayInit", DEF_DELAY_INIT,lpIniFile); 
	iDelayBus = GetPrivateProfileInt(HD44780_SECTION,"DelayBus", DEF_DELAY_BUS,lpIniFile); 
	iDelayMultiplier = GetPrivateProfileInt(HD44780_SECTION,"DelayMultiplier", DEF_DELAY_MULTIPLIER,lpIniFile); 

	int type = GetPrivateProfileInt(HD44780_SECTION,"DelayType", 0,lpIniFile);
	DelayType = type ? VHR_TIMING : PORT_IO;

	BuildCharMap(HD44780_CHARMAP, lpIniFile, charMap);
}

void CCfg44780::Save(LPCSTR lpIniFile)
{
	char string[32];

	wsprintf(string,"%d",iPort);
	WritePrivateProfileString(HD44780_SECTION,"Port",string,lpIniFile);
	wsprintf(string,"%d",iCols);
	WritePrivateProfileString(HD44780_SECTION,"Columns",string,lpIniFile);
	wsprintf(string,"%d",iRows);
	WritePrivateProfileString(HD44780_SECTION,"Rows",string,lpIniFile);
	wsprintf(string,"%d",bBacklight);
	WritePrivateProfileString(HD44780_SECTION,"BacklightCircuit",string,lpIniFile);
	wsprintf(string,"%d",byCellW);
	WritePrivateProfileString(HD44780_SECTION,"CellWidth",string,lpIniFile);
	wsprintf(string,"%d",byCellH);
	WritePrivateProfileString(HD44780_SECTION,"CellHeight",string,lpIniFile);
	wsprintf(string,"%d",byInterface);
	WritePrivateProfileString(HD44780_SECTION,"Interface",string,lpIniFile);
	wsprintf(string,"%d",bSplitScreens);
	WritePrivateProfileString(HD44780_SECTION,"SplitScreens",string,lpIniFile);
	wsprintf(string,"%d",iDelayShort);
	WritePrivateProfileString(HD44780_SECTION,"DelayShort",string,lpIniFile);
	wsprintf(string,"%d",iDelayMed);
	WritePrivateProfileString(HD44780_SECTION,"DelayMed",string,lpIniFile);
	wsprintf(string,"%d",iDelayLong);
	WritePrivateProfileString(HD44780_SECTION,"DelayLong",string,lpIniFile);
	wsprintf(string,"%d",iDelayInit);
	WritePrivateProfileString(HD44780_SECTION,"DelayInit",string,lpIniFile);
	wsprintf(string,"%d",iDelayBus);
	WritePrivateProfileString(HD44780_SECTION,"DelayBus",string,lpIniFile);
	wsprintf(string,"%d",iDelayMultiplier);
	WritePrivateProfileString(HD44780_SECTION,"DelayMultiplier",string,lpIniFile);
	wsprintf(string,"%d",DelayType);
	WritePrivateProfileString(HD44780_SECTION,"DelayType",string,lpIniFile);
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLcdHD44780::CLcdHD44780()
{
	lcd_x=0;
	lcd_y=0;

	m_bInit = FALSE;
	m_bScroll = m_bBlink = m_bCursor = m_bLineWrap = m_bScroll = FALSE;

	m_bSplitScreens = FALSE;

	m_pcDev = NULL;
}

CLcdHD44780::~CLcdHD44780()
{
	Close();
}

void  CLcdHD44780::SetBacklight(short nSeconds)
{
	if (nSeconds < 0)
	{
		m_pcDev->backlight(FALSE);
	}
	else
	{
		m_pcDev->backlight(TRUE);
		// TODO test timer functions !!!
		if (nSeconds > 0)
			StartBacklightTimer(nSeconds);
	}

	m_nBackLight = nSeconds;
}

void  CLcdHD44780::SetBlink(BOOL bOn)
{
	// set lcd on (4), cursor_on (2), and cursor_blink(1)
//	WriteData(0, RS_INSTR, 8 | 4 | 2*m_bCursor | bOn);LCD_Pause(g_44780Cfg.iDelayLong);
	m_bBlink = bOn;
}

void  CLcdHD44780::Clear()
{
	WriteData(0, RS_INSTR, 1);
	if (m_pcDev) 
		m_pcDev->uPause(g_44780Cfg.iDelayLong);
}

void  CLcdHD44780::Close()
{
	Clear();

	m_bOpen = FALSE;

	if (m_pcDev) {
		m_pcDev->Close();
		delete m_pcDev;
		m_pcDev = NULL;
	}
}

void  CLcdHD44780::SetContrast(short nLevel)
{
}

void  CLcdHD44780::Cursor(BOOL bOn)
{
	// set lcd on (4), cursor_on (2), and cursor_blink(1)
//	WriteData(0, RS_INSTR, 8 | 4 | 2*bOn | m_bBlink);LCD_Pause(g_44780Cfg.iDelayLong);
	m_bCursor = bOn;
}

void  CLcdHD44780::InitHorizontalBar()
{
  char a[] = {
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
    1,0,0,0,0,
  };
  char b[] = {
    1,1,0,0,0,
    1,1,0,0,0,
    1,1,0,0,0,
    1,1,0,0,0,
    1,1,0,0,0,
    1,1,0,0,0,
    1,1,0,0,0,
    1,1,0,0,0,
  };
  char c[] = {
    1,1,1,0,0,
    1,1,1,0,0,
    1,1,1,0,0,
    1,1,1,0,0,
    1,1,1,0,0,
    1,1,1,0,0,
    1,1,1,0,0,
    1,1,1,0,0,
  };
  char d[] = {
    1,1,1,1,0,
    1,1,1,1,0,
    1,1,1,1,0,
    1,1,1,1,0,
    1,1,1,1,0,
    1,1,1,1,0,
    1,1,1,1,0,
    1,1,1,1,0,
  };

  SetChar(1,a);
  SetChar(2,b);
  SetChar(3,c);
  SetChar(4,d);
}

void  CLcdHD44780::InitVerticalBar()
{
  char a[] = {
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,1,1,
  };
  char b[] = {
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,1,1,
    1,1,1,1,1,
  };
  char c[] = {
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
  };
  char d[] = {
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
  };
  char e[] = {
    0,0,0,0,0,
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
  };
  char f[] = {
    0,0,0,0,0,
    0,0,0,0,0,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
  };
  char g[] = {
    0,0,0,0,0,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
    1,1,1,1,1,
  };

  SetChar(1,a);
  SetChar(2,b);
  SetChar(3,c);
  SetChar(4,d);
  SetChar(5,e);
  SetChar(6,f);
  SetChar(7,g);
}

void  CLcdHD44780::HBar(short x, short y, short nDir, short len)
{
	char map[6] = { 32, 1, 2, 3, 4, (char)255  };

	for (; x<=g_44780Cfg.iCols && len>0; x++) {
		SetPosition(x,y);
		Write( len >= g_44780Cfg.byCellW ? 255 : map[len] );
		len -= g_44780Cfg.byCellW;
	}
}

void  CLcdHD44780::VBar(short x, short len)
{
	char map[9] = {32, 1, 2, 3, 4, 5, 6, 7, (char)255 };

	int y;
	for (y=g_44780Cfg.iRows; y > 0 && len>0; y--) 
	{
		SetPosition(x,y);
		Write( len >= g_44780Cfg.byCellH ? 255 : map[len] );
		len -= g_44780Cfg.byCellH;
	}
}


void  CLcdHD44780::InitLargeDigit()
{
}

void  CLcdHD44780::LargeDigit(short nCol, short nNumber)
{
}

void  CLcdHD44780::SetLineWrap(BOOL bOn)
{
	m_bLineWrap = bOn;
}

BOOL  CLcdHD44780::Open()
{
	// init HD44780
	m_bInit = TRUE;

	LCDEN = 1;
	SECONDLCDEN = 2;
	m_bSplitScreens = g_44780Cfg.bSplitScreens;

	Close();

	switch (g_44780Cfg.byInterface) {
	  case IF_SHIFTREG_EX :
		m_pcDev = new CDevParallelShiftRegEx44780();
		break;
	  case IF_SHIFTREG :
		m_pcDev = new CDevParallelShiftReg44780();
		break;
	  case IF_4BIT :
		m_pcDev = new CDevParallel4Bit44780();
		break;
	  default :
		m_pcDev = new CDevParallel8Bit44780();
	}

	m_pcDev->SetDelayType(g_44780Cfg.DelayType);
	m_pcDev->SetDelays(g_44780Cfg.iDelayShort, g_44780Cfg.iDelayMed, g_44780Cfg.iDelayLong,
		               g_44780Cfg.iDelayInit, g_44780Cfg.iDelayMultiplier);
	m_pcDev->SetBusDelay((BYTE)g_44780Cfg.iDelayBus);
	m_pcDev->SetBacklight(g_44780Cfg.bBacklight);

	char szPort[10];
	wsprintf(szPort, "%d", g_44780Cfg.iPort);

	LPCSTR keypad = g_Config.bInParallelLCDport && g_Config.bInParallelEnabled ? "keypad" : NULL;
	if (!m_pcDev->Open(szPort, keypad)) {
		m_bInit = FALSE;
		return FALSE;
	}

	m_bInit = FALSE;
	m_bOpen = TRUE;

	m_charMap = g_44780Cfg.charMap;

	return TRUE;
}

void  CLcdHD44780::SetPosition(short x, short y)
{
	x -= 1;
	y -= 1;
	int DDaddr = x + (y % 2) * 0x40;

	if ((y % 4) >= 2)
		DDaddr += g_44780Cfg.iCols;

	if (g_44780Cfg.iRows == 1)
		DDaddr += (x % 8) * (0x40 - 8);      //cope with 16x1 display

	if (!m_bSplitScreens)
	{
		WriteData(LCDEN, RS_INSTR, POS | DDaddr);
	}
	else
	{
		if (y < (g_44780Cfg.iRows / 2))
		{	// 1st controller / LCD

			if (g_44780Cfg.iRows == 2) 
			DDaddr += (x % 8) * (0x40 - 8);// two 16x1 displays

			WriteData(LCDEN, RS_INSTR, POS | DDaddr);
		}
		else
		{	// 2nd controller / LCD

			DDaddr = x + ((y - (g_44780Cfg.iRows / 2)) % 2) * 0x40;

			if (((y - (g_44780Cfg.iRows / 2)) % 4) >= 2) 
				DDaddr += g_44780Cfg.iCols;
	
			if (g_44780Cfg.iRows == 2) 
				DDaddr += (x % 8) * (0x40 - 8);// two 16x1 displays
			
			WriteData(SECONDLCDEN, RS_INSTR, POS | DDaddr);		
		}
	}

	lcd_x = x;
	lcd_y = y;
}

void  CLcdHD44780::SetScroll(BOOL bOn)
{
/*
	WriteData(0, RS_INSTR, 4 | bOn * 2);
	LCD_Pause(g_44780Cfg.iDelayLong); //this can take time to do on some displays

	// -> this call reverses the output on my display!

	m_bScroll = bOn;
*/
}

void  CLcdHD44780::Write(char c)
{
	char szTmp[2] = {c, 0};
	Write(szTmp);
}

void  CLcdHD44780::Write(LPCSTR lpText)
{
	if (!lpText) 
		return;

	int x,y;
	CString csText = lpText;
	ConvertTextToLCDCharset(csText);
	LPCSTR p = (LPCTSTR)csText;


	y = lcd_y;
	int iMax = __min(g_44780Cfg.iCols, (int)(lcd_x + strlen(lpText)));	// M.Z.

	for (x = lcd_x; (x < iMax) && *p != '\0'; x++, p++)
	{
	  if (*p == '\n')
	  {
		  x = 0;
		  y++;
		  if (y >= g_44780Cfg.iRows)
			  return;
		  SetPosition(x+1,y+1);
		  p++;
		  iMax = __min(g_44780Cfg.iCols, (int)strlen(p));
	  }
	

	  if ((g_44780Cfg.iRows==1) && (x==8))
		  SetPosition(x+1,y+1);//for  16x1 

	  UCHAR  outChar;
	  switch( *p )
	  {
		  case 1:
		  case 2:
	      case 3:
	      case 4:
	      case 5:
	      case 6:
	      case 7:
	      case 8:
			  // adjust custom chars
		      outChar = *p - 1;
			  break;
          default :
			  outChar = *p;
	  }

	  if (m_bSplitScreens)
	  {
		  if ((g_44780Cfg.iRows == 2) && (x == 8)) 
			  SetPosition(x+1,y+1);// two 16x1's

		  if (y < (g_44780Cfg.iRows / 2)) 
			WriteData(LCDEN, RS_DATA, outChar);
		  else
			WriteData(SECONDLCDEN, RS_DATA, outChar);
	  }
	  else			
	  {
		  WriteData(LCDEN, RS_DATA, outChar);
	  }

	}
}



BOOL  CLcdHD44780::CreateCustomChar(short n, CCustomChar &cChar)
{
	if (n > MAX_CUSTOM_CHARS)
		return FALSE;

	// @todo: 
	WriteData(0, RS_INSTR, 64 | n*8);

	int iMax = __min(g_44780Cfg.byCellH, cChar.m_byDataSize);
	for (int i = 0; i < iMax; i++)
	{
		if (cChar.m_byarrData[i] > 31)
			cChar.m_byarrData[i] = 0;	
		WriteData(0, RS_DATA, cChar.m_byarrData[i]);
	}

	for (; i < g_44780Cfg.byCellH; i++)
		WriteData(0, RS_DATA, 0);

	return TRUE;
}

short CLcdHD44780::GetMaxCustomChar()
{
	return MAX_CUSTOM_CHARS;
}

LPCTSTR CLcdHD44780::ConvertTagsToCustomChars(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( "%c1", ch );
	ch[0] = (char)2;
	csText.Replace( "%c2", ch );
	ch[0] = (char)3;
	csText.Replace( "%c3", ch );
	ch[0] = (char)4;
	csText.Replace( "%c4", ch );
	ch[0] = (char)5;
	csText.Replace( "%c5", ch );
	ch[0] = (char)6;
	csText.Replace( "%c6", ch );
	ch[0] = (char)7;
	csText.Replace( "%c7", ch );
	ch[0] = (char)8;
	csText.Replace( "%c8", ch );

	return csText;
}

LPCTSTR CLcdHD44780::ConvertCustomCharsToTags(CString &csText)
{
	char ch[2];
	ch[1] = '\0';
	ch[0] = (char)1;
	csText.Replace( ch, "%c1" );
	ch[0] = (char)2;
	csText.Replace( ch, "%c2" );
	ch[0] = (char)3;
	csText.Replace( ch, "%c3" );
	ch[0] = (char)4;
	csText.Replace( ch, "%c4" );
	ch[0] = (char)5;
	csText.Replace( ch, "%c5" );
	ch[0] = (char)6;
	csText.Replace( ch, "%c6" );
	ch[0] = (char)7;
	csText.Replace( ch, "%c7" );
	ch[0] = (char)8;
	csText.Replace( ch, "%c8" );

	return csText;
}

void CLcdHD44780::WriteData(unsigned char displayID, unsigned char flags, unsigned char ch)
{
	if (!m_bOpen && !m_bInit) // MZ, Mai 05 2k
		return;

	if (!m_pcDev || !m_pcDev->IsOpen()) {
		return;
	}

	m_pcDev->senddata(displayID, flags, ch);

	// @todo check if an additional delay here helps or not since all actions take at least 40us to execute
	/*
	if (m_pcDev) 
		m_pcDev->uPause(g_44780Cfg.iDelayShort);
	*/
}

/////////////////////////////////////////////////////////////////
// Sets a custom character from 0-7...
//
// For input, values > 0 mean "on" and values <= 0 are "off".
//
// The input is just an array of characters...
//
void CLcdHD44780::SetChar(int n, char *dat)
{
	int row, col;
	int letter;

	if (n < 0 || n > 7)
		return;
	if (!dat) 
		return;

	WriteData(0, RS_INSTR, 64 | n*8);

	for(row=0; row<g_44780Cfg.byCellH; row++) {
		letter = 0;
		for(col=0; col<g_44780Cfg.byCellW; col++) {
			letter <<= 1;
			letter |= (dat[(row*g_44780Cfg.byCellW) + col] > 0);
		}
		WriteData(0, RS_DATA, letter);
	}
}

int	CLcdHD44780::GetRows()		// MZ, June 27
{
	return g_44780Cfg.iRows;
}

int	CLcdHD44780::GetColumns()	// MZ, June 27
{
	return g_44780Cfg.iCols;
}

CDevParallel* CLcdHD44780::GetParallelDevice()
{
	return m_pcDev;
}

void CLcdHD44780::HandleKeyPad()
{
	if (m_pcDev) {
		m_pcDev->HandleKeyPad();
	}
}