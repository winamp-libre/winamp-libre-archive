// DlgPageMenu.cpp : implementation file
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgPageMenu.h"
#include "DynaMenus.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern t_DynaMenu	aAllFuncs[];
extern CDynaMenus	g_DynaMenus;
extern CString		g_ConfigPath;

/////////////////////////////////////////////////////////////////////////////
// CDlgPageMenu property page

IMPLEMENT_DYNCREATE(CDlgPageMenu, CPropertyPage)

CDlgPageMenu::CDlgPageMenu() : CPropertyPage(CDlgPageMenu::IDD)
{
	//{{AFX_DATA_INIT(CDlgPageMenu)
	m_MenuCaption = _T("");
	//}}AFX_DATA_INIT
}

CDlgPageMenu::~CDlgPageMenu()
{
}

void CDlgPageMenu::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPageMenu)
	DDX_Control(pDX, IDC_TREEMENU, m_MenuTree);
	DDX_Control(pDX, IDC_BUT_DELETE, m_DeleteButton);
	DDX_Control(pDX, IDC_BUT_INSERT, m_InsertButton);
	DDX_Control(pDX, IDC_BUT_INSERTSUB, m_InsertChildButton);
	DDX_Control(pDX, IDC_COMBO_FUNCS, m_ComboFuncs);
	DDX_Text(pDX, IDC_EDIT_CAPTION, m_MenuCaption);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPageMenu, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgPageMenu)
	ON_BN_CLICKED(IDC_BUT_INSERT, OnInsertItem)
	ON_BN_CLICKED(IDC_BUT_INSERTSUB, OnInsertSubItem)
	ON_CBN_SELCHANGE(IDC_COMBO_FUNCS, OnSelchangeComboFuncs)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREEMENU, OnSelchangedTreemenu)
	ON_BN_CLICKED(IDC_MENUAPPLY, OnMenuapply)
	ON_BN_CLICKED(IDC_BUT_DELETE, OnButDelete)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPageMenu message handlers

BOOL CDlgPageMenu::OnApply() 
{
	g_DynaMenus.BuildFromTreeview(&m_MenuTree);

	CFile thefile;
	thefile.Open(g_ConfigPath + MENU_FILE,CFile::modeCreate);
	thefile.Close();
	thefile.Open(g_ConfigPath + MENU_FILE,CFile::modeWrite);
	CArchive archive(&thefile, CArchive::store);
	m_MenuTree.Serialize(archive);
	archive.Close();
	thefile.Close();

	return CPropertyPage::OnApply();
}

BOOL CDlgPageMenu::OnInitDialog() 
{
	HTREEITEM	tmp;
	int			idx;

	CPropertyPage::OnInitDialog();

	CFile thefile;
	if (thefile.Open(g_ConfigPath + MENU_FILE,CFile::modeRead))
	{
		CArchive archive(&thefile, CArchive::load);
		m_MenuTree.DeleteAllItems();
		m_MenuTree.Serialize(archive);
		archive.Close();
		thefile.Close();
	}
	
	bool bInsertRoot = false;
	HTREEITEM hRoot = m_MenuTree.GetRootItem();
    int nRootData = 0;
    if( hRoot != NULL )
	{
	  nRootData = m_MenuTree.GetItemData( hRoot );
	}
	if( hRoot == NULL ||
		nRootData != -2 )
	{
		MessageBox( "Invalid or no menu data found. New menu created." );
		m_MenuTree.DeleteAllItems();
		tmp = m_MenuTree.InsertItem( MENU_ROOT_TEXT, 0, 0, TVI_ROOT, TVI_LAST);
		m_MenuTree.SetItemData(tmp, -2);
	}
		
	// Fill in combo box with available functions
	for (int i = 0; aAllFuncs[i].Id != 0; i++)
	{
		idx = m_ComboFuncs.AddString(aAllFuncs[i].Label);
		m_ComboFuncs.SetItemData(idx, aAllFuncs[i].Id);
	}

	UpdateData(FALSE);

	return TRUE;
}

void CDlgPageMenu::OnInsertItem() 
{
	HTREEITEM	sel;
	HTREEITEM	parent;

	sel = m_MenuTree.GetSelectedItem();
	parent = m_MenuTree.GetParentItem(sel);
	sel = m_MenuTree.InsertItem("NewMenuItem", 0, 0, parent, sel);
	m_MenuTree.SetItemData(sel, -1);
	m_MenuTree.EnsureVisible( sel );
    m_MenuTree.SelectItem( sel );
	m_MenuTree.SetFocus();
	this->SetModified();
}

void CDlgPageMenu::OnInsertSubItem() 
{
	HTREEITEM	sel;
	
	sel = m_MenuTree.GetSelectedItem();
	sel = m_MenuTree.InsertItem("NewMenuItem", 0, 0, sel, TVI_LAST);
	m_MenuTree.SetItemData(sel, -1);
    m_MenuTree.EnsureVisible( sel );
    m_MenuTree.SelectItem( sel );
    m_MenuTree.SetFocus();
	this->SetModified();
}

void CDlgPageMenu::OnSelchangeComboFuncs() 
{
	HTREEITEM	sel;
    HTREEITEM	root;

	sel = m_MenuTree.GetSelectedItem();
    root = m_MenuTree.GetRootItem();
	if( sel == root )
	{
    	m_ComboFuncs.SelectString( -1, aAllFuncs[0].Label );
		return;
	}
	else
	{
	//	m_ComboFuncs.SetCurSel( 1 );
	}
	
	m_ComboFuncs.GetWindowText(m_MenuCaption);
	UpdateData(FALSE);
}

void CDlgPageMenu::OnSelchangedTreemenu(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	HTREEITEM	sel;
	int			FuncID, idx;
	
	sel = m_MenuTree.GetSelectedItem();
	m_MenuCaption = m_MenuTree.GetItemText(sel);
	FuncID = m_MenuTree.GetItemData(sel);


	for (int i = 0; aAllFuncs[i].Id != 0; i++)
	{
		if (aAllFuncs[i].Id == FuncID)
			break;
	}	

	idx = m_ComboFuncs.FindStringExact(0, aAllFuncs[i].Label);
	m_ComboFuncs.SetCurSel(idx);
	UpdateData(FALSE);

	if (FuncID == -1 || FuncID == -2)
		m_InsertChildButton.EnableWindow(true);
	else
		m_InsertChildButton.EnableWindow(false);

	if( FuncID == -2 )
	{
		m_ComboFuncs.SelectString( -1, aAllFuncs[0].Label );
		m_ComboFuncs.EnableWindow( false );
	}
	else
		m_ComboFuncs.EnableWindow( true );



	HTREEITEM first;
	first = m_MenuTree.GetParentItem(sel);
	if (first == NULL)
	{
		m_InsertButton.EnableWindow(FALSE);
		m_DeleteButton.EnableWindow(FALSE);
	}
	else
	{
		m_InsertButton.EnableWindow(TRUE);
		m_DeleteButton.EnableWindow(TRUE);
	}


	if (pResult)
		*pResult = 0;
}

void CDlgPageMenu::OnMenuapply() 
{
	HTREEITEM	sel;
	int			idx;
	int			FuncID;

	UpdateData(TRUE);
	sel = m_MenuTree.GetSelectedItem();
	m_MenuTree.SetItemText(sel, m_MenuCaption.GetBuffer(1));
	idx = m_ComboFuncs.GetCurSel();
	FuncID = m_ComboFuncs.GetItemData(idx);
	m_MenuTree.SetItemData(sel, FuncID);
	m_MenuCaption.ReleaseBuffer();
	UpdateData(FALSE);
	OnSelchangedTreemenu(NULL, NULL);
	this->SetModified();
}

void CDlgPageMenu::OnButDelete() 
{
	HTREEITEM sel;
	HTREEITEM first;
    

	sel = m_MenuTree.GetSelectedItem();
	first = m_MenuTree.GetParentItem(sel);
	
	if (first != NULL)
	{
		m_MenuTree.DeleteItem(sel);
    	this->SetModified();
	}


	m_MenuTree.SetFocus();
}
