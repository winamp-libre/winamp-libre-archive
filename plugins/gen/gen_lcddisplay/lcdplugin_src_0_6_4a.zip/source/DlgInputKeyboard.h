#if !defined(AFX_DLGINPUTKEYBOARD_H__E524D0B5_5119_4163_BA5D_95D1823C07F0__INCLUDED_)
#define AFX_DLGINPUTKEYBOARD_H__E524D0B5_5119_4163_BA5D_95D1823C07F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgInputKeyboard.h : header file
//

#include "DlgInput.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgInputKeyboard dialog

class CDlgInputKeyboard : public CDlgInput
{
	DECLARE_DYNCREATE(CDlgInputKeyboard)

// Construction
public:
	CDlgInputKeyboard();
	~CDlgInputKeyboard();

// Dialog Data
	//{{AFX_DATA(CDlgInputKeyboard)
	enum { IDD = IDD_INPUT_KEYBOARD };
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDlgInputKeyboard)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual void RefreshList();

	// Generated message map functions
	//{{AFX_MSG(CDlgInputKeyboard)
	virtual BOOL OnInitDialog();
	afx_msg void OnAdd();
	afx_msg void OnDelete();
	afx_msg void OnEdit();
	afx_msg void OnDblclkListKb(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGINPUTKEYBOARD_H__E524D0B5_5119_4163_BA5D_95D1823C07F0__INCLUDED_)
