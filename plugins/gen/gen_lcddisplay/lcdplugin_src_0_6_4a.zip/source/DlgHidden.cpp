// DlgHidden.cpp : implementation file
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgHidden.h"
#include "DynaMenus.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CDynaMenus g_DynaMenus;
extern CString	  g_ConfigPath;


/////////////////////////////////////////////////////////////////////////////
// CDlgHidden dialog


CDlgHidden::CDlgHidden(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgHidden::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgHidden)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlgHidden::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgHidden)
	DDX_Control(pDX, IDC_TREE1, m_Tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgHidden, CDialog)
	//{{AFX_MSG_MAP(CDlgHidden)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgHidden message handlers

BOOL CDlgHidden::OnInitDialog() 
{
	TRACE("CDlgHidden::OnInitDialog() : Begin");
	CDialog::OnInitDialog();
	
	HTREEITEM tmp;

	CFile thefile;
	if (thefile.Open(g_ConfigPath + MENU_FILE,CFile::modeRead))
	{
		TRACE("CDlgHidden::OnInitDialog() : Dynamenu file found. Loading...");
		CArchive archive(&thefile, CArchive::load);
		m_Tree.DeleteAllItems();
		m_Tree.Serialize(archive);
		archive.Close();
		thefile.Close();
		TRACE("CDlgHidden::OnInitDialog() : Dynamenu file Loaded");
	}
	else
	{
		TRACE("CDlgHidden::OnInitDialog() : Dynamenu file NOT found");
		tmp = m_Tree.InsertItem("Main LCD Menu", 0, 0, TVI_ROOT, TVI_LAST);
		m_Tree.SetItemData(tmp, -1);
	}

	TRACE("CDlgHidden::OnInitDialog() : Translating to Dynamenu Class");
	g_DynaMenus.BuildFromTreeview(&m_Tree);
	this->DestroyWindow();
	TRACE("CDlgHidden::OnInitDialog() : End");
	return TRUE;
}
