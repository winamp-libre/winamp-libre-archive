/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2000-2003 Frank Verhamme. All Rights Reserved.
//
//  This file is part of the WinAmp Serial LCD Display Plugin.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
/////////////////////////////////////////////////////////////////////////////
//
// LCDMenuFunc.cpp:   LCD display Menue Steuerung
//
/////////////////////////////////////////////////////////////////////////////
// Modifications:
// 24.07.2000 - FVerhamme: first release
// 19.10.2000 - FVerhamme: Change the MenuLine function to read strings from
//                         the rc file
// 01.04.2001 - FVerhamme: Add scrolling in Playlist, Sorting the Playlist
// 2002/01/04 MZ  NULL ptr check in Menu_Select
// 2002/07/07 MZ LCD access with EnterCriticalSection & LeaveCriticalSection
// 2003/01/19 MZ LCD handling improved (locking & releasing, timer functions don't exist anymore)
// 2003/01/23 MZ Included TiTi's version T4 changes (http://www.poulpy.com/lcdplugin/)
// 2003/07/12 MZ Replaced hard coded custom chars in file browser, works now with every display 
//
/////////////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------
// Hier stehen die Funktionen zur Steuerung der Displaymenues
// Diese brauchen i.d.R. nicht mehr ver�ndert zu werden !!
// ----------------------------------------------------------------------------

#include "stdafx.h"
#include "LCDMenuFunc.h"
#include "gen_lcddisplay.h"

#include <stdlib.h>
#include <string.h>
#include <windows.h>

char g_cCBox_Unchecked;
char g_cCBox_Checked;

extern CRITICAL_SECTION critSecLCDWrite;

/* Funktion    : Menue_Enter
 * Beschreibung: Initialisiert das �bergebene Menue
 * Rueckgabe   : TRUE
 * Parameter   : Zeiger auf das anzugeigende Menue,
 *               Zeiger auf die erste Menuezeile,
 *               Anzahl der Menueeintraege
 *               Freigeben von Speicher ? 0 = Nein, 1 = Ja
 */
int Menu_Enter(tCurrMenu* pCurrMenu, tMenuLine* pFirstLine, int iLineCnt, int iFreeMenuOnLeave)
{
  Menu_Leave(pCurrMenu); // Wenn bereits ein Menue vorhanden ist, dann l�schen!
                         // Jetzt mit den neuen Werten neu initialisieren  
  pCurrMenu->pFirstLine = pFirstLine;             // Zeiger auf die erste Menuezeile setzen
  pCurrMenu->iLineCnt = iLineCnt;                 // Anzahl der Menuezeilen �bergeben
  pCurrMenu->iFreeMenuOnLeave = iFreeMenuOnLeave; // Angabe, ob das Menue sp�ter freigegeben werden muss

  Menu_ResetTimer(pCurrMenu);

  return 1;
}

/* Funktion    : Menue_Leave
 * Beschreibung: Pr�ft ob ein Men� vorhanden ist.
 *               Dieses wird dann gel�scht !
 * Rueckgabe   : True
 * Parameter   : Zeiger auf ein Menue
 */
int Menu_Leave(tCurrMenu* pCurrMenu)
{
  // Wenn kein Menu vorhanden ist, dann sofort wieder raus !
  if(!pCurrMenu->pFirstLine)
	  return 0;
  
  // Ansonsten wird das Menue gel�scht
  pCurrMenu->iLineCnt = 0;

  if(pCurrMenu->iFreeMenuOnLeave) 
	  free(pCurrMenu->pFirstLine);

  pCurrMenu->pFirstLine = 0;
  pCurrMenu->iLineSelected = 0;
  
  Menu_ResetTimer(pCurrMenu);

  return 1;  
}

/* Funktion    : Menu_IsActive
 * Beschreibung: Pr�ft ob das �bergebene Menu aktiv ist
 * Rueckgabe   : True oder False
 * Parameter   : Zeiger auf das Menue, das gepr�ft werden soll
 */
int Menu_IsActive(tCurrMenu* pCurrMenu)
{
  if(pCurrMenu->pFirstLine) // Wenn das Menue einen Zeiger auf eine Menuezeile hat
	  return 1;             // ist das Menue aktiv
  else
	  return 0;
}

/* Funktion    : Menue_Down
 * Beschreibung: Aktuelle Menuezeile um eins erh�hen
 * Rueckgabe   : egal
 * Parameter   : Zeiger auf das Menue, das um eins erh�ht werden soll
 */
int Menu_Down(tCurrMenu* pCurrMenu)
{
  pCurrMenu->iLineSelected++;  // aktuelle Zahl um eins erh�hen
  // Wenn die Zahl nun gr��er ist die maximale Menuezeilen, dann setzen wir Zahl auf 0;
  if(pCurrMenu->iLineSelected >= pCurrMenu->iLineCnt)
	  pCurrMenu->iLineSelected = 0;

  Menu_ResetTimer(pCurrMenu);

  return 1;
}

/* Funktion    : Menue_Up
 * Beschreibung: Aktuelle Menuezeile um eins verringern
 * Rueckgabe   : egal
 * Parameter   : Zeiger auf das Menue, in der die Zeile verringert werden soll
 */
int Menu_Up(tCurrMenu* pCurrMenu)
{
  pCurrMenu->iLineSelected--;   //  aktuelle Zahl um eins verringern
  // Wenn die Zahl nun kleiner als 0 ist, so setzen wir die Zahl auf den letzen Eintrag :-)
  if(pCurrMenu->iLineSelected < 0)
	  pCurrMenu->iLineSelected = pCurrMenu->iLineCnt-1;

  Menu_ResetTimer(pCurrMenu);

  return 1;
}

/* Funktion    : Menue_Select
 * Beschreibung: Ausf�hren der Aktion, die in der ausgew�lte Punkt vorsieht
 * Rueckgabe   : egal
 * Parameter   : Zeiger auf das Menue
 */
int Menu_Select(tCurrMenu* pCurrMenu)
{
  // Auslesen der Zahl aus iLineSelected des �bergebenen Menues.
  // Aufrufen der Funktion !
	if (pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].pActionFunc == NULL) {		// function check added, MZ 2001/12/30
		Menu_Leave(pCurrMenu);
	} else {
		pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].pActionFunc(pCurrMenu);
	}
  
	return 1;
}

/* Funktion    : Menu_Update
 * Beschreibung: Displays the provided menu  / Anzeigen des �bergebenen Menues
 * Rueckgabe   : don't care / egal
 * Parameter   : Pointer to menu to display  / Zeiger auf das anzuzeigende Menue
 */
int Menu_Update(tCurrMenu* pCurrMenu)
{
	if(!pCurrMenu->pFirstLine) // user wants to go out again / Benutzer will mit % wieder raus !
	{
		// clear display
		EnterCriticalSection(&critSecLCDWrite);
		g_LCD->Clear();
		LeaveCriticalSection(&critSecLCDWrite);
		// start refresh timer - Weiter mit Standardanzeige
		// Hier werden wieder die benutzerdefinierten Zeichen geladen
		char *p;
		char szBuffer[10000];
		GetPrivateProfileString( SECTION_NAME, "CustomChars", "", szBuffer,
								sizeof(szBuffer), g_szIniFile);
		char *p2 = szBuffer, *pEnd = p2 + strlen(p2);
		int  i = 0, iSize = strlen(szBuffer);
		p = strtok(p2, "|");
		while (p != NULL)
		{
		  if (i == MAX_CUSTOM_CHAR)
			break;
		  g_Config.carrCustomChar[i++].Set(p);
		  p2 += strlen(p) + 1;
		  if (p2 >= pEnd)
  			break;
		p = strtok(p2, "|");
		}
		SetCustomChars();
		// Jetzt sind die benutzerdefinierten Zeichen wieder da

		pCurrMenu->iInitComplete = 0;
		// MZ 2003/01/19  replaced timer functions with threads and put output handling in CLCDFactory
	    g_LCDFactory.EnableOutput(TRUE);

		// restore SA / Spectrum Analyser auf den Wert setzen, der beim Betreten des Menue vorhanden war
		g_Spectrum_Analyser.in_menu = 0;
		g_Spectrum_Analyser.char_loaded = 0;
	}
	else
	{
		char cArrow[10]      = "%c1";
		char ListElement[10] = "%c3";
		char Slider[10]      = "%c8";

		char CBoxChecked[4]   = "%c5";
		char CBoxUnchecked[4] = "%c4";
		
		g_Spectrum_Analyser.in_menu = 1;
					
		// get full control over LCD  MZ 2003/01/19
		g_LCDFactory.EnableOutput(FALSE);

		EnterCriticalSection(&critSecLCDWrite);

		if (!pCurrMenu->iInitComplete) // pressed for the first time?
		{
			// define first 5 custom chars for menu
			char *p;
			char szBuffer[] = "8,12,14,15,15,14,12,8|4,14,21,4,4,21,14,4|17,17,17,17,17,17,17,17|31,17,17,17,17,17,17,31|31,17,27,21,21,27,17,31|0,0,0,0,0,0,0,0|0,0,0,0,0,0,0,0|0,0,0,0,0,0,0,0";
			char *p2 = szBuffer, *pEnd = p2 + strlen(p2);
			int i=0, iSize = strlen(szBuffer);
			p = strtok(p2, "|");
			while (p != NULL)
			{
				if(i == MAX_CUSTOM_CHAR)
					break;
				g_Config.carrMenueChar[i++].Set(p);
				p2 += strlen(p) + 1;
				if(p2 >= pEnd)
					break;
				p = strtok(p2, "|");
			}
			SetMenueChars();

			g_LCD->ConvertTextToLCDCharset(CBoxChecked);
			g_LCD->ConvertTextToLCDCharset(CBoxUnchecked);
			g_cCBox_Checked = CBoxChecked[0];
			g_cCBox_Unchecked = CBoxUnchecked[0];

			pCurrMenu->iInitComplete = 1;	// Status merken
			

		}
		// draw menu in its current state
		int iMaxLcdLines = g_LCD->GetRows();

		if (iMaxLcdLines > pCurrMenu->iLineCnt) 
		  iMaxLcdLines = pCurrMenu->iLineCnt;

		for (int iLcdLine = 0; iLcdLine < iMaxLcdLines; iLcdLine++)
		{
			int iMenuLine, iCharPos = 0;
			char szBuffer[512], *pChar;

			iMenuLine = pCurrMenu->iLineSelected + iLcdLine;
			if (iMenuLine >= pCurrMenu->iLineCnt)
				iMenuLine -= pCurrMenu->iLineCnt;

			if (!iLcdLine) // display an arrow in the the first line, defined as custom char 1
			{
				g_LCD->SetPosition (1,iLcdLine+1);
				g_LCD->ConvertTextToLCDCharset(cArrow);
				g_LCD->Write(cArrow);
			}

			//----------------------------------------------
			// Display menu or list after column 2 / Ab Spalte 2 das Menue oder die Liste ausgeben
			//----------------------------------------------
			g_LCD->SetPosition (2,iLcdLine+1);

			if(pCurrMenu->pFirstLine[iMenuLine].idText) {
				LoadString(g_Plugin.hDllInstance, pCurrMenu->pFirstLine[iMenuLine].idText, szBuffer, sizeof(szBuffer));
			} else {
				strcpy(szBuffer, pCurrMenu->pFirstLine[iMenuLine].cTextBuff);
			}

			//g_LCD->ConvertTextToLCDCharset(szBuffer);

			pChar = szBuffer;
			pChar[g_LCD->GetColumns() - 1 ] = 0;   //WG:  nur -1, damit bei kurzen Menus der Slider weggelassen werden kann
			g_LCD->Write(pChar);
		}

		//-------------------------------------------------
		// display slider on right side of display
		//-------------------------------------------------
		int LineCnt = g_LCD->GetRows(),
		PixelLineCnt = 8,
		CurrentPixelLine = 0;

		if (pCurrMenu->iLineCnt-1 > LineCnt) {    //WG:  Slider nur anzeigen wenn Menu l�nger als LCD
			if(pCurrMenu->iLineCnt-1 != 0)
				CurrentPixelLine = (int)((double)pCurrMenu->iLineSelected / (double)(pCurrMenu->iLineCnt-1) * (double)(LineCnt*PixelLineCnt-1));
			
			int LineNo = (int)(CurrentPixelLine / PixelLineCnt),
					PixelLineNo = (int)(CurrentPixelLine % PixelLineCnt);

			// define custom char for slider
			char * p, *tmp, szBuffer[24];
			p = tmp = szBuffer;
			for (int i=0; i < PixelLineCnt; i++)
			{
				if (i == PixelLineNo)
				{
					strncpy(tmp, "31,", 3);
					tmp += 3;
				}
				else
				{
					strncpy(tmp, "17,", 3);
					tmp += 3;
				}
			}
			szBuffer[23] = 0;

			g_Config.carrMenueChar[7].Set(p); //Sonderzeichen in Struktur einpflegen
		
			if (g_LCD != NULL)
	  			g_LCD->CreateCustomChar(7, g_Config.carrMenueChar[7]); // und erstellen

			// Jetzt die Men�sonderzeichen einf�gen
			int y = 1; //Slider kann erst in Zeile 2 beginnen
			for (i = 0; i < LineCnt; i++)
			{
				if (i == LineNo)
				{
					g_LCD->SetPosition(g_LCD->GetColumns(), y+i);
					g_LCD->ConvertTextToLCDCharset(Slider);
					g_LCD->Write(Slider);
				}
				else
				{
					g_LCD->SetPosition(g_LCD->GetColumns(), y+i);
					g_LCD->ConvertTextToLCDCharset(ListElement);
					g_LCD->Write(ListElement);
				}
			}
		}

		LeaveCriticalSection(&critSecLCDWrite);

	}
	return 1;
}


//----------------------------------
// Hilfspointer zur �bergabe des aktuellen Menu
// -----------------------------------
static tCurrMenu* pCurrMenuHlp = 0;

// ---------------------------------------
// Reset Scroll Timer fuer Menu
// ---------------------------------------
void Menu_ResetTimer(tCurrMenu* pCurrMenu)
{
  int iTextLength = 0, iDisplayLength =0;
  char csText[256];
  
  // kill 1st and 2nd timer
  ::KillTimer( NULL, g_uiMenuTimer1 );
  ::KillTimer( NULL, g_uiMenuTimer2 );
  pCurrMenuHlp = 0;

  //Scroll Position zuruecksetzen
  pCurrMenu->iScrollingPos = 0;

  if(pCurrMenu->pFirstLine)
  {  
    if(pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].idText)
    {
      LoadString(g_Plugin.hDllInstance, pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].idText, csText, sizeof(csText));
    }
    else
	    strcpy(csText, pCurrMenu->pFirstLine[pCurrMenu->iLineSelected].cTextBuff);

    iDisplayLength = g_LCD->GetColumns() - 2; // 2 fixed Charaters
    iTextLength = strlen(csText);

    if(iTextLength > iDisplayLength)
    {
      // start 1st timer, intervall = 1000 ms
      pCurrMenuHlp = pCurrMenu;
      g_uiMenuTimer1 = SetTimer(NULL, NULL, 1000,	(TIMERPROC)MenuScrollTimer1);
    }
  }
}

// ---------------------------------------
// ScrollFunktion fuer die erste Menuzeile
// ---------------------------------------
VOID CALLBACK MenuScrollTimer1( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
  // kill 1st timer
  ::KillTimer( NULL, g_uiMenuTimer1 );

  // start 2nd timer, (intervall = 200ms)
  g_uiMenuTimer2 = SetTimer(NULL, NULL, g_Config.iScrollTimeStart + 
				(g_Config.byScrollSteps - g_Config.byScrollSpeed + 1) * g_Config.iScrollTimeStep,	(TIMERPROC)MenuScrollTimer2);
}


VOID CALLBACK MenuScrollTimer2( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{

	CString csTempEnd=g_Config.szScrollSeparator2;   //( "�~ " );   //Trennzeichen beim Scrollen - TODO: eigenes
		// '~ ' ergibt kleinen '-> ' auf LCD (nur auf echtem LCDs [zumindest bei Hitachi..], bei Onscreen Sim. wird ein graues K�stchen angezeigt.

	int iDisplayLength;
	//static int iDisplayLength = g_LCD->GetColumns() - 2;
	static int LineCnt = g_LCD->GetRows();
  if (pCurrMenuHlp->iLineCnt > LineCnt) {    //WG:  Slider nur anzeigen wenn Menu l�nger als LCD
		iDisplayLength = g_LCD->GetColumns() - 2;
	} else {
		iDisplayLength = g_LCD->GetColumns() - 1;
	}

  if(pCurrMenuHlp)
  {
    CString csText, csTemp;

    pCurrMenuHlp->iScrollingPos++;
    if(pCurrMenuHlp->pFirstLine[pCurrMenuHlp->iLineSelected].idText)
    {
      csText.LoadString(pCurrMenuHlp->pFirstLine[pCurrMenuHlp->iLineSelected].idText);
    }
    else
	    csText = pCurrMenuHlp->pFirstLine[pCurrMenuHlp->iLineSelected].cTextBuff;

		if (csText.GetLength() > iDisplayLength)
			csText += csTempEnd; //WG:  Damit man wei�, da� der Text noch weiter geht.. 
    // draw menu line
    csTemp = csText.Mid(pCurrMenuHlp->iScrollingPos, iDisplayLength);

    if (csTemp.GetLength() < iDisplayLength)
    {
      int iRest = iDisplayLength - (csText.GetLength()- pCurrMenuHlp->iScrollingPos);
      if (iRest > 0)
        csTemp += csText.Left(iRest);
    }

    g_LCD->SetPosition(2,1);
    g_LCD->Write(csTemp);

    // Ist die Zeile durchgescrollt
    if(pCurrMenuHlp->iScrollingPos >= csText.GetLength())
    {
      // kill 2nd timer
      ::KillTimer( NULL, g_uiMenuTimer2 );
      pCurrMenuHlp->iScrollingPos = 0;

      // start 1st timer, intervall = 3000ms
      g_uiMenuTimer1 = SetTimer( NULL, NULL, 3000, (TIMERPROC)MenuScrollTimer1);
      
    }
  }
}

