// InputParallel.h: interface for the CInputParallel class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INPUTPARALLEL_H__BED8A67D_F73E_405B_B3C3_58AF4AF3D135__INCLUDED_)
#define AFX_INPUTPARALLEL_H__BED8A67D_F73E_405B_B3C3_58AF4AF3D135__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "InputLCD.h"

class CInputParallel : public CInputLCD  
{
public:
	CInputParallel();
	virtual ~CInputParallel();

// Overrides
public:
	virtual BOOL ReadConfig(LPCSTR lpIniFile);
	virtual BOOL WriteConfig(LPCSTR lpIniFile);
	virtual BOOL InitDevice();
};

#endif // !defined(AFX_INPUTPARALLEL_H__BED8A67D_F73E_405B_B3C3_58AF4AF3D135__INCLUDED_)
