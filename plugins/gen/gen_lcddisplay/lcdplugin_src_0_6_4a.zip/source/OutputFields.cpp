/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// COutputFieldHandler.cpp: Collection class and manipulation methods for 
//                   COutputField objects
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/01/19 MZ  Method SwitchSet rewritten (waiting until output thread finished current loop)
// 2003/06/07 MZ  DeleteSet fixed: m_bySets wasn't set to correct value = bug 709848 If you delete a set, they all disappear
//
/////////////////////////////////////////////////////////////////////////////
//
// Todo:
// - synchronize array access so that output can be enabled while in cfg mode
// - use a map for the sets
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "OutputFields.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COutputFieldHandler::COutputFieldHandler()
{
	m_bySets = 0;
	m_byCurrSet = 0;
}

COutputFieldHandler::~COutputFieldHandler()
{
	Clear();
}

void COutputFieldHandler::Clear()
{
    // free memory
    for (int iField = 0; iField < m_cptrarrField.GetSize(); iField++) 
    {
        delete (COutputField *)m_cptrarrField.GetAt(iField);
    }
    m_cptrarrField.RemoveAll();
}

void COutputFieldHandler::DeleteSet(BYTE byNbr)
{
	COutputField *pcField;

	// recount set #, don't trust byNbr parameter (couldn't exist...)
	m_bySets = 0;

    for (int iField = 0; iField < m_cptrarrField.GetSize(); iField++) 
    {
        pcField = (COutputField *)m_cptrarrField.GetAt(iField);
		if (pcField->m_bySet == byNbr)
		{
			m_cptrarrField.RemoveAt(iField);
			delete pcField;
			iField--;
			continue;
		}
		else if (pcField->m_bySet > byNbr)
		{	// adjust fields with a higher set number
			pcField->m_bySet--;
		}

		m_bySets = max(m_bySets, pcField->m_bySet+1);
    }
}

void COutputFieldHandler::ClearSet(BYTE byNbr)
{
	COutputField *pcField;

    for (int iField = 0; iField < m_cptrarrField.GetSize(); iField++) 
    {
        pcField = (COutputField *)m_cptrarrField.GetAt(iField);
		if (pcField->m_bySet == byNbr)
		{
			m_cptrarrField.RemoveAt(iField);
			delete pcField;
			iField--;
		}
    }
}


void COutputFieldHandler::Init()
{
    for (int iField = 0; iField < m_cptrarrField.GetSize(); iField++) 
    {
        COutputField *pcField = (COutputField *)m_cptrarrField.GetAt(iField);

        pcField->m_iType = 0;
        pcField->m_bUpdate = TRUE;
        pcField->m_iScrollIndex = 0;
		pcField->m_bScrollForwards = TRUE; //added by James Maher

        if (pcField->m_csText.IsEmpty())
            continue;

        if (pcField->m_csText.Find(SONGTITLE_TAG) != -1)
            pcField->m_iType = pcField->m_iType | SONG_TITLE;

        if (pcField->m_csText.Find(PLAYBACKSTATUS_TAG) != -1)
            pcField->m_iType = pcField->m_iType | PLAYBACK_STATUS;

        if (pcField->m_csText.Find(PLAYLISTPOS_TAG) != -1)
            pcField->m_iType = pcField->m_iType | PLAYLIST_POS;

        if (pcField->m_csText.Find(PLAYLISTLENGTH_TAG) != -1)
            pcField->m_iType = pcField->m_iType | PLAYLIST_LENGTH;

        if (pcField->m_csText.Find(SONGLEN_TAG) != -1)
            pcField->m_iType = pcField->m_iType | SONG_LENGTH;

        if (pcField->m_csText.Find(SONGPOS_TAG) != -1)
            pcField->m_iType = pcField->m_iType | SONG_POS;

        if (pcField->m_csText.Find(CHANNELS_TAG) != -1)
            pcField->m_iType = pcField->m_iType | CHANNELS;

        if (pcField->m_csText.Find(SAMPLERATE_TAG) != -1)
            pcField->m_iType = pcField->m_iType | SAMPLE_RATE;

        if (pcField->m_csText.Find(BITRATE_TAG) != -1)
            pcField->m_iType = pcField->m_iType | BIT_RATE;

        if (pcField->m_csText.Find(ID3_ARTIST_TAG) != -1)
            pcField->m_iType = pcField->m_iType | ID3_ARTIST;

        if (pcField->m_csText.Find(ID3_TITLE_TAG) != -1)
            pcField->m_iType = pcField->m_iType | ID3_TITLE;

        if (pcField->m_csText.Find(ID3_ALBUM_TAG) != -1)
            pcField->m_iType = pcField->m_iType | ID3_ALBUM;

        if (pcField->m_csText.Find(ID3_YEAR_TAG) != -1)
            pcField->m_iType = pcField->m_iType | ID3_YEAR;

        if (pcField->m_csText.Find(ID3_COMMENT_TAG) != -1)
            pcField->m_iType = pcField->m_iType | ID3_COMMENT;

        if (pcField->m_csText.Find(ID3_GENRE_TAG) != -1)
            pcField->m_iType = pcField->m_iType | ID3_GENRE;

        if (pcField->m_csText.Find(ID3_TRACK_TAG) != -1)
            pcField->m_iType = pcField->m_iType | ID3_TRACK;

        if (pcField->m_csText.Find(VOLUME_TAG) != -1)
            pcField->m_iType = pcField->m_iType | VOLUME;

        if (pcField->m_csText.Find(SYS_TIME_TAG) != -1)
            pcField->m_iType = pcField->m_iType | SYS_TIME;
        //FVerhamm
        if (pcField->m_csText.Find(SHUFFLE_TAG) != -1)
            pcField->m_iType = pcField->m_iType | SHUFFLE;

        if (pcField->m_csText.Find(REPEAT_TAG) != -1)
            pcField->m_iType = pcField->m_iType | REPEAT;
        //FVerhamm

		if (pcField->m_csText.Find(CPUUSAGE_TAG) != -1)
            pcField->m_iType = pcField->m_iType | CPUUSAGE;
		
		if (pcField->m_csText.Find(MEMUSAGE_TAG) != -1)
            pcField->m_iType = pcField->m_iType | MEMUSAGE;

		if (pcField->m_csText.Find(VOLUMEBAR_TAG) != -1)
            pcField->m_iType = pcField->m_iType | VOLUMEBAR;

		if (pcField->m_csText.Find(SLEEPTIMER_TAG) != -1)
			pcField->m_iType = pcField->m_iType | SLEEPTIMER;
    }
}

CString COutputFieldHandler::GetCfgString()
{
    CString csBuffer;
    char    szBuffer[10000];

    for (int iField = 0; iField < m_cptrarrField.GetSize(); iField++) 
    {
        if (iField > 0)
            csBuffer += FIELD_SEPARATOR;

        COutputField *pcField = (COutputField *)m_cptrarrField.GetAt(iField);

        wsprintf( szBuffer, "%d%s%d%s%d%s%s%s%d%s%d%s%d%s%d",
            pcField->m_bActive, LIST_SEPARATOR,
            pcField->m_iRow,    LIST_SEPARATOR,
            pcField->m_iCol,    LIST_SEPARATOR,
            pcField->m_csText,  LIST_SEPARATOR,
            pcField->m_iLength, LIST_SEPARATOR,
            pcField->m_iAlignment, LIST_SEPARATOR,
            pcField->m_ScrollType, LIST_SEPARATOR,
            pcField->m_bySet );
        
        csBuffer += szBuffer;
    }

	return csBuffer;
}

void COutputFieldHandler::LoadFromCfgString(LPSTR lpString)
{
    char    *pszField, *p;
    char    szBuffer[10000];
    int     iCount;
    COutputField *pcField = NULL;


	Clear();

	// get fields
    CStringArray csarrFields;
	pszField = strtok( lpString, FIELD_SEPARATOR );

	while (pszField != NULL)
	{
	  csarrFields.Add( pszField );
	  pszField = strtok( NULL, FIELD_SEPARATOR );
	}

	// parse fields
	for (int i = 0; i < csarrFields.GetSize(); i++)
	{
          strcpy(szBuffer, csarrFields.GetAt(i));

          p = strtok( szBuffer, LIST_SEPARATOR );
          iCount = 0;
          pcField = new COutputField;
	      pcField->m_bySet = 0;			// optional field, must be initialized!

          while (p != NULL)
          {
            switch (iCount)
            {
            case 0 : pcField->m_bActive = atoi(p);  break;
            case 1 : pcField->m_iRow = atoi(p);     break;
            case 2 : pcField->m_iCol = atoi(p);     break;
            case 3 : pcField->m_csText = p;         break;
            case 4 : pcField->m_iLength = atoi(p);  break;
            case 5 : pcField->m_iAlignment = atoi(p); break;
            case 6 : pcField->m_ScrollType = (COutputField::SCROLLING)atoi(p);    break;
			case 7 : pcField->m_bySet = atoi(p);
					 m_bySets = max(m_bySets, pcField->m_bySet+1);
					 break;
            }

            iCount++;
            p = strtok( NULL, LIST_SEPARATOR );
          }

          m_cptrarrField.Add( pcField );     

		pszField = strtok( NULL, FIELD_SEPARATOR );

      }
      
	  Init();
}

int COutputFieldHandler::GetTotalFieldCount()
{
	return m_cptrarrField.GetSize();
}


int COutputFieldHandler::GetFieldCount(BYTE bySet)
{
	int iCount = 0;

    for (int iField = 0; iField < m_cptrarrField.GetSize(); iField++) 
    {
        if (((COutputField *)m_cptrarrField.GetAt(iField))->m_bySet == bySet)
			iCount++;
	}
	return iCount;
}

COutputField * COutputFieldHandler::GetField(int iIndex)
{
	return (COutputField *)m_cptrarrField.GetAt(iIndex);
}


void COutputFieldHandler::Add(COutputField *pcField)
{
	m_cptrarrField.Add(pcField);
	m_bySets = max(m_bySets, pcField->m_bySet+1);
}

BYTE COutputFieldHandler::GetSetCount()
{
	return m_bySets;
}

BYTE COutputFieldHandler::CopySet(BYTE bySet)
{
	BYTE		byNewSet = m_bySets;
	CPtrArray	carrFields;


	// get source fields
	COutputField *pcField = NULL, *pcNewField = NULL;
    for (int iField = 0; iField < m_cptrarrField.GetSize(); iField++) 
    {
		pcField = (COutputField *)m_cptrarrField.GetAt(iField);
        if (pcField->m_bySet == bySet)
		{
			pcNewField = new COutputField(*pcField);

			// TODO: copy field (first implement copy constructor in COutputField!
			// pcNewField = pcField;

			pcNewField->m_bySet = byNewSet;
			carrFields.Add(pcNewField);
		}
	}

	// insert the new set
    for (iField = 0; iField < carrFields.GetSize(); iField++) 
		m_cptrarrField.Add(carrFields.GetAt(iField));

	m_bySets++;
	
	return byNewSet;
}

void COutputFieldHandler::SetCurrentSet(BYTE bySet)
{
	m_byCurrSet = bySet;
	if (m_byCurrSet >= m_bySets)
		m_byCurrSet = m_bySets-1;
}

BYTE COutputFieldHandler::GetCurrentSet()
{
	return m_byCurrSet;
}

BYTE COutputFieldHandler::SwitchSet()
{	
	if (m_bySets <= 1)
		return m_byCurrSet;

	// MZ 2002/01/19 wait until all input and output threads finished the current loop
	if (!AcquireWriteLock(&g_OutputLock)) {
		return m_byCurrSet;
	}

	// now it's safe to change the set

	do {
		m_byCurrSet++;
		if (m_byCurrSet >= m_bySets)
			m_byCurrSet = 0;
	} while (m_byCurrSet == g_Config.iSwitchPause || m_byCurrSet == g_Config.iSwitchStop);
	
	// update all fields, this clears the display
	g_bUpdateAll = TRUE;

	ReleaseWriteLock(&g_OutputLock);

	return m_byCurrSet;
}
