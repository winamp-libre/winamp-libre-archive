// DynaMenus.h: interface for the CDynaMenus class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DYNAMENUS_H__0E5B1890_1FB8_4D21_84E9_9B94CE9924E7__INCLUDED_)
#define AFX_DYNAMENUS_H__0E5B1890_1FB8_4D21_84E9_9B94CE9924E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define MAX_CHILDS 32

typedef struct		s_menuitem {
	struct s_menuitem	*childs[MAX_CHILDS];
	CString				Label;
	int					FuncID;
}					t_menuitem;

class CDynaMenus  
{
public:
	int Init();
	int EnterMenu(tCurrMenu *pCurrMenu, t_menuitem *menu);
	int Read_Config();
	int Write_Config();
	bool BuildFromTreeview(CTreeCtrl *tree);
	t_menuitem *m_MenuStruct;
	CDynaMenus();
	virtual ~CDynaMenus();

private:
	void DelChilds(t_menuitem *menu);

};

#endif // !defined(AFX_DYNAMENUS_H__0E5B1890_1FB8_4D21_84E9_9B94CE9924E7__INCLUDED_)
