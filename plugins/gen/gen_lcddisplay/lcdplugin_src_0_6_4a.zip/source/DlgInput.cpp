/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Base class for input driver configuration dialogs (CDlgInputWinLIRC etc.)
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2003/02/09 MZ  extended input (default/menu/set actions)
// 2003/06/01 MZ  generic edit function added (OnEdit())
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgInput.h"
#include "DlgInputAdd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgInput dialog


CDlgInput::CDlgInput(int id)
	: CPropertyPage(id)
{
	//{{AFX_DATA_INIT(CDlgInput)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CDlgInput::SetModified()
{
	CPropertyPage* pParent = (CPropertyPage*) GetParent();
	pParent->SetModified();
}

void CDlgInput::RefreshList()
{
	POSITION pos;
	CString   key;
	INPUT_BTN *btn;

	m_cList.DeleteAllItems();
	
	// new code
	for (pos = m_mapInput.GetStartPosition(); pos != NULL; ) {
		m_mapInput.GetNextAssoc(pos, key, (void *&)btn);

		int item = m_cList.InsertItem(0, key);
		if (item < 0)
			continue;

		m_cList.SetItem(item, 1, LVIF_TEXT, acts[btn->defAction].name,0,0,0,0);
		m_cList.SetItem(item, 2, LVIF_TEXT, acts[btn->menuAction].name,0,0,0,0);
		m_cList.SetItem(item, 3, LVIF_TEXT, acts[btn->setAction].name,0,0,0,0);
	}

}

void CDlgInput::OnDelete() 
{
	int index = m_cList.GetSelectionMark();

	if(index == -1)	{
		MessageBox("Select a button first.");
		return;
	}

	char key[256];
	m_cList.GetItemText(index,0,key,255);
	
	INPUT_BTN *btn;

	if (m_mapInput.Lookup(key, (void *&)btn)) {

		m_mapInput.RemoveKey(key);
		delete btn;

		m_cList.DeleteItem(index);
		m_cList.SetSelectionMark(index);

		SetModified();
		return;
	}

	MessageBox("Couldn't find that button, doh!");
}

void CDlgInput::OnAdd()
{
	CDlgInputAdd cDlg(this);

	if(cDlg.DoModal() == IDOK) {
		RefreshList();
		SetModified();
	}
}

void CDlgInput::OnEdit()
{
	int index = m_cList.GetSelectionMark();

	if(index == -1) {
		MessageBox("Select a button first.");
		return;
	}

	char key[256];
	m_cList.GetItemText(index,0,key,255);
	
	INPUT_BTN *btn;

	if (!m_mapInput.Lookup(key, (void *&)btn)) {
		MessageBox("Couldn't find that button, doh!");
		return;
	}


	CDlgInputAdd cDlg(this);

	// @HACK but hey, life is short!
	cDlg.m_id = key;
	cDlg.m_btn = btn;

	if(cDlg.DoModal() == IDOK) {
		RefreshList();
		m_cList.AutoSizeColumns();
		SetModified();
	}	
	
}
