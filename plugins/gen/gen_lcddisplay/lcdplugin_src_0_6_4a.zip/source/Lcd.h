/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Lcd.h: interface for the CLcd class.
//
// This is the base interface for the lcd driver implementations.
// Note: The interface is not stable, currently it's only used for Matrix 
//       Orbital LCD's / VFD's. It has to be reviewed if it can be used with
//       other display types!
// 
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2002/01/10 MZ  some clean up, implemented getter methods 
//
// TODO: redefine interface, remove serial display specific stuff (baudrate,
//       open fct)
//

#if !defined(AFX_LCD_H__46EB1810_54CC_11D3_B633_0010A4F5373D__INCLUDED_)
#define AFX_LCD_H__46EB1810_54CC_11D3_B633_0010A4F5373D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CustomChar.h"
#include "SerialDevice.h"
#include "Tbtreed.h"

#define DRV_MORBITAL	"morbital"
#define DRV_MORBITALGLK	"MO_GLK"
#define DRV_HD44780		"HD44780"
#define DRV_HD44780NT	"HD44780NT"
#define DRV_HD667xx	    "HD667xx"
#define DRV_MILFORDBPK  "MILFORD_BPK"
#define DRV_PJRC        "PJRC"

#define DEF_DRIVER		DRV_SIM

//FVerhamm
#define DRV_SIM         "screensim"
//FVerhamm

#define DRV_CRYSTALFONTZ "CrystalFontz"
#define DRV_NORITAKE     "Noritake"
#define DRV_SCOTTEDWARDS "ScottEdwards"
//TSchirme
#define DRV_SED153X      "SED153x"


// helper functions
extern int BuildCharMap(LPCTSTR lpIniSectionName, LPCTSTR lpIniFile, tULongToULong &map);


class CDevParallel;

class CLcd  
{
public:
	static UINT  m_uiBacklightTimer;
	static CLcd  *m_pInstance;

protected:
	short	m_nBackLight, m_nContrast, m_nBrightness;
	BOOL	m_bBlink, m_bOpen, m_bCursor, m_bLineWrap, m_bScroll;
	long	m_lLastError;
	tULongToULong m_charMap;

public:
	CLcd();
	virtual ~CLcd();

/******************************************************************************
Function : SetBacklight
Purpose  : Handles the backlight
Parameters : nSeconds: < 0 : switch off
                         0 : switch on
					   > 0 : switch on for nSeconds
Returns : void
Author  : Markus Zehnder    
******************************************************************************/
	virtual void  SetBacklight(short nSeconds) = 0;
	virtual short GetBacklight() { return m_nBackLight; };
	virtual void  Clear() = 0;
	virtual void  Close() = 0;
	virtual BOOL  IsOpen() { return m_bOpen; };
	virtual void  SetContrast(short nLevel) {};		// not supported by every LCD
	virtual short GetContrast() { return m_nContrast; };		
	virtual void  SetBrightness(short nLevel) {};	// not supported by every LCD
	virtual short GetBrightness() { return m_nBrightness; };	
	virtual void  Home() { SetPosition(1, 1); };
	virtual BOOL  Open() = 0;
	virtual void  SetPosition(short nCol, short nRow) = 0;
	virtual void  Write(LPCSTR lpText) = 0;
	virtual short GetMaxCustomChar() = 0;
	virtual BOOL  CreateCustomChar(short nNumber, CCustomChar &cChar) = 0;
	virtual LPCTSTR ConvertTagsToCustomChars(CString &csText) = 0;
	virtual LPCTSTR ConvertCustomCharsToTags(CString &csText) = 0;
	virtual int		GetRows() = 0;		// MZ, June 27
	virtual int		GetColumns() = 0;	// MZ, June 27
	virtual LPCSTR  ConvertTextToLCDCharset(CString &csText);	// MZ, August 16 2k
	virtual LPCSTR  ConvertTextToLCDCharset(LPSTR lpText);	// MZ, August 16 2k

	// GetSerialDevice & GetParallelDevice are not very OO but due to lack of time...
	// Should be replaced with GetDevice that is a general device object and the concrete 
	// subclasses are either CDevSerial or CDevParallel...
	// But the whole concept has to be revised first, anyway it works that way...
	// (and I'm not in school again where I'd get minus points for it :-)
	virtual CDevSerial* GetSerialDevice() { return NULL; }

	virtual CDevParallel* GetParallelDevice() { return NULL; }

	// handles keypad inputs.
	// should be called once in a while (ca. 10 / sec) from the the same thread that calls
	// the other driver methods and NOT from a separate thread!!!
	virtual void HandleKeyPad() { };	// Note: not used for serial drivers


	// -- Optional methods, used by the plugin but really not required... --
	virtual void  SetScroll(BOOL bOn) {};
	virtual BOOL  GetScroll() { return m_bScroll; };
	virtual void  SetBlink(BOOL On) {};
	virtual BOOL  GetBlink() { return m_bBlink; };
	virtual void  SetLineWrap(BOOL bOn) {};
	virtual BOOL  GetLineWrap() { return m_bLineWrap; };
	virtual void  Cursor(BOOL bOn) {};
	virtual BOOL  IsCursorOn() { return m_bCursor; };
	// -- end of used optional methods --


	// -- Optional methods, not yet used by the plugin... --
	virtual long  GetLastError() { return m_lLastError; };
	virtual void  InitHorizontalBar() {};
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen) {};
	virtual void  InitVerticalBar() {};
	virtual void  VBar(short nCol, short nLength) {};
	virtual void  InitLargeDigit() {};
	virtual void  LargeDigit(short nCol, short nNumber) {};
	// -- end of unused optional methods --


protected:
	// the current backlight timer function is not 100% flexible, but good enough for a single active display...
	virtual void StopBacklightTimer();
	virtual void StartBacklightTimer(int iSeconds);
	static VOID CALLBACK BacklightTimerFunc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );
};

struct LCD_DRIVER
{
	char	*szID;
	char	*szName;
	CLcd	*pcLcd;
	CDialog *pcCfgDlg;
};

#endif // !defined(AFX_LCD_H__46EB1810_54CC_11D3_B633_0010A4F5373D__INCLUDED_)
