//=========================================================================
//
// Copyright � Dundas Software Ltd. 1998, All Rights Reserved
//
// tbtreed.cpp : implementation file
//
//=========================================================================

#include "stdafx.h"

#include "tbtreed.h"                    // class header


//=========================================================================
// Derived tree class: tStringToString
//=========================================================================

tStringToString::~tStringToString()
{
    RemoveAll();
}

void tStringToString::onDeleteKey(void*& keyPtr)
{
    free(keyPtr);
}

void tStringToString::onDeleteData(void*& dataPtr)
{
    free(dataPtr);
}

int tStringToString::onSetKey(void*& keyPtr, void* key)
{
    keyPtr = _strdup((const char*)key);
    return keyPtr ? 1 : 0;
}

int tStringToString::onSetData(void*& dataPtr, void* data)
{
    dataPtr = _strdup((const char*)data);
    return dataPtr ? 1 : 0;
}

tStringToString::relativeKeyValue 
    tStringToString::onCompareKeys(void* key1, void* key2)
{
    return (relativeKeyValue)strcmp((const char*)key1, (const char*)key2);
}

const char* tStringToString::onGetKeyName(void* keyPtr)
{
    return (const char*)keyPtr;
}

int tStringToString::onStore(void* where, POSITION node)
{
    const char* string = (const char*)getKey(node);
    long len = strlen(string) + 1;
    m_bufSize = __max(m_bufSize, len);
    int ok = streamWrite((NQ ostream*)where, (void*)string, len);
    if (ok)
    {
        string = (const char*)getData(node);
        len = strlen(string) + 1;
        m_bufSize = __max(m_bufSize, len);
        ok = streamWrite((NQ ostream*)where, (void*)string, len);
    }
    return ok;
}

int tStringToString::onLoad(void* where)
{
    long kLen, dLen;
    int ok = streamRead((NQ istream*)where, (char*)m_keyBuf, m_bufSize, kLen);
    if (ok)
    {
        ok = streamRead((NQ istream*)where, (char*)m_dataBuf, m_bufSize, dLen);
        if (ok)
            ok = Set((const char*)m_keyBuf, (const char*)m_dataBuf);
    }
    return ok;
}


//==========================================================================
// Derived tree class: tStringToULong
//==========================================================================

tStringToULong::~tStringToULong()
{
    RemoveAll();
}

void tStringToULong::onDeleteKey(void*& keyPtr)
{
    free(keyPtr);
}

void tStringToULong::onDeleteData(void*& dataPtr)
{
}

int tStringToULong::onSetKey(void*& keyPtr, void* key)
{
    keyPtr = _strdup((const char*)key);
    return keyPtr ? 1 : 0;
}

int tStringToULong::onSetData(void*& dataPtr, void* data)
{
    dataPtr = data;
    return 1;
}

tStringToULong::relativeKeyValue 
    tStringToULong::onCompareKeys(void* key1, void* key2)
{
    return (relativeKeyValue)strcmp((const char*)key1, (const char*)key2);
}

const char* tStringToULong::onGetKeyName(void* keyPtr)
{
    return (const char*)keyPtr;
}

int tStringToULong::onStore(void* where, POSITION node)
{
    const char* string = (const char*)getKey(node);
    long len = strlen(string) + 1;
    m_bufSize = __max(m_bufSize, len);
    int ok = streamWrite((NQ ostream*)where, (void*)string, len);
    if (ok)
    {
        unsigned long val = (unsigned long)getData(node);
        len = sizeof(val);
        m_bufSize = __max(m_bufSize, len);
        ok = streamWrite((NQ ostream*)where, (void*)&val, len);
    }
    return ok;
}

int tStringToULong::onLoad(void* where)
{
    long kLen;
    unsigned long data;
    int ok = streamRead((NQ istream*)where, (char*)m_keyBuf, m_bufSize, kLen);
    if (ok)
    {
        ok = streamRead((NQ istream*)where, (char*)&data, sizeof(data));
        if (ok)
            ok = Set((const char*)m_keyBuf, data);
    }
    return ok;
}


//==========================================================================
// Derived tree class: tULongToString
//==========================================================================

tULongToString::~tULongToString()
{
    RemoveAll();
}

void tULongToString::onDeleteKey(void*& keyPtr)
{
}

void tULongToString::onDeleteData(void*& dataPtr)
{
    free(dataPtr);
}

int tULongToString::onSetKey(void*& keyPtr, void* key)
{
    keyPtr = key;
    return 1;
}

int tULongToString::onSetData(void*& dataPtr, void* data)
{
    dataPtr = _strdup((const char*)data);
    return dataPtr ? 1 : 0;
}

tULongToString::relativeKeyValue 
    tULongToString::onCompareKeys(void* key1, void* key2)
{
    if ((unsigned long)key1 < (unsigned long)key2)
        return less;
    if ((unsigned long)key1 == (unsigned long)key2)
        return equal;
    return greater;
}

static char keyName_tULongToString[30];
const char* tULongToString::onGetKeyName(void* keyPtr)
{
    sprintf(keyName_tULongToString, "%lu", (unsigned long)keyPtr);
    return (const char*)keyName_tULongToString;
}

int tULongToString::onStore(void* where, POSITION node)
{
    unsigned long key = (unsigned long)getKey(node);
    int ok = streamWrite((NQ ostream*)where, (void*)&key, sizeof(key));
    if (ok)
    {
        const char* string = (const char*)getData(node);
        long len = strlen(string) + 1;
        m_bufSize = __max(m_bufSize, len);
        ok = streamWrite((NQ ostream*)where, (void*)string, len);
    }
    return ok;
}

int tULongToString::onLoad(void* where)
{
    unsigned long key;
    long dLen;
    int ok = streamRead((NQ istream*)where, (char*)&key, sizeof(key));
    if (ok)
    {
        ok = streamRead((NQ istream*)where, (char*)m_dataBuf, m_bufSize, dLen);
        if (ok)
            ok = Set(key, (const char*)m_dataBuf);
    }
    return ok;
}


//==========================================================================
// Derived tree class: tULongToULong
//==========================================================================

tULongToULong::~tULongToULong()
{
    RemoveAll();
}

void tULongToULong::onDeleteKey(void*& keyPtr)
{
}

void tULongToULong::onDeleteData(void*& dataPtr)
{
}

int tULongToULong::onSetKey(void*& keyPtr, void* key)
{
    keyPtr = key;
    return 1;
}

int tULongToULong::onSetData(void*& dataPtr, void* data)
{
    dataPtr = data;
    return 1;
}

tULongToULong::relativeKeyValue 
    tULongToULong::onCompareKeys(void* key1, void* key2)
{
    if ((unsigned long)key1 < (unsigned long)key2)
        return less;
    if ((unsigned long)key1 == (unsigned long)key2)
        return equal;
    return greater;
}

static char keyName_tULongToULong[30];
const char* tULongToULong::onGetKeyName(void* keyPtr)
{
    sprintf(keyName_tULongToULong, "%lu", (unsigned long)keyPtr);
    return (const char*)keyName_tULongToULong;
}

int tULongToULong::onStore(void* where, POSITION node)
{
    unsigned long key = (unsigned long)getKey(node);
    int ok = streamWrite((NQ ostream*)where, (void*)&key, sizeof(key));
    if (ok)
    {
        unsigned long data = (unsigned long)getData(node);
        ok = streamWrite((NQ ostream*)where, (void*)&data, sizeof(data));
    }
    return ok;
}

int tULongToULong::onLoad(void* where)
{
    unsigned long key, data;
    int ok = streamRead((NQ istream*)where, (char*)&key, sizeof(key));
    if (ok)
    {
        ok = streamRead((NQ istream*)where, (char*)&data, sizeof(data));
        if (ok)
            ok = Set(key, data);
    }
    return ok;
}


//==========================================================================
// Derived tree class: tLongToString
//==========================================================================

tLongToString::~tLongToString()
{
    RemoveAll();
}

void tLongToString::onDeleteKey(void*& keyPtr)
{
}

void tLongToString::onDeleteData(void*& dataPtr)
{
    free(dataPtr);
}

int tLongToString::onSetKey(void*& keyPtr, void* key)
{
    keyPtr = key;
    return 1;
}

int tLongToString::onSetData(void*& dataPtr, void* data)
{
    dataPtr = _strdup((const char*)data);
    return dataPtr ? 1 : 0;
}

tLongToString::relativeKeyValue 
    tLongToString::onCompareKeys(void* key1, void* key2)
{
    if ((long)key1 < (long)key2)
        return less;
    if ((long)key1 == (long)key2)
        return equal;
    return greater;
}

static char keyName_tLongToString[30];
const char* tLongToString::onGetKeyName(void* keyPtr)
{
    sprintf(keyName_tLongToString, "%li", (long)keyPtr);
    return (const char*)keyName_tLongToString;
}

int tLongToString::onStore(void* where, POSITION node)
{
    long key = (long)getKey(node);
    int ok = streamWrite((NQ ostream*)where, (void*)&key, sizeof(key));
    if (ok)
    {
        const char* string = (const char*)getData(node);
        long len = strlen(string) + 1;
        m_bufSize = __max(m_bufSize, len);
        ok = streamWrite((NQ ostream*)where, (void*)string, len);
    }
    return ok;
}

int tLongToString::onLoad(void* where)
{
    long key;
    long dLen;
    int ok = streamRead((NQ istream*)where, (char*)&key, sizeof(key));
    if (ok)
    {
        ok = streamRead((NQ istream*)where, (char*)m_dataBuf, m_bufSize, dLen);
        if (ok)
            ok = Set(key, (const char*)m_dataBuf);
    }
    return ok;
}


//==========================================================================
// Derived tree class: tLongToULong
//==========================================================================

tLongToULong::~tLongToULong()
{
    RemoveAll();
}

void tLongToULong::onDeleteKey(void*& keyPtr)
{
}

void tLongToULong::onDeleteData(void*& dataPtr)
{
}

int tLongToULong::onSetKey(void*& keyPtr, void* key)
{
    keyPtr = key;
    return 1;
}

int tLongToULong::onSetData(void*& dataPtr, void* data)
{
    dataPtr = data;
    return 1;
}

tLongToULong::relativeKeyValue 
    tLongToULong::onCompareKeys(void* key1, void* key2)
{
    if ((long)key1 < (long)key2)
        return less;
    if ((long)key1 == (long)key2)
        return equal;
    return greater;
}

static char keyName_tLongToULong[30];
const char* tLongToULong::onGetKeyName(void* keyPtr)
{
    sprintf(keyName_tLongToULong, "%li", (long)keyPtr);
    return (const char*)keyName_tLongToULong;
}

int tLongToULong::onStore(void* where, POSITION node)
{
    long key = (long)getKey(node);
    int ok = streamWrite((NQ ostream*)where, (void*)&key, sizeof(key));
    if (ok)
    {
        unsigned long data = (unsigned long)getData(node);
        ok = streamWrite((NQ ostream*)where, (void*)&data, sizeof(data));
    }
    return ok;
}

int tLongToULong::onLoad(void* where)
{
    long key;
    unsigned long data;
    int ok = streamRead((NQ istream*)where, (char*)&key, sizeof(key));
    if (ok)
    {
        ok = streamRead((NQ istream*)where, (char*)&data, sizeof(data));
        if (ok)
            ok = Set(key, data);
    }
    return ok;
}
