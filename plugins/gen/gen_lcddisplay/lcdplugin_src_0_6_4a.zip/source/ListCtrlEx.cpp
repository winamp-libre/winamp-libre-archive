/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// ListCtrlEx.cpp:   Extended list control functionality
//
// Collection of different articles from CodeGuru - codeguru.developer.com
// and own enhancements
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ListCtrlEx.h"
#include "InPlaceEdit.h"
#include "InPlaceList.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MINCOLWIDTH 10

#define IDC_IPEDIT 12345

int CListCtrlHelper::AddItem(LPCTSTR strItem, int nItem, int nSubItem, UINT nState, int nImageIndex, long nParam)
{
	LVITEM lvItem;
	lvItem.mask = LVIF_TEXT;
	lvItem.iItem = nItem;
	lvItem.iSubItem = nSubItem;
	lvItem.pszText = (LPTSTR)strItem;

	if (nState != -1)
	{
		lvItem.mask |= LVIF_STATE;
		lvItem.state = nState;
	}
	if (nImageIndex != -1)
	{
		lvItem.mask |= LVIF_IMAGE;
		lvItem.iImage = nImageIndex;
	}
	if (nParam != -1)
	{
		lvItem.mask |= LVIF_PARAM;
		lvItem.lParam = nParam;
	}
	if (nSubItem == 0)
		return m_cListCtrl.InsertItem(&lvItem);
	else
		return m_cListCtrl.SetItem(&lvItem);
}

// AddColumn    - adds column after the right most column
// Returns      - the index of the new column if successful or -1 otherwise.
// sColHeading  - the column's heading
// nWidth       - Width of the column, in pixels. If this parameter is -1, 
//                the column width is the same as previous column
// nFormat      - the alignment of the column. Can be LVCFMT_LEFT,
//                LVCFMT_RIGHT, or LVCFMT_CENTER.
int CListCtrlHelper::AddColumn(LPCTSTR sColHeading, int nWidth /* = -1*/, int nFormat /* = LVCFMT_LEFT*/)
{
        CHeaderCtrl* pHeader = (CHeaderCtrl*)m_cListCtrl.GetDlgItem(0);
        int nColumnCount = pHeader->GetItemCount();

        if( nWidth == -1 )
        {
                // The line below return zero for ICON views
                //nWidth = GetColumnWidth( nColumnCount - 1 );

                // Get the column width of the previous column from header control
                HD_ITEM hd_item;
                hd_item.mask = HDI_WIDTH;               //indicate that we want the width
                pHeader->GetItem( nColumnCount - 1, &hd_item );
                nWidth = hd_item.cxy;
        }
        return m_cListCtrl.InsertColumn( nColumnCount, sColHeading, nFormat, nWidth, nColumnCount );
}

int CListCtrlHelper::GetColumnCount() const
{
     // get the header control
     CHeaderCtrl* pHeader = (CHeaderCtrl*)m_cListCtrl.GetDlgItem(0);
     // return the number of items in it - ie. the number of columns
     return pHeader->GetItemCount();
}


void CListCtrlHelper::AutoSizeColumns(int col /*=-1*/)
{
     // Call this after your list control is filled
     m_cListCtrl.SetRedraw(false);
     int mincol = col < 0 ? 0 : col;
     int maxcol = col < 0 ? GetColumnCount()-1 : col;
     for (col = mincol; col <= maxcol; col++)
	 {
          m_cListCtrl.SetColumnWidth(col,LVSCW_AUTOSIZE);
          int wc1 = m_cListCtrl.GetColumnWidth(col);
          m_cListCtrl.SetColumnWidth(col,LVSCW_AUTOSIZE_USEHEADER);
          int wc2 = m_cListCtrl.GetColumnWidth(col);
          int wc = max(MINCOLWIDTH,max(wc1,wc2));
          m_cListCtrl.SetColumnWidth(col,wc);
     }
     m_cListCtrl.SetRedraw(true);
     m_cListCtrl.Invalidate();
}

BOOL CListCtrlHelper::DeleteAll()
{
	BOOL bRet;
	
	bRet = m_cListCtrl.DeleteAllItems();
	
	for (int i = GetColumnCount()-1; i >= 0; i--)
	{
		bRet &= m_cListCtrl.DeleteColumn(i);
	}
	
	return bRet;
}



/////////////////////////////////////////////////////////////////////////////
// CListCtrlEx

BEGIN_MESSAGE_MAP(CListCtrlEx, CListCtrl)
	//{{AFX_MSG_MAP(CListCtrlEx)
	ON_NOTIFY_REFLECT(LVN_ENDLABELEDIT, OnEndlabelEdit)
	ON_WM_LBUTTONDOWN()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL( )
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListCtrlEx message handlers

CListCtrlEx::~CListCtrlEx()
{
	// release drop down lists, MZ 2001/12/30
   POSITION pos;
   WORD key;
   CStringList *pcarrList;
   
   for( pos = m_cDropListMap.GetStartPosition(); pos != NULL; )
   {
	   m_cDropListMap.GetNextAssoc( pos, key, (CObject*&)pcarrList );

	   delete pcarrList;
   }

}

int CListCtrlEx::AddItem(LPCTSTR strItem, int nItem, int nSubItem, UINT nState, int nImageIndex, long nParam)
{
	CListCtrlHelper	cListHelper(*this);

	return cListHelper.AddItem(strItem, nItem, nSubItem, nState, nImageIndex, nParam );
}

int CListCtrlEx::GetColumnCount()
{
	CListCtrlHelper	cListHelper(*this);

	return cListHelper.GetColumnCount();
}


void CListCtrlEx::AutoSizeColumns(int col /*=-1*/)
{
	CListCtrlHelper	cListHelper(*this);

	cListHelper.AutoSizeColumns( col );
}

BOOL CListCtrlEx::DeleteAll()
{
	CListCtrlHelper	cListHelper(*this);

	return cListHelper.DeleteAll();
}

DWORD CListCtrlEx::GetViewStyle() const
{
	ASSERT(::IsWindow(m_hWnd));
	return (DWORD) (::GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK);
}

DWORD CListCtrlEx::SetViewStyle(DWORD dwNewView)
{
	ASSERT(::IsWindow(m_hWnd));
	return (DWORD) (::SetWindowLong(m_hWnd, GWL_STYLE, (::GetWindowLong(m_hWnd, GWL_STYLE) & ~LVS_TYPEMASK) | dwNewView) & LVS_TYPEMASK);
}

// Available with IE4 Dll => commctl.dll v4.71.1712.3
#ifndef NOLISTVIEWEX

POSITION CListCtrlEx::GetFirstSelectedItemPosition() const
{
	ASSERT(::IsWindow(m_hWnd));
	return (POSITION)(1+GetNextItem(-1, LVIS_SELECTED));
}

int CListCtrlEx::GetNextSelectedItem(POSITION& pos) const
{
	ASSERT(::IsWindow(m_hWnd));
	int nReturn = (int)pos-1;
	pos = (POSITION)(1+GetNextItem(nReturn, LVIS_SELECTED));
	return nReturn;
}

// AddColumn    - adds column after the right most column
// Returns      - the index of the new column if successful or -1 otherwise.
// sColHeading  - the column's heading
// nWidth       - Width of the column, in pixels. If this parameter is -1, 
//                the column width is the same as previous column
// nFormat      - the alignment of the column. Can be LVCFMT_LEFT,
//                LVCFMT_RIGHT, or LVCFMT_CENTER.
int CListCtrlEx::AddColumn(LPCTSTR sColHeading, int nWidth /* = -1*/, int nFormat /* = LVCFMT_LEFT*/)
{
	CListCtrlHelper	cListHelper(*this);

	return cListHelper.AddColumn( sColHeading, nWidth, nFormat );
}

BOOL CListCtrlEx::GetColumnOrderArray(LPINT pnArray, int nCount) const
{
	ASSERT(::IsWindow(m_hWnd));

	if (nCount == -1)
	{
		CHeaderCtrl* pHeader = GetHeaderCtrl();
		if (pHeader != NULL)
			nCount = pHeader->GetItemCount();
	}
	
	if (nCount == -1)
		return FALSE;

	ASSERT(AfxIsValidAddress(pnArray, nCount * sizeof(int)));
	return (BOOL) ::SendMessage(m_hWnd, LVM_GETCOLUMNORDERARRAY, (WPARAM)nCount, (LPARAM)pnArray);
}

BOOL CListCtrlEx::SetColumnOrderArray(int nCount, LPINT pnArray)
{
	ASSERT(::IsWindow(m_hWnd));
	ASSERT(AfxIsValidAddress(pnArray, nCount * sizeof(int), FALSE));
	return (BOOL) ::SendMessage(m_hWnd, LVM_SETCOLUMNORDERARRAY, (WPARAM)nCount, (LPARAM)pnArray);
}

CSize CListCtrlEx::SetIconSpacing(CSize size)
{
	ASSERT(::IsWindow(m_hWnd));
	return CSize((DWORD) ::SendMessage(m_hWnd, LVM_SETICONSPACING, 0, MAKELPARAM(size.cx, size.cy)));
}

CSize CListCtrlEx::SetIconSpacing(int cx, int cy)
{
	ASSERT(::IsWindow(m_hWnd));
	return CSize((DWORD) ::SendMessage(m_hWnd, LVM_SETICONSPACING, 0, MAKELPARAM(cx, cy)));
}

CHeaderCtrl* CListCtrlEx::GetHeaderCtrl() const
{
	ASSERT(::IsWindow(m_hWnd));

	HWND hWnd = (HWND) ::SendMessage(m_hWnd, LVM_GETHEADER, 0, 0L);
	if (hWnd == NULL)
		return NULL;
	else
		return (CHeaderCtrl*) CHeaderCtrl::FromHandle(hWnd);
}

HCURSOR CListCtrlEx::GetHotCursor() const
{
	ASSERT(::IsWindow(m_hWnd));
	return (HCURSOR) ::SendMessage(m_hWnd, LVM_GETHOTCURSOR, 0, 0L);
}

HCURSOR CListCtrlEx::SetHotCursor(HCURSOR hc)
{
	ASSERT(::IsWindow(m_hWnd) && hc != NULL);
	return (HCURSOR) ::SendMessage(m_hWnd, LVM_SETHOTCURSOR, 0, (LPARAM)hc);
}

BOOL CListCtrlEx::GetSubItemRect(int nItem, int nSubItem, int nArea, CRect & rcRef) const
{
	ASSERT(::IsWindow(m_hWnd));
	ASSERT(nArea == LVIR_BOUNDS || nArea == LVIR_ICON || nArea == LVIR_LABEL);

	RECT rect;
	rect.top = nSubItem;
	rect.left = nArea;

	BOOL bReturn = (BOOL) ::SendMessage(m_hWnd, LVM_GETSUBITEMRECT, nItem, (LPARAM) &rect);
	if (bReturn)
		rcRef = rect;
	return bReturn;
}

int CListCtrlEx::GetHotItem() const
{
	ASSERT(::IsWindow(m_hWnd));
	return (int) ::SendMessage(m_hWnd, LVM_GETHOTITEM, 0, 0L);
}

int CListCtrlEx::SetHotItem(int nIndex)
{
	ASSERT(::IsWindow(m_hWnd));
	return (int) ::SendMessage(m_hWnd, LVM_SETHOTITEM, (WPARAM)nIndex, 0L);
}

int CListCtrlEx::GetSelectionMark() const
{
	ASSERT(::IsWindow(m_hWnd));
	return (int) ::SendMessage(m_hWnd, LVM_GETSELECTIONMARK, 0, 0L);
}

int CListCtrlEx::SetSelectionMark(int nIndex)
{
	ASSERT(::IsWindow(m_hWnd));
	return (int) ::SendMessage(m_hWnd, LVM_SETSELECTIONMARK, 0, (LPARAM)nIndex);
}

DWORD CListCtrlEx::GetExtendedStyle() const
{ 
	ASSERT(::IsWindow(m_hWnd)); 
	return (DWORD) ::SendMessage(m_hWnd, LVM_GETEXTENDEDLISTVIEWSTYLE, 0, 0L);
}

DWORD CListCtrlEx::SetExtendedStyle(DWORD dwNewStyle)
{
	ASSERT(::IsWindow(m_hWnd));
	return (DWORD) ::SendMessage(m_hWnd, LVM_SETEXTENDEDLISTVIEWSTYLE, 0, (LPARAM)dwNewStyle);
}

int CListCtrlEx::SubItemHitTest(LPLVHITTESTINFO lpInfo)
{
	ASSERT(::IsWindow(m_hWnd));
	return (int) ::SendMessage(m_hWnd, LVM_SUBITEMHITTEST, 0, (LPARAM)lpInfo);
}

UINT CListCtrlEx::GetNumberOfWorkAreas() const
{
	ASSERT(::IsWindow(m_hWnd));
	UINT nWorkAreas;
	::SendMessage(m_hWnd, LVM_GETNUMBEROFWORKAREAS, 0, (LPARAM)&nWorkAreas);
	return nWorkAreas;
}

void CListCtrlEx::GetWorkAreas(int nWorkAreas, LPRECT lpRect) const
{
	ASSERT(::IsWindow(m_hWnd));
	::SendMessage(m_hWnd, LVM_GETWORKAREAS, (WPARAM)nWorkAreas, (LPARAM)lpRect);
}

void CListCtrlEx::SetWorkAreas(int nWorkAreas, LPRECT lpRect)
{
	ASSERT(::IsWindow(m_hWnd));
	::SendMessage(m_hWnd, LVM_SETWORKAREAS, (WPARAM)nWorkAreas, (LPARAM)lpRect);
}

BOOL CListCtrlEx::SetItemCountEx(int iCount, DWORD dwFlags)
{
	ASSERT(::IsWindow(m_hWnd));
	ASSERT((GetStyle() & LVS_OWNERDATA));	

	return (BOOL) ::SendMessage(m_hWnd, LVM_SETITEMCOUNT, (WPARAM)iCount, (LPARAM)dwFlags);
}

CSize CListCtrlEx::ApproximateViewRect(CSize size, int nCount) const
{
	ASSERT(::IsWindow(m_hWnd));
	return CSize((DWORD) ::SendMessage(m_hWnd, LVM_APPROXIMATEVIEWRECT, nCount, MAKELPARAM(size.cx, size.cy)));
}

BOOL CListCtrlEx::GetBkImage(LVBKIMAGE* plvbkImage) const
{
	ASSERT(::IsWindow(m_hWnd));
	return (BOOL) ::SendMessage(m_hWnd, LVM_GETBKIMAGE, 0, (LPARAM)plvbkImage);
}

BOOL CListCtrlEx::SetBkImage(HBITMAP hbm, BOOL bTile, int xOffsetPercent, int yOffsetPercent)
{
	LVBKIMAGE lv;

	lv.ulFlags = LVBKIF_SOURCE_HBITMAP;
	lv.ulFlags |= (bTile) ? LVBKIF_STYLE_TILE : LVBKIF_STYLE_NORMAL;
	lv.hbm = hbm;
	lv.xOffsetPercent = xOffsetPercent;
	lv.yOffsetPercent = yOffsetPercent;
	return SetBkImage(&lv);
}

BOOL CListCtrlEx::SetBkImage(LPTSTR pszUrl, BOOL bTile, int xOffsetPercent, int yOffsetPercent)
{
	LVBKIMAGE lv;

	lv.ulFlags = LVBKIF_SOURCE_HBITMAP;
	lv.ulFlags |= (bTile) ? LVBKIF_STYLE_TILE : LVBKIF_STYLE_NORMAL;
	lv.pszImage = pszUrl;
	lv.xOffsetPercent = xOffsetPercent;
	lv.yOffsetPercent = yOffsetPercent;
	return SetBkImage(&lv);
}

BOOL CListCtrlEx::SetBkImage(LVBKIMAGE* plvbkImage)
{
	ASSERT(::IsWindow(m_hWnd));
	return (BOOL) ::SendMessage(m_hWnd, LVM_SETBKIMAGE, 0, (LPARAM)plvbkImage);
}

DWORD CListCtrlEx::GetHoverTime() const
{
	ASSERT(::IsWindow(m_hWnd));
	return (DWORD) ::SendMessage(m_hWnd, LVM_GETHOVERTIME, 0, 0L);
}

DWORD CListCtrlEx::SetHoverTime(DWORD dwHoverTime)
{
	ASSERT(::IsWindow(m_hWnd));
	return (DWORD) ::SendMessage(m_hWnd, LVM_SETHOVERTIME, 0, (LPARAM)dwHoverTime);
}

BOOL CListCtrlEx::GetCheck(int nItem) const
{
	ASSERT(::IsWindow(m_hWnd));
	int nState = (int) ::SendMessage(m_hWnd, LVM_GETITEMSTATE, (WPARAM)nItem, (LPARAM)LVIS_STATEIMAGEMASK);

	return ((BOOL)(nState >> 12) -1);
}

BOOL CListCtrlEx::SetCheck(int nItem, BOOL bCheck)
{
	ASSERT(::IsWindow(m_hWnd));
	LVITEM lvi;
	lvi.stateMask = LVIS_STATEIMAGEMASK;
	lvi.state = INDEXTOSTATEIMAGEMASK((bCheck ? 2 : 1));

	return (BOOL) ::SendMessage(m_hWnd, LVM_SETITEMSTATE, nItem, (LPARAM)&lvi);
}


// ***********
// HitTestEx    - Determine the row index and column index for a point
// Returns      - the row index or -1 if point is not over a row
// point        - point to be tested.
// col          - to hold the column index
int CListCtrlEx::HitTestEx(CPoint &point, int *col) const
{
        int colnum = 0;
        int row = HitTest( point, NULL );
        
        if( col ) *col = 0;

        // Make sure that the ListView is in LVS_REPORT
        if( (GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK) != LVS_REPORT )
                return row;

        // Get the top and bottom row visible
        row = GetTopIndex();
        int bottom = row + GetCountPerPage();
        if( bottom > GetItemCount() )
                bottom = GetItemCount();
        
        // Get the number of columns
        CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);
        int nColumnCount = pHeader->GetItemCount();

        // Loop through the visible rows
        for( ;row <=bottom;row++)
        {
                // Get bounding rect of item and check whether point falls in it.
                CRect rect;
                GetItemRect( row, &rect, LVIR_BOUNDS );
                if( rect.PtInRect(point) )
                {
                        // Now find the column
                        for( colnum = 0; colnum < nColumnCount; colnum++ )
                        {
                                int colwidth = GetColumnWidth(colnum);
                                if( point.x >= rect.left 
                                        && point.x <= (rect.left + colwidth ) )
                                {
                                        if( col ) *col = colnum;
                                        return row;
                                }
                                rect.left += colwidth;
                        }
                }
        }
        return -1;
}

// EditSubLabel         - Start edit of a sub item label
// Returns              - Temporary pointer to the new edit control
// nItem                - The row index of the item to edit
// nCol                 - The column of the sub item.
CEdit* CListCtrlEx::EditSubLabel( int nItem, int nCol )
{
        // The returned pointer should not be saved

        // Make sure that the item is visible
        if( !EnsureVisible( nItem, TRUE ) ) return NULL;

        // Make sure that nCol is valid
        CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);
        int nColumnCount = pHeader->GetItemCount();
        if( nCol >= nColumnCount || GetColumnWidth(nCol) < 5 )
                return NULL;

        // Get the column offset
        int offset = 0;
        for( int i = 0; i < nCol; i++ )
                offset += GetColumnWidth( i );

        CRect rect;
        GetItemRect( nItem, &rect, LVIR_BOUNDS );

        // Now scroll if we need to expose the column
        CRect rcClient;
        GetClientRect( &rcClient );
        if( offset + rect.left < 0 || offset + rect.left > rcClient.right )
        {
                CSize size;
                size.cx = offset + rect.left;
                size.cy = 0;
                Scroll( size );
                rect.left -= size.cx;
        }

        // Get Column alignment
        LV_COLUMN lvcol;
        lvcol.mask = LVCF_FMT;
        GetColumn( nCol, &lvcol );
        DWORD dwStyle ;
        if((lvcol.fmt&LVCFMT_JUSTIFYMASK) == LVCFMT_LEFT)
                dwStyle = ES_LEFT;
        else if((lvcol.fmt&LVCFMT_JUSTIFYMASK) == LVCFMT_RIGHT)
                dwStyle = ES_RIGHT;
        else dwStyle = ES_CENTER;

        rect.left += offset+4;
        rect.right = rect.left + GetColumnWidth( nCol ) - 3 ;
        if( rect.right > rcClient.right) rect.right = rcClient.right;

        dwStyle |= WS_BORDER|WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL;
        CEdit *pEdit = new CInPlaceEdit(this, nItem, nCol, GetItemText( nItem, nCol ));
        pEdit->Create( dwStyle, rect, this, IDC_IPEDIT );


        return pEdit;
}

void CListCtrlEx::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
        if( GetFocus() != this ) SetFocus();
        CListCtrl::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CListCtrlEx::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
        if( GetFocus() != this ) SetFocus();
        CListCtrl::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CListCtrlEx::OnLButtonDown(UINT nFlags, CPoint point)
{
        int index;
        CListCtrl::OnLButtonDown(nFlags, point);

        int column;
        if( ( index = HitTestEx( point, &column )) != -1 )
        {
                UINT flag = LVIS_FOCUSED;
                if((GetItemState( index, flag ) & flag) == flag && column > 0)
                {
                        // Add check for LVS_EDITLABELS
                        if( GetWindowLong(m_hWnd, GWL_STYLE) & LVS_EDITLABELS )
						{
							CStringList *pcList; // = m_cDropListMap .Get(column);
							if (m_cDropListMap.Lookup( column, (CObject*&)pcList))
							{
								ShowInPlaceList( index, column, *pcList, 0 );
							}
							else
							{
                                EditSubLabel( index, column );
							}
						}
                }
                else
                        SetItemState( index, LVIS_SELECTED | LVIS_FOCUSED ,
                                        LVIS_SELECTED | LVIS_FOCUSED); 
        }
}


#endif // NOLISTVIEWEX

void CListCtrlEx::OnEndlabelEdit(NMHDR* pNMHDR, LRESULT* pResult) 
{
        LV_DISPINFO *plvDispInfo = (LV_DISPINFO *)pNMHDR;
        LV_ITEM *plvItem = &plvDispInfo->item;

        if (plvItem->pszText != NULL)
        {
                SetItemText(plvItem->iItem, plvItem->iSubItem, plvItem->pszText);
        }
        *pResult = FALSE;
}

// --------------- drop down list functions ---------------------------------------
// taken from codeguru.developer.com by Zafir Anjum

// ShowInPlaceList              - Creates an in-place drop down list for any 
//                              - cell in the list view control
// Returns                      - A temporary pointer to the combo-box control
// nItem                        - The row index of the cell
// nCol                         - The column index of the cell
// lstItems                     - A list of strings to populate the control with
// nSel                         - Index of the initial selection in the drop down list
CComboBox* CListCtrlEx::ShowInPlaceList( int nItem, int nCol, 
                                        CStringList &lstItems, int nSel )
{
        // The returned pointer should not be saved

        // Make sure that the item is visible
        if( !EnsureVisible( nItem, TRUE ) ) return NULL;

        // Make sure that nCol is valid 
        CHeaderCtrl* pHeader = (CHeaderCtrl*)GetDlgItem(0);
        int nColumnCount = pHeader->GetItemCount();
        if( nCol >= nColumnCount || GetColumnWidth(nCol) < 10 ) 
                return NULL;

        // Get the column offset
        int offset = 0;
        for( int i = 0; i < nCol; i++ )
                offset += GetColumnWidth( i );

        CRect rect;
        GetItemRect( nItem, &rect, LVIR_BOUNDS );

        // Now scroll if we need to expose the column
        CRect rcClient;
        GetClientRect( &rcClient );
        if( offset + rect.left < 0 || offset + rect.left > rcClient.right )
        {
                CSize size;
                size.cx = offset + rect.left;
                size.cy = 0;
                Scroll( size );
                rect.left -= size.cx;
        }

        rect.left += offset+4;
        rect.right = rect.left + GetColumnWidth( nCol ) - 3 ;
        int height = rect.bottom-rect.top;
        rect.bottom += 5*height;
        if( rect.right > rcClient.right) rect.right = rcClient.right;

        DWORD dwStyle = WS_BORDER|WS_CHILD|WS_VISIBLE
                                        |CBS_DROPDOWNLIST|CBS_DISABLENOSCROLL;
        CComboBox *pList = new CInPlaceList(nItem, nCol, &lstItems, nSel);
        pList->Create( dwStyle, rect, this, IDC_IPEDIT );
        pList->SetItemHeight( -1, height);
        pList->SetHorizontalExtent( GetColumnWidth( nCol ));


        return pList;
}

void CListCtrlEx::SetDropDownListCol(int iCol, CStringArray &carrItems)
{
	CStringList *pcarrList = new CStringList(carrItems.GetSize());

	for (int i = 0; i < carrItems.GetSize(); i++)
		pcarrList->AddTail( carrItems.GetAt(i) );

	m_cDropListMap.SetAt( iCol, pcarrList );
}


