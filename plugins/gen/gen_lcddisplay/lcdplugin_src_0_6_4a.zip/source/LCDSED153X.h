/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2002 TSchirme. All Rights Reserved.
//  tobias.schirmer@foni.net
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
// LCDSED153X.h: interface for the CCfgSED class.
//
//////////////////////////////////////////////////////////////////////
// Modifications:
//  -
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LCDSED153X_H__9AD794C2_2E96_11D6_B385_FFFFFF000000__INCLUDED_)
#define AFX_LCDSED153X_H__9AD794C2_2E96_11D6_B385_FFFFFF000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// LPT1
#define	DEF_LPTPORT_SED		0x378
// medium contrast
#define DEF_CONTRAST_SED	15

#define MAX_LPTPORT_STRLEN   7

class CCfgSED  
{
public:
	CCfgSED();
	~CCfgSED();
	void Load(LPCSTR lpIniFile);
	void Save(LPCSTR lpIniFile);

public:
	short	iLPTPort;
	BYTE	byContrast;
	int		iRows;
	int		iCols;
	int		iBacklight;
	tULongToULong charMap;
};

extern	CCfgSED	 g_SEDCfg; 

class CLcdSED153X : public CLcd  
{
public:
	CLcdSED153X();
	virtual ~CLcdSED153X();

	virtual BOOL  Open();
	virtual BOOL  IsOpen();
	virtual void  Close();
	virtual long  GetLastError();

	virtual void  InitDisplay();
	virtual void  SetContrast(short nLevel);
	virtual short GetContrast();
	virtual int   GetRows();		
	virtual int   GetColumns();	

	virtual void  Home();
	virtual void  Clear();
	virtual void  SetPosition(short nCol, short nRow);
	virtual void  Write(LPCSTR lpText);

	virtual BOOL  CreateCustomChar(short nNumber, CCustomChar &cChar);
	virtual short GetMaxCustomChar();
	virtual LPCTSTR ConvertTagsToCustomChars(CString &csText);
	virtual LPCTSTR ConvertCustomCharsToTags(CString &csText);

	void LPTWrite(unsigned char data);
	void WriteSED(unsigned char adr, unsigned char data);
	void ClearSEDBitmap(void);

	// unimplemented functions
	//
	virtual void  SetBacklight(short nMinutes);
	virtual short GetBacklight();
	virtual void  SetBlink(BOOL On);
	virtual BOOL  GetBlink();
	virtual void  Cursor(BOOL bOn);
	virtual BOOL  IsCursorOn();
	virtual void  InitHorizontalBar();
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen);
	virtual void  InitVerticalBar();
	virtual void  VBar(short nCol, short nLength);
	virtual void  InitLargeDigit();
	virtual void  LargeDigit(short nCol, short nNumber);
	virtual void  SetLineWrap(BOOL bOn);
	virtual BOOL  GetLineWrap();
	virtual void  SetScroll(BOOL bOn);
	virtual BOOL  GetScroll();

private:
	void	WriteData(BYTE byData);
	void	WriteSEDControl(unsigned char data);
	void	WriteSEDData(unsigned char data);
	void	WriteSEDCustomData(unsigned char data);

protected:
	typedef void  (CALLBACK *WRITECHAR)(ULONG, UCHAR);

	//	BYTE	m_byCmdPrefix;
	long	m_lLastError;
	short	m_nContrast;
	BOOL	m_bOpen;
	BOOL	m_hLPTPort;
	short	m_act_row;
	short	m_act_col;

	BOOL		m_bWinNT;
	WRITECHAR	m_lpfnWriteChar;
	HINSTANCE	m_hDriver; 

};


#endif // !defined(AFX_LCDSED153X_H__9AD794C2_2E96_11D6_B385_FFFFFF000000__INCLUDED_)

