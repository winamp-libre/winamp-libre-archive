//=========================================================================
//
// Copyright � Dundas Software Ltd. 1998, All Rights Reserved
//
// tbtremfc.cpp : implementation file
//
//=========================================================================


#include "stdafx.h"
#include "tbtremfc.h"                    // class header


//==========================================================================
// MFC Derived tree class: CtStringToString
//==========================================================================
IMPLEMENT_SERIAL(CtStringToString, CObject, 0)

CtStringToString::~CtStringToString()
{
    RemoveAll();
}

void CtStringToString::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        CString key,data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtStringToString::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << (DWORD) GetKey(node);
        ar << (DWORD) GetData(node);
    }
    else
        ok = tStringToString::onStore(where, node);
    return ok;
}


//==========================================================================
// MFC Derived tree class: CtStringToULong
//==========================================================================
IMPLEMENT_SERIAL(CtStringToULong, CObject, 0)

CtStringToULong::~CtStringToULong()
{
    RemoveAll();
}

void CtStringToULong::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        CString key;
        unsigned long data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtStringToULong::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << (DWORD) GetKey(node);
        ar << GetData(node);
    }
    else
        ok = tStringToULong::onStore(where, node);
    return ok;
}


//==========================================================================
// MFC Derived tree class: CtStringToCObject
//==========================================================================
IMPLEMENT_SERIAL(CtStringToCObject, CObject, 0)

CtStringToCObject::~CtStringToCObject()
{
    RemoveAll();
}

void CtStringToCObject::onDeleteData(void*& dataPtr)
{
    delete (CObject*)dataPtr;
}

int CtStringToCObject::onSetData(void*& dataPtr, void* data)
{
    dataPtr = data;
    return 1;
}

void CtStringToCObject::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        CString key;
        CObject* data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtStringToCObject::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << (DWORD) GetKey(node);
        ar << GetData(node);
    }
    else
        ok = 0;
    return ok;
}


//==========================================================================
// MFC Derived tree class: CtULongToString
//==========================================================================
IMPLEMENT_SERIAL(CtULongToString, CObject, 0)

CtULongToString::~CtULongToString()
{
    RemoveAll();
}

void CtULongToString::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        unsigned long key;
        CString data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtULongToString::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << GetKey(node);
        ar << (DWORD) GetData(node);
    }
    else
        ok = tULongToString::onStore(where, node);
    return ok;
}


//==========================================================================
// MFC Derived tree class: CtULongToULong
//==========================================================================
IMPLEMENT_SERIAL(CtULongToULong, CObject, 0)

CtULongToULong::~CtULongToULong()
{
    RemoveAll();
}

void CtULongToULong::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        unsigned long key;
        unsigned long data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtULongToULong::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << GetKey(node);
        ar << GetData(node);
    }
    else
        ok = tULongToULong::onStore(where, node);
    return ok;
}


//==========================================================================
// MFC Derived tree class: CtULongToCObject
//==========================================================================
IMPLEMENT_SERIAL(CtULongToCObject, CObject, 0)

CtULongToCObject::~CtULongToCObject()
{
    RemoveAll();
}

void CtULongToCObject::onDeleteData(void*& dataPtr)
{
    delete (CObject*)dataPtr;
}

int CtULongToCObject::onSetData(void*& dataPtr, void* data)
{
    dataPtr = data;
    return 1;
}

void CtULongToCObject::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        unsigned long key;
        CObject* data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtULongToCObject::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << GetKey(node);
        ar << GetData(node);
    }
    else
        ok = 0;
    return ok;
}


//==========================================================================
// MFC Derived tree class: CtLongToString
//==========================================================================
IMPLEMENT_SERIAL(CtLongToString, CObject, 0)

CtLongToString::~CtLongToString()
{
    RemoveAll();
}

void CtLongToString::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        long key;
        CString data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtLongToString::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << GetKey(node);
        ar << (DWORD) GetData(node);
    }
    else
        ok = tLongToString::onStore(where, node);
    return ok;
}


//==========================================================================
// MFC Derived tree class: CtLongToULong
//==========================================================================
IMPLEMENT_SERIAL(CtLongToULong, CObject, 0)

CtLongToULong::~CtLongToULong()
{
    RemoveAll();
}

void CtLongToULong::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        long key;
        unsigned long data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtLongToULong::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << GetKey(node);
        ar << GetData(node);
    }
    else
        ok = tLongToULong::onStore(where, node);
    return ok;
}


//==========================================================================
// MFC Derived tree class: CtLongToCObject
//==========================================================================
IMPLEMENT_SERIAL(CtLongToCObject, CObject, 0)

CtLongToCObject::~CtLongToCObject()
{
    RemoveAll();
}

void CtLongToCObject::onDeleteData(void*& dataPtr)
{
    delete (CObject*)dataPtr;
}

int CtLongToCObject::onSetData(void*& dataPtr, void* data)
{
    dataPtr = data;
    return 1;
}

void CtLongToCObject::Serialize(CArchive& ar)
{
    m_bufSize = -1;                             // inticates CArchive 
    if (ar.IsStoring())
    {
        ar << GetCount();
        storeTree((void*)&ar);
    }
    else
    {
        RemoveAll();
        long imbalance = SetAutoBalance(0);     // turn off autobalance
        long count;
        long key;
        CObject* data;
        ar >> count;
        while (count)
        {
            ar >> key;
            ar >> data;
            Set(key,data);
            count--;
        }
        SetAutoBalance(imbalance);              // resume autobalance
    }
}

int CtLongToCObject::onStore(void* where, POSITION node)
{
    int ok = 1;
    if (m_bufSize == -1)
    {
        CArchive& ar = (CArchive&)(*(CArchive*)where);
        ar << GetKey(node);
        ar << GetData(node);
    }
    else
        ok = 0;
    return ok;
}
