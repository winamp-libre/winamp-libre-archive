/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// 20.11.99 - Exchanged WinAmp polling with Scroll Separator Field, M.Zehnder
// 18.11.99 - Sroll Separator Field added, F. Verhamme
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DLGPAGEVARIABLES_H__FBF15222_944F_11D3_A83D_60C953C10000__INCLUDED_)
#define AFX_DLGPAGEVARIABLES_H__FBF15222_944F_11D3_A83D_60C953C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgPageVariables.h : header file
//

#include "CustomCharDef.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgPageVariables dialog

class CDlgPageVariables : public CPropertyPage
{
	DECLARE_DYNCREATE(CDlgPageVariables)
protected:
	int		m_iOldCCharIndex;
	int		m_iMaxCustomChars;

// Construction
public:
	CDlgPageVariables();
	~CDlgPageVariables();

// Dialog Data
	//{{AFX_DATA(CDlgPageVariables)
	enum { IDD = IDD_PAGE_VARIABLES };
	CComboBox	m_cCustomCharCombo;
	CCustomCharDef	m_cCustomCharDef;
	int		m_iVariable;
	BOOL	m_bTrimTrailing;
	BOOL	m_bTrimLeading;
	BOOL	m_bTimeBlink;
	CString	m_csPause;
	CString	m_csPlay;
	CString	m_csStop;
	CString	m_csTimeFormat;
	CString m_csDateTimeFormat;
	CString m_csDateTimeOpt;
	CString	m_csRepOff;
	CString	m_csRepOn;
	CString	m_csShuffleOff;
	CString	m_csShuffleOn;
	int		m_VolBarLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDlgPageVariables)
	public:
	virtual BOOL OnApply();
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDlgPageVariables)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeVariable();
	afx_msg void OnSetModified();
	afx_msg void OnDefBtn();
	afx_msg void OnAlloffBtn();
	afx_msg void OnAllonBtn();
	afx_msg void OnSelchangeCharnbrCombo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPAGEVARIABLES_H__FBF15222_944F_11D3_A83D_60C953C10000__INCLUDED_)
