/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LCDFactory.h: interface for the CLCDFactory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LCDFACTORY_H__1B35A330_5961_11D3_B639_0010A4F5373D__INCLUDED_)
#define AFX_LCDFACTORY_H__1B35A330_5961_11D3_B639_0010A4F5373D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LCD.h"
#include "tbtreed.h"


class CLCDFactory  
{
protected:
	static volatile BOOL  m_bTerminate;
	BOOL  m_bClosed;
	DWORD m_dwThreadIDWinampPoll;
	DWORD m_dwThreadIDLCDOutput;
	
	HANDLE m_hWinampPoll;
	HANDLE m_hLCDOutput;
	tStringToULong m_mapDrv;

	void   RegisterDriver(LCD_DRIVER *drv);
	void   RegisterDriver(char *szID, char *szName, CLcd *pcLcd, CDialog *pcCfgDlg);

public:
	CLCDFactory();
	~CLCDFactory();

	void EnableOutput(BOOL state);
	void Terminate();

	CLcd * GetLCDDriver();
	LCD_DRIVER * GetDriver(char *szID);
	POSITION FirstDriver();
	POSITION NextDriver(POSITION pos);
	LCD_DRIVER * GetDriver(POSITION pos);

	BOOL OpenLCD(CLcd *pcLcd);
	BOOL CloseLCD();
};

#define COPYRIGHTOWNER "Markus Zehnder"

#endif // !defined(AFX_LCDFACTORY_H__1B35A330_5961_11D3_B639_0010A4F5373D__INCLUDED_)
