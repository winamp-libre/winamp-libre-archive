//=========================================================================
//
// Copyright � Dundas Software Ltd. 1998, All Rights Reserved
//
// tbtreed.h : header file
//
//==========================================================================

// conditional compilation to avoid multiple defintions
#ifndef _tbtreed_h_
#define _tbtreed_h_

#ifndef _tbtree_h_
#include "tbtree.h"
#endif

//==========================================================================
// Derived tree class: string key, string data
//==========================================================================
class EXT_CLASS tStringToString : public tBalTree
{
public:
    virtual ~tStringToString();
    inline int Set(const char* key, const char* data);
    inline const char* Get(const char* key);
    inline const char* GetKey(POSITION pos);
    inline const char* GetData(POSITION pos);
    inline int SetData(POSITION pos, const char* data);
    inline POSITION Find(const char* key);
    inline int Remove(const char* key);
    inline int Remove(POSITION& pos);
    
protected:
    // These members required in all derived classes:
    virtual void onDeleteKey(void*& keyPtr);
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetKey(void*& keyPtr, void* key);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual relativeKeyValue onCompareKeys(void* key1, void* key2);
    
    // This member provided for debugging support:
    virtual const char* onGetKeyName(void* keyPtr);
    
    // These members provide serialization to iostreams:
    virtual int onStore(void* where, POSITION node);    // output 1 node
    virtual int onLoad(void* where);                    // input 1 node

private:
};

//==========================================================================
// Derived tree class: string key, unsigned long data
//==========================================================================
class EXT_CLASS tStringToULong : public tBalTree
{
public:
    virtual ~tStringToULong();
    inline int Set(const char* key, unsigned long data);
    inline unsigned long Get(const char* key);
    inline const char* GetKey(POSITION pos);
    inline unsigned long GetData(POSITION pos);
    inline int SetData(POSITION pos, unsigned long data);
    inline POSITION Find(const char* key);
    inline int Remove(const char* key);
    inline int Remove(POSITION& pos);
    
protected:
    // These members required in all derived classes:
    virtual void onDeleteKey(void*& keyPtr);
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetKey(void*& keyPtr, void* key);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual relativeKeyValue onCompareKeys(void* key1, void* key2);
    
    // This member provided for debugging support:
    virtual const char* onGetKeyName(void* keyPtr);
    
    // These members provide serialization to iostreams:
    virtual int onStore(void* where, POSITION node);    // output 1 node
    virtual int onLoad(void* where);                    // input 1 node

private:
};

//==========================================================================
// Derived tree class: unsigned long key, string data
//==========================================================================
class EXT_CLASS tULongToString : public tBalTree
{
public:
    virtual ~tULongToString();
    inline int Set(unsigned long key, const char* data);
    inline const char* Get(unsigned long key);
    inline unsigned long GetKey(POSITION pos);
    inline const char* GetData(POSITION pos);
    inline int SetData(POSITION pos, const char* data);
    inline POSITION Find(unsigned long key);
    inline int Remove(unsigned long key);
    inline int Remove(POSITION& pos);
    
protected:
    // These members required in all derived classes:
    virtual void onDeleteKey(void*& keyPtr);
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetKey(void*& keyPtr, void* key);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual relativeKeyValue onCompareKeys(void* key1, void* key2);
    
    // This member provided for debugging support:
    virtual const char* onGetKeyName(void* keyPtr);
    
    // These members provide serialization to iostreams:
    virtual int onStore(void* where, POSITION node);    // output 1 node
    virtual int onLoad(void* where);                    // input 1 node

private:
};

//==========================================================================
// Derived tree class: unsigned long key, unsigned long data
//==========================================================================
class EXT_CLASS tULongToULong : public tBalTree
{
public:
    virtual ~tULongToULong();
    inline int Set(unsigned long key, unsigned long data);
    inline unsigned long Get(unsigned long key);
    inline unsigned long GetKey(POSITION pos);
    inline unsigned long GetData(POSITION pos);
    inline int SetData(POSITION pos, unsigned long data);
    inline POSITION Find(unsigned long key);
    inline int Remove(unsigned long key);
    inline int Remove(POSITION& pos);
    
protected:
    // These members required in all derived classes:
    virtual void onDeleteKey(void*& keyPtr);
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetKey(void*& keyPtr, void* key);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual relativeKeyValue onCompareKeys(void* key1, void* key2);
    
    // This member provided for debugging support:
    virtual const char* onGetKeyName(void* keyPtr);
    
    // These members provide serialization to iostreams:
    virtual int onStore(void* where, POSITION node);    // output 1 node
    virtual int onLoad(void* where);                    // input 1 node

private:
};

//==========================================================================
// Derived tree class: long key, string data
//==========================================================================
class EXT_CLASS tLongToString : public tBalTree
{
public:
    virtual ~tLongToString();
    inline int Set(long key, const char* data);
    inline const char* Get(long key);
    inline long GetKey(POSITION pos);
    inline const char* GetData(POSITION pos);
    inline int SetData(POSITION pos, const char* data);
    inline POSITION Find(long key);
    inline int Remove(long key);
    inline int Remove(POSITION& pos);
    
protected:
    // These members required in all derived classes:
    virtual void onDeleteKey(void*& keyPtr);
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetKey(void*& keyPtr, void* key);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual relativeKeyValue onCompareKeys(void* key1, void* key2);
    
    // This member provided for debugging support:
    virtual const char* onGetKeyName(void* keyPtr);
    
    // These members provide serialization to iostreams:
    virtual int onStore(void* where, POSITION node);    // output 1 node
    virtual int onLoad(void* where);                    // input 1 node

private:
};

//==========================================================================
// Derived tree class: long key, unsigned long data
//==========================================================================
class EXT_CLASS tLongToULong : public tBalTree
{
public:
    virtual ~tLongToULong();
    inline int Set(long key, unsigned long data);
    inline unsigned long Get(long key);
    inline long GetKey(POSITION pos);
    inline unsigned long GetData(POSITION pos);
    inline int SetData(POSITION pos, unsigned long data);
    inline POSITION Find(long key);
    inline int Remove(long key);
    inline int Remove(POSITION& pos);
    
protected:
    // These members required in all derived classes:
    virtual void onDeleteKey(void*& keyPtr);
    virtual void onDeleteData(void*& dataPtr);
    virtual int onSetKey(void*& keyPtr, void* key);
    virtual int onSetData(void*& dataPtr, void* data);
    virtual relativeKeyValue onCompareKeys(void* key1, void* key2);
    
    // This member provided for debugging support:
    virtual const char* onGetKeyName(void* keyPtr);
    
    // These members provide serialization to iostreams:
    virtual int onStore(void* where, POSITION node);    // output 1 node
    virtual int onLoad(void* where);                    // input 1 node

private:
};

//--------------------------------------------------------------------------
// INLINE members for all classes defined here.
//--------------------------------------------------------------------------

// tStringToString
inline int tStringToString::Set(const char* key, const char* data)
{
    return set((void*)key, (void*)data);
}

inline const char* tStringToString::Get(const char* key)
{
    return (const char*)getData(find((void*)key));
}

inline POSITION tStringToString::Find(const char* key)
{
    return (POSITION)find((void*)key);
}

inline int tStringToString::SetData(POSITION node, const char* data)
{
    return setData(node, (void*)data);
}

inline int tStringToString::Remove(const char* key)
{
    POSITION pos = find((void*)key);
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline int tStringToString::Remove(POSITION& pos)
{
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline const char* tStringToString::GetKey(POSITION pos)
{
    return (const char*)getKey(pos);
}

inline const char* tStringToString::GetData(POSITION pos)
{
    return (const char*)getData(pos);
}

// tStringToULong
inline int tStringToULong::Set(const char* key, unsigned long data)
{
    return set((void*)key, (void*)data);
}

inline unsigned long tStringToULong::Get(const char* key)
{
    return (unsigned long)getData(find((void*)key));
}

inline int tStringToULong::SetData(POSITION node, unsigned long data)
{
    return setData(node, (void*)data);
}

inline POSITION tStringToULong::Find(const char* key)
{
    return (POSITION)find((void*)key);
}

inline int tStringToULong::Remove(const char* key)
{
    POSITION pos = find((void*)key);
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline int tStringToULong::Remove(POSITION& pos)
{
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline const char* tStringToULong::GetKey(POSITION pos)
{
    return (const char*)getKey(pos);
}

inline unsigned long tStringToULong::GetData(POSITION pos)
{
    return (unsigned long)getData(pos);
}

// tULongToString
inline int tULongToString::Set(unsigned long key, const char* data)
{
    return set((void*)key, (void*)data);
}

inline const char* tULongToString::Get(unsigned long key)
{
    return (const char*)getData(find((void*)key));
}

inline int tULongToString::SetData(POSITION node, const char* data)
{
    return setData(node, (void*)data);
}

inline POSITION tULongToString::Find(unsigned long key)
{
    return (POSITION)find((void*)key);
}

inline int tULongToString::Remove(unsigned long key)
{
    POSITION pos = find((void*)key);
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline int tULongToString::Remove(POSITION& pos)
{
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline unsigned long tULongToString::GetKey(POSITION pos)
{
    return (unsigned long)getKey(pos);
}

inline const char* tULongToString::GetData(POSITION pos)
{
    return (const char*)getData(pos);
}

// tULongToULong
inline int tULongToULong::Set(unsigned long key, unsigned long data)
{
    return set((void*)key, (void*)data);
}

inline unsigned long tULongToULong::Get(unsigned long key)
{
    return (unsigned long)getData(find((void*)key));
}

inline int tULongToULong::SetData(POSITION node, unsigned long data)
{
    return setData(node, (void*)data);
}

inline POSITION tULongToULong::Find(unsigned long key)
{
    return (POSITION)find((void*)key);
}

inline int tULongToULong::Remove(unsigned long key)
{
    POSITION pos = find((void*)key);
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline int tULongToULong::Remove(POSITION& pos)
{
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline unsigned long tULongToULong::GetKey(POSITION pos)
{
    return (unsigned long)getKey(pos);
}

inline unsigned long tULongToULong::GetData(POSITION pos)
{
    return (unsigned long)getData(pos);
}

// tLongToString
inline int tLongToString::Set(long key, const char* data)
{
    return set((void*)key, (void*)data);
}

inline const char* tLongToString::Get(long key)
{
    return (const char*)getData(find((void*)key));
}

inline int tLongToString::SetData(POSITION node, const char* data)
{
    return setData(node, (void*)data);
}

inline POSITION tLongToString::Find(long key)
{
    return (POSITION)find((void*)key);
}

inline int tLongToString::Remove(long key)
{
    POSITION pos = find((void*)key);
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline int tLongToString::Remove(POSITION& pos)
{
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline long tLongToString::GetKey(POSITION pos)
{
    return (long)getKey(pos);
}

inline const char* tLongToString::GetData(POSITION pos)
{
    return (const char*)getData(pos);
}

// tLongToULong
inline int tLongToULong::Set(long key, unsigned long data)
{
    return set((void*)key, (void*)data);
}

inline unsigned long tLongToULong::Get(long key)
{
    return (unsigned long)getData(find((void*)key));
}

inline int tLongToULong::SetData(POSITION node, unsigned long data)
{
    return setData(node, (void*)data);
}

inline POSITION tLongToULong::Find(long key)
{
    return (POSITION)find((void*)key);
}

inline int tLongToULong::Remove(long key)
{
    POSITION pos = find((void*)key);
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline int tLongToULong::Remove(POSITION& pos)
{
    int ok = pos ? 1 : 0;
    remove(pos);
    return ok;
}

inline long tLongToULong::GetKey(POSITION pos)
{
    return (long)getKey(pos);
}

inline unsigned long tLongToULong::GetData(POSITION pos)
{
    return (unsigned long)getData(pos);
}

#endif
//// end ///////////////////////////////////////////////////////////////////
