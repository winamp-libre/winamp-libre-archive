
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

// Struktur sLcdParams als neuen Typ tLcdParams anlegen
// hwndOwner => Handle des Besitzers (das Plugin)
// hInstance => Handler der Instance auf die Plugin-DLL
// pTitle    => Zeiger auf einen String, f�r den Titel
// xPos, yPos=> X & Y Koordinaten
// cxChar, cyChar => Spalten & Zeilen f�r Displaysimulation
// cFgCol    => Vordergrundfarbe
// cBkCol    => Hintergrundfarbe

typedef struct sLcdSimParams
{
  HWND hwndOwner;
  HINSTANCE hInstance;
  char* pTitle;
  int xPos, yPos;
  int cxChars, cyChars;  
  struct { COLORREF cFgCol, cBkCol; } sLightOn;
  struct { COLORREF cFgCol, cBkCol; } sLightOff;
}
tLcdSimParams;

// ------------------------------------------
// Funktionsprototypen f�r die LCD Simulation
// ------------------------------------------

HWND LcdDisplaySim_Open(tLcdSimParams* pParams);
void LcdDisplaySim_Close(HWND hwndDisplay);
void LcdDisplaySim_Clear(HWND hwndDisplay);
void LcdDisplaySim_SetCursorPos(HWND hwndDisplay, int xPos, int yPos);
void LcdDisplaySim_PrintString(HWND hwndDisplay, const char* pText);
void LcdDisplaySim_SetCustomChar(HWND hwndDisplay, char cChar, char* pCharData, int iCharDataLen);
void LcdDisplaySim_LightOn(HWND hwndDisplay);
void LcdDisplaySim_LightOff(HWND hwndDisplay);
void LcdDisplaySim_SetContrast(HWND hwndDisplay, COLORREF cNewColor);
//int LoadLcdSimCharSet(HWND hwnd);

#ifdef __cplusplus
}
#endif


