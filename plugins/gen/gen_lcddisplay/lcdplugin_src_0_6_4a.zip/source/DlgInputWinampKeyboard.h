#ifndef AFX_DLGINPUTWINAMPKEYBOARD_H__7EEC2E72_8783_11D7_BBA8_000102049CBC__INCLUDED_
#define AFX_DLGINPUTWINAMPKEYBOARD_H__7EEC2E72_8783_11D7_BBA8_000102049CBC__INCLUDED_

// DlgInputWinampKeyboard.h : Header-Datei
//

#include "DlgInput.h"

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CDlgInputWinampKeyboard 

class CDlgInputWinampKeyboard : public CDlgInput
{
    DECLARE_DYNCREATE(CDlgInputWinampKeyboard)
	// Konstruktion
public:
	CDlgInputWinampKeyboard(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(CDlgInputWinampKeyboard)
	enum { IDD = IDD_INPUT_WINAMP_KEYBOARD };
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CDlgInputWinampKeyboard)
	public:
	virtual BOOL OnApply();
    protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	virtual void RefreshList();

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CDlgInputWinampKeyboard)
	afx_msg void OnAdd();
	afx_msg void OnEdit();
	afx_msg void OnDelete();
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkListKb(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio f�gt zus�tzliche Deklarationen unmittelbar vor der vorhergehenden Zeile ein.

#endif // AFX_DLGINPUTWINAMPKEYBOARD_H__7EEC2E72_8783_11D7_BBA8_000102049CBC__INCLUDED_
