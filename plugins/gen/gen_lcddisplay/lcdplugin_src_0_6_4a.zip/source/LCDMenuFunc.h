/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2000 Frank Verhamme. All Rights Reserved.
//
//  This file is part of the WinAmp Serial LCD Display Plugin.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
/////////////////////////////////////////////////////////////////////////////
//
// LCDMenuFunc.h:   LCD display Menue Steuerung
//
/////////////////////////////////////////////////////////////////////////////
// Modifications:
// 2002/01/04 MZ  enhanced sMenuLine structure
//
// 24.07.2000 - FVerhamme: first release
// 19.10.2000 - FVerhamme: Change MenuLine structure to read text from rc file
// 01.04.2001 - FVerhamme: Add scrolling in Playlist, Sorting the Playlist
//
/////////////////////////////////////////////////////////////////////////////
#ifndef __LCDMENUFUNC__
#define __LCDMENUFUNC__

// ----------------------------------------------------------------------------
// Hier stehen die Strukturen zur Steuerung von Menues auf einem Display.
// Diese brauchen i.d.R. nicht mehr ver�ndert zu werden !!
// ----------------------------------------------------------------------------
// Struktur die ein komplettes Menue definiert
// iLineCnt          = Anzahl der Menuezeilen
// pFirstLine        = Zeiger auf die Menuezeile
// iLineSelected     = Ausgew�hlte Menuezeile
// iFreeMenueOnLeave = Angabe ob Spreicher freigegeben werden muss !
//                     Dies ist immer n�tig wenn Spreicher reserviert wurde
//                     0 = Speicher nicht freigeben; 1 = Speicher freigeben
typedef struct sCurrMenu
{
  int iLineCnt;
  struct sMenuLine* pFirstLine;
  int iLineSelected;
  int iFreeMenuOnLeave;
  int iInitComplete;
  int iScrollingPos; // Scrollposition
}
tCurrMenu;

typedef int(*tMenuAction)(tCurrMenu*);

//Struktur einer Menuezeile
// idText      = StringID aus der RC Datei oder 0 wenn fester Text
// cText       = Text, der angezeigt werden soll oder "" wenn Text aus RC Datei
// pActionFunc = Funktion die aufgerufen werden soll
typedef struct sMenuLine
{
  int idText;
  TCHAR cTextBuff[_MAX_PATH];
  tMenuAction pActionFunc;
  int iUserData;
  TCHAR cTextBuff2[_MAX_PATH];		// not very nice but due to lack of time... @TODO make dynamic -> quite a bit of work :(  MZ 2001/12/30
}
tMenuLine;


extern char g_cCBox_Unchecked;
extern char g_cCBox_Checked;


// Dynamic Menus thx titi!
typedef struct	s_DynaMenu {
	int			Id;
	char		Label[_MAX_PATH];
	tMenuAction pActionFunc;
	int			UserData;
}				t_DynaMenu;


// ----------------------------------------------------------------------------
// Hier stehen die Funktionsprototypen zur Steuerung der Displaymenues
// Diese brauchen i.d.R. nicht mehr ver�ndert zu werden !!
// ----------------------------------------------------------------------------
int Menu_Enter(tCurrMenu* pCurrMenu, tMenuLine* pFirstLine, int iLineCnt, int iFreeMenuOnLeave);
int Menu_Leave(tCurrMenu* pCurrMenu);
int Menu_IsActive(tCurrMenu* pCurrMenu);
int Menu_Down(tCurrMenu* pCurrMenu);
int Menu_Up(tCurrMenu* pCurrMenu);
int Menu_Select(tCurrMenu* pCurrMenu);
int Menu_Update(tCurrMenu* pCurrMenu);

void Menu_ResetTimer(tCurrMenu* pCurrMenu);

VOID CALLBACK MenuScrollTimer1( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );
VOID CALLBACK MenuScrollTimer2( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime );

int FindMenuScrollPosition(char* pText);
#endif




