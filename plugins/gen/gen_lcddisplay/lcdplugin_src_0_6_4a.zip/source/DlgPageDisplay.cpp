/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgPageDisplay.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 27.06.00 - MZ, added status field
// 18.08.01 - Zlatko Novak, added option for Spectrum Analyser
//			  to start automaticly with starting plugin, added option
//			  for Spectrum Analyser Falloff and Spectrum Analyser 
//			  Falloff 
// 21.10.01 - MZ, added spectrum analyser position configuration
// 20.01.02 - FV, added height paramater for Spectrum ananlyser
// 2003/02/09 MZ  volume bar configuration added
// 2003/07/11 MZ  change handler for every field, save current dlg state before start & stop button handling
// 2003/08/03 MZ  replaced hard coded LCD driver access with dynamic methods through CLCDFactory 
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgPageDisplay.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPageDisplay dialog


CDlgPageDisplay::CDlgPageDisplay()
	: CPropertyPage(CDlgPageDisplay::IDD)
{
	//{{AFX_DATA_INIT(CDlgPageDisplay)
	m_bAutoOpen = FALSE;
	m_csActive = _T("---");
	m_csStatus = _T("");
	m_bFalloff = FALSE;
	m_bAutoAnalyser = FALSE;
	m_iSAcol = 1;
	m_iSAheight = 4;
	m_iSArow = 4;
	m_iSAwidth = 20;
	m_iVBwidth = 0;
	m_iVBrow = 0;
	m_iVBcol = 0;
	m_bVolBar = FALSE;
	//}}AFX_DATA_INIT
}


void CDlgPageDisplay::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPageDisplay)
	DDX_Control(pDX, IDC_LCD_COMBO, m_cLCDCombo);
	DDX_Check(pDX, IDC_CHECK_AUTOOPEN, m_bAutoOpen);
	DDX_Text(pDX, IDC_ACTIVE, m_csActive);
	DDX_Text(pDX, IDC_STATUS, m_csStatus);
	DDX_Check(pDX, IDC_CHECK2_FALLOFF, m_bFalloff);
	DDX_Check(pDX, IDC_CHECK1_ANALYSER, m_bAutoAnalyser);
	DDX_Text(pDX, IDC_SA_COL, m_iSAcol);
	DDV_MinMaxInt(pDX, m_iSAcol, 1, 999);
	DDX_Text(pDX, IDC_SA_HEIGHT, m_iSAheight);
	DDV_MinMaxInt(pDX, m_iSAheight, 1, 4);
	DDX_Text(pDX, IDC_SA_ROW, m_iSArow);
	DDV_MinMaxInt(pDX, m_iSArow, 1, 999);
	DDX_Text(pDX, IDC_SA_WIDTH, m_iSAwidth);
	DDV_MinMaxInt(pDX, m_iSAwidth, 1, 999);
	DDX_Text(pDX, IDC_VB_WIDTH, m_iVBwidth);
	DDX_Text(pDX, IDC_VB_ROW, m_iVBrow);
	DDX_Text(pDX, IDC_VB_COL, m_iVBcol);
	DDX_Check(pDX, IDC_CHECK1_VOLBAR, m_bVolBar);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPageDisplay, CPropertyPage)
	//{{AFX_MSG_MAP(CDlgPageDisplay)
	ON_BN_CLICKED(IDC_CFG_BTN, OnCfgBtn)
	ON_CBN_SELCHANGE(IDC_LCD_COMBO, OnSelchangeLcdCombo)
	ON_BN_CLICKED(IDC_START_BTN, OnStartBtn)
	ON_BN_CLICKED(IDC_STOP_BTN, OnStopBtn)
	ON_BN_CLICKED(IDC_CHECK_AUTOOPEN, OnModified)
	ON_BN_CLICKED(IDC_CHECK1_ANALYSER, OnModified)
	ON_BN_CLICKED(IDC_CHECK2_FALLOFF, OnModified)
	ON_BN_CLICKED(IDC_CHECK1_VOLBAR, OnModified)
	ON_EN_CHANGE(IDC_SA_COL, OnModified)
	ON_EN_CHANGE(IDC_SA_HEIGHT, OnModified)
	ON_EN_CHANGE(IDC_SA_ROW, OnModified)
	ON_EN_CHANGE(IDC_SA_WIDTH, OnModified)
	ON_EN_CHANGE(IDC_VB_COL, OnModified)
	ON_EN_CHANGE(IDC_VB_ROW, OnModified)
	ON_EN_CHANGE(IDC_VB_WIDTH, OnModified)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPageDisplay message handlers

BOOL CDlgPageDisplay::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

  	
    char szBuffer1[512], szBuffer2[512];
    int i = 0, iDrv = CB_ERR;


   POSITION pos;
   LCD_DRIVER *pDrv;
      
   for (pos = g_LCDFactory.FirstDriver(); pos != NULL; )
   {
		pDrv = (LCD_DRIVER *)g_LCDFactory.GetDriver(pos);

		if (pDrv != NULL) {
			if (stricmp(g_Config.szDriver, pDrv->szID) == 0)
				iDrv = i;
			m_cLCDCombo.AddString(pDrv->szName);
			m_cLCDCombo.SetItemDataPtr(i, pDrv);
			i++;
		}

		pos = g_LCDFactory.NextDriver(pos);
   }
	
	if (iDrv != CB_ERR)
	{
		m_cLCDCombo.SetCurSel(iDrv);
		m_cLCDCombo.GetLBText(iDrv, m_csActive);
	}

	if (g_LCD)
	{
        LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_DISPL_STARTED, szBuffer1, sizeof(szBuffer1));
        LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_DISPL_STOPPED, szBuffer2, sizeof(szBuffer2));
		m_csStatus = g_LCD->IsOpen() ? szBuffer1 : szBuffer2;		// MZ, June 27th 2k
	}

	m_bAutoOpen  = g_Config.bAutoOpen;
	m_bAutoAnalyser = g_Config.bAutoAnalyser;
	m_bFalloff = g_Config.bFalloff;
	m_iSAcol = g_Config.iSAcol;
	m_iSArow = g_Config.iSArow;
	m_iSAheight = g_Config.iSAheight;
	m_iSAwidth = g_Config.iSAwidth;

	m_iVBcol = g_Config.iVBcol;
	m_iVBrow = g_Config.iVBrow;
	m_iVBwidth = g_Config.iVBwidth;
	m_bVolBar = g_Config.bTempVB;


	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgPageDisplay::OnCfgBtn() 
{
	int i = m_cLCDCombo.GetCurSel();

	LCD_DRIVER *pDrv = (LCD_DRIVER *)m_cLCDCombo.GetItemDataPtr(i);

	if (pDrv && pDrv->pcCfgDlg != NULL)
		pDrv->pcCfgDlg->DoModal();
}

BOOL CDlgPageDisplay::OnApply() 
{
	int i = m_cLCDCombo.GetCurSel();
	LCD_DRIVER *pDrv = (LCD_DRIVER *)m_cLCDCombo.GetItemDataPtr(i);
	if (pDrv)
		strcpy(g_Config.szDriver, pDrv->szID);

	g_Config.bAutoOpen = m_bAutoOpen;
	g_Config.bAutoAnalyser = m_bAutoAnalyser; 
	g_Config.bFalloff = m_bFalloff;;
	g_Config.iSAcol = m_iSAcol;
	g_Config.iSArow = m_iSArow;
	g_Config.iSAheight = m_iSAheight;
	g_Config.iSAwidth = m_iSAwidth;

	g_Config.iVBcol = m_iVBcol;
	g_Config.iVBrow = m_iVBrow;
	g_Config.iVBwidth = m_iVBwidth;
	g_Config.bTempVB = m_bVolBar;
	
	return CPropertyPage::OnApply();
}

void CDlgPageDisplay::OnSelchangeLcdCombo() 
{
	int i = m_cLCDCombo.GetCurSel();
	if (i == CB_ERR)
		return;

	LCD_DRIVER *pDrv = (LCD_DRIVER *)m_cLCDCombo.GetItemDataPtr(i);
	
	if (pDrv) {
		GetDlgItem(IDC_START_BTN)->EnableWindow(pDrv->pcLcd != NULL);
		GetDlgItem(IDC_STOP_BTN)->EnableWindow(pDrv->pcLcd != NULL);
		GetDlgItem(IDC_CFG_BTN)->EnableWindow(pDrv->pcCfgDlg != NULL);
	}

	OnModified();
}

void CDlgPageDisplay::OnStartBtn() 
{
	char szBuffer1[512];

	int i = m_cLCDCombo.GetCurSel();
	if (i == CB_ERR)
		return;

	// save current state, MZ 2003/07/11
	UpdateData();

	LCD_DRIVER *pDrv = (LCD_DRIVER *)m_cLCDCombo.GetItemDataPtr(i);

	if (pDrv && pDrv->pcLcd != NULL)
	{
		if (g_LCDFactory.OpenLCD(pDrv->pcLcd))
		{
			LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_DISPL_STARTED, szBuffer1, sizeof(szBuffer1));
			m_cLCDCombo.GetLBText(i, m_csActive);
			m_csStatus = szBuffer1;
			UpdateData(FALSE);
		}
		else
		{
			// TODO: error message!
			LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_DISPL_ERROR, szBuffer1, sizeof(szBuffer1));
			m_csStatus = szBuffer1;
		}
	}
}

void CDlgPageDisplay::OnStopBtn() 
{
	char szBuffer1[512];

	// save current state, MZ 2003/07/11
	UpdateData();

	if (g_LCD && g_LCD->IsOpen())			// MZ, July 21 2k
		g_LCDFactory.CloseLCD();

	LoadString(g_Plugin.hDllInstance, IDS_CFGDLG_DISPL_STOPPED, szBuffer1, sizeof(szBuffer1));
	m_csStatus = szBuffer1;
	UpdateData(FALSE);
}

void CDlgPageDisplay::OnModified() {
	CPropertyPage::SetModified();
}

