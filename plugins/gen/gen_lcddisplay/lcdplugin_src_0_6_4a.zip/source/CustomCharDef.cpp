/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2000 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// CustomCharDef.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
//
// TODO: make the hard coded m_pcChar array size dynamic, provide array size 
//       in constructor
//


#include "stdafx.h"
#include <math.h>
#include "CustomCharDef.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCustomCharDef

CCustomCharDef::CCustomCharDef()
{
	Init(5, 8);
}

CCustomCharDef::CCustomCharDef(int iCols, int iRows)
{
	Init(iCols, iRows);
}

void CCustomCharDef::Init(int iCols, int iRows)
{
	m_iRows = iRows;
	m_iCols = iCols;

	m_pcChar = new CUSTOMCHAR[iCols*iRows];

	//FVerhamm - Bugfix
	//Zum Zeitpunkt dieses Aufruf ist das Handle auf das Fenster noch NULL,
	//deswegen wurde immer eine Assertion geschmissen.
	//Ich habe Create eingebaut und die Funktion dorthin verschoben :-)
	//SetAllDots(FALSE);
}

BOOL CCustomCharDef::Create( LPCTSTR lpszText, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	BOOL retvalue = CStatic::Create(lpszText, dwStyle, rect, pParentWnd, nID);
	SetAllDots(FALSE);
	return retvalue;
	
}


CCustomCharDef::~CCustomCharDef()
{
	delete []m_pcChar;
}

void CCustomCharDef::SetSize(int iCols, int iRows)
{
	// TODO: add read/write lock to variables
	// 
	m_iRows = iRows;
	m_iCols = iCols;

	delete []m_pcChar;
	m_pcChar = new CUSTOMCHAR[iCols*iRows];
}

BEGIN_MESSAGE_MAP(CCustomCharDef, CStatic)
	//{{AFX_MSG_MAP(CCustomCharDef)
	ON_WM_PAINT()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCustomCharDef message handlers

void CCustomCharDef::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	int   iPos;
    CRect r;
    GetClientRect(&r);

	int cx = (r.right - (m_iCols - 1) * BLOCKSEP_SIZE) / m_iCols;
	int cy = (r.bottom - (m_iRows - 1) * BLOCKSEP_SIZE) / m_iRows;

	cx > cy ? cx = cy : cy = cx;

	int iHeight = cy;

	for (int x = 0; x < m_iRows; x++)
	{
		int iWidth = cx;
		for (int y = 0; y < m_iCols; y++)
		{
			iPos = x*m_iCols + y;
			m_pcChar[iPos].cRect.left = iWidth - cx;
			m_pcChar[iPos].cRect.top = iHeight - cy;
			m_pcChar[iPos].cRect.right = m_pcChar[iPos].cRect.left + cx;
			m_pcChar[iPos].cRect.bottom = m_pcChar[iPos].cRect.top + cy;

			iWidth += cx + BLOCKSEP_SIZE;
		}
		iHeight += cy + BLOCKSEP_SIZE;
	}

    DWORD hiCol = ::GetSysColor(COLOR_3DHIGHLIGHT);
    DWORD loCol = ::GetSysColor(COLOR_3DSHADOW);
    DWORD backCol = ::GetSysColor(COLOR_3DFACE);

	for (x = 0; x < m_iRows; x++)
	{
		for (int y = 0; y < m_iCols; y++)
		{
		  iPos = x*m_iCols + y;
		  dc.FillSolidRect(&m_pcChar[iPos].cRect, m_pcChar[iPos].bFill ? RGB(0,0,0) : backCol);
		  dc.Draw3dRect(&m_pcChar[iPos].cRect,hiCol,loCol);
		}
	}

	
	// Do not call CStatic::OnPaint() for painting messages
}

void CCustomCharDef::OnLButtonUp(UINT nFlags, CPoint point) 
{
	int iPos;

	for (int x = 0; x < m_iRows; x++)
	{
		for (int y = 0; y < m_iCols; y++)
		{
		  iPos = x*m_iCols + y;
		  if (m_pcChar[iPos].cRect.PtInRect(point))
		  {
			  m_pcChar[iPos].bFill = !m_pcChar[iPos].bFill;
			  RedrawWindow();
			  break;
		  }
		}
	}
	CStatic::OnLButtonUp(nFlags, point);
}

void CCustomCharDef::SetAllDots(BOOLEAN bOn)
{
	for (int x = 0; x < m_iRows; x++)
		for (int y = 0; y < m_iCols; y++)
			m_pcChar[x*m_iCols + y].bFill = bOn;
		//if(m_hWnd) RedrawWindow();
		RedrawWindow();
}

void CCustomCharDef::SetChar(CCustomChar &cChar)
{
	int iMax = __min(m_iRows, cChar.m_byDataSize);

	for (int x = 0; x < iMax; x++)
	{
		for (int y = 0; y < m_iCols; y++)
		{
			m_pcChar[x*m_iCols + y].bFill = cChar.m_byarrData[x] & (BYTE)pow(2, m_iCols - 1 - y);
		}
	}
	RedrawWindow();
}

void CCustomCharDef::GetChar(CCustomChar &cChar)
{
	int iMax = __min(m_iRows, cChar.m_byDataSize);

	for (int x = 0; x < iMax; x++)
	{
		cChar.m_byarrData[x] = 0;
		for (int y = 0; y < m_iCols; y++)
		{
			cChar.m_byarrData[x] |= (BYTE)((m_pcChar[x*m_iCols + y].bFill ? 1 : 0) * pow(2, m_iCols - 1 - y));
		}
	}
}

