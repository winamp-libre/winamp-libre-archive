/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2002 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on markus.zehnder@gmx.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// LcdHD667xx.h: interface for the CLcdHD667xx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LCDHD667xx_H__284FE561_BF2B_11D3_8F31_0000E871C360__INCLUDED_)
#define AFX_LCDHD667xx_H__284FE561_BF2B_11D3_8F31_0000E871C360__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LcdHD44780.h"
#include "DevParallel44780.h"

#ifdef  FONTSIZE
	#undef  FONTSIZE
#endif
#define FONTSIZE 0
   // 4= 7line font 0=10 line font  (default was 0=10 line andrewm)



#define LCDCLOCK 16
#define LCDDATA 8


// default delay values in us
#define DEF_DELAY_SHORT		  40
#define DEF_DELAY_MED		 100
#define DEF_DELAY_LONG		1600
#define DEF_DELAY_INIT		4100
#define DEF_DELAY_BUS		  17
#define DEF_DELAY_MULTIPLIER   1


/* Control output lines
 * Write to baseaddress+2
 */
#define nSTRB 	0x01	/* negative logic */
#define STRB 	0x01
#define nLF 	0x02
#define LF 		0x02
#define INIT 	0x04	/* the only positive logic output line */
#define nSEL 	0x08
#define SEL 	0x08
#define ENIRQ	0x10	/* Enable IRQ via ACK line */
#define ENBI	0x20	/* Enable bi-directional port */

#define OUTMASK	0x0B	/* SEL, LF and STRB are hardware inverted */
			/* Use this mask only for the control output lines */
			/* XOR with this mask ( ^ OUTMASK ) */


/* Control input lines
 * Read from baseaddress+1
 */
#define nFAULT		0x08
#define FAULT		0x08
#define SELIN		0x10
#define PAPEREND	0x20
#define nACK		0x40
#define ACK			0x40
#define BUSY		0x80
#define IRQ			0x02

#define INMASK	0x84	/* BUSY input and the IRQ indicator are inverted */
			/* Use this mask only for the control input lines */
			/* XOR with this mask ( ^ OUTMASK ) */


class CCfg667xx
{
public:
	CCfg667xx();
	~CCfg667xx();
	void Load(LPCSTR lpIniFile);
	void Save(LPCSTR lpIniFile);

public:
	int		iPort;
	int		iRows;
	int		iCols;
	BYTE    byInterface;
	BOOL    bBacklight;
	BYTE	byCellW, byCellH;
	BOOL	bSplitScreens;
	int		iDelayShort;
	int     iDelayMed;
	int		iDelayLong;
	int		iDelayInit;
	int		iDelayBus;
	int		iDelayMultiplier;
	DELAY_TYPES   DelayType;
	tULongToULong charMap;
};

extern	CCfg667xx	 g_667xxCfg; 

class CLcdHD667xx : public CLcdHD44780  
{
public:
	CLcdHD667xx();
	virtual ~CLcdHD667xx();

	virtual void  Clear();
	virtual void  HBar(short nCol, short nRow, short nDir, short nLen);
	virtual BOOL  Open();
	virtual void  SetPosition(short nCol, short nRow);
	virtual void  VBar(short nCol, short nLength);
	virtual void  Write(LPCSTR lpText);
	virtual BOOL  CreateCustomChar(short nNumber, CCustomChar &cChar);
	virtual short GetMaxCustomChar();
	virtual int		GetRows();		// MZ, June 27
	virtual int		GetColumns();	// MZ, June 27

protected:
	BYTE	SECONDLCDEN, RS, LCDEN;
	BOOL	m_bSplitScreens;
	BOOL	m_bInit;
	int		lcd_x, lcd_y;

	CDevParallel44780 *m_pcDev;


	virtual void SetChar(int n, char *dat);
};

#endif // !defined(AFX_LCDHD667xx_H__284FE561_BF2B_11D3_8F31_0000E871C360__INCLUDED_)
