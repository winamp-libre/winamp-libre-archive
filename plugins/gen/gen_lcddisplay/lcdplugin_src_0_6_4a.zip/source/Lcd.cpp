/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Lcd.cpp: implementation of the CLcd class.
//
//////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2002/01/10 MZ  generic backlight timer function
// 2003/01/12 MZ  PJRC driver
// 2003/01/26 MZ  m_pInstance must not be set in constructor, moved to lcd driver's open method
// 2003/07/13 MZ  custom character map added 
// 2003/08/03 MZ  moved LCD driver definitions into CLCDFactory
//

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "Lcd.h"


UINT CLcd::m_uiBacklightTimer = 0;
CLcd  *CLcd::m_pInstance = NULL;

CLcd::CLcd() {
	m_bScroll = m_bBlink = m_bCursor = m_bLineWrap = m_bScroll = FALSE;
	m_uiBacklightTimer = 0;
	m_pInstance = NULL;
	m_nBackLight = m_nContrast = m_nBrightness = -1;
	m_lLastError = 0;
	m_bOpen = FALSE;	// per default a LCD is closed after creation, MZ 2002/11/10
}

CLcd::~CLcd() {
	KillTimer( NULL, m_uiBacklightTimer );
	m_pInstance = NULL;
}

VOID CALLBACK CLcd::BacklightTimerFunc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime ) {

	KillTimer(NULL, m_uiBacklightTimer);

	if (m_pInstance != NULL && m_pInstance->GetBacklight() != 0) {
		m_pInstance->SetBacklight(-1);
	}
}

void CLcd::StartBacklightTimer(int iSeconds)
{
	if (iSeconds > 0) {
		StopBacklightTimer();
		m_uiBacklightTimer = SetTimer(NULL, NULL, iSeconds * 1000, 
			(TIMERPROC)CLcd::BacklightTimerFunc);
	}
}

void CLcd::StopBacklightTimer()
{
	if (m_uiBacklightTimer != 0) {
		KillTimer(NULL, m_uiBacklightTimer);
		m_uiBacklightTimer = 0;
	}
}

/******************************************************************************
Function : ConvertToLCDCharset
Purpose  : Makes all special chars LCD compliant 
Parameters : Pointer to text string
Returns : Static pointer to formated text string
Author  : Markus Zehnder, 14.11.99	
******************************************************************************/
LPCSTR CLcd::ConvertTextToLCDCharset(LPSTR lpText)
{
	CString csTemp;
	csTemp = lpText;
	ConvertTextToLCDCharset(csTemp);
	strcpy(lpText, csTemp);
	return lpText;
}

LPCSTR CLcd::ConvertTextToLCDCharset(CString &csText)
{
	// process character map, MZ 2003/07/13
	char from, to;
	POSITION pos = m_charMap.First();

	while (pos != NULL) {
		from = (char)m_charMap.GetKey(pos);
		to = (char)m_charMap.GetData(pos);

		csText.Replace(from, to);

		pos = m_charMap.Next(pos);
	}

	// replace custom chars
	ConvertTagsToCustomChars(csText);

	return csText;
}



// helper functions
int BuildCharMap(LPCTSTR lpIniSectionName, LPCTSTR lpIniFile, tULongToULong &map) {

	// load character map
	char szBuffer[1024];
	GetPrivateProfileSection(lpIniSectionName, szBuffer, 1024, lpIniFile);

	char ch, chLcd;
	char *p = szBuffer;
	char *pField;
	int  count = 0;


	while (p != NULL && p[0] != '\0') {

		if (isdigit(p[0])) {
			ch = atoi(p);
		} else {
			ch = p[0];
		}

		if (ch != 0) {

			pField = strstr(p, "=");

			if (pField != NULL) {
				pField++;
				chLcd = atoi(pField);
				if (isdigit(pField[0])) {
					chLcd = atoi(pField);
				} else {
					chLcd = pField[0];
				}

				if (chLcd != 0) {
					map.Set(ch, chLcd);
					count++;
				}
			}

		}

		p += strlen(p) + 1;
	}

	return count;
}