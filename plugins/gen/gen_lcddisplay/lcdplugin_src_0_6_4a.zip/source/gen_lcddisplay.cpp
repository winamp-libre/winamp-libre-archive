/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// gen_lcddisplay.cpp:   Main file of the plugin
//
// Most important functions:
// - LCDOutputThread:  Writes the output fields to the LCD display
// - WinampPollThread: Gets data from WinAmp and formats the output fields 
// - config_read & config_write: Configuration handling
// - init    called by Winamp to initialize the plugin
// - config  called by Winamp to configure the plugin
// - quit    called by Winamp to terminate the plugin
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
//
// 13.11.99 - text alignment added, M.Zehnder
// 14.11.99 - special char replacement, M.Zehnder
// 18.11.99 - Sroll Separator Field added, F. Verhamme
// 20.11.99 - ID3-tag handling added, M.Zehnder
// 28.12.99 - major bug fixes, custom char handling, blinking song time, reverse
//            song time counting, text convert functions, M.Zehnder
// 09.01.2k - text formatting in combination with srolling fixed , M.Zehnder
// 15.06.00 - Insert functions to control the plugin via the numeric block, F. Verhamme
// 28.06.2k - bugfixes: id3 tag fields special char conversion, custom char initialization,
//            initialization without active lcd driver, MZ
// 20.07.00 - LCD Menu functions to control Winamp over LCD, F. Verhamme
// 24.07.00 - Get & Set Winamp Shuffle status, F. Verhamme
// 01.08.00 - Select Userdefined Playlists via LCD Menu, F. Verhamme
// 16.08.00 - Moved ConvertTextToLCDCharset(..) into LCD driver, removed ConvertLCDText(..), cfg dlg cosmetics, new text format option, M.Zehnder
// 18.10.00 - Aenderungen am Shuffle, Repeat hinzugefuegt
//          - Aktuelle FRONTEND.H eingebaut
//          - Changes to Keypad functions
// 19.10.00 - Auslagern der Texte in die RC Datei
// 27.01.01 - Moved keyboard functions into keyboard.cpp, spec analyzer changed (show all fields in row 1+2 when active),
//            critical section for LCD access added  M.Zehnder
// 08.07.01 - KEY_CFG added, MZ
// 19.07.01 - continuous bitrate update for VBR files, MZ
// 21.09.01 - Long Playlist / Song names correctly displayed and scrolled, long named Playlists correctly loaded, WG
//
// 2002/01/04 MZ  input drivers for keyboard, WinLIRC and COM-port, custom text for repeat and shuffle flags, repeat flag fix
// 2002/02/03 MZ - fixed isFieldInSpecAnalyzer. SA height is no longer hard coded
//               - extended minute tag added, i.e. minute display > 60
// 2002/06/12 MZ  basic implementation of automatically switching output set
// 2002/06/15 MZ  "Plugin executed illegal operation" error bug fixed
// 2002/07/07 MZ LCD access with EnterCriticalSection & LeaveCriticalSection
// 2002/11/07 MZ if the extended minute tag (3 digits) is not present allow minutes in the range of 60 - 99
// 2003/01/19 MZ replaced Windows Timer functions 'WinampTimerFunc' and 'OutputTimerFunc' with threads. (Didn't work with the input design...)
// 2003/01/21 MZ Output field update handing fixed in LCDOutputThread. All optimizations were disabled because of an incorrect boolean operation!
// 2003/01/23 MZ Included TiTi's version T4 changes (http://www.poulpy.com/lcdplugin/)
//               Simplified volume bar (timeout var instead of timer fctn)
// 2003/01/26 MZ - Delay loading of pdh.dll (NT performance monitoring) and OS check to use the plugin with W9x
//               Make sure the program is linked with "pdh.lib delayimp.lib /DELAYLOAD:pdh.dll" !!! Infos:
//               http://msdn.microsoft.com/library/default.asp?url=/library/en-us/vccore/html/vcconLinkerSupportForDelayedLoadingOfDLLs.asp
//               - quit() fixed: serious bugs in LCD drivers fixed! Hack for memory leaks in CCustomChar.
// 2003/02/09 MZ some cleanup and bugfixes
// 2003/06/07 MZ bugfix [715499] Pause, then stop, then play, back at the pause screen
//               bugfix [619116] Custom Character Scrolling
// 2003/07/11 MZ bugfix [764503] song position (%6) for songs > 60 min (function FormatTime)
//
/////////////////////////////////////////////////////////////////////////////
//
// @TODO: 
// - custom char handling: remove hard coded size, LCD drivers might support more than 8 characters
// - rewrite spectrum analyser: vis plugin must return one value per position and this plugin must do the scaling!
// - Equalizer function from TiTi's T4 is not yet working, crashes plugin!
// - translate german comments
// - testing testing testing...
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#if _MFC_VER > 0x0421
#include <delayimp.h>
#endif
#include "gen_lcddisplay.h"
#include "DlgConfig.h"
#include <process.h>
#include "LCDHD44780.h"
#include "ScreenSimLcd.h"
#include "LcdCrystalFontz.h"
#include "LcdNoritake.h"
#include "LcdScottEdwards.h"
#include "LcdHD667xx.h"
#include "LcdSED153X.h"

#include "LCDMenuShow.h"

#include "DlgInputKeyboard.h"
#include "DlgInputWinampKeyboard.h"
#include "DlgInputWinLIRC.h"
#include "DlgInputSerial.h"
#include "DlgInputParallel.h"
#include "DlgPageAdditional.h"
#include "DlgPageAbout.h"
#include "DlgPageMenu.h"
#include "perfmon.h"
#include "DynaMenus.h"
#include "DlgHidden.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// ---------------  L O C A L   F U N C T I O N S  ----------------------------

void  config();
void  quit();
int   init();
LPSTR ConvertText(LPSTR lpText);
BOOL isFieldInSpecAnalyzer(COutputField *pcField);
BOOL isFieldInVolumeBar(COutputField *pcField);

// ---------------  L O C A L   V A R I A B L E S  ----------------------------

static DWORD  _dwVolBarEndTime;

CRITICAL_SECTION critSecLCDWrite;

extern tMenuLine*	g_pPlayListMenu;
extern tMenuLine*	g_pEquaMenu;
extern int			g_iIdx;

int SearchPlaylists(CString sDirName, tMenuLine* &pPlayListMenu, BOOL bFirst = FALSE, BOOL bRecursive = TRUE);
int compare(const void *arg1, const void *arg2);
// ---------------  G L O B A L   V A R I A B L E S  --------------------------

winampGeneralPurposePlugin g_Plugin =
{
    GPPHDR_VER,
    "",
    init,
    config,
    quit,
};

char               g_szAppName[255];
char               g_szAppVer[50];
char               g_szIniFile[MAX_PATH];
CString			   g_ConfigPath;
BYTE               g_byCurrSet, g_byMaxSets;
WINAMP_INFO        g_WinAmpInfo;
CONFIG             g_Config;
UINT               g_uiScrollTimer;
BOOL               g_bOutput = TRUE, g_bUpdateAll = FALSE;
BOOL               g_bComPortOpen = FALSE;
RWLock             g_OutputLock;
SPECTRUM_ANALYSER  g_Spectrum_Analyser; //structure for the spectrum analyser
UINT			   g_uiMenuTimer1, g_uiMenuTimer2;
CLCDFactory        g_LCDFactory;
CLcd               *g_LCD = NULL;
CInputWinLIRC	   g_InWinLIRC;
CInputKeyboard	   g_InKeyboard;
CInputWinampKeyboard	g_InWinampKeyboard;
CInputSerial	   g_InSerial;
CInputParallel	   g_InParallel;
int				   g_CounterCPU;
int				   g_CounterMEM;
bool			   g_bEqua = FALSE;
int				   g_uiEquaTimer;
int				   g_uiEquaBand;
BOOL			   g_uiEquaSpec;
CPerfMon		   *g_pPerfMon;
tCurrMenu		   sCurrMenu;        // menu structure
HHOOK              hHook;
CDynaMenus		   g_DynaMenus;
//Sleep-Timer
UINT			   g_uiSleepTimer;
BOOL			   g_bSleepActive = false;
int				   g_iSleepTime;

// FVerhamm
BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	TRACE("In _DllMainCRTStartup\n");
    return TRUE;
}
// FVerhamm

/******************************************************************************
Function : winampGetGeneralPurposePlugin
Purpose  : Identifies this dll as a general purpose plugin for WinAmp.
Parameters : -
Returns : Pointer to winampGeneralPurposePlugin structure.
Author  : Markus Zehnder    
******************************************************************************/
__declspec( dllexport ) winampGeneralPurposePlugin * winampGetGeneralPurposePlugin()
{
    return &g_Plugin;
}

__declspec( dllexport ) int DebugInit(HWND hwndParent, HINSTANCE hDllInstance)
{
	TRACE("In DebugInit\n");

	g_Plugin.hwndParent = hwndParent;
	g_Plugin.hDllInstance = hDllInstance;
	return init();
}

/******************************************************************************
Function : init
Purpose  : Plugin initialization, called by WinAmp
Parameters : -
Returns : int (?)
Author  : Markus Zehnder    
******************************************************************************/
int init()
{
    char        szBuffer1[512], szBuffer2[512];

    AFX_MANAGE_STATE(AfxGetStaticModuleState());

	g_Config.eInitStatus = IN_PROGRESS;
    
	try
    {
        static char c[512];
        char        filename[512],*p;

		// check if we're running under NT: some functions of the plugin only work in NT!
		OSVERSIONINFO versionInfo;
		versionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
		::GetVersionEx(&versionInfo);
		g_Config.bWinNT = (versionInfo.dwPlatformId == VER_PLATFORM_WIN32_NT);
        
		InitializeCriticalSection(&critSecLCDWrite);
		
		g_byCurrSet = 0;
		g_byMaxSets = 1;
		g_Config.pcVolume = NULL;
		g_Config.iSaveSet = 0;
		g_pPerfMon = NULL;

        // FVerhamm
        g_Spectrum_Analyser.active = 0;
        g_Spectrum_Analyser.char_loaded = 0;
            
        memset( &sCurrMenu, 0, sizeof(tCurrMenu)); // Die Menuevariable mit '0' initialisieren
        //FVerhamm

        // Get Application Name and Version
        LoadString(g_Plugin.hDllInstance, IDS_APPNAME, g_szAppName, sizeof(g_szAppName));
        LoadString(g_Plugin.hDllInstance, IDS_APPVER, g_szAppVer, sizeof(g_szAppVer));

        g_WinAmpInfo.iVersion = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETVERSION);    // Winamp Version in globale Struktur eintragen
        if (g_WinAmpInfo.iVersion < REQ_WINAMP_VERSION)                                         // Vergleich der Winamp Version
        {
            LoadString(g_Plugin.hDllInstance, IDS_WARN1, szBuffer1, sizeof(szBuffer1));
            wsprintf(szBuffer2, szBuffer1, MAJOR_VER(REQ_WINAMP_VERSION), MINOR_VER(REQ_WINAMP_VERSION));

            if (IDNO == MessageBox( g_Plugin.hwndParent, szBuffer2, g_szAppName, MB_YESNO | MB_ICONEXCLAMATION )) {
				g_Config.eInitStatus = FAILED;
                return 0;
			}
        }

        GetModuleFileName(g_Plugin.hDllInstance,filename,sizeof(filename));                     // Plugindateiname holen

        p = filename+lstrlen(filename);                                                         // Zeiger p ans Ende setzen
        while (p >= filename && *p != '\\')                                                     // Pfad abschneiden
            p--;
        wsprintf((g_Plugin.description=c),"%s %s (%s)",g_szAppName, g_szAppVer, p+1);       // Infos zusammen
    
        if (++p >= filename) *p = 0;                                                            // Zeiger p  auf 0 setzen
        strcpy(g_szIniFile, filename);                                                          // Pluginpfad in globale Variable eintragen
        strcat(g_szIniFile, CONFIG_FILE);                                                       // gen_LCD.INI anh�ngen

		g_ConfigPath = filename;

        config_read(g_szIniFile);                                                               // auslesen der Config-Datei

		g_InWinLIRC.ReadConfig(g_szIniFile);
		g_InKeyboard.ReadConfig(g_szIniFile);
		g_InWinampKeyboard.ReadConfig(g_szIniFile);
		g_InSerial.ReadConfig(g_szIniFile);
		g_InParallel.ReadConfig(g_szIniFile);

        if (!InitRWLock( &g_OutputLock ))
        {
			g_Config.eInitStatus = FAILED;
            LoadString(g_Plugin.hDllInstance, IDS_WARN2, szBuffer1, sizeof(szBuffer1));
            MessageBox( g_Plugin.hwndParent, szBuffer1, g_szAppName, MB_OK | MB_ICONERROR );
            return 0;
        }

		// bugfix: WinNT 4.0 hangs with certain sound drivers! --> option to disable volume variable, MZ April 17
		if (g_Config.byVolSource != 255 )
		{
			g_Config.pcVolume = new CVolume();
	        g_Config.pcVolume->SetCallbackVar(&g_WinAmpInfo.byVolume, g_Config.byVolSource);
		}


        g_LCD = g_LCDFactory.GetLCDDriver();                                                    // Seriellen/Parallelen Treiber laden

        if (g_LCD == NULL)
        {
			g_Config.eInitStatus = FAILED;
            LoadString(g_Plugin.hDllInstance, IDS_WARN3, szBuffer1, sizeof(szBuffer1));
            MessageBox( g_Plugin.hwndParent, szBuffer1, g_szAppName, MB_OK | MB_ICONERROR );
            return 0;
        }

        if (g_Config.bAutoOpen)
        {
          if (!g_LCDFactory.OpenLCD(g_LCD))
            g_LCD = NULL;                   // bugfix: if open failed disable driver, MZ August 17 2k
        }
		if (g_Config.bAutoAnalyser)
		{
			g_Spectrum_Analyser.active=1;
		}
		if (g_Config.bFalloff)
		{
			g_Spectrum_Analyser.falloff=1;
		}
	
		// Input devices
		if (g_Config.bWLEnabled)
			g_InWinLIRC.InitDevice();

		if (g_Config.bEnableKeypad)
			g_InKeyboard.InitDevice();

		if (g_Config.bEnableWinampKeypad)
			g_InWinampKeyboard.InitDevice();

		if (g_Config.bInSerialEnabled)
			g_InSerial.InitDevice();

		if (g_Config.bInParallelEnabled)
			g_InParallel.InitDevice();

		if (g_Config.bPerfMonEnabled) {
			if (g_Config.bPerfMonForce || g_Config.bWinNT) {
				g_pPerfMon = new CPerfMon();

				if (!g_pPerfMon->Initialize()) {
					AfxMessageBox("PerfMon did not initialize properly!");
				} else {
					g_CounterCPU = g_pPerfMon->AddCounter(CNTR_CPU);
					g_CounterMEM = g_pPerfMon->AddCounter(CNTR_MEMINUSE_PERCENT);
				//	ASSERT(g_CounterCPU > -1 && g_CounterMEM > -1);
				}
			}
		}
	
		g_Config.bSpinCharOK = FALSE;

		// Parse all playlists
		g_pPlayListMenu = NULL;
		g_pEquaMenu = NULL;

		g_iIdx = SearchPlaylists(g_Config.szPlaylistPathUser, g_pPlayListMenu, TRUE, g_Config.bPLrecursive);

		if (g_iIdx == 0) {
			// no playlists found
			g_pPlayListMenu = (tMenuLine*)realloc(g_pPlayListMenu, sizeof(tMenuLine));
			strcpy(g_pPlayListMenu[0].cTextBuff, "");
			g_pPlayListMenu[0].idText = IDS_NO_PLAYLIST;
			g_pPlayListMenu[0].pActionFunc = NULL;
			g_iIdx++;
		}

   
		if (g_Config.bPLsort) {
			qsort((void*)g_pPlayListMenu, (size_t)g_iIdx, sizeof (tMenuLine), compare);
		}

    	// ### THAT IS VERY DIRTY : Load Dynamic Menus from serialization
		TRACE("Loading Custom menu from serialization");
		CDlgHidden dlg;
		dlg.DoModal();
		TRACE("Done Loading Custom menu from serialization");

		g_Config.eInitStatus = OK;
    }
    catch(...)
    {
		g_Config.eInitStatus = FAILED;
        LoadString(g_Plugin.hDllInstance, IDS_WARN4, szBuffer1, sizeof(szBuffer1));
        MessageBox( g_Plugin.hwndParent, szBuffer1, g_szAppName, MB_ICONSTOP );
        if (g_LCD)
            g_LCDFactory.CloseLCD();
    }   

    return 0;
}

/******************************************************************************
Function : config
Purpose  : Plugin configuration, called by WinAmp
Parameters : -
Returns : void
Author  : Markus Zehnder    
******************************************************************************/
void config()
{
    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    char szOldDriver[20], szBuffer1[512];
    strcpy(szOldDriver, g_Config.szDriver);


	// disable keyboard hook, MZ April 27 01
    if (hHook)
        UnhookWindowsHookEx(hHook);
	g_InKeyboard.CloseDevice();
	g_InWinampKeyboard.CloseDevice();

	// display cfg dlg
    CDlgConfig  cDlg( g_szAppName );

    // g_bOutput = FALSE;
	g_LCDFactory.EnableOutput(FALSE);

    if (g_LCD != NULL)
    {
		EnterCriticalSection(&critSecLCDWrite);
        LoadString(g_Plugin.hDllInstance, IDS_CONFIG, szBuffer1, sizeof(szBuffer1));
		g_LCD->Home();
        g_LCD->Write( szBuffer1 );
		LeaveCriticalSection(&critSecLCDWrite);
    }

    try
    {
		CComboPage	comboPage(IDD_PAGE_INPUT);
		CDlgInputWinLIRC  cInWinLirc;
		CDlgInputKeyboard cInKeyboard;
		CDlgInputWinampKeyboard cInWinampKeyboard;
		CDlgInputSerial   cInSerial;
		CDlgInputParallel cInParallel;

		comboPage.AddPage(&cInKeyboard, cInKeyboard.IDD);
		comboPage.AddPage(&cInWinampKeyboard, cInWinampKeyboard.IDD);
		comboPage.AddPage(&cInWinLirc,  cInWinLirc.IDD);
		comboPage.AddPage(&cInSerial,   cInSerial.IDD);
		comboPage.AddPage(&cInParallel, cInParallel.IDD);

		CDlgPageAbout cPageAbout;
		CDlgPageMenu  cPageMenu;
		CDlgPageAdditional cPageAdditional;

		cDlg.AddPage(&comboPage);
		cDlg.AddPage(&cPageMenu);
		cDlg.AddPage(&cPageAdditional);
		cDlg.AddPage(&cPageAbout);

        if (IDOK == cDlg.DoModal())
        {   // save LCD configurations
			// @TODO remove all LCD driver dependencies: this should be the job of CLCDFactory!
			g_44780Cfg.Save(g_szIniFile);
			g_667xxCfg.Save(g_szIniFile);
			g_MOCfg.Save(g_szIniFile);
			g_SimCfg.Save(g_szIniFile);
			g_CFCfg.Save(g_szIniFile);
			g_NoritakeCfg.Save(g_szIniFile);
			g_SECfg.Save(g_szIniFile);
			g_SEDCfg.Save(g_szIniFile);
        }
    }
    catch(...)
    {
        LoadString(g_Plugin.hDllInstance, IDS_WARN5, szBuffer1, sizeof(szBuffer1));
        MessageBox( g_Plugin.hwndParent, szBuffer1, g_szAppName, MB_ICONSTOP );
    }

    if(stricmp(g_Config.szDriver, szOldDriver) == 0)
    {
        if (g_LCD != NULL) {
			EnterCriticalSection(&critSecLCDWrite);
            g_LCD->Clear();
			LeaveCriticalSection(&critSecLCDWrite);
		}
    }
    else
    {
        // terminate old LCD driver
        g_LCDFactory.CloseLCD();
        g_LCD = NULL;
        config_write(g_szIniFile); 
		g_InWinLIRC.WriteConfig(g_szIniFile);
		g_InKeyboard.WriteConfig(g_szIniFile);
		g_InWinampKeyboard.WriteConfig(g_szIniFile);
		g_InSerial.WriteConfig(g_szIniFile);
		g_InParallel.WriteConfig(g_szIniFile);

        // load new LCD driver
        g_LCD = g_LCDFactory.GetLCDDriver();    // Seriellen/Parallelen Treiber laden

    }

    g_Config.cOutputFields.Init();

    if(g_Config.bAutoOpen && (stricmp(g_Config.szDriver, szOldDriver) != 0))
    {
        if (!g_LCDFactory.OpenLCD(g_LCD))
            g_LCD = NULL;                   // bugfix: if open failed disable driver, MZ August 17 2k
    }

    if (g_Config.bEnableKeypad)
		g_InKeyboard.InitDevice();
	else
		g_InKeyboard.CloseDevice();

    if (g_Config.bEnableWinampKeypad)
		g_InWinampKeyboard.InitDevice();
	else
		g_InWinampKeyboard.CloseDevice();
	
	
	g_LCDFactory.EnableOutput(TRUE);
}

/******************************************************************************
Function : quit
Purpose  : Plugin cleanup, called by WinAmp
Parameters : -
Returns : void
Author  : Markus Zehnder    
******************************************************************************/
void quit()
{
    g_Spectrum_Analyser.active = 0;

    AFX_MANAGE_STATE(AfxGetStaticModuleState());

    ::KillTimer( NULL, g_uiScrollTimer );
    //g_LCDFactory.Terminate();

	g_LCDFactory.EnableOutput(FALSE);


    config_write(g_szIniFile);
	g_InWinLIRC.WriteConfig(g_szIniFile);
	g_InKeyboard.WriteConfig(g_szIniFile);
	g_InWinampKeyboard.WriteConfig(g_szIniFile);
	g_InSerial.WriteConfig(g_szIniFile);
	g_InParallel.WriteConfig(g_szIniFile);
    g_Config.cOutputFields.Clear();
	g_InWinLIRC.CloseDevice();
	g_InKeyboard.CloseDevice();
	g_InWinampKeyboard.CloseDevice();
	g_InSerial.CloseDevice();
	g_InParallel.CloseDevice();

	if (g_Config.pcVolume) {
		delete g_Config.pcVolume;
		g_Config.pcVolume = NULL;
	}

	if (g_pPerfMon) {
		g_pPerfMon->RemoveCounter(g_CounterCPU);
		g_pPerfMon->RemoveCounter(g_CounterMEM);
		g_pPerfMon->Uninitialize();

		delete g_pPerfMon;
		g_pPerfMon = NULL;
	}

    if (hHook) {
        UnhookWindowsHookEx(hHook);
		hHook = NULL;
	}

    g_LCDFactory.Terminate();

	/* MZ 20030803 seems to work now -> re-test...
	// @hack free allocated memory from the custom characters, somehow the destructor doesn't get called !? MZ 2003/01/26
	for (int i=0; i < MAX_SYSTEM_CCHAR; i++) {
		g_Config.carrCustomChar[i].Uninitialize();
	}
	for (i=0; i < MAX_CUSTOM_CHAR + 1; i++) {
		g_Config.carrMenueChar[i].Uninitialize();
	}
	*/

	CString   key;
	INPUT_BTN *btn;

	for (POSITION pos = g_Config.mapInSerial.GetStartPosition(); pos != NULL; ){
		g_Config.mapInSerial.GetNextAssoc( pos, key, (void*&)btn );
		delete btn;
	}

	for (pos = g_Config.mapInWinLirc.GetStartPosition(); pos != NULL; ){
		g_Config.mapInWinLirc.GetNextAssoc( pos, key, (void*&)btn );
		delete btn;
	}

	for (pos = g_Config.mapInParallel.GetStartPosition(); pos != NULL; ){
		g_Config.mapInParallel.GetNextAssoc( pos, key, (void*&)btn );
		delete btn;
	}
/*
	// release all keyboard keys, MZ 2003/07/13
	// --> Winamp doesn't terminate anymore with a release build!? strange...
	WORD    wKey;
    KB_KEY* pe;

	for (pos = g_Config.mapKBcfg.GetStartPosition(); pos != NULL; ){
		g_Config.mapKBcfg.GetNextAssoc( pos, wKey, (void*&)pe );
		delete pe;
	}

	for (pos = g_Config.mapKBcfg_menu.GetStartPosition(); pos != NULL; ){
		g_Config.mapKBcfg_menu.GetNextAssoc( pos, wKey, (void*&)pe );
		delete pe;
	}

	for (pos = g_Config.mapKBcfg_set.GetStartPosition(); pos != NULL; ){
		g_Config.mapKBcfg_set.GetNextAssoc( pos, wKey, (void*&)pe );
		delete pe;
	}

	for (pos = g_Config.mapWAKBcfg.GetStartPosition(); pos != NULL; ){
		g_Config.mapWAKBcfg.GetNextAssoc( pos, wKey, (void*&)pe );
		delete pe;
	}

	for (pos = g_Config.mapWAKBcfg_menu.GetStartPosition(); pos != NULL; ){
		g_Config.mapWAKBcfg_menu.GetNextAssoc( pos, wKey, (void*&)pe );
		delete pe;
	}

	for (pos = g_Config.mapWAKBcfg_set.GetStartPosition(); pos != NULL; ){
		g_Config.mapWAKBcfg_set.GetNextAssoc( pos, wKey, (void*&)pe );
		delete pe;
	}

*/
    DeleteCriticalSection(&critSecLCDWrite);
}


/******************************************************************************
Function : config_read
Purpose  : Reads the configuration from the ini file into the global structure
           g_Config.
Parameters : lpIniFile: ini file name
Returns : void
Author  : Markus Zehnder    
******************************************************************************/
void config_read(LPCSTR lpIniFile)
{
    char    *p;
    char    szBuffer[10000];
    char	stmp[16];
	COutputField *pcField = NULL;

    LoadString(g_Plugin.hDllInstance, IDS_STATUS_PAUSE, szBuffer, sizeof(szBuffer));    
	GetPrivateProfileString( SECTION_NAME, "Str_Pause", szBuffer, g_Config.szPause, MAX_STATUS_STRLEN, lpIniFile);

    LoadString(g_Plugin.hDllInstance, IDS_STATUS_STOP, szBuffer, sizeof(szBuffer));
    GetPrivateProfileString( SECTION_NAME, "Str_Stop", szBuffer, g_Config.szStop, MAX_STATUS_STRLEN, lpIniFile);

    LoadString(g_Plugin.hDllInstance, IDS_STATUS_PLAY, szBuffer, sizeof(szBuffer));
    GetPrivateProfileString( SECTION_NAME, "Str_Play", szBuffer, g_Config.szPlay, MAX_STATUS_STRLEN, lpIniFile);

	GetPrivateProfileString( SECTION_NAME, "VolBarLen", "10", stmp, 10, lpIniFile);
	g_Config.iVolBarLen = atoi(stmp);

	GetPrivateProfileString( SECTION_NAME, "VolBarWidth", "38", stmp, 10, lpIniFile);
	g_Config.iVBwidth = atoi(stmp);
	GetPrivateProfileString( SECTION_NAME, "VolBarCol", "1", stmp, 10, lpIniFile);
	g_Config.iVBcol = atoi(stmp);
	GetPrivateProfileString( SECTION_NAME, "VolBarRow", "2", stmp, 10, lpIniFile);
	g_Config.iVBrow = atoi(stmp);
	GetPrivateProfileString( SECTION_NAME, "VolBarActivate", "0", stmp, 10, lpIniFile);
	g_Config.bTempVB = atoi(stmp);
	GetPrivateProfileString( SECTION_NAME, "VolBarChar", "0xFF", stmp, MAX_VB_CHAR, lpIniFile);
	// convert character
	if (strncmp(stmp, "0x", 2) == 0) {
		sscanf(stmp, "%x", &g_Config.szVBchar[0]);
		g_Config.szVBchar[1] = '\0';
	} else {
		strcpy(g_Config.szVBchar, stmp);
	}

	GetPrivateProfileString( SECTION_NAME, "EquaType", "0", stmp, 10, lpIniFile);
	g_Config.iEquaType = atoi(stmp);

	GetPrivateProfileString( SECTION_NAME, "SwitchPause", "0", stmp, 10, lpIniFile);
	g_Config.iSwitchPause = atoi(stmp);
	GetPrivateProfileString( SECTION_NAME, "SwitchStop", "0", stmp, 10, lpIniFile);
	g_Config.iSwitchStop = atoi(stmp);

    LoadString(g_Plugin.hDllInstance, IDS_ON, szBuffer, sizeof(szBuffer));
    GetPrivateProfileString( SECTION_NAME, "Str_ShuffleOn", szBuffer, g_Config.szShuffleOn, MAX_STATUS_STRLEN, lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Str_RepeatOn", szBuffer, g_Config.szRepeatOn, MAX_STATUS_STRLEN, lpIniFile);
    LoadString(g_Plugin.hDllInstance, IDS_OFF, szBuffer, sizeof(szBuffer));
    GetPrivateProfileString( SECTION_NAME, "Str_ShuffleOff", szBuffer, g_Config.szShuffleOff, MAX_STATUS_STRLEN, lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Str_RepeatOff", szBuffer, g_Config.szRepeatOff, MAX_STATUS_STRLEN, lpIniFile);

    GetPrivateProfileString( SECTION_NAME, "TimeFormat", DEF_TIME_FORMAT, g_Config.szTimeFormat, MAX_TIME_STRLEN, lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "SysTimeFormat", DEF_SYSTIME_FORMAT, g_Config.szDateTimeFormat, MAX_TIME_STRLEN, lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Driver", DEF_DRIVER, g_Config.szDriver, sizeof(g_Config.szDriver), lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Str_ScrollSeparator", DEF_SCROLL_SEPARATOR, g_Config.szScrollSeparator, MAX_STATUS_STRLEN, lpIniFile);
    GetPrivateProfileString( SECTION_NAME, "Str_ScrollSeparator2", DEF_SCROLL_SEPARATOR2, g_Config.szScrollSeparator2, MAX_STATUS_STRLEN, lpIniFile);
	if (g_Config.szScrollSeparator[0] == '"')
    {
        strncpy(szBuffer, g_Config.szScrollSeparator + 1, strlen(g_Config.szScrollSeparator) - 2);
        strcpy(g_Config.szScrollSeparator, szBuffer);
    }
    if (g_Config.szScrollSeparator2[0] == '"')
    {
        strncpy(szBuffer, g_Config.szScrollSeparator2 + 1, strlen(g_Config.szScrollSeparator2) - 2);
        strcpy(g_Config.szScrollSeparator2, szBuffer);
    }

    GetPrivateProfileString( SECTION_NAME, "Str_PlaylistPathUser", DEF_PLAYLISTPATHUSER, g_Config.szPlaylistPathUser, MAX_STATUS_STRLEN, lpIniFile);
    if (g_Config.szPlaylistPathUser[0] == '"')
    {
        strncpy(szBuffer, g_Config.szPlaylistPathUser + 1, strlen(g_Config.szPlaylistPathUser) - 2);
        strcpy(g_Config.szPlaylistPathUser, szBuffer);
    }
	// playlist path must end with a back slash, MZ 2001/12/30
	p = g_Config.szPlaylistPathUser + lstrlen(g_Config.szPlaylistPathUser) -1;
	if( *p != '\\')
		strcat(g_Config.szPlaylistPathUser, "\\");


    g_Config.bAutoOpen  =  GetPrivateProfileInt(SECTION_NAME,"AutoOpen",1,lpIniFile); 
	g_Config.bBacklight =  GetPrivateProfileInt(SECTION_NAME,"SetBacklight",1,lpIniFile); 
    g_Config.iBacklightTimeout = GetPrivateProfileInt(SECTION_NAME,"Timeout",0,lpIniFile); 
    if (g_Config.iBacklightTimeout < 1)
        g_Config.iBacklightTimeout = 0;

    g_Config.dwSwitchSetTimeout = (DWORD)GetPrivateProfileInt(SECTION_NAME,"SwitchSetTimeout",0,lpIniFile); 

    g_Config.byTimeoutType = (BYTE)GetPrivateProfileInt(SECTION_NAME,"TimeoutType",TIMEOUT_GLOBAL,lpIniFile); 
    g_Config.bOutput =     GetPrivateProfileInt(SECTION_NAME,"ShowOutput",1,lpIniFile); 
    g_Config.bRowMode =    GetPrivateProfileInt(SECTION_NAME,"RowMode",1,lpIniFile); 
    g_Config.byLCDRefresh = (BYTE)GetPrivateProfileInt(SECTION_NAME,"LCDRefresh", DEF_LCDREFRESH,lpIniFile); 
    if (g_Config.byLCDRefresh < 1)
        g_Config.byLCDRefresh = 4;

    g_Config.byWinAmpPoll = (BYTE)GetPrivateProfileInt(SECTION_NAME,"WinAmpPoll",DEF_WINAMPPOLL,lpIniFile); 
    if (g_Config.byWinAmpPoll < 1)
        g_Config.byWinAmpPoll = 5;

    g_Config.bLocal =      GetPrivateProfileInt(SECTION_NAME,"LocalLCD",1,lpIniFile); 
    g_Config.byScrollSpeed = (BYTE)GetPrivateProfileInt(SECTION_NAME,"ScrollSpeed", DEF_SCROLLSPEED,lpIniFile); 
    g_Config.byScrollSteps = (BYTE)GetPrivateProfileInt(SECTION_NAME,"ScrollSteps", DEF_SCROLLSTEPS,lpIniFile); 
    g_Config.iScrollTimeStart = GetPrivateProfileInt(SECTION_NAME,"ScrollTimeStart",DEF_SCROLLTIMESTART,lpIniFile); 
    g_Config.iScrollTimeStep  = GetPrivateProfileInt(SECTION_NAME,"ScrollTimeStep", DEF_SCROLLTIMESTEP,lpIniFile); 
    g_Config.byTxtConv = (BYTE)GetPrivateProfileInt(SECTION_NAME,"TextConversion", DEF_TXT_CONV,lpIniFile); 
    g_Config.bTrimLeading = (BOOLEAN)GetPrivateProfileInt(SECTION_NAME,"TrimLeading", TRUE,lpIniFile); 
    g_Config.bTrimTrailing = (BOOLEAN)GetPrivateProfileInt(SECTION_NAME,"TrimTrailing", TRUE,lpIniFile); 
    g_Config.bTimeBlink = (BOOLEAN)GetPrivateProfileInt(SECTION_NAME,"BlinkTime", TRUE,lpIniFile); 
    g_Config.bTimeFwd = (BOOLEAN)GetPrivateProfileInt(SECTION_NAME,"TimeFwd", TRUE,lpIniFile); 
    g_Config.byVolSource = (BYTE)GetPrivateProfileInt(SECTION_NAME,"SourceVolume", VOLUME_MASTER,lpIniFile); 
    g_Config.bEnableKeypad  =  GetPrivateProfileInt(SECTION_NAME,"EnableKeypad",1,lpIniFile);


    // output strings
//    ClearOutputFields();                                    // Loescht das Display

    // check if new version (with text alignment) is available
    GetPrivateProfileString( SECTION_NAME, "Fields v2", "", szBuffer, sizeof(szBuffer), lpIniFile);
	g_Config.cOutputFields.LoadFromCfgString(szBuffer);


    // custom characters
    GetPrivateProfileString( SECTION_NAME, "CustomChars", "", szBuffer, sizeof(szBuffer), lpIniFile);
    char *p2 = szBuffer, *pEnd = p2 + strlen(p2);
    int  i = 0, iSize = strlen(szBuffer);

    p = strtok(p2, "|");

    while (p != NULL)
    {
        if (i == MAX_CUSTOM_CHAR)
            break;
        g_Config.carrCustomChar[i++].Set(p);
        p2 += strlen(p) + 1;
        if (p2 >= pEnd)
            break;
        p = strtok(p2, "|");
    }

	// spectrum analyser
	g_Config.bAutoAnalyser = GetPrivateProfileInt(SECTION_NAME,"SA_AutoStart",0,lpIniFile);
	g_Config.bFalloff  = GetPrivateProfileInt(SECTION_NAME,"SA_falloff",1,lpIniFile);
	g_Config.iSAcol    = GetPrivateProfileInt(SECTION_NAME,"SA_col",1,lpIniFile);
	g_Config.iSArow    = GetPrivateProfileInt(SECTION_NAME,"SA_row",4,lpIniFile);
	g_Config.iSAwidth  = GetPrivateProfileInt(SECTION_NAME,"SA_width",20,lpIniFile);
	g_Config.iSAheight = GetPrivateProfileInt(SECTION_NAME,"SA_height",4,lpIniFile);

	// playlist, MZ 2001/12/30
	g_Config.bPLsort = GetPrivateProfileInt(SECTION_NAME,"PL_sort",1,lpIniFile);
	g_Config.bPLrecursive = GetPrivateProfileInt(SECTION_NAME,"PL_recursive",0,lpIniFile);

	// performance counter, MZ 2003/01/26
	g_Config.bPerfMonEnabled = GetPrivateProfileInt(SECTION_NAME,"PerfMonEnabled",1,lpIniFile);
	g_Config.bPerfMonForce  = GetPrivateProfileInt(SECTION_NAME,"PerfMonForce",0,lpIniFile);

	// system shutdown & hibernation, MZ 2003/07/10
    GetPrivateProfileString(SECTION_NAME, "Shutdown_msg_hibernate", "Hibernate", g_Config.szLCDMsgHibernate, MAX_LCD_MSG_STRLEN, lpIniFile);
    GetPrivateProfileString(SECTION_NAME, "Shutdown_msg_standby", "Standby", g_Config.szLCDMsgStandby, MAX_LCD_MSG_STRLEN, lpIniFile);
    GetPrivateProfileString(SECTION_NAME, "Shutdown_msg_shutdown", "System is shutting down...", g_Config.szLCDMsgShutdown, MAX_LCD_MSG_STRLEN, lpIniFile);
    GetPrivateProfileString(SECTION_NAME, "Shutdown_msg_reboot", "System is rebooting...", g_Config.szLCDMsgReboot, MAX_LCD_MSG_STRLEN, lpIniFile);
	g_Config.bShutdownForce  = GetPrivateProfileInt(SECTION_NAME,"Shutdown_force",0,lpIniFile);
	g_Config.bySleepFunction = GetPrivateProfileInt(SECTION_NAME,"Sleep_shutdown", SYSTEM_SHUTDOWN, lpIniFile);
}

/******************************************************************************
Function : config_write
Purpose  : Saves the configuration from the global structure g_Config into the
           ini file.
Parameters : lpIniFile: ini file name
Returns : void
Author  : Markus Zehnder    
******************************************************************************/
void config_write(LPCSTR lpIniFile)
{
    char string[32];
	char stmp[16];
    CString csBuffer;

    WritePrivateProfileString( SECTION_NAME, "TimeFormat", g_Config.szTimeFormat, lpIniFile);
    WritePrivateProfileString( SECTION_NAME, "Str_Play", g_Config.szPlay, lpIniFile);
    WritePrivateProfileString( SECTION_NAME, "Str_Pause", g_Config.szPause, lpIniFile);
    WritePrivateProfileString( SECTION_NAME, "Str_Stop", g_Config.szStop, lpIniFile);
    WritePrivateProfileString( SECTION_NAME, "SysTimeFormat", g_Config.szDateTimeFormat, lpIniFile);
    WritePrivateProfileString( SECTION_NAME, "Driver", g_Config.szDriver, lpIniFile);

    WritePrivateProfileString( SECTION_NAME, "Str_ShuffleOn", g_Config.szShuffleOn, lpIniFile);
    WritePrivateProfileString( SECTION_NAME, "Str_RepeatOn", g_Config.szRepeatOn, lpIniFile);
    WritePrivateProfileString( SECTION_NAME, "Str_ShuffleOff", g_Config.szShuffleOff, lpIniFile);
    WritePrivateProfileString( SECTION_NAME, "Str_RepeatOff", g_Config.szRepeatOff, lpIniFile);

	sprintf(stmp, "%d", g_Config.iVolBarLen);
	WritePrivateProfileString( SECTION_NAME, "VolBarLen", stmp, lpIniFile);

	sprintf(stmp, "%d", g_Config.iVBcol);
	WritePrivateProfileString( SECTION_NAME, "VolBarCol", stmp, lpIniFile);
	sprintf(stmp, "%d", g_Config.iVBrow);
	WritePrivateProfileString( SECTION_NAME, "VolBarRow", stmp, lpIniFile);
	sprintf(stmp, "%d", g_Config.iVBwidth);
	WritePrivateProfileString( SECTION_NAME, "VolBarWidth", stmp, lpIniFile);
	sprintf(stmp, "%d", g_Config.bTempVB);
	WritePrivateProfileString( SECTION_NAME, "VolBarActivate", stmp, lpIniFile);

	sprintf(stmp, "%d", g_Config.iEquaType);
	WritePrivateProfileString( SECTION_NAME, "EquaType", stmp, lpIniFile);

	sprintf(stmp, "%d", g_Config.iSwitchPause);
	WritePrivateProfileString( SECTION_NAME, "SwitchPause", stmp, lpIniFile);
	sprintf(stmp, "%d", g_Config.iSwitchStop);
	WritePrivateProfileString( SECTION_NAME, "SwitchStop", stmp, lpIniFile);

    //FVerhamme
    csBuffer = "\""; csBuffer+=g_Config.szScrollSeparator; csBuffer+="\"";
    WritePrivateProfileString( SECTION_NAME, "Str_ScrollSeparator", csBuffer, lpIniFile);
	csBuffer = "\""; csBuffer+=g_Config.szScrollSeparator2; csBuffer+="\"";
	WritePrivateProfileString( SECTION_NAME, "Str_ScrollSeparator2", csBuffer, lpIniFile);
    csBuffer = "\""; csBuffer+=g_Config.szPlaylistPathUser; csBuffer+="\"";
    WritePrivateProfileString( SECTION_NAME, "Str_PlaylistPathUser", csBuffer, lpIniFile);

    wsprintf(string,"%d",g_Config.bAutoOpen);
    WritePrivateProfileString(SECTION_NAME,"AutoOpen",string,lpIniFile);
	wsprintf(string,"%d",g_Config.bBacklight);
    WritePrivateProfileString(SECTION_NAME,"SetBacklight",string,lpIniFile);
    wsprintf(string,"%d",g_Config.iBacklightTimeout);
    WritePrivateProfileString(SECTION_NAME,"Timeout",string,lpIniFile);
    wsprintf(string,"%d",g_Config.dwSwitchSetTimeout);
    WritePrivateProfileString(SECTION_NAME,"SwitchSetTimeout",string,lpIniFile);
    wsprintf(string,"%d",g_Config.byTimeoutType);
    WritePrivateProfileString(SECTION_NAME,"TimeoutType",string,lpIniFile);
    wsprintf(string,"%d",g_Config.bOutput);
    WritePrivateProfileString(SECTION_NAME,"ShowOutput",string,lpIniFile);
    wsprintf(string,"%d",g_Config.bRowMode);
    WritePrivateProfileString(SECTION_NAME,"RowMode",string,lpIniFile);
    wsprintf(string,"%d",g_Config.byLCDRefresh);
    WritePrivateProfileString(SECTION_NAME,"LCDRefresh",string,lpIniFile);
    wsprintf(string,"%d",g_Config.byWinAmpPoll);
    WritePrivateProfileString(SECTION_NAME,"WinAmpPoll",string,lpIniFile);
    wsprintf(string,"%d",g_Config.byScrollSpeed);
    WritePrivateProfileString(SECTION_NAME,"ScrollSpeed",string,lpIniFile);
    wsprintf(string,"%d",g_Config.byScrollSteps);
    WritePrivateProfileString(SECTION_NAME,"ScrollSteps",string,lpIniFile);
    wsprintf(string,"%d",g_Config.iScrollTimeStart);
    WritePrivateProfileString(SECTION_NAME,"ScrollTimeStart",string,lpIniFile);
    wsprintf(string,"%d",g_Config.iScrollTimeStep);
    WritePrivateProfileString(SECTION_NAME,"ScrollTimeStep",string,lpIniFile);
    wsprintf(string,"%d",g_Config.byTxtConv);
    WritePrivateProfileString(SECTION_NAME,"TextConversion",string,lpIniFile);
    wsprintf(string,"%d",g_Config.bTrimLeading);
    WritePrivateProfileString(SECTION_NAME,"TrimLeading",string,lpIniFile);
    wsprintf(string,"%d",g_Config.bTrimTrailing);
    WritePrivateProfileString(SECTION_NAME,"TrimTrailing",string,lpIniFile);
    wsprintf(string,"%d",g_Config.bTimeBlink);
    WritePrivateProfileString(SECTION_NAME,"BlinkTime",string,lpIniFile);
    wsprintf(string,"%d",g_Config.bTimeFwd);
    WritePrivateProfileString(SECTION_NAME,"TimeFwd",string,lpIniFile);
    wsprintf(string,"%d",g_Config.byVolSource);
    WritePrivateProfileString(SECTION_NAME,"SourceVolume",string,lpIniFile);

    wsprintf(string,"%d",g_Config.bEnableKeypad);
    WritePrivateProfileString(SECTION_NAME,"EnableKeypad",string,lpIniFile);

	csBuffer = g_Config.cOutputFields.GetCfgString();
    WritePrivateProfileString(SECTION_NAME, "Fields v2", csBuffer, lpIniFile);

    // custom characters
    CString csTemp;
    csBuffer = "";
    for (int i = 0; i < MAX_CUSTOM_CHAR; i++)
    {
        if (i > 0)
            csBuffer+="|";
        csBuffer+=g_Config.carrCustomChar[i].GetAsString(csTemp);
    }

    WritePrivateProfileString(SECTION_NAME, "CustomChars", csBuffer, lpIniFile);

		// spectrum analyser
	wsprintf(string,"%d",g_Config.bAutoAnalyser);
    WritePrivateProfileString(SECTION_NAME,"SA_AutoStart",string,lpIniFile);
    wsprintf(string,"%d",g_Config.bFalloff);
    WritePrivateProfileString(SECTION_NAME,"SA_falloff",string,lpIniFile);
	
	wsprintf(string,"%d",g_Config.iSAcol);
    WritePrivateProfileString(SECTION_NAME,"SA_col",string,lpIniFile);
	wsprintf(string,"%d",g_Config.iSArow);
    WritePrivateProfileString(SECTION_NAME,"SA_row",string,lpIniFile);
	wsprintf(string,"%d",g_Config.iSAwidth);
    WritePrivateProfileString(SECTION_NAME,"SA_width",string,lpIniFile);
	wsprintf(string,"%d",g_Config.iSAheight);
    WritePrivateProfileString(SECTION_NAME,"SA_height",string,lpIniFile);

	// playlist, MZ 2001/12/30
	wsprintf(string,"%d",g_Config.bPLsort);
    WritePrivateProfileString(SECTION_NAME,"PL_sort",string,lpIniFile);
	wsprintf(string,"%d",g_Config.bPLrecursive);
    WritePrivateProfileString(SECTION_NAME,"PL_recursive",string,lpIniFile);

	// system shutdown & hibernation, MZ 2003/07/10
    WritePrivateProfileString(SECTION_NAME, "Shutdown_msg_hibernate", g_Config.szLCDMsgHibernate, lpIniFile);
    WritePrivateProfileString(SECTION_NAME, "Shutdown_msg_standby", g_Config.szLCDMsgStandby, lpIniFile);
    WritePrivateProfileString(SECTION_NAME, "Shutdown_msg_shutdown", g_Config.szLCDMsgShutdown, lpIniFile);
    WritePrivateProfileString(SECTION_NAME, "Shutdown_msg_reboot", g_Config.szLCDMsgReboot, lpIniFile);
	wsprintf(string,"%d",g_Config.bShutdownForce);
    WritePrivateProfileString(SECTION_NAME,"Shutdown_force",string,lpIniFile);
	wsprintf(string,"%d",g_Config.bySleepFunction);
	WritePrivateProfileString(SECTION_NAME,"Sleep_shutdown",string,lpIniFile);
}

/******************************************************************************
Function : WinampPollThread   (previously: WinampTimerFunc)
Purpose  : WinAmp polling thread
Parameters : pVoid: pointer to  BOOL variable to indicate shutdown
Returns : thread exit code (not used)
Author  : Markus Zehnder    
******************************************************************************/
DWORD WINAPI WinampPollThread(LPVOID pVoid)
{
	// ATTENTION: DO NOT CREATE ANY WINDOWS TIMERs IN THIS THREAD!
	// this thread doesn't process any Windows msg's and therefor the created timer will never be called!


	// timing variables
	long  sleep;
	DWORD dwTime;
	DWORD next = GetTickCount() + 1000 / g_Config.byWinAmpPoll;

	// polling variables
	char     *pszSong = NULL;
	int      iPos;
	int      iSec = 0, iOldSec = -1;
	CString  csOldSong;
	int		 curvolume = g_WinAmpInfo.byVolume;
	char     szTemp[100];
	BOOL     bSongChange;
	int      iPlaybackStatus, iPlaylistLength, iSongLength, iBitrate;

	BOOL  *pbTerminate = (BOOL *)pVoid;


	while (!*pbTerminate) {

		sleep = next - GetTickCount();

		// safety measure: 100 ms sleep time to prevent over cpu usage 
		//                 There's no reason anyway to poll Winamp more than 10 times per second...

		if (sleep < 100) {
			sleep = 100;
		}

		Sleep(sleep);

		if (*pbTerminate)
			break;
		
		dwTime = GetTickCount();

		next = dwTime + 1000 / g_Config.byWinAmpPoll;


		//curvolume = g_WinAmpInfo.byVolume;
		bSongChange = FALSE;

		if (!g_bOutput)
			continue;

		// get playlist pos
		iPos = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETLISTPOS);

		// get song SetPosition
		g_WinAmpInfo.iSongPosition = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETOUTPUTTIME);

		// get status
		iPlaybackStatus = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_ISPLAYING);
		g_WinAmpInfo.bPlayStatusChange = g_WinAmpInfo.iPlaybackStatus != iPlaybackStatus;

		// Switch to pause or stop state
		if (iPlaybackStatus == 3)
		{
			// player is in pause mode
			if (g_Config.iSwitchPause != -1)
			{
				if (g_Config.iSwitchPause != g_Config.cOutputFields.GetCurrentSet())
				{
					g_Config.iSaveSet = g_Config.cOutputFields.GetCurrentSet();
					g_bUpdateAll = TRUE;
				}
				g_Config.cOutputFields.SetCurrentSet(g_Config.iSwitchPause);
			}
		}
		else if (iPlaybackStatus == 1)
		{
			// playing
			if (g_Config.iSaveSet != -1)
			{
				g_Config.cOutputFields.SetCurrentSet(g_Config.iSaveSet);
				g_Config.iSaveSet = -1;
				g_bUpdateAll = TRUE;
			}
		}
		else if (g_Config.iSwitchStop != -1)
		{
			// player is in stop mode
			if (g_Config.iSwitchStop != g_Config.cOutputFields.GetCurrentSet())
			{
				if (g_Config.cOutputFields.GetCurrentSet() != g_Config.iSwitchPause) {
					g_Config.iSaveSet = g_Config.cOutputFields.GetCurrentSet();
				}
				g_bUpdateAll = TRUE;
			}
			g_Config.cOutputFields.SetCurrentSet(g_Config.iSwitchStop);
		}


		// get playlist length
		iPlaylistLength = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETLISTLENGTH);

		// get song name
		pszSong = (char *)SendMessage(g_Plugin.hwndParent,WM_WA_IPC,iPos,IPC_GETPLAYLISTTITLE);

		// check for new song
		if (pszSong != NULL)
		{
			if (strcmp(pszSong, csOldSong) != 0)
			{
				g_WinAmpInfo.bSongChange = bSongChange = TRUE;
				if (*pszSong == '\0')
					g_WinAmpInfo.csTitleName = "";
				else
					g_WinAmpInfo.csTitleName = pszSong;
            
				csOldSong = g_WinAmpInfo.csTitleName;

				if (!g_WinAmpInfo.csTitleName.IsEmpty())
					g_WinAmpInfo.csTitleName.Replace( "\\n", "\n" );

				// read id3 tags from mp3 file
				char *szFileName = (char *)SendMessage(g_Plugin.hwndParent,WM_WA_IPC,iPos,IPC_GETPLAYLISTFILE);

				g_WinAmpInfo.cID3Tag.ReadTag(szFileName);   // note: NULL checking is done in the CID3Tag class.
			}
		}

		// get song length
		iSongLength = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,1,IPC_GETOUTPUTTIME);       
		if (iSongLength == -1)
			iSongLength = 0;

		// get sample rate
		g_WinAmpInfo.iSampleRate = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETINFO);

		// get bitrate
		iBitrate = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,1,IPC_GETINFO);

		// get channels
		g_WinAmpInfo.iChannels = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,2,IPC_GETINFO);


		// calculate current song position in seconds
		if (g_WinAmpInfo.iSongPosition >= 0)
			iSec = g_WinAmpInfo.iSongPosition / 1000;
		else
			iSec = 0;

		if (g_bUpdateAll) {
			EnterCriticalSection(&critSecLCDWrite);
			g_LCD->Clear();
			LeaveCriticalSection(&critSecLCDWrite);
		}

		// set write lock on g_WinAmpInfo  
		// MZ 2003/01/19 moved here from start of function to solve synchronization issues with output thread: 
		// locking must be as short as possible! Above Winamp polling is unpredictable in terms of execution time 
		// -> blocks output if the datastructure is locked!
		while (!AcquireWriteLock(&g_OutputLock));


		// update all lcd fields with the received information from Winamp or directly from the file (ID3 tags)
		// (a good place for optimizations...)
		for (int iField = 0; iField < g_Config.cOutputFields.GetTotalFieldCount(); iField++) 
		{
			if (*pbTerminate)
				break;

			BOOL bConvert = FALSE;
			COutputField *pcField = (COutputField *)g_Config.cOutputFields.GetField(iField);

			if (!pcField->m_bActive || pcField->m_csText.IsEmpty())
				continue;

			// is it the correct output set?
			if (pcField->m_bySet != g_Config.cOutputFields.GetCurrentSet() && !g_bUpdateAll)
				 continue;

			// check if field needs to be updated. bugfix MZ 2003/01/21: DYNAMIC_FIELD must be AND'ed not OR'd!
			if (((iSec != iOldSec) && (pcField->m_iType & SONG_POS)) ||
				bSongChange || g_bUpdateAll || g_WinAmpInfo.bPlayStatusChange ||
				(pcField->m_iType & DYNAMIC_FIELD) ||
				(pcField->m_iType & SLEEPTIMER) ||
				((iPlaylistLength != g_WinAmpInfo.iPlaylistLength) && (pcField->m_iType & PLAYLIST_LEN)) ||
				((iSongLength     != g_WinAmpInfo.iSongLength) && (pcField->m_iType & SONG_LENGTH)) ||
				(iPos != g_WinAmpInfo.iPlaylistPos) ||
				(((iBitrate != g_WinAmpInfo.iBitRate) && (pcField->m_iType & BIT_RATE))))
			{
				pcField->m_bUpdate = TRUE;
            
				// clear lcd text
				pcField->m_csLCDText = pcField->m_csText;

				if (pcField->m_iType & SONG_POS) {
					if (!pcField->m_csLCDText.IsEmpty())
						pcField->m_csLCDText.Replace( SONGPOS_TAG, FormatTime(g_Config.bTimeFwd ? iSec :
							iSec - iSongLength, (iPlaybackStatus == 3) && g_Config.bTimeBlink) );
				}

				if (pcField->m_iType & SONG_LENGTH)
					pcField->m_csLCDText.Replace( SONGLEN_TAG, FormatTime(iSongLength) );

				if (pcField->m_iType & PLAYBACK_STATUS) {
					char *pszText;
					switch (iPlaybackStatus) {
						case 1 : 
							pszText  = g_Config.szPlay; break;
						case 3 : 
							pszText  = g_Config.szPause; break;
						default : 
							pszText = g_Config.szStop;
					}
					pcField->m_csLCDText.Replace( PLAYBACKSTATUS_TAG, pszText );
				}

				if (pcField->m_iType & SONG_TITLE) {
					pcField->m_csLCDText.Replace( SONGTITLE_TAG, g_WinAmpInfo.csTitleName );
					bConvert = TRUE;
				}

				if (pcField->m_iType & SAMPLE_RATE)
					pcField->m_csLCDText.Replace( SAMPLERATE_TAG, itoa(g_WinAmpInfo.iSampleRate,szTemp,10) );

				if (pcField->m_iType & BIT_RATE)
					pcField->m_csLCDText.Replace( BITRATE_TAG, itoa(iBitrate,szTemp,10) );

				if (pcField->m_iType & CHANNELS)
					pcField->m_csLCDText.Replace( CHANNELS_TAG, itoa(g_WinAmpInfo.iChannels,szTemp,10) );

				if (pcField->m_iType & PLAYLIST_POS)
					pcField->m_csLCDText.Replace( PLAYLISTPOS_TAG, itoa(iPos + 1,szTemp,10) );
        
				if (pcField->m_iType & PLAYLIST_LENGTH)
					pcField->m_csLCDText.Replace( PLAYLISTLENGTH_TAG, itoa(iPlaylistLength,szTemp,10) );
        
				if (pcField->m_iType & VOLUME)
					pcField->m_csLCDText.Replace( VOLUME_TAG, itoa(g_WinAmpInfo.byVolume,szTemp,10) );

				if (pcField->m_iType & SYS_TIME)
					pcField->m_csLCDText.Replace( SYS_TIME_TAG, CTime::GetCurrentTime().Format(g_Config.szDateTimeFormat) );

				if (bSongChange) {
					pcField->m_iScrollIndex = 0;
					if (pcField->m_ScrollType == pcField->BOUNCE) {
						pcField->m_bScrollForwards = TRUE; //added by James Maher
					}
				}

				// replace id3 tags
				if (pcField->m_iType & ID3_ARTIST) {
					pcField->m_csLCDText.Replace( ID3_ARTIST_TAG, g_WinAmpInfo.cID3Tag.GetArtist() );
					bConvert = TRUE;
				}

				if (pcField->m_iType & ID3_TITLE) {
					pcField->m_csLCDText.Replace( ID3_TITLE_TAG, g_WinAmpInfo.cID3Tag.hasID3Tag() ?
						g_WinAmpInfo.cID3Tag.GetTitle() : g_WinAmpInfo.csTitleName );
					bConvert = TRUE;
				}

				if (pcField->m_iType & ID3_ALBUM) {
					pcField->m_csLCDText.Replace( ID3_ALBUM_TAG, g_WinAmpInfo.cID3Tag.GetAlbum() );
					bConvert = TRUE;
				}

				if (pcField->m_iType & ID3_YEAR)
					pcField->m_csLCDText.Replace( ID3_YEAR_TAG, g_WinAmpInfo.cID3Tag.GetYear() );

				if (pcField->m_iType & ID3_COMMENT) {
					pcField->m_csLCDText.Replace( ID3_COMMENT_TAG, g_WinAmpInfo.cID3Tag.GetComment() );
					bConvert = TRUE;
				}

				if (pcField->m_iType & ID3_GENRE)
					pcField->m_csLCDText.Replace( ID3_GENRE_TAG, g_WinAmpInfo.cID3Tag.GetGenre() );

				if (pcField->m_iType & ID3_TRACK)
					pcField->m_csLCDText.Replace( ID3_TRACK_TAG, g_WinAmpInfo.cID3Tag.GetTrackNumber() );

				if (pcField->m_iType & SHUFFLE) {
					char *pszText;
					pszText = (SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GET_SHUFFLE) ? g_Config.szShuffleOn : g_Config.szShuffleOff);
					pcField->m_csLCDText.Replace( SHUFFLE_TAG, pszText );
				}

				if (pcField->m_iType & REPEAT) {
					char *pszText;
					pszText = (SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GET_REPEAT) ? g_Config.szRepeatOn : g_Config.szRepeatOff);
					pcField->m_csLCDText.Replace( REPEAT_TAG, pszText );
				}

				if (g_pPerfMon) {
					g_pPerfMon->CollectQueryData();

					if (pcField->m_iType & CPUUSAGE) {
						CString Mystr;
						long lMin, lMax, lMean, lCpu;

						g_pPerfMon->CollectQueryData();
						lCpu = g_pPerfMon->GetCounterValue(g_CounterCPU);
						g_pPerfMon->GetStatistics(&lMin, &lMax, &lMean, g_CounterCPU);
						Mystr.Format("%ld", lMean);
						pcField->m_csLCDText.Replace( CPUUSAGE_TAG, Mystr.GetBuffer(1));
						Mystr.ReleaseBuffer();
					}

					if (pcField->m_iType & MEMUSAGE) {
						CString Mystr;
						long lMem;

						g_pPerfMon->CollectQueryData();
						lMem = g_pPerfMon->GetCounterValue(g_CounterMEM);
						Mystr.Format("%ld", lMem);
						pcField->m_csLCDText.Replace( MEMUSAGE_TAG, Mystr.GetBuffer(1));
						Mystr.ReleaseBuffer();
					}
				}

				if (pcField->m_iType & VOLUMEBAR) {
					char pszText[41];
					int vol = g_WinAmpInfo.byVolume;
					int width = g_Config.iVolBarLen - 2;

					if (width < 2)
						width = 2;

					memset(pszText, 0, 41);
					memset(pszText, ' ', g_Config.iVolBarLen);
					pszText[0] = '[';
					pszText[g_Config.iVolBarLen - 1] = ']';

					char szTmp[MAX_VB_CHAR];
					strcpy(szTmp, g_Config.szVBchar);
					g_LCD->ConvertTextToLCDCharset(szTmp);

					memset(pszText + 1, szTmp[0], (vol * width) / 100);
					pcField->m_csLCDText.Replace(VOLUMEBAR_TAG, pszText);
				}

				if (pcField->m_iType & SLEEPTIMER)
				{
					if(!g_bSleepActive)
						pcField->m_csLCDText.Replace(SLEEPTIMER_TAG, "-");
					else
					{
						if(g_iSleepTime <= 60)
							pcField->m_csLCDText.Replace(SLEEPTIMER_TAG, itoa(g_iSleepTime, szTemp, 10));
						else
							pcField->m_csLCDText.Replace(SLEEPTIMER_TAG, itoa(g_iSleepTime / 60, szTemp, 10));
					}
				}

				// prepare text for correct scroll behaviour! MZ 20030607
				g_LCD->ConvertTagsToCustomChars(pcField->m_csLCDText);

				if (bConvert) {
					ConvertText(pcField->m_csLCDText.GetBuffer(0));
					pcField->m_csLCDText.ReleaseBuffer();
				}

			}

		}

		if (curvolume != g_WinAmpInfo.byVolume && g_Config.bTempVB)
		{
			curvolume = g_WinAmpInfo.byVolume;
			_dwVolBarEndTime = GetTickCount() + 2000;
		}

		g_WinAmpInfo.iPlaybackStatus = iPlaybackStatus;
		g_WinAmpInfo.iPlaylistLength = iPlaylistLength;
		g_WinAmpInfo.iSongLength = iSongLength;
		g_WinAmpInfo.iBitRate = iBitrate;
		iOldSec = iSec;
		g_WinAmpInfo.iPlaylistPos = iPos;
		g_bUpdateAll = FALSE;

		// unlock
		ReleaseWriteLock(&g_OutputLock);
        		

		//TRACE1("POLL time: %d\n", GetTickCount() - dwTime);

	}

	return 0;
}

 
char *Equa_Get_BandStr(int band)
{
	switch (band)
	{
	case 0:
		return (" 60Hz");
	case 1:
		return ("170Hz");
	case 2:
		return ("310Hz");
	case 3:
		return ("600Hz");
	case 4:
		return (" 1KHz");
	case 5:
		return (" 3KHz");
	case 6:
		return (" 6KHz");
	case 7:
		return ("12KHz");
	case 8:
		return ("14KHz");
	case 9:
		return ("16KHz");
	case 10:
		return ("PrAmp");
	default:
		return (NULL);
	}
}

void Equa_Disp_Band(int band)
{
	int ret, orig;
	int height;
	int mid = 8;
	char c[2] = "A";
	char str[10];
	int posx = band + 2;
	float forig;


	height = 8 * g_LCD->GetRows();

	if (band == 10)
	{
		//PreAmp channel
		posx = 1;	
	}
	
	orig = ret = SendMessage(g_Plugin.hwndParent, WM_USER, (WPARAM)band, (LPARAM)127);

	ret = (height * ret) / 64;	// scale value;
	ret = height - ret;


	for (int i=1; i <= g_LCD->GetRows(); ++i)
	{
		int val;

		g_LCD->SetPosition(posx, i);
		val = ret - (g_LCD->GetRows() - i) * 8;
		if (val >= 8)
			c[0] = (char)0x08;
		else if (val <= 0)
			c[0] = (char)' ';
		else
			c[0] = (char)val;
		g_LCD->Write(c);
	}

	g_LCD->SetPosition(12, g_LCD->GetRows() / 2);
	g_LCD->Write(Equa_Get_BandStr(band));
	g_LCD->SetPosition(12, g_LCD->GetRows() / 2 + 1);

	forig = (float)(40 * orig) / (float)64;	// scale value;
	orig = (int)forig;
	if (forig - orig > 0.5)
		orig++;
	orig = -(orig - 20);
	
	if (orig >= 0)
		sprintf(str, "+%2dDb", orig);
	else
		sprintf(str, "-%2dDb", -orig);
	g_LCD->Write(str);
}

VOID CALLBACK Equa_TimerFunc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
	static int oldAct = -1;
	static bool oldState = TRUE;
	int posx = g_uiEquaBand + 2;

	if (g_uiEquaBand == 10)
		posx = 1;

	if (!g_bEqua)
	{
		// Equalizer is not displayed anymore
		oldAct = -1;
		oldState = TRUE;
		::KillTimer(NULL, idEvent);
		return ;
	}
	
	if (oldAct == -1)
		oldAct = g_uiEquaBand;

	if (oldAct != g_uiEquaBand)
	{
		Equa_Disp_Band(oldAct);
		oldAct = g_uiEquaBand;
	}

	if (oldState == TRUE)
	{
		for (int i = 1; i <= g_LCD->GetRows(); ++i)
		{
			g_LCD->SetPosition(posx, i);
			g_LCD->Write(" ");
		}
		oldState = FALSE;
	}
	else
	{
		Equa_Disp_Band(g_uiEquaBand);
		oldState = TRUE;
	}
}

int Equa_Init_Display()
{
	Equa_Disp_Band(0);
	Equa_Disp_Band(1);
	Equa_Disp_Band(2);
	Equa_Disp_Band(3);
	Equa_Disp_Band(4);
	Equa_Disp_Band(5);
	Equa_Disp_Band(6);
	Equa_Disp_Band(7);
	Equa_Disp_Band(8);
	Equa_Disp_Band(9);
	Equa_Disp_Band(10);

	return (1);
}

/******************************************************************************
Function : LCDOutputThread  (previously OutputTimerFunc)
Purpose  : Writes the output fields to the LCD display
Parameters : pVoid: pointer to  BOOL variable to indicate shutdown
Returns : thread exit code (not used)
Author  : Markus Zehnder    
******************************************************************************/
DWORD WINAPI LCDOutputThread(LPVOID pVoid)
{
    int     iMax;
    BOOL    bBackLight;
	long    sleep;
	DWORD   dwTime;
	DWORD   next = GetTickCount() + (1000 / g_Config.byLCDRefresh);
	DWORD   lastSwitch = 0;
    CString csStatus, csText;
	BOOL    *pbTerminate = (BOOL *)pVoid;
	MSG     msg;


	while (!*pbTerminate) {

		bBackLight = FALSE;

		sleep = next - GetTickCount();

		// safety measure: 20 ms sleep time to prevent over cpu usage
		if (sleep < 20) {
			sleep = 20;
		}

		Sleep(sleep);

		if (*pbTerminate)
			break;

		dwTime = GetTickCount();
		next = dwTime + (1000 / g_Config.byLCDRefresh);


		// take care of the stupid Windows message processing, otherwise all timerfunctions that 
		// have been created from this thread don't work anymore! E.g. LCD BacklightTimerFunc. MZ 2003/01/25
		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE) > 0) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		if (*pbTerminate)
			break;

		if (g_LCD == NULL)
			continue;

		EnterCriticalSection(&critSecLCDWrite);		// MZ 20030802
		g_LCD->HandleKeyPad();
		LeaveCriticalSection(&critSecLCDWrite);

		if (!g_bOutput || !g_Config.bOutput)
			continue;
/*
		if (g_bEqua)
		{
			CCustomChar cc;


			g_uiEquaBand = 10;
			g_uiEquaSpec = FALSE;

			// Kill all default update timers
			::KillTimer( NULL, g_uiScrollTimer );

			// @todo MZ since there are no timers anymore find out what needs to be changed!
			// At the moment it's not working...
			//::KillTimer( NULL, g_uiPollingTimer);
			//::KillTimer( NULL, g_uiTOutputTimer );


			if (g_Spectrum_Analyser.active)
			{
				// Stop spectrum analyser
				g_Spectrum_Analyser.active = 0;
				g_Spectrum_Analyser.char_loaded = 0; 
				g_bUpdateAll = TRUE;
				g_uiEquaSpec = TRUE;
				g_LCD->Clear();
			}
			
			EnterCriticalSection(&critSecLCDWrite);

			// Create Equalizer custom chars
			{
				char *p;
				char szBuffer[256];
				char *p2 = szBuffer, *pEnd;
				int i=0, iSize;

				if (g_Config.iEquaType == 0)
					strcpy(szBuffer, "0,0,0,0,0,0,0,31|0,0,0,0,0,0,31,31|0,0,0,0,0,31,31,31|0,0,0,0,31,31,31,31|0,0,0,31,31,31,31,31|0,0,31,31,31,31,31,31|0,31,31,31,31,31,31,31|31,31,31,31,31,31,31,31");
				else
					strcpy(szBuffer, "0,0,0,0,0,0,0,27|0,0,0,0,0,0,27,27|0,0,0,0,0,27,27,27|0,0,0,0,27,27,27,27|0,0,0,27,27,27,27,27|0,0,27,27,27,27,27,27|0,27,27,27,27,27,27,27|27,27,27,27,27,27,27,27");
				pEnd = p2 + strlen(p2);
				iSize = strlen(szBuffer);
				p = strtok(p2, "|");
				while (p != NULL)
				{
					cc.Set(p);
					g_LCD->CreateCustomChar(i++, cc);
					//g_Config.carrMenueChar[i++].Set(p);
					p2 += strlen(p) + 1;
					if (p2 >= pEnd)
						break;
					p = strtok(p2, "|");
				}
				g_Spectrum_Analyser.char_loaded = 1;
			}

			Equa_Init_Display();

			LeaveCriticalSection(&critSecLCDWrite);

			g_uiEquaTimer = ::SetTimer(NULL, NULL, 200, (TIMERPROC)Equa_TimerFunc);
			
			continue;
		}
*/
		// set lock on g_WinAmpInfo
		while (!AcquireReadLock(&g_OutputLock));

		iMax = g_Config.cOutputFields.GetTotalFieldCount();

		// set LCD properties
		if (g_WinAmpInfo.bSongChange)
		{
			if ((g_Config.byTimeoutType == TIMEOUT_TRACKCHANGE) || 
				(g_Config.byTimeoutType ==  TIMEOUT_TRACKPLAYCHANGE))
				bBackLight = TRUE;
			g_WinAmpInfo.bSongChange = FALSE;
		}

		if (g_WinAmpInfo.bPlayStatusChange)
		{
			if (g_Config.byTimeoutType == TIMEOUT_TRACKPLAYCHANGE)
				bBackLight = TRUE;
			g_WinAmpInfo.bPlayStatusChange = FALSE;
		}

		// set backlight timeout
		if (bBackLight && g_Config.bBacklight)
			g_LCD->SetBacklight( g_Config.iBacklightTimeout );

		// write output fields
		for (int iField = 0; iField < iMax; iField++) 
		{
			COutputField *pcField = (COutputField *)g_Config.cOutputFields.GetField(iField); //.cptrarrField.GetAt(iField);

			// future enhancement: multiple output sets
			if (pcField->m_bySet != g_Config.cOutputFields.GetCurrentSet())
				continue;

			if (isFieldInSpecAnalyzer(pcField))
				continue;

			// @HACK check enable flag, AcquireReadLock & AcquireWriteLock should handle everything but something's wrong... MZ 2003/01/19
			if (!g_bOutput)
				break;

			if (isFieldInVolumeBar(pcField))
				continue;

			if (pcField->m_bActive && (pcField->m_bUpdate || pcField->m_ScrollType != pcField->OFF))
			{
				pcField->m_bUpdate = FALSE;
				EnterCriticalSection(&critSecLCDWrite);                 // only one thread can access the LCD at the same time (spec_analyser_data also writes to the LCD!), M.Zehnder, Jan 27, 01
				g_LCD->SetPosition(pcField->m_iCol,pcField->m_iRow);    // Setzt die Position im Display
				g_LCD->Write( FormatOutputText(pcField) );              // Anzeigen des Textes
				LeaveCriticalSection(&critSecLCDWrite);
			}
		}

		// write temp volume bar if asked
		if (_dwVolBarEndTime > 0 && _dwVolBarEndTime > dwTime) {
			char pszText[41];
			
			int vol = g_WinAmpInfo.byVolume;
			int width = g_Config.iVBwidth - 2;

			if (width < 2)
				width = 2;

			memset(pszText, 0, 41);
			memset(pszText, ' ', g_Config.iVBwidth);
			pszText[0] = '[';
			pszText[g_Config.iVBwidth - 1] = ']';

			char szTmp[MAX_VB_CHAR];
			strcpy(szTmp, g_Config.szVBchar);
			g_LCD->ConvertTextToLCDCharset(szTmp);

			memset(pszText + 1, szTmp[0], (vol * width) / 100);

			EnterCriticalSection(&critSecLCDWrite);
			g_LCD->SetPosition(g_Config.iVBcol,g_Config.iVBrow);
			g_LCD->Write(pszText);
			LeaveCriticalSection(&critSecLCDWrite);
		} else if (_dwVolBarEndTime != 0) {	
			_dwVolBarEndTime = 0;
			g_bUpdateAll = TRUE;	// easiest way to reset screen. Optimized version would be: write blank string & only set affected fields to updated
		}

		// unlock (must be called before SwitchSet! SwitchSet aquires write lock!)
		ReleaseReadLock(&g_OutputLock);

		// automatically switch set if necessary, MZ 2002/06/12	
		if ((g_Config.dwSwitchSetTimeout > 0) &&
			(dwTime > (lastSwitch + g_Config.dwSwitchSetTimeout * 1000)))
		{
				g_Config.cOutputFields.SwitchSet();
				lastSwitch = dwTime;
		}

	}

	return 0;
}


/******************************************************************************
Function : ScrollTimerFunc
Purpose  : Sets the scroll index of scrollable output fields.
Parameters : hwnd:    handle of window for timer messages 
             uMsg:    WM_TIMER message
             idEvent: timer identifier
             dwTime:  current system time
Returns : void
Author  : Markus Zehnder    
******************************************************************************/
VOID CALLBACK ScrollTimerFunc( HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime )
{
    // set write lock on g_WinAmpInfo
    if (!AcquireWriteLock(&g_OutputLock))
		return;
    
    int iMax = g_Config.cOutputFields.GetTotalFieldCount();

    for (int iField = 0; iField < iMax; iField++) 
    {
        COutputField *pcField = (COutputField *)g_Config.cOutputFields.GetField(iField);

        // check if the field is in the active output sets
        if (pcField->m_bySet != g_Config.cOutputFields.GetCurrentSet())
            continue;

		switch (pcField->m_ScrollType) {
		case pcField->FORWARD:
                ++pcField->m_iScrollIndex;

                if (pcField->m_iScrollIndex >= (int)(pcField->m_csLCDText.GetLength() + strlen(g_Config.szScrollSeparator))) {
                    pcField->m_iScrollIndex = 0;
				}
				break;
		case pcField->BACKWARD:
                --pcField->m_iScrollIndex;

                if (pcField->m_iScrollIndex <= 0) {
                    pcField->m_iScrollIndex = (int)(pcField->m_csLCDText.GetLength() + strlen(g_Config.szScrollSeparator));
				}
				break;
		case pcField->BOUNCE:
				// Implemented by James Maher. jamie.maher@eudoramail.com
				if (pcField->m_bScrollForwards)
				{   // Scroll Forwards!
					// Implemented by James Maher. jamie.maher@eudoramail.com
					// scroll to end - wait - scroll to beginning - wait - etc.

					++pcField->m_iScrollIndex;
					
					// subtract the LCD field length to stop at the right character (end of field length)
					if (pcField->m_iScrollIndex - 1 >= (int)(pcField->m_csLCDText.GetLength() ) - pcField->m_iLength)
					{
						--pcField->m_iScrollIndex; //make sure it delays. Display the last position again.
						pcField->m_bScrollForwards = FALSE; //reverse direction
					}
				}
				else //Scroll Backwards! 
				{
					--pcField->m_iScrollIndex;

					if (pcField->m_iScrollIndex <= -1)
					{
						pcField->m_iScrollIndex = 0;	   // bugfix MZ 2003/01/25
						pcField->m_bScrollForwards = TRUE; //reverse direction, go forwards
					}
					//end of changes by James Maher (in this function)
				}
				break;
		default:
			// do nothing :)
			break;
        }
    }

    // unlock
    ReleaseWriteLock(&g_OutputLock);
}

/******************************************************************************
Function : isFieldInSpecAnalyzer
Purpose  : Determines if the specified field is inside the spectrum analyzer area
Parameters : pcField : pointer to COutputField
Returns : TRUE if field is inside area
Author  : Markus Zehnder    
******************************************************************************/
BOOL isFieldInSpecAnalyzer(COutputField *pcField)
{
	if (!g_Spectrum_Analyser.active)
		return FALSE;
	int iStart = pcField->m_iCol;
	int iEnd = pcField->m_iCol + pcField->m_iLength - 1;
	int iSAstart = g_Config.iSAcol;
	int iSAend = g_Config.iSAcol + g_Config.iSAwidth - 1;

	// SA height is no longer hard coded, MZ 2002/02/03
	BOOL bInRow = FALSE;

	for (int i=0; i < g_Config.iSAheight; i++) {
		bInRow |= pcField->m_iRow == g_Config.iSArow - i;
	}	

	return (bInRow                                          // field is in a row of the SA area
			 && ((iStart >= iSAstart && iStart <= iSAend)	// field starts inside area
				 || (iEnd >= iSAstart && iEnd  <= iSAend)	// field ends inside area 
				 || (iStart < iSAstart && iEnd >  iSAend)));// field passes through area

}

/******************************************************************************
Function : isFieldVolumeBar
Purpose  : Determines if the specified field is inside the temp Volume bar area
Parameters : pcField : pointer to COutputField
Returns : TRUE if field is inside area
Author  : MZ / Thibault LAMY
******************************************************************************/
BOOL isFieldInVolumeBar(COutputField *pcField)
{
	if (_dwVolBarEndTime == 0)
		return FALSE;
	int iStart = pcField->m_iCol;
	int iEnd = pcField->m_iCol + pcField->m_iLength - 1;
	int iSAstart = g_Config.iVBcol;
	int iSAend = g_Config.iVBcol + g_Config.iVBwidth - 1;

	// SA height is no longer hard coded, MZ 2002/02/03
	BOOL bInRow = FALSE;

	if (g_Config.iVBrow == pcField->m_iRow)
		bInRow = TRUE;

	return (bInRow                                          // field is in a row of the SA area
			 && ((iStart >= iSAstart && iStart <= iSAend)	// field starts inside area
				 || (iEnd >= iSAstart && iEnd  <= iSAend)	// field ends inside area 
				 || (iStart < iSAstart && iEnd >  iSAend)));// field passes through area

}

/******************************************************************************
Function : FormatTime
Purpose  : Returns a formated time string from the provided seconds parameter.
Parameters : iSeconds : seconds
             bBlink   : if TRUE the time string blinks
Returns : static pointer to formated time string
Author  : Markus Zehnder    
******************************************************************************/
LPCSTR FormatTime( int iSeconds, BOOL bBlink /*= FALSE*/ )
{
// warning: this function is not multithreading capable !!!
    static char    szHour[3], szExtMin[4], szMin[3], szSec[3];
    static DWORD   dwLastTickCount;
    static CString csTime;

    LPCSTR  lpNegSign = "-";
    BOOLEAN bNeg = FALSE;
    DWORD   dwTickCount = GetTickCount();

    csTime = g_Config.szTimeFormat;


    if (iSeconds < 0)
    {
        iSeconds *= -1;
        bNeg = TRUE;
    }

    if (bBlink && (dwTickCount - dwLastTickCount < 1000))
    {
        strcpy(szHour, "  ");
		strcpy(szExtMin, "   ");
        strcpy(szMin, "  ");
        strcpy(szSec, "  ");
        lpNegSign = " ";  
    }
    else
    {
        wsprintf( szHour, "%02d", iSeconds / 3600 );

		// bugfix [764503] song position (%6) for songs > 60 min, MZ 2003/07/11 

		if (csTime.Find(HOUR_TAG) >= 0) {
			// easiest one: hh:mm:ss
	        wsprintf( szMin, "%02d", (iSeconds % 3600) / 60 );
			strcpy(szExtMin, szMin);
		} else if (csTime.Find(EXT_MINUTE_TAG) >= 0) {
			// easy too: mmm:ss
	        wsprintf( szExtMin, "%03d", (iSeconds / 60) % 1000 );
		} else {
			// no hour,no 3-digit minutes: use minutes as 00-99
	        wsprintf( szMin, "%02d", (iSeconds / 60) % 100 );
			strcpy(szExtMin, szMin);
		}

		// end bugfix [764503]

        wsprintf( szSec, "%02d", iSeconds % 3600 % 60 );
    }

    csTime.Replace( HOUR_TAG, szHour );
    csTime.Replace( EXT_MINUTE_TAG, szExtMin );
    csTime.Replace( MINUTE_TAG, szMin );
    csTime.Replace( SECOND_TAG, szSec );

    if (bNeg)
        csTime = lpNegSign + csTime;

    if (dwTickCount - dwLastTickCount >= 2000)
        dwLastTickCount = dwTickCount;

    return csTime;
}

/******************************************************************************
Function : FormatOutputText
Purpose  : Returns the formated output text string from the specified output
           field.
Parameters : Pointer to COutputField
Returns : Static pointer to formated output text string
Author  : Markus Zehnder    
******************************************************************************/
LPCSTR FormatOutputText(COutputField *pcField)
{
// warning: this function is not multithreading capable !!!
    static CString csText;
    CString csTemp = pcField->m_csLCDText;

    if (pcField->m_iLength <= 0)
    {
        // plain text without format parameters
        return csTemp;
    }

	// MZ 20030607
//	g_LCD->ConvertTagsToCustomChars(csTemp);

    if (pcField->m_ScrollType != pcField->OFF && (pcField->m_iLength < csTemp.GetLength()))
    {
        // we have a scroll text
        csTemp += g_Config.szScrollSeparator;

        // replace custom chars tags with actual output character so we get the true length of the output string!
        // Note: the scroll separator may contain tags as well...
        g_LCD->ConvertTagsToCustomChars(csTemp);

		// sanity check...
		if (pcField->m_iScrollIndex < 0) {
			pcField->m_iScrollIndex = 0;
		}

        csText = csTemp.Mid(pcField->m_iScrollIndex, pcField->m_iLength);
        
        if (csText.GetLength() < pcField->m_iLength)
        {
            int iRest = pcField->m_iLength - (csTemp.GetLength() - pcField->m_iScrollIndex);
            if (iRest > 0)
                csText += csTemp.Left(iRest);
        }
    }
    else
    {
        // replace custom chars tags with actual output character so we get the true length of the output string!
//        g_LCD->ConvertTagsToCustomChars(csTemp);

        // normal text
        csText = csTemp.Left(pcField->m_iLength);

        int iSpaces = pcField->m_iLength - csText.GetLength();

        if (iSpaces > 0)
        {
            switch (pcField->m_iAlignment)
            {
            case ALIGNMENT_CENTER :
                iSpaces/=2;
                break;
            case ALIGNMENT_RIGHT :
                break;
            default :  // == left
                iSpaces = 0;
                break;
            }

            for (int i = 0; i < iSpaces; i++)
                csText.Insert( 0, " " );
        }
    }

    for (int i = csText.GetLength(); i < pcField->m_iLength; i++)
        csText += " ";

    return csText.GetBuffer(0);
}

/******************************************************************************
Function : ConvertText
Purpose  : Converts the specified string as specified in the text conversion.
Parameters : Pointer to source string
Returns : Pointer to formated string
Author  : Markus Zehnder, 26.12.99  
******************************************************************************/
LPSTR ConvertText(LPSTR lpText)
{
    if (g_Config.bTrimLeading)
        while (*lpText == ' ')
            lpText++;

    if (g_Config.bTrimTrailing)
    {
        int iEnd = strlen(lpText) - 1;
        if (iEnd > 0)
            while (lpText[iEnd] == ' ')
                lpText[iEnd--] = '\0';
    }

    LPSTR p = lpText;
    BOOL bUp;
    switch (g_Config.byTxtConv)
    {
        case CONV_UPPERCASE  :
            for(;*p != '\0';p++)
                *p = toupper(*p);
            break;
        case CONV_LOWERCASE  : 
            for(;*p != '\0';p++)
                *p = tolower(*p);
            break;
        case CONV_FIRSTUPPER :
            // convert first letter of each word to uppercase
            for(bUp = TRUE; *p != '\0'; p++)
            {
                if (bUp)
                    *p = toupper(*p);
                else
                    *p = tolower(*p);
                bUp = (*p == ' ');
            }
            break;
        case CONV_UPPERCASE_FIRST : // MZ, 16.08.00
            // convert first letter of each word to uppercase, don't touch the rest
            for(bUp = TRUE; *p != '\0'; p++)
            {
                if (bUp)
                    *p = toupper(*p);
                bUp = (*p == ' ');
            }
            break;
        // default = don't change
    }

    return lpText;
}


/******************************************************************************
Function : SetCustomChars
Purpose  : Sends the defined custom characters to the display
Parameters : -
Returns : void
Author  : Markus Zehnder, 29.12.99  
******************************************************************************/
void SetCustomChars()
{
    if (g_LCD == NULL)
        return;

    EnterCriticalSection(&critSecLCDWrite);

// note: the custom char 0 is not used.
    // This needs some changes in the lcd interface, the char 0 is currently 
    // treated as the \0 string terminator!
	// FV: set chars 0 to 7 an swap them in the write function of the display
    for (int i = 0; i < MAX_CUSTOM_CHAR; i++)
        g_LCD->CreateCustomChar(i, g_Config.carrCustomChar[i]);  // removed +1

	LeaveCriticalSection(&critSecLCDWrite);
}



//*****************************************************************************
// Function : SetMenueChars
// Purpose  : Sends the defined custom characters to the display
// Parameters : -
// Returns : void
// Author  : Frank Verhamme, 31.06.2000
//*****************************************************************************
void SetMenueChars()
{
    if (g_LCD == NULL)
        return;

    // only one thread can access the LCD at the same time, MZ 2002/07/07
	EnterCriticalSection(&critSecLCDWrite);     

    // note: the custom char 0 is not used.
    // This needs some changes in the lcd interface, the char 0 is currently 
    // treated as the \0 string terminator!
	// FV: set chars 0 to 7 an swap them in the write function of the display
    for (int i = 0; i < MAX_CUSTOM_CHAR; i++)
        g_LCD->CreateCustomChar(i, g_Config.carrMenueChar[i]);

    LeaveCriticalSection(&critSecLCDWrite);
}

//*****************************************************************************
// Function : CalculatePlayNo
// Purpose  : Calculates a Number for the Track to Play
// Parameters : -
// Returns : Number as int
// Author  : Frank Verhamme, 31.06.2000
//*****************************************************************************
int CalculatePlayNo(int iCurrentNo, int iAddValue)
{
    if(iCurrentNo == -1)
        iCurrentNo = 0;
    return iCurrentNo * 10 + iAddValue;
}

#ifdef __cplusplus
extern "C" {
#endif
__declspec(dllexport) void spec_analyser_stop(void)
{
  if (g_Spectrum_Analyser.char_loaded == 1)
  {
    // load custom chars...
      char *p;
      char szBuffer[10000];
      GetPrivateProfileString( SECTION_NAME, "CustomChars", "", szBuffer,
                                sizeof(szBuffer), g_szIniFile);
      char *p2 = szBuffer, *pEnd = p2 + strlen(p2);
      int  i = 0, iSize = strlen(szBuffer);
      p = strtok(p2, "|");
      while (p != NULL)
      {
        if (i == MAX_CUSTOM_CHAR)
            break;
        g_Config.carrCustomChar[i++].Set(p);
        p2 += strlen(p) + 1;
        if (p2 >= pEnd)
            break;
        p = strtok(p2, "|");
      }
      SetCustomChars();
      // ...custom chars are restored

      g_Spectrum_Analyser.char_loaded = 0;
  }

  g_Spectrum_Analyser.active = 0;   // stop spectrum analyser
}

__declspec(dllexport) void spec_analyser_init(int *rows, int *columns, int *width, int *height, int *falloff)
{
	// Initialization check (Fix of "Plugin executed illegal operation" error), MZ 2002/06/15
  while (g_Config.eInitStatus == IN_PROGRESS) {
	Sleep(200);
  }

  if (g_Config.eInitStatus != OK || g_LCD == NULL) {
	*rows    = 0;
	*columns = 0;
	*width   = 0;
	*height  = 0;
	*falloff = FALSE;
	return;
  }

  // initialize visualization plugin with size of SA
  *rows    = g_LCD->GetRows();
  *columns = g_LCD->GetColumns();
  *width   = g_Config.iSAwidth;
  *height  = g_Config.iSAheight;
  *falloff = g_Spectrum_Analyser.falloff;
}
 
// @todo remove hard coded size of 2 lines, use dynamic array
__declspec(dllexport) void spec_analyser_data(char *line1, char *line2, char *line3, char *line4)
{
  if (g_LCD == NULL)
	  return;

  // don't display SA while in cfg menu, MZ 2002/02/03
  if (g_bOutput && g_Spectrum_Analyser.in_menu == 0 && g_Spectrum_Analyser.active == 1)
  {
    if (g_Spectrum_Analyser.char_loaded == 0)
    {
        // load custom chars for SA
		// MZ 2002/02/16 use a custom char for the full block, not every LCD has block char at 0xFF
        char *p;
        char szBuffer[] = "0,0,0,0,0,0,0,31|0,0,0,0,0,0,31,31|0,0,0,0,0,31,31,31|0,0,0,0,31,31,31,31|0,0,0,31,31,31,31,31|0,0,31,31,31,31,31,31|0,31,31,31,31,31,31,31|31,31,31,31,31,31,31,31";
        char *p2 = szBuffer, *pEnd = p2 + strlen(p2);
        int i=0, iSize = strlen(szBuffer);
        p = strtok(p2, "|");
        while (p != NULL)
		{
			if(i == MAX_CUSTOM_CHAR)
				break;
			g_Config.carrMenueChar[i++].Set(p);
			p2 += strlen(p) + 1;
			if (p2 >= pEnd)
				break;
			p = strtok(p2, "|");
		}
        SetMenueChars();
        g_Spectrum_Analyser.char_loaded = 1;
    }

	// additional size check, MZ 2002/06/16
	int iMax = g_LCD->GetColumns();
	int len = strlen(line1);
	line1[iMax] = line2[iMax] = line3[iMax] = line4[iMax] = '\0';

    EnterCriticalSection(&critSecLCDWrite);     // only one thread can access the LCD at the same time (OutputTimerFunc also writes to the LCD!), M.Zehnder, Jan 27, 01
    // @TODO make number of lines configurable
	for( int x=1; x <= g_Config.iSAheight && x <= g_LCD->GetRows(); x++)
	{
		if (x==1)
		{
			g_LCD->SetPosition(g_Config.iSAcol, g_Config.iSArow);
			g_LCD->Write(line1);
		}

		if (x==2)
		{
			g_LCD->SetPosition(g_Config.iSAcol, g_Config.iSArow - 1);
			g_LCD->Write(line2);
		}
		if (x==3)
		{
			g_LCD->SetPosition(g_Config.iSAcol, g_Config.iSArow - 2);
			g_LCD->Write(line3);
		}
		if (x==4)
		{
			g_LCD->SetPosition(g_Config.iSAcol, g_Config.iSArow - 3);
			g_LCD->Write(line4);
		}
	}

    LeaveCriticalSection(&critSecLCDWrite);
  }
}

// Anzeigen der Daten f�r den VU Spectrum Analyser
__declspec(dllexport) void spec_analyser_vudata(char *line1)
{
  // don't display VU while in cfg menu, MZ 2002/02/03
  if (g_bOutput && g_Spectrum_Analyser.in_menu == 0 && g_Spectrum_Analyser.active == 1)
  {
    if (g_Spectrum_Analyser.char_loaded == 0)
    {
        // Chars fuer Spectrum Analyser sind noch nicht vorhanden.
        char *p;
        char szBuffer[] = "1,1,1,1,1,1,1,1|2,2,2,2,2,2,2,2|4,4,4,4,4,4,4,4|8,8,8,8,8,8,8,8|16,16,16,16,16,16,16,16|32,32,32,32,32,32,32,32|0,0,0,0,0,0,0,0";
        char *p2 = szBuffer, *pEnd = p2 + strlen(p2);
        int i=0, iSize = strlen(szBuffer);
        p = strtok(p2, "|");
        while(p != NULL)
		{
            if(i == MAX_CUSTOM_CHAR)
                break;
            g_Config.carrMenueChar[i++].Set(p);
            p2 += strlen(p) + 1;
            if(p2 >= pEnd)
                break;
            p = strtok(p2, "|");
		}
        SetMenueChars();
        g_Spectrum_Analyser.char_loaded = 1;
    }

    EnterCriticalSection(&critSecLCDWrite);     // only one thread can access the LCD at the same time (OutputTimerFunc also writes to the LCD!), M.Zehnder, Jan 27, 01
    // @todo make position configurable
	g_LCD->SetPosition(g_Config.iSAcol, g_Config.iSArow);
    g_LCD->Write(line1);
    LeaveCriticalSection(&critSecLCDWrite);
  }
}

#ifdef __cplusplus
}
#endif


BEGIN_MESSAGE_MAP(CGen_lcddisplayApp, CWinApp)
	//{{AFX_MSG_MAP(CGen_irApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGen_lcddisplayApp construction

CGen_lcddisplayApp::CGen_lcddisplayApp()
{
    // TODO: add construction code here,
    // Place all significant initialization in InitInstance
	g_Config.eInitStatus = IN_PROGRESS;
}

BOOL CGen_lcddisplayApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}
	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// The one and only CGen_lcddisplayApp object

CGen_lcddisplayApp theApp;


/******************************************************************************
Function : GetLastErrorMsg
Purpose  : Calls the GetLastError() function and returns a formated error msg.
Parameters : lpBuffer : pointer to buffer for storing the error message.
			 iBufLen  : length of lpBuffer
Returns : Pointer to the error msg (lpBuffer)
Author  : Markus Zehnder	12.08.99
******************************************************************************/
LPCTSTR GetLastErrorMsg( LPTSTR lpBuffer, int iBufLen){
	// get the system error message
	if (FormatMessage( 
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		lpBuffer,
		iBufLen,
		NULL 
		) == 0)
	{

		_tcsncpy(lpBuffer, _T("?"), iBufLen);
		lpBuffer[iBufLen] = _T('\0');
	}

	return lpBuffer;
}

