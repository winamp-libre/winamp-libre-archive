#if !defined(AFX_DLGPAGEADDITIONNAL_H__973C662C_7EBF_403D_B366_DF7705572460__INCLUDED_)
#define AFX_DLGPAGEADDITIONNAL_H__973C662C_7EBF_403D_B366_DF7705572460__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgPageAdditional.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgPageAdditional dialog

class CDlgPageAdditional : public CPropertyPage
{
	DECLARE_DYNCREATE(CDlgPageAdditional)

// Construction
public:
	BOOL m_bEq1;
	BOOL m_bEq2;
	CDlgPageAdditional();
	~CDlgPageAdditional();

// Dialog Data
	//{{AFX_DATA(CDlgPageAdditional)
	enum { IDD = IDD_PAGE_ADDITIONNAL };
	BOOL	m_bOnPause;
	BOOL	m_bOnStop;
	CString	m_cOnStop;
	CString	m_cOnPause;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CDlgPageAdditional)
	public:
	virtual BOOL OnApply();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CDlgPageAdditional)
	virtual BOOL OnInitDialog();
	afx_msg void OnCheckOnpause();
	afx_msg void OnCheckOnstop();
	afx_msg void OnChangeEditPause();
	afx_msg void OnChangeEditStop();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGPAGEADDITIONNAL_H__973C662C_7EBF_403D_B366_DF7705572460__INCLUDED_)
