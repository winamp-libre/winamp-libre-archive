/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// DlgCfgNoritake.cpp : Cfg Dlg for Noritake LCD's
//
// Modifications:
// 2002/11/10 MZ  display port as hex value & let user edit port value
// 2003/02/08 MZ  turbo, write & init delay added, brightness settings fixed
// 
//
// @TODO: 
// - custom fonts 
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "DlgCfgNoritake.h"
#include "LcdNoritake.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgNoritake dialog


CDlgCfgNoritake::CDlgCfgNoritake(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgCfgNoritake::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgCfgNoritake)
	m_csHeight = _T("");
	m_csPort = _T("");
	m_csWidth = _T("");
	m_byCCharEnd = 0;
	m_byCCharStart = 0;
	m_byCellHeight = 0;
	m_byCellWidth = 0;
	m_csFontFile = _T("");
	m_iDelayInit = 0;
	m_bTurbo = FALSE;
	m_iDelayWrite = 0;
	//}}AFX_DATA_INIT
}


void CDlgCfgNoritake::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgCfgNoritake)
	DDX_Control(pDX, IDC_BRIGHTNESS_SLIDER, m_cBrightness);
	DDX_CBString(pDX, IDC_COMBO_HEIGHT, m_csHeight);
	DDX_CBString(pDX, IDC_COMBO_PORT, m_csPort);
	DDX_CBString(pDX, IDC_COMBO_WIDTH, m_csWidth);
	DDX_Text(pDX, IDC_CCHAR_END, m_byCCharEnd);
	DDX_Text(pDX, IDC_CCHAR_START, m_byCCharStart);
	DDX_Text(pDX, IDC_CELLH_EDIT, m_byCellHeight);
	DDX_Text(pDX, IDC_CELLW_EDIT, m_byCellWidth);
	DDX_Text(pDX, IDC_EDIT_FONTFILE, m_csFontFile);
	DDV_MaxChars(pDX, m_csFontFile, 255);
	DDX_Text(pDX, IDC_EDIT_INITDELAY, m_iDelayInit);
	DDV_MinMaxInt(pDX, m_iDelayInit, 0, 1000);
	DDX_Check(pDX, IDC_CHECK_TURBO, m_bTurbo);
	DDX_Text(pDX, IDC_EDIT_WRITEDELAY, m_iDelayWrite);
	DDV_MinMaxInt(pDX, m_iDelayWrite, 0, 100);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgCfgNoritake, CDialog)
	//{{AFX_MSG_MAP(CDlgCfgNoritake)
	ON_BN_CLICKED(IDC_DEF_BTN, OnDefBtn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgCfgNoritake message handlers

BOOL CDlgCfgNoritake::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	char	szTemp[10];

	wsprintf(szTemp, "%x", g_NoritakeCfg.iPort);
	m_csPort = szTemp;
	m_csWidth = itoa( g_NoritakeCfg.iWidth, szTemp, 10 );
	m_csHeight = itoa( g_NoritakeCfg.iHeight, szTemp, 10 );
	m_byCellWidth = g_NoritakeCfg.byCellW;
	m_byCellHeight = g_NoritakeCfg.byCellH;

	m_cBrightness.SetRange(0, 15);
	m_cBrightness.SetPos(g_NoritakeCfg.byBrightness);

	m_bTurbo = g_NoritakeCfg.bTurbo;
	m_iDelayInit = g_NoritakeCfg.iDelayInit;
	m_iDelayWrite = g_NoritakeCfg.iDelayShort;
	
	// @TODO: implement following cfg parameters in LCD driver...
	m_csFontFile = "[internal]";
	m_byCCharStart = DEF_NO_CCHAR_START;
	m_byCCharEnd   = DEF_NO_CCHAR_END;

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgCfgNoritake::OnDefBtn() 
{
	char szBuf[10];

	m_csPort = "378";
	m_csHeight = itoa(DEF_NO_HEIGHT, szBuf, 10);
	m_csWidth  = itoa(DEF_NO_WIDTH, szBuf, 10);
	m_byCCharStart = DEF_NO_CCHAR_START;
	m_byCCharEnd   = DEF_NO_CCHAR_END;
	m_byCellHeight = DEF_NO_CELL_H;
	m_byCellWidth  = DEF_NO_CELL_W;
	m_cBrightness.SetPos(DEF_NO_BRIGHTNESS);
	m_bTurbo = TRUE;
	m_iDelayInit = DEF_NO_DELAY_INIT;
	m_iDelayWrite = DEF_NO_DELAY_SHORT;
	
	UpdateData(FALSE);
}

void CDlgCfgNoritake::OnOK() 
{
	UpdateData();

	g_NoritakeCfg.iWidth = atoi( m_csWidth );
	g_NoritakeCfg.iHeight = atoi( m_csHeight );
	sscanf(m_csPort, "%x", &g_NoritakeCfg.iPort);
	if (g_NoritakeCfg.iPort <= 0) {
		g_NoritakeCfg.iPort = 0x378;
	}
	g_NoritakeCfg.byCellW = m_byCellWidth;
	g_NoritakeCfg.byCellH = m_byCellHeight;
	g_NoritakeCfg.byBrightness = m_cBrightness.GetPos();
	g_NoritakeCfg.bTurbo = m_bTurbo;
	g_NoritakeCfg.iDelayInit = m_iDelayInit;
	g_NoritakeCfg.iDelayShort = m_iDelayWrite;
	
	CDialog::OnOK();
}
