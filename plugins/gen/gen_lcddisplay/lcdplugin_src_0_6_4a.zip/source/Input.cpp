/////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 1999-2003 Markus Zehnder. All Rights Reserved.
//
//  This file is part of the WinAmp LCD Display Plugin project.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//
// If the source code for this program is not available from the place 
// whence you received this file, check http://www.markuszehnder.ch or
// contact the author on lcdplugin@markuszehnder.ch for information on obtaining
// it.
//
// It would be nice of you letting me know that you are using it, as well as
// sending me your modifications, bugfixes and enhancements.
//
//
/////////////////////////////////////////////////////////////////////////////
//
// Base class of all input drivers.
// Defines driver functions and implements common functions and plugin actions.
//
/////////////////////////////////////////////////////////////////////////////
//
// Modifications:
// 2002/01/10 MZ  Bugfix: after SA gets inactive reload normal custom chars,
//                don't start SA if menu is active.
//                Enhancement: direct number input added (as in the old version)
//                with additional timout. 
// 2002/06/16 MZ  Enhancement for long keypress actions & some new methods
// 2003/01/23 MZ Included TiTi's version T4 changes (http://www.poulpy.com/lcdplugin/)
// 2003/01/25 MZ Included TiTi's version T5 changes (http://www.poulpy.com/lcdplugin/)
// 2003/01/26 MZ - ReAdded some old functions that were no longer present in TiTi's version
//               - long kepress bugfix
// 2003/07/12 MZ Replaced hard coded custom chars in file browser, works now with every display 
// 2003/08/03 MZ improved DoReInit()
// 2003/11/02 MZ DoReInit(): safety pause added before opening device again
//
// CVS: $Author: mrzed $, $Revision: 1.17 $, $Date: 2003/11/03 00:02:05 $
// 
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "gen_lcddisplay.h"
#include "LCDMenuShow.h"
#include "DynaMenus.h"

#include "Input.h"
#include "Winamp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
int   CInput::m_iJump2Number = 0;
DWORD CInput::m_dwLastInput = 0;
BOOL  CInput::m_bBacklight = FALSE;

extern bool g_bEqua;
extern int  g_uiEquaBand;
extern BOOL g_uiEquaSpec;
extern CDynaMenus g_DynaMenus;


CInput::CInput()
{
	m_bInitialized = FALSE;
}

CInput::~CInput()
{

}

BOOL CInput::ShowMenu()
{

	if (g_bEqua)
	{
		g_bEqua = FALSE;
		Menu_Leave(&sCurrMenu);
		Menu_Update(&sCurrMenu);

		if (g_uiEquaSpec)
		{
			// Re activate spectrum analyser if needed
			g_Spectrum_Analyser.active = 1;
			g_bUpdateAll = TRUE;
		}
	}
	else if (Menu_IsActive(&sCurrMenu))
	{
		Menu_Leave(&sCurrMenu);
		Menu_Update(&sCurrMenu);

	}
	else
	{
		g_DynaMenus.EnterMenu(&sCurrMenu, g_DynaMenus.m_MenuStruct);
//		Menu_Enter(&sCurrMenu, aMainMenu, sizeof(aMainMenu) / sizeof(tMenuLine), 0);
		Menu_Update(&sCurrMenu);
	}

	return TRUE;
}

BOOL CInput::MenuSelect()
{
	if(Menu_IsActive(&sCurrMenu))
	{
		Menu_Select(&sCurrMenu);
		Menu_Update(&sCurrMenu);         
	}

	return TRUE;
}

BOOL CInput::SwitchOutputSet()
{
	g_Config.cOutputFields.SwitchSet();
	// update all fields, this clears the display as well
	g_bUpdateAll = TRUE;

	return TRUE;
}

BOOL CInput::SwitchBacklight()
{
	m_bBacklight = !m_bBacklight;

	if (g_LCD != NULL) {
		g_LCD->SetBacklight(m_bBacklight ? 0 : -1);
	}

	return TRUE;
}

BOOL CInput::DoReInit()
{
	if (g_LCD != NULL) {
		g_LCDFactory.CloseLCD();

		// make sure display is properly closed, e.g. Crystalfontz needs some time before it can be opened again!
		Sleep(1500);

		g_LCD = g_LCDFactory.GetLCDDriver();                                                    // Seriellen/Parallelen Treiber laden
		
		if (!g_LCDFactory.OpenLCD(g_LCD)) {
			g_LCD = NULL;
		} else {
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CInput::MenuUp()
{
	if (g_bEqua)
	{
		int orig;
		float forig;

		orig = SendMessage(g_Plugin.hwndParent, WM_USER, (WPARAM)g_uiEquaBand, (LPARAM)127);

		forig = (float)(40 * orig) / (float)64;	// scale value;
		orig = (int)forig;
		if (forig - orig > 0.5)
			orig++;
		orig = -(orig - 20);

		orig += 1;
		if (orig > 20)
			orig = 20;

		orig = (-orig) + 20;
		forig = (float)(64 * orig) / (float)40;
		orig = (int)forig;
		if (forig - orig > 0.5)
			orig++;

		SendMessage(g_Plugin.hwndParent, WM_USER, (WPARAM)orig, (LPARAM)128);
		return (TRUE);
	}
	
	if (Menu_IsActive(&sCurrMenu))
	{
		Menu_Up(&sCurrMenu);
		Menu_Update(&sCurrMenu);
	}

	return TRUE;
}

BOOL CInput::MenuDown()
{
	if (g_bEqua)
	{
		int orig;
		float forig;

		orig = SendMessage(g_Plugin.hwndParent, WM_USER, (WPARAM)g_uiEquaBand, (LPARAM)127);

		forig = (float)(40 * orig) / (float)64;	// scale value;
		orig = (int)forig;
		if (forig - orig > 0.5)
			orig++;
		orig = -(orig - 20);

		orig -= 1;
		if (orig < -20)
			orig = -20;

		orig = (-orig) + 20;
		forig = (float)(64 * orig) / (float)40;
		orig = (int)forig;
		if (forig - orig > 0.5)
			orig++;

		SendMessage(g_Plugin.hwndParent, WM_USER, (WPARAM)orig, (LPARAM)128);
		return (TRUE);
	}
	
	if (Menu_IsActive(&sCurrMenu))
	{
		Menu_Down(&sCurrMenu);
		Menu_Update(&sCurrMenu);
	}

	return TRUE;
}

BOOL CInput::Previous()
{
	sCurrMenu.iLineSelected = (sCurrMenu.iLineSelected - 10) % (sCurrMenu.iLineCnt - 1);
	if (sCurrMenu.iLineSelected < 0)
		sCurrMenu.iLineSelected = sCurrMenu.iLineCnt - 1 + sCurrMenu.iLineSelected;
	Menu_ResetTimer(&sCurrMenu);
	Menu_Update(&sCurrMenu);
	return TRUE;
}

BOOL CInput::Next()
{
	sCurrMenu.iLineSelected = (sCurrMenu.iLineSelected + 10) % (sCurrMenu.iLineCnt - 1);
	Menu_ResetTimer(&sCurrMenu);
	Menu_Update(&sCurrMenu);
	return TRUE;
}

BOOL CInput::PlayPause()
{
	if (g_WinAmpInfo.iPlaybackStatus == 1) {   
		// currently playing
		SendMessage(g_Plugin.hwndParent,WM_COMMAND, WINAMP_PAUSE,0);
	} else {
		SendMessage(g_Plugin.hwndParent,WM_COMMAND, WINAMP_PLAY,0);
	}

	return TRUE;
}

BOOL CInput::ShowAnalyzer()
{
	if (g_Spectrum_Analyser.in_menu)
		return TRUE;

	if (g_bEqua)
		return TRUE;
	
	g_Spectrum_Analyser.active = (g_Spectrum_Analyser.active ? 0 : 1);

	if (g_Spectrum_Analyser.active == 0) {
		// unload custom chars for the SA
		g_Spectrum_Analyser.char_loaded = 0; 
		// and reload the normal custom chars
		SetCustomChars();
	}

	// update all fields, this clears the display as well
	g_bUpdateAll = TRUE;

	return TRUE;
}

BOOL CInput::Jump2Number()
{
	if (m_iJump2Number == 0) {
		m_iJump2Number = -1;
		// init timeout
		m_dwLastInput = GetTickCount();
	} else {
		int iPlaylistLength = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETLISTLENGTH);
		
		m_iJump2Number = abs(m_iJump2Number);
		
		if (m_iJump2Number > iPlaylistLength)		// if Nr. > Playliste, then set
			m_iJump2Number = iPlaylistLength;		// end of playlist

		SendMessage(g_Plugin.hwndParent,WM_WA_IPC,(m_iJump2Number -1),IPC_SETPLAYLISTPOS);
		SendMessage(g_Plugin.hwndParent,WM_COMMAND, WINAMP_PLAY,0);		// und abspielen

		// reset
		m_iJump2Number = 0;
	}

	return TRUE;
}

BOOL CInput::Jump10Forward()
{
	int iPlaylistLength = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETLISTLENGTH);
	int iPos = SendMessage(g_Plugin.hwndParent,WM_WA_IPC,0,IPC_GETLISTPOS);
	if((iPos+10) >= iPlaylistLength)
		iPos = iPos+10 - iPlaylistLength;
	else
		iPos += 10;

	SendMessage(g_Plugin.hwndParent,WM_WA_IPC,iPos,IPC_SETPLAYLISTPOS);
	SendMessage(g_Plugin.hwndParent,WM_COMMAND, WINAMP_PLAY,0);

	return TRUE;
}

void CInput::ExecuteAction(const action &act, BOOL bLongPress)
{
	LPARAM fct    = act.fct;   
	WPARAM msgNbr = act.msgNbr;

    if (bLongPress) {
		if (act.fctLong || act.msgLong) {
			fct = act.fctLong;
			msgNbr = act.msgLong;
		} else if (!act.repeatable) {
			// no repeat action defined
			return;
		}
	} 

	for (int j=0; j < act.count; j++) {
		// check if internal or WinAmp command
		if (fct != 0) {
			// internal function

			ActionFctn action = (ActionFctn)fct;
			action();
		} else {
			if (msgNbr != 0) {
				PostMessage(
					g_Plugin.hwndParent,
					act.message == 0 ? WM_COMMAND : act.message,	// bugfix MZ 2003/01/26 act.message must be checked
					msgNbr,
					0);
			}
		}
	}
}

const action* CInput::GetCommand(LPCTSTR lpButtonName, CStringArray &buttons, CDWordArray &actions)
{
	int max;
	if((max = buttons.GetSize()) != actions.GetSize()) {
		TRACE("CInput::GetCommand ERROR: mismatch between buttons and actions!\n");
		return NULL;
	}

	// find the button
	for (int i = 0; i < max; i++)
		if (stricmp(buttons[i], lpButtonName) == 0)
			break;

	if (i == max)
		return NULL;

	return &acts[actions[i]];
}

BOOL CInput::HandleSongPosInput(int key)
{
	if (key >= VK_NUMPAD0)
		key = key - (VK_NUMPAD0 - '0');

	if (!isdigit(key) || m_iJump2Number == 0)
		return FALSE;

	// timeout handling if user doesn't press the ending 'jump2number' key or enters the digits too slowly
	if (GetTickCount() - m_dwLastInput >= INPUT_TIMEOUT) {
		m_iJump2Number = 0;
		return FALSE;
	}

	int digit = key - '0';

	m_iJump2Number = CalculatePlayNo(m_iJump2Number, digit);

	m_dwLastInput = GetTickCount();

	return TRUE;
}

static char char_lower(char c)
{
	if (c <= 'Z' && c >= 'A')
	{
		return (c - ('A' - 'a'));
	}
	return (c);
}

BOOL CInput::NextLetter()
{
	if (Menu_IsActive(&sCurrMenu))
	{
		int cursel = sCurrMenu.iLineSelected;
		int oldsel = cursel;
		
		while (1)
		{
			cursel++;
			if (cursel >= sCurrMenu.iLineCnt)
				cursel = 0;
			if (cursel == oldsel)
			{
				// We falled back on initial item
				break;
			}
			if ((sCurrMenu.pFirstLine[oldsel].cTextBuff[0] == g_cCBox_Unchecked || sCurrMenu.pFirstLine[oldsel].cTextBuff[0] == g_cCBox_Checked) &&
				(sCurrMenu.pFirstLine[cursel].cTextBuff[0] == g_cCBox_Unchecked || sCurrMenu.pFirstLine[cursel].cTextBuff[0] == g_cCBox_Checked))
			{
				if (char_lower(sCurrMenu.pFirstLine[cursel].cTextBuff[1]) != char_lower(sCurrMenu.pFirstLine[oldsel].cTextBuff[1]))
					break;
			}
			else if (char_lower(sCurrMenu.pFirstLine[cursel].cTextBuff[0]) != char_lower(sCurrMenu.pFirstLine[oldsel].cTextBuff[0]))
			{
				break;
			}
			
		}

		sCurrMenu.iLineSelected = cursel;
		Menu_ResetTimer(&sCurrMenu);


		Menu_Update(&sCurrMenu);
	}
	return (TRUE);
}

BOOL CInput::PreviousLetter()
{
	if (Menu_IsActive(&sCurrMenu))
	{
		int cursel = sCurrMenu.iLineSelected;
		int oldsel = cursel;
		int tmpsel;
		
		while (1)
		{
			cursel--;
			if (cursel < 0)
				cursel = sCurrMenu.iLineCnt - 1;
			if (cursel == oldsel)
			{
				// We falled back on initial item
				break;
			}
			if ((sCurrMenu.pFirstLine[oldsel].cTextBuff[0] == g_cCBox_Unchecked || sCurrMenu.pFirstLine[oldsel].cTextBuff[0] == g_cCBox_Checked) &&
				(sCurrMenu.pFirstLine[cursel].cTextBuff[0] == g_cCBox_Unchecked || sCurrMenu.pFirstLine[cursel].cTextBuff[0] == g_cCBox_Checked))
			{
				if (char_lower(sCurrMenu.pFirstLine[cursel].cTextBuff[1]) != char_lower(sCurrMenu.pFirstLine[oldsel].cTextBuff[1]))
				{
					break;
				}
			}
			else if (char_lower(sCurrMenu.pFirstLine[cursel].cTextBuff[0]) != char_lower(sCurrMenu.pFirstLine[oldsel].cTextBuff[0]))
			{
				break;
			}
		}
		
		oldsel = cursel;

		while (1)
		{
			tmpsel = cursel;
			cursel--;
			if (cursel < 0)
				cursel = sCurrMenu.iLineCnt - 1;
			if (cursel == oldsel)
			{
				// We falled back on initial item
				break;
			}
			if ((sCurrMenu.pFirstLine[oldsel].cTextBuff[0] == g_cCBox_Unchecked || sCurrMenu.pFirstLine[oldsel].cTextBuff[0] == g_cCBox_Checked) &&
				(sCurrMenu.pFirstLine[cursel].cTextBuff[0] == g_cCBox_Unchecked || sCurrMenu.pFirstLine[cursel].cTextBuff[0] == g_cCBox_Checked))
			{
				if (char_lower(sCurrMenu.pFirstLine[cursel].cTextBuff[1]) != char_lower(sCurrMenu.pFirstLine[oldsel].cTextBuff[1]))
				{
					break;
				}
			}
			else if (char_lower(sCurrMenu.pFirstLine[cursel].cTextBuff[0]) != char_lower(sCurrMenu.pFirstLine[oldsel].cTextBuff[0]))
			{
				break;
			}
		}

		sCurrMenu.iLineSelected = tmpsel;
		Menu_ResetTimer(&sCurrMenu);

		Menu_Update(&sCurrMenu);
	}
	return (TRUE);
}

BOOL CInput::SelectAll()
{
	if (!Menu_IsActive(&sCurrMenu))
	{
		return (TRUE);
	}

	if (sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff2[0] == (char)0xFE ||
		sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff2[0] == (char)0xFD)
	{
		char toset = 0;
		for (int i = 0; i < sCurrMenu.iLineCnt; ++i)
		{
			if (sCurrMenu.pFirstLine[i].cTextBuff[0] < 6)
			{
				if (toset == 0)
				{
					if (sCurrMenu.pFirstLine[i].cTextBuff[0] == g_cCBox_Unchecked)
						toset = g_cCBox_Checked;
					else
						toset = g_cCBox_Unchecked;
				}
				sCurrMenu.pFirstLine[i].cTextBuff[0] = toset;
			}
		}
		Menu_Update(&sCurrMenu);
	}
	return (TRUE);
}

BOOL CInput::MenuRight()
{
	if (g_bEqua)
	{
		if (g_uiEquaBand <= 8)
			g_uiEquaBand++;
		if (g_uiEquaBand == 10)
			g_uiEquaBand = 0;
		return (TRUE);
	}
	if (sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff2[0] == (char)0xFE)
	{
		// We are on a directory in the browser;
		Menu_Select(&sCurrMenu);
		Menu_Update(&sCurrMenu);
	}
	else if (sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff2[0] == (char)0xFD)
	{
		// We are on a song file in the browser
		if (sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff[0] == g_cCBox_Unchecked)
			sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff[0] = g_cCBox_Checked;
		else
			sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff[0] = g_cCBox_Unchecked;
		Menu_Update(&sCurrMenu);
	}
	return TRUE;

}

BOOL CInput::MenuLeft()
{
	if (g_bEqua)
	{
		if (g_uiEquaBand >= 1)
			g_uiEquaBand--;
		else if (g_uiEquaBand == 0)
			g_uiEquaBand = 10;
		return (TRUE);
	}

	if (sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff2[0] == (char)0xFE)
	{
		char *ptrend, *ptr;

		ptrend = sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].cTextBuff2;
		ptrend += strlen(ptrend) - 2;

		while (*ptrend != '\\')
		{
			if (*ptrend == (char)0xFE)
				return (TRUE);
			ptrend--;
		}
		ptrend--;
		while (*ptrend != '\\')
		{
			if (*ptrend == (char)0xFE)
			{
				Menu_Leave(&sCurrMenu);
				WinampMenuBrowse(&sCurrMenu);
				Menu_Update(&sCurrMenu);
				return (TRUE);
			}
			ptrend--;
		}
		ptr = ptrend;
		ptr--;
		*(ptrend + 1) = 0;
		sCurrMenu.pFirstLine[sCurrMenu.iLineSelected].pActionFunc = WinampMenuBrowseDir;
		return (MenuSelect());

	}
	return TRUE;
}

BOOL CInput::Nothing()
{
	// Idle bind
	return (TRUE);
}

BOOL CInput::ShowBrowser()
{
	// @TODO handle long key press = backlight on / off

	if (g_bEqua)
	{
		g_bEqua = FALSE;
		Menu_Leave(&sCurrMenu);
		Menu_Update(&sCurrMenu);

		if (g_uiEquaSpec)
		{
			// Re activate spectrum analyser if needed
			g_Spectrum_Analyser.active = 1;
			g_bUpdateAll = TRUE;
		}
	}
	else if (Menu_IsActive(&sCurrMenu))
	{
		Menu_Leave(&sCurrMenu);
		Menu_Update(&sCurrMenu);
		return TRUE;
	}

	WinampMenuBrowse(&sCurrMenu);
	Menu_Update(&sCurrMenu);

	return TRUE;
}

BOOL CInput::ClearPlaylist()
{
	SendMessage(g_Plugin.hwndParent, WM_WA_IPC, 0, IPC_DELETE);
	return TRUE;
}

BOOL CInput::SystemShutdown()
{
	SystemShutdownFunc(SYSTEM_SHUTDOWN);
	return TRUE;
}

BOOL CInput::SystemStandby()
{
	SystemShutdownFunc(SYSTEM_STANDBY);
	return TRUE;
}

BOOL CInput::SystemReboot()
{
	SystemShutdownFunc(SYSTEM_REBOOT);
	return TRUE;
}

BOOL CInput::SystemHibernate()
{
	SystemShutdownFunc(SYSTEM_HIBERNATE);
	return TRUE;
}

BOOL CInput::SystemSleepTimer()
{
	if(!g_bSleepActive)
	{
		SetSleepTimer(15);
	}
	else
	{
		if((g_iSleepTime / 60) < (15 - 1))
			g_iSleepTime = 15 * 60;
		else if((g_iSleepTime / 60) < (29 - 1))
			g_iSleepTime = 30 * 60;
		else if((g_iSleepTime / 60) < (45 - 1))
			g_iSleepTime = 45 * 60;
		else if((g_iSleepTime / 60) < (60 - 1))
			g_iSleepTime = 60 * 60;
		else if((g_iSleepTime / 60) < (75 - 1))
			g_iSleepTime = 75 * 60;
		else if((g_iSleepTime / 60) < (90 - 1))
			g_iSleepTime = 90 * 60;
		else if((g_iSleepTime / 60) >= (90 - 1))
			ResetSleepTimer();
	}
	return TRUE;
}