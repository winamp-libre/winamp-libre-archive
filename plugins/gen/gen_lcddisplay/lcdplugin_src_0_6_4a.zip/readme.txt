WinAmp LCD Plugin README

Version: 0.6.4 alpha source release
Date:    2003/11/02

Development environment: Visual Studio C++ 6.0 SP5
Required libraries: ogg vorbis sdk


This is just a quick readme file, please refer to the plugin page for up to 
date information:
http://www.markuszehnder.ch/projects/lcdplugin/


Why and what is an alpha version? 
- This binary version is based on the CVS files in SourceForge.net as of 2003/11/02, tag 'rel_0_6_4_alpha'
- Most features should work as expected with some exceptions, see below.
- This code base has only been minimally tested, that's why it's just an alpha version.
- Use this version at your own risk! Don't blame me if your computer crashes
  and you loose your diploma work, love letters or whatsoever ;)
- If you have problems or question please post a message in the help forum:
  http://sourceforge.net/forum/forum.php?forum_id=28093
  You don't need to register at SourceForge!
  From now on this is the preferred way of getting support. If you just send me an email, 
  I might not reply - I will read it though and try to fix the problem for the next beta 
  release but no other users will be aware of it or are able to help you!
- Post bug reports on SourceForge, this is the best way to notify me and others of bugs
  and to keep track of its status: 
  https://sourceforge.net/tracker/?group_id=9036&atid=109036

---

Supported LCDs:

Matrix Orbital serial LCD/VFD
Crystalfontz 632/634 serial v1.3
HD44780
Noritake VFD 800
PJRC 8x24            (http://www.pjrc.com)
Scott Edwards Serial (not personally tested, but should work)
Optrex SED153x       (not personally tested, but should work)
Milford 4x20 bpk     (not personally tested, but should work)
HD667xx              (NOT TESTED AT ALL!)


I'd appreciate it if you give me feedback for the untested drivers.

---

Required driver for HD44780, HD667xx, Noritake & SED153x

NT Port I/O Driver from Scientific Software Tools, Inc: 
http://www.driverlinx.com

This free driver is required for Windows NT 4, 2000 and XP.

Attention: the Noritake driver requires it for Windows 9x/ME as well!

---

LCD interface wiring diagrams

- HD44780
See either hd44780_howto.txt or

8-Bit, one controller: 
http://www.markuszehnder.ch/projects/lcdplugin/images/lcd_parallel_8bit.gif

8-Bit, two controllers (4x40 LCD): 
http://www.markuszehnder.ch/projects/lcdplugin/images/lcd_parallel_8bit_2controller.gif

hd44780_howto.txt also contains information about keypads and the backlight ciruit.
Many thanx to the Linux project lcdproc! Attention: extended 8-bit is not supported.


See gen_LCD.ini section [Keypad] for parallel keypad configuration.
The purpose is to assign one character to each button. This character must
be specified and linked to an action in the plugin input cfg page.


- Noritake VFD 800 
See Noritake_800_pinouts.txt

---

Installation


1.) copy the following files from the binary release (lcdplugin_bin_0.6.3a.zip)
into the WinAmp plugin directory (normally c:\program files\winamp\plugins):
 - gen_lcddisplay.dll
 - vis_spec_analyser.dll
 - lcdmenu.ini
 - gen_LCD.ini (not required if you already have an older 0.6.x version installed!)

2.) Configure the plugin to your needs :) 
The plugin configuration is located in Winamp under 'Plug-ins, General Purpose --> 
LC Display plug-in [version]'. (Press Ctrl+P to display Winamp's configuration screen).

Detailed information: 
http://markuszehnder.ch/projects/lcdplugin/download.php#installation
http://markuszehnder.ch/projects/lcdplugin/configuration.php

---

Change Log


0.6.4 alpha

New features:
- Sleep timer
- 44780 shift register interface with 2 wires
- LCD re-init option
- input options for shutdown, standby, hibernate & reboot
- standby and hibernation options re-initialize plugin after wake up

Modifications:
- internal LCD driver handling greatly improved. Simplifies future driver development and contributions.
- Equalizer removed from dynamic menu configuration (was never working and not intended to be public).

Bugfixes:
- memory leaks introduced with dynamic menus fixed
- shutdown option now powers off computer
- PJRC & Crystalfontz driver: correct newline handling


0.6.3 alpha

New features:
- Custom character map for each LCD. See gen_lcd.ini
- Dynamic menus. Thanks Tilo & TiTi
- configurable LCD msg text for shutdown, reboot, standby and hibernate. See gen_lcd.ini

Modifications:
- No error dialog if connection to WinLIRC server failed.

Bugfixes:
- [611676] Reversed Hibernate/Standy Menu Functions. Bug was closed but slipped in again...
- [764503] song position (%6) for songs > 60 min
- synchronizing keypad access: the parallel keypad needs to write data as well, very bad if the SA writes at the same time!
- Input functions "Winamp: Play Audio-CD" and "Winamp: Current track as bookmark" are working now
- [762793] Song position returns to 00:00 when pressing stop in Winamp.
- [762793] Reselected old options in Display page when pressing Start/Stop button.
- [762793] Adding a set twice or more without adding any field results in sets with same number
- [732568] Wrong characters in browse menu (check boxes)
- WinampKeyboard edit key function


0.6.2 alpha

New features:
- Advanced WinLIRC configuration: Thresholds for repeating keys. Finally WinLIRC is usable! (request 611654)
- Checking if AlbumList plugin is installed, if not a msg is printed in the LCD menu
- AlbumList: enqueue album - thanks Tilo

Modifications:
- All WinLIRC entries in gen_lcd.ini are now grouped in a section called [WinLIRC]
  If you don't want to loose your old settings:
  1) Start & close Winamp to create the new [WinLIRC] section and its keys
  2) Delete all keys in [WinLIRC]
  3) Move all WinLIRC_### entries in the section [WinLIRC] and remove the trailing "WinLIRC_"
- Faster sorting

Bugfixes:
- [641582] Problems With Winlirc and the Menus
- [750620] Crash after cancel keyboard add dlg
- [709832] Can't get track number if there's an ID3v2 -> track tag added, year tag fixed
- [709848] If you delete a set, they all disappear
- [619116] Custom Character Scrolling
- "Play Artist" function improved, about 12 x faster - thanks Tilo


0.6.1 alpha

New features:
- New input driver 'Winamp Keyboard'. Credits go to Tilo Arnold, thanx!
Captures key inputs from Winamp's main window. This keyboard driver will now work with
Girder (http://www.girder.nl) and most probably with other remote control tools as well!

- Updated hd44780_howto.txt. Credits go to Ulrich Meyer-Ciolek, thanx!
> The pinout of the 4094 shift-register and the connection to the LCD was wrong. The
> attached version is tested and works perfect.


0.6 alpha 

New major features since 0.5:
- id3v2 tag support
- file system browser (LCD menu)
- bounce scrolling mode
- extended input (default action, menu action, set action)
- additional LCD drivers
- Volume bar
- Performance counters (cpu & memory)
- Internal architecture changes for improved performance / greater accuracy
- bugfixes and new bugs ;-)

Bugfixes:
- Crystalfonz driver:
  - CTS & DTR lines are set again, i.e. the display is powered over the serial line.
  - Spectrum Analyzer works
- Noritake driver:
  - clear sreen command fixed
  - brightness settings
- Improved Plugin shutdown procedure
- Serial input
- HD44780 timing problems

Removed or disabled features:
- Output variables: %S
- Most german resources


---

General:

Not working features:

- LCD equalizer
- Noritake driver: only the first 8 custom characters will work
- ?


Untested features:

- Win9x compatability! (Performance Monitoring features should not be loaded)
- German OS (invalid resources)
- HD667xx driver
- HD44780 backlight circuit
- HD44780 4 bit interface & Shift register interface (Got positive feedback that it works!)
- Extended parallel port input (architecture has been rewritten since last release)


Known bugs:

- See bug list on SourceForge: https://sourceforge.net/tracker/?group_id=9036&atid=109036
- Non-linear spectrum analyzer only works when output size is set to 4 x 20
- Display problems with Repeat and shuffle output variables (%rep or %s displayed for
  a short time)
- Memory leaks (Noritake custom characters and some others)
- There are many more...

---

How to contact me


Support: http://sourceforge.net/forum/forum.php?forum_id=28093

For bug reports: https://sourceforge.net/tracker/?group_id=9036&atid=109036

For feature requests: https://sourceforge.net/tracker/?atid=359036&group_id=9036&func=browse

Anything else: lcdplugin@markuszehnder.ch

Please be patient if you send me an email. I usually reply to every email,
but it can take several weeks since I'm often on business trips with limited
internet access & time...

---

Copyright (c) 1999 - 2003 by Markus Zehnder

Oh, by the way, it's Open Source!
The source code is available at SourceForge:
https://sourceforge.net/projects/lcdplugin/

Read the GNU Public License for the terms and conditions for copying, 
distribution and modification:
http://www.gnu.org/copyleft/gpl.html

Don't forget to send me your enhancements and modifications ;-)

And I don't mind a PayPal donation if you really like this software :-D
