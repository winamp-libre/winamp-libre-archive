/*
 * Winamp httpQ Plugin
 * Copyright (C) 1999-2003 Kosta Arvanitis
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Kosta Arvanitis (karvanitis@hotmail.com)
 */
#include "httpq.h"

#include "commandmap.h"
#include "commands.h"
#include "query.h"
#include "socketwriter.h"


//--------------------------------------------------
// Command/Function map
//--------------------------------------------------
const char *gArgValidate_PasswordA[] = {"pass"};
const char *gArgPlay[]               = {"p"};
const char *gArgStop[]               = {"p"};
const char *gArgPause[]              = {"p"};
const char *gArgNextTrack[]          = {"p"};
const char *gArgPreviousTrack[]      = {"p"};
const char *gArgFadeoutAndStop[]     = {"p"};
const char *gArgGetVersion[]         = {"p"};
const char *gArgDelete[]             = {"p"};
const char *gArgIsPlaying[]          = {"p"};
const char *gArgGetListLength[]      = {"p"};
const char *gArgGetListPos[]         = {"p"};
const char *gArgGetPlayListPos[]     = {"p"};
const char *gArgShuffle_Status[]     = {"p"};
const char *gArgRepeat_Status[]      = {"p"};
const char *gArgVolumeUp[]           = {"p"};
const char *gArgVolumeDown[]         = {"p"};
const char *gArgFlushPlayList[]      = {"p"};
const char *gArgGetCurrentTitle[]    = {"p"};
const char *gArgUpdateCurrentTitle[] = {"p"};
const char *gArgInternet[]           = {"p"};
const char *gArgRestart[]            = {"p"};
const char *gArgGetAutoService[]     = {"p"};
const char *gArgShoutCast_Connect[]  = {"p"};
const char *gArgShoutCast_Status[]   = {"p"};
const char *gArgGetPlayListTitle[]   = {"p", "delim"};
const char *gArgGetPlayListFile[]    = {"p", "delim"};
const char *gArgExec_Visual[]        = {"p"};
const char *gArgGetVolume[]          = {"p"};
const char *gArgGetPlayListTitleA[]  = {"p", "index"};
const char *gArgGetPlayListFileA[]   = {"p", "index"};
const char *gArgDeletePosA[]         = {"p", "index"};
const char *gArgGetOutputTimeA[]     = {"p", "frmt"};
const char *gArgJumpToTimeA[]        = {"p", "ms"};
const char *gArgSetPlayListPosA[]    = {"p", "index"};
const char *gArgChDirA[]             = {"p", "dir"};
const char *gArgPlayFileA[]          = {"p", "file"};
const char *gArgGetInfoA[]           = {"p", "info"};
const char *gArgShuffleA[]           = {"p", "enable"};
const char *gArgRepeatA[]            = {"p", "enable"};
const char *gArgSetVolumeA[]         = {"p", "level"};
const char *gArgGetEqDataA[]         = {"p", "band"};
const char *gArgSetAutoServiceA[]    = {"p", "enable"};
const char *gArgSetEqDataA[]         = {"p", "band", "level"};
const char *gArgGetId3Tag[]          = {"p", "tags", "delim"};
const char *gArgGetMpegInfo[]        = {"p", "info", "delim"}; 

const CommandMapItem gCommandMap[] =
{
    //  cmd, func, arg_count, arg_list

    {"",                    Root,               0,  NULL},
    {"validate_password",   Validate_PasswordA, 1,  gArgValidate_PasswordA},
    {"play",                Play,               1,  gArgPlay},
    {"stop",                Stop,               1,  gArgStop},
    {"pause",               Pause,              1,  gArgPause},
    {"next",                NextTrack,          1,  gArgNextTrack},
    {"prev",                PreviousTrack,      1,  gArgPreviousTrack},
    {"fadeoutandstop",      FadeoutAndStop,     1,  gArgFadeoutAndStop},
    {"getversion",          GetVersion,         1,  gArgGetVersion},
    {"delete",              Delete,             1,  gArgDelete},
    {"isplaying",           IsPlaying,          1,  gArgIsPlaying},
    {"getlistlength",       GetListLength,      1,  gArgGetListLength},
    {"getlistpos",          GetListPos,         1,  gArgGetListPos},
    {"getplaylistpos",      GetPlayListPos,     1,  gArgGetPlayListPos},
    {"shuffle_status",      Shuffle_Status,     1,  gArgShuffle_Status},
    {"repeat_status",       Repeat_Status,      1,  gArgRepeat_Status},
    {"volumeup",            VolumeUp,           1,  gArgVolumeUp},
    {"volumedown",          VolumeDown,         1,  gArgVolumeDown},
    {"flushplaylist",       FlushPlayList,      1,  gArgFlushPlayList},
    {"getcurrenttitle",     GetCurrentTitle,    1,  gArgGetCurrentTitle},
    {"updatecurrenttitle",  UpdateCurrentTitle, 1,  gArgUpdateCurrentTitle},
    {"internet",            Internet,           1,  gArgInternet},
    {"restart",             Restart,            1,  gArgRestart},
    {"getautoservice",      GetAutoService,     1,  gArgGetAutoService},
    {"shoutcast_connect",   ShoutCast_Connect,  1,  gArgShoutCast_Connect},
    {"shoutcast_status",    ShoutCast_Status,   1,  gArgShoutCast_Status},
    {"getplaylisttitle",    GetPlayListTitle,   2,  gArgGetPlayListTitle},
    {"getplaylistfile",     GetPlayListFile,    2,  gArgGetPlayListFile},
    {"exec_visual",         Exec_Visual,        1,  gArgExec_Visual},
    {"getvolume",           GetVolume,          1,  gArgGetVolume},
    {"getplaylisttitle",    GetPlayListTitleA,  2,  gArgGetPlayListTitleA},
    {"getplaylistfile",     GetPlayListFileA,   2,  gArgGetPlayListFileA},
    {"deletepos",           DeletePosA,         2,  gArgDeletePosA},
    {"getoutputtime",       GetOutputTimeA,     2,  gArgGetOutputTimeA},
    {"jumptotime",          JumpToTimeA,        2,  gArgJumpToTimeA},
    {"setplaylistpos",      SetPlayListPosA,    2,  gArgSetPlayListPosA},
    {"chdir",               ChDirA,             2,  gArgChDirA},
    {"playfile",            PlayFileA,          2,  gArgPlayFileA},
    {"getinfo",             GetInfoA,           2,  gArgGetInfoA},
    {"shuffle",             ShuffleA,           2,  gArgShuffleA},
    {"repeat",              RepeatA,            2,  gArgRepeatA},
    {"setvolume",           SetVolumeA,         2,  gArgSetVolumeA},
    {"setautoservice",      SetAutoServiceA,    2,  gArgSetAutoServiceA},
    {"geteqdata",           GetEqDataA,         2,  gArgGetEqDataA},
    {"seteqdata",           SetEqDataA,         3,  gArgSetEqDataA},
    {"getid3tag",           GetId3Tag,          3,  gArgGetId3Tag},
    {"getmpeginfo",         GetMpegInfo,        3,  gArgGetMpegInfo},
};


const CommandMapItem *FindFunction(Query &query)
{
    const CommandMapItem *pCommand = NULL;

    for(int i=0; i<ARRAYSIZE(gCommandMap); i++)
    {
        pCommand = &gCommandMap[i];
        
        // number of arguments does not match
        if (query.NumArguments() != pCommand->ArgCount)
            continue;

        // command names do not match
        if(strcmp(query.GetPath(), pCommand->Command) != 0)
            continue;

        // validate each argument exists
        bool err = false;
        for(unsigned int i =0; i < pCommand->ArgCount; i++)
        {
            const char *arg = pCommand->Args[i];
            if (!query.ContainsArgument(arg))
            {
                err = true;
                break;
            }
        }
        if (err)
            continue;

        // we have a match
        return pCommand;
    }

    return NULL;
}

