//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by httpq.rc
//
#define IDD_DIALOG                      101
#define IDD_ABOUT                       102
#define IDD_GENERAL                     103
#define IDD_ADVANCED                    104
#define IDD_SECURITY                    105
#define IDD_IP                          107
#define IDC_TREE                        1000
#define IDC_START                       1001
#define IDC_STOP                        1002
#define IDC_FRAME                       1003
#define ID_IP_ADDRESS                   1004
#define ID_GENERAL_PASSWORD             1005
#define ID_GENERAL_PORT                 1006
#define ID_GENERAL_AUTO_SERVICE         1007
#define ID_GENERAL_PASSWORD_LABEL       1008
#define ID_GENERAL_PORT_LABEL           1009
#define ID_ADVANCED_HEADERS_ENABLED     1011
#define ID_ADVANCED_TIMEOUT_LABEL       1012
#define ID_ADVANCED_TIMEOUT             1017
#define ID_SECURITY_ALLOW_ALL           1019
#define ID_SECURITY_DENY_ALL            1020
#define ID_SECURITY_ADDR_LIST           1021
#define ID_SECURITY_ADD                 1023
#define ID_SECURITY_REMOVE              1025
#define ID_ABOUT_LINE1                  1029
#define ID_ABOUT_LINE2                  1030
#define ID_ABOUT_LICENSE                1031
#define ID_ABOUT_EMAIL                  1032
#define ID_ABOUT_WEB                    1034
#define ID_GENERAL_IP_ADDRESS           1044
#define ID_GENERAL_IP_ADDRESS_LABEL     1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
