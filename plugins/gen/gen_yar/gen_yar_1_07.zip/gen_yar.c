#define WIN32_MEAN_AND_LEAN
// this shows places bar in filedialog
//#define _WIN32_WINNT 0x0501
#include <windows.h>
#include "frontend.h"
#include "gen.h"
#include "resource.h"

// size optimizations
#ifdef NDEBUG
//#pragma comment(linker,"/merge:.text=.data")
//#pragma comment(linker,"/ignore:4078")
//#pragma comment(linker,"/opt:nowin98")
#endif

#define MYMENUITEM 49998
#define MYUPDATER	WM_USER+70

BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved) {
	return TRUE;
}

BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam,LPARAM lParam);

void config();
void quit();
int init();
#define APPVER "v1.07"
#define APPSHORTNAME "Yar-matey!"
#define APPNAME APPSHORTNAME " Playlist Copier"
#define APPNAMEVER APPNAME " " APPVER

void SaveThemFiles();

winampGeneralPurposePlugin plugin = {
	GPPHDR_VER,
	APPNAMEVER,
	init,
	config,
	quit,
};

void config() {
	MessageBox(plugin.hwndParent,
		APPNAMEVER
		"\nhttp://apps.bcheck.net/\n\n"
		"Pick 'Copy playlist files' from\nthe main Winamp/system menu.",
		"About " APPSHORTNAME, MB_ICONINFORMATION | MB_RIGHT);
}

void quit() {
}

BOOL g_bSavePlaylist=FALSE;
BOOL g_bNumberFiles=TRUE;
BOOL g_bUsePlaylistTitle=FALSE;
BOOL g_bIncludeDirectory=FALSE;

void config_read()
{
	char ini_file[MAX_PATH], *p;
	GetModuleFileName(plugin.hDllInstance,ini_file,sizeof(ini_file));
	p=ini_file+lstrlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	lstrcat(ini_file,"plugin.ini");

	g_bSavePlaylist = GetPrivateProfileInt(APPNAME,"SavePlaylist",g_bSavePlaylist,ini_file);
	g_bNumberFiles = GetPrivateProfileInt(APPNAME,"NumberFilenames",g_bNumberFiles,ini_file);
	g_bUsePlaylistTitle = GetPrivateProfileInt(APPNAME,"UsePlaylistTitle",g_bUsePlaylistTitle,ini_file);
	g_bIncludeDirectory = GetPrivateProfileInt(APPNAME,"IncludeDirectory",g_bIncludeDirectory,ini_file);
}

void config_write()
{
	char ini_file[MAX_PATH], *p;
	char string[32];
	GetModuleFileName(plugin.hDllInstance,ini_file,sizeof(ini_file));
	p=ini_file+lstrlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	lstrcat(ini_file,"plugin.ini");

	wsprintf(string,"%d",g_bSavePlaylist);
	WritePrivateProfileString(APPNAME,"SavePlaylist",string,ini_file);

	wsprintf(string,"%d",g_bNumberFiles);
	WritePrivateProfileString(APPNAME,"NumberFilenames",string,ini_file);

	wsprintf(string,"%d",g_bUsePlaylistTitle);
	WritePrivateProfileString(APPNAME,"UsePlaylistTitle",string,ini_file);

	wsprintf(string,"%d",g_bIncludeDirectory);
	WritePrivateProfileString(APPNAME,"IncludeDirectory",string,ini_file);
}

void* mymalloc(size_t bytes) {
	void* mem;
	if(!bytes) return NULL;
	mem=HeapAlloc(GetProcessHeap(), 0, bytes);
	return mem;
}

void myfree(void* mem) {
	if(mem)
		HeapFree(GetProcessHeap(), 0, mem);
}

int PlayListCount;

DWORD FileSize(const char* szFileName) {
	WIN32_FIND_DATA ffd;
	HANDLE hFind = FindFirstFile(szFileName, &ffd);
	if(hFind!=INVALID_HANDLE_VALUE)
		FindClose(hFind);
	else
		ffd.nFileSizeLow=0;
	return ffd.nFileSizeLow;
}

DWORD WINAPI FileCountThread(LPVOID lpParameter) {
	HWND hwnd=(HWND)lpParameter;
	char *szFileName;
	DWORD fsize=0;
	int x;
	for(x=0;x<PlayListCount; x++) {
		szFileName=(char*)SendMessage(plugin.hwndParent, WM_USER, x, IPC_GETPLAYLISTFILE);
		fsize += FileSize(szFileName)/1024;
		if(PlayListCount>10 && x%(PlayListCount/10)==0) {
			if(IsWindow(hwnd))
				PostMessage((HWND)hwnd, MYUPDATER, fsize, TRUE);
			else
				return 0;
		}
	}

	if(IsWindow(hwnd))
		PostMessage((HWND)hwnd, MYUPDATER, fsize, FALSE);

	return 0;
}

void FileHookInitDialog(HWND hdlg) {
	DWORD dwThreadId;
	PlayListCount=SendMessage(plugin.hwndParent, WM_USER, 0, IPC_GETLISTLENGTH);

	CreateThread(NULL, 0, FileCountThread, (LPVOID)hdlg, 0, &dwThreadId);

	{
	char crap[255];
	if(PlayListCount>1000)
		wsprintf(crap, "%d,%03d", PlayListCount/1000, PlayListCount%1000);
	else
		wsprintf(crap, "%d", PlayListCount);
	SetDlgItemText(hdlg, IDC_FILES, crap);
	}

	config_read();
	CheckDlgButton(hdlg, IDC_PLAYLIST, g_bSavePlaylist);
	CheckDlgButton(hdlg, IDC_NUMBER, g_bNumberFiles);
	CheckDlgButton(hdlg, IDC_PLAYLISTTITLE, g_bUsePlaylistTitle);
	CheckDlgButton(hdlg, IDC_INCLUDEDIR, g_bIncludeDirectory);
}

void FileHookDestroy(HWND hdlg) {
	g_bSavePlaylist = IsDlgButtonChecked(hdlg, IDC_PLAYLIST);
	g_bNumberFiles = IsDlgButtonChecked(hdlg, IDC_NUMBER);
	g_bUsePlaylistTitle = IsDlgButtonChecked(hdlg, IDC_PLAYLISTTITLE);
	g_bIncludeDirectory = IsDlgButtonChecked(hdlg, IDC_INCLUDEDIR);
	config_write();
}

UINT APIENTRY OFNHookProc(HWND hdlg, UINT uiMsg, WPARAM wParam, LPARAM lParam) {

	switch(uiMsg) {
	case WM_INITDIALOG:
		FileHookInitDialog(hdlg);
		return FALSE;
	case WM_DESTROY:
		FileHookDestroy(hdlg);
		return FALSE;
	case WM_NOTIFY :
		if( ((LPOFNOTIFY)lParam)->hdr.code == CDN_INITDONE) {
			RECT rect;
			GetWindowRect(GetParent(hdlg), &rect);
			SetWindowPos(GetParent(hdlg), 0, 
				(GetSystemMetrics(SM_CXSCREEN)-(rect.right-rect.left))/2,
				(GetSystemMetrics(SM_CYSCREEN)-(rect.bottom-rect.top))/2,
				0, 0, SWP_NOSIZE);
		}
		return TRUE;
	case MYUPDATER:
		{
			char crap[255];
			if(wParam>1024*1024)
				wsprintf(crap, "%s%d,%03d.%d MB", (lParam?"+":""), wParam/(1024*1024),wParam/1024%1024, wParam/102%10);
			else
				wsprintf(crap, "%s%d.%d MB", (lParam?"+":""), wParam/1024, wParam/102%10);
			SetDlgItemText(hdlg, IDC_FILESIZE, crap);
		}
		return TRUE;
	}
	return FALSE;
}

BOOL WriteLine(HANDLE hFile, const char* text) {
	DWORD byteswritten;
	return WriteFile(hFile, text, lstrlen(text), &byteswritten, NULL);
}

char* mystrrchr(char* str, char charToFind) {
    char *p=str;
	char *rp=str;
	for(; *p; p++) {
		if(*p==charToFind)
			rp=p;
	}
	return rp;
}

// given szFile = "c:\pathname\stuff\application.exe"
// return int lstrlen
//        NameStart = "application.exe"
//        ExtStart  = ".exe"
//
int CrackFilename(char* szFile, char** ppNameStart, char** ppExtStart) {
	char* NameStart, *ExtStart;
	int stringLength = lstrlen(szFile);

	NameStart = mystrrchr(szFile, '\\');
	if(!NameStart) NameStart = szFile;
	else NameStart++;
	if(ppExtStart) {
		ExtStart = mystrrchr(NameStart, '.');
		if(!ExtStart) ExtStart = NameStart+stringLength;
		*ppExtStart = ExtStart;
	}
	if(ppNameStart)
		*ppNameStart = NameStart;

	return stringLength;
}

void CopyFiles(char* szDestLoc, int nFileOffset) {
	DWORD buffsizeFrom, buffsizeTo;
	char *bigbuffFrom, *bigbuffTo, *pFrom, *pTo;
	char numberFormatString[6]; // "%03d_"
	HANDLE hPlsFile;

	int x, destDirLength, numberStringLength;
	const char *szSrcLoc;
	if(g_bSavePlaylist) {
		SendMessage(plugin.hwndParent, WM_COMMAND, WINAMP_BUTTON4, 0); // must stop to get lengths
		lstrcpy(&szDestLoc[nFileOffset], "playlist.m3u");
		hPlsFile = CreateFile(szDestLoc, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, 0, NULL);
		if(hPlsFile == INVALID_HANDLE_VALUE) {
			MessageBox(plugin.hwndParent, "Error creating playlist file.", APPNAMEVER, MB_OK);
			return;
		}
		WriteLine(hPlsFile, "#EXTM3U\r\n");
	}

	// set up format for number prepend
	if(g_bNumberFiles) {
		int numberLength = (
			PlayListCount <       10 ? 1 :
			PlayListCount <      100 ? 2 :
			PlayListCount <     1000 ? 3 :
			PlayListCount <    10000 ? 4 :
			PlayListCount <   100000 ? 5 :
			PlayListCount <  1000000 ? 6 :
			PlayListCount < 10000000 ? 7 :
			PlayListCount <100000000 ? 8 : 9);
		wsprintf(numberFormatString, "%%0%dd_", numberLength);
		numberStringLength = numberLength +1;
	}

// how big of a buffer ?
	buffsizeFrom=buffsizeTo=0;
	destDirLength = lstrlen(szDestLoc);
	for(x=0; x<PlayListCount; x++) {
		char *sourcePath, *sourceFilename, *sourceExtension;
		int sourcePathLength, destTitleLength, destPathLength;

		// determine source length
		sourcePath = (char*)SendMessage(plugin.hwndParent, WM_USER, x, IPC_GETPLAYLISTFILE);
		sourcePathLength = CrackFilename(sourcePath, &sourceFilename, &sourceExtension);
		buffsizeFrom += sourcePathLength +1; //+1 for separator

		// determine dest length
		if(g_bUsePlaylistTitle) {
			char *destTitle = (char*)SendMessage(plugin.hwndParent, WM_USER, x,IPC_GETPLAYLISTTITLE);
			destTitleLength = lstrlen(destTitle);
		} else
			destTitleLength = sourceExtension-sourceFilename;

		// get parent dir
		if(g_bIncludeDirectory && sourceFilename>sourcePath+4) { // is this a problem for network shares?
			char* parentDirectory = sourceFilename-2;
			while(parentDirectory>sourcePath+4 && *parentDirectory!='\\')
				parentDirectory--;
			destTitleLength += sourceFilename-parentDirectory;
		}

		destPathLength = destDirLength + destTitleLength + lstrlen(sourceExtension);
		buffsizeTo += destPathLength + 1 +(g_bNumberFiles?numberStringLength:0); //+1 for separator, +4 for "003_"
	}

	// allocate From and To buffers
	bigbuffFrom = mymalloc(buffsizeFrom+1); // +1 for termination
	bigbuffTo = mymalloc(buffsizeTo+1); // +1 for termination

// now build the big strings
	pFrom = bigbuffFrom;
	pTo = bigbuffTo;
	for(x=0; x<PlayListCount; x++) {
		szSrcLoc=(char*)SendMessage(plugin.hwndParent, WM_USER, x, IPC_GETPLAYLISTFILE);
		if(FileSize(szSrcLoc)>0) { // skip missing / bad files
			char *destTitle, *sourcePath, *sourceFilename, *sourceExtension, *destFilename;
			int sourcePathLength, destTitleLength;

			// -- add source file
			sourcePath = (char*)SendMessage(plugin.hwndParent, WM_USER, x, IPC_GETPLAYLISTFILE);
			sourcePathLength = CrackFilename(sourcePath, &sourceFilename, &sourceExtension);
			lstrcpy(pFrom, sourcePath);
			pFrom += sourcePathLength+1;
			*pFrom=0;

			// -- add destination file
			// add destination directory
			lstrcpyn(pTo, szDestLoc, nFileOffset+1);
			pTo += nFileOffset;
			destFilename=pTo; // just filename (no path) for playlist

			// include parent dir
			if(g_bIncludeDirectory && sourceFilename>sourcePath+4) { // is this a problem for network shares?
				char* parentDirectory = sourceFilename-2;
				while(parentDirectory>sourcePath+4 && *parentDirectory!='\\')
					parentDirectory--;
				lstrcpyn(pTo, parentDirectory+1, sourceFilename-parentDirectory);
				pTo += sourceFilename-parentDirectory-1;
			}

			// add number
			if(g_bNumberFiles) {
				wsprintf(pTo, numberFormatString, x+1);
				pTo+=numberStringLength;
			}
			// get dest title (either playlist title or filename without path and extension)
			if(g_bUsePlaylistTitle) {
				destTitle = (char*)SendMessage(plugin.hwndParent, WM_USER, x,IPC_GETPLAYLISTTITLE);;
				destTitleLength = lstrlen(destTitle);
			} else {
				destTitle = sourceFilename;
				destTitleLength = sourceExtension-sourceFilename;
			}
			// add dest title
			lstrcpyn(pTo, destTitle, destTitleLength+1);

			// Remove bad chars from the file name (note much of this dll is not unicode-safe!)
			{
				char *p=pTo;
				for(;*p;p++) {
					switch(*p) {
						case '<': *p='�'; break;
						case '>': *p='�'; break;
						case '"': *p='\'';break;
						case '?': *p='�'; break;
						case '*': *p='+'; break;
						case '|': *p='!'; break;
						case '\\':*p='_'; break;
						case '/': case ':': *p='-';
					}
				}
			}
			pTo += destTitleLength;

			// add file extension
			lstrcpy(pTo, sourceExtension);
			pTo += lstrlen(sourceExtension)+1;
			*pTo=0;

			// -- add playlist entry
			if(g_bSavePlaylist) {
				int songlength;
				char *playlistTitle;
				char crap[50];
				SendMessage(plugin.hwndParent, WM_USER, x, IPC_SETPLAYLISTPOS);
				songlength = SendMessage(plugin.hwndParent, WM_USER, 1, IPC_GETOUTPUTTIME);
				playlistTitle = (char*)SendMessage(plugin.hwndParent, WM_USER, x,IPC_GETPLAYLISTTITLE);;
				wsprintf(crap, "#EXTINF:%d,", songlength);
				WriteLine(hPlsFile, crap);
				WriteLine(hPlsFile, playlistTitle);
				WriteLine(hPlsFile, "\r\n");
				WriteLine(hPlsFile, destFilename);
				WriteLine(hPlsFile, "\r\n");
			}
		} else { // bad/missing file
			char crap[MAX_PATH+20];
			wsprintf(crap, "Error copying file: '%s', skipping.", szSrcLoc);
			MessageBox(plugin.hwndParent, crap, APPNAMEVER, MB_OK);
		}
	}
	if(g_bSavePlaylist)
		CloseHandle(hPlsFile);
// now copy the files
	{
		SHFILEOPSTRUCT fileOp;
		fileOp.hwnd = plugin.hwndParent;
		fileOp.wFunc = FO_COPY;
		fileOp.pFrom = bigbuffFrom;
		fileOp.pTo = bigbuffTo;
		fileOp.fFlags = FOF_MULTIDESTFILES | FOF_NOCONFIRMMKDIR;
		SHFileOperation(&fileOp);
	}

	myfree(bigbuffFrom);
	myfree(bigbuffTo);
}

void SaveThemFiles() {
	OPENFILENAME ofn;
	char szDestLoc[MAX_PATH];

	ofn.Flags = OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_EXPLORER
		| OFN_ENABLETEMPLATE | OFN_ENABLEHOOK | OFN_ENABLESIZING;
	ofn.hInstance = plugin.hDllInstance;
	ofn.lpTemplateName = MAKEINTRESOURCE(IDD_FILEDLG);
	ofn.lpfnHook = &OFNHookProc;

	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.lpstrFile = szDestLoc;
	ofn.nMaxFile = sizeof(szDestLoc);
	ofn.lpstrTitle = "Select location to save files to";
	ofn.hwndOwner = plugin.hwndParent;
	ofn.lpstrFilter = "All Files";
	ofn.lpstrInitialDir = ofn.lpstrDefExt = ofn.lpstrCustomFilter = ofn.lpstrFileTitle = NULL;
	ofn.nFilterIndex = 0;
	lstrcpy(szDestLoc, "(Filename Ignored)");

	if(GetSaveFileName(&ofn))
		CopyFiles(szDestLoc, ofn.nFileOffset);
}

HACCEL hAccel;

LRESULT MyProc(LPVOID oldproc, HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	if(message==WM_KEYDOWN || message==WM_SYSKEYDOWN) {
		MSG msg;
		msg.hwnd = hwnd;
		msg.message = message;
		msg.wParam = wParam;
		msg.lParam = lParam;
		msg.time = GetMessageTime();
		GetCursorPos(&msg.pt);
		if(TranslateAccelerator(plugin.hwndParent, hAccel, &msg))
			return TRUE;
	} else if((message==WM_COMMAND || message==WM_SYSCOMMAND)&& LOWORD(wParam)==MYMENUITEM) {
		SaveThemFiles();
		return 0;
	}
	return CallWindowProc(oldproc,hwnd,message,wParam,lParam);
}

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK PEWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK EQWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK MBWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK VideoWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ALWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

struct proc {
	const char* ClassName;
	void* newproc;
	void* oldproc;
} procs[] = {
	NULL, MainWndProc, NULL, // first is just the hwnd.parent
	"Winamp PE", PEWndProc, NULL,
	"Winamp EQ", EQWndProc, NULL,
	"Winamp MB", MBWndProc, NULL,
	"Winamp Video", VideoWndProc, NULL,
	"Winamp AL", ALWndProc, NULL
};
#define proccount sizeof(procs)/sizeof(struct proc)

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	return MyProc(procs[0].oldproc, hwnd,message,wParam,lParam);
}
LRESULT CALLBACK PEWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	return MyProc(procs[1].oldproc, hwnd,message,wParam,lParam);
}
LRESULT CALLBACK EQWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	return MyProc(procs[2].oldproc, hwnd,message,wParam,lParam);
}
LRESULT CALLBACK MBWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	return MyProc(procs[3].oldproc, hwnd,message,wParam,lParam);
}
LRESULT CALLBACK VideoWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	return MyProc(procs[4].oldproc, hwnd,message,wParam,lParam);
}
LRESULT CALLBACK ALWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	return MyProc(procs[5].oldproc, hwnd,message,wParam,lParam);
}

int init() {
	{ /* override lots of winamp windows so Alt+C works (almost) everywhere */
		int x;
		HWND hwnd;
		for(x=0; x<proccount; x++) {
			if(x==0)
				hwnd = plugin.hwndParent;
			else 
				hwnd = FindWindow(procs[x].ClassName, NULL);
			if(hwnd!=NULL) {
				procs[x].oldproc = (void *)GetWindowLong(hwnd,GWL_WNDPROC);
				SetWindowLong(hwnd,GWL_WNDPROC,(LONG)procs[x].newproc);
			}
		}
	}

	{ /* insert my menu item above exit */
		MENUITEMINFO mii;
		HMENU hMenu = GetSystemMenu(plugin.hwndParent, FALSE);
		HMENU hSubMenu = GetSubMenu(hMenu, 0);
		if(hSubMenu) // if there is no submenu, this is not winamp, just put it in the system menu
			hMenu=hSubMenu;
	
		mii.cbSize = sizeof(MENUITEMINFO);
		mii.fMask = MIIM_TYPE | MIIM_ID | MIIM_DATA;
		mii.fType = MFT_STRING;
		mii.wID = MYMENUITEM;
		mii.dwTypeData = "Copy playlist files\tAlt+C";
		InsertMenuItem(hMenu, GetMenuItemCount(hMenu)-1, TRUE, &mii);
	}
	hAccel = LoadAccelerators(plugin.hDllInstance, MAKEINTRESOURCE(IDR_ACCEL_YAR));

	return 0;
}

__declspec( dllexport ) winampGeneralPurposePlugin * winampGetGeneralPurposePlugin() {
	return &plugin;
}