//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by gen_yar.rc
//
#define IDR_ACCEL_YAR                   101
#define IDD_FILEDLG                     102
#define IDC_PLAYLIST                    1000
#define IDC_NUMBER                      1001
#define IDC_FILESIZE                    1002
#define IDC_SHOWPLAYLIST                1003
#define IDC_NUMBER2                     1003
#define IDC_PLAYLISTTITLE               1003
#define IDC_FILES                       1004
#define IDC_PLAYLISTTITLE2              1005
#define IDC_INCLUDEDIR                  1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
