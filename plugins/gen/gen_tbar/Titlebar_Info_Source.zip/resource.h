//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gen_tbar_3.rc
//
#define IDD_DIALOG                      101
#define IDB_TAB_NORMAL                  102
#define IDB_TAB_SELECTED                103
#define IDB_TAB_HILITED                 104
#define IDC_SHOW_REMAINING_TIME         1000
#define IDC_CHOOSE_FONT                 1001
#define IDC_SHOW_PLAYSTATUS             1002
#define IDC_GET_HELP                    1003
#define IDC_HSPIN                       1004
#define IDC_HEDIT                       1005
#define IDC_VEDIT                       1006
#define IDC_VSPIN                       1007
#define IDC_SEARCH_CAPTION              1008
#define IDC_REDRAW_OLD_CAPTION          1009
#define IDC_ABOUT                       1010
#define IDC_PLUGIN_ENABLED              1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
