// gen_tbar_2.cpp : Defines the entry point for the DLL application.
//

#include "gen_tbar_2.h"

gen_tbar* p_gen_tbar;

BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    return TRUE;
}

winampGeneralPurposePlugin plugin = {GPPHDR_VER, "", init, config, quit,};

int init()
{
	HINSTANCE hInstance = plugin.hDllInstance;
	HWND hWndParent     = plugin.hwndParent;

	// Get version information from DLL
	CStdString helpfile;
	CStdString version;

	GetModuleFileName(hInstance, helpfile.GetBuffer(MAX_PATH), MAX_PATH);
	helpfile.ReleaseBuffer();

	version = helpfile;
	PathRemoveFileSpec(helpfile.GetBuffer(MAX_PATH));
	helpfile.ReleaseBuffer();
	helpfile += "\\gen_tbar.chm";

	DWORD dwArg;
	DWORD dwInfoSize = GetFileVersionInfoSize(version.GetBuffer(MAX_PATH), &dwArg);
	version.ReleaseBuffer();

	BYTE* lpBuffer = new BYTE[dwInfoSize];
	GetFileVersionInfo(version.GetBuffer(MAX_PATH), NULL, dwInfoSize, lpBuffer);
	version.ReleaseBuffer();

	UINT uInfoSize;
	LPVOID lpValue;
	
	if (VerQueryValue(lpBuffer, TEXT("\\StringFileInfo\\040904b0\\FileVersion"), &lpValue, &uInfoSize))
		version.Format("Titlebar Info %s", lpValue);
	else
		version = "Titlebar Info x.xx";

	delete[] lpBuffer;
	lpBuffer = NULL;

	// Set plugin description
	static char c[512];
	char filename[512], *p;
	GetModuleFileName(hInstance, filename,sizeof(filename));
	p = filename + lstrlen(filename);
	while (p >= filename && *p != '\\') p--;
	wsprintf((plugin.description = c), "%s (%s)", version.GetBuffer(MAX_PATH), _strlwr(p+1)); // "%s" must be a pointer to char!
	version.ReleaseBuffer();

	p_gen_tbar = new gen_tbar(hInstance, hWndParent, helpfile, version);

	return 0;
}

void quit()
{
	delete p_gen_tbar;
	p_gen_tbar = NULL;
}

void config()
{
	p_gen_tbar->config();
}

extern "C"
__declspec( dllexport ) winampGeneralPurposePlugin * winampGetGeneralPurposePlugin()
{
	return &plugin;
}
