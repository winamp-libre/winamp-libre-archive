#include "gen_tbar.h"

gen_tbar* pGenTbar = NULL;

DWORD WINAPI ThreadProc(LPVOID lpParameter)
{
	while (pGenTbar)
	{
		pGenTbar->draw_titlebar();
		Sleep(1000);
	}

	return 0;
}

BOOL CALLBACK ConfigProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return pGenTbar->config_proc(hwndDlg, uMsg, wParam, lParam);
}

gen_tbar::gen_tbar(HINSTANCE h_dll_instance, HWND hwnd_parent, CStdString help_file, CStdString plugin_version)
{
	hDllInstance = h_dll_instance;
	hWndParent   = hwnd_parent;

	strHelpFile = help_file;
	strVersion  = plugin_version;

	hThread    = NULL;
	dwThreadId = 0;

	// Get data from registry
	data = new char[200];
	
	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "search_caption", &data))
		strSearchCaption = data;
	else
		strSearchCaption.Empty();

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "remaining_time", &data))
		show_remaining_time = (strtol(data, NULL, 10) != 0);
	else
		show_remaining_time = true;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "redraw_old_caption", &data))
		redraw_old_caption = (strtol(data, NULL, 10) != 0);
	else
		redraw_old_caption = false;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_name", &data))
	{
		strncpy(lfont.lfFaceName, data, LF_FACESIZE);
		lfont.lfFaceName[LF_FACESIZE - 1] = '\0';
	}
	else
		strncpy(lfont.lfFaceName, "Arial", LF_FACESIZE);

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_height", &data))
		lfont.lfHeight = strtol(data, NULL, 10);
	else
		lfont.lfHeight = -11;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_weight", &data))
		lfont.lfWeight = strtol(data, NULL, 10);
	else
		lfont.lfWeight = FW_BOLD;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_italic", &data))
		lfont.lfItalic = (unsigned char)strtoul(data, NULL, 10);
	else
		lfont.lfItalic = false;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_underline", &data))
		lfont.lfUnderline = (unsigned char)strtoul(data, NULL, 10);
	else
		lfont.lfUnderline = false;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_strikeout", &data))
		lfont.lfStrikeOut = (unsigned char)strtoul(data, NULL, 10);
	else
		lfont.lfStrikeOut = false;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_color", &data))
		color = strtoul(data, NULL, 10);
	else
		color = GetSysColor(COLOR_CAPTIONTEXT);

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "show_playstatus", &data))
		show_playstatus = (strtol(data, NULL, 10) != 0);
	else
		show_playstatus = false;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "plugin_enabled", &data))
		plugin_enabled = (strtol(data, NULL, 10) != 0);
	else
		plugin_enabled = true;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "shift_horizontal", &data))
		horizontalshift = strtol(data, NULL, 10);
	else
		horizontalshift = 0;

	if (get_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "shift_vertical", &data))
		verticalshift = strtol(data, NULL, 10);
	else
		verticalshift = 0;

	// Set font attributes that cannot be changed
	lfont.lfWidth			= 0;
	lfont.lfEscapement		= 0;
	lfont.lfOrientation		= 0;
	lfont.lfCharSet			= DEFAULT_CHARSET;
	lfont.lfOutPrecision	= OUT_STRING_PRECIS;
	lfont.lfClipPrecision	= CLIP_STROKE_PRECIS;
	lfont.lfQuality			= DRAFT_QUALITY;
	lfont.lfPitchAndFamily	= VARIABLE_PITCH | FF_DONTCARE;

	pInfo = new TitleInfo;
	pInfo->setSearchCaption(strSearchCaption);

	pGenTbar = this;
	hThread  = CreateThread(NULL, 0, ThreadProc, 0, 0, &dwThreadId);
}

gen_tbar::~gen_tbar()
{
	delete pInfo;
	pInfo = NULL;

	pGenTbar = NULL;

	// Save data in registry
	sprintf(data, "%s", strSearchCaption.GetBuffer(512)); // "%s" must be a pointer to char!
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "search_caption", data);

	sprintf(data, "%d", show_remaining_time);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "remaining_time", data);

	sprintf(data, "%d", redraw_old_caption);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "redraw_old_caption", data);

	sprintf(data, "%s", lfont.lfFaceName);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_name", data);

	sprintf(data, "%d", lfont.lfHeight);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_height", data);

	sprintf(data, "%d", lfont.lfWeight);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_weight", data);

	sprintf(data, "%d", lfont.lfItalic);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_italic", data);

	sprintf(data, "%d", lfont.lfUnderline);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_underline", data);

	sprintf(data, "%d", lfont.lfStrikeOut);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_strikeout", data);

	sprintf(data, "%d", color);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "font_color", data);

	sprintf(data, "%d", show_playstatus);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "show_playstatus", data);

	sprintf(data, "%d", plugin_enabled);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "plugin_enabled", data);

	sprintf(data, "%d", horizontalshift);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "shift_horizontal", data);

	sprintf(data, "%d", verticalshift);
	set_registry_string(HKEY_CURRENT_USER, "Software\\radix\\gen_tbar", "shift_vertical", data);
	
	delete[] data;
	data = NULL;
}

void gen_tbar::config()
{
	// Open dialog box for configuration
	DialogBox(hDllInstance, MAKEINTRESOURCE(IDD_DIALOG), hWndParent, ConfigProc);
}

bool gen_tbar::config_proc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_INITDIALOG)							// Initialisation of dialog box
	{
		SetWindowText(hwndDlg, strVersion);

		redraw_old_caption_old  = redraw_old_caption;
		show_remaining_time_old = show_remaining_time;
		show_playstatus_old		= show_playstatus;
		plugin_enabled_old		= plugin_enabled;

		color_old = color;
		lfont_old = lfont;

		horizontalshift_old	= horizontalshift;
		verticalshift_old	= verticalshift;

		CheckDlgButton(hwndDlg, IDC_REDRAW_OLD_CAPTION, redraw_old_caption);
		CheckDlgButton(hwndDlg, IDC_SHOW_REMAINING_TIME, show_remaining_time_old);
		CheckDlgButton(hwndDlg, IDC_SHOW_PLAYSTATUS, show_playstatus_old);

		CheckDlgButton(hwndDlg, IDC_PLUGIN_ENABLED, plugin_enabled_old);
		SetWindowText(GetDlgItem(hwndDlg, IDC_PLUGIN_ENABLED), plugin_enabled?"Plugin en&abled":"Plugin dis&abled");

		sprintf(data, "%s", lfont.lfFaceName);
		HWND hStaticDialog = GetDlgItem(hwndDlg, IDC_CHOOSE_FONT);
		SetWindowText(hStaticDialog, data);

		HWND hHorSpin = GetDlgItem(hwndDlg, IDC_HSPIN);
		SendMessage(hHorSpin, UDM_SETRANGE, 0L, MAKELONG(250, -250));
		SendMessage(hHorSpin, UDM_SETPOS,   0L, MAKELONG(horizontalshift_old, 0));

		HWND hVerSpin = GetDlgItem(hwndDlg, IDC_VSPIN);
		SendMessage(hVerSpin, UDM_SETRANGE, 0L, MAKELONG(20, -20));
		SendMessage(hVerSpin, UDM_SETPOS,   0L, MAKELONG(verticalshift_old, 0));

		HWND hSearchCaption = GetDlgItem(hwndDlg, IDC_SEARCH_CAPTION);
		SendMessage(hSearchCaption, EM_SETLIMITTEXT, (WPARAM) SEARCH_CAPTION_TEXT, 0L);
		SetWindowText(hSearchCaption, strSearchCaption);
	}
	else if ((uMsg == WM_VSCROLL) && (LOWORD(wParam) == SB_THUMBPOSITION))
	{
		HWND hwndScrollBar = (HWND) lParam; // handle to scroll bar 

		if (hwndScrollBar == GetDlgItem(hwndDlg, IDC_HSPIN))
			horizontalshift = (short int) HIWORD(wParam);
		else if (hwndScrollBar == GetDlgItem(hwndDlg, IDC_VSPIN))
			verticalshift = (short int) HIWORD(wParam);
	}
	else if (uMsg == WM_HELP)
	{
		CStdString strContextHelpFile = strHelpFile + "::/popup.txt";

		LPHELPINFO lphi = (LPHELPINFO) lParam;
		if (lphi->iContextType == HELPINFO_WINDOW)
			HtmlHelp((HWND) lphi->hItemHandle, strContextHelpFile, HH_TP_HELP_WM_HELP, (DWORD) id_array) ;
	}
	else if (uMsg == WM_COMMAND)
	{
		switch (LOWORD(wParam))
		{
			case IDC_REDRAW_OLD_CAPTION:	// Check box "Redraw old caption" has been (un)checked
			{
				redraw_old_caption = (IsDlgButtonChecked(hwndDlg,IDC_REDRAW_OLD_CAPTION) == BST_CHECKED?1:0);
				break;
			}
			case IDC_SHOW_REMAINING_TIME:	// Check box "Show remaining time" has been (un)checked
			{
				show_remaining_time = (IsDlgButtonChecked(hwndDlg,IDC_SHOW_REMAINING_TIME) == BST_CHECKED?1:0);
				break;
			}
			case IDC_SHOW_PLAYSTATUS:		// Check box "Show playback status" has been (un)checked
			{
				show_playstatus = (IsDlgButtonChecked(hwndDlg,IDC_SHOW_PLAYSTATUS) == BST_CHECKED?1:0);
				break;
			}
			case IDC_PLUGIN_ENABLED:		// Check box "Plugin ***abled" has been (un)checked
			{
				plugin_enabled = (IsDlgButtonChecked(hwndDlg,IDC_PLUGIN_ENABLED) == BST_CHECKED?1:0);
				SetWindowText(GetDlgItem(hwndDlg, IDC_PLUGIN_ENABLED), plugin_enabled?"Plugin en&abled":"Plugin dis&abled");
				break;
			}
			case IDC_GET_HELP:
			{
				HtmlHelp(NULL, strHelpFile, HH_DISPLAY_TOPIC, 0);
				break;
			}
			case IDC_ABOUT:					// Button "About" has been pressed
			{
				MessageBox(hWndParent, "(c) 1999-2003 by J. van den Oever and M. Zuther\n"
					"Homepage: http://www.mzuther.de/programme/\n\n"
					"Based on \"Notify CD Player\" by Mats Ljungqvist.\n"
					"Converted to plugin by Safai Ma.\n\n"
					"Thanks to anyone who sent ideas or bug reports.\n",
					strVersion, MB_OK|MB_APPLMODAL);
				break;
			}
			case IDC_CHOOSE_FONT:			// Button "Font" has been pressed
			{
				CHOOSEFONT cf;

				cf.lStructSize	= sizeof(CHOOSEFONT);
				cf.hwndOwner	= hwndDlg;
				cf.Flags		= CF_FORCEFONTEXIST | CF_SCREENFONTS | CF_LIMITSIZE | CF_INITTOLOGFONTSTRUCT | CF_EFFECTS;
				cf.lpLogFont	= &lfont;
				cf.nSizeMin		= 6;
				cf.nSizeMax		= 14;
				cf.rgbColors	= color;
				if (ChooseFont(&cf))		// "Ok" button was pressed in font dialog
				{
					color = cf.rgbColors;
					sprintf(data, "%s", lfont.lfFaceName);
					HWND hStaticDialog = GetDlgItem(hwndDlg, IDC_CHOOSE_FONT);
					SetWindowText(hStaticDialog, data);
				}
				break;
			}
			case IDOK:						// "Ok" button was pressed in dialog box
			{
				HWND hSearchCaption = GetDlgItem(hwndDlg, IDC_SEARCH_CAPTION);
				
				GetWindowText(hSearchCaption, strSearchCaption.GetBuffer(SEARCH_CAPTION_TEXT), SEARCH_CAPTION_TEXT);
				strSearchCaption.ReleaseBuffer();

				pInfo->setSearchCaption(strSearchCaption);

				EndDialog(hwndDlg,0);
				break;
			}
			case IDCANCEL:					// "Cancel" button was pressed in dialog box
			{
				redraw_old_caption  = redraw_old_caption_old;
				show_remaining_time	= show_remaining_time_old;
				show_playstatus		= show_playstatus_old;
				plugin_enabled		= plugin_enabled_old;

				horizontalshift	= horizontalshift_old;
				verticalshift	= verticalshift_old;

				lfont = lfont_old;
				color = color_old;

				EndDialog(hwndDlg,0);
				break;
			}
		}
	}

	return false;
}

bool gen_tbar::get_song_data()
{
#if defined __GEN_TBAR_FOR_WINAMP_2__
	// IPC_GETLISTPOS returns the playlist position
	int track_number = SendMessage(hWndParent, WM_USER, 0, IPC_GETLISTPOS);
#elif defined __GEN_TBAR_FOR_WINAMP_3__
	CoreHandle core("Main");
	int track_number = core.getCurPlaybackNumber();
#endif

#if defined __GEN_TBAR_FOR_WINAMP_2__
	// IPC_GETLISTLENGTH returns the length of the current playlist in tracks
	int total_track_number = SendMessage(hWndParent, WM_USER, 0, IPC_GETLISTLENGTH);
#elif defined __GEN_TBAR_FOR_WINAMP_3__
	int total_track_number = core.getNumTracks();
#endif

#if defined __GEN_TBAR_FOR_WINAMP_2__
	// IPC_GETPLAYLISTTITLE gets the title of the playlist entry [index]
	CStdString strTrackName = (char*)SendMessage(hWndParent, WM_USER, track_number, IPC_GETPLAYLISTTITLE);
#elif defined __GEN_TBAR_FOR_WINAMP_3__
	int song_length = 0;
	CStdString strTrackName;
	strTrackName.Empty();

	waServiceFactory* p_service_factory = api->service_getServiceByGuid(nsGUID::fromChar("{B240D9A9-A39D-410D-BFC7-22856AD9F722}"));

	if (p_service_factory)
	{
		svc_plDir* p_svc_pldir = castService<svc_plDir>(p_service_factory);
	
		if (p_svc_pldir && (p_svc_pldir->getNumPlaylists() > 0))
		{
			PlaylistHandle hPlaylist = p_svc_pldir->getCurrentlyPlaying();

			if (hPlaylist != INVALID_PLAYLIST_HANDLE)
			{
				Playlist* p_playlist = p_svc_pldir->getPlaylist(hPlaylist);
			
				if (p_playlist)
				{	
					const char* play_string = p_playlist->enumItem(track_number);
					song_length = api->metadb_getLength(play_string);										// milliseconds
					api->metadb_getMetaData(play_string, MT_NAME, strTrackName.GetBuffer(TEXTLENGTH), TEXTLENGTH, MDT_STRINGZ);	// track name
					strTrackName.ReleaseBuffer();
				}
			}
		}
	}
#endif

	// Prevent further mischief in case of error
	if ((strTrackName == NULL) || strTrackName.IsEmpty())
	{
		strTitle.Empty();
		strTime.Empty();

		return false;
	}
	else
	{
		CStdString strTotalTrackNumber;
		strTotalTrackNumber.Format("%02d", total_track_number);

		CStdString strTrackNumber;
		strTrackNumber.Format("%02d", track_number + 1);

		strTitle = "%t. %n";
		strTitle.Replace("%t", strTrackNumber);
		strTitle.Replace("%T", strTotalTrackNumber);
		strTitle.Replace("%n", strTrackName);	// "%s" must be a pointer to char!
		strTrackName.ReleaseBuffer();

		int play_status;

		if (show_playstatus)

#if defined __GEN_TBAR_FOR_WINAMP_2__
			// IPC_ISPLAYING returns the status of playback
			play_status = SendMessage(hWndParent, WM_USER, 0, IPC_ISPLAYING);	// Paused: 3
#elif defined __GEN_TBAR_FOR_WINAMP_3__
			play_status = core.getStatus();										// Paused: -1
#endif

		else
			play_status = 1; // "[Pause]" or [Stop] are not displayed

		switch (play_status)
		{
			case 1:		// Winamp is playing: get current play time and song length from Winamp
			{

#if defined __GEN_TBAR_FOR_WINAMP_2__
				// IPC_GETOUTPUTTIME returns the position of the current song in milliseconds (mode 0)
				int song_position = SendMessage(hWndParent, WM_USER, 0, IPC_GETOUTPUTTIME);			// milliseconds
				// IPC_GETOUTPUTTIME returns the length of the current song in seconds (mode 1)
				int song_length   = SendMessage(hWndParent, WM_USER, 1, IPC_GETOUTPUTTIME) * 1000;	// convert to milliseconds
#elif defined __GEN_TBAR_FOR_WINAMP_3__
				int song_position = core.getPosition();												// milliseconds
#endif

				if (show_remaining_time) // Show remaining time or play time
					song_position = song_length - song_position;

				song_position = int ((song_position / 1000.0) + 0.5);

				if (song_position < 0) // Track has been written (i.e. encoded) while Winamp already played it
				{
					song_position = abs(song_position);
					strTime.Format(" - [%02d:%02d]", song_position/60, song_position%60);
				}
				else
				{
					strTime.Format(" - %02d:%02d", song_position/60, song_position%60);
				}
				break;
			}

#if defined __GEN_TBAR_FOR_WINAMP_2__
			case 3:		// Playback is currently paused
#elif defined __GEN_TBAR_FOR_WINAMP_3__
			case -1:	// Playback is currently paused
#endif

			{
				strTime = " - [Pause]";
				break;
			}
			default:	// Playback is currently stopped
			{
				strTime = " - [Stop]";
				break;
			}
		}
	}

	return true;
}

void gen_tbar::draw_titlebar()
{
	if (pInfo && plugin_enabled && get_song_data())
	{
		pInfo->setText(strTitle, strTime);
		pInfo->setFont(lfont);
		pInfo->setFontColor(color);
		pInfo->setFontShift(horizontalshift, verticalshift);
		pInfo->setShowPlayStatus(show_playstatus);
		pInfo->setRedrawOldCaption(redraw_old_caption);
		pInfo->drawOnCaption();
	}
}

bool gen_tbar::get_registry_string(HKEY root_key, char* sub_key, char* key_name, char** data)
{
	HKEY hRegistry;
	DWORD dwType = REG_SZ;
	DWORD dwSize = 199;

	RegOpenKeyEx(root_key, sub_key, NULL, KEY_EXECUTE, &hRegistry);
	LONG rueck = RegQueryValueEx(hRegistry, key_name, NULL, &dwType, (BYTE*)*data, &dwSize);
	RegCloseKey(hRegistry);
	hRegistry = NULL;

	return (rueck == ERROR_SUCCESS);
}

bool gen_tbar::set_registry_string(HKEY root_key, char* sub_key, char* key_name, char* data)
{
	char* registry_data = new char[200];
	strncpy(registry_data, data, 200);
	registry_data[199] = '\0';

	HKEY hRegistry;
	DWORD dwSize = 199;
	DWORD dwType = REG_SZ;
	RegCreateKeyEx(root_key, sub_key, NULL, NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hRegistry, NULL);

	dwSize = 199;
	dwType = REG_SZ;
	LONG rueck = RegSetValueEx(hRegistry, key_name, NULL, dwType, (BYTE*)registry_data, strlen(registry_data) + 1);
	RegCloseKey(hRegistry);
	hRegistry = NULL;

	delete[] registry_data;
	registry_data = NULL;

	return (rueck == ERROR_SUCCESS);
}
