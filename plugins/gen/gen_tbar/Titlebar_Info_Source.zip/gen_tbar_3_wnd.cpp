/*

  Nullsoft WASABI Source File License

  Copyright 1999-2001 Nullsoft, Inc.

    This software is provided 'as-is', without any express or implied
    warranty.  In no event will the authors be held liable for any damages
    arising from the use of this software.

    Permission is granted to anyone to use this software for any purpose,
    including commercial applications, and to alter it and redistribute it
    freely, subject to the following restrictions:

    1. The origin of this software must not be misrepresented; you must not
       claim that you wrote the original software. If you use this software
       in a product, an acknowledgment in the product documentation would be
       appreciated but is not required.
    2. Altered source versions must be plainly marked as such, and must not be
       misrepresented as being the original software.
    3. This notice may not be removed or altered from any source distribution.


  Brennan Underwood
  brennan@nullsoft.com

*/

#include "gen_tbar_3_wnd.h"

// Methods required by Window Creation Services
const char *gen_tbar_3_wnd::getWindowTypeName()
{
	// Give it a name to keep things happy
	return "gen_tbar_3 - Configuration";
}

GUID gen_tbar_3_wnd::getWindowTypeGuid()
{
	// We don't have a window to display
	return INVALID_GUID;
}

void gen_tbar_3_wnd::setIconBitmaps(ButtonWnd *button)
{
	// Set the bitmaps for the Thinger
	button->setBitmaps(the->gethInstance(), IDB_TAB_NORMAL, NULL, IDB_TAB_HILITED, IDB_TAB_SELECTED);
}

// The main code
void gen_tbar_3_bucket_item::onLeftPush(int x, int y)
{
	static const GUID guid = 
	{ 0x909daf1b, 0x277c, 0x11d7, { 0x89, 0x10, 0xda, 0x64, 0xb0, 0x45, 0x56, 0x40 } };
	api->cmd_postCommand(guid, "config");
}
