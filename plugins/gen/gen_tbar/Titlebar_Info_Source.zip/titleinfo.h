// class TitleInfo

#ifndef TITLEINFO_H
#define TITLEINFO_H

#include "stdafx.h"
#include "resource.h"

#include <commctrl.h>
#include <commdlg.h>
#include <stdio.h>
#include <stdlib.h>
#include "StdString.h"

class TitleInfo
{
public:
	TitleInfo();
	~TitleInfo();
	void drawOnCaption();
	void setText(CStdString newTitleText, CStdString newTimeText);
	void setSearchCaption(CStdString newSearchCaption);
	bool isStringInCaption(CStdString WindowText);
	void setShowPlayStatus(bool newstatus)							{ bShowPlayStatus = newstatus; }
	void setRedrawOldCaption(bool redraw_old_caption)				{ bRedrawOldCaption = redraw_old_caption; }
	void setFont(LOGFONT lfont)										{ sCaptionFont = lfont; }
	void setFontColor(const DWORD newcolor)							{ nCaptionFontColor = newcolor; }
	void setFontShift(int newHorizontalShift, int newVerticalShift)	{ nHorizontalShift = newHorizontalShift; nVerticalShift   = newVerticalShift; }
private:
	DWORD   nCaptionFontColor;
	LOGFONT sCaptionFont;
	HWND    hLastForegroundWindow;

	int nHorizontalShift;
	int nVerticalShift;
	unsigned int nLastCaptionXPos;
	unsigned int nLastCaptionLen;

	CStdString* pSearchCaption;

	CStdString strTimeText;
	CStdString strTitleText;

	bool bShowPlayStatus;
	bool bBlinking;
	bool bRedrawOldCaption;

	void drawCaption(HWND hForegroundWnd, unsigned int nStyle);
	void updateCaption(HWND hWnd);
};

#endif
