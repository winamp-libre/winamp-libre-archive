/*

  Nullsoft WASABI Source File License

  Copyright 1999-2001 Nullsoft, Inc.

    This software is provided 'as-is', without any express or implied
    warranty.  In no event will the authors be held liable for any damages
    arising from the use of this software.

    Permission is granted to anyone to use this software for any purpose,
    including commercial applications, and to alter it and redistribute it
    freely, subject to the following restrictions:

    1. The origin of this software must not be misrepresented; you must not
       claim that you wrote the original software. If you use this software
       in a product, an acknowledgment in the product documentation would be
       appreciated but is not required.
    2. Altered source versions must be plainly marked as such, and must not be
       misrepresented as being the original software.
    3. This notice may not be removed or altered from any source distribution.


  Brennan Underwood
  brennan@nullsoft.com

*/

#ifndef _GEN_TBAR_3_H
#define _GEN_TBAR_3_H

// Always start with std.h
#include "studio/bfc/std.h"

#include "resource.h"
#include "gen_tbar.h"
#include "gen_tbar_3_wnd.h"

#include "studio/studio/wac.h"
#include "studio/studio/services/creators.h"
#include "studio/bfc/wndcreator.h"
#include "studio/common/xlatstr.h"

class GenericWnd;

#define WACNAME WACGeneric
#define WACPARENT WAComponentClient

class WACNAME : public WACPARENT
{
public:
	WACNAME();
	virtual ~WACNAME();

	virtual GUID getGUID();

	virtual void onCreate();
	virtual void onDestroy();
	virtual void onSkinLoaded();
	virtual int  onCommand(const char *cmd, int param1, int param2, void *ptr, int ptrlen);

private:
	gen_tbar* p_gen_tbar;
};

extern WACPARENT *the;

#endif // _GEN_TBAR_3_H
