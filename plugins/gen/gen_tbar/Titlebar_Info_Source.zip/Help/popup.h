#ifndef IDH_OK
#define IDH_OK                          28443
#endif

#ifndef IDH_CANCEL
#define IDH_CANCEL                      28444
#endif

#define IDH_SHOW_REMAINING_TIME         1000
#define IDH_CHOOSE_FONT                 1001
#define IDH_SHOW_PLAYSTATUS             1002
#define IDH_GET_HELP                    1003
#define IDH_HSPIN                       1004
#define IDH_HEDIT                       1005
#define IDH_VEDIT                       1006
#define IDH_VSPIN                       1007
#define IDH_SEARCH_CAPTION              1008
#define IDH_REDRAW_OLD_CAPTION          1009
#define IDH_ABOUT                       1010
#define IDH_PLUGIN_ENABLED              1011
