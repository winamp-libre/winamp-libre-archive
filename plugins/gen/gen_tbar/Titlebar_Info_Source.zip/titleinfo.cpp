#include "titleinfo.h"

TitleInfo::TitleInfo()
{
	strTimeText.Empty();
	strTitleText.Empty();

	bBlinking         = true;
	bShowPlayStatus   = false;
	bRedrawOldCaption = false;

	pSearchCaption = new CStdString[10];

	for (int i=0; i < 10; i++)
		pSearchCaption[i].Empty();
}

TitleInfo::~TitleInfo()
{
	delete[] pSearchCaption;
	pSearchCaption = NULL;
}

void TitleInfo::updateCaption(HWND hWnd)
{
	CStdString strWindowText;
	GetWindowText(hWnd, strWindowText.GetBuffer(512), 512);
	strWindowText.ReleaseBuffer();

	if (!isStringInCaption(strWindowText))
	{
		// Prevents the "XP display bug", but behaves strange with Netscape 7.0 (don't ask me why...):
		SetWindowPos(hWnd, NULL, NULL, NULL, NULL, NULL, SWP_FRAMECHANGED | SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOSIZE | SWP_NOZORDER);
	}
}

void TitleInfo::drawOnCaption()
{
	HWND hForegroundWnd = GetForegroundWindow();
	CStdString strName;
	unsigned int nStyle;
	unsigned int nExStyle;

	if (!hForegroundWnd || strTitleText.IsEmpty())
		return;

	// Find out the actual parent of this foreground window 
	// in case it is a popup window with a caption
	if (GetParent(hForegroundWnd))
	{
		HWND hWnd;

		hWnd = GetParent(hForegroundWnd);
		while(hWnd)
		{
			hForegroundWnd = hWnd;
			hWnd = GetParent(hForegroundWnd);
		}
	}

	// Removed Netscape 7.0 bug by setting "bRedrawOldCaption" to false.
	if (bRedrawOldCaption && (hLastForegroundWindow != hForegroundWnd) && hLastForegroundWindow && IsWindow(hLastForegroundWindow))
		updateCaption(hLastForegroundWindow); // If we have changed the foreground window, repaint the last foreground window caption

	hLastForegroundWindow = hForegroundWnd;

	// Check if we are supposed to draw this info
	// the window must have a titlebar and must not be a toolwindow
	// it must not be setup.exe or winver.exe (#32770) and not 
	// the Windows Taskbar (Shell_TrayWnd)
	// it also mustn't be a Winamp window (Winamp v1.x).
	GetClassName(hForegroundWnd, strName.GetBuffer(80), 80);
	strName.ReleaseBuffer();

	nStyle = GetWindowLong(hForegroundWnd, GWL_STYLE);
	nExStyle = GetWindowLong(hForegroundWnd, GWL_EXSTYLE);

	if ((nStyle & WS_CAPTION) == WS_CAPTION && !(nExStyle & WS_EX_TOOLWINDOW) && (strName != "#32770") &&
		(strName != "Shell_TrayWnd") && (strName != "Winamp v1.x") && (strName != "Winamp EQ") &&
		(strName != "Winamp PE") && (strName =! "Winamp MB"))
	{
		drawCaption(hForegroundWnd, nStyle);
	}
}

void TitleInfo::drawCaption(HWND hForegroundWnd, unsigned int nStyle)
{
	CStdString strWindowText;
	GetWindowText(hForegroundWnd, strWindowText.GetBuffer(512), 512);
	strWindowText.ReleaseBuffer();

	if (!isStringInCaption(strWindowText))
	{
		CStdString strTrackNumber;

		int nLeft;
		int nLeftSpace = 0;
		int nRightSpace = 0;
		int nDrawCaptionPos = 0;

		RECT sDrawRectTitle;
		RECT sDrawRectTime;
		RECT sRect;

		SIZE sTempSize;
		SIZE sTimeSize;
		SIZE sTitleSize;
		SIZE sTrackNumberSize;

		NONCLIENTMETRICS sMetrics;
		HFONT hDrawFont;

		sMetrics.cbSize = sizeof(sMetrics);
		SystemParametersInfo(SPI_GETNONCLIENTMETRICS, 0, &sMetrics, FALSE);

		// First we need to calculate the actual length of the active window text
		HDC hDC   = GetWindowDC(hForegroundWnd);
		hDrawFont = CreateFontIndirect(&sMetrics.lfCaptionFont);
		hDrawFont = (HFONT)SelectObject(hDC, hDrawFont);
		GetTextExtentPoint(hDC, strWindowText, strWindowText.GetLength(), &sTempSize);
		hDrawFont = (HFONT)SelectObject(hDC, hDrawFont);
		DeleteObject(hDrawFont);

		// Now use the user defined font
		hDrawFont = CreateFontIndirect(&sCaptionFont);
		hDrawFont = (HFONT)SelectObject(hDC, hDrawFont);
		GetWindowRect(hForegroundWnd, &sRect);
		GetTextExtentPoint(hDC, strTitleText, strTitleText.GetLength(), &sTitleSize);

		// Retrieve the size of the track number
		strTrackNumber = strTitleText.Left(strTitleText.Find('.') + 1);
		GetTextExtentPoint(hDC, strTrackNumber, strTrackNumber.GetLength(), &sTrackNumberSize);

		// Retrieve the size of the time display
		GetTextExtentPoint(hDC, strTimeText, strTimeText.GetLength(), &sTimeSize);
		nRightSpace = 10 + sTimeSize.cx;

		// Close button
		if ((nStyle & WS_SYSMENU) == WS_SYSMENU)
		{
			nRightSpace += GetSystemMetrics(SM_CXSIZE);
			nLeftSpace  += GetSystemMetrics(SM_CXSIZE);
		}
		
		if ((nStyle & WS_MINIMIZEBOX) == WS_MINIMIZEBOX || (nStyle & WS_MAXIMIZEBOX) == WS_MAXIMIZEBOX)
		{
			nRightSpace += 2*GetSystemMetrics(SM_CXSIZE);
		}
		
		if ((nStyle & WS_BORDER) == WS_BORDER && !((nStyle & WS_MAXIMIZE) == WS_MAXIMIZE))
		{
			nRightSpace += GetSystemMetrics(SM_CXBORDER);
			nLeftSpace  += GetSystemMetrics(SM_CXBORDER);
			nDrawCaptionPos += GetSystemMetrics(SM_CXBORDER);
		}
		
		if ((nStyle & WS_THICKFRAME) == WS_THICKFRAME && !((nStyle & WS_MAXIMIZE) == WS_MAXIMIZE))
		{
			nRightSpace += GetSystemMetrics(SM_CXFRAME);
			nLeftSpace  += GetSystemMetrics(SM_CXFRAME);
			nDrawCaptionPos += GetSystemMetrics(SM_CXFRAME);
		}
		
		if ((nStyle & WS_DLGFRAME) == WS_DLGFRAME && !((nStyle & WS_MAXIMIZE) == WS_MAXIMIZE))
		{
			nRightSpace += GetSystemMetrics(SM_CXDLGFRAME);
			nLeftSpace  += GetSystemMetrics(SM_CXDLGFRAME);
			nDrawCaptionPos += GetSystemMetrics(SM_CXDLGFRAME);
		}
		
		nLeft = sRect.right - sRect.left - nRightSpace - sTitleSize.cx + nHorizontalShift;
		nLeftSpace -= nHorizontalShift;

		SetBkMode(hDC, TRANSPARENT);
		SetTextColor(hDC, nCaptionFontColor);
		sDrawRectTitle.top = GetSystemMetrics(SM_CYFRAME) + (GetSystemMetrics(SM_CYCAPTION) - sTitleSize.cy) / 2 - 1;
		sDrawRectTitle.bottom = sDrawRectTitle.top + sTitleSize.cy;

		updateCaption(hForegroundWnd);
		nLastCaptionLen = sTitleSize.cx;

		// Designates space between window title and winamp data written on caption
		int spacer = 25;

		if (nLeft > (sTempSize.cx + nLeftSpace + spacer))
		{
			sDrawRectTitle.left  = nLeft;
			sDrawRectTitle.right = sDrawRectTitle.left + sTitleSize.cx;
		}
		else
		{
			sDrawRectTitle.left  = sTempSize.cx + spacer + nLeftSpace;
			sDrawRectTitle.right = nLeft + sTitleSize.cx;
		}
		nLastCaptionXPos = sDrawRectTitle.left;

		sDrawRectTitle.left   += nHorizontalShift;
		sDrawRectTitle.right  += nHorizontalShift;
		sDrawRectTitle.top    += nVerticalShift;
		sDrawRectTitle.bottom += nVerticalShift;

		if(sDrawRectTitle.right > (sDrawRectTitle.left + sTrackNumberSize.cx))
		{
			sDrawRectTime.left   = sDrawRectTitle.right;
			sDrawRectTime.right  = sDrawRectTitle.right + sTimeSize.cx;
			sDrawRectTime.top    = sDrawRectTitle.top;
			sDrawRectTime.bottom = sDrawRectTitle.bottom;

			DrawText(hDC, strTitleText, strTitleText.GetLength(), &sDrawRectTitle, DT_LEFT | DT_VCENTER | DT_NOPREFIX);

			if (bShowPlayStatus && bBlinking)
				bBlinking = false;
			else
			{
				if ((strTimeText == " - [Pause]") || (strTimeText == " - [Stop]"))
					bBlinking = true;

				DrawText(hDC, strTimeText, strTimeText.GetLength(), &sDrawRectTime, DT_LEFT | DT_VCENTER | DT_NOPREFIX);
			}
		}

		hDrawFont = (HFONT)SelectObject(hDC, hDrawFont);
		DeleteObject(hDrawFont);
		ReleaseDC(hForegroundWnd, hDC);
	}
}

void TitleInfo::setText(CStdString newTitleText, CStdString newTimeText)
{
	strTitleText = newTitleText;
	strTimeText  = newTimeText;
}

void TitleInfo::setSearchCaption(CStdString newSearchCaption)
{
	CStdString strSearchCaption;
	strSearchCaption = newSearchCaption;

	char* token = strtok(strSearchCaption.GetBuffer(512), ";");
	strSearchCaption.ReleaseBuffer();

	for (int i=0; i < 10; i++)
	{
		if (token != NULL)
			pSearchCaption[i] = token;
		else
			pSearchCaption[i].Empty();

		token = strtok(NULL, ";");
	}
}

bool TitleInfo::isStringInCaption(CStdString WindowText)
{
	for (int i=0; i < 10; i++)
	{
		if (!pSearchCaption[i].IsEmpty())					// pSearchCaption[i] is not empty
			if (WindowText.Find(pSearchCaption[i]) != -1)	// pSearchCaption[i] appears in pWindowText
				return true;								// the search is over
	}

	return false;											// nothing found
}
