#ifndef GEN_TBAR_H
#define GEN_TBAR_H

#if defined __GEN_TBAR_FOR_WINAMP_2__
#include "frontend.h"
#elif defined __GEN_TBAR_FOR_WINAMP_3__
#include "studio/common/corehandle.h"
#include "studio/pledit/svc_pldir.h"
#include "studio/pledit/playlist.h"
#include "studio/bfc/wndcreator.h"
#else
#error Select plugin version with __GEN_TBAR_FOR_WINAMP_2__ or __GEN_TBAR_FOR_WINAMP_3__
#endif

#include "titleinfo.h"
#include "Help\popup.h"
#include <htmlhelp.h>
#include <Shlwapi.h>

#define SEARCH_CAPTION_TEXT  64
#define TEXTLENGTH          512

class gen_tbar
{
public:
	gen_tbar(HINSTANCE h_dll_instance, HWND hwnd_parent, CStdString help_file, CStdString plugin_version);
	~gen_tbar();

	void config();
	void draw_titlebar();
	bool enabled() { return plugin_enabled; }

	bool gen_tbar::config_proc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

protected:
	bool get_song_data();

	bool get_registry_string(HKEY root_key, char* sub_key, char* key_name, char** data);
	bool set_registry_string(HKEY root_key, char* sub_key, char* key_name, char* data);

	HANDLE hThread;
	DWORD dwThreadId;

	HINSTANCE hDllInstance;	// plugin data
	HWND hWndParent;		// plugin data

	TitleInfo* pInfo;

	LOGFONT lfont;
	LOGFONT lfont_old;

	int verticalshift;
	int verticalshift_old;
	int horizontalshift;
	int horizontalshift_old;

	DWORD color;
	DWORD color_old;

	char* data;

	CStdString strHelpFile;
	CStdString strSearchCaption;
	CStdString strVersion;

    CStdString strTime;
    CStdString strTitle;

	bool plugin_enabled;
	bool plugin_enabled_old;
	bool redraw_old_caption;
	bool redraw_old_caption_old;
	bool show_remaining_time;
	bool show_remaining_time_old;
	bool show_playstatus;
	bool show_playstatus_old;
};

BOOL CALLBACK ConfigProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

static DWORD id_array[] =
{
	IDOK,                    IDH_OK,
	IDCANCEL,                IDH_CANCEL,
	IDC_SHOW_REMAINING_TIME, IDH_SHOW_REMAINING_TIME,
	IDC_CHOOSE_FONT,         IDH_CHOOSE_FONT,
	IDC_SHOW_PLAYSTATUS,     IDH_SHOW_PLAYSTATUS,
	IDC_GET_HELP,            IDH_GET_HELP,
	IDC_ABOUT,               IDH_ABOUT,
	IDC_HSPIN,               IDH_HSPIN,
	IDC_HEDIT,               IDH_HEDIT,
	IDC_VEDIT,               IDH_VEDIT,
	IDC_VSPIN,               IDH_VSPIN,
	IDC_SEARCH_CAPTION,      IDH_SEARCH_CAPTION,
	IDC_REDRAW_OLD_CAPTION,  IDH_REDRAW_OLD_CAPTION,
	IDC_PLUGIN_ENABLED,      IDH_PLUGIN_ENABLED,
	0, 0
};

#endif // GEN_TBAR_H
