#ifndef GEN_TBAR_2_H
#define GEN_TBAR_2_H

#include "gen_tbar.h"

#define GPPHDR_VER 0x10

typedef struct
{
	int version;
	char *description;
	int (*init)();
	void (*config)();
	void (*quit)();
	HWND hwndParent;
	HINSTANCE hDllInstance;
} winampGeneralPurposePlugin;

int init();
void quit();
void config();

#endif // GEN_TBAR_2_H
