/*

  Nullsoft WASABI Source File License

  Copyright 1999-2001 Nullsoft, Inc.

    This software is provided 'as-is', without any express or implied
    warranty.  In no event will the authors be held liable for any damages
    arising from the use of this software.

    Permission is granted to anyone to use this software for any purpose,
    including commercial applications, and to alter it and redistribute it
    freely, subject to the following restrictions:

    1. The origin of this software must not be misrepresented; you must not
       claim that you wrote the original software. If you use this software
       in a product, an acknowledgment in the product documentation would be
       appreciated but is not required.
    2. Altered source versions must be plainly marked as such, and must not be
       misrepresented as being the original software.
    3. This notice may not be removed or altered from any source distribution.


  Brennan Underwood
  brennan@nullsoft.com

*/

#include "gen_tbar_3.h"

static WACNAME wac;
WACPARENT *the = &wac;                     

// {909DAF1B-277C-11d7-8910-DA64B0455640}
static const GUID guid = 
{ 0x909daf1b, 0x277c, 0x11d7, { 0x89, 0x10, 0xda, 0x64, 0xb0, 0x45, 0x56, 0x40 } };

WACNAME::WACNAME() : WACPARENT("gen_tbar_3")
{
	registerService(new WndCreateCreatorSingle< CreateBucketItem<gen_tbar_3_wnd, gen_tbar_3_bucket_item> >);
}

WACNAME::~WACNAME()
{
}

GUID WACNAME::getGUID()
{
	return guid;
}

void WACNAME::onCreate()
{
}

void WACNAME::onSkinLoaded()
{
	HINSTANCE hInstance = gethInstance();
	HWND hWndParent     = (api->main_getRootWnd())->gethWnd();

	// Get version information from DLL
	CStdString helpfile;
	CStdString version;

	GetModuleFileName(hInstance, helpfile.GetBuffer(MAX_PATH), MAX_PATH);
	helpfile.ReleaseBuffer();

	version = helpfile;
	PathRemoveFileSpec(helpfile.GetBuffer(MAX_PATH));
	helpfile.ReleaseBuffer();
	helpfile += "\\gen_tbar.chm";

	DWORD dwArg;
	DWORD dwInfoSize = GetFileVersionInfoSize(version.GetBuffer(MAX_PATH), &dwArg);
	version.ReleaseBuffer();

	BYTE* lpBuffer = new BYTE[dwInfoSize];
	GetFileVersionInfo(version.GetBuffer(MAX_PATH), NULL, dwInfoSize, lpBuffer);
	version.ReleaseBuffer();

	UINT uInfoSize;
	LPVOID lpValue;
	
	if (VerQueryValue(lpBuffer, TEXT("\\StringFileInfo\\040904b0\\FileVersion"), &lpValue, &uInfoSize))
		version.Format("Titlebar Info %s", lpValue);
	else
		version = "Titlebar Info x.xx";

	delete[] lpBuffer;
	lpBuffer = NULL;

	p_gen_tbar = new gen_tbar(hInstance, hWndParent, helpfile, version);
}

void WACNAME::onDestroy()
{
	delete p_gen_tbar;
	p_gen_tbar = NULL;
}

int WACNAME::onCommand(const char *cmd, int param1, int param2, void *ptr, int ptrlen)
{
	if (!strcmp(cmd, "config"))
		p_gen_tbar->config();

	return 0;
}
