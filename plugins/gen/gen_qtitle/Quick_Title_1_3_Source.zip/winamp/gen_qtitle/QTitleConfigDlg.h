#if !defined(AFX_QTITLECONFIGDLG_H__6598DDE4_3A9A_11D6_86F1_00E02910A56E__INCLUDED_)
#define AFX_QTITLECONFIGDLG_H__6598DDE4_3A9A_11D6_86F1_00E02910A56E__INCLUDED_

#include <controls/ColorPicker.h>	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// QTitleConfigDlg.h : header file
//
#include <controls/ColorPicker.h>

/////////////////////////////////////////////////////////////////////////////
// CQTitleConfigDlg dialog

class CQTitleConfigDlg : public CDialog
{
// Construction
public:
	BOOL		GetShowTransitions();
	void		SetShowTransitions(BOOL bTransitions);

	int			GetWindowPosition();
	void		SetWindowPosition(int iPosition);

	BOOL		IsTransparent();
	void		SetTransparent(BOOL bTransparent);

	COLORREF	GetBGColor();
	void		SetBGColor(COLORREF rColor);

	COLORREF	GetFGColor();
	void		SetFGColor(COLORREF rColor);

	LPCTSTR		GetFontName();
	void		SetFontName(LPCTSTR szFontName);

	void		SetFontSize(int iFontSize);
	int			GetFontSize();

	int			GetTimeout();
	void		SetTimeout(int iTimeout);

	BOOL		IsEnabled();
	void		SetEnabled(BOOL bEnable);

	void		SetHotKey(UINT uiModifiers, UINT uiVirtualKey);
	void		GetHotKey(UINT& uiModifiers, UINT& uiVirtualKey);

	int			GetWordWrap();
	void		SetWordWrap(int iWordWrap);


	CQTitleConfigDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CQTitleConfigDlg)
	enum { IDD = IDD_DIALOG1 };
	CComboBox	m_comboHotKey;
	CComboBox	m_comboFontName;
	int		m_iTimeout;
	BOOL	m_bEnabled;
	int		m_iFontSize;
	BOOL	m_bTransparent;
	BOOL	m_bAlt;
	BOOL	m_bCtrl;
	BOOL	m_bWin;
	BOOL	m_bShift;
	int		m_iPosition;
	BOOL	m_bTransitions;
	int		m_iWordWrap;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQTitleConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CQTitleConfigDlg)
	virtual void OnOK();
	afx_msg void OnKillFocusEditFontSize();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CColorPicker	m_buttonForeground;
	CColorPicker	m_buttonBackground;
	CString			m_sFontName;
	CString			m_sHotKey;
	COLORREF		m_rFGColor;
	COLORREF		m_rBGColor;
	UINT			m_uiHotKeyMods;
	UINT			m_uiVirtualKey;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QTITLECONFIGDLG_H__6598DDE4_3A9A_11D6_86F1_00E02910A56E__INCLUDED_)
