// gen_qtitle.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "gen_qtitle.h"
#include "QTitleConfigDlg.h"

#include <winamp/gen.h>
#include <winamp/winamp.h>
#include <winamp/frontend.h>

#include "QTitleWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const TCHAR g_kszTimeout[]			= _T("Timeout");
const TCHAR g_kszEnabled[]			= _T("Enabled");
const TCHAR g_kszWindowPosition[]	= _T("WindowPosition");
const TCHAR g_kszTransitions[]		= _T("Transitions");
									
const TCHAR g_kszFontName[]			= _T("FontName");
const TCHAR g_kszFontSize[]			= _T("FontSize");
									
const TCHAR g_kszFGColor[]			= _T("FGColor");
const TCHAR g_kszBGColor[]			= _T("BGColor");
const TCHAR g_kszTransparent[]		= _T("Transparent");
									
const TCHAR g_kszHotKey[]			= _T("HotKey");
const TCHAR g_kszHotKeyMods[]		= _T("HotKeyMods");

const TCHAR g_kszWordWrap[]			= _T("WordWrap");

CGen_qtitleApp	theApp;
WNDPROC			lpfnOldWndProc = NULL;

// Global plug-in information
winampGeneralPurposePlugin plugin = {GPPHDR_VER, // version of gen.h header
									 "",
									 CGen_qtitleApp::Init,
									 CGen_qtitleApp::Config,
									 CGen_qtitleApp::Quit,};


BEGIN_MESSAGE_MAP(CGen_qtitleApp, CWinApp)
	//{{AFX_MSG_MAP(CGen_qtitleApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGen_qtitleApp construction

//-------------------------------------------------------------------------
// CGen_qtitleApp
//-------------------------------------------------------------------------
CGen_qtitleApp::CGen_qtitleApp() :
	m_pwndQTitle(NULL)
{
}

//-------------------------------------------------------------------------
// ~CGen_qtitleApp
//-------------------------------------------------------------------------
CGen_qtitleApp::~CGen_qtitleApp()
{
}


//-------------------------------------------------------------------------
// WndProc
//
// Allows this plug-in to intercept Winamp message
//-------------------------------------------------------------------------
LRESULT CALLBACK 
WndProc(HWND hwnd, UINT uiMessage, WPARAM wParam, LPARAM lParam)
{
	switch(uiMessage)
	{
		case WM_SETTEXT:
			theApp.UpdateQTitleWnd(hwnd, FALSE);
			break;
		case WM_KEYUP:
			switch(wParam)
			{
				case _T('Z'):
				case _T('X'):
				case _T('C'):
				case _T('B'):
				{
					theApp.UpdateQTitleWnd(hwnd, TRUE);
					break;
				}
			}
			break;
		case WM_COMMAND:
		{
			switch(wParam)
			{
				case WINAMP_BUTTON1:
				case WINAMP_BUTTON2:
				case WINAMP_BUTTON3:
				case WINAMP_BUTTON5:
				{
					theApp.UpdateQTitleWnd(hwnd, TRUE);
					break;
				}
			}
			break;
		}
	}

	// Forward the message onto Winamp
	return CallWindowProc(lpfnOldWndProc, hwnd, uiMessage, wParam, lParam);
}

//-------------------------------------------------------------------------
// winampGetGeneralPurposePlugin
//
// Returns the pointer to the entry point functions to WinAmp
//-------------------------------------------------------------------------
winampGeneralPurposePlugin*
winampGetGeneralPurposePlugin()
{
	return &plugin;
}

//-------------------------------------------------------------------------
// Init
//-------------------------------------------------------------------------
int 
CGen_qtitleApp::Init()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return(theApp.Initialize());
}

//-------------------------------------------------------------------------
// Quit
//-------------------------------------------------------------------------
void
CGen_qtitleApp::Quit()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	theApp.CleanUp();
}

//-------------------------------------------------------------------------
// Config
//-------------------------------------------------------------------------
void
CGen_qtitleApp::Config()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	theApp.Configuration();
}


//-------------------------------------------------------------------------
// Initialize
//-------------------------------------------------------------------------
int 
CGen_qtitleApp::Initialize()
{
	static char szDescription[512];
	char		szFileName[512];


	GetModuleFileName(plugin.hDllInstance, szFileName, sizeof(szFileName));

	wsprintf(szDescription,
			 "Winamp Quick Title v1.2 (%s)",
			 strrchr(szFileName, '\\') + 1);

	plugin.description = szDescription;

	lpfnOldWndProc = (WNDPROC)GetWindowLong(plugin.hwndParent, GWL_WNDPROC);

	SetWindowLong(plugin.hwndParent, GWL_WNDPROC, reinterpret_cast<DWORD>(WndProc));

	SetRegistryKey(_T("Winamp"));

	m_pwndQTitle = new CQTitleWnd;

	if(m_pwndQTitle)
	{
		if(m_pwndQTitle->Create(plugin.hwndParent))
		{
			UINT uiHotKeyMods = 0;
			UINT uiVirtualKey = 0;

			m_pwndQTitle->SetTimeout(GetProfileInt(_T(""), g_kszTimeout, m_pwndQTitle->GetTimeout()));
			m_pwndQTitle->SetEnabled(GetProfileInt(_T(""), g_kszEnabled, m_pwndQTitle->IsEnabled()));
			m_pwndQTitle->SetShowTransitions(GetProfileInt(_T(""), g_kszTransitions, m_pwndQTitle->GetShowTransitions()));
			m_pwndQTitle->SetWindowPosition(GetProfileInt(_T(""), g_kszWindowPosition, m_pwndQTitle->GetWindowPosition()));

			m_pwndQTitle->SetFontName(GetProfileString(_T(""), g_kszFontName, m_pwndQTitle->GetFontName()));
			m_pwndQTitle->SetFontSize(GetProfileInt(_T(""), g_kszFontSize, m_pwndQTitle->GetFontSize()));

			m_pwndQTitle->SetFGColor(GetProfileInt(_T(""), g_kszFGColor, m_pwndQTitle->GetFGColor()));
			m_pwndQTitle->SetBGColor(GetProfileInt(_T(""), g_kszBGColor, m_pwndQTitle->GetBGColor()));

			m_pwndQTitle->SetTransparent(GetProfileInt(_T(""), g_kszTransparent, m_pwndQTitle->IsTransparent()));

			m_pwndQTitle->GetHotKey(uiHotKeyMods, uiVirtualKey);
			uiVirtualKey = GetProfileInt(_T(""), g_kszHotKey, uiVirtualKey);
			uiHotKeyMods = GetProfileInt(_T(""), g_kszHotKeyMods, uiHotKeyMods);
			m_pwndQTitle->SetHotKey(uiHotKeyMods, uiVirtualKey);

			m_pwndQTitle->SetWordWrap(GetProfileInt(_T(""), g_kszWordWrap, m_pwndQTitle->GetWordWrap()));
		}
	}

	return(0);
}

//-------------------------------------------------------------------------
// Configuration
//-------------------------------------------------------------------------
void 
CGen_qtitleApp::Configuration()
{
	if(m_pwndQTitle)
	{
		UINT uiHotKeyMods = 0;
		UINT uiVirtualKey = 0;

		CQTitleConfigDlg oDlg;

		oDlg.SetTimeout(m_pwndQTitle->GetTimeout());
		oDlg.SetEnabled(m_pwndQTitle->IsEnabled());
		oDlg.SetTransparent(m_pwndQTitle->IsTransparent());
		oDlg.SetWindowPosition(m_pwndQTitle->GetWindowPosition());
		oDlg.SetShowTransitions(m_pwndQTitle->GetShowTransitions());

		oDlg.SetFontSize(m_pwndQTitle->GetFontSize());
		oDlg.SetFontName(m_pwndQTitle->GetFontName());

		oDlg.SetBGColor(m_pwndQTitle->GetBGColor());
		oDlg.SetFGColor(m_pwndQTitle->GetFGColor());

		m_pwndQTitle->GetHotKey(uiHotKeyMods, uiVirtualKey);
		oDlg.SetHotKey(uiHotKeyMods, uiVirtualKey);

		oDlg.SetWordWrap(m_pwndQTitle->GetWordWrap());

		if(IDOK == oDlg.DoModal())
		{
			m_pwndQTitle->SetTimeout(oDlg.GetTimeout());
			m_pwndQTitle->SetEnabled(oDlg.IsEnabled());
			m_pwndQTitle->SetTransparent(oDlg.IsTransparent());
			m_pwndQTitle->SetWindowPosition(oDlg.GetWindowPosition());
			m_pwndQTitle->SetShowTransitions(oDlg.GetShowTransitions());

			m_pwndQTitle->SetFontSize(oDlg.GetFontSize());
			m_pwndQTitle->SetFontName(oDlg.GetFontName());

			m_pwndQTitle->SetFGColor(oDlg.GetFGColor());
			m_pwndQTitle->SetBGColor(oDlg.GetBGColor());

			oDlg.GetHotKey(uiHotKeyMods, uiVirtualKey);
			m_pwndQTitle->SetHotKey(uiHotKeyMods, uiVirtualKey);

			m_pwndQTitle->SetWordWrap(oDlg.GetWordWrap());
		}
	}
}

//-------------------------------------------------------------------------
// CleanUp
//-------------------------------------------------------------------------
void 
CGen_qtitleApp::CleanUp()
{
	if(m_pwndQTitle)
	{
		UINT uiHotKeyMods = 0;
		UINT uiVirtualKey = 0;

		WriteProfileInt(_T(""), g_kszTimeout, m_pwndQTitle->GetTimeout());
		WriteProfileInt(_T(""), g_kszEnabled, m_pwndQTitle->IsEnabled());
		WriteProfileInt(_T(""), g_kszWindowPosition, m_pwndQTitle->GetWindowPosition());
		WriteProfileInt(_T(""), g_kszTransitions, m_pwndQTitle->GetShowTransitions());
		WriteProfileInt(_T(""), g_kszTransparent, m_pwndQTitle->IsTransparent());
		
		WriteProfileInt(_T(""), g_kszFontSize, m_pwndQTitle->GetFontSize());
		WriteProfileString(_T(""), g_kszFontName, m_pwndQTitle->GetFontName());

		WriteProfileInt(_T(""), g_kszFGColor, m_pwndQTitle->GetFGColor());
		WriteProfileInt(_T(""), g_kszBGColor, m_pwndQTitle->GetBGColor());

		m_pwndQTitle->GetHotKey(uiHotKeyMods, uiVirtualKey);
		WriteProfileInt(_T(""), g_kszHotKey, uiVirtualKey);
		WriteProfileInt(_T(""), g_kszHotKeyMods, uiHotKeyMods);

		WriteProfileInt(_T(""), g_kszWordWrap, m_pwndQTitle->GetWordWrap());

		if(m_pwndQTitle->m_hWnd)
		{
			m_pwndQTitle->DestroyWindow();
		}

	}
}

//-------------------------------------------------------------------------
// UpdateQTitleWnd
//-------------------------------------------------------------------------
void 
CGen_qtitleApp::UpdateQTitleWnd(HWND hwnd, BOOL bForceDisplay)
{
	if(m_pwndQTitle && m_pwndQTitle->GetShowTransitions())
	{
		PostMessage(m_pwndQTitle->m_hWnd, WMU_UPDATE_TEXT, (BOOL)bForceDisplay, 0);
	}
}
