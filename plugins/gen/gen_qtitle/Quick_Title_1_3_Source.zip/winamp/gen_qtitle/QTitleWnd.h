#if !defined(AFX_QTITLEWND_H__77CCA24F_3378_11D6_86F1_00E02910A56E__INCLUDED_)
#define AFX_QTITLEWND_H__77CCA24F_3378_11D6_86F1_00E02910A56E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// QTitleWnd.h : header file
//
#define WMU_UPDATE_TEXT		WM_USER + 0

/////////////////////////////////////////////////////////////////////////////
// CQTitleWnd window
class CQTitleWnd : public CFrameWnd
{
// Construction
public:
	CQTitleWnd();

	BOOL Create(HWND hwndWinamp);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQTitleWnd)
	public:
	virtual BOOL DestroyWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL		GetShowTransitions();
	void		SetShowTransitions(BOOL bTransitions);

	int			GetWindowPosition();
	void		SetWindowPosition(int iPosition);

	void		SetTransparent(BOOL bTransparent);
	BOOL		IsTransparent();

	void		SetBGColor(COLORREF rColor);
	COLORREF	GetBGColor();

	void		SetFGColor(COLORREF rColor);
	COLORREF	GetFGColor();

	void		SetFontName(LPCTSTR szFontName);
	LPCTSTR		GetFontName();
	
	int			GetFontSize();
	void		SetFontSize(int iFontSize);
	
	void		SetEnabled(BOOL bEnable);
	BOOL		IsEnabled();

	void		SetTimeout(int iTimeout);
	int			GetTimeout();

	void		SetHotKey(UINT uiModifiers, UINT uiVirtualKey);
	void		GetHotKey(UINT& uiModifiers, UINT& uiVirtualKey);

	int			GetWordWrap();
	void		SetWordWrap(int iWordWrap);

	virtual		~CQTitleWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CQTitleWnd)
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	afx_msg LRESULT OnUpdateDisplay(WPARAM, LPARAM);
	afx_msg LRESULT OnHotKey(WPARAM, LPARAM);

private:
	void		ResetFont();

	CString		m_sText;
	HWND		m_hwndWinamp;
	BOOL		m_bEnabled;
	BOOL		m_bTransparent;
	int			m_iTimeout;
	CFont		m_oFont;
	int			m_iFontSize;
	CString		m_sFontName;
	COLORREF	m_rFGColor;
	COLORREF	m_rBGColor;
	UINT		m_uiHotKeyMods;
	UINT		m_uiVirtualKey;
	int			m_iCountdown;
	int			m_iPosition;
	BOOL		m_bTransitions;
	int			m_iWordWrap;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QTITLEWND_H__77CCA24F_3378_11D6_86F1_00E02910A56E__INCLUDED_)
