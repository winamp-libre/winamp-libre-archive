// QTitleConfigDlg.cpp : implementation file
//

#include "stdafx.h"
#include "gen_qtitle.h"
#include "QTitleConfigDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define HOTKEY 100

HWND g_hWndFontCombo = NULL;

/////////////////////////////////////////////////////////////////////////////
// CQTitleConfigDlg dialog
int CALLBACK 
EnumFontFamiliesExProc(ENUMLOGFONTEX*	lpelfe, 
					   NEWTEXTMETRICEX*	lpntme, 
					   int				iFontType, 
					   LPARAM			lParam)

{
	::SendMessage(g_hWndFontCombo, CB_ADDSTRING, 0, (LPARAM)lpelfe->elfLogFont.lfFaceName);

	return 1;
}


CQTitleConfigDlg::CQTitleConfigDlg(CWnd* pParent /*=NULL*/) :
	CDialog(CQTitleConfigDlg::IDD, pParent),
	m_bCtrl(FALSE),
	m_bAlt(FALSE),
	m_bShift(FALSE),
	m_bWin(FALSE),
	m_uiHotKeyMods(MOD_ALT),
	m_uiVirtualKey(_T('Q')),
	m_sFontName(_T("Courier")),
	m_rFGColor(RGB(0,0,0)),
	m_rBGColor(RGB(255,255,255)),
	m_iFontSize(0),
	m_iPosition(0),
	m_iTimeout(0),
	m_iWordWrap(0),
	m_bTransitions(TRUE),
	m_bTransparent(FALSE),
	m_bEnabled(FALSE)
{
	//{{AFX_DATA_INIT(CQTitleConfigDlg)
	//}}AFX_DATA_INIT
}


void CQTitleConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQTitleConfigDlg)
	DDX_Control(pDX, IDC_HOTKEY, m_comboHotKey);
	DDX_Control(pDX, IDC_FONT_NAME, m_comboFontName);
	DDX_Text(pDX, IDC_TIMEOUT, m_iTimeout);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnabled);
	DDX_Text(pDX, IDC_FONT_SIZE, m_iFontSize);
	DDX_Check(pDX, IDC_TRANSPARENT, m_bTransparent);
	DDX_Check(pDX, IDC_ALT, m_bAlt);
	DDX_Check(pDX, IDC_CTRL, m_bCtrl);
	DDX_Check(pDX, IDC_WIN, m_bWin);
	DDX_Check(pDX, IDC_SHIFT, m_bShift);
	DDX_CBIndex(pDX, IDC_POSITION, m_iPosition);
	DDX_Check(pDX, IDC_TRACK_CHANGE, m_bTransitions);
	DDX_Radio(pDX, IDC_WORD_WRAP, m_iWordWrap);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CQTitleConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CQTitleConfigDlg)
	ON_EN_KILLFOCUS(IDC_FONT_SIZE, OnKillFocusEditFontSize)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQTitleConfigDlg message handlers


void 
CQTitleConfigDlg::OnKillFocusEditFontSize() 
{
	UpdateData(TRUE);

	if(m_iFontSize < 6 || m_iFontSize > 60)
	{
		m_iFontSize = 12;
	}
	
	UpdateData(FALSE);
}


void 
CQTitleConfigDlg::SetEnabled(BOOL bEnable)
{
	m_bEnabled = bEnable;
}

BOOL 
CQTitleConfigDlg::IsEnabled()
{
	return(m_bEnabled);
}

void 
CQTitleConfigDlg::SetTimeout(int iTimeout)
{
	m_iTimeout = iTimeout;
}

int 
CQTitleConfigDlg::GetTimeout()
{
	return(m_iTimeout);
}

void 
CQTitleConfigDlg::OnOK() 
{
	UpdateData(TRUE);

	m_comboFontName.GetLBText(m_comboFontName.GetCurSel(), m_sFontName);

	m_rFGColor	= m_buttonForeground.GetColor();
	m_rBGColor		= m_buttonBackground.GetColor();

	m_uiHotKeyMods = 0;
	if(m_bCtrl)  m_uiHotKeyMods |= MOD_CONTROL;
	if(m_bAlt)	 m_uiHotKeyMods |= MOD_ALT;
	if(m_bShift) m_uiHotKeyMods |= MOD_SHIFT;
	if(m_bWin)   m_uiHotKeyMods |= MOD_WIN;

	m_uiVirtualKey = _T('A') + m_comboHotKey.GetCurSel();

	CDialog::OnOK();
}

int CQTitleConfigDlg::GetFontSize()
{
	return(m_iFontSize);
}

void CQTitleConfigDlg::SetFontSize(int iFontSize)
{
	m_iFontSize = iFontSize;
}

BOOL CQTitleConfigDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(m_buttonForeground.SubclassDlgItem(IDC_FONT_COLOR, this))
	{
		m_buttonForeground.SetDefaultText(_T(""));
	}

	if(m_buttonBackground.SubclassDlgItem(IDC_BACKGROUND_COLOR, this))
	{
		m_buttonBackground.SetDefaultText(_T(""));
	}

	g_hWndFontCombo = m_comboFontName.m_hWnd;

	HDC	hDC = ::GetDC(m_hWnd);

	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));

	EnumFontFamiliesEx(hDC, &lf, (FONTENUMPROC)EnumFontFamiliesExProc, 0, 0);

	::ReleaseDC(m_hWnd, hDC);

	m_comboFontName.SelectString(-1, m_sFontName);
	m_buttonForeground.SetColor(m_rFGColor);
	m_buttonBackground.SetColor(m_rBGColor);

	m_bCtrl		= (m_uiHotKeyMods & MOD_CONTROL? TRUE: FALSE);
	m_bAlt		= (m_uiHotKeyMods & MOD_ALT? TRUE: FALSE);
	m_bShift	= (m_uiHotKeyMods & MOD_SHIFT? TRUE: FALSE);
	m_bWin		= (m_uiHotKeyMods & MOD_WIN? TRUE: FALSE);

	CString sHotKey;
	sHotKey.Format(_T("%c"), m_uiVirtualKey);
	m_comboHotKey.SelectString(-1, sHotKey);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void 
CQTitleConfigDlg::SetFontName(LPCTSTR szFontName)
{
	m_sFontName = szFontName;
}

LPCTSTR 
CQTitleConfigDlg::GetFontName()
{

	return(m_sFontName);
}

BOOL 
CQTitleConfigDlg::IsTransparent()
{
	return(m_bTransparent);
}

void 
CQTitleConfigDlg::SetTransparent(BOOL bTransparent)
{
	m_bTransparent = bTransparent;
}

void 
CQTitleConfigDlg::SetBGColor(COLORREF rColor)
{
	m_rBGColor = rColor;
}

COLORREF 
CQTitleConfigDlg::GetBGColor()
{
	return(m_rBGColor);
}

void 
CQTitleConfigDlg::SetFGColor(COLORREF rColor)
{
	m_rFGColor = rColor;
}

COLORREF 
CQTitleConfigDlg::GetFGColor()
{
	return(m_rFGColor);
}


void 
CQTitleConfigDlg::SetHotKey(UINT uiModifiers, UINT uiVirtualKey)
{
	m_uiHotKeyMods	= uiModifiers;
	m_uiVirtualKey	= uiVirtualKey;
}

void 
CQTitleConfigDlg::GetHotKey(UINT& uiModifiers, UINT& uiVirtualKey)
{
	uiModifiers		= m_uiHotKeyMods;
	uiVirtualKey	= m_uiVirtualKey;
}


int 
CQTitleConfigDlg::GetWindowPosition()
{
	return(m_iPosition);
}

void 
CQTitleConfigDlg::SetWindowPosition(int iPosition)
{
	m_iPosition = iPosition;
}

void 
CQTitleConfigDlg::SetShowTransitions(BOOL bTransitions)
{
	m_bTransitions = bTransitions;
}

BOOL 
CQTitleConfigDlg::GetShowTransitions()
{
	return(m_bTransitions);
}

int 
CQTitleConfigDlg::GetWordWrap()
{
	return(m_iWordWrap);
}

void 
CQTitleConfigDlg::SetWordWrap(int iWordWrap)
{
	m_iWordWrap = iWordWrap;
}
