// gen_qtitle.h : main header file for the GEN_QTITLE DLL
//

#if !defined(AFX_GEN_QTITLE_H__77CCA245_3378_11D6_86F1_00E02910A56E__INCLUDED_)
#define AFX_GEN_QTITLE_H__77CCA245_3378_11D6_86F1_00E02910A56E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CGen_qtitleApp
// See gen_qtitle.cpp for the implementation of this class
//
class CQTitleWnd;

class CGen_qtitleApp : public CWinApp
{
public:
	CGen_qtitleApp();
	virtual ~CGen_qtitleApp();

	static void		Quit();
	static void		Config();
	static int		Init();

	void			UpdateQTitleWnd(HWND hwnd, BOOL bForceDisplay);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGen_qtitleApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CGen_qtitleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void			CleanUp();
	void			Configuration();
	int				Initialize();

private:
	CQTitleWnd*		m_pwndQTitle;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GEN_QTITLE_H__77CCA245_3378_11D6_86F1_00E02910A56E__INCLUDED_)
