//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gen_qtitle.rc
//
#define IDC_TIMEOUT                     2001
#define IDD_DIALOG1                     2002
#define IDC_CHECK_ENABLE                2002
#define IDC_FONT_SIZE                   2004
#define IDC_FONT_COLOR                  2005
#define IDC_FONT_NAME                   2006
#define IDC_TRANSPARENT                 2007
#define IDC_BACKGROUND_COLOR            2008
#define IDC_CTRL                        2009
#define IDC_ALT                         2010
#define IDC_WIN                         2011
#define IDC_HOTKEY                      2012
#define IDC_SHIFT                       2013
#define IDC_POSITION                    2014
#define IDC_TRACK_CHANGE                2015
#define IDC_RADIO1                      2016
#define IDC_WORD_WRAP                   2016
#define IDC_RADIO2                      2017
#define IDC_TRUNCATE                    2017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2006
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2017
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
