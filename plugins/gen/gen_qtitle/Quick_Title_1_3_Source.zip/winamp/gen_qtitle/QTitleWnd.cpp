// QTitleWnd.cpp : implementation file
//

#include "stdafx.h"

#include <winamp/frontend.h>

#include "gen_qtitle.h"
#include "QTitleWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQTitleWnd

#define TIMER_EVENT_ID	100
#define HOTKEY			100

//-------------------------------------------------------------------------
// CQTitleWnd
//-------------------------------------------------------------------------
CQTitleWnd::CQTitleWnd() :
	m_iCountdown(0),
	m_uiHotKeyMods(MOD_ALT),
	m_uiVirtualKey(_T('S')),
	m_rBGColor(RGB(230,230,250)),
	m_rFGColor(RGB(102,102,102)),
	m_sFontName(_T("Courier")),
	m_bTransparent(FALSE),
	m_iFontSize(24),
	m_bEnabled(TRUE),
	m_iTimeout(2000),
	m_hwndWinamp(NULL),
	m_iPosition(3),
	m_bTransitions(TRUE),
	m_iWordWrap(0)
{
}

//-------------------------------------------------------------------------
// ~CQTitleWnd
//-------------------------------------------------------------------------
CQTitleWnd::~CQTitleWnd()
{
}


BEGIN_MESSAGE_MAP(CQTitleWnd, CFrameWnd)
	//{{AFX_MSG_MAP(CQTitleWnd)
	ON_WM_PAINT()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WMU_UPDATE_TEXT, OnUpdateDisplay)
	ON_MESSAGE(WM_HOTKEY, OnHotKey)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CQTitleWnd message handlers


//-------------------------------------------------------------------------
// Create
//-------------------------------------------------------------------------
BOOL 
CQTitleWnd::Create(HWND hwndWinamp)
{
	BOOL bReturn = FALSE;

	CString sWndClass = AfxRegisterWndClass(CS_OWNDC, 0, 0, 0);
    
	if(CFrameWnd::Create(sWndClass,
						 _T(""), // no title
						 WS_POPUP,
						 CRect(0,0,0,0)))  
	{
		// Change the properties so that the window does not show on the taskbar
		ModifyStyleEx(WS_EX_APPWINDOW | WS_EX_CLIENTEDGE | WS_EX_WINDOWEDGE,
					  WS_EX_TOOLWINDOW);

		m_hwndWinamp = hwndWinamp;

		SetHotKey(m_uiHotKeyMods, m_uiVirtualKey);

		bReturn = TRUE;
	}

	return(bReturn);
}

//-------------------------------------------------------------------------
// OnUpdateDisplay
//-------------------------------------------------------------------------
LRESULT 
CQTitleWnd::OnUpdateDisplay(WPARAM wParam, LPARAM lParam)
{
	if(m_bEnabled)
	{
		BOOL bForceDisplay = (BOOL)wParam;

		int iIndex = ::SendMessage(m_hwndWinamp, WM_WA_IPC, 0, IPC_GETLISTPOS);

		CString sText = (LPCTSTR)::SendMessage(m_hwndWinamp, WM_WA_IPC, iIndex, IPC_GETPLAYLISTTITLE);

		if(bForceDisplay || m_sText.Compare(sText))
		{
			CRect rcText(0,0,0,0);
			CRect rcDesktop;

			m_sText = sText;

			KillTimer(TIMER_EVENT_ID);

			ShowWindow(SW_HIDE);

			// This short sleep lets the window clear itself
			// because transparent mode will just keep
			// writing over-lapping text which eventually
			// becomes unreadable
			if(m_bTransparent)
			{
				SleepEx(10, FALSE);
			}

			::GetWindowRect(::GetDesktopWindow(), &rcDesktop);

			CDC* pDC = GetDC();

			CFont* pOldFont = pDC->SelectObject(&m_oFont);

			UINT uiFormat = DT_NOPREFIX | DT_CENTER | DT_VCENTER | DT_CALCRECT;

			pDC->DrawText(m_sText, rcText, uiFormat);

			if(rcText.right > rcDesktop.right)
			{
				rcText.right = rcDesktop.right;

				if(0 == m_iWordWrap)
				{
					uiFormat |= DT_WORDBREAK;
				}
				else
				{
					uiFormat |= DT_WORD_ELLIPSIS;
				}

				pDC->DrawText(m_sText, rcText, DT_CALCRECT | uiFormat);
			}


			pDC->SelectObject(pOldFont);

			ReleaseDC(pDC);

			rcText.InflateRect(4,4);

			switch(m_iPosition)
			{
				case 0: // top left
					rcText.OffsetRect(0, 0);
					break;
				case 1: // top middle
					rcText.OffsetRect((rcDesktop.right - rcText.right) / 2, 0);
					break;
				case 2: // top right
					rcText.OffsetRect(rcDesktop.right - rcText.right, 0);
					break;
				case 4: // bottom left
					rcText.OffsetRect(0, rcDesktop.bottom - rcText.bottom);
					break;
				case 5: // bottom middle
					rcText.OffsetRect((rcDesktop.right - rcText.right) / 2, 
									  rcDesktop.bottom - rcText.bottom);
					break;
				case 6: // bottom right
					rcText.OffsetRect(rcDesktop.right - rcText.right, 
									  rcDesktop.bottom - rcText.bottom);
					break;
				default:// centered
					rcText.OffsetRect((rcDesktop.right - rcText.right) / 2, 
									  (rcDesktop.bottom - rcText.bottom) / 2);
					break;
			}

			MoveWindow(&rcText,FALSE);

			SetWindowPos(&wndTopMost,
						 0,0,0,0,
						 SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);

			SetTimer(TIMER_EVENT_ID, m_iTimeout, NULL);
		}
	}

	return(0);
}

//-------------------------------------------------------------------------
// OnPaint
//-------------------------------------------------------------------------
void 
CQTitleWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	CRect rcText;

	GetClientRect(&rcText);

	CFont* pOldFont = dc.SelectObject(&m_oFont);

	UINT uiFormat = DT_NOPREFIX | DT_CENTER | DT_VCENTER;

	if(0 == m_iWordWrap)
	{
		uiFormat |= DT_WORDBREAK;
	}
	else
	{
		uiFormat |= DT_WORD_ELLIPSIS;
	}

	if(m_bTransparent)
	{
		dc.SetBkMode(TRANSPARENT);
		rcText.DeflateRect(4,4);

		dc.SetTextColor(m_rBGColor);
		rcText.OffsetRect(-1,-1);
		dc.DrawText(m_sText, rcText, uiFormat);
		rcText.OffsetRect(2,0);
		dc.DrawText(m_sText, rcText, uiFormat);
		rcText.OffsetRect(0,2);
		dc.DrawText(m_sText, rcText, uiFormat);
		rcText.OffsetRect(-2,0);
		dc.DrawText(m_sText, rcText, uiFormat);
		rcText.OffsetRect(1,-1);

		dc.SetTextColor(m_rFGColor);
		dc.DrawText(m_sText, rcText, uiFormat);
	}
	else
	{
		dc.FillSolidRect(&rcText, m_rBGColor);
		dc.DrawEdge(rcText, EDGE_ETCHED, BF_RECT);

		rcText.DeflateRect(4,4);
		dc.SetTextColor(m_rFGColor);
		dc.DrawText(m_sText, rcText, uiFormat);
	}



	dc.SelectObject(pOldFont);
}

//-------------------------------------------------------------------------
// OnTimer
//-------------------------------------------------------------------------
void 
CQTitleWnd::OnTimer(UINT nIDEvent) 
{
	ShowWindow(SW_HIDE);

	CFrameWnd::OnTimer(nIDEvent);
}

void 
CQTitleWnd::SetTimeout(int iTimeout)
{
	m_iTimeout = iTimeout;
}

int 
CQTitleWnd::GetTimeout()
{
	return(m_iTimeout);
}

void 
CQTitleWnd::SetEnabled(BOOL bEnable)
{
	m_bEnabled = bEnable;

	SetHotKey(m_uiHotKeyMods, m_uiVirtualKey);
}

BOOL		
CQTitleWnd::IsEnabled()
{
	return(m_bEnabled);
}

void 
CQTitleWnd::SetFontSize(int iFontSize)
{
	m_iFontSize = iFontSize;

	ResetFont();
}

int 
CQTitleWnd::GetFontSize()
{
	return(m_iFontSize);
}

void 
CQTitleWnd::SetFontName(LPCTSTR szFontName)
{
	m_sFontName = szFontName;

	ResetFont();
}

LPCTSTR
CQTitleWnd::GetFontName()
{
	return(m_sFontName);
}


void 
CQTitleWnd::SetFGColor(COLORREF rColor)
{
	m_rFGColor = rColor;
}

COLORREF
CQTitleWnd::GetFGColor()
{
	return(m_rFGColor);
}


void 
CQTitleWnd::SetBGColor(COLORREF rColor)
{
	m_rBGColor = rColor;
}

COLORREF
CQTitleWnd::GetBGColor()
{
	return(m_rBGColor);
}


void 
CQTitleWnd::SetTransparent(BOOL bTransparent)
{

	m_bTransparent = bTransparent;
}

BOOL
CQTitleWnd::IsTransparent()
{

	return(m_bTransparent);
}

void
CQTitleWnd::ResetFont()
{
	LOGFONT lf;

	memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy(lf.lfFaceName, m_sFontName); 
	lf.lfWeight = FW_BOLD;
	lf.lfHeight = m_iFontSize;

	m_oFont.Detach();
	m_oFont.CreateFontIndirect(&lf);
}

void 
CQTitleWnd::SetHotKey(UINT uiModifiers, UINT uiVirtualKey)
{
	m_uiHotKeyMods	= uiModifiers;
	m_uiVirtualKey	= uiVirtualKey;

	::UnregisterHotKey(m_hWnd, HOTKEY);

	if(m_uiHotKeyMods && m_bEnabled)
	{
		::RegisterHotKey(m_hWnd, HOTKEY, m_uiHotKeyMods, m_uiVirtualKey);
	}
}

void 
CQTitleWnd::GetHotKey(UINT& uiModifiers, UINT& uiVirtualKey)
{
	uiModifiers		= m_uiHotKeyMods;
	uiVirtualKey	= m_uiVirtualKey;
}


LRESULT 
CQTitleWnd::OnHotKey(WPARAM wParam, LPARAM lParam)
{
	PostMessage(WMU_UPDATE_TEXT, (WPARAM) TRUE, 0);

	return(1);
}

BOOL 
CQTitleWnd::DestroyWindow() 
{
	::UnregisterHotKey(m_hWnd, HOTKEY);

	return CFrameWnd::DestroyWindow();
}

int 
CQTitleWnd::GetWindowPosition()
{
	return(m_iPosition);
}

void 
CQTitleWnd::SetWindowPosition(int iPosition)
{
	m_iPosition = iPosition;
}

void 
CQTitleWnd::SetShowTransitions(BOOL bTransitions)
{
	m_bTransitions = bTransitions;
}

BOOL 
CQTitleWnd::GetShowTransitions()
{
	return(m_bTransitions);
}


int 
CQTitleWnd::GetWordWrap()
{
	return(m_iWordWrap);
}

void 
CQTitleWnd::SetWordWrap(int iWordWrap)
{
	m_iWordWrap = iWordWrap;
}
