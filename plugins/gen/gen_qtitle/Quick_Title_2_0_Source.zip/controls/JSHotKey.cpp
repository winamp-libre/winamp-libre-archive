//---------------------------------------------------------------------------
// Copyright 2004 James Starling
//---------------------------------------------------------------------------

#include "stdafx.h"
#include "JSHotKey.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define VK_PRESSED1 -127
#define VK_PRESSED2 -128


//---------------------------------------------------------------------------
// DDX_JSHotKey
//---------------------------------------------------------------------------
void AFXAPI 
DDX_JSHotKey(CDataExchange *pDX, int nIDC, WORD& wVirtualKeyCode, WORD& wModifiers)
{
    HWND hWndCtrl = pDX->PrepareCtrl(nIDC);
    ASSERT (hWndCtrl != NULL);                
    
    CJSHotKey* pCtrl = (CJSHotKey*) CWnd::FromHandle(hWndCtrl);

    if (pDX->m_bSaveAndValidate)
    {
		pCtrl->GetHotKey(wVirtualKeyCode, wModifiers);
    }
    else // initializing
    {
		pCtrl->SetHotKey(wVirtualKeyCode, wModifiers);
    }
}

//---------------------------------------------------------------------------
// CJSHotKey
//---------------------------------------------------------------------------
CJSHotKey::CJSHotKey() :
	m_wModifiers(0),
	m_wVirtualKeyCode(0)
{
}

//---------------------------------------------------------------------------
// ~CJSHotKey
//---------------------------------------------------------------------------
CJSHotKey::~CJSHotKey()
{
}


BEGIN_MESSAGE_MAP(CJSHotKey, CHotKeyCtrl)
	ON_WM_PAINT()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

//---------------------------------------------------------------------------
// OnKeyDown
//---------------------------------------------------------------------------
void 
CJSHotKey::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// Workaround: Winkey by design is not processed 
	// by the CHotKeyCtrl base class. This code prevents winkey 
	// from clearing other hot key modifiers (e.g. ctrl) from 
	// the display. By commenting out ON_WM_KEYDOWN() above 
	// you can press Ctrl then Winkey to see the problem
	if(nChar == VK_LWIN || nChar == VK_RWIN)
	{
		InvalidateRect(NULL, TRUE);
	}
	else
	{
		CHotKeyCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
	}
}

//---------------------------------------------------------------------------
// OnPaint
//---------------------------------------------------------------------------
void 
CJSHotKey::OnPaint() 
{
	InvalidateRect(NULL, TRUE);

	WORD		wVirtualKeyCode = 0;
	WORD		wModifiers = 0;

	GetHotKey(wVirtualKeyCode, wModifiers);

	if(VK_PRESSED1 == GetKeyState(VK_LWIN) || 
	   VK_PRESSED2 == GetKeyState(VK_LWIN) ||
	   VK_PRESSED1 == GetKeyState(VK_RWIN) || 
	   VK_PRESSED2 == GetKeyState(VK_RWIN))
	{
		wModifiers |= HOTKEYF_EXT;
	}

	m_wVirtualKeyCode	= wVirtualKeyCode;
	m_wModifiers		= wModifiers;

	SetHotKey(m_wVirtualKeyCode, m_wModifiers);

	TCHAR szKeyName[32];
	GetKeyNameText(MapVirtualKey(m_wVirtualKeyCode, 0) << 16, // need to bit shift, see docs
								 szKeyName, 
								 sizeof(szKeyName));

	CString	sText;
	if(m_wModifiers & HOTKEYF_EXT)		sText += _T("Winkey + ");
	if(m_wModifiers & HOTKEYF_CONTROL)	sText += _T("Ctrl + ");
	if(m_wModifiers & HOTKEYF_ALT)		sText += _T("Alt + ");
	if(m_wModifiers & HOTKEYF_SHIFT)	sText += _T("Shift + ");
										sText += szKeyName;
	if(sText.IsEmpty())					sText =  _T("None");

	CPaintDC	dc(this); // device context for painting
	CRect		rcCtrl;

	GetClientRect(rcCtrl);

	CFont* pOldFont = dc.SelectObject(GetFont());
	dc.FillSolidRect(rcCtrl, GetSysColor(COLOR_WINDOW));

	dc.DrawText(sText, rcCtrl, DT_LEFT | DT_SINGLELINE | DT_VCENTER | DT_CALCRECT);
	dc.DrawText(sText, rcCtrl, DT_LEFT | DT_SINGLELINE | DT_VCENTER);

	SetCaretPos(CPoint(rcCtrl.right, rcCtrl.top));

	dc.SelectObject(pOldFont);
}
