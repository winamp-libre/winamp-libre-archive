//---------------------------------------------------------------------------
// Copyright 2004 James Starling
//
// NOTE: AfxInitRichEdit() must be called somewhere in your application
//       in order to use this control.
//---------------------------------------------------------------------------

#include "stdafx.h"
#include "JSHiliteEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//---------------------------------------------------------------------------
// CJSHiliteEdit
//---------------------------------------------------------------------------
CJSHiliteEdit::CJSHiliteEdit(BOOL bCaseSensitive /*=FALSE*/) :
	m_bCaseSensitive(bCaseSensitive),
	m_iRedraw(0)
{
	m_cfText.cbSize			= sizeof(CHARFORMAT);
	m_cfText.dwMask			= CFM_COLOR | CFM_BOLD;
	m_cfText.dwEffects		= CFE_BOLD;
	m_cfText.crTextColor	= RGB(0,0,0);

	m_cfKeyword.cbSize		= sizeof(CHARFORMAT);
	m_cfKeyword.dwMask		= CFM_COLOR | CFM_BOLD;
	m_cfKeyword.dwEffects	= CFE_BOLD;
	m_cfKeyword.crTextColor = RGB(200,0,0);
}

//---------------------------------------------------------------------------
// ~CJSHiliteEdit
//---------------------------------------------------------------------------
CJSHiliteEdit::~CJSHiliteEdit()
{
	CleanUp(); // Free the lists
}


BEGIN_MESSAGE_MAP(CJSHiliteEdit, CRichEditCtrl)
	ON_CONTROL_REFLECT(EN_CHANGE, OnChange)
	ON_WM_KEYDOWN()
	ON_CONTROL_REFLECT(EN_KILLFOCUS, OnKillFocus)
END_MESSAGE_MAP()

//---------------------------------------------------------------------------
// OnChange
//---------------------------------------------------------------------------
void 
CJSHiliteEdit::OnChange() 
{
	FormatLine(LineFromChar(-1)); // -1 gets the current line
}

//---------------------------------------------------------------------------
// PreSubclassWindow
//---------------------------------------------------------------------------
void 
CJSHiliteEdit::PreSubclassWindow() 
{
	// Need to set this mask otherwise OnChange() will not get invoked
	SetEventMask(GetEventMask() | ENM_CHANGE);
	
	CRichEditCtrl::PreSubclassWindow();
}

//---------------------------------------------------------------------------
// AddKeyword
//---------------------------------------------------------------------------
void 
CJSHiliteEdit::AddKeyword(LPCTSTR szWord, BOOL bAutoReplace /*=FALSE*/) 
{
	CTWordInfo* pWordInfo = new CTWordInfo(szWord, bAutoReplace);

	if(pWordInfo)
	{
		CString sWord = szWord;

		// The search keys should all be uppercase
		// for case-insensitive look-ups
		sWord.MakeUpper();

		m_sKeywords += sWord;

		m_oKeywordMap.SetAt(sWord, pWordInfo);
	}
}

//---------------------------------------------------------------------------
// CleanUp
//---------------------------------------------------------------------------
void 
CJSHiliteEdit::CleanUp()
{
	CString				sKey;
	CTWordInfo*	pWordInfo = NULL;
	POSITION			pos = m_oKeywordMap.GetStartPosition();

	while(pos)
	{
		m_oKeywordMap.GetNextAssoc(pos, sKey, pWordInfo);

		delete pWordInfo;
	}

	m_oKeywordMap.RemoveAll();
}

//---------------------------------------------------------------------------
// FormatWindowText
//---------------------------------------------------------------------------
void
CJSHiliteEdit::FormatWindowText()
{
	SetRedraw(FALSE);

	int	iLines = GetLineCount();

	for(int iLine = 0; iLine < iLines; iLine++)
	{
		FormatLine(iLine);
	}

	SetRedraw(TRUE);
}

//---------------------------------------------------------------------------
// PreSubclassWindow
//---------------------------------------------------------------------------
void
CJSHiliteEdit::FormatLine(int iLine)
{
	SetRedraw(FALSE);

	int	iLineLength = LineLength(LineIndex(iLine));

	if(0 < iLineLength)
	{
		BOOL bAllowReplace = FALSE;

		// Allocate at least 4 bytes because 
		// GetLine() will attempt to read the length of the buffer
		// from the start of the buffer.
		TCHAR* szLine = new TCHAR[max(iLineLength, sizeof(DWORD)) + 1];

		if(szLine)
		{
			// Make sure to clean the buffer
			memset(szLine, 0, max(iLineLength, sizeof(DWORD)) + 1);

			// Read the line of text
			int iCharsRead = GetLine(iLine, szLine, iLineLength);

			if(0 < iCharsRead)
			{
				CHARRANGE	crCurrent;
				int			iFirstCharOfLine = LineIndex(iLine);

				GetSel(crCurrent);

				// We don't want to display any selections
				// as we reformat the line
				HideSelection(TRUE, FALSE);

				// Always NULL terminated
				szLine[iCharsRead] = _T('\0');

				TCHAR* szWord = szLine;

				for(int iIndex = 0; iIndex < iLineLength; iIndex++)
				{
					TCHAR cChar = szLine[iIndex + 1];

					szLine[iIndex + 1] = _T('\0');

					int iWordLength = _tcslen(szWord);

					CHARRANGE crWord;
					crWord.cpMin = (iFirstCharOfLine + iIndex + 1) - iWordLength;
					crWord.cpMax = (iFirstCharOfLine + iIndex + 1);

					SetSel(crWord);

					SetSelectionCharFormat(m_cfText);

					if(IsKeyword(szWord) && !IsAlphaNum(cChar))
					{
						bAllowReplace = (crCurrent.cpMax != crWord.cpMax);

						// Format the word
						FormatKeyword(szWord, bAllowReplace);

						szWord = (szLine + iIndex) + 1;
					}
					else if(!IsPartialKeyword(szWord))
					{
						szWord = (szLine + iIndex) + 1;
					}

					szLine[iIndex + 1] = cChar;
				}

				SetSel(crCurrent);

				SetSelectionCharFormat(m_cfText);

				HideSelection(FALSE, FALSE);
			}

			delete[] szLine, szLine = NULL;
		}
	}

	SetRedraw(TRUE);
}

//---------------------------------------------------------------------------
// SetWindowText
//---------------------------------------------------------------------------
void
CJSHiliteEdit::SetWindowText(LPCTSTR szText)
{
	CRichEditCtrl::SetWindowText(szText);

	FormatWindowText();
}

//---------------------------------------------------------------------------
// FormatKeyword
//---------------------------------------------------------------------------
BOOL
CJSHiliteEdit::FormatKeyword(LPCTSTR szWord, BOOL	bAllowReplace)
{
	CTWordInfo*	pWordInfo = NULL;
	CString		sWord = szWord;

	sWord.MakeUpper();

	m_oKeywordMap.Lookup(sWord, pWordInfo);

	return(FormatWord(szWord, bAllowReplace, m_cfKeyword, pWordInfo));
}

//---------------------------------------------------------------------------
// FormatWord
//---------------------------------------------------------------------------
BOOL
CJSHiliteEdit::FormatWord(LPCTSTR			szWord, 
						  BOOL				bAllowReplace, 
						  CHARFORMAT&		cf, 
						  CTWordInfo*		pWordInfo)
{
	BOOL bFormat = FALSE;

	if(pWordInfo)
	{
		if(!m_bCaseSensitive)
		{
			bFormat = (0 == _tcsicmp(pWordInfo->m_sWord, szWord));
		}
		else
		{
			bFormat = (0 == _tcscmp(pWordInfo->m_sWord, szWord));
		}

		if(bFormat)
		{
			// Only replace if not already exact match
			if(bAllowReplace && 
			   pWordInfo->m_bAutoReplace && 
			   0 != pWordInfo->m_sWord.Compare(szWord))
			{
				CHARRANGE crCurrent;

				GetSel(crCurrent);

				ReplaceSel(pWordInfo->m_sWord);

				// Reset the selection so we can
				// format it below
				SetSel(crCurrent);
			}

			// Format the word
			SetSelectionCharFormat(cf);
		}
	}

	return(bFormat);
}

//---------------------------------------------------------------------------
// SetCaseSensitive
//---------------------------------------------------------------------------
void
CJSHiliteEdit::SetCaseSensitive(BOOL bCaseSensitive)
{
	m_bCaseSensitive = bCaseSensitive;

	FormatWindowText();
}

//---------------------------------------------------------------------------
// GetTextFormat
//---------------------------------------------------------------------------
void
CJSHiliteEdit::GetTextFormat(CHARFORMAT& cf)
{
	memcpy(&cf, &m_cfText, sizeof(CHARFORMAT));
}

//---------------------------------------------------------------------------
// SetTextFormat
//---------------------------------------------------------------------------
void
CJSHiliteEdit::SetTextFormat(CHARFORMAT& cf)
{
	memcpy(&m_cfText, &cf, sizeof(CHARFORMAT));

	FormatWindowText();
}

//---------------------------------------------------------------------------
// SetTextColor
//---------------------------------------------------------------------------
void
CJSHiliteEdit::SetTextColor(COLORREF crColor)
{
	CHARFORMAT cf;

	GetTextFormat(cf);

	cf.dwMask |= CFM_COLOR;
	cf.crTextColor = crColor;

	SetTextFormat(cf);
}

//---------------------------------------------------------------------------
// GetKeywordFormat
//---------------------------------------------------------------------------
void
CJSHiliteEdit::GetKeywordFormat(CHARFORMAT& cf)
{
	memcpy(&cf, &m_cfKeyword, sizeof(CHARFORMAT));
}

//---------------------------------------------------------------------------
// SetKeywordFormat
//---------------------------------------------------------------------------
void
CJSHiliteEdit::SetKeywordFormat(CHARFORMAT& cf)
{
	memcpy(&m_cfKeyword, &cf, sizeof(CHARFORMAT));

	FormatWindowText();
}

//---------------------------------------------------------------------------
// SetKeywordColor
//---------------------------------------------------------------------------
void
CJSHiliteEdit::SetKeywordColor(COLORREF crColor)
{
	CHARFORMAT cf;

	GetKeywordFormat(cf);

	cf.dwMask |= CFM_COLOR;
	cf.crTextColor = crColor;

	SetKeywordFormat(cf);
}

//---------------------------------------------------------------------------
// IsKeyword
//---------------------------------------------------------------------------
BOOL
CJSHiliteEdit::IsKeyword(LPCTSTR szWord)
{
	CTWordInfo*		pWordInfo = NULL;
	CString			sWord = szWord;

	// The search keys should all be uppercase
	// for case-insensitive look-ups
	sWord.MakeUpper();

	m_oKeywordMap.Lookup(sWord, pWordInfo);

	return(pWordInfo? TRUE: FALSE);
}

//---------------------------------------------------------------------------
// IsPartialKeyword
//---------------------------------------------------------------------------
BOOL
CJSHiliteEdit::IsPartialKeyword(LPCTSTR szWord)
{
	CString sWord = szWord;

	// The search keys should all be uppercase
	// for case-insensitive look-ups
	sWord.MakeUpper();

	return(-1 < m_sKeywords.Find(sWord));
}

//---------------------------------------------------------------------------
// DestroyLists
//---------------------------------------------------------------------------
void
CJSHiliteEdit::DestroyLists()
{
	CleanUp();
}

//---------------------------------------------------------------------------
// SetRedraw
//
// This method must always be called in FALSE/TRUE pairs.
//---------------------------------------------------------------------------
void
CJSHiliteEdit::SetRedraw(BOOL bRedraw)
{
	CSingleLock oLock(&m_csRedraw, TRUE);

	if(bRedraw)
	{
		m_iRedraw = max(0, m_iRedraw - 1);
	}
	else
	{
		m_iRedraw++;
	}

	CRichEditCtrl::SetRedraw(0 == m_iRedraw);

	if(0 == m_iRedraw)
	{
		InvalidateRect(NULL);
		SetEventMask(GetEventMask() | ENM_CHANGE);
	}
	else
	{
		// Disable the change notication when
		// redraw is disabled. 
		SetEventMask(GetEventMask() & ~ENM_CHANGE);
	}

}

//---------------------------------------------------------------------------
// OnKeyDown
//---------------------------------------------------------------------------
void 
CJSHiliteEdit::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if(VK_RETURN == nChar)
	{
		SetRedraw(FALSE);

		CHARRANGE crCurrent;

		GetSel(crCurrent);

		int iLine = LineFromChar(-1);

		// Change the selection to the first character
		// so that none of the words will register as
		// the current word
		SetSel(0,0);

		FormatLine(iLine);

		// Restore the selection
		SetSel(crCurrent);

		SetRedraw(TRUE);
	}
	
	CRichEditCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
}

//---------------------------------------------------------------------------
// OnKillFocus
//---------------------------------------------------------------------------
void 
CJSHiliteEdit::OnKillFocus()
{
	SetRedraw(FALSE);

	int iLine = LineFromChar(-1);

	// Change the selection to the first character
	// so that none of the words will register as
	// the current word
	SetSel(0,0);

	FormatLine(iLine);

	SetRedraw(TRUE);
}

//---------------------------------------------------------------------------
// IsAlphaNum
//---------------------------------------------------------------------------
BOOL
CJSHiliteEdit::IsAlphaNum(TCHAR cChar)
{
	return((cChar >= _T('a') && cChar <= _T('z')) ||
		   (cChar >= _T('A') && cChar <= _T('Z')) || 
		   (cChar >= _T('0') && cChar <= _T('9')) ||
		    cChar == _T('<') ||
		    cChar == _T('%') ||
		    cChar == _T('>'));
}
