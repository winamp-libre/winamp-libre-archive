//---------------------------------------------------------------------------
// Copyright 2004 James Starling
//---------------------------------------------------------------------------

#if !defined(AFX_JSHOTKEY_H__4698DF89_11A0_40CA_93C7_344CC93998FD__INCLUDED_)
#define AFX_JSHOTKEY_H__4698DF89_11A0_40CA_93C7_344CC93998FD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

void AFXAPI DDX_JSHotKey(CDataExchange *pDX, int nIDC, WORD& wVirtualKeyCode, WORD& wModifiers);

class CJSHotKey : public CHotKeyCtrl
{
// Construction
public:
	CJSHotKey();
	virtual ~CJSHotKey();

protected:
	afx_msg void OnPaint();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);

	DECLARE_MESSAGE_MAP()

private:
	WORD m_wModifiers;
	WORD m_wVirtualKeyCode;
};

#endif // !defined(AFX_JSHOTKEY_H__4698DF89_11A0_40CA_93C7_344CC93998FD__INCLUDED_)
