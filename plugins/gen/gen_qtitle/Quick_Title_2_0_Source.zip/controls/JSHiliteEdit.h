//---------------------------------------------------------------------------
// Copyright 2004 James Starling
//---------------------------------------------------------------------------

#if !defined(AFX_JSHILITEEDIT_H__4698DF89_11A0_40CA_93C7_344CC93998FD__INCLUDED_)
#define AFX_JSHILITEEDIT_H__4698DF89_11A0_40CA_93C7_344CC93998FD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxmt.h>
#include <afxtempl.h>

class CTWordInfo : public CObject
{
private:
	friend class CJSHiliteEdit;

	CTWordInfo(const CTWordInfo&); // disable copy constructor
	CTWordInfo& operator=(const CTWordInfo&); // disable copy

	CTWordInfo();
	CTWordInfo(LPCTSTR szWord, BOOL bAutoReplace = FALSE);

	CString m_sWord;
	BOOL	m_bAutoReplace;
};

inline
CTWordInfo::CTWordInfo(LPCTSTR szWord, BOOL bAutoReplace /*=FALSE*/) :
	m_sWord(szWord),
	m_bAutoReplace(bAutoReplace)
{
}

typedef CMap<CString, LPCTSTR, CTWordInfo*, CTWordInfo*> CTWordInfoMap ;

class CJSHiliteEdit : public CRichEditCtrl
{
public:
					CJSHiliteEdit(BOOL bCaseSensitive = FALSE);
	virtual			~CJSHiliteEdit();

	virtual void	AddKeyword(LPCTSTR szWord, BOOL bAutoReplace = FALSE);
	virtual BOOL	IsKeyword(LPCTSTR szWord);
	virtual BOOL	IsPartialKeyword(LPCTSTR szWord);

	virtual BOOL	IsCaseSensitive() const;
	virtual void	SetCaseSensitive(BOOL bCaseSensitive);

	virtual void	SetWindowText(LPCTSTR szText);

	virtual void	SetKeywordColor(COLORREF crColor);
	virtual void	SetKeywordFormat(CHARFORMAT& cf);
	virtual void	GetKeywordFormat(CHARFORMAT& cf);

	virtual void	SetTextColor(COLORREF crColor);
	virtual void	SetTextFormat(CHARFORMAT& cf);
	virtual void	GetTextFormat(CHARFORMAT& cf);

	virtual void	DestroyLists();

	virtual void	Refresh();

protected:
	virtual void	PreSubclassWindow();
	afx_msg void	OnChange();
	afx_msg void	OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void	OnKillFocus();

	DECLARE_MESSAGE_MAP()
private:
	void					CleanUp();

	void					FormatWindowText();
	void					FormatLine(int iLine);

	BOOL					FormatKeyword(LPCTSTR szWord, BOOL bAllowReplace);
	BOOL					FormatWord(LPCTSTR			szWord, 
									   BOOL				bAllowReplace, 
									   CHARFORMAT&		cf, 
									   CTWordInfo*		pWordInfo);

	void					SetRedraw(BOOL bRedraw);
	BOOL					IsAlphaNum(TCHAR cChar);

	CTWordInfoMap			m_oKeywordMap;
	CString					m_sKeywords;
	BOOL					m_bCaseSensitive;
	CHARFORMAT				m_cfText;
	CHARFORMAT				m_cfKeyword;
	int						m_iRedraw;
	CCriticalSection		m_csRedraw;
};

//---------------------------------------------------------------------------
// IsCaseSensitive
//---------------------------------------------------------------------------
inline BOOL
CJSHiliteEdit::IsCaseSensitive() const
{
	return(m_bCaseSensitive);
}

//---------------------------------------------------------------------------
// Refresh
//---------------------------------------------------------------------------
inline void
CJSHiliteEdit::Refresh()
{
	FormatWindowText();
}


#endif // !defined(AFX_JSHILITEEDIT_H__4698DF89_11A0_40CA_93C7_344CC93998FD__INCLUDED_)
