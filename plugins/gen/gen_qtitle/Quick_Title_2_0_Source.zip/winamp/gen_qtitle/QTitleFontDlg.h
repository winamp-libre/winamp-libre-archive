//---------------------------------------------------------------------------
// Copyright 2004 James Starling
//---------------------------------------------------------------------------

#if !defined(AFX_QTITLEFONTDIALOG_H__C2D8EC35_4CCF_44A2_8A9A_7D7608D11ECE__INCLUDED_)
#define AFX_QTITLEFONTDIALOG_H__C2D8EC35_4CCF_44A2_8A9A_7D7608D11ECE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CQTitleFontDlg : public CFontDialog
{
	DECLARE_DYNAMIC(CQTitleFontDlg)

public:
	CQTitleFontDlg(LPLOGFONT	lplfInitial = NULL,
				   DWORD		dwFlags = CF_EFFECTS | CF_SCREENFONTS,
				   CDC*			pdcPrinter = NULL,
				   CWnd*		pParentWnd = NULL);

	#ifndef _AFX_NO_RICHEDIT_SUPPORT

	CQTitleFontDlg(const CHARFORMAT&	charformat,
				   DWORD				dwFlags = CF_SCREENFONTS,
				   CDC*					pdcPrinter = NULL,
				   CWnd*				pParentWnd = NULL);
	#endif

protected:
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_QTITLEFONTDIALOG_H__C2D8EC35_4CCF_44A2_8A9A_7D7608D11ECE__INCLUDED_)
