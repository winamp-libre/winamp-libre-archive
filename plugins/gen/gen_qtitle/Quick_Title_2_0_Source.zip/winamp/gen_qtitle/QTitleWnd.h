//---------------------------------------------------------------------------
// Copyright 2002-2004 James Starling
//---------------------------------------------------------------------------

#if !defined(AFX_QTITLEWND_H__77CCA24F_3378_11D6_86F1_00E02910A56E__INCLUDED_)
#define AFX_QTITLEWND_H__77CCA24F_3378_11D6_86F1_00E02910A56E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define KEYWORD_ARTIST		_T("$artist")
#define KEYWORD_ALBUM		_T("$album")
#define KEYWORD_TITLE		_T("$title")
#define KEYWORD_TRACK		_T("$track")
#define KEYWORD_WINAMP		_T("$winamp") // Winamp's title

#define WMU_UPDATE_TEXT		WM_USER + 0

typedef BOOL (WINAPI *lpfnSetLayeredWindowAttributes)(HWND hWnd, 
                                  COLORREF crKey, BYTE bAlpha, DWORD dwFlags);

class CQTitleWnd : public CFrameWnd
{
// Construction
public:
					CQTitleWnd();
	virtual			~CQTitleWnd();

	BOOL			Create(HWND hwndWinamp);
	virtual BOOL	DestroyWindow();

	void			Display(BOOL bForceDisplay);
	void			GetPrefs(QTITLEPREFS& prefs);
	void			SetPrefs(QTITLEPREFS& prefs);
	BOOL			IsTransitions();
	BOOL			IsTransparent();
	HWND			GetWinampHWND();

protected:
	afx_msg void	OnPaint();
	afx_msg void	OnTimer(UINT nIDEvent);
	afx_msg LRESULT OnUpdateDisplay(WPARAM, LPARAM);
	afx_msg LRESULT OnHotKey(WPARAM, LPARAM);

	DECLARE_MESSAGE_MAP()

private:
	void			ResetFont();

	CString			m_sText;
	CString			m_sWinampTitle;
	CString			m_sFile;
	HWND			m_hwndWinamp;
	CFont			m_oFont;
	UINT			m_uiFormat;
	BYTE			m_byAlpha;
					
	QTITLEPREFS		m_prefs;

	lpfnSetLayeredWindowAttributes	m_pSetLayeredWindowAttributes;
};


//-------------------------------------------------------------------------
// IsTransitions
//-------------------------------------------------------------------------
inline BOOL 
CQTitleWnd::IsTransitions()
{
	return(m_prefs.bTransitions);	
}

//-------------------------------------------------------------------------
// IsTransparent
//-------------------------------------------------------------------------
inline BOOL 
CQTitleWnd::IsTransparent()
{
	return(m_prefs.bOutline);	
}

//-------------------------------------------------------------------------
// GetWinampHWND
//-------------------------------------------------------------------------
inline HWND
CQTitleWnd::GetWinampHWND()
{
	return(m_hwndWinamp);
}


#endif // !defined(AFX_QTITLEWND_H__77CCA24F_3378_11D6_86F1_00E02910A56E__INCLUDED_)
