//---------------------------------------------------------------------------
// Copyright 2002-2004 James Starling
//---------------------------------------------------------------------------

#if !defined(AFX_QTITLECONFIGDLG_H__6598DDE4_3A9A_11D6_86F1_00E02910A56E__INCLUDED_)
#define AFX_QTITLECONFIGDLG_H__6598DDE4_3A9A_11D6_86F1_00E02910A56E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../../controls/ColorPicker.h"
#include "../../controls/JSHotKey.h"
#include "../../controls/JSHiliteEdit.h"
#include "../../controls/JSHyperLink.h"
#include "../../controls/XInfoTip.h"

class CQTitleWnd;

class CQTitleConfigDlg : public CDialog
{
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CQTitleConfigDlg(CQTitleWnd* pwndQTitle, CWnd* pParent = NULL);   // standard constructor

	void			GetPrefs(QTITLEPREFS& prefs);
	void			SetPrefs(QTITLEPREFS& prefs);

protected:
	enum { IDD = IDD_QTITLECONFIG };

	virtual void	DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	afx_msg void	OnFont();
	afx_msg void	OnInvert();
	afx_msg void	OnPreview();
	afx_msg void	OnPresets();
	afx_msg void	OnAnchor();

	afx_msg void	OnSetPreset(int iMenuID);
	afx_msg void	OnTopLeft()		{OnSetPreset(IDM_TOPLEFT);};
	afx_msg void	OnTop()			{OnSetPreset(IDM_TOP);};
	afx_msg void	OnTopRight()	{OnSetPreset(IDM_TOPRIGHT);};
	afx_msg void	OnCenter()		{OnSetPreset(IDM_CENTER);};
	afx_msg void	OnBottomLeft()	{OnSetPreset(IDM_BOTTOMLEFT);};
	afx_msg void	OnBottom()		{OnSetPreset(IDM_BOTTOM);};
	afx_msg void	OnBottomRight() {OnSetPreset(IDM_BOTTOMRIGHT);};

	virtual void	OnOK();
	virtual BOOL	OnInitDialog();
	afx_msg void	OnLButtonUp(UINT nFlags, CPoint pt);
	afx_msg void	OnMouseMove(UINT nFlags, CPoint pt);
	void			SetCursor(CPoint& pt);
	afx_msg void	OnAlignSelChange();
	afx_msg void	OnTimer(UINT nIDEvent);

	DECLARE_MESSAGE_MAP()

private:
	void			SetFormatFont();
	void			SetFormatAlignment();

	CColorPicker		m_buttonForeground;
	CColorPicker		m_buttonBackground;
	CJSHotKey			m_oHotKey;
	CJSHiliteEdit		m_oFormat;
	CJSHyperLink		m_oMailTo;
	QTITLEPREFS			m_prefs;
	CQTitleWnd*			m_pwndQTitle;
	CStatic				m_oAnchor;
	CComboBox			m_comboAlign;
	CSliderCtrl			m_sliderTransparency;
	CToolTipCtrl		m_tooltip;

	HCURSOR				m_hAnchor[9];
	HICON				m_hShowAnchor;
	HICON				m_hNoAnchor;
	BOOL				m_bDragAnchor;
};

#endif // !defined(AFX_QTITLECONFIGDLG_H__6598DDE4_3A9A_11D6_86F1_00E02910A56E__INCLUDED_)
