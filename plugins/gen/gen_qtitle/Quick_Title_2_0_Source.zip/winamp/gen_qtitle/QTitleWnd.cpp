//---------------------------------------------------------------------------
// Copyright 2002-2004 James Starling
//---------------------------------------------------------------------------

#include "stdafx.h"

#include "gen_qtitle.h"
#include "QTitleWnd.h"

#include "../wa_ipc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define TIMERID_HIDE	100
#define TIMERID_FADEOUT	101
#define HOTKEY			100

#ifndef WS_EX_LAYERED
#define WS_EX_LAYERED           0x00080000
#define LWA_COLORKEY            0x00000001
#define LWA_ALPHA               0x00000002
#endif // ndef WS_EX_LAYERED

const g_kiPadding = 4;

#define TRANSBGRND(c) (RGB(GetRValue(c) + 1, GetGValue(c), GetBValue(c)))

//-------------------------------------------------------------------------
// CQTitleWnd
//-------------------------------------------------------------------------
CQTitleWnd::CQTitleWnd() :
	m_hwndWinamp(NULL),
	m_uiFormat(0),
	m_byAlpha(255),
	m_pSetLayeredWindowAttributes(NULL)
{
	ZeroMemory(&m_prefs, sizeof(QTITLEPREFS));

	_stprintf(m_prefs.szFontName, _T("%s"), _T("Comic Sans MS")),
	_stprintf(m_prefs.szFormat, _T("%s"), KEYWORD_WINAMP),

	m_prefs.wHotKeyMods = MOD_ALT,
	m_prefs.wVirtualKey = 81, // 'Q'
	m_prefs.rBGColor = RGB(0x00,0x00,0x00),
	m_prefs.rFGColor = RGB(0xFF,0xD7,0x00),
	m_prefs.bOutline = TRUE,
	m_prefs.iFontSize = 24,
	m_prefs.iAlign = DT_LEFT;
	m_prefs.bEnabled = TRUE,
	m_prefs.iTimeout = 2000,
	m_prefs.bTransitions = TRUE;
	m_prefs.bSingleLine = FALSE;
	m_prefs.byAlpha = 255;

	CRect rcDesktop;
	GetDesktopWindow()->GetClientRect(rcDesktop);
	m_prefs.pt = CPoint(rcDesktop.Width() / 2, rcDesktop.Height() / 2);
}

//-------------------------------------------------------------------------
// ~CQTitleWnd
//-------------------------------------------------------------------------
CQTitleWnd::~CQTitleWnd()
{
}


BEGIN_MESSAGE_MAP(CQTitleWnd, CFrameWnd)
	ON_WM_PAINT()
	ON_WM_TIMER()
	ON_MESSAGE(WMU_UPDATE_TEXT, OnUpdateDisplay)
	ON_MESSAGE(WM_HOTKEY, OnHotKey)
END_MESSAGE_MAP()


//-------------------------------------------------------------------------
// Create
//-------------------------------------------------------------------------
BOOL 
CQTitleWnd::Create(HWND hwndWinamp)
{
	BOOL bReturn = FALSE;

	CString sWndClass = AfxRegisterWndClass(CS_OWNDC, 0, 0, 0);
    
	if(CFrameWnd::Create(sWndClass,
						 _T(""), // no title
						 WS_POPUP,
						 CRect(0,0,0,0)))  
	{
		DWORD	dwRemove = WS_EX_APPWINDOW | WS_EX_CLIENTEDGE | WS_EX_WINDOWEDGE;
		DWORD	dwAdd = WS_EX_TOOLWINDOW;
		HMODULE	hUser32 = GetModuleHandle(_T("USER32.DLL"));

		m_pSetLayeredWindowAttributes = 
							   (lpfnSetLayeredWindowAttributes)GetProcAddress(hUser32, 
							   _T("SetLayeredWindowAttributes"));

		if(m_pSetLayeredWindowAttributes)
		{
			dwAdd |= WS_EX_LAYERED;
		}

		// Change the properties so that the window does not show on the taskbar
		ModifyStyleEx(dwRemove, dwAdd);

		m_hwndWinamp = hwndWinamp;

		bReturn = TRUE;
	}

	return(bReturn);
}

//-------------------------------------------------------------------------
// OnHotKey
//-------------------------------------------------------------------------
LRESULT 
CQTitleWnd::OnHotKey(WPARAM wParam, LPARAM lParam)
{
	PostMessage(WMU_UPDATE_TEXT, (WPARAM) TRUE, 0);

	return(1);
}

//-------------------------------------------------------------------------
// DestroyWindow
//-------------------------------------------------------------------------
BOOL 
CQTitleWnd::DestroyWindow() 
{
	::UnregisterHotKey(m_hWnd, HOTKEY);

	return CFrameWnd::DestroyWindow();
}

//-------------------------------------------------------------------------
// OnUpdateDisplay
//-------------------------------------------------------------------------
LRESULT 
CQTitleWnd::OnUpdateDisplay(WPARAM wParam, LPARAM lParam)
{
	if(m_prefs.bEnabled)
	{
		Display((BOOL)wParam);
	}

	return(0);
}

//-------------------------------------------------------------------------
// Display
//-------------------------------------------------------------------------
void
CQTitleWnd::Display(BOOL bForceDisplay)
{
	int iIndex = ::SendMessage(GetWinampHWND(), WM_WA_IPC, 0, IPC_GETLISTPOS);

	CString sWinampTitle = (LPCTSTR)::SendMessage(GetWinampHWND(), WM_WA_IPC, iIndex, IPC_GETPLAYLISTTITLE);

	if(bForceDisplay || m_sWinampTitle.Compare(sWinampTitle))
	{
		CRect	rcDesktop;
		CRect	rcText;
		BOOL	bValid = TRUE;

		m_sWinampTitle = sWinampTitle;

		TRY
		{
			TCHAR szValue[256];

			m_sText = m_prefs.szFormat;

			// optimization
			if(m_sText == KEYWORD_WINAMP) AfxThrowResourceException();

			extendedFileInfoStruct efi;
			efi.filename = (LPTSTR)::SendMessage(GetWinampHWND(), WM_WA_IPC, iIndex, IPC_GETPLAYLISTFILE);
			efi.ret = szValue;
			efi.retlen = sizeof(szValue);

			if(0 <= m_sText.Find(KEYWORD_ARTIST)) 
			{
				efi.metadata = _T("ARTIST");

				if(::SendMessage(GetWinampHWND(), WM_WA_IPC, (WPARAM) &efi, IPC_GET_EXTENDED_FILE_INFO) && *szValue)
				{
					m_sText.Replace(KEYWORD_ARTIST, szValue);
				}
				else
				{
					AfxThrowResourceException();
				}
			}

			if(0 <= m_sText.Find(KEYWORD_TITLE)) 
			{
				efi.metadata = _T("TITLE");

				if(::SendMessage(GetWinampHWND(), WM_WA_IPC, (WPARAM) &efi, IPC_GET_EXTENDED_FILE_INFO) && *szValue)
				{
					m_sText.Replace(KEYWORD_TITLE, szValue);
				}
				else
				{
					AfxThrowResourceException();
				}
			}

			if(0 <= m_sText.Find(KEYWORD_TRACK)) 
			{
				efi.metadata = _T("TRACK");

				if(::SendMessage(GetWinampHWND(), WM_WA_IPC, (WPARAM) &efi, IPC_GET_EXTENDED_FILE_INFO) && *szValue)
				{
					m_sText.Replace(KEYWORD_TRACK, szValue);
				}
				else
				{
					AfxThrowResourceException();
				}
			}


			if(0 <= m_sText.Find(KEYWORD_ALBUM)) 
			{
				efi.metadata = _T("ALBUM");

				if(::SendMessage(GetWinampHWND(), WM_WA_IPC, (WPARAM) &efi, IPC_GET_EXTENDED_FILE_INFO) && *szValue)
				{
					m_sText.Replace(KEYWORD_ALBUM, szValue);
				}
				else
				{
					AfxThrowResourceException();
				}
			}

			if(0 <= m_sText.Find(KEYWORD_WINAMP)) 
			{
				m_sText.Replace(KEYWORD_WINAMP, m_sWinampTitle);
			}
		}
		CATCH_ALL(e)
		{
			m_sText = m_sWinampTitle;
		}
		END_CATCH_ALL

		KillTimer(TIMERID_HIDE);
		KillTimer(TIMERID_FADEOUT);

		ShowWindow(SW_HIDE);

		// This short sleep lets the window clear itself
		// because transparent mode will just keep
		// writing over-lapping text which eventually
		// becomes unreadable
		if(!m_pSetLayeredWindowAttributes && m_prefs.bOutline)
		{
			SleepEx(10, FALSE);
		}

		GetDesktopWindow()->GetWindowRect(&rcDesktop);

		rcText = rcDesktop;
		rcText.bottom = rcText.top + 1;
		rcText.right /= 2;

		CDC* pDC = GetDC();

		CFont* pOldFont = pDC->SelectObject(&m_oFont);

		int x = max(0, min(g_kix - 1, (m_prefs.pt.x / (rcDesktop.right  / g_kix))));
		int y = max(0, min(g_kiy - 1, (m_prefs.pt.y / (rcDesktop.bottom / g_kiy))));

		m_uiFormat = DT_NOPREFIX | m_prefs.iAlign;;

		m_uiFormat |= (m_prefs.bSingleLine? DT_WORD_ELLIPSIS | DT_SINGLELINE: DT_WORDBREAK);

		pDC->DrawText(m_sText, rcText, m_uiFormat | DT_CALCRECT);

		pDC->SelectObject(pOldFont);

		ReleaseDC(pDC);

		rcText.InflateRect(0, 0, g_kiPadding * 2, g_kiPadding * 2);

		CPoint pt(0,0);

		switch(g_aiAnchor[y][x])
		{
			case ANCHOR_TOPLEFT:
				pt.x = m_prefs.pt.x;
				pt.y = m_prefs.pt.y;
				break;
			case ANCHOR_TOP:
				pt.x = m_prefs.pt.x - (rcText.Width() / 2);
				pt.y = m_prefs.pt.y;
				break;
			case ANCHOR_TOPRIGHT:
				pt.x = m_prefs.pt.x - rcText.Width();
				pt.y = m_prefs.pt.y;
				break;
			case ANCHOR_LEFT:
				pt.x = m_prefs.pt.x;
				pt.y = m_prefs.pt.y - (rcText.Height() / 2);
				break;
			case ANCHOR_CENTER:
				pt.x = m_prefs.pt.x - (rcText.Width()  / 2);
				pt.y = m_prefs.pt.y - (rcText.Height() / 2);
				break;
			case ANCHOR_RIGHT:
				pt.x = m_prefs.pt.x - rcText.Width();
				pt.y = m_prefs.pt.y - (rcText.Height() / 2);
				break;
			case ANCHOR_BOTTOMLEFT:
				pt.x = m_prefs.pt.x;
				pt.y = m_prefs.pt.y - rcText.Height();
				break;
			case ANCHOR_BOTTOM:
				pt.x = m_prefs.pt.x - (rcText.Width() / 2);
				pt.y = m_prefs.pt.y - rcText.Height();
				break;
			case ANCHOR_BOTTOMRIGHT:
				pt.x = m_prefs.pt.x - rcText.Width();
				pt.y = m_prefs.pt.y - rcText.Height();
				break;
		}

		rcText.OffsetRect(pt);

		if(m_pSetLayeredWindowAttributes)
		{
			m_byAlpha = m_prefs.byAlpha;

			if(m_prefs.bOutline)
			{
				m_pSetLayeredWindowAttributes(m_hWnd, TRANSBGRND(m_prefs.rBGColor), m_byAlpha, LWA_COLORKEY | LWA_ALPHA);
			}
			else
			{
				m_pSetLayeredWindowAttributes(m_hWnd, m_prefs.rBGColor, m_byAlpha, LWA_ALPHA);
			}
		}

		SetWindowPos(&wndTopMost,
					 rcText.left,
					 rcText.top,
					 rcText.Width(),
					 rcText.Height(),
					 SWP_NOACTIVATE | SWP_SHOWWINDOW);

		if(m_pSetLayeredWindowAttributes)
		{
			SetTimer(TIMERID_FADEOUT, m_prefs.iTimeout / 2, NULL);
		}
		else
		{
			SetTimer(TIMERID_HIDE, m_prefs.iTimeout, NULL);
		}
	}
}

//-------------------------------------------------------------------------
// OnPaint
//-------------------------------------------------------------------------
void 
CQTitleWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	CRect rcText;

	GetClientRect(&rcText);

	CFont* pOldFont = dc.SelectObject(&m_oFont);

	if(m_prefs.bOutline)
	{
		if(m_pSetLayeredWindowAttributes)
		{
			dc.FillSolidRect(&rcText, TRANSBGRND(m_prefs.rBGColor));
		}

		dc.SetBkMode(TRANSPARENT);

		rcText.DeflateRect(g_kiPadding, g_kiPadding);

		dc.SetTextColor(m_prefs.rBGColor);
		dc.DrawText(m_sText, rcText + CPoint(-1,-1), m_uiFormat);
		dc.DrawText(m_sText, rcText + CPoint(1,1),   m_uiFormat);
		dc.DrawText(m_sText, rcText + CPoint(1,-1),  m_uiFormat);
		dc.DrawText(m_sText, rcText + CPoint(-1,1),  m_uiFormat);

		dc.SetTextColor(m_prefs.rFGColor);
		dc.DrawText(m_sText, rcText, m_uiFormat);
	}
	else
	{
		dc.FillSolidRect(&rcText, m_prefs.rBGColor);
		dc.DrawEdge(rcText, EDGE_BUMP, BF_RECT);

		rcText.DeflateRect(g_kiPadding, g_kiPadding);

		dc.SetTextColor(m_prefs.rFGColor);
		dc.DrawText(m_sText, rcText, m_uiFormat);
	}


	dc.SelectObject(pOldFont);
}

//-------------------------------------------------------------------------
// OnTimer
//-------------------------------------------------------------------------
void 
CQTitleWnd::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent == TIMERID_HIDE)
	{
		KillTimer(TIMERID_HIDE);

		ShowWindow(SW_HIDE);
	}

	if(nIDEvent == TIMERID_FADEOUT)
	{
		KillTimer(TIMERID_FADEOUT);

		int iInterations = 20;

		m_byAlpha = max(0, m_byAlpha - (m_prefs.byAlpha / iInterations));

		if(m_prefs.bOutline)
		{
			m_pSetLayeredWindowAttributes(m_hWnd, TRANSBGRND(m_prefs.rBGColor), m_byAlpha, LWA_COLORKEY | LWA_ALPHA);
		}
		else
		{
			m_pSetLayeredWindowAttributes(m_hWnd, m_prefs.rBGColor, m_byAlpha, LWA_ALPHA);
		}

		if(m_byAlpha)
		{
			SetTimer(TIMERID_FADEOUT, (m_prefs.iTimeout / 2) / iInterations, NULL);
		}
		else
		{
			ShowWindow(SW_HIDE);
		}

	}

	CFrameWnd::OnTimer(nIDEvent);
}

//-------------------------------------------------------------------------
// ResetFont
//-------------------------------------------------------------------------
void
CQTitleWnd::ResetFont()
{
	LOGFONT lf;

	memset(&lf, 0, sizeof(LOGFONT));
	_tcscpy(lf.lfFaceName, m_prefs.szFontName); 
	lf.lfWeight = m_prefs.iFontWeight;
	lf.lfItalic = m_prefs.bFontItalic;
	lf.lfHeight = m_prefs.iFontSize;

	m_oFont.Detach();
	m_oFont.CreateFontIndirect(&lf);
}

//-------------------------------------------------------------------------
// GetPrefs
//-------------------------------------------------------------------------
void
CQTitleWnd::GetPrefs(QTITLEPREFS& prefs)
{
	memcpy(&prefs, &m_prefs, sizeof(QTITLEPREFS));

	::UnregisterHotKey(m_hWnd, HOTKEY);
}

//-------------------------------------------------------------------------
// SetPrefs
//-------------------------------------------------------------------------
void
CQTitleWnd::SetPrefs(QTITLEPREFS& prefs)
{
	memcpy(&m_prefs, &prefs, sizeof(QTITLEPREFS));

	::RegisterHotKey(m_hWnd, HOTKEY, m_prefs.wHotKeyMods, m_prefs.wVirtualKey);

	ResetFont();
}

