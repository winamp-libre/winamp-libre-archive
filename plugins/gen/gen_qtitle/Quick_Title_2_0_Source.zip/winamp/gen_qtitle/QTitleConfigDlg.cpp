//---------------------------------------------------------------------------
// Copyright 2002-2004 James Starling
//---------------------------------------------------------------------------

#include "stdafx.h"
#include "gen_qtitle.h"
#include "QTitleConfigDlg.h"
#include "QTitleFontDlg.h"
#include "QTitleWnd.h"

#include "../wa_ipc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const TCHAR g_kszMailTo[] = _T("mailto:jamess@rogers.com?subject=Winamp%20Quick%20Title%20Plug-in");

#define TIMERID_SHOWPREVIEW		100

//---------------------------------------------------------------------------
// CQTitleConfigDlg
//---------------------------------------------------------------------------
CQTitleConfigDlg::CQTitleConfigDlg(CQTitleWnd* pwndQTitle, CWnd* pParent /*=NULL*/) :
	CDialog(CQTitleConfigDlg::IDD, pParent),
	m_pwndQTitle(pwndQTitle),
	m_bDragAnchor(FALSE)
{
	ASSERT(m_pwndQTitle);

	ZeroMemory(&m_prefs, sizeof(QTITLEPREFS));
}


//---------------------------------------------------------------------------
// DoDataExchange
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	CString sFormat;

	if(!pDX->m_bSaveAndValidate)
	{
		if(m_comboAlign.GetSafeHwnd())	m_comboAlign.SetCurSel(m_prefs.iAlign);
		if(m_oFormat.GetSafeHwnd())		m_oFormat.SetWindowText(m_prefs.szFormat);
	}

	DDX_Text(pDX, IDC_TIMEOUT, m_prefs.iTimeout);
	DDX_Slider(pDX, IDC_TRANSPARENCY, (int&)m_prefs.byAlpha);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_prefs.bEnabled);
	DDX_Check(pDX, IDC_OUTLINE, m_prefs.bOutline);
	DDX_Check(pDX, IDC_TRACK_CHANGE, m_prefs.bTransitions);
	DDX_Check(pDX, IDC_LINES, m_prefs.bSingleLine);
	DDX_ColorPicker(pDX, IDC_FONT_COLOR, m_prefs.rFGColor);
	DDX_ColorPicker(pDX, IDC_BACKGROUND_COLOR, m_prefs.rBGColor);
	DDX_JSHotKey(pDX, IDC_HOTKEY, m_prefs.wVirtualKey, m_prefs.wHotKeyMods);

	if(pDX->m_bSaveAndValidate)
	{
		if(m_comboAlign.GetSafeHwnd()) 	m_prefs.iAlign = m_comboAlign.GetCurSel();
		if(m_oFormat.GetSafeHwnd())		m_oFormat.GetWindowText(m_prefs.szFormat, sizeof(m_prefs.szFormat));
	}
}


BEGIN_MESSAGE_MAP(CQTitleConfigDlg, CDialog)
	ON_WM_TIMER()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDC_PRESETS, OnPresets)
	ON_BN_CLICKED(IDC_INVERT, OnInvert)
	ON_BN_CLICKED(IDC_SELECT_FONT, OnFont)
	ON_BN_CLICKED(IDC_PREVIEW, OnPreview)
	ON_BN_CLICKED(IDC_ANCHOR, OnAnchor)
	ON_CBN_SELCHANGE(IDC_ALIGN, OnAlignSelChange)

	ON_COMMAND(IDM_TOPLEFT,		OnTopLeft)
	ON_COMMAND(IDM_TOP,			OnTop)
	ON_COMMAND(IDM_TOPRIGHT,	OnTopRight)
	ON_COMMAND(IDM_CENTER,		OnCenter)
	ON_COMMAND(IDM_BOTTOMLEFT,	OnBottomLeft)
	ON_COMMAND(IDM_BOTTOM,		OnBottom)
	ON_COMMAND(IDM_BOTTOMRIGHT, OnBottomRight)
END_MESSAGE_MAP()

//---------------------------------------------------------------------------
// OnOK
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnOK() 
{
	UpdateData(TRUE);

	CDialog::OnOK();
}

//---------------------------------------------------------------------------
// OnInitDialog
//---------------------------------------------------------------------------
BOOL 
CQTitleConfigDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(m_buttonForeground.SubclassDlgItem(IDC_FONT_COLOR, this))
	{
		m_buttonForeground.SetDefaultText(_T(""));
	}

	if(m_buttonBackground.SubclassDlgItem(IDC_BACKGROUND_COLOR, this))
	{
		m_buttonBackground.SetDefaultText(_T(""));
	}

	m_sliderTransparency.SubclassDlgItem(IDC_TRANSPARENCY, this);
	m_sliderTransparency.SetRange(0, 255);

	m_comboAlign.SubclassDlgItem(IDC_ALIGN, this);
	m_comboAlign.AddString(_T("Left"));
	m_comboAlign.AddString(_T("Center"));
	m_comboAlign.AddString(_T("Right"));

	m_oMailTo.SubclassDlgItem(IDC_MAILTO, this);
	m_oMailTo.SetURL(g_kszMailTo, FALSE);

	m_oHotKey.SubclassDlgItem(IDC_HOTKEY, this);

	m_oFormat.SubclassDlgItem(IDC_FORMAT, this);
	m_oFormat.LimitText(sizeof(m_prefs.szFormat)-1);

	m_oFormat.AddKeyword(KEYWORD_ARTIST, TRUE);
	m_oFormat.AddKeyword(KEYWORD_ALBUM,  TRUE);
	m_oFormat.AddKeyword(KEYWORD_TITLE,  TRUE);
	m_oFormat.AddKeyword(KEYWORD_TRACK,  TRUE);
	m_oFormat.AddKeyword(KEYWORD_WINAMP, TRUE);

	m_oFormat.AddKeyword(_T("$if"), TRUE);

	m_hShowAnchor = AfxGetApp()->LoadIcon(IDI_ANCHOR);
	m_hNoAnchor   = AfxGetApp()->LoadIcon(IDI_NOANCHOR);

	m_oAnchor.SubclassDlgItem(IDC_ANCHOR, this);
	m_oAnchor.SetIcon(m_hShowAnchor);

	m_hAnchor[0] = AfxGetApp()->LoadCursor(IDC_CENTER);
	m_hAnchor[1] = AfxGetApp()->LoadCursor(IDC_TOPLEFT);
	m_hAnchor[2] = AfxGetApp()->LoadCursor(IDC_TOP);
	m_hAnchor[3] = AfxGetApp()->LoadCursor(IDC_TOPRIGHT);
	m_hAnchor[4] = AfxGetApp()->LoadCursor(IDC_RIGHT);
	m_hAnchor[5] = AfxGetApp()->LoadCursor(IDC_BOTTOMRIGHT);
	m_hAnchor[6] = AfxGetApp()->LoadCursor(IDC_BOTTOM);
	m_hAnchor[7] = AfxGetApp()->LoadCursor(IDC_BOTTOMLEFT);
	m_hAnchor[8] = AfxGetApp()->LoadCursor(IDC_LEFT);

	// Loading the icon this way prevents it from being stretched
	HICON hFont = (HICON)::LoadImage(AfxGetResourceHandle(), 
									 MAKEINTRESOURCE(IDI_FONT), 
									 IMAGE_ICON, 
									 0, 
									 0,
									 0); // use default size because width/height are also zero

	static_cast<CButton*>(GetDlgItem(IDC_SELECT_FONT))->SetIcon(hFont);

	HICON hInvert = (HICON)::LoadImage(AfxGetResourceHandle(), 
									   MAKEINTRESOURCE(IDI_INVERT), 
									   IMAGE_ICON, 
									   0, 
									   0,
									   0); // use default size because width/height are also zero

	static_cast<CButton*>(GetDlgItem(IDC_INVERT))->SetIcon(hInvert);

	HICON hPresets = (HICON)::LoadImage(AfxGetResourceHandle(), 
									    MAKEINTRESOURCE(IDI_PRESETS), 
										IMAGE_ICON, 
										0, 
										0,
										0); // use default size because width/height are also zero

	static_cast<CButton*>(GetDlgItem(IDC_PRESETS))->SetIcon(hPresets);


	UpdateData(FALSE);

	SetFormatFont();
	SetFormatAlignment();

	int iWAVersion = ::SendMessage(m_pwndQTitle->GetWinampHWND(), WM_WA_IPC, 0, IPC_GETVERSION);

	if(iWAVersion < 2.9)
	{
		m_oFormat.EnableWindow(FALSE);
		GetDlgItem(IDC_FORMAT_GROUP)->EnableWindow(FALSE);
	}


	OSVERSIONINFO os = { sizeof(os) };
	GetVersionEx(&os);

	BOOL bWin2K = (VER_PLATFORM_WIN32_NT == os.dwPlatformId && os.dwMajorVersion >= 5); 

	GetDlgItem(IDC_TRANSPARENCY_LABEL)->EnableWindow(bWin2K);
	m_sliderTransparency.EnableWindow(bWin2K);
	GetDlgItem(IDC_WIN2K_GROUP)->EnableWindow(bWin2K);

	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		m_tooltip.AddTool(GetDlgItem(IDC_FORMAT), IDS_FORMAT);
		m_tooltip.AddTool(GetDlgItem(IDC_HOTKEY), IDS_HOTKEY);
		m_tooltip.AddTool(GetDlgItem(IDC_ALIGN), IDS_ALIGN);
		m_tooltip.AddTool(GetDlgItem(IDC_TIMEOUT), IDS_TIMEOUT);
		m_tooltip.AddTool(GetDlgItem(IDC_ANCHOR), IDS_ANCHOR);
		m_tooltip.AddTool(GetDlgItem(IDC_TRACK_CHANGE), IDS_TRACK_CHANGE);
		m_tooltip.AddTool(GetDlgItem(IDC_LINES), IDS_LINES);
		m_tooltip.AddTool(GetDlgItem(IDC_FONT_COLOR), IDS_FOREGROUND);
		m_tooltip.AddTool(GetDlgItem(IDC_BACKGROUND_COLOR), IDS_BACKGROUND);
		m_tooltip.AddTool(GetDlgItem(IDC_PREVIEW), IDS_PREVIEW);
		m_tooltip.AddTool(GetDlgItem(IDC_PRESETS), IDS_PRESETS);
		m_tooltip.AddTool(GetDlgItem(IDC_INVERT), IDS_INVERT);
		m_tooltip.AddTool(GetDlgItem(IDC_SELECT_FONT), IDS_SELECT_FONT);
		m_tooltip.AddTool(GetDlgItem(IDC_TRANSPARENCY), IDS_TRANSPARENCY);
		m_tooltip.AddTool(GetDlgItem(IDC_OUTLINE), IDS_OUTLINE);

	}
	return TRUE;
}

//---------------------------------------------------------------------------
// OnFont
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnFont() 
{
	LOGFONT lf;
	CFont *pFont = GetFont();
	pFont->GetLogFont(&lf);

	lf.lfHeight = m_prefs.iFontSize;
	lf.lfWeight = m_prefs.iFontWeight;
	lf.lfItalic = m_prefs.bFontItalic;
	_tcscpy(lf.lfFaceName, m_prefs.szFontName);

	CQTitleFontDlg dlg(&lf);

	if (dlg.DoModal() == IDOK)
	{
		dlg.GetCurrentFont(&lf);

		m_prefs.iFontSize = lf.lfHeight;
		m_prefs.iFontWeight = lf.lfWeight;
		m_prefs.bFontItalic = lf.lfItalic;
		_tcscpy(m_prefs.szFontName, lf.lfFaceName);

		SetFormatFont();
	}
}

//---------------------------------------------------------------------------
// OnPresets
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnPresets() 
{
	CMenu oMenu;
	CRect rcCtrl;

	oMenu.LoadMenu(IDR_PRESETS);

	GetDlgItem(IDC_PRESETS)->GetWindowRect(rcCtrl);

	oMenu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, 
									    rcCtrl.left, 
										rcCtrl.bottom + 2, 
										this);
}


//---------------------------------------------------------------------------
// OnInvert
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnInvert() 
{
	COLORREF crFGColor = m_buttonForeground.GetColor();

	m_buttonBackground.SetColor(RGB(0xFF - GetRValue(crFGColor),
									0xFF - GetGValue(crFGColor),
									0xFF - GetBValue(crFGColor)));

	m_buttonBackground.InvalidateRect(NULL);
}

//---------------------------------------------------------------------------
// OnPreview
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnPreview() 
{
	UpdateData(TRUE);

	QTITLEPREFS prefs;

	GetPrefs(prefs);

	prefs.iTimeout		= 2000; // limit to 2 seconds
	prefs.wHotKeyMods	= 0;	// do not allow a hot key to be set
	prefs.wVirtualKey	= 0;

	m_pwndQTitle->SetPrefs(prefs);

	m_pwndQTitle->Display(TRUE);
}

//---------------------------------------------------------------------------
// OnAnchor
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnAnchor() 
{
	SetCapture();

	m_bDragAnchor = TRUE;

	m_oAnchor.SetIcon(m_hNoAnchor);

	CPoint pt;

	GetCursorPos(&pt);

	ScreenToClient(&pt);

	SetCursor(pt);
}


//---------------------------------------------------------------------------
// GetPrefs
//---------------------------------------------------------------------------
void
CQTitleConfigDlg::GetPrefs(QTITLEPREFS& prefs)
{
	memcpy(&prefs, &m_prefs, sizeof(QTITLEPREFS));

	// The RegisterHotKey modifiers are not in the same order as the CHotKeyCtrl's GetHotKey
	prefs.wHotKeyMods = (m_prefs.wHotKeyMods & HOTKEYF_ALT?		MOD_ALT:	 0) | 
						(m_prefs.wHotKeyMods & HOTKEYF_CONTROL? MOD_CONTROL: 0) |
						(m_prefs.wHotKeyMods & HOTKEYF_SHIFT?	MOD_SHIFT:	 0) |
						(m_prefs.wHotKeyMods & HOTKEYF_EXT?		MOD_WIN:	 0);
}

//---------------------------------------------------------------------------
// SetPrefs
//---------------------------------------------------------------------------
void
CQTitleConfigDlg::SetPrefs(QTITLEPREFS& prefs)
{
	memcpy(&m_prefs, &prefs, sizeof(QTITLEPREFS));

	// The RegisterHotKey modifiers are not in the same order as the CHotKeyCtrl's GetHotKey
	m_prefs.wHotKeyMods = (prefs.wHotKeyMods & MOD_ALT?		HOTKEYF_ALT:	 0) | 
						  (prefs.wHotKeyMods & MOD_CONTROL? HOTKEYF_CONTROL: 0) |
						  (prefs.wHotKeyMods & MOD_SHIFT?	HOTKEYF_SHIFT:	 0) |
						  (prefs.wHotKeyMods & MOD_WIN?		HOTKEYF_EXT:	 0);
}

//---------------------------------------------------------------------------
// OnLButtonUp
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnLButtonUp(UINT nFlags, CPoint pt) 
{
	if(m_bDragAnchor)
	{
		ReleaseCapture();

		m_bDragAnchor = FALSE;

		KillTimer(TIMERID_SHOWPREVIEW);

		OnPreview();

		m_oAnchor.SetIcon(m_hShowAnchor);
	}
	
	CDialog::OnLButtonUp(nFlags, pt);
}

//---------------------------------------------------------------------------
// OnMouseMove
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnMouseMove(UINT nFlags, CPoint pt) 
{
	if(m_bDragAnchor)
	{
		SetCursor(pt);

		KillTimer(TIMERID_SHOWPREVIEW);

		SetTimer(TIMERID_SHOWPREVIEW, 500, NULL);
	}
	
	CDialog::OnMouseMove(nFlags, pt);
}

//---------------------------------------------------------------------------
// SetCursor
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::SetCursor(CPoint &pt)
{
	CRect rcDesktop;

	GetDesktopWindow()->GetWindowRect(rcDesktop);

	ClientToScreen(&pt);

	m_prefs.pt = pt;

	int x = max(0, min(g_kix - 1, (pt.x / (rcDesktop.right  / g_kix))));
	int y = max(0, min(g_kiy - 1, (pt.y / (rcDesktop.bottom / g_kiy))));

	::SetCursor(m_hAnchor[g_aiAnchor[y][x]]);
}

//---------------------------------------------------------------------------
// OnAlignSelChange
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnAlignSelChange() 
{
	UpdateData(TRUE);

	SetFormatAlignment();
}

//---------------------------------------------------------------------------
// SetFormatFont
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::SetFormatFont() 
{
	m_oFormat.SetSel(0,-1);

	CHARFORMAT cf;

	cf.cbSize = sizeof(CHARFORMAT);
	cf.dwMask = CFM_FACE;
	_tcscpy(cf.szFaceName, m_prefs.szFontName);

	m_oFormat.SetDefaultCharFormat(cf);
	m_oFormat.SetSelectionCharFormat(cf);

	m_oFormat.SetSel(0,0);

	m_oFormat.Refresh();
}


//---------------------------------------------------------------------------
// SetFormatAlignment
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::SetFormatAlignment() 
{
	m_oFormat.SetSel(0,-1);

	PARAFORMAT pf;
	pf.cbSize = sizeof(PARAFORMAT);
	pf.dwMask = PFM_ALIGNMENT;
	switch(m_prefs.iAlign)
	{
		case DT_LEFT:
			pf.wAlignment = PFA_LEFT;
			break;
		case DT_CENTER:
			pf.wAlignment = PFA_CENTER;
			break;
		case DT_RIGHT:
			pf.wAlignment = PFA_RIGHT;
			break;
	}

	m_oFormat.SetParaFormat(pf);

	m_oFormat.SetSel(0,0);

	m_oFormat.Refresh();
}

//---------------------------------------------------------------------------
// OnSetPreset
//---------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnSetPreset(int iMenuID)
{
	CRect rcDesktop;

	GetDesktopWindow()->GetWindowRect(rcDesktop);

	switch(iMenuID)
	{
		case IDM_TOPLEFT:
			m_prefs.pt = CPoint(0,0);
			break;
		case IDM_TOP:
			m_prefs.pt = CPoint(rcDesktop.right / 2, 0);
			break;
		case IDM_TOPRIGHT:
			m_prefs.pt = CPoint(rcDesktop.right,0);
			break;
		case IDM_CENTER:
			m_prefs.pt = CPoint(rcDesktop.right / 2, rcDesktop.bottom / 2);
			break;
		case IDM_BOTTOMLEFT:
			m_prefs.pt = CPoint(0, rcDesktop.bottom);
			break;
		case IDM_BOTTOM:
			m_prefs.pt = CPoint(rcDesktop.right / 2, rcDesktop.bottom);
			break;
		case IDM_BOTTOMRIGHT:
			m_prefs.pt = CPoint(rcDesktop.right, rcDesktop.bottom);
			break;
	}

	OnPreview();
}

//-------------------------------------------------------------------------
// OnTimer
//-------------------------------------------------------------------------
void 
CQTitleConfigDlg::OnTimer(UINT nIDEvent) 
{
	KillTimer(TIMERID_SHOWPREVIEW);

	OnPreview();
}

//-------------------------------------------------------------------------
// PreTranslateMessage
//-------------------------------------------------------------------------
BOOL 
CQTitleConfigDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}
	return CDialog::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}
