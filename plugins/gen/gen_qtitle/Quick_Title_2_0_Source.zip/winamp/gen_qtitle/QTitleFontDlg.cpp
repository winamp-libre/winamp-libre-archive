//---------------------------------------------------------------------------
// Copyright 2004 James Starling
//---------------------------------------------------------------------------

#include "stdafx.h"
#include "gen_qtitle.h"
#include "QTitleFontDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CQTitleFontDlg, CFontDialog)

//---------------------------------------------------------------------------
// CQTitleFontDlg
//---------------------------------------------------------------------------
CQTitleFontDlg::CQTitleFontDlg(LPLOGFONT	lplfInitial, 
							   DWORD		dwFlags, 
							   CDC*			pdcPrinter, 
							   CWnd*		pParentWnd) : 
	CFontDialog(lplfInitial, dwFlags, pdcPrinter, pParentWnd)
{
   m_cf.hInstance		= AfxGetResourceHandle();
   m_cf.lpTemplateName	= MAKEINTRESOURCE(IDD_QTITLEFONT);
   m_cf.Flags			|= CF_ENABLETEMPLATE;
}


BEGIN_MESSAGE_MAP(CQTitleFontDlg, CFontDialog)
END_MESSAGE_MAP()

