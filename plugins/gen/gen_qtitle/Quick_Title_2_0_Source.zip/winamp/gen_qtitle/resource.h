//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gen_qtitle.rc
//
#define IDI_INFO                        129
#define IDC_CENTER                      130
#define IDC_TOPLEFT                     131
#define IDI_ANCHOR                      131
#define IDC_TOP                         132
#define IDI_NOANCHOR                    132
#define IDC_TOPRIGHT                    133
#define IDC_RIGHT                       134
#define IDC_BOTTOMRIGHT                 135
#define IDC_BOTTOM                      136
#define IDC_BOTTOMLEFT                  137
#define IDC_LEFT                        138
#define IDC_TIMEOUT                     2001
#define IDD_DIALOG1                     2002
#define IDC_CHECK_ENABLE                2002
#define IDD_QTITLECONFIG                2002
#define IDC_FONT_SIZE1                  2004
#define IDC_FONT_COLOR                  2005
#define IDC_FONT_NAME                   2006
#define IDD_QTITLEFONTDIALOG            2006
#define IDD_QTITLEFONT                  2006
#define IDC_TRANSPARENT                 2007
#define IDC_OUTLINE                     2007
#define IDC_BACKGROUND_COLOR            2008
#define IDC_CTRL                        2009
#define IDI_FONT                        2009
#define IDC_ALT                         2010
#define IDI_INVERT                      2010
#define IDC_WIN                         2011
#define IDR_PRESETS                     2011
#define IDI_PRESETS                     2011
#define IDC_HOTKEY                      2012
#define IDI_HELP                        2012
#define IDC_SHIFT                       2013
#define IDR_HELP_MENU                   2013
#define IDC_POSITION                    2014
#define IDC_TRACK_CHANGE                2015
#define IDS_TRACK_CHANGE                2015
#define IDC_RADIO1                      2016
#define IDC_WORD_WRAP                   2016
#define IDC_RADIO2                      2017
#define IDC_TRUNCATE                    2017
#define IDC_SELECT_FONT                 2019
#define IDC_PREVIEW                     2020
#define IDC_INVERT                      2021
#define IDC_PRESETS                     2022
#define IDC_LINES                       2026
#define IDC_ANCHOR                      2027
#define IDC_FORMAT                      2031
#define IDC_ALIGN                       2032
#define IDC_MAILTO                      2033
#define IDC_TRANSPARENCY                2034
#define IDC_TRANSPARENCY_LABEL          2036
#define IDC_WINXP_GROUP                 2037
#define IDC_FORMAT_GROUP                2039
#define IDC_WIN2K_GROUP                 2040
#define IDM_TOPLEFT                     32771
#define IDM_TOP                         32772
#define IDM_TOPRIGHT                    32773
#define ID_POPUP_HELP_PRINT             32773
#define IDM_CENTER                      32774
#define IDM_BOTTOMLEFT                  32775
#define IDM_BOTTOM                      32776
#define IDM_BOTTOMRIGHT                 32777
#define ID_FILE_KEEPHELPONTOP_ONTOP     32891
#define ID_FILE_KEEPHELPONTOP_NOTONTOP  32892
#define IDS_ANCHOR                      57345
#define IDS_HOTKEY                      57346
#define IDS_SELECT_FONT                 57347
#define IDS_FOREGROUND                  57348
#define IDS_BACKGROUND                  57349
#define IDS_LINES                       57350
#define IDS_ENABLE                      57351
#define IDS_PREVIEW                     57352
#define IDS_TIMEOUT                     57353
#define IDS_TRANSPARENT                 57354
#define IDS_OUTLINE                     57354
#define IDS_FORMAT                      57355
#define IDS_ALIGN                       57356
#define IDS_INVERT                      57357
#define IDS_TRANSPARENCY                57358
#define IDS_PRESETS                     57359

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2015
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         2041
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif
