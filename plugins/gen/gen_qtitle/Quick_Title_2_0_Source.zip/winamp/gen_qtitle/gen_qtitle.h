//---------------------------------------------------------------------------
// Copyright 2002-2004 James Starling
//---------------------------------------------------------------------------

#if !defined(AFX_GEN_QTITLE_H__77CCA245_3378_11D6_86F1_00E02910A56E__INCLUDED_)
#define AFX_GEN_QTITLE_H__77CCA245_3378_11D6_86F1_00E02910A56E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

enum EANCHOR
{
	ANCHOR_CENTER = 0,
	ANCHOR_TOPLEFT,
	ANCHOR_TOP,
	ANCHOR_TOPRIGHT,
	ANCHOR_RIGHT,
	ANCHOR_BOTTOMRIGHT,
	ANCHOR_BOTTOM,
	ANCHOR_BOTTOMLEFT,
	ANCHOR_LEFT
};

typedef struct tagQTitlePrefs
{
	BOOL		bEnabled;
	BOOL		bOutline;
	int			iTimeout;
	TCHAR		szFontName[64];
	int			iFontSize;
	int			iAlign;
	BOOL		bFontItalic;
	int			iFontWeight;
	COLORREF	rFGColor;
	COLORREF	rBGColor;
	WORD		wHotKeyMods;
	WORD		wVirtualKey;
	int			iCountdown;
	BOOL		bTransitions;
	BOOL		bSingleLine;
	POINT		pt;
	TCHAR		szFormat[256];
	BYTE		byAlpha;
} QTITLEPREFS;

const int g_kix = 3;
const int g_kiy = 3;

const int g_aiAnchor[g_kix][g_kiy] = {	{ANCHOR_TOPLEFT,	ANCHOR_TOP,		ANCHOR_TOPRIGHT},
										{ANCHOR_LEFT,		ANCHOR_CENTER,	ANCHOR_RIGHT},
										{ANCHOR_BOTTOMLEFT,	ANCHOR_BOTTOM,	ANCHOR_BOTTOMRIGHT}};

class CQTitleWnd;

class CGen_qtitleApp : public CWinApp
{
public:
	CGen_qtitleApp();
	virtual ~CGen_qtitleApp();

	static void		Quit();
	static void		Config();
	static int		Init();

	void			UpdateQTitleWnd(HWND hwnd, BOOL bForceDisplay);

	DECLARE_MESSAGE_MAP()

protected:
	void			CleanUp();
	void			Configuration();
	int				Initialize();

private:
	CQTitleWnd*		m_pwndQTitle;
};

#endif // !defined(AFX_GEN_QTITLE_H__77CCA245_3378_11D6_86F1_00E02910A56E__INCLUDED_)
