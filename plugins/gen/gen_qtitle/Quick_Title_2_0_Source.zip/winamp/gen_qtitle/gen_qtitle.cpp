//---------------------------------------------------------------------------
// Copyright 2002-2004 James Starling
//---------------------------------------------------------------------------

#include "stdafx.h"
#include "gen_qtitle.h"
#include "QTitleConfigDlg.h"

#include "../gen.h"
#include "../wa_ipc.h"

#include "QTitleWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const TCHAR g_kszTimeout[]			= _T("Timeout");
const TCHAR g_kszEnabled[]			= _T("Enabled");
const TCHAR g_kszWindowPosition[]	= _T("WindowPosition");
const TCHAR g_kszTransitions[]		= _T("Transitions");
									
const TCHAR g_kszFontName[]			= _T("FontName");
const TCHAR g_kszFontSize[]			= _T("FontSize");
const TCHAR g_kszFontWeight[]		= _T("FontWeight");
const TCHAR g_kszFontItalic[]		= _T("FontItalic");
const TCHAR g_kszAlign[]			= _T("Align");
									
const TCHAR g_kszFGColor[]			= _T("FGColor");
const TCHAR g_kszBGColor[]			= _T("BGColor");
const TCHAR g_kszOutline[]			= _T("Transparent");
									
const TCHAR g_kszHotKey[]			= _T("HotKey");
const TCHAR g_kszHotKeyMods[]		= _T("HotKeyMods");

const TCHAR g_kszWordWrap[]			= _T("WordWrap");

const TCHAR g_kszAnchorX[]			= _T("AnchorX");
const TCHAR g_kszAnchorY[]			= _T("AnchorY");

const TCHAR g_kszFormat[]			= _T("Format");
const TCHAR g_kszAlpha[]			= _T("Alpha");

CGen_qtitleApp	theApp;
WNDPROC			lpfnOldWndProc = NULL;

// Global plug-in information
winampGeneralPurposePlugin plugin = {GPPHDR_VER, // version of gen.h header
									 "",
									 CGen_qtitleApp::Init,
									 CGen_qtitleApp::Config,
									 CGen_qtitleApp::Quit,};


BEGIN_MESSAGE_MAP(CGen_qtitleApp, CWinApp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGen_qtitleApp construction

//-------------------------------------------------------------------------
// CGen_qtitleApp
//-------------------------------------------------------------------------
CGen_qtitleApp::CGen_qtitleApp() :
	m_pwndQTitle(NULL)
{
	AfxInitRichEdit();
}

//-------------------------------------------------------------------------
// ~CGen_qtitleApp
//-------------------------------------------------------------------------
CGen_qtitleApp::~CGen_qtitleApp()
{
}


//-------------------------------------------------------------------------
// WndProc
//
// Allows this plug-in to intercept Winamp message
//-------------------------------------------------------------------------
LRESULT CALLBACK 
WndProc(HWND hwnd, UINT uiMessage, WPARAM wParam, LPARAM lParam)
{
	switch(uiMessage)
	{
		case WM_SETTEXT:
			theApp.UpdateQTitleWnd(hwnd, FALSE);
			break;
		case WM_KEYUP:
			switch(wParam)
			{
				case _T('Z'):
				case _T('X'):
				case _T('C'):
				case _T('B'):
				{
					theApp.UpdateQTitleWnd(hwnd, TRUE);
					break;
				}
			}
			break;
		case WM_COMMAND:
		{
			switch(wParam)
			{
				case WINAMP_BUTTON1:
				case WINAMP_BUTTON2:
				case WINAMP_BUTTON3:
				case WINAMP_BUTTON5:
				{
					theApp.UpdateQTitleWnd(hwnd, TRUE);
					break;
				}
			}
			break;
		}
	}

	// Forward the message onto Winamp
	return CallWindowProc(lpfnOldWndProc, hwnd, uiMessage, wParam, lParam);
}

//-------------------------------------------------------------------------
// winampGetGeneralPurposePlugin
//
// Returns the pointer to the entry point functions to WinAmp
//-------------------------------------------------------------------------
winampGeneralPurposePlugin*
winampGetGeneralPurposePlugin()
{
	return &plugin;
}

//-------------------------------------------------------------------------
// Init
//-------------------------------------------------------------------------
int 
CGen_qtitleApp::Init()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return(theApp.Initialize());
}

//-------------------------------------------------------------------------
// Quit
//-------------------------------------------------------------------------
void
CGen_qtitleApp::Quit()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	theApp.CleanUp();
}

//-------------------------------------------------------------------------
// Config
//-------------------------------------------------------------------------
void
CGen_qtitleApp::Config()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	theApp.Configuration();
}


//-------------------------------------------------------------------------
// Initialize
//-------------------------------------------------------------------------
int 
CGen_qtitleApp::Initialize()
{
	static char szDescription[512];
	char		szFileName[512];


	GetModuleFileName(plugin.hDllInstance, szFileName, sizeof(szFileName));

	wsprintf(szDescription,
			 "Winamp Quick Title v2.0 (%s)",
			 strrchr(szFileName, '\\') + 1);

	plugin.description = szDescription;

	lpfnOldWndProc = (WNDPROC)GetWindowLong(plugin.hwndParent, GWL_WNDPROC);

	SetWindowLong(plugin.hwndParent, GWL_WNDPROC, reinterpret_cast<DWORD>(WndProc));

	SetRegistryKey(_T("Winamp"));

	m_pwndQTitle = new CQTitleWnd;

	if(m_pwndQTitle)
	{
		if(m_pwndQTitle->Create(plugin.hwndParent))
		{
			QTITLEPREFS prefs;

			m_pwndQTitle->GetPrefs(prefs);

			_tcscpy(prefs.szFontName, GetProfileString(_T(""), g_kszFontName, prefs.szFontName)); 
			_tcscpy(prefs.szFormat,   GetProfileString(_T(""), g_kszFormat,   prefs.szFormat)); 

			prefs.iTimeout		= GetProfileInt(_T(""), g_kszTimeout,			prefs.iTimeout);
			prefs.bEnabled		= GetProfileInt(_T(""), g_kszEnabled,			prefs.bEnabled);
			prefs.bTransitions	= GetProfileInt(_T(""), g_kszTransitions,		prefs.bTransitions);
			prefs.iFontSize		= GetProfileInt(_T(""), g_kszFontSize,			prefs.iFontSize);
			prefs.bFontItalic	= GetProfileInt(_T(""), g_kszFontItalic,		prefs.bFontItalic);
			prefs.iFontWeight	= GetProfileInt(_T(""), g_kszFontWeight,		prefs.iFontWeight);
			prefs.iAlign		= GetProfileInt(_T(""), g_kszAlign,				prefs.iAlign);
			prefs.rFGColor		= GetProfileInt(_T(""), g_kszFGColor,			prefs.rFGColor);
			prefs.rBGColor		= GetProfileInt(_T(""), g_kszBGColor,			prefs.rBGColor);
			prefs.bOutline		= GetProfileInt(_T(""), g_kszOutline,		prefs.bOutline);
			prefs.wVirtualKey	= GetProfileInt(_T(""), g_kszHotKey,			prefs.wVirtualKey);
			prefs.wHotKeyMods	= GetProfileInt(_T(""), g_kszHotKeyMods,		prefs.wHotKeyMods);
			prefs.bSingleLine	= GetProfileInt(_T(""), g_kszWordWrap,			prefs.bSingleLine);
			prefs.pt.x			= GetProfileInt(_T(""), g_kszAnchorX,			prefs.pt.x);
			prefs.pt.y			= GetProfileInt(_T(""), g_kszAnchorY,			prefs.pt.y);
			prefs.byAlpha		= GetProfileInt(_T(""), g_kszAlpha,				prefs.byAlpha);

			m_pwndQTitle->SetPrefs(prefs);
		}
	}

	return(0);
}

//-------------------------------------------------------------------------
// Configuration
//-------------------------------------------------------------------------
void 
CGen_qtitleApp::Configuration()
{
	if(m_pwndQTitle)
	{
		CQTitleConfigDlg oDlg(m_pwndQTitle);

		QTITLEPREFS prefs;
		m_pwndQTitle->GetPrefs(prefs);
		oDlg.SetPrefs(prefs);

		if(IDOK == oDlg.DoModal())
		{
			oDlg.GetPrefs(prefs);
		}

		// Always call this method so that the hot key is reset
		m_pwndQTitle->SetPrefs(prefs);
	}
}

//-------------------------------------------------------------------------
// CleanUp
//-------------------------------------------------------------------------
void 
CGen_qtitleApp::CleanUp()
{
	if(m_pwndQTitle)
	{
		QTITLEPREFS prefs;
		m_pwndQTitle->GetPrefs(prefs);

		WriteProfileString(_T(""), g_kszFontName, prefs.szFontName);
		WriteProfileString(_T(""), g_kszFormat,   prefs.szFormat);

		WriteProfileInt(_T(""), g_kszTimeout,			prefs.iTimeout);
		WriteProfileInt(_T(""), g_kszEnabled,			prefs.bEnabled);
		WriteProfileInt(_T(""), g_kszTransitions,		prefs.bTransitions);
		WriteProfileInt(_T(""), g_kszOutline,			prefs.bOutline);
		WriteProfileInt(_T(""), g_kszFontSize,			prefs.iFontSize);
		WriteProfileInt(_T(""), g_kszFontWeight,		prefs.iFontWeight);
		WriteProfileInt(_T(""), g_kszAlign,				prefs.iAlign);
		WriteProfileInt(_T(""), g_kszFontItalic,		prefs.bFontItalic);
		WriteProfileInt(_T(""), g_kszFGColor,			prefs.rFGColor);
		WriteProfileInt(_T(""), g_kszBGColor,			prefs.rBGColor);
		WriteProfileInt(_T(""), g_kszHotKey,			prefs.wVirtualKey);
		WriteProfileInt(_T(""), g_kszHotKeyMods,		prefs.wHotKeyMods);
		WriteProfileInt(_T(""), g_kszWordWrap,			prefs.bSingleLine);
		WriteProfileInt(_T(""), g_kszAnchorX,			prefs.pt.x);
		WriteProfileInt(_T(""), g_kszAnchorY,			prefs.pt.y);
		WriteProfileInt(_T(""), g_kszAlpha,				prefs.byAlpha);

		if(m_pwndQTitle->m_hWnd)
		{
			m_pwndQTitle->DestroyWindow();
		}

	}
}

//-------------------------------------------------------------------------
// UpdateQTitleWnd
//-------------------------------------------------------------------------
void 
CGen_qtitleApp::UpdateQTitleWnd(HWND hwnd, BOOL bForceDisplay)
{
	if(m_pwndQTitle && m_pwndQTitle->IsTransitions())
	{
		PostMessage(m_pwndQTitle->m_hWnd, WMU_UPDATE_TEXT, (BOOL)bForceDisplay, 0);
	}
}
