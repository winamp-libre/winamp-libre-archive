// gen_scripting.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"
#include "frontend.h"
#include "GEN.h"
#include "Global.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{D73AE023-B11E-446D-BD5B-6F565AFBB62D}", 
		 name = "gen_scripting", 
		 helpstring = "gen_scripting 1.0 Type Library",
		 resource_name = "IDR_GEN_SCRIPTING") ];

// WinAmp GEN plug-in stuff

int waInit();
void waConfig();
void waQuit();
LRESULT CALLBACK waWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

std::basic_string<TCHAR> g_strVersion;
std::basic_string<TCHAR> g_strFilename;
std::basic_string<TCHAR> g_strPluginDescription;

HWND g_hwndGenScripting = NULL;

winampGeneralPurposePlugin g_waGenPlugin =
{
	GPPHDR_VER,
	"",
	waInit,
	waConfig,
	waQuit,
	NULL,
	NULL
};

// Generic function

void getFileVersionAndName()
{
	g_strVersion = "<unknown>";
	g_strFilename = "<unknown>";

	TCHAR szModName[_MAX_PATH + 1];
	DWORD dwVerSize;
	DWORD dwUnused;

	if (GetModuleFileName(g_waGenPlugin.hDllInstance, szModName, _MAX_PATH))
	{
		TCHAR *szFilename = szModName + _tcslen(szModName); // point at the null terminator.

		while (szFilename >= szModName && *szFilename != '\\' && *szFilename != '/')
		{
			szFilename--;
		}

		g_strFilename = (szFilename + 1);

		if (0 != (dwVerSize = GetFileVersionInfoSize(szModName, &dwUnused)))
		{
			BYTE *pVerData = new BYTE[dwVerSize];

			if (GetFileVersionInfo(szModName, NULL, dwVerSize, pVerData))
			{
				LPVOID pBuffer;
				UINT bufLen;

				if(VerQueryValue(pVerData, _T("\\VarFileInfo\\Translation"), &pBuffer, &bufLen))
				{
					// Find out language of version resource
					BYTE* lang = (BYTE*)pBuffer;

					TCHAR *resblk = LeoDavidsonUtils::StringAllocAndFormat(_T("\\StringFileInfo\\%02x%02x%02x%02x\\FileVersion"), lang[1], lang[0], lang[3], lang[2]);

					if (VerQueryValue(pVerData, resblk, &pBuffer, &bufLen))
					{
						g_strVersion = reinterpret_cast<TCHAR*>(pBuffer);
					}

					delete [] resblk;
				}
			}

			delete [] pVerData;
		}
	}
}

int waInit()
{
	if (NULL == g_hwndGenScripting)
	{
		// get version and generate description string

		getFileVersionAndName();

		TCHAR *szDescription = LeoDavidsonUtils::StringAllocAndFormat(_T("Scripting Support v%s (%s)"),
			g_strVersion.c_str(), g_strFilename.c_str());

		g_strPluginDescription = szDescription;
		delete [] szDescription;

		g_waGenPlugin.description = const_cast<char *>(g_strPluginDescription.c_str());

		// register & create our hidden window for inter-process messaging

		WNDCLASSEX wcex;
		ZeroMemory(&wcex, sizeof(wcex));
		wcex.cbSize			= sizeof(wcex);
		wcex.style			= 0;
		wcex.lpfnWndProc	= reinterpret_cast<WNDPROC>(waWndProc);
		wcex.cbClsExtra		= 0;
		wcex.cbWndExtra		= 0;
		wcex.hInstance		= g_waGenPlugin.hDllInstance;
		wcex.hIcon			= NULL;
		wcex.hCursor		= NULL;
		wcex.hbrBackground	= NULL;
		wcex.lpszMenuName	= NULL;
		wcex.lpszClassName	= szwaGenScriptingWindowClass;
		wcex.hIconSm		= NULL;

		if (0 != RegisterClassEx(&wcex))
		{
			g_hwndGenScripting = CreateWindow(szwaGenScriptingWindowClass,
											  g_strPluginDescription.c_str(),
											  WS_OVERLAPPEDWINDOW, CW_USEDEFAULT,
											  0, 100, 100, NULL, NULL,
											  g_waGenPlugin.hDllInstance, NULL);
		}
	}

	return(0);
}

void waQuit()
{
	if (NULL != g_hwndGenScripting)
	{
		DestroyWindow(g_hwndGenScripting);
		g_hwndGenScripting = NULL;
	}
}

void waConfig()
{
	MessageBox(g_waGenPlugin.hwndParent,
				"Active Scripting Support Plug-in for Winamp\nby Leo 'Nudel' Davidson\n\n"
				"Allows you to query and control Winamp from Active Scripting languages such as VBScript, JScript and Perl.\n\n"
				"Updates and C++ source-code available online at http://www.TheHeartOfTheCorporateBeast.com\n",
				g_waGenPlugin.description,
				MB_OK|MB_TOPMOST);
}

extern "C" __declspec( dllexport ) winampGeneralPurposePlugin *winampGetGeneralPurposePlugin()
{
	return(&g_waGenPlugin);
}

// WindProc which does the WinAmp-side work of this DLL.

LRESULT wawpCDReplySendMessageString(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam, HWND hwndReply)
{
	LRESULT smRes = SendMessage(g_waGenPlugin.hwndParent, message, wParam, lParam);

	if (NULL == smRes)
	{
		ReplyMessage(0);
	}
	else
	{
		ReplyMessage(1);

		COPYDATASTRUCT cds;
		ZeroMemory(&cds, sizeof(cds));
		cds.dwData = 0;
		cds.lpData = reinterpret_cast<void *>(smRes);
		cds.cbData = strlen(reinterpret_cast<char *>(smRes)) + 1;

		SendMessage(hwndReply, WM_COPYDATA, 0, reinterpret_cast<LPARAM>(&cds));
	}
	return(0);
}

LRESULT CALLBACK waWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case(WM_COPYDATA):
	case(WM_COMMAND):
	case(WM_USER): // the same as WM_WA_IPC
		// Pass these and their replies straight on.
		return(SendMessage(g_waGenPlugin.hwndParent, message, wParam, lParam));
		break;
	case(WM_USER+1): // IPC_GETPLAYLISTFILE  and string reply needs sending back
		return(wawpCDReplySendMessageString(hWnd, WM_USER, wParam, IPC_GETPLAYLISTFILE, reinterpret_cast<HWND>(lParam)));
		break;
	case(WM_USER+2): // IPC_GETPLAYLISTTITLE and string reply needs sending back
		return(wawpCDReplySendMessageString(hWnd, WM_USER, wParam, IPC_GETPLAYLISTTITLE, reinterpret_cast<HWND>(lParam)));
		break;
	default:
		return(DefWindowProc(hWnd, message, wParam, lParam));
	}

	return 0;
}
