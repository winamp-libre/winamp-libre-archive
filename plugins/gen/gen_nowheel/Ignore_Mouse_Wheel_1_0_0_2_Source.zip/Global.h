#ifndef __GLOBAL_H_
#define __GLOBAL_H_

// -- definitions --

// Default size for fixed-size buffers
#define BUFFERSIZE 4096

// -- utility functions --

namespace LeoDavidsonUtils
{
	// delete[] the result.
	// Returns NULL on failure.
	TCHAR *StringAllocAndFormat(const TCHAR *format, ...);

	// delete[] the result.
	// Returns NULL on failure.
	TCHAR *VStringAllocAndFormat(const TCHAR *format, va_list args);
};

#endif
