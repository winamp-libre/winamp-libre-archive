// gen_nowheel.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "GEN.h"
#include "Global.h"
#include <Zmouse.h>

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

// WinAmp GEN plug-in stuff

int waInit();
void waConfig();
void waQuit();
LRESULT CALLBACK waWndProcMain(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK waWndProcPlaylist(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
bool swallowWheelMessage(LRESULT *pLResult, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

std::basic_string<TCHAR> g_strVersion;
std::basic_string<TCHAR> g_strFilename;
std::basic_string<TCHAR> g_strPluginDescription;

LONG_PTR g_pOldWProcMain = NULL;
LONG_PTR g_pOldWProcPlaylist = NULL;

HWND g_hwndPlaylist = NULL;

UINT g_wm_mousewheel_win95 = 0;

winampGeneralPurposePlugin g_waGenPlugin =
{
	GPPHDR_VER,
	"",
	waInit,
	waConfig,
	waQuit,
	NULL,
	NULL
};

// Generic function

void getFileVersionAndName()
{
	g_strVersion = "<unknown>";
	g_strFilename = "<unknown>";

	TCHAR szModName[_MAX_PATH + 1];
	DWORD dwVerSize;
	DWORD dwUnused;

	if (GetModuleFileName(g_waGenPlugin.hDllInstance, szModName, _MAX_PATH))
	{
		TCHAR *szFilename = szModName + _tcslen(szModName); // point at the null terminator.

		while (szFilename >= szModName && *szFilename != '\\' && *szFilename != '/')
		{
			szFilename--;
		}

		g_strFilename = (szFilename + 1);

		if (0 != (dwVerSize = GetFileVersionInfoSize(szModName, &dwUnused)))
		{
			BYTE *pVerData = new BYTE[dwVerSize];

			if (GetFileVersionInfo(szModName, NULL, dwVerSize, pVerData))
			{
				LPVOID pBuffer;
				UINT bufLen;

				if(VerQueryValue(pVerData, _T("\\VarFileInfo\\Translation"), &pBuffer, &bufLen))
				{
					// Find out language of version resource
					BYTE* lang = (BYTE*)pBuffer;

					TCHAR *resblk = LeoDavidsonUtils::StringAllocAndFormat(_T("\\StringFileInfo\\%02x%02x%02x%02x\\FileVersion"), lang[1], lang[0], lang[3], lang[2]);

					int v0,v1,v2,v3;

					if (VerQueryValue(pVerData, resblk, &pBuffer, &bufLen)
					&&	4 == _stscanf(reinterpret_cast<TCHAR *>(pBuffer), _T("%d, %d, %d, %d"), &v0, &v1, &v2, &v3))
					{
						TCHAR *szVers = LeoDavidsonUtils::StringAllocAndFormat(_T("%d.%d.%d.%d"), v0, v1, v2, v3);

						g_strVersion = szVers;

						delete [] szVers;
					}

					delete [] resblk;
				}
			}

			delete [] pVerData;
		}
	}
}

int waInit()
{
	// get version and generate description string

	getFileVersionAndName();

	TCHAR *szDescription = LeoDavidsonUtils::StringAllocAndFormat(_T("Ignore Mouse Wheel v%s [%s]"),
		g_strVersion.c_str(), g_strFilename.c_str());

	g_strPluginDescription = szDescription;
	delete [] szDescription;

	g_waGenPlugin.description = const_cast<char *>(g_strPluginDescription.c_str());

	// Lookup the mouse message if we're on Windows 95.

	OSVERSIONINFO osVers;
	ZeroMemory(&osVers, sizeof(osVers));
	osVers.dwOSVersionInfoSize = sizeof(osVers);

	if (0 == GetVersionEx(&osVers)
	||	VER_PLATFORM_WIN32_WINDOWS != osVers.dwPlatformId
	||	4 != osVers.dwMajorVersion
	||  0 != osVers.dwMinorVersion)
	{
		// Not running on Win95. Don't waste the message number.
		g_wm_mousewheel_win95 = 0;
	}
	else
	{
		// Running on Win95 (sheesh!). Register the message.
		g_wm_mousewheel_win95 = RegisterWindowMessage(MSH_MOUSEWHEEL);
	}

	// subclass Winamp's main window and its playlist window

	if (NULL != g_waGenPlugin.hwndParent)
	{
		g_pOldWProcMain = SetWindowLongPtr(g_waGenPlugin.hwndParent, GWLP_WNDPROC,
											reinterpret_cast<LONG_PTR>(waWndProcMain));
	}

	g_hwndPlaylist = FindWindow("Winamp PE", NULL);

	if (NULL != g_hwndPlaylist)
	{
		g_pOldWProcPlaylist = SetWindowLongPtr(g_hwndPlaylist, GWLP_WNDPROC,
											reinterpret_cast<LONG_PTR>(waWndProcPlaylist));
	}

	return(0);
}

void waQuit()
{
	if (NULL != g_pOldWProcPlaylist && IsWindow(g_hwndPlaylist))
	{
		SetWindowLongPtr(g_hwndPlaylist, GWLP_WNDPROC, g_pOldWProcPlaylist);
	}

	if (NULL != g_pOldWProcMain)
	{
		SetWindowLongPtr(g_waGenPlugin.hwndParent, GWLP_WNDPROC, g_pOldWProcMain);
	}
}

void waConfig()
{
	MessageBox(g_waGenPlugin.hwndParent,
				"Plugin for Winamp2 which makes it ignore the mouse wheel when in small mode\nby Leo 'Nudel' Davidson\n\n"
				"I got sick of accidentally skipping tracks because Winamp got the focus and I moved the mouse wheel.\n\n"
				"Updates and C++ source-code available online at http://www.TheHeartOfTheCorporateBeast.com\n",
				g_waGenPlugin.description,
				MB_OK|MB_TOPMOST);
}

extern "C" __declspec( dllexport ) winampGeneralPurposePlugin *winampGetGeneralPurposePlugin()
{
	return(&g_waGenPlugin);
}

LRESULT CALLBACK waWndProcMain(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT lResult = 0;

	if (swallowWheelMessage(&lResult, hWnd, message, wParam, lParam))
	{
		return(lResult);
	}
	else if (NULL != g_pOldWProcMain)
	{
		return(CallWindowProc(reinterpret_cast<WNDPROC>(g_pOldWProcMain),
								hWnd, message, wParam, lParam));
	}
	else
	{
		return(0);
	}
}

LRESULT CALLBACK waWndProcPlaylist(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT lResult = 0;

	if (swallowWheelMessage(&lResult, hWnd, message, wParam, lParam))
	{
		return(lResult);
	}
	else if (NULL != g_pOldWProcMain)
	{
		return(CallWindowProc(reinterpret_cast<WNDPROC>(g_pOldWProcPlaylist),
								hWnd, message, wParam, lParam));
	}
	else
	{
		return(0);
	}
}

bool swallowWheelMessage(LRESULT *pLResult, HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	bool bResult = false;

	if (WM_MOUSEWHEEL == message
	||	(0 != g_wm_mousewheel_win95 && g_wm_mousewheel_win95 == message))
	{
		RECT rectClient;

		if (GetClientRect(hWnd, &rectClient) && 116 > (rectClient.bottom - rectClient.top))
		{
			MessageBeep(MB_ICONEXCLAMATION);
			bResult = true;
			*pLResult = (WM_MOUSEWHEEL == message ? 0 : TRUE);
		}
	}

	return(bResult);
}
