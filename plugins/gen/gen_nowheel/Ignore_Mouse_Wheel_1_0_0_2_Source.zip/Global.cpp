#include "stdafx.h"
#include "Global.h"

// -- definitions --

// -- utility functions --

// delete[] the result.
// Returns NULL on failure.
TCHAR *LeoDavidsonUtils::StringAllocAndFormat(const TCHAR *format, ...)
{
	va_list args;
	va_start(args, format);
	TCHAR *result = VStringAllocAndFormat(format, args);
	va_end(args);

	return(result);
}

// delete[] the result.
// Returns NULL on failure.
TCHAR *LeoDavidsonUtils::VStringAllocAndFormat(const TCHAR *format, va_list args)
{
	size_t bufferSize = BUFFERSIZE;

	TCHAR *szResult = new TCHAR[bufferSize];

	while(true)
	{
		int formatRes = _vsntprintf(szResult, bufferSize, format, args);

		// formatRes negative on error; (bufferSize == formatRes) should be redundant for _vsntprintf.

		if ((0 > formatRes) || (bufferSize == formatRes))
		{
			delete [] szResult;
			bufferSize *= 2;
			szResult = new TCHAR[bufferSize];
		}
		else
		{
			break;
		}
	}

	return(szResult);
}
