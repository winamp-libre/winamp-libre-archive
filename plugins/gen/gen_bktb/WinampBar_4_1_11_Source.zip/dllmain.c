/******************************************************************************

  $Id: dllmain.c,v 1.9 2001/02/14 20:37:32 Gavin_Smyth Exp $

  Winamp title bar controller

  DLL startup function

  Copyright 1999-2001 Gavin Smyth
  http://www.beesknees.freeserve.co.uk/software/

******************************************************************************/

#include "common.h"
#include "resource.h"

#include "registry.inl"
#include "list.inl"
#include "funcs.inl"
#include "bar.inl"
#include "winampif.inl"

/* Remove whinges about unused variable "reserved" */
#pragma warning( push )
#pragma warning( disable : 4100 )

BOOL WINAPI DllMain( HINSTANCE hinst, DWORD reason, LPVOID reserved )
{
  if( reason == DLL_PROCESS_ATTACH )
  {
    NONCLIENTMETRICS metrics;

    LOG(( "DLL loading" ));

    /* Save a little bit of time by getting rid of thread notifications since
       I don't need them */
    DisableThreadLibraryCalls( hinst );

    DllInstance = hinst;

    Heap = GetProcessHeap();
    if( !Heap )
      return FALSE;

    metrics.cbSize = sizeof( metrics );
    if( SystemParametersInfo( SPI_GETNONCLIENTMETRICS, 0, &metrics, FALSE ) )
      CaptionFont = CreateFontIndirect( &metrics.lfCaptionFont );
    if( !CaptionFont )
      return FALSE;

    InitializeCriticalSection( &WindowList.mutex );

    ButtonPressed = -1;
  }
  else if( reason == DLL_PROCESS_DETACH )
  {
    LIST_ITEM* p;

    LOG(( "DLL unloading" ));

    for( p = WindowList.head; p; p = p->next )
    {
      LOG(( "Resetting %08X (%d)", p, p->hwnd ));
      if( IsSubclassed( p->hwnd ) )
      {
        p->setWindowLong( p->hwnd, GWL_WNDPROC, (LONG)p->proc );
        Repaint( p->hwnd ); /* Just to be sure the buttons are gone */
      }
    }

    if( BackBuffer )
      DeleteObject( BackBuffer );

    ReleaseList();
    DeleteCriticalSection( &WindowList.mutex );

    DeleteObject( ButtonImages );

    DeleteObject( CaptionFont );
  }

  return TRUE;
}

#pragma warning( pop )

/*****************************************************************************/
