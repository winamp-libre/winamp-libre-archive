/******************************************************************************

  $Id: common.h,v 1.14 2001/04/08 15:57:46 Gavin_Smyth Exp $

  Common file - exists mainly to facilitate precompiled headers

  Needs to be #included first in any source file, and the project set up
  to use this for precompiler headers

                      Copyright 1999-2001 Gavin Smyth
                 http://www.beesknees.freeserve.co.uk

******************************************************************************/

#ifndef _h_common_h_
#define _h_common_h_

/* Rely on some W98+ features */
#define WINVER 0x0500

#define STRICT
#define WINDOWS_LEAN_AND_MEAN
/* Warning 4115 appears in rpcasync.h, dragged in by windows.h */
#pragma warning( disable : 4115 )
#include <windows.h>
#include <windowsx.h>
#include <tchar.h>
/* Warning 4201 appears in commctrl.h */
#pragma warning( disable : 4201 )
#include <commctrl.h>

#ifdef WINAMPBAR_EXPORTS
# define EXPORT __declspec( dllexport )
#else
# define EXPORT __declspec( dllimport )
#endif

/* Not interested in inlining messages */
#pragma warning( disable: 4711 )

/******************************************************************************

  Logging interface

******************************************************************************/

#ifdef _DEBUG
  void __cdecl Log( const char* format, ... );
# define LOG( args ) Log args
#else
# define LOG( args ) 0 /* Nothing */
#endif

/* Window list maintenance */

typedef WINUSERAPI LRESULT (WINAPI *CALL_WINDOW_PROC)( WNDPROC, HWND, UINT, WPARAM, LPARAM );
typedef WINUSERAPI LRESULT (WINAPI *SET_WINDOW_LONG)( HWND, INT, LONG );

typedef struct LIST_ITEM
{
  struct LIST_ITEM* next;           /* List maintenance */
  HWND              hwnd;           /* Window this refers to */
  WNDPROC           proc;           /* That window's original procedure */
  CALL_WINDOW_PROC  callWindowProc; /* Narrow or wide CallWindowProc */
  SET_WINDOW_LONG   setWindowLong;  /* Narrow or wide SetWindowLong */
} LIST_ITEM;

/* Choose a size to make memory management relatively efficient - grab a page
   subtract a (conservative) bit for the header, and divvy up the remainder,
   letting C round down of course */

#define ITEMS_PER_BLOCK ( ( 4096 - 64 ) / sizeof( LIST_ITEM ) )

typedef struct LIST_BLOCK
{
  struct LIST_BLOCK* next;          /* List maintenance */
  LIST_ITEM          items[ ITEMS_PER_BLOCK ];
} LIST_BLOCK;

typedef struct
{
  LIST_ITEM*       head;            /* Active window list */
  LIST_ITEM*       cache;           /* Unused list items */
  LIST_BLOCK*      bhead;           /* Allocated memory blocks */
  CRITICAL_SECTION mutex;           /* Protect access to the above */
} LIST;

/******************************************************************************

  The next bunch of variables are shared between _all_ processes using this
  DLL. OK, global variables aren't "good" but I want this to be small and
  fast.

******************************************************************************/

#define BUTTON_HEIGHT 12
#define BUTTON_WIDTH 12
#define NUM_BUTTONS 16

typedef struct
{
  TCHAR title[ 256 ];   /* Name of the song */
  UINT  chars;          /* Length in characters */
  LONG  pixels;         /* Width in pixels */
} TITLE;

typedef enum { TIME_NONE, TIME_ELAPSED, TIME_REMAINING, TIME_CLOCK } TIME_DISPLAY;

typedef struct
{
  void (*proc)( WPARAM );  /* Function to execute for this button */
  WPARAM arg;              /* Argument to pass to it */
  const TCHAR* name;       /* String identifying the button */
} BUTTON_DETAILS;

extern HWND  WinampWindow;           /* Window to which to direct Winamp control messages */
extern HWND  MostRecentWindow;       /* Last activated window */
extern HWND  PrevRecentWindow;       /* The one prior to that */
extern TITLE Song[ 2 ];              /* Title of the currently playing and "next" song */
extern UINT  WhichSong;              /* Which of the above is current */
extern BOOL  DisplayTitle;           /* Enable display of song title */
extern BOOL  StripSuffix;            /* Strip file suffix from title or not */
extern TIME_DISPLAY DisplayTime;     /* Whether to display track time or not */
extern UINT  NumButtons;             /* Number of enabled buttons */
extern BYTE  Buttons[ NUM_BUTTONS ]; /* Indexes to the enabled buttons */
extern BYTE  PresetVolume;           /* Volume to set to */
extern UINT  Offset;                 /* Space to add in between buttons */
extern COLORREF Colour;              /* Colour in which to display text */
extern TCHAR BitmapFile[ MAX_PATH ]; /* Name of the file to use for the button bitmaps */

extern const BUTTON_DETAILS ButtonDetails[ NUM_BUTTONS ];

/******************************************************************************

  These variables are process specific.

******************************************************************************/

extern HIMAGELIST ButtonImages;       /* Button bitmaps and "inverses" */
extern HFONT      CaptionFont;        /* Font to draw text in */
extern LIST       WindowList;         /* List of all subclassed windows */
extern HANDLE     Heap;               /* Heap to use for dynamic memory */
extern LONG       TimeWidth;          /* Width of 99:99 for time display */
extern HBITMAP    BackBuffer;         /* Double buffer for title bar */
extern SIZE       BackBufferSize;     /* Size of the above */
extern HINSTANCE  DllInstance;        /* Handle to this DLL */

/******************************************************************************

  Read and write the DisplayTitle etc flags from/to the registry

******************************************************************************/

static void RegReadSettings( void );
static void RegWriteSettings( void );

/******************************************************************************

  System wide initialisation and shutdown - done once only.

******************************************************************************/

static int InitialiseGlobal( HINSTANCE hInstance );
static void ShutdownGlobal( void );

#endif /* _h_common_h_ */

/*****************************************************************************/
