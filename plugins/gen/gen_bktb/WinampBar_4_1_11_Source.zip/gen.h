typedef struct {
	int version;
	char *description;
	int (__cdecl *init)( void );
	void (__cdecl *config)( void );
	void (__cdecl *quit)( void );
	HWND hwndParent;
	HINSTANCE hDllInstance;
} winampGeneralPurposePlugin;

#define GPPHDR_VER 0x10

//extern winampGeneralPurposePlugin *gen_plugins[256];
//typedef winampGeneralPurposePlugin * (*winampGeneralPurposePluginGetter)( void );
