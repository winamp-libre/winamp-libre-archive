/******************************************************************************

  $Id: log.c,v 1.3 2001/01/03 19:29:31 Gavin_Smyth Exp $

  Emit messages to a file.

  Copyright 1999-2001 Gavin Smyth
  http://www.beesknees.freeserve.co.uk/software/

******************************************************************************/

#ifdef _DEBUG

# include "common.h"
# include <stdarg.h>

/* OK: this routine is a bit dodgy in that it doesn't protect against buffer
   overflow, but I know that all logs I'm raising in this program will fit */

void __cdecl Log( const char* format, ... )
{
  HANDLE f = CreateFile( _T("C:\\bklog.txt"), GENERIC_WRITE,
                         FILE_SHARE_WRITE | FILE_SHARE_READ,
                         NULL, OPEN_ALWAYS, 0, NULL );
  if( f != INVALID_HANDLE_VALUE )
  {
    va_list args;
    char buffer[ 512 ];
    DWORD numToWrite, numWritten;

    numToWrite = wsprintfA( buffer, "%10lu %08lX: ", GetTickCount(), GetCurrentProcessId() );
    va_start( args, format );
    numToWrite += wvsprintfA( buffer + numToWrite, format, args );
    va_end( args );
    buffer[ numToWrite++ ] = '\r';
    buffer[ numToWrite++ ] = '\n';

    SetFilePointer( f, 0, NULL, FILE_END );
    WriteFile( f, buffer, numToWrite, &numWritten, NULL );

    CloseHandle( f );
  }
}

#else /* Not a debug build, so do nothing instead */

  /* Don't whinge about this being empty */
# pragma warning( disable: 4206 )
#endif

/*****************************************************************************/
