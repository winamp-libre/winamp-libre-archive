/******************************************************************************

  $Id: resource.h,v 1.25 2001/11/01 19:26:21 Gavin Exp $

  Resource symbols

  Copyright 1999-2001 Gavin Smyth
  http://www.beesknees.freeserve.co.uk/software/

******************************************************************************/

/* Version number */
#define V_MAJOR   5
#define V_MINOR   1
#define V_BUILD   4
#define V_FLAGS   VS_FF_PRERELEASE

/* Main icon */
#define IDI_MAIN             50

/* Configuration dialog box */
#define IDD_CONFIGURE        101

/* Controls on the dialog box */
#define IDC_DISPLAYTITLE     1001
#define IDC_HOME             1002
#define IDC_BUTTONLIST       1003
#define IDC_PRESET           1004
#define IDC_PRESETSPIN       1005
#define IDC_STRIP            1006
#define IDC_OFFSET           1007
#define IDC_OFFSETSPIN       1008
#define IDC_COLOUR           1009
#define IDC_UP               1010
#define IDC_DOWN             1011
#define IDC_TIME_NONE        1012
#define IDC_TIME_ELAPSED     1013
#define IDC_TIME_REMAINING   1014
#define IDC_TIME_CLOCK       1015
#define IDC_BITMAP_FILE      1016
#define IDC_BITMAP_SELECT    1017
#define IDC_TITLETIP         1018
#define IDC_FONT             1019

/* Width of the list control */
#define LIST_WIDTH           90

/* Button bitmaps */
#define IDB_BUTTONS          10001
#define IDB_BUTTONS16        10002

/* Version numbers - string has to be narrow */
#define VERSION              V_MAJOR,V_MINOR,V_BUILD,0
#define V_( a )              #a
#define V_STR( a, b, c )     V_(a) "." V_(b) "." V_(c)
#define VERSION_STRING       V_STR( V_MAJOR, V_MINOR, V_BUILD )

/*****************************************************************************/
