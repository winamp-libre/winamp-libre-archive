/******************************************************************************

  $Id: dllmain.c,v 1.11 2001/10/17 08:37:55 Gavin Exp $

  Winamp title bar controller

  DLL startup function

  Copyright 1999-2001 Gavin Smyth
  http://www.beesknees.freeserve.co.uk/software/

******************************************************************************/

#include "common.h"
#include "resource.h"

#include "registry.inl"
#include "funcs.inl"
#include "tooltip.inl"
#include "draw.inl"
#include "bar.inl"
#include "winampif.inl"

/* Remove whinges about unused variable "reserved" */
#pragma warning( push )
#pragma warning( disable : 4100 )

BOOL WINAPI DllMain( HINSTANCE hinst, DWORD reason, LPVOID reserved )
{
  if( reason == DLL_PROCESS_ATTACH )
  {
    /* Save a little bit of time by getting rid of thread notifications since
       I don't need them */
    DisableThreadLibraryCalls( hinst );

    DllInstance = hinst;
  }

  return TRUE;
}

#pragma warning( pop )

/*****************************************************************************/
