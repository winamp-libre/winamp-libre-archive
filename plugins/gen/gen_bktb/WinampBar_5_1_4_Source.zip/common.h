/******************************************************************************

  $Id: common.h,v 1.24 2001/10/24 18:41:42 Gavin Exp $

  Common file - exists mainly to facilitate precompiled headers

  Needs to be #included first in any source file, and the project set up
  to use this for precompiler headers

                      Copyright 1999-2001 Gavin Smyth
                 http://www.beesknees.freeserve.co.uk

******************************************************************************/

#ifndef _h_common_h_
#define _h_common_h_

#define STRICT
#define WINDOWS_LEAN_AND_MEAN
/* Warning 4115 appears in rpcasync.h, dragged in by windows.h */
#pragma warning( disable : 4115 )
#include <windows.h>
#include <windowsx.h>
#include <tchar.h>
/* Warning 4201 appears in commctrl.h */
#pragma warning( disable : 4201 )
#include <commctrl.h>

#ifdef WINAMPBAR_EXPORTS
# define EXPORT __declspec( dllexport )
#else
# define EXPORT __declspec( dllimport )
#endif

/* Not interested in inlining messages */
#pragma warning( disable: 4711 )

/******************************************************************************

  Logging interface

******************************************************************************/

#ifdef _DEBUG
  void __cdecl Log( const char* format, ... );
# define LOG( args ) Log args
#else
# define LOG( args ) 0 /* Nothing */
#endif

#define BUTTON_HEIGHT 12
#define BUTTON_WIDTH 12
#define NUM_BUTTONS 16
#define BUTTON_GAP 4 /* Space between text and buttons */

typedef struct
{
  TCHAR title[ 256 ];   /* Name of the song */
  UINT  chars;          /* Length in characters */
} TITLE;

typedef enum { TIME_NONE = 0, TIME_ELAPSED, TIME_REMAINING, TIME_CLOCK } TIME_DISPLAY;

typedef struct
{
  void (*proc)( WPARAM );  /* Function to execute for this button */
  WPARAM arg;              /* Argument to pass to it */
  BOOL autorepeat;         /* If set, autorepeat command */
  const TCHAR* name;       /* String identifying the button */
  const TCHAR* tip;        /* Tooltip string */
} BUTTON_DETAILS;

extern volatile HWND WinampBarWindow; /* My window */
extern HWND  WinampWindow;            /* Window to which to direct Winamp control messages */
extern HWND  TooltipWindow;           /* Window used for tooltips */
extern TITLE Song;                    /* Title of the currently playing song */
extern BOOL  DisplayTitle;            /* Enable display of song title */
extern BOOL  StripSuffix;             /* Strip file suffix from title or not */
extern BOOL  TitleTooltip;            /* Display title or button name as tooltip */
extern TIME_DISPLAY DisplayTime;      /* Whether to display track time or not */
extern UINT  NumButtons;              /* Number of enabled buttons */
extern BYTE  Buttons[ NUM_BUTTONS ];  /* Indexes to the enabled buttons */
extern HIMAGELIST ButtonImages;       /* Button bitmaps */
extern int   ButtonPressed;           /* Last pressed button */
extern int   TimeSincePressed;       /* Ticks since the button was pressed */
extern BYTE  PresetVolume;            /* Volume to set to */
extern UINT  Offset;                  /* Space to add in between buttons */
extern COLORREF Colour;               /* Colour in which to display text */
extern TCHAR BitmapFile[ MAX_PATH ];  /* Name of the file to use for the button bitmaps */
extern HFONT WinampBarFont;           /* Font to draw text in */
extern LONG  TimeWidth;               /* Width of 99:99 for number display */

extern const BUTTON_DETAILS ButtonDetails[ NUM_BUTTONS ];

extern HINSTANCE  DllInstance;        /* Handle to this DLL */

/******************************************************************************

  Set the winamp bar window font, and calculate the width of the time field.

******************************************************************************/

static void SetFont( HFONT h );

/******************************************************************************

  Read and write the DisplayTitle etc flags from/to the registry.

******************************************************************************/

static void RegReadSettings( void );
static void RegWriteSettings( void );

/******************************************************************************

  Grab the name of the currently playing song and chop of extraneous bits.

******************************************************************************/

static void GetCurrentSong( void );

/******************************************************************************

  System wide initialisation and shutdown - done once only.

******************************************************************************/

static int InitialiseGlobal( HINSTANCE hInstance );
static void ShutdownGlobal( void );

#endif /* _h_common_h_ */

/*****************************************************************************/
