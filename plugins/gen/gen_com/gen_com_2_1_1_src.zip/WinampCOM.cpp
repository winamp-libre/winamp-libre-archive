/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2000 John Adcock.  All rights reserved.
/////////////////////////////////////////////////////////////////////////////
//
//	This file is subject to the terms of the GNU General Public License as
//	published by the Free Software Foundation.  A copy of this license is
//	included with this software distribution in the file COPYING.  If you
//	do not have a copy, you may obtain a copy by writing to the Free
//	Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
//
//	This software is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details
//
/////////////////////////////////////////////////////////////////////////////
// WinampCOM.cpp
/////////////////////////////////////////////////////////////////////////////
// Change Log
//
// Date          Developer             Changes
//
// 05 Jan 2000   John Adcock           Original GPL Release    
// 29 Jan 2000   John Adcock           Changed the registration to avoid pop-up
//
/////////////////////////////////////////////////////////////////////////////

// Note: Proxy/Stub Information
//      To build a separate proxy/stub DLL, 
//      run nmake -f WinampCOMps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "WinampCOM.h"
#include <process.h>

#include "WinampCOM_i.c"
#include "Application.h"
#include "gen.h"
#include "winampcmd.h"
#include "plugin.h"
#include "frontend.h"


const DWORD dwTimeOut = 5000; // time for EXE to be idle before shutting down
const DWORD dwPause = 1000; // time to wait for threads to finish up

// Passed to CreateThread to monitor the shutdown event
static DWORD WINAPI MonitorProc(void* pv)
{
    CExeModule* p = (CExeModule*)pv;
    p->MonitorShutdown();
    return 0;
}

BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY(CLSID_Application, CApplication)
END_OBJECT_MAP()


LONG CExeModule::Unlock()
{
    LONG l = CComModule::Unlock();
    if (l == 0)
    {
        bActivity = true;
        SetEvent(hEventShutdown); // tell monitor that we transitioned to zero
    }
    return l;
}

//Monitors the shutdown event
void CExeModule::MonitorShutdown()
{
    while (1)
    {
        WaitForSingleObject(hEventShutdown, INFINITE);
        DWORD dwWait=0;
        do
        {
            bActivity = false;
            dwWait = WaitForSingleObject(hEventShutdown, dwTimeOut);
        } while (dwWait == WAIT_OBJECT_0);
        // timed out
		if (!bActivity && m_nLockCnt == 0) // if no activity let's really bail
        {
                break;
        }
    }
    CloseHandle(hEventShutdown);
    PostThreadMessage(dwThreadID, WM_QUIT, 0, 0);
}

bool CExeModule::StartMonitor()
{
    hEventShutdown = CreateEvent(NULL, false, false, NULL);
    if (hEventShutdown == NULL)
        return false;
    DWORD dwThreadID;
    HANDLE h = CreateThread(NULL, 0, MonitorProc, this, 0, &dwThreadID);
    return (h != NULL);
}


LPCTSTR FindOneOf(LPCTSTR p1, LPCTSTR p2)
{
    while (p1 != NULL && *p1 != NULL)
    {
        LPCTSTR p = p2;
        while (p != NULL && *p != NULL)
        {
            if (*p1 == *p)
                return CharNext(p1);
            p = CharNext(p);
        }
        p1 = CharNext(p1);
    }
    return NULL;
}

CExeModule _Module;

DWORD WINAPI WorkerThreadFunc(LPVOID Param)
{
	BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY(CLSID_Application, CApplication)
	END_OBJECT_MAP()

    HRESULT hRes = CoInitialize(NULL);

    _Module.Init(ObjectMap, plugin.hDllInstance, &LIBID_WINAMPCOMLib);
    _Module.dwThreadID = GetCurrentThreadId();

	IClassFactory* pICf = NULL;
	(ObjectMap[0].pfnGetClassObject)(NULL, IID_IClassFactory, (void**)&pICf);

	IApplication* pIApp = NULL;
	pICf->CreateInstance(NULL, IID_IApplication, (void**)&pIApp);
	pICf->Release();

	CApplication* pCApp = (CApplication*)pIApp;
	
    int nRet = 0;
    hRes = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER, 
										REGCLS_MULTIPLEUSE);
    _ASSERTE(SUCCEEDED(hRes));

    MSG msg;
    while (GetMessage(&msg, 0, 0, 0))
	{
		if(msg.message == WM_USER)
		{
			pCApp->SongChange();
		}
        DispatchMessage(&msg);
	}

	pIApp->Release();

    _Module.RevokeClassObjects();
    _Module.Term();
    
	CoUninitialize();
    return 0;
}

HWND hWndWinamp;


DWORD CExeModule::RegisterAdditionalResource(UINT ResId)
{
	USES_CONVERSION;
	HRESULT hRes = S_OK;
	CComPtr<IRegistrar> p;

	hRes = CoCreateInstance(CLSID_Registrar, NULL,
		CLSCTX_INPROC_SERVER, IID_IRegistrar, (void**)&p);

	if (SUCCEEDED(hRes))
	{
		HINSTANCE hWinamp = (HINSTANCE)GetWindowLong(plugin.hwndParent, GWL_HINSTANCE); 
		TCHAR szModule[_MAX_PATH];

		GetModuleFileName(hWinamp, szModule, _MAX_PATH);

		// Convert to short path to work around bug in NT4's CreateProcess
		TCHAR szModuleShort[_MAX_PATH];
		GetShortPathName(szModule, szModuleShort, _MAX_PATH);
		LPOLESTR pszModule = T2OLE(szModuleShort);

		int nLen = ocslen(pszModule);
		LPOLESTR pszModuleQuote = (LPOLESTR)alloca((nLen*4+2)*sizeof(OLECHAR));
		CComModule::ReplaceSingleQuote(pszModuleQuote, pszModule);

		// we now add append a known file to the end
		// this prevents winamp from complaining too much
		// we OLE starts the process with -embedding
		// we know that winamp.ini as always in the same
		// place as the exe so I'll use this

		nLen = wcslen(pszModuleQuote);
		pszModuleQuote[nLen] = L' ';
		for(int i(1); i < nLen - 2; ++i)
		{
			pszModuleQuote[nLen + i] = pszModuleQuote[i - 1];
		}
		pszModuleQuote[nLen + i]  = L'i';
		pszModuleQuote[nLen + i + 1]  = L'n';
		pszModuleQuote[nLen + i + 2]  = L'i';
		pszModuleQuote[nLen + i + 3]  = L'\0';

		p->AddReplacement(OLESTR("Module"), pszModuleQuote);

		GetModuleFileName(plugin.hDllInstance, szModule, _MAX_PATH);

		// Convert to short path to work around bug in NT4's CreateProcess
		GetShortPathName(szModule, szModuleShort, _MAX_PATH);
		pszModule = T2OLE(szModuleShort);
		nLen = ocslen(pszModule);
		pszModuleQuote = (LPOLESTR)alloca((nLen*2+1)*sizeof(OLECHAR));
		CComModule::ReplaceSingleQuote(pszModuleQuote, pszModule);
		LPOLESTR szType = OLESTR("REGISTRY");
		hRes = p->ResourceRegister(pszModule, ResId, szType);
	}
	return hRes;
}



#ifdef __cplusplus
extern "C"{
#endif 

HANDLE hThread;
DWORD ThreadId;
WNDPROC wpOrigWinampProc;


// Subclass procedure 
LRESULT APIENTRY WinampSubclassProc(HWND hwnd, UINT uMsg,  WPARAM wParam, LPARAM lParam)
{ 
    if (uMsg == WM_USER && wParam == 0x29A)
	{
		static LPARAM LastSong(-1);
		if(LastSong != lParam)
		{
			LastSong = lParam;
			PostThreadMessage(ThreadId, WM_USER, 0, 0);
		}
	}
    return CallWindowProc(wpOrigWinampProc, hwnd, uMsg, wParam, lParam); 
} 

int __cdecl WinampCOMInit()
{
    _Module.Init(ObjectMap, plugin.hDllInstance, &LIBID_WINAMPCOMLib);
    _Module.dwThreadID = GetCurrentThreadId();
	hWndWinamp = plugin.hwndParent;

	HWND hWndPlayList = FindWindow("Winamp PE",NULL);
	wpOrigWinampProc = (WNDPROC)SetWindowLong(hWndPlayList, GWL_WNDPROC, (LONG)WinampSubclassProc); 

    LPCSTR lpCmdLine = GetCommandLine();
    TCHAR szTokens[] = _T("-/");
    LPCTSTR lpszToken = FindOneOf(lpCmdLine, szTokens);
    while (lpszToken != NULL)
    {
        if (lstrcmpi(lpszToken, _T("embedding"))==0)
		{
				SendMessage(hWndWinamp,WM_WA_IPC,0,IPC_DELETE);
		}
        lpszToken = FindOneOf(lpszToken, szTokens);
	}

    _Module.UpdateRegistryFromResource(IDR_WinampCOM, TRUE);
    _Module.RegisterServer(TRUE);
	_Module.RegisterAdditionalResource(IDR_APPLICATION2);

	
	hThread = (HANDLE) CreateThread(NULL,0,WorkerThreadFunc,NULL,0, &ThreadId);
	return 0;
}

void __cdecl WinampCOMConfig()
{
	MessageBox(plugin.hwndParent, "No Configuration required", "Winamp COM", MB_OK);
}

void __cdecl WinampCOMQuit()
{
	PostThreadMessage(ThreadId, WM_QUIT, 0, 0);
	
	DWORD ExitCode;

	GetExitCodeThread(hThread, &ExitCode);

	while(ExitCode == STILL_ACTIVE)
	{
		Sleep(50);
		GetExitCodeThread(hThread, &ExitCode);
	}
    
	HWND hWndPlayList = FindWindow("Winamp PE",NULL);
	SetWindowLong(hWndPlayList, GWL_WNDPROC, (LONG) wpOrigWinampProc); 

    LPCSTR lpCmdLine = GetCommandLine();
    TCHAR szTokens[] = _T("-/");
    LPCTSTR lpszToken = FindOneOf(lpCmdLine, szTokens);
    while (lpszToken != NULL)
    {
        if (lstrcmpi(lpszToken, _T("UnregComPlugin"))==0)
		{
			_Module.UpdateRegistryFromResource(IDR_WinampCOM, FALSE);
			_Module.UnregisterServer(TRUE);
			break;
		}
        lpszToken = FindOneOf(lpszToken, szTokens);
	}
}

__declspec( dllexport ) 
winampGeneralPurposePlugin * __cdecl winampGetGeneralPurposePlugin()
{
	return &plugin;
}


#ifdef __cplusplus
}
#endif 



