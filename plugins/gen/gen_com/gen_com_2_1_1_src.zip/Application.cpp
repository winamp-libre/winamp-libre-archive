/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2000 John Adcock.  All rights reserved.
/////////////////////////////////////////////////////////////////////////////
//
//	This file is subject to the terms of the GNU General Public License as
//	published by the Free Software Foundation.  A copy of this license is
//	included with this software distribution in the file COPYING.  If you
//	do not have a copy, you may obtain a copy by writing to the Free
//	Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
//
//	This software is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details
//
/////////////////////////////////////////////////////////////////////////////
// Application.cpp : Implementation of CApplication
/////////////////////////////////////////////////////////////////////////////
// Change Log
//
// Date          Developer             Changes
//
// 05 Jan 2000   John Adcock           Original GPL Release    
// 26 Jan 2000   John Adcock           Added Repeat and shuffle status
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WinampCOM.h"
#include "Application.h"
#include "frontend.h"


/////////////////////////////////////////////////////////////////////////////
// Menu Item Definitions
#define WINAMP_MENU_OPTIONS_POS		11
#define WINAMP_MENU_REPEAT			40022
#define WINAMP_MENU_SHUFFLE			40023

/////////////////////////////////////////////////////////////////////////////
// CApplication

extern HWND hWndWinamp;


CApplication::CApplication()
{
}


STDMETHODIMP CApplication::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IApplication
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CApplication::SendCommand(eWinampCommand Code)
{
	SendMessage(hWndWinamp, WM_COMMAND, Code, 0);
	return S_OK;
}

STDMETHODIMP CApplication::get_Version(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,0,IPC_GETVERSION);
	return S_OK;
}

STDMETHODIMP CApplication::ClearPlaylist()
{
	SendMessage(hWndWinamp,WM_WA_IPC,0,IPC_DELETE);
	return S_OK;
}

STDMETHODIMP CApplication::Play()
{
	SendMessage(hWndWinamp, WM_COMMAND, WINAMP_PLAY, 0);
	return S_OK;
}

STDMETHODIMP CApplication::get_Status(eWinampPlayStatus *pVal)
{
	*pVal = (eWinampPlayStatus)SendMessage(hWndWinamp,WM_WA_IPC,0,IPC_ISPLAYING);
	return S_OK;
}

STDMETHODIMP CApplication::put_Status(eWinampPlayStatus newVal)
{
	switch(newVal)
	{
	case WINAMP_STOPPED:
		SendCommand(WINAMP_STOP);
		break;
	case WINAMP_PAUSED:
		SendCommand(WINAMP_PAUSE);
		break;
	default:
		Play();
		break;
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_CurrentPos(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,0,IPC_GETOUTPUTTIME);
	return S_OK;
}

STDMETHODIMP CApplication::put_CurrentPos(long newVal)
{
	SendMessage(hWndWinamp,WM_WA_IPC,newVal,IPC_JUMPTOTIME);
	return S_OK;
}

STDMETHODIMP CApplication::SetVolume(long newVal)
{
	if(newVal < 0)
	{
		newVal = 0;
	}
	if(newVal > 255)
	{
		newVal = 255;
	}
	long CurrentValue(SendMessage(hWndWinamp,WM_WA_IPC,newVal,IPC_SETVOLUME));
	return S_OK;
}

STDMETHODIMP CApplication::get_SampleRate(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,0,IPC_GETINFO);
	return S_OK;
}

STDMETHODIMP CApplication::get_Bitrate(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,1,IPC_GETINFO);
	return S_OK;
}

STDMETHODIMP CApplication::get_Channels(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,2,IPC_GETINFO);
	return S_OK;
}

STDMETHODIMP CApplication::SetPanning(long PanIndex)
{
	SendMessage(hWndWinamp,WM_WA_IPC,PanIndex,IPC_SETPANNING);
	return S_OK;
}

STDMETHODIMP CApplication::get_PlayListPos(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,0,IPC_GETLISTPOS);
	return S_OK;
}

STDMETHODIMP CApplication::put_PlayListPos(long newVal)
{
	SendMessage(hWndWinamp,WM_WA_IPC,newVal,IPC_SETPLAYLISTPOS);
	return S_OK;
}

STDMETHODIMP CApplication::get_EqPosition(long Band, long *pVal)
{
	if(Band < 0)
	{
		Band = 0;
	}
	if(Band > 9)
	{
		Band = 9;
	}
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,Band,IPC_GETEQDATA);
	return S_OK;
}

STDMETHODIMP CApplication::put_EqPosition(long Band, long newVal)
{
	if(Band < 0)
	{
		Band = 0;
	}
	if(Band > 9)
	{
		Band = 9;
	}
	if(newVal < 0)
	{
		newVal = 0;
	}
	if(newVal > 63)
	{
		newVal = 63;
	}
	SendMessage(hWndWinamp,WM_WA_IPC,Band,IPC_GETEQDATA);
	SendMessage(hWndWinamp,WM_WA_IPC,newVal,IPC_SETEQDATA);
	return S_OK;
}

STDMETHODIMP CApplication::get_PreAmpPosition(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,10,IPC_GETEQDATA);
	return S_OK;
}

STDMETHODIMP CApplication::put_PreAmpPosition(long newVal)
{
	if(newVal < 0)
	{
		newVal = 0;
	}
	if(newVal > 63)
	{
		newVal = 63;
	}
	SendMessage(hWndWinamp,WM_WA_IPC,10,IPC_GETEQDATA);
	SendMessage(hWndWinamp,WM_WA_IPC,newVal,IPC_SETEQDATA);
	return S_OK;
}

STDMETHODIMP CApplication::AddFile(BSTR FileName)
{
	USES_CONVERSION;
	if(FileName != NULL)
	{
		int DirPos(0);
		COPYDATASTRUCT cds;

		for(DirPos = wcslen(FileName); DirPos > 0 && FileName[DirPos] != L'\\'; DirPos--);
		if(FileName[DirPos] == L'\\')
		{
			FileName[DirPos] = L'\0';
			strcpy(m_TempBuffer, W2A(FileName));
			cds.dwData = IPC_CHDIR;
			cds.lpData = (void *) m_TempBuffer;
			cds.cbData = strlen((char*)m_TempBuffer)+1; // include space for null char
			SendMessage(hWndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);
			strcpy(m_TempBuffer, W2A(FileName + DirPos + 1));
		}
		else
		{
			strcpy(m_TempBuffer, W2A(FileName));
		}
		cds.dwData = IPC_PLAYFILE;
		cds.lpData = (void *) m_TempBuffer;
		cds.cbData = strlen(m_TempBuffer)+1; // include space for null char
		SendMessage(hWndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);
	}
	return S_OK;
}

STDMETHODIMP CApplication::ChangeDirectory(BSTR NewDir)
{
	USES_CONVERSION;
	if(NewDir != NULL)
	{
		strcpy(m_TempBuffer, W2A(NewDir));
		COPYDATASTRUCT cds;
		cds.dwData = IPC_CHDIR;
		cds.lpData = (void *) m_TempBuffer;
		cds.cbData = strlen(m_TempBuffer)+1; // include space for null char
		SendMessage(hWndWinamp,WM_COPYDATA,(WPARAM)NULL,(LPARAM)&cds);
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_PlayListCount(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,0,IPC_GETLISTLENGTH);
	return S_OK;
}


STDMETHODIMP CApplication::get_SongFileName(long PlayListPos, BSTR *pVal)
{
	USES_CONVERSION;
	char *Name = (char *)SendMessage(hWndWinamp,WM_WA_IPC,PlayListPos,IPC_GETPLAYLISTFILE);
	if(Name != NULL)
	{
		*pVal = SysAllocString(A2W(Name));
	}
	else
	{
		*pVal = NULL;
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_SongTitle(long PlayListPos, BSTR *pVal)
{
	USES_CONVERSION;
	char *Name = (char *)SendMessage(hWndWinamp,WM_WA_IPC,PlayListPos,IPC_GETPLAYLISTTITLE);
	if(Name != NULL)
	{
		*pVal = SysAllocString(A2W(Name));
	}
	else
	{
		*pVal = NULL;
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_CurrentSongFileName(BSTR *pVal)
{
	long PlayListPos(0);
	get_PlayListPos(&PlayListPos);
	get_SongFileName(PlayListPos, pVal);
	return S_OK;
}

STDMETHODIMP CApplication::get_CurrentSongTitle(BSTR *pVal)
{
	long PlayListPos(0);
	get_PlayListPos(&PlayListPos);
	get_SongTitle(PlayListPos, pVal);
	return S_OK;
}

STDMETHODIMP CApplication::get_SkinName(BSTR *pVal)
{
	USES_CONVERSION;
	m_TempBuffer[0] = '\0';
	SendMessage(hWndWinamp,WM_WA_IPC,(WPARAM)m_TempBuffer,IPC_GETSKIN);
	if(m_TempBuffer[0] != '\0')
	{
		*pVal = SysAllocString(A2W(m_TempBuffer));
	}
	else
	{
		*pVal = NULL;
	}
	return S_OK;
}

STDMETHODIMP CApplication::put_SkinName(BSTR newVal)
{
	USES_CONVERSION;
	strcpy(m_TempBuffer, W2A(newVal));
	SendMessage(hWndWinamp,WM_WA_IPC,(WPARAM)m_TempBuffer,IPC_SETSKIN);
	return S_OK;
}

STDMETHODIMP CApplication::StartPlugIn(BSTR PlugInName)
{
	USES_CONVERSION;
	strcpy(m_TempBuffer, W2A(PlugInName));
	SendMessage(hWndWinamp,WM_WA_IPC,(WPARAM)m_TempBuffer,IPC_EXECPLUG);
	return S_OK;
}

STDMETHODIMP CApplication::ToggleShufflePlay()
{
	long rc = SendMessage(hWndWinamp, WM_COMMAND, WINAMP_FILE_SHUFFLE, 0);
	return S_OK;
}

STDMETHODIMP CApplication::ToggleRepeatPlay()
{
	SendMessage(hWndWinamp, WM_COMMAND, WINAMP_FILE_REPEAT, 0);
	return S_OK;
}

STDMETHODIMP CApplication::Stop()
{
	SendMessage(hWndWinamp, WM_COMMAND, WINAMP_STOP, 0);
	return S_OK;
}

STDMETHODIMP CApplication::Pause()
{
	SendMessage(hWndWinamp, WM_COMMAND, WINAMP_PAUSE, 0);
	return S_OK;
}

STDMETHODIMP CApplication::FastForward()
{
	SendMessage(hWndWinamp, WM_COMMAND, WINAMP_FASTFWD, 0);
	return S_OK;
}

STDMETHODIMP CApplication::Rewind()
{
	SendMessage(hWndWinamp, WM_COMMAND, WINAMP_REWIND, 0);
	return S_OK;
}

STDMETHODIMP CApplication::get_EqEnabled(VARIANT_BOOL *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,11,IPC_GETEQDATA)?VARIANT_TRUE:VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CApplication::put_EqEnabled(VARIANT_BOOL newVal)
{
	SendMessage(hWndWinamp,WM_WA_IPC,11,IPC_GETEQDATA);
	SendMessage(hWndWinamp,WM_WA_IPC,newVal,IPC_SETEQDATA);
	return S_OK;
}

STDMETHODIMP CApplication::get_AutoloadEnabled(VARIANT_BOOL *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC,12,IPC_GETEQDATA)?VARIANT_TRUE:VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CApplication::put_AutoloadEnabled(VARIANT_BOOL newVal)
{
	SendMessage(hWndWinamp,WM_WA_IPC,12,IPC_GETEQDATA);
	SendMessage(hWndWinamp,WM_WA_IPC,newVal,IPC_SETEQDATA);
	return S_OK;
}

STDMETHODIMP CApplication::get_ID3Tag(long Tag, BSTR *pVal)
{
	return E_NOTIMPL;
}

void CApplication::SongChange()
{
	Fire_SongChange();
}

STDMETHODIMP CApplication::get_CurrentSongLength(long *pVal)
{
	*pVal = SendMessage(hWndWinamp,WM_WA_IPC, 1,IPC_GETOUTPUTTIME);
	return S_OK;
}

STDMETHODIMP CApplication::FastFwd5Secs()
{
	SendMessage(hWndWinamp, WM_COMMAND, WINAMP_FFWD5S, 0);
	return S_OK;
}

STDMETHODIMP CApplication::Rewind5Secs()
{
	SendMessage(hWndWinamp, WM_COMMAND, WINAMP_REW5S, 0);
	return S_OK;
}

STDMETHODIMP CApplication::get_Visible(VARIANT_BOOL *pVal)
{
	*pVal = IsWindowVisible(hWndWinamp)?VARIANT_TRUE:VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CApplication::put_Visible(VARIANT_BOOL newVal)
{
	if(newVal)
	{
		if(!IsWindowVisible(hWndWinamp))
		{
			ShowWindow(hWndWinamp, SW_SHOW);
		}
	}
	else
	{
		if(IsWindowVisible(hWndWinamp))
		{
			ShowWindow(hWndWinamp, SW_HIDE);
		}
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_MiniBrowserVisible(VARIANT_BOOL *pVal)
{
	HWND hWnd = FindWindow("Winamp MB",NULL);
	*pVal = IsWindowVisible(hWnd)?VARIANT_TRUE:VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CApplication::put_MiniBrowserVisible(VARIANT_BOOL newVal)
{
	HWND hWnd = FindWindow("Winamp MB",NULL);
	if(newVal)
	{
		if(!IsWindowVisible(hWnd))
		{
			ShowWindow(hWnd, SW_SHOW);
		}
	}
	else
	{
		if(IsWindowVisible(hWnd))
		{
			ShowWindow(hWnd, SW_HIDE);
		}
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_EqualizerVisible(VARIANT_BOOL *pVal)
{
	HWND hWnd = FindWindow("Winamp EQ",NULL);
	*pVal = IsWindowVisible(hWnd)?VARIANT_TRUE:VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CApplication::put_EqualizerVisible(VARIANT_BOOL newVal)
{
	HWND hWnd = FindWindow("Winamp EQ",NULL);
	if(newVal)
	{
		if(!IsWindowVisible(hWnd))
		{
			ShowWindow(hWnd, SW_SHOW);
		}
	}
	else
	{
		if(IsWindowVisible(hWnd))
		{
			ShowWindow(hWnd, SW_HIDE);
		}
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_PlaylistVisible(VARIANT_BOOL *pVal)
{
	HWND hWnd = FindWindow("Winamp PE",NULL);
	*pVal = IsWindowVisible(hWnd)?VARIANT_TRUE:VARIANT_FALSE;
	return S_OK;
}

STDMETHODIMP CApplication::put_PlaylistVisible(VARIANT_BOOL newVal)
{
	HWND hWnd = FindWindow("Winamp PE",NULL);
	if(newVal)
	{
		if(!IsWindowVisible(hWnd))
		{
			ShowWindow(hWnd, SW_SHOW);
		}
	}
	else
	{
		if(IsWindowVisible(hWnd))
		{
			ShowWindow(hWnd, SW_HIDE);
		}
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_ShuffleStatus(VARIANT_BOOL *pVal)
{
	if(GetMenuState(GetOptionMenu(), WINAMP_MENU_SHUFFLE, MF_BYCOMMAND) == MF_CHECKED)
	{
		*pVal = VARIANT_TRUE;
	}
	else
	{
		*pVal = VARIANT_FALSE;
	}
	return S_OK;
}

STDMETHODIMP CApplication::put_ShuffleStatus(VARIANT_BOOL newVal)
{
	VARIANT_BOOL CurVal;
	get_ShuffleStatus(&CurVal);
	if(CurVal != newVal)
	{
		ToggleShufflePlay();
	}
	return S_OK;
}

STDMETHODIMP CApplication::get_RepeatStatus(VARIANT_BOOL *pVal)
{
	if(GetMenuState(GetOptionMenu(), WINAMP_MENU_REPEAT, MF_BYCOMMAND) == MF_CHECKED)
	{
		*pVal = VARIANT_TRUE;
	}
	else
	{
		*pVal = VARIANT_FALSE;
	}
	return S_OK;
}

STDMETHODIMP CApplication::put_RepeatStatus(VARIANT_BOOL newVal)
{
	VARIANT_BOOL CurVal;
	get_RepeatStatus(&CurVal);
	if(CurVal != newVal)
	{
		ToggleRepeatPlay();
	}
	return S_OK;
}

HMENU CApplication::GetOptionMenu()
{
	// Get System menu handle
	HMENU hMenuSystem = GetSystemMenu(hWndWinamp, 0);

	//Get Winamp sub-menu handle
	HMENU hMenuWinamp = GetSubMenu(hMenuSystem, 0);

	//Get Options sub-menu handle
	return GetSubMenu(hMenuWinamp, WINAMP_MENU_OPTIONS_POS);
}
