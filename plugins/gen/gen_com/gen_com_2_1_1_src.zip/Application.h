/////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2000 John Adcock.  All rights reserved.
/////////////////////////////////////////////////////////////////////////////
//
//	This file is subject to the terms of the GNU General Public License as
//	published by the Free Software Foundation.  A copy of this license is
//	included with this software distribution in the file COPYING.  If you
//	do not have a copy, you may obtain a copy by writing to the Free
//	Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
//
//	This software is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details
//
/////////////////////////////////////////////////////////////////////////////
// Application.h : Declaration of the CApplication

#ifndef __APPLICATION_H_
#define __APPLICATION_H_

#include "resource.h"       // main symbols
#include "WinampCOMCP.h"

/////////////////////////////////////////////////////////////////////////////
// CApplication
class ATL_NO_VTABLE CApplication : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CApplication, &CLSID_Application>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CApplication>,
	public IDispatchImpl<IApplication, &IID_IApplication, &LIBID_WINAMPCOMLib>,
	public CProxy_IApplicationEvents< CApplication >
{
public:
	CApplication();

DECLARE_REGISTRY_RESOURCEID(IDR_APPLICATION)

DECLARE_PROTECT_FINAL_CONSTRUCT()

DECLARE_CLASSFACTORY_SINGLETON(CApplication);

BEGIN_COM_MAP(CApplication)
	COM_INTERFACE_ENTRY(IApplication)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CApplication)
CONNECTION_POINT_ENTRY(DIID__IApplicationEvents)
END_CONNECTION_POINT_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IApplication
public:
	STDMETHOD(get_RepeatStatus)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_RepeatStatus)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_ShuffleStatus)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_ShuffleStatus)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_PlaylistVisible)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_PlaylistVisible)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_EqualizerVisible)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_EqualizerVisible)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_MiniBrowserVisible)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_MiniBrowserVisible)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_Visible)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_Visible)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_ID3Tag)(long Tag, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_AutoloadEnabled)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_AutoloadEnabled)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(get_EqEnabled)(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD(put_EqEnabled)(/*[in]*/ VARIANT_BOOL newVal);
	STDMETHOD(Rewind)();
	STDMETHOD(FastForward)();
	STDMETHOD(Pause)();
	STDMETHOD(Stop)();
	STDMETHOD(ToggleRepeatPlay)();
	STDMETHOD(ToggleShufflePlay)();
	STDMETHOD(StartPlugIn)(BSTR PlugInName);
	STDMETHOD(get_SkinName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_SkinName)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_CurrentSongTitle)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_CurrentSongFileName)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_SongTitle)(long PlayListPos, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_SongFileName)(long PlayListPos, /*[out, retval]*/ BSTR *pVal);
	STDMETHOD(get_PlayListCount)(/*[out, retval]*/ long *pVal);
	STDMETHOD(ChangeDirectory)(BSTR NewDir);
	STDMETHOD(AddFile)(BSTR FileName);
	STDMETHOD(get_PreAmpPosition)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_PreAmpPosition)(/*[in]*/ long newVal);
	STDMETHOD(get_EqPosition)(long Band, /*[out, retval]*/ long *pVal);
	STDMETHOD(put_EqPosition)(long Band, /*[in]*/ long newVal);
	STDMETHOD(get_PlayListPos)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_PlayListPos)(/*[in]*/ long newVal);
	STDMETHOD(SetPanning)(long PanIndex);
	STDMETHOD(get_Channels)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_Bitrate)(/*[out, retval]*/ long *pVal);
	STDMETHOD(get_SampleRate)(/*[out, retval]*/ long *pVal);
	STDMETHOD(SetVolume)(/*[in]*/ long newVal);
	STDMETHOD(get_CurrentPos)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_CurrentPos)(/*[in]*/ long newVal);
	STDMETHOD(get_Status)(/*[out, retval]*/ eWinampPlayStatus *pVal);
	STDMETHOD(put_Status)(/*[in]*/ eWinampPlayStatus newVal);
	STDMETHOD(Play)();
	STDMETHOD(ClearPlaylist)();
	STDMETHOD(get_Version)(/*[out, retval]*/ long *pVal);
	STDMETHOD(SendCommand)(eWinampCommand Code);
	STDMETHOD(Rewind5Secs)();
	STDMETHOD(FastFwd5Secs)();
	STDMETHOD(get_CurrentSongLength)(/*[out, retval]*/ long *pVal);
	void SongChange();
private:
	char m_TempBuffer[MAX_PATH+2];
	HMENU GetOptionMenu();
};

#endif //__APPLICATION_H_
