#ifdef __cplusplus
extern "C"{
#endif 

int __cdecl WinampCOMInit();
void __cdecl WinampCOMConfig();
void __cdecl WinampCOMQuit();

winampGeneralPurposePlugin plugin =
{
	GPPHDR_VER,
	"WinampCOM",
	WinampCOMInit,
	WinampCOMConfig,
	WinampCOMQuit,
};


#ifdef __cplusplus
}
#endif 
