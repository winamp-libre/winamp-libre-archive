// CppSamp.h : main header file for the CPPSAMP application
//

#if !defined(AFX_CPPSAMP_H__80B8383B_24BA_11D3_83C7_0008C782A257__INCLUDED_)
#define AFX_CPPSAMP_H__80B8383B_24BA_11D3_83C7_0008C782A257__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCppSampApp:
// See CppSamp.cpp for the implementation of this class
//

class CCppSampApp : public CWinApp
{
public:
	CCppSampApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCppSampApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCppSampApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CPPSAMP_H__80B8383B_24BA_11D3_83C7_0008C782A257__INCLUDED_)
