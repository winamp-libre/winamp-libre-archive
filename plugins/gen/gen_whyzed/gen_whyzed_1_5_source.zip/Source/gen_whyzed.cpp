

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
    *                                                                 *
    *   Whyzed Winamp Plugin 1.5                                      *
    *   Copyright � 2004 Sebastian Pipping <webmaster@hartwork.org>   *
    *                                                                 *
    *   --> http://www.hartwork.org                                   *
    *                                                                 *
    *                                                                 *
    *   This source code is released under LGPL.         2004-07-05   *
    *   See LGPL.txt for details.                                     *
    *                                                                 *
    \* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */



/*

	-- COMPILING INFO --
	linker libs:	MSVCRT.LIB kernel32.lib user32.lib
	linker opts:	/ALIGN:4096 /NODEFAULTLIB:LIBCMT.LIB

	threads:		single-threaded


	-- CALL ORDER --
	(1) winampGetGeneralPurposePlugin
	(2) whyzed_init
		<running>
	(3) whyzed_config
		<running>
	(4) whyzed_quit

*/



#define WIN32_LEAN_AND_MEAN

#include <windows.h>

#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#include <errno.h>

#include "Include\wa_ipc.h"
#include "Include\gen.h"

#include "resource.h"

#include "devil_compile.h"



#ifdef __cplusplus
#define EXPORT extern "C" __declspec( dllexport )
#else
#define EXPORT __declspec( dllexport )
#endif



#define			PLUGIN_NAME			"Whyzed Winamp Plugin"
#ifndef _DEBUG
	#define		PLUGIN_VERSION		"1.5"
#else
	#define		PLUGIN_VERSION		"1.5 DEBUG"
#endif



#define MAX_TITLE_LENGTH 30



bool g_bExchangeDefault		= false;
bool g_bExchangeDefault_OLD	= false;
bool g_bExchangeAVS			= true;
bool g_bExchangeAVS_OLD		= true;

bool g_bDiscardSettings		= false;
bool g_bMpexWinamp			= false;

char g_szWhyzedIniPath[ _MAX_PATH ]		= "";
char g_szWhyzedModulePath[ _MAX_PATH ]	= "";


HWND g_hEQUALIZER	= NULL;
HWND g_hPLAYLIST	= NULL;
HWND g_hVIDEO		= NULL;

WNDPROC wndproc_EQUALIZER_OLD	= NULL;
WNDPROC wndproc_MAIN_OLD		= NULL;
WNDPROC wndproc_PLAYLIST_OLD	= NULL;
WNDPROC wndproc_VIDEO_OLD		= NULL;


#pragma data_seg( ".SHARED" )

	bool g_bWaitingAVS			= false;
	bool g_bVisStartDetected	= false;

	HHOOK g_hCBT	= NULL;
	HWND g_hAVS	= NULL;

	WNDPROC wndproc_AVS_OLD		= NULL;

	winampGeneralPurposePlugin g_WHYZED;

#pragma data_seg()
#pragma comment( linker, "/section:.SHARED,rws" )


// ******************************************************** WritePrivateProfileInt *****
BOOL WritePrivateProfileInt( LPCTSTR lpAppName, LPCTSTR lpKeyName, int iValue, LPCTSTR lpFileName )
{
	TCHAR szBuffer[ 16 ];
	wsprintf( szBuffer, TEXT( "%i" ), iValue );
    return( WritePrivateProfileString( lpAppName, lpKeyName, szBuffer, lpFileName ) );
}


// ******************************************************************* wndproc_AVS *****
LRESULT CALLBACK wndproc_AVS( HWND hwnd, UINT message, WPARAM wp, LPARAM lp )
{
	switch( message )
	{
		case WM_KEYDOWN:
		case WM_KEYUP:
		{
			if( g_bExchangeAVS )
			{
				switch( wp )
				{
					case 'Y':
					{
						// Pass to MAIN
						PostMessage( g_WHYZED.hwndParent, message, ( g_bMpexWinamp ? ( g_bExchangeDefault ? 'Z' : 'Y' ) : ( g_bExchangeDefault ? 'Y' : 'Z' ) ), lp );
						return 0;
					}
					case 'Z':
					{
						wp = 'Y';
						break;
					}
				}
			}
			else
			{
				if( wp == 'Z' )
				{
					// Pass to MAIN
					PostMessage( g_WHYZED.hwndParent, message, ( g_bMpexWinamp ? ( g_bExchangeDefault ? 'Z' : 'Y' ) : ( g_bExchangeDefault ? 'Y' : 'Z' ) ), lp );
					return 0;
				}
			}
			break;
		}
		case WM_DESTROY:
		{
			g_bWaitingAVS = true;
			break;
		}
	}
	return CallWindowProc( wndproc_AVS_OLD, hwnd, message, wp, lp );
}


// **************************************************************** wndproc_COMMON *****
LRESULT CALLBACK wndproc_COMMON( HWND hwnd, UINT message, WPARAM wp, LPARAM lp )
{
	switch( message )
	{
		case WM_COMMAND:
		case WM_SYSCOMMAND:
		{
			if( wp == 40192 )
			{
				g_bVisStartDetected = true;
			}
			break;
		}
		case WM_KEYDOWN:
		case WM_KEYUP:
		{
			if( g_bExchangeDefault )
			{
				switch( wp )
				{
					case 'Y':
					{
						wp = 'Z';
						break;
					}
					case 'Z':
					{
						wp = 'Y';
						break;
					}
				}
				break;
			}
		}
		case WM_USER:
		{
			if( wp == 0 )
			{
				switch( lp )
				{
					case 0:
					case 505:
					{
						g_bVisStartDetected = true;
						break;
					}
				}
			}
			break;
		}
	}

	if( hwnd == g_WHYZED.hwndParent )
	{
		return CallWindowProc( wndproc_MAIN_OLD, hwnd, message, wp, lp );
	}
	else if( hwnd == g_hPLAYLIST )
	{
		return CallWindowProc( wndproc_PLAYLIST_OLD, hwnd, message, wp, lp );
	}
	else if( hwnd == g_hEQUALIZER )
	{
		return CallWindowProc( wndproc_EQUALIZER_OLD, hwnd, message, wp, lp );
	}
	else
	{
		return CallWindowProc( wndproc_VIDEO_OLD, hwnd, message, wp, lp );
	}
}


// **************************************************************** wndproc_CONFIG *****
BOOL CALLBACK wndproc_CONFIG( HWND hwnd, UINT message, WPARAM wp, LPARAM lp )
{
	switch( message )
	{
		case WM_INITDIALOG:
		{
			// Save current settings
			g_bExchangeDefault_OLD	= g_bExchangeDefault;
			g_bExchangeAVS_OLD		= g_bExchangeAVS;

			g_bDiscardSettings		= true;


			// Apply settings to checkboxes
			CheckDlgButton( hwnd, IDC_CHECK_DEFAULT, ( g_bExchangeDefault ? BST_CHECKED : BST_UNCHECKED ) );
			CheckDlgButton( hwnd, IDC_CHECK_AVS, ( g_bExchangeAVS ? BST_CHECKED : BST_UNCHECKED ) );


			// Set window title
			char szTitle[ 512 ] = "";
			wsprintf( szTitle, "%s %s", PLUGIN_NAME, PLUGIN_VERSION );
			SetWindowText( hwnd, szTitle );


			// Center window on parent
			RECT RectParent;
			GetWindowRect( GetForegroundWindow(), &RectParent );
			int ParentWidth = RectParent.right - RectParent.left;
			int ParentHeight = RectParent.bottom - RectParent.top;

			RECT Rectg_WHYZED;
			GetWindowRect( hwnd, &Rectg_WHYZED );
			int g_WHYZEDWidth = Rectg_WHYZED.right - Rectg_WHYZED.left;
			int g_WHYZEDHeight = Rectg_WHYZED.bottom - Rectg_WHYZED.top;

			int ox = ( ParentWidth - g_WHYZEDWidth ) / 2 + RectParent.left;
			int oy = ( ParentHeight - g_WHYZEDHeight ) / 2 + RectParent.top;

			MoveWindow( hwnd, ox, oy, g_WHYZEDWidth, g_WHYZEDHeight, false );


			return TRUE;
		}
		case WM_DESTROY:
		{
			if( g_bDiscardSettings )
			{
				// Restore old settings
				g_bExchangeDefault	= g_bExchangeDefault_OLD;
				g_bExchangeAVS		= g_bExchangeAVS_OLD;
			}
			break;
		}
		case WM_SYSCOMMAND:
		{
			switch( wp )
			{
				case SC_CLOSE:
				{
					EndDialog( hwnd, FALSE );
					return TRUE;
				}
			}
			break;
		}
		case WM_COMMAND:
		{
			switch( LOWORD( wp ) )
			{
				case IDC_CHECK_DEFAULT:
				{
					g_bExchangeDefault = ( BST_CHECKED == IsDlgButtonChecked( hwnd, IDC_CHECK_DEFAULT ) );
					break;
				}
				case IDC_CHECK_AVS:
				{
					g_bExchangeAVS = ( BST_CHECKED == IsDlgButtonChecked( hwnd, IDC_CHECK_AVS ) );
					break;
				}
				case IDOK:
				{
					g_bDiscardSettings = false;
				}
				case IDCANCEL:	// Button or [ESCAPE]
				{
					EndDialog( hwnd, FALSE );
					return TRUE;
				}
			}
			break;
		}
	}
	return 0;
}


// ****************************************************************** hookproc_cbt *****
LRESULT CALLBACK hookproc_cbt( int code, WPARAM wp, LPARAM lp )
{
	if( ( HCBT_CREATEWND == code ) && g_bWaitingAVS && g_bVisStartDetected )
	{
		// MSDN says WE CANNOT TRUST "CBT_CREATEWND"
		// so we use only the window handle
		// and get the class name using "GetClassName". (-> Q106079)

		HWND hwnd = ( HWND )wp;

		// Same process as our winamp?
		static DWORD g_dwPID_WINAMP = 0;
		if( !g_dwPID_WINAMP )
		{
			GetWindowThreadProcessId( g_WHYZED.hwndParent, &g_dwPID_WINAMP );
		}

		DWORD dwPID;
		GetWindowThreadProcessId( hwnd, &dwPID );

		if( dwPID == g_dwPID_WINAMP )
		{
			// AVS window?
			char szClass[ 7 ] = "";
			GetClassName( hwnd, szClass, 7 );
			if( !strcmp( szClass, "avswnd" ) )
			{
				g_hAVS = hwnd;

				// Hack WNDPROC of AVS
				wndproc_AVS_OLD = ( WNDPROC )GetWindowLong( g_hAVS, GWL_WNDPROC );
				if( wndproc_AVS_OLD != NULL )
				{
					SetWindowLong( g_hAVS, GWL_WNDPROC, ( LONG )wndproc_AVS );
				}

				g_bWaitingAVS		= false;
				g_bVisStartDetected	= false;
			}
		}
	}
	return CallNextHookEx( g_hCBT, code, wp, lp );
}


// ******************************************************************* whyzed_init *****
int whyzed_init()
{
	// Get Whyzed module path
	GetModuleFileName( g_WHYZED.hDllInstance, g_szWhyzedModulePath, sizeof( g_szWhyzedModulePath ) );

	// Set Whyzed description
	char * szWhyzedModuleFile = NULL;
	szWhyzedModuleFile = g_szWhyzedModulePath + strlen( g_szWhyzedModulePath );
	while( ( szWhyzedModuleFile >= g_szWhyzedModulePath ) && ( *szWhyzedModuleFile != '\\' ) )
	{
		szWhyzedModuleFile--;
	}
	szWhyzedModuleFile++;
	wsprintf( g_WHYZED.description, "%s %s (%s)", PLUGIN_NAME, PLUGIN_VERSION, szWhyzedModuleFile );

	// Get [gen_whyzed.ini] path
	strncpy( g_szWhyzedIniPath, g_szWhyzedModulePath, szWhyzedModuleFile - g_szWhyzedModulePath );
	strcat( g_szWhyzedIniPath, "gen_whyzed.ini" );

	// Read config
	g_bExchangeAVS = ( bool )GetPrivateProfileInt( PLUGIN_VERSION, "avs", 1, g_szWhyzedIniPath );
	UINT iTemp = GetPrivateProfileInt( PLUGIN_VERSION, "default", -1, g_szWhyzedIniPath );
	if( iTemp == -1 )
	{
		// Not found -> Check for German language pack

		// Get [Winamp.ini] path
		char szWinampIniPath[ _MAX_PATH ] = "";
		szWhyzedModuleFile -= 2;
		while( ( szWhyzedModuleFile >= g_szWhyzedModulePath ) && ( *szWhyzedModuleFile != '\\' ) )
		{
			szWhyzedModuleFile--;
		}
		szWhyzedModuleFile++;
		strncpy( szWinampIniPath, g_szWhyzedModulePath, szWhyzedModuleFile - g_szWhyzedModulePath );
		strcat( szWinampIniPath, "Winamp.ini" );

		char szLangPack[ _MAX_FNAME ] = "";
		GetPrivateProfileString( "Winamp", "langpack", "", szLangPack, sizeof( szLangPack ), szWinampIniPath );
		_strlwr( szLangPack );	// Lower-case
		if( strstr( szLangPack, "deutsch" ) || strstr( szLangPack, "german" ) )
		{
			// Does the file exist?
			char szLangPackPath[ _MAX_PATH ] = "";
			strncpy( szLangPackPath, g_szWhyzedModulePath, szWhyzedModuleFile - g_szWhyzedModulePath );
			strcat( szLangPackPath, szLangPack );
			int iLangFile = _open( szLangPackPath, _O_RDONLY );
			if( iLangFile == -1 )
			{
				// Error
				switch( errno )
				{
					case EACCES:
					{
						// Found -> Don't exchange
						g_bExchangeDefault = false;
						break;
					}
					case ENOENT:
					{
						// Missing -> Exchange
						g_bExchangeDefault = true;
						break;
					}
				}
			}
			else
			{
				// Success -> Found -> Don't exchange
				g_bExchangeDefault = false;
				_close( iLangFile );
			}
		}
		else
		{
			// Missing -> Exchange
			g_bExchangeDefault = true;
		}
	}
	else
	{
		g_bExchangeDefault = ( bool )iTemp;
	}

	// Hack WNDPROC of MAIN
	wndproc_MAIN_OLD = ( WNDPROC )GetWindowLong( g_WHYZED.hwndParent, GWL_WNDPROC );
	if( wndproc_MAIN_OLD != NULL )
	{
		SetWindowLong( g_WHYZED.hwndParent, GWL_WNDPROC, ( LONG )wndproc_COMMON );
	}

	// Find PLAYLIST, EQUALIZER and VIDEO
	int iFound = 0;
	DWORD g_dwPID_WINAMP;
	GetWindowThreadProcessId( g_WHYZED.hwndParent, &g_dwPID_WINAMP );
	DWORD dwPID;
	char szClass[ MAX_TITLE_LENGTH ] = "";
	HWND hwnd = GetWindow( GetDesktopWindow(), GW_CHILD );
	while( hwnd != NULL )
	{
		GetWindowThreadProcessId( hwnd, &dwPID );
		if( dwPID == g_dwPID_WINAMP )
		{
			GetClassName( hwnd, szClass, MAX_TITLE_LENGTH );

			// "Winamp PE"
			if( !strcmp( szClass, "Winamp PE" ) )
			{
				char szTitle[ MAX_TITLE_LENGTH ] = "";
				GetWindowText( hwnd, szTitle, MAX_TITLE_LENGTH );
				if( !strcmp( szTitle, "Winamp Playlist-Editor" ) )
				{
					// Seems to be MPeX-Winamp
					g_bMpexWinamp = true;

					if( iTemp == -1 )
					{
						g_bExchangeDefault = false;
					}
				}
				else
				{
					// Normal Winamp
					g_bMpexWinamp = false;
				}
				g_hPLAYLIST = hwnd;
				iFound++;
			}

			// "Winamp EQ"
			else if( !strcmp( szClass, "Winamp EQ" ) )
			{
				g_hEQUALIZER = hwnd;
				iFound++;
			}

			// "Winamp Video"
			else if( !strcmp( szClass, "Winamp Video" ) )
			{
				g_hVIDEO = hwnd;
				iFound++;
			}

			// Early breakout
			if( iFound == 3 )
			{
				break;	// ...out of while
			}
		}
		hwnd = GetWindow( hwnd, GW_HWNDNEXT );
	}

	// Hack WNDPROC of PLAYLIST
	wndproc_PLAYLIST_OLD = ( WNDPROC )GetWindowLong( g_hPLAYLIST, GWL_WNDPROC );
	if( wndproc_PLAYLIST_OLD != NULL )
	{
		SetWindowLong( g_hPLAYLIST, GWL_WNDPROC, ( LONG )wndproc_COMMON );
	}

	// Hack WNDPROC of EQUALIZER
	wndproc_EQUALIZER_OLD = ( WNDPROC )GetWindowLong( g_hEQUALIZER, GWL_WNDPROC );
	if( wndproc_EQUALIZER_OLD != NULL )
	{
		SetWindowLong( g_hEQUALIZER, GWL_WNDPROC, ( LONG )wndproc_COMMON );
	}

	// Hack WNDPROC of VIDEO
	wndproc_VIDEO_OLD = ( WNDPROC )GetWindowLong( g_hVIDEO, GWL_WNDPROC );
	if( wndproc_VIDEO_OLD != NULL )
	{
		SetWindowLong( g_hVIDEO, GWL_WNDPROC, ( LONG )wndproc_COMMON );
	}


	// Install CBT hook to detect AVS
	g_bWaitingAVS = true;
	g_hCBT = SetWindowsHookEx( WH_CBT, &hookproc_cbt, g_WHYZED.hDllInstance, 0 );


	return 0;
}


// ***************************************************************** whyzed_config *****
void whyzed_config()
{
	DialogBox( g_WHYZED.hDllInstance, MAKEINTRESOURCE( IDD_DIALOG_CONFIG ), GetForegroundWindow(), wndproc_CONFIG );

}


// ******************************************************************* whyzed_quit *****
void whyzed_quit()
{
	// REMOVE HOOK
	if( g_hCBT != NULL ) UnhookWindowsHookEx( g_hCBT );

	// Write config to [gen_whyzed.ini]
	WritePrivateProfileInt( PLUGIN_VERSION, "default",	( int )g_bExchangeDefault,	g_szWhyzedIniPath );
	WritePrivateProfileInt( PLUGIN_VERSION, "avs",		( int )g_bExchangeAVS,		g_szWhyzedIniPath );

	// No leaks...
	delete [] g_WHYZED.description;
}


// **************************************************** winampGeneralPurposePlugin *****
EXPORT winampGeneralPurposePlugin * winampGetGeneralPurposePlugin()
{
	g_WHYZED.version		= GPPHDR_VER;
	g_WHYZED.description	= new char[ 512 ];
	g_WHYZED.init			= &whyzed_init;
	g_WHYZED.config			= &whyzed_config;
	g_WHYZED.quit			= &whyzed_quit;
	g_WHYZED.hwndParent		= NULL;
	g_WHYZED.hDllInstance	= NULL;

	return &g_WHYZED;
}