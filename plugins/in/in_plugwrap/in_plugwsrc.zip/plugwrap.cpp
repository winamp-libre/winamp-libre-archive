/*

  PlugWrap, WinAMP input-plugin wrapper
  v. 000622
  Mic, 2000

*/


#include <windows.h>
#include "in2.h"


typedef In_Module*(*pfnwinampGetInModule2)();
typedef Out_Module*(*pfnwinampGetOutModule)();

HMODULE outPlug,inPlug;
BOOL inIsLoaded = FALSE,outIsLoaded = FALSE;
int isPlaying = 0;
int paused = 0;
int volume=128;
char szBuf[300]; 
HWND plugParent=0;
char eqData[10];
In_Module *in_mod;
Out_Module *out_mod;
pfnwinampGetInModule2 winampGetInModule2;
pfnwinampGetOutModule winampGetOutModule;
//pfnSetConfig SetConfig;
//pfnGetConfig GetConfig;


// Empty functions for WinAMP functionality.
void SAVSAInit(int,int){}
void SAVSADeInit(){}
void SAAddPCMData(void*,int,int,int){}
int SAGetMode(){return 0;}
void SAAdd(void*,int,int){}
void VSAAddPCMData(void*,int,int,int){}
int VSAGetMode(int*,int*){return 0;}
void VSAAdd(void*,int){}
void VSASetInfo(int,int){}
int dsp_isactive(){return 0;}
int dsp_dosamples(short int*,int,int,int,int){return 0;}
void SetInfo(int,int,int,int){}






BOOL WINAPI LibMain(HINSTANCE hDLLInst, DWORD fdwReason, LPVOID lpvReserved)
{
 switch (fdwReason)
 {
  case DLL_PROCESS_ATTACH:
   return TRUE;
   break;
  case DLL_PROCESS_DETACH:
   break;
  case DLL_THREAD_ATTACH:
   break;
  case DLL_THREAD_DETACH:
   break;
 }
 return TRUE;
}




INT XPlayOpen(char *fname)
{
  if (!outIsLoaded)
  {
   if((outPlug=LoadLibrary("out_wave.dll"))==NULL)
	{
		MessageBox(NULL,"A required .DLL file, OUT_WAVE.DLL, was not found.","Error Starting Program",MB_ICONEXCLAMATION);
		return 1;
	}
	winampGetOutModule=(pfnwinampGetOutModule)GetProcAddress(outPlug,"winampGetOutModule");
	out_mod = winampGetOutModule();
	out_mod->hMainWindow = plugParent;
	out_mod->hDllInstance = outPlug;
	out_mod->Init();
    outIsLoaded = TRUE;
  }

  if (!inIsLoaded)
  {
    if((inPlug=LoadLibrary(fname))==NULL)
	{
        wsprintf(szBuf,"A requried file, %s, was not found.",fname);
		MessageBox(NULL,szBuf,"Error Loading Plugin",MB_ICONEXCLAMATION);
		return 1;
	}
	winampGetInModule2=(pfnwinampGetInModule2)GetProcAddress(inPlug,"winampGetInModule2");
	//SetConfig = (pfnSetConfig)GetProcAddress(inPlug,"SetConfig");
	//GetConfig = (pfnGetConfig)GetProcAddress(inPlug,"GetConfig");
	in_mod = winampGetInModule2();
	in_mod->hMainWindow = plugParent;
	in_mod->hDllInstance = inPlug;
	in_mod->SAVSAInit = &SAVSAInit;
	in_mod->SAVSADeInit = &SAVSADeInit;
	in_mod->SAAddPCMData = &SAAddPCMData;
	in_mod->SAGetMode = &SAGetMode;
	in_mod->SAAdd = &SAAdd;
	in_mod->VSAAddPCMData = &VSAAddPCMData;
	in_mod->VSAGetMode = &VSAGetMode;
	in_mod->VSAAdd = &VSAAdd;
	in_mod->VSASetInfo = &VSASetInfo;
	in_mod->dsp_isactive = &dsp_isactive;
	in_mod->dsp_dosamples = &dsp_dosamples;
	in_mod->SetInfo = &SetInfo;
	in_mod->outMod = out_mod;
	in_mod->Init();
	//dwControlID = GetMixerControlID(uMixerID,MIXERLINE_COMPONENTTYPE_SRC_WAVEOUT,MIXERCONTROL_CONTROLTYPE_VOLUME);
	//in_mod->SetVolume(GetMixerControlValue(uMixerID,dwControlID)/256);
    in_mod->SetVolume(volume);
    
	/*GetConfig(&cfg);
	cfg.OldBRE = 0;
	cfg.NoTime = 1;
	SetConfig(&cfg);*/
    
  }
	return 0;
}


/*
VOID GetXPlugCfg(stConfig *lpcfg)
{
	GetConfig(lpcfg);
}

VOID SetXPlugCfg(stConfig *lpcfg)
{
	SetConfig(lpcfg);
}
*/


VOID SetXPlugParent(HWND prnt)
{
	if (inIsLoaded)
  	  in_mod->hMainWindow = prnt;
  	if (outIsLoaded)
 	   out_mod->hMainWindow = prnt;
	plugParent = prnt;
}


BOOL XPlayClose()
{
    if (inIsLoaded)
	{
	 in_mod->Quit();
	 FreeLibrary(inPlug);
    }
	 return TRUE;
}

VOID wavOutClose()
{
	if (outIsLoaded)
	{
	   out_mod->Quit();
	   FreeLibrary(outPlug);
	   outIsLoaded = FALSE;
	}
}


INT InitXPlug(char *plugName)
{
 if (!inIsLoaded)
 {
  if (XPlayOpen(plugName))
  {
   inIsLoaded = FALSE;
   return 1;
  }
 }
 inIsLoaded = TRUE;
 return 0;
}


BOOL LoadX(char *fname)
{
 return TRUE;
}


VOID StopX()
{
 if (isPlaying)
 {
  in_mod->Stop();
  isPlaying = 0;
 }
}


INT PlayX(char *fname)
{
  if (inIsLoaded && outIsLoaded)
  {
   if (isPlaying)
 	 StopX();
   if (in_mod->Play(fname))
   {
	   isPlaying = 0;
	   return 1;
   }
   isPlaying = 1;
  }
 return 0;
}


VOID PauseX()
{
	if (!paused)
		in_mod->Pause();
	else
		in_mod->UnPause();
	paused = (!paused);
}


VOID DeInitXPlug(int closeOut)
{
 StopX();
 if (inIsLoaded)
 {
  if (XPlayClose()) {}
   inIsLoaded = FALSE;
 }
 if (closeOut)
   wavOutClose();
}


INT GetXLength()
{
	return in_mod->GetLength();
}


INT GetXOutputTime()
{
	return in_mod->GetOutputTime();
}

VOID SetXOutputTime(int mstm)
{
	in_mod->SetOutputTime(mstm);
}


//Set output volume (0 - 255)
VOID SetXVolume(int vol)
{
	in_mod->SetVolume(vol);
	volume = vol; 
}

//Set pan (-127 - 127) 
VOID SetXPan(int pan)
{
	in_mod->SetPan(pan);
}


VOID SetXEqualizer(int on,char *data,int preamp)
{
int i;
 for (i=0;i<10;i++)
 {
	eqData[i] = (*(data+i));
 }
 if (inIsLoaded)
  in_mod->EQSet(on,eqData,preamp);
}


 