#include "ac3thread.h"


DecoderThread::DecoderThread(In_Module *_mod):
Thread(true)
{
  spk      = AC3Speakers(MODE_STEREO);
  sink_id  = SINK_DSOUND;
  sink     = 0;
  mod      = _mod;

  seek_pos = -1;
  state    = state_stop;

  ev_play  = CreateEvent(0, true, false, 0);
  ev_stop  = CreateEvent(0, true, true,  0);

  resume();
}

DecoderThread::~DecoderThread()
{
  stop();
  f_terminate = true;               
  state = state_stop;
  SetEvent(ev_play);

  CloseHandle(ev_play);
  CloseHandle(ev_stop);

  if (sink) delete sink;
}

AudioSink *
DecoderThread::create_sink(int sink_id)
{
  switch (sink_id)
  {
    case SINK_WINAMP: return new WinampSink(mod); break;
    case SINK_DSOUND: return new DSSink(mod->hMainWindow); break;
    default: return 0;
  }
}

STDMETHODIMP 
DecoderThread::get_cpu_load(double *cpu_load)
{
  if (cpu_load)
    *cpu_load = cpu.usage();
  return S_OK;
}

STDMETHODIMP 
DecoderThread::get_config_file(char *_filename, int _size)
{
  if (_filename)
    *filename = 0;

  return S_OK;
}

STDMETHODIMP 
DecoderThread::get_speakers(AC3Speakers *_spk)
{
  if (_spk)
    *_spk = spk;
  return S_OK;
}

STDMETHODIMP 
DecoderThread::set_speakers(AC3Speakers  _spk)
{
  if (spk == _spk)
  {
    spk = _spk;
    return S_OK;
  }
  if (!sink)
  {
    spk = _spk;
    return S_OK;
  }

  if (sink->is_open())
  {
    if (!sink->query(_spk, bsi.sample_rate))
      return E_FAIL;

    bool old_ev_play = (WaitForSingleObject(ev_play, 0) == WAIT_OBJECT_0);
    ResetEvent(ev_play);
    if (WaitForSingleObject(ev_stop, 1000) != WAIT_OBJECT_0)
    {
      if (old_ev_play) 
        SetEvent(ev_play);

      return E_FAIL;
    }

    spk = _spk;
    sink->close();
    sink->open(spk, bsi.sample_rate);
    sink->get_order(&spk);
    set_mode(spk);
    switch (spk.fmt)
    {
      case FORMAT_PCM16: mixer.level = 32767.0;       break;
      case FORMAT_PCM24: mixer.level = 8388607.0;     break;
      case FORMAT_PCM32: mixer.level = 2147483647.0;  break;
      case FORMAT_FLOAT: mixer.level = 1.0;           break;
    }

    state = state_start;
    if (old_ev_play) 
      SetEvent(ev_play);
  }
  else
  {
    if (!sink->query(_spk, 48000))
      return E_FAIL;
    spk = _spk;
  }

  return S_OK;
}

STDMETHODIMP 
DecoderThread::query_speakers(AC3Speakers  _spk, bool *supported)
{
  if (supported)
    *supported = sink->query(_spk, 48000);
  return S_OK;
}

STDMETHODIMP 
DecoderThread::get_sink(int *_sink)
{
  if (_sink)
    *_sink = sink_id;
  return S_OK;
}

STDMETHODIMP 
DecoderThread::set_sink(int  _sink)
{
  if (!sink)
  {
    sink_id = _sink;
    sink = create_sink(sink_id);
    return sink? S_OK: E_FAIL;
  }

  AudioSink  *new_sink = create_sink(_sink);
  AC3Speakers new_spk  = spk;
  if (!new_sink) return E_FAIL;

  new_sink->set_volume(sink->get_volume());
  new_sink->set_pan(sink->get_pan());

  if (sink->is_open())
  {
    if (!new_sink->query(new_spk, bsi.sample_rate))
      if (!new_sink->query(AC3Speakers(MODE_STEREO), bsi.sample_rate))
      {
        delete new_sink;
        return E_FAIL;
      }
      else
        new_spk = AC3Speakers(MODE_STEREO);

    bool old_ev_play = (WaitForSingleObject(ev_play, 0) == WAIT_OBJECT_0);
    ResetEvent(ev_play);

    if (WaitForSingleObject(ev_stop, 1000) != WAIT_OBJECT_0)
    {
      if (old_ev_play) 
        SetEvent(ev_play);

      delete new_sink;
      return E_FAIL;
    }

    sink->close();
    delete sink;
    sink_id = _sink;
    sink = new_sink;
    spk = new_spk;

    sink->open(spk, bsi.sample_rate);
    sink->get_order(&spk);
    set_mode(spk);

    switch (spk.fmt)
    {
      case FORMAT_PCM16: mixer.level = 32767.0;       break;
      case FORMAT_PCM24: mixer.level = 8388607.0;     break;
      case FORMAT_PCM32: mixer.level = 2147483647.0;  break;
      case FORMAT_FLOAT: mixer.level = 1.0;           break;
    }
    state = state_start;

    if (old_ev_play)
      SetEvent(ev_play);
  }
  else
  {
    if (!new_sink->query(new_spk, 48000))
      if (!new_sink->query(AC3Speakers(MODE_STEREO), 48000))
      {
        delete new_sink;
        return E_FAIL;
      }
      else
        spk = AC3Speakers(MODE_STEREO);

    delete sink;
    sink_id = _sink;
    sink = new_sink;
  }

  return S_OK;
}




bool 
DecoderThread::play(const char *_filename)
{
  if (!stop()) return false;

  // open file
  open(_filename);
  if (!probe()) return false;

  if (!sink)
    if FAILED(set_sink(sink_id))
      return false;

  if (!sink->open(spk, bsi.sample_rate)) 
    return false;

  sink->get_order(&spk);
  set_mode(spk);
  switch (spk.fmt)
  {
    case FORMAT_PCM16: mixer.level = 32767.0;       break;
    case FORMAT_PCM24: mixer.level = 8388607.0;     break;
    case FORMAT_PCM32: mixer.level = 2147483647.0;  break;
    case FORMAT_FLOAT: mixer.level = 1.0;           break;
  }

  // prepare
  mod->SetInfo(bsi.bitrate / 1000, bsi.sample_rate / 1000, 2, 1);
  reset();

  // run!
  state = state_start;
  SetEvent(ev_play);
  return true;
}

bool 
DecoderThread::stop()
{
  // syncronisation
  ResetEvent(ev_play);
  WaitForSingleObject(ev_stop, 2000);

  // reset all
  if (sink)
    if (sink->is_open())
    {
      sink->flush(0);
      sink->close();
    }

  pos      = 0;
  seek_pos = -1;
  state = state_stop;
  
  close();
  reset();

  return true;
}


DWORD 
DecoderThread::process()
{
  WORD out_buf[1536 * 2];  // SPDIF output buffer

  cpu.start_measure();
  while (1)
  {
    // syncronization
    SetEvent(ev_stop);
    WaitForSingleObject(ev_play, INFINITE);
    ResetEvent(ev_stop);

    // termination
    if (f_terminate)
      return 0;

    // decode
    if (seek_pos != -1)
    {
      pos      = seek_pos;
      seek_pos = -1;

      FileDecoder::seek(int(pos));
      sink->flush(int(pos));
      state = state_start;
    }

    switch (state)
    {
    case state_start:
      state = state_read;
      break;

    case state_stop:
      ResetEvent(ev_play);
      break;

    case state_flush:
      Sleep(sink->get_lag_time());
      PostMessage(mod->hMainWindow, WM_WA_MPEG_EOF, 0, 0);
      state = state_stop;
      break;

    case state_read:
      if (eof())
      {
        state = state_flush;
        break;
      }

      if (!spk.spdif)
      {
        if (!block()) break;
        state = state_write;
      }
      else
      {
        if (!frame()) break;

        memset(out_buf, 0, sizeof(out_buf));

        out_buf[0] = 0xf872;            // Pa  sync word 1 
        out_buf[1] = 0x4e1f;            // Pb  sync word 2 
        out_buf[2] = 0x0001;            // Pc  burst-info (data-type = AC3) 
        out_buf[3] = bsi.frame_size*8;  // Pd  length-code (bits)     
        _swab((char *)buf, (char *)(out_buf+4), bsi.frame_size);

        state = state_write;
      }

    case state_write:
      if (!spk.spdif)
      {
        if (sink->can_write())
        {
          sink->write((const sample_buffer_t *)&samples);
          pos += 256000.0 / double(bsi.sample_rate);
          state = state_read;
        }
        else
          Sleep(50);
      }
      else
      {
        if (sink->can_write_raw(sizeof(out_buf)))
        {
          sink->write_raw((uint8_t*)out_buf, sizeof(out_buf));
          pos += 256000.0 * 6 / double(bsi.sample_rate);
          state = state_read;
        }
        else
          Sleep(50);
        break;
      }
    }
  }
  cpu.stop_measure();
  return 0;
}
