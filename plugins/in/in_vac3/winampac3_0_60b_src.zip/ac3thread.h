#ifndef AC3THREAD_H
#define AC3THREAD_H

#include "winamp.h"
#include "ac3decoder.h"
#include "sink.h"
#include "thread.h"
#include "cpu.h"

///////////////////////////////////////////////////////////////////////////////
//
// Decoder Thread
//
///////////////////////////////////////////////////////////////////////////////

class DecoderThread : public DecoderControl, public Thread
{
protected:
  AC3Speakers spk;

  int         sink_id;
  AudioSink  *sink;

  In_Module  *mod;
  CPUMeter    cpu;

  HANDLE      ev_play;
  HANDLE      ev_stop;

  int         seek_pos;
  double      pos;

  enum { state_start, state_stop, state_flush, state_read, state_write }
              state;

  AudioSink   *create_sink(int sink_id);

  STDMETHODIMP get_cpu_load(double *cpu_load);
  STDMETHODIMP get_config_file(char *filename, int size);

  STDMETHODIMP get_speakers(AC3Speakers *spk);
  STDMETHODIMP set_speakers(AC3Speakers  spk);
  STDMETHODIMP query_speakers(AC3Speakers spk, bool *supported);

  STDMETHODIMP get_sink(int *_sink);
  STDMETHODIMP set_sink(int  _sink);

public:
  DecoderThread(In_Module *mod);
  ~DecoderThread();

  DWORD process();

  void  seek(int _seek_pos) { seek_pos = _seek_pos; }
  int   get_pos()           { return int(pos);      }

  bool play(const char *filename);
  bool stop();

  void pause()       { if (sink) sink->pause(); }
  void unpause()     { if (sink) sink->unpause(); }
  bool is_paused()   { return sink? sink->is_paused(): false; }

  void set_volume(int _volume)  { if (sink) sink->set_volume(_volume);  }
  void set_pan(int _pan)        { if (sink) sink->set_pan(_pan);        }
  int  get_lag_time()           { return sink? sink->get_lag_time(): 0; }
};


#endif
