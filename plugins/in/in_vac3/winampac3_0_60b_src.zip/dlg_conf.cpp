#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <commctrl.h>
#include <math.h>
#include "vac3dec\defs.h"
#include "registry.h"
#include "dlg_conf.h"
#include "resource.h"


#define CONF_SPEAKERS 1
#define CONF_INFO     2
#define CONF_GAINS    4
#define CONF_DRC      8
#define CONF_MATRIX   16
#define CONF_DELAY    32
#define CONF_EQ       64


const double min_gain_level  = -20.0;
const double max_gain_level  = +20.0;
const double min_level = -50.0;
const double min_eq_level = -150;
const int ticks = 5;
const double sonic_speed = 330; // m/s

const int matrix_control[6][6] =
{
  { IDC_EDT_L_L,   IDC_EDT_C_L,   IDC_EDT_R_L,   IDC_EDT_SL_L,   IDC_EDT_SR_L,   IDC_EDT_LFE_L },
  { IDC_EDT_L_C,   IDC_EDT_C_C,   IDC_EDT_R_C,   IDC_EDT_SL_C,   IDC_EDT_SR_C,   IDC_EDT_LFE_C },
  { IDC_EDT_L_R,   IDC_EDT_C_R,   IDC_EDT_R_R,   IDC_EDT_SL_R,   IDC_EDT_SR_R,   IDC_EDT_LFE_R },
  { IDC_EDT_L_SL,  IDC_EDT_C_SL,  IDC_EDT_R_SL,  IDC_EDT_SL_SL,  IDC_EDT_SR_SL,  IDC_EDT_LFE_SL },
  { IDC_EDT_L_SR,  IDC_EDT_C_SR,  IDC_EDT_R_SR,  IDC_EDT_SL_SR,  IDC_EDT_SR_SR,  IDC_EDT_LFE_SR },
  { IDC_EDT_L_LFE, IDC_EDT_C_LFE, IDC_EDT_R_LFE, IDC_EDT_SL_LFE, IDC_EDT_SR_LFE, IDC_EDT_LFE_LFE }
};

int ctl_eq_slider[9] = { IDC_EQ1, IDC_EQ2, IDC_EQ3, IDC_EQ4,
                         IDC_EQ5, IDC_EQ6, IDC_EQ7, IDC_EQ8, IDC_EQ9 };

int ctl_eq_edt[9]    = { IDC_EDT_EQ1, IDC_EDT_EQ2, IDC_EDT_EQ3, IDC_EDT_EQ4,
                         IDC_EDT_EQ5, IDC_EDT_EQ6, IDC_EDT_EQ7, IDC_EDT_EQ8, IDC_EDT_EQ9 };

int ctl_eq_level[9]  = { IDC_LEVEL_EQ1, IDC_LEVEL_EQ2, IDC_LEVEL_EQ3, IDC_LEVEL_EQ4,
                         IDC_LEVEL_EQ5, IDC_LEVEL_EQ6, IDC_LEVEL_EQ7, IDC_LEVEL_EQ8, IDC_LEVEL_EQ9 };

int ctl_delay[6]     = { IDC_EDT_DL, IDC_EDT_DC, IDC_EDT_DR, IDC_EDT_DSL, IDC_EDT_DSR, IDC_EDT_DLFE };


#define dlg_printf(dlg, ctrl, format, params)                     \
{                                                                 \
  char buf[255];                                                  \
  sprintf(buf, format, ##params);                                 \
  SendDlgItemMessage(dlg, ctrl, WM_SETTEXT, 0, (LONG)(LPSTR)buf); \
}

#define value2db(value) ((value > 0)? log10(value)*20.0: 0)
#define db2value(db)    pow(10.0, (db)/20.0)

bool delete_reg_key(const char *name, HKEY root)
{
  HKEY  key;
  char  buf[256];
  DWORD len;

  if (RegOpenKeyEx(root, name, 0, KEY_READ | KEY_WRITE, &key) != ERROR_SUCCESS)
    return false;

  len = 256;
  while (RegEnumKeyEx(key, 0, (LPTSTR)buf, &len, 0, 0, 0, 0) == ERROR_SUCCESS)
  {
    len = 256;
    if (!delete_reg_key(buf, key))
    {
      RegCloseKey(key);
      return false;
    }
  }

  len = 256;
  while (RegEnumValue(key, 0, (LPTSTR)buf, &len, 0, 0, 0, 0) == ERROR_SUCCESS)
  {
    len = 256;
    if (RegDeleteValue(key, buf) != ERROR_SUCCESS)
    {
      RegCloseKey(key);
      return false;
    }
  }

  RegCloseKey(key);
  RegDeleteKey(root, name);
  return true;
}

const char *ac3_modes[] = 
{
  "1+1 - Dual mono",
  "1/0 - mono",
  "2/0 - stereo",
  "3/0 - 3 front",
  "2/1 - surround",
  "3/1 - surround",
  "2/2 - quadro",
  "3/2 - 5 channels",
  "1+1+LFE Dual mono+LFE",
  "1/0+LFE 1.1 mono",
  "2/0+LFE 2.1 stereo",
  "3/0+LFE 3.1 front",
  "2/1+LFE 3.1 surround",
  "3/1+LFE 4.1 surround",
  "2/2+LFE 4.1 quadro",
  "3/2+LFE 5.1 channels",
  "Dolby Surround",
  "Dolby Surround + LFE",
};

///////////////////////////////////////////////////////////////////////////////
// Speakers list definition
///////////////////////////////////////////////////////////////////////////////

const char *spklist_name[] = 
{
  "1/0 - mono",
  "2/0 - stereo",
  "3/0 - 3 front",
  "2/1 - surround",
  "3/1 - surround",
  "2/2 - quadro",
  "3/2 - 5 channels",
  "1/0+SW 1.1 mono",
  "2/0+SW 2.1 stereo",
  "3/0+SW 3.1 front",
  "2/1+SW 3.1 surround",
  "3/1+SW 4.1 surround",
  "2/2+SW 4.1 quadro",
  "3/2+SW 5.1 channels",
  "Dolby Surround/ProLogic",
  "Dolby ProLogic II",
  "SPDIF",
};

const AC3Speakers spklist_spk[] = 
{
  AC3Speakers(MODE_1_0),
  AC3Speakers(MODE_2_0),
  AC3Speakers(MODE_3_0),
  AC3Speakers(MODE_2_1),
  AC3Speakers(MODE_3_1),
  AC3Speakers(MODE_2_2),
  AC3Speakers(MODE_3_2),
  AC3Speakers(MODE_1_0 | MODE_LFE),
  AC3Speakers(MODE_2_0 | MODE_LFE),
  AC3Speakers(MODE_3_0 | MODE_LFE),
  AC3Speakers(MODE_2_1 | MODE_LFE),
  AC3Speakers(MODE_3_1 | MODE_LFE),
  AC3Speakers(MODE_2_2 | MODE_LFE),
  AC3Speakers(MODE_3_2 | MODE_LFE),
  AC3Speakers(MODE_STEREO, DOLBY_SURROUND),
  AC3Speakers(MODE_STEREO, DOLBY_PROLOGICII),
  AC3Speakers(MODE_STEREO, NO_DOLBY, FORMAT_PCM16, SPDIF_AUTO)
};

int spk2list_tbl[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
int list2spk_tbl[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };

AC3Speakers list2spk(int list)
{
  return spklist_spk[list2spk_tbl[list]];
}

int spk2list(AC3Speakers spk)
{
  if (spk.spdif)              return spk2list_tbl[16];

  switch (spk.dolby)
  {
    case DOLBY_SURROUND:      return spk2list_tbl[14];
    case DOLBY_PROLOGIC:      return spk2list_tbl[14];
    case DOLBY_PROLOGICII:    return spk2list_tbl[15];
  }

  switch (spk.mode)
  {
    case MODE_1_0:            return spk2list_tbl[0];
    case MODE_2_0:            return spk2list_tbl[1];
    case MODE_3_0:            return spk2list_tbl[2];
    case MODE_2_1:            return spk2list_tbl[3];
    case MODE_3_1:            return spk2list_tbl[4];
    case MODE_2_2:            return spk2list_tbl[5];
    case MODE_3_2:            return spk2list_tbl[6];
                                     
    case MODE_1_0 | MODE_LFE: return spk2list_tbl[7];
    case MODE_2_0 | MODE_LFE: return spk2list_tbl[8];
    case MODE_3_0 | MODE_LFE: return spk2list_tbl[9];
    case MODE_2_1 | MODE_LFE: return spk2list_tbl[10];
    case MODE_3_1 | MODE_LFE: return spk2list_tbl[11];
    case MODE_2_2 | MODE_LFE: return spk2list_tbl[12];
    case MODE_3_2 | MODE_LFE: return spk2list_tbl[13];
  }                             
  
  return 1;
}


///////////////////////////////////////////////////////////////////////////////
// Formats list definition
///////////////////////////////////////////////////////////////////////////////

const char *fmtlist[] = 
{
  "PCM 16bit",
  "PCM 24bit",
  "PCM 32bit",
  "PCM Float"
};

int list2fmt(int list)
{
  switch (list)
  {
    case 0:  return FORMAT_PCM16;
    case 1:  return FORMAT_PCM24;
    case 2:  return FORMAT_PCM32;
    case 3:  return FORMAT_FLOAT;
    default: return FORMAT_PCM16;
  }
}

int fmt2list(int fmt)
{
  switch (fmt)
  {
    case FORMAT_PCM16: return 0;
    case FORMAT_PCM24: return 1;
    case FORMAT_PCM32: return 2;
    case FORMAT_FLOAT: return 3;
    default: return 0;
  }
}

///////////////////////////////////////////////////////////////////////////////
// Sink list definition
///////////////////////////////////////////////////////////////////////////////

const char *sinklist[] = 
{
  "Direct Sound",
  "Winamp output"
};

int list2sink(int list)
{
  switch (list)
  {
    case 0:  return SINK_DSOUND;
    case 1:  return SINK_WINAMP;
    default: return SINK_DSOUND;
  }
}

int sink2list(int fmt)
{
  switch (fmt)
  {
    case SINK_DSOUND: return 0;
    case SINK_WINAMP: return 1;
    default: return 0;
  }
}

///////////////////////////////////////////////////////////////////////////////
// Delay units
///////////////////////////////////////////////////////////////////////////////

char *units_list[] =
{
  "Samples",
  "Millisecs",
  "Meters",
  "Centimeters",
  "Foots",
  "Inches"
};

double unit2factor(int unit, int sample_rate) 
// returns factor to convert delay value from user selected units to samples
{
  if (!sample_rate) sample_rate = 48000;
  switch (unit)
  {
    case 0: return 1;
    case 1: return double(sample_rate) /*[Hz]*/ / 1000.0; /*[ms/sec]*/
    case 2: return -1.0 * double(sample_rate) /*[Hz]*/ / sonic_speed; /*[m/s]*/
    case 3: return -1.0 * double(sample_rate) /*[Hz]*/ / sonic_speed  /*[m/s]*/ / 100.0; /*[cm/m]*/
    case 4: return -1.0 * double(sample_rate) /*[Hz]*/ / sonic_speed  /*[m/s]*/ / 3.28;  /*[ft/m]*/
    case 5: return -1.0 * double(sample_rate) /*[Hz]*/ / sonic_speed  /*[m/s]*/ / 39.37; /*[in/m]*/
  }
  return 1;
}

///////////////////////////////////////////////////////////////////////////////
// Initialization / Deinitialization
///////////////////////////////////////////////////////////////////////////////

CWinampAC3_conf *CWinampAC3_conf::create_main(HMODULE hmodule, IWinampAC3 *filter)
{ return new CWinampAC3_conf(hmodule, MAKEINTRESOURCE(IDD_MAIN), filter, CONF_SPEAKERS | CONF_INFO | CONF_DRC | CONF_GAINS); }

CWinampAC3_conf *CWinampAC3_conf::create_mixer(HMODULE hmodule, IWinampAC3 *filter)
{ return new CWinampAC3_conf(hmodule, MAKEINTRESOURCE(IDD_MIXER), filter, CONF_SPEAKERS | CONF_GAINS | CONF_MATRIX); }

CWinampAC3_conf *CWinampAC3_conf::create_eq(HMODULE hmodule, IWinampAC3 *filter)
{ return new CWinampAC3_conf(hmodule, MAKEINTRESOURCE(IDD_EQ), filter, CONF_DELAY | CONF_EQ); }

CWinampAC3_conf *CWinampAC3_conf::create_about(HMODULE hmodule, IWinampAC3 *filter)
{ return new CWinampAC3_conf(hmodule, MAKEINTRESOURCE(IDD_ABOUT), filter, 0); }


CWinampAC3_conf::CWinampAC3_conf(HMODULE _hmodule, LPCSTR _dlg_res, IWinampAC3 *_filter, int _flags) 
:TabSheet(_hmodule, _dlg_res)
{
  filter = _filter;
  flags = _flags;
  InitCommonControls();
}

void
CWinampAC3_conf::switch_on()
{
  set_dynamic_controls();
  set_controls();

  RegistryKey reg(REG_WINAMPAC3);

  delay_units = 1; 
  reg.get_int32("delay_units", delay_units);

  int refresh = 200;
  reg.get_int32("refresh", refresh);
  SetTimer(hwnd, 1, refresh, 0);

  TabSheet::switch_on();
}

void
CWinampAC3_conf::switch_off()
{
  KillTimer(hwnd, 1);
  TabSheet::switch_off();
}

///////////////////////////////////////////////////////////////////////////////
// Handle messages
///////////////////////////////////////////////////////////////////////////////

BOOL 
CWinampAC3_conf::message(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch (uMsg)
  {
    case WM_HSCROLL:
    case WM_VSCROLL:
      command(GetDlgCtrlID((HWND)lParam), LOWORD(wParam));
      return TRUE;

    case WM_TIMER:
      set_dynamic_controls();
      return TRUE;
  }

  return TabSheet::message(hwnd, uMsg, wParam, lParam);
}

void 
CWinampAC3_conf::reload_state()
{
  filter->get_speakers(&spk);
  filter->get_sink(&sink);
  filter->get_bsi(&bsi);
  filter->get_cpu_load(&cpu_load);
  filter->get_stat(&frames, &errors);
  filter->get_levels(in_levels, &in_level, out_levels, &out_level);
  // Gains
  filter->get_gain(&master, &gain);
  filter->get_gains(&slev, &clev, &lfelev);
  filter->get_bsi_locks(&slev_lock, &clev_lock, &lfelev_lock);
  // AGC
  filter->get_auto_gain(&auto_gain);
  filter->get_normalize(&normalize);
  // DRC
  filter->get_dynrng(&dynrng, &dynrng_level, &dynrng_power);
  // Matrix
  filter->get_auto_matrix(&auto_matrix);
  filter->get_normalize_matrix(&normalize_matrix);
  filter->get_expand_stereo(&expand_stereo);
  filter->get_voice_control(&voice_control);
  filter->get_bass_redir(&bass_redir);
  // Equalizer
  filter->get_eq_on(&eq_on);
  filter->get_eq9(eq);
  filter->get_eq9_levels(eq_levels);
  // Delay
  filter->get_delay_on(&delay_on);
  filter->get_delay(delay);
}


///////////////////////////////////////////////////////////////////////////////
// Controls initalization/update
///////////////////////////////////////////////////////////////////////////////

void 
CWinampAC3_conf::init_controls()
{
  int i, j;
  /////////////////////////////////////
  // Link controls

  cmb_preset.link(hwnd, IDC_CMB_PRESET);
  cmb_matrix.link(hwnd, IDC_CMB_MATRIX);

  if (flags & CONF_MATRIX)
    for (i = 0; i < 6; i++)
      for (j = 0; j < 6; j++)
        edt_matrix[i][j].link(hwnd, matrix_control[i][j]);

  edt_master.link(hwnd, IDC_EDT_MASTER);
  edt_gain  .link(hwnd, IDC_EDT_GAIN);
  edt_voice .link(hwnd, IDC_EDT_VOICE);
  edt_sur   .link(hwnd, IDC_EDT_SUR);
  edt_lfe   .link(hwnd, IDC_EDT_LFE);

  edt_gain.enable(false);

  cmb_delay.link(hwnd, IDC_CMB_DELAY);
  cmb_units.link(hwnd, IDC_CMB_UNITS);
  cmb_eq.link(hwnd, IDC_CMB_EQ);

  // Delay controls
  if (flags & CONF_DELAY)
    for (i = 0; i < 6; i++)
      edt_delay[i].link(hwnd, ctl_delay[i]);

  // Equalizer controls
  if (flags & CONF_EQ)
    for (i = 0; i < 9; i++)
    {
      edt_eq[i].link(hwnd, ctl_eq_edt[i]);
      SendDlgItemMessage(hwnd, ctl_eq_slider[i], TBM_SETRANGE, TRUE, MAKELONG(min_gain_level, max_gain_level) * ticks);
      SendDlgItemMessage(hwnd, ctl_eq_slider[i], TBM_SETTIC, 0, 0);

      SendDlgItemMessage(hwnd, ctl_eq_level[i],  PBM_SETBARCOLOR, 0, RGB(0, 128, 0));
      SendDlgItemMessage(hwnd, ctl_eq_level[i],  PBM_SETRANGE, 0, MAKELPARAM(0, -min_eq_level * ticks));
    }

  /////////////////////////////////////
  // Init links

  // WinampAC3 links
  lnk_ac3filter.link(hwnd, IDC_LNK_AC3FILTER);
  lnk_forum.link(hwnd, IDC_LNK_FORUM);
  // Related projects
  lnk_matrix_mixer.link(hwnd, IDC_LNK_MATRIX_MIXER);
  lnk_winampac3.link(hwnd, IDC_LNK_WINAMPAC3);
  lnk_liba52.link(hwnd, IDC_LNK_LIBA52);
  // Mail
  lnk_email.link(hwnd, IDC_LNK_EMAIL);


  /////////////////////////////////////
  // Init sliders

  SendDlgItemMessage(hwnd, IDC_DRC_LEVEL,     TBM_SETRANGE, TRUE, MAKELONG(min_gain_level, max_gain_level) * ticks);
  SendDlgItemMessage(hwnd, IDC_DRC_LEVEL,     TBM_SETTIC, 0, 0);
  SendDlgItemMessage(hwnd, IDC_DRC_POWER,     TBM_SETRANGE, TRUE, MAKELONG(min_gain_level, max_gain_level) * ticks);
  SendDlgItemMessage(hwnd, IDC_DRC_POWER,     TBM_SETTIC, 0, 0);

  SendDlgItemMessage(hwnd, IDC_SLIDER_MASTER, TBM_SETRANGE, TRUE, MAKELONG(min_gain_level, max_gain_level) * ticks);
  SendDlgItemMessage(hwnd, IDC_SLIDER_MASTER, TBM_SETTIC, 0, 0);
  SendDlgItemMessage(hwnd, IDC_SLIDER_GAIN,   TBM_SETRANGE, TRUE, MAKELONG(min_gain_level, max_gain_level) * ticks);
  SendDlgItemMessage(hwnd, IDC_SLIDER_GAIN,   TBM_SETTIC, 0, 0);

  SendDlgItemMessage(hwnd, IDC_SLIDER_LFE,    TBM_SETRANGE, TRUE, MAKELONG(min_gain_level, max_gain_level) * ticks);
  SendDlgItemMessage(hwnd, IDC_SLIDER_LFE,    TBM_SETTIC, 0, 0);
  SendDlgItemMessage(hwnd, IDC_SLIDER_VOICE,  TBM_SETRANGE, TRUE, MAKELONG(min_gain_level, max_gain_level) * ticks);
  SendDlgItemMessage(hwnd, IDC_SLIDER_VOICE,  TBM_SETTIC, 0, 0);
  SendDlgItemMessage(hwnd, IDC_SLIDER_SUR,    TBM_SETRANGE, TRUE, MAKELONG(min_gain_level, max_gain_level) * ticks);
  SendDlgItemMessage(hwnd, IDC_SLIDER_SUR,    TBM_SETTIC, 0, 0);

  SendDlgItemMessage(hwnd, IDC_CPU,           PBM_SETRANGE, 0, MAKELPARAM(0, 100));

  /////////////////////////////////////
  // Mixer levels

  int in_ch2control[6]  = { IDC_IN_L,  IDC_IN_C,  IDC_IN_R,  IDC_IN_SL,  IDC_IN_SR,  IDC_IN_LFE  };
  int out_ch2control[6] = { IDC_OUT_L, IDC_OUT_C, IDC_OUT_R, IDC_OUT_SL, IDC_OUT_SR, IDC_OUT_LFE };
  for (i = 0; i < 6; i++)
  {
    SendDlgItemMessage(hwnd, in_ch2control[i],  PBM_SETBARCOLOR, 0, RGB(0, 128, 0));
    SendDlgItemMessage(hwnd, out_ch2control[i], PBM_SETBARCOLOR, 0, RGB(0, 128, 0));
    // log scale
    SendDlgItemMessage(hwnd, in_ch2control[i],  PBM_SETRANGE, 0, MAKELPARAM(0, -min_level * ticks));
    SendDlgItemMessage(hwnd, out_ch2control[i], PBM_SETRANGE, 0, MAKELPARAM(0, -min_level * ticks));
//    // linear scale
//    SendDlgItemMessage(hwnd, in_ch2control[i],  PBM_SETRANGE, 0, MAKELPARAM(0, 256));
//    SendDlgItemMessage(hwnd, out_ch2control[i], PBM_SETRANGE, 0, MAKELPARAM(0, 256));
  }

  /////////////////////////////////////
  // Speakers

  if (flags & CONF_SPEAKERS)
  {
    SendDlgItemMessage(hwnd, IDC_CMB_SPK, CB_RESETCONTENT, 0, 0);
    int list = 0;
    for (i = 0; i < sizeof(spklist_name) / sizeof(spklist_name[0]); i++)
    {
      bool supported;
      filter->query_speakers(spklist_spk[i], &supported);
      if (supported)
      {
        SendDlgItemMessage(hwnd, IDC_CMB_SPK, CB_ADDSTRING, 0, (LONG)spklist_name[i]);
        spk2list_tbl[i] = list;
        list2spk_tbl[list] = i;
        list++;
      }
    }
  }

  /////////////////////////////////////
  // Formats

  if (flags & CONF_SPEAKERS)
  {
    SendDlgItemMessage(hwnd, IDC_CMB_FORMAT, CB_RESETCONTENT, 0, 0);
    for (i = 0; i < sizeof(fmtlist) / sizeof(fmtlist[0]); i++)
      SendDlgItemMessage(hwnd, IDC_CMB_FORMAT, CB_ADDSTRING, 0, (LONG)fmtlist[i]);
  }

  /////////////////////////////////////
  // Sink

  if (flags & CONF_SPEAKERS)
  {
    SendDlgItemMessage(hwnd, IDC_CMB_SINK, CB_RESETCONTENT, 0, 0);
    for (i = 0; i < sizeof(sinklist) / sizeof(sinklist[0]); i++)
      SendDlgItemMessage(hwnd, IDC_CMB_SINK, CB_ADDSTRING, 0, (LONG)sinklist[i]);
  }

  /////////////////////////////////////
  // Delay units

  if (flags & CONF_DELAY)
  {
    SendDlgItemMessage(hwnd, IDC_CMB_UNITS, CB_RESETCONTENT, 0, 0);
    for (i = 0; i < sizeof(units_list) / sizeof(units_list[0]); i++)
      SendDlgItemMessage(hwnd, IDC_CMB_UNITS, CB_ADDSTRING, 0, (LONG)units_list[i]);
  }

}

void 
CWinampAC3_conf::set_dynamic_controls()
{
  reload_state();

  /////////////////////////////////////
  // Statistics

  if (flags & CONF_INFO)
  {
    dlg_printf(hwnd, IDC_EDT_BITRATE,       "%d", bsi.bitrate);
    dlg_printf(hwnd, IDC_EDT_SAMPLE_RATE,   "%d", bsi.sample_rate);
    dlg_printf(hwnd, IDC_EDT_FREQ_COUPLING, "%2.3f", double(bsi.cplbegf)/1000);
    dlg_printf(hwnd, IDC_EDT_FREQ_HIGH,     "%2.3f", double(bsi.chendf[0])/1000);
    dlg_printf(hwnd, IDC_EDT_FRAMES,        "%i", frames);
    dlg_printf(hwnd, IDC_EDT_ERRORS,        "%i", errors);
    dlg_printf(hwnd, IDC_CPU_LABEL,         "%i%%", int(cpu_load*100));

    SendDlgItemMessage(hwnd, IDC_CPU, PBM_SETPOS, int(cpu_load * 100),  0);
    int mode = bsi.spk.mode & 15;
    if (bsi.spk.dolby) 
      mode = (bsi.spk.mode & MODE_LFE)? 17: 16;
    SendDlgItemMessage(hwnd, IDC_EDT_CHANNELS, WM_SETTEXT, 0, (DWORD) (LPSTR)ac3_modes[mode]);
  }

  /////////////////////////////////////
  // Dynamic range compression

  if (flags & CONF_DRC)
    SendDlgItemMessage(hwnd, IDC_DRC_LEVEL, TBM_SETPOS, TRUE, long(-value2db(dynrng_level) * ticks));

  /////////////////////////////////////
  // Gain controls

  if (flags & CONF_GAINS)
  {
    SendDlgItemMessage(hwnd, IDC_SLIDER_GAIN, TBM_SETPOS, TRUE, long(-value2db(gain) * ticks));
    edt_gain.update_value(value2db(gain));

    if (clev_lock)   
    { 
      SendDlgItemMessage(hwnd, IDC_SLIDER_VOICE, TBM_SETPOS, TRUE, long(-value2db(clev) * ticks)); 
      EnableWindow(GetDlgItem(hwnd, IDC_SLIDER_VOICE), false);
      edt_voice.update_value(value2db(clev)); 
      edt_voice.enable(false); 
    }

    if (slev_lock)   
    { 
      SendDlgItemMessage(hwnd, IDC_SLIDER_SUR, TBM_SETPOS, TRUE, long(-value2db(slev) * ticks)); 
      EnableWindow(GetDlgItem(hwnd, IDC_SLIDER_SUR), false);
      edt_sur.update_value(value2db(slev)); 
      edt_sur.enable(false); 
    }

    if (lfelev_lock)   
    { 
      SendDlgItemMessage(hwnd, IDC_SLIDER_LFE, TBM_SETPOS, TRUE, long(-value2db(lfelev) * ticks)); 
      EnableWindow(GetDlgItem(hwnd, IDC_SLIDER_LFE), false);
      edt_lfe.update_value(value2db(lfelev)); 
      edt_lfe.enable(false); 
    }
  }

  /////////////////////////////////////
  // Matrix controls

  if ((flags & CONF_MATRIX) && auto_matrix)
    set_matrix_controls();

  /////////////////////////////////////
  // Equalizer levels

  if (flags & CONF_EQ)
  {
    for (int i = 0; i < 9; i++)                              
      SendDlgItemMessage(hwnd, ctl_eq_level[i], PBM_SETPOS, int(eq_levels[i] > 0? log10(eq_levels[i])*20.0 - min_eq_level: 0) * ticks,  0);
  }

  /////////////////////////////////////
  // Mixer levels

  int in_ch2control[6]  = { IDC_IN_L,  IDC_IN_C,  IDC_IN_R,  IDC_IN_SL,  IDC_IN_SR,  IDC_IN_LFE  };
  int out_ch2control[6] = { IDC_OUT_L, IDC_OUT_C, IDC_OUT_R, IDC_OUT_SL, IDC_OUT_SR, IDC_OUT_LFE };
  for (int ch = 0; ch < 6; ch++)
  {
    // log scale
    SendDlgItemMessage(hwnd, in_ch2control[ch],  PBM_SETPOS, in_levels[ch] / in_level   > 0? long(-(min_level - log10(in_levels[ch]  / in_level )*20) * ticks): -1000 * ticks,  0);
    SendDlgItemMessage(hwnd, out_ch2control[ch], PBM_SETPOS, out_levels[ch] / out_level > 0? long(-(min_level - log10(out_levels[ch] / out_level)*20) * ticks): -1000 * ticks,  0);
    SendDlgItemMessage(hwnd, out_ch2control[ch], PBM_SETBARCOLOR, 0, (out_level - out_levels[ch]) < 0.001? RGB(255, 0, 0): RGB(0, 128, 0));
//    // linear scale
//    SendDlgItemMessage(hwnd, in_ch2control[ch],  PBM_SETPOS,   long(in_levels[ch] * 256 / in_level),  0);
//    SendDlgItemMessage(hwnd, out_ch2control[ch], PBM_SETPOS,   long(out_levels[ch]* 256 / out_level), 0);
  }

}

void 
CWinampAC3_conf::set_controls()
{
  int i;

  reload_state();

  /////////////////////////////////////
  // Speakers and format

  if (flags & CONF_SPEAKERS)
  {
    SendDlgItemMessage(hwnd, IDC_CMB_SPK,    CB_SETCURSEL, spk2list(spk), 0);
    SendDlgItemMessage(hwnd, IDC_CMB_FORMAT, CB_SETCURSEL, fmt2list(spk.fmt), 0);
    SendDlgItemMessage(hwnd, IDC_CMB_SINK,   CB_SETCURSEL, sink2list(sink), 0);
  }

  /////////////////////////////////////
  // Dynamic range compression

  if (flags & CONF_DRC)
  {
    SendDlgItemMessage(hwnd, IDC_CHK_DYNRNG, BM_SETCHECK, dynrng? BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_DRC_POWER,  TBM_SETPOS, TRUE, long(-value2db(dynrng_power) * ticks));
  }
                                                                                          
  /////////////////////////////////////
  // Gain controls

  if (flags & CONF_GAINS)
  {
    SendDlgItemMessage(hwnd, IDC_SLIDER_MASTER, TBM_SETPOS, TRUE, long(-value2db(master) * ticks));
    edt_master.update_value(value2db(master));

    SendDlgItemMessage(hwnd, IDC_CHK_AUTO_GAIN, BM_SETCHECK, auto_gain?        BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_CHK_NORMALIZE, BM_SETCHECK, normalize?        BST_CHECKED: BST_UNCHECKED, 1);
    EnableWindow(GetDlgItem(hwnd, IDC_CHK_NORMALIZE), auto_gain);

    SendDlgItemMessage(hwnd, IDC_CHK_SLOCK,    BM_SETCHECK, slev_lock?   BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_CHK_CLOCK,    BM_SETCHECK, clev_lock?   BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_CHK_LFELOCK,  BM_SETCHECK, lfelev_lock? BST_CHECKED: BST_UNCHECKED, 1);

    SendDlgItemMessage(hwnd, IDC_SLIDER_VOICE, TBM_SETPOS, TRUE, long(-value2db(clev)   * ticks));
    SendDlgItemMessage(hwnd, IDC_SLIDER_SUR,   TBM_SETPOS, TRUE, long(-value2db(slev)   * ticks));
    SendDlgItemMessage(hwnd, IDC_SLIDER_LFE,   TBM_SETPOS, TRUE, long(-value2db(lfelev) * ticks));

    EnableWindow(GetDlgItem(hwnd, IDC_SLIDER_VOICE), !clev_lock);
    EnableWindow(GetDlgItem(hwnd, IDC_SLIDER_SUR),   !slev_lock);
    EnableWindow(GetDlgItem(hwnd, IDC_SLIDER_LFE),   !lfelev_lock);

    edt_voice.update_value(value2db(clev));
    edt_sur  .update_value(value2db(slev));
    edt_lfe  .update_value(value2db(lfelev));

    edt_voice.enable(!clev_lock);   
    edt_sur  .enable(!slev_lock);   
    edt_lfe  .enable(!lfelev_lock); 
  }

  /////////////////////////////////////

  // Delay

  if (flags & CONF_DELAY)
  {
    double factor = 1/unit2factor(delay_units, bsi.sample_rate);
    for (i = 0; i < 6; i++)
    {
      edt_delay[i].update_value(delay[i]*factor);
      edt_delay[i].enable(delay_on);
    }
    SendDlgItemMessage(hwnd, IDC_CHK_DELAY, BM_SETCHECK, delay_on? BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_CMB_UNITS, CB_SETCURSEL, delay_units, 0);
    EnableWindow(GetDlgItem(hwnd, IDC_CMB_UNITS),  delay_on);
  }

  /////////////////////////////////////
  // Equalizer

  if (flags & CONF_EQ)
  {
    SendDlgItemMessage(hwnd, IDC_CHK_EQ, BM_SETCHECK, eq_on? BST_CHECKED: BST_UNCHECKED, 1);
    for (i = 0; i < 9; i++)
    {
      edt_eq[i].update_value(value2db(eq[i]));
      edt_eq[i].enable(eq_on);
      SendDlgItemMessage(hwnd, ctl_eq_slider[i], TBM_SETPOS, TRUE, long(-value2db(eq[i]) * ticks));
      EnableWindow(GetDlgItem(hwnd, ctl_eq_slider[i]), eq_on);
    }
  }

  /////////////////////////////////////
  // Matrix

  if (flags & CONF_MATRIX)
  {
    set_matrix_controls();
    SendDlgItemMessage(hwnd, IDC_CHK_AUTO_MATRIX,   BM_SETCHECK, auto_matrix?      BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_CHK_EXPAND_STEREO, BM_SETCHECK, expand_stereo?    BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_CHK_VOICE_CONTROL, BM_SETCHECK, voice_control?    BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_CHK_NORM_MATRIX,   BM_SETCHECK, normalize_matrix? BST_CHECKED: BST_UNCHECKED, 1);
    SendDlgItemMessage(hwnd, IDC_CHK_BASS_REDIR,    BM_SETCHECK, bass_redir?       BST_CHECKED: BST_UNCHECKED, 1);
    EnableWindow(GetDlgItem(hwnd, IDC_CHK_EXPAND_STEREO), auto_matrix);
    EnableWindow(GetDlgItem(hwnd, IDC_CHK_VOICE_CONTROL), auto_matrix);
    EnableWindow(GetDlgItem(hwnd, IDC_CHK_NORM_MATRIX), auto_matrix);
  }

  /////////////////////////////////////
  // Presets

  #define fill_combobox(control, registry)                                                \
  {                                                                                       \
    HKEY key;                                                                             \
    char preset[256];                                                                     \
    int  n;                                                                               \
                                                                                          \
                                                                                          \
    SendDlgItemMessage(hwnd, control, WM_GETTEXT, 256, (LONG)preset);                     \
    SendDlgItemMessage(hwnd, control, CB_RESETCONTENT, 0, 0);                             \
                                                                                          \
    if (RegOpenKeyEx(HKEY_CURRENT_USER, registry, 0, KEY_READ, &key) == ERROR_SUCCESS)    \
    {                                                                                     \
      char buf[256];                                                                      \
      int i = 0;                                                                          \
      DWORD len = 256;                                                                    \
      while (RegEnumKeyEx(key, i++, (LPTSTR)buf, &len, 0, 0, 0, 0) == ERROR_SUCCESS)      \
      {                                                                                   \
        SendDlgItemMessage(hwnd, control, CB_ADDSTRING, 0, (LONG)buf);                    \
        len = 256;                                                                        \
      }                                                                                   \
    }                                                                                     \
                                                                                          \
    n = SendDlgItemMessage(hwnd, control, CB_FINDSTRINGEXACT, 0, (LONG)preset);           \
    if (n != CB_ERR)                                                                      \
      SendDlgItemMessage(hwnd, control, CB_SETCURSEL, n, 0);                              \
    SendDlgItemMessage(hwnd, control, WM_SETTEXT, 0, (LONG)preset);                       \
  }

  if (flags & CONF_GAINS)  fill_combobox(IDC_CMB_PRESET, "Software\\WinampAC3\\preset");
  if (flags & CONF_MATRIX) fill_combobox(IDC_CMB_MATRIX, "Software\\WinampAC3\\matrix");
  if (flags & CONF_DELAY)  fill_combobox(IDC_CMB_DELAY,  "Software\\WinampAC3\\delay");
  if (flags & CONF_EQ)     fill_combobox(IDC_CMB_EQ,     "Software\\WinampAC3\\equalizer");
}

void 
CWinampAC3_conf::set_matrix_controls()
{
  bool auto_matrix;
  mixer_matrix_t matrix;

  filter->get_matrix(&matrix);
  filter->get_auto_matrix(&auto_matrix);

  for (int i = 0; i < 6; i++)
    for (int j = 0; j < 6; j++)
    {
      edt_matrix[i][j].update_value(matrix[j][i]);
      SendDlgItemMessage(hwnd, matrix_control[j][i], EM_SETREADONLY, auto_matrix, 0);
    }
}



///////////////////////////////////////////////////////////////////////////////
// Commands
///////////////////////////////////////////////////////////////////////////////

void 
CWinampAC3_conf::command(int control, int message)
{
  /////////////////////////////////////
  // Matrix controls

  if (message == CB_ENTER)
  {
    mixer_matrix_t matrix;
    filter->get_matrix(&matrix);
    bool update_matrix = false;

    for (int i = 0; i < 6; i++)
      for (int j = 0; j < 6; j++)
        if (control == matrix_control[i][j])
        {
          matrix[j][i] = edt_matrix[i][j].value;
          update_matrix = true;
        }

    if (update_matrix)
    {
      filter->set_matrix(&matrix);
      set_matrix_controls();
    }
  }

  switch (control)
  {
    /////////////////////////////////////
    // Speaker selection

    case IDC_CMB_SPK:
    case IDC_CMB_FORMAT:
      if (message == CBN_SELENDOK)
      {
        AC3Speakers spk = list2spk(SendDlgItemMessage(hwnd, IDC_CMB_SPK, CB_GETCURSEL, 0, 0));
        spk.fmt = list2fmt(SendDlgItemMessage(hwnd, IDC_CMB_FORMAT, CB_GETCURSEL, 0, 0));
        filter->set_speakers(spk);
        set_controls();
      }
      break;

    case IDC_CMB_SINK:
      if (message == CBN_SELENDOK)
      {
        int sink = list2sink(SendDlgItemMessage(hwnd, IDC_CMB_SINK, CB_GETCURSEL, 0, 0));
        filter->set_sink(sink);
        init_controls();  // requery allowed modes
        set_controls();
      }
      break;

    /////////////////////////////////////
    // Auto gain control

    case IDC_SLIDER_MASTER:
      if (message == TB_THUMBPOSITION || message == TB_ENDTRACK)
      {
        sample_t master = db2value(-double(SendDlgItemMessage(hwnd, IDC_SLIDER_MASTER,TBM_GETPOS, 0, 0))/ticks);
        filter->set_gain(master);
        set_controls();
      }
      break;

    case IDC_EDT_MASTER:
      if (message == CB_ENTER)
      {
        filter->set_gain(db2value(edt_master.value));
        set_controls();
      }
      break;

    case IDC_CHK_AUTO_GAIN:
    {
      bool auto_gain = (SendDlgItemMessage(hwnd, IDC_CHK_AUTO_GAIN, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_auto_gain(auto_gain);
      set_controls();
      break;
    }

    case IDC_CHK_NORMALIZE:
    {
      bool normalize = (SendDlgItemMessage(hwnd, IDC_CHK_NORMALIZE, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_normalize(normalize);
      set_controls();
      break;
    }

    /////////////////////////////////////
    // Gain controls

    case IDC_CHK_CLOCK:    
    case IDC_CHK_SLOCK:    
    case IDC_CHK_LFELOCK:
    {
      bool slev_lock   = (SendDlgItemMessage(hwnd, IDC_CHK_SLOCK,   BM_GETCHECK, 0, 0) == BST_CHECKED);
      bool clev_lock   = (SendDlgItemMessage(hwnd, IDC_CHK_CLOCK,   BM_GETCHECK, 0, 0) == BST_CHECKED);
      bool lfelev_lock = (SendDlgItemMessage(hwnd, IDC_CHK_LFELOCK, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_bsi_locks(slev_lock, clev_lock, lfelev_lock);
      set_controls();
      break;
    }

    case IDC_SLIDER_VOICE:
    case IDC_SLIDER_SUR:
    case IDC_SLIDER_LFE:
      if (message == TB_THUMBPOSITION || message == TB_ENDTRACK)
      {
        sample_t clev   = db2value(-double(SendDlgItemMessage(hwnd, IDC_SLIDER_VOICE, TBM_GETPOS, 0, 0))/ticks);
        sample_t slev   = db2value(-double(SendDlgItemMessage(hwnd, IDC_SLIDER_SUR,   TBM_GETPOS, 0, 0))/ticks);
        sample_t lfelev = db2value(-double(SendDlgItemMessage(hwnd, IDC_SLIDER_LFE,   TBM_GETPOS, 0, 0))/ticks);
        filter->set_gains(slev,  clev,  lfelev);
        set_controls();
      }
      break;

    case IDC_EDT_VOICE:
    case IDC_EDT_SUR:
    case IDC_EDT_LFE:
      if (message == CB_ENTER)
      {
        filter->set_gains(db2value(edt_sur.value), db2value(edt_voice.value), db2value(edt_lfe.value));
        set_controls();
      }
      break;

    /////////////////////////////////////
    // Dynamic range compreesion

    case IDC_DRC_POWER:
      if (message == TB_THUMBPOSITION || message == TB_ENDTRACK)
      {
        bool dynrng;
        sample_t dynrng_level, dynrng_power;
        filter->get_dynrng(&dynrng, &dynrng_level, &dynrng_power);
        dynrng_power = db2value(-double(SendDlgItemMessage(hwnd, IDC_DRC_POWER, TBM_GETPOS, 0, 0))/ticks);
        filter->set_dynrng(dynrng, dynrng_power);
        set_controls();
      }
      break;

    case IDC_CHK_DYNRNG:
    {
      bool dynrng;
      sample_t dynrng_level, dynrng_power;
      filter->get_dynrng(&dynrng, &dynrng_level, &dynrng_power);
      dynrng = (SendDlgItemMessage(hwnd, IDC_CHK_DYNRNG, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_dynrng(dynrng, dynrng_power);
      set_controls();
      break;
    }

    /////////////////////////////////////
    // Matrix

    case IDC_CHK_AUTO_MATRIX:
    {
      bool auto_matrix = (SendDlgItemMessage(hwnd, IDC_CHK_AUTO_MATRIX, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_auto_matrix(auto_matrix);
      set_controls();
      break;
    }

    case IDC_CHK_NORM_MATRIX:
    {
      bool normalize_matrix = (SendDlgItemMessage(hwnd, IDC_CHK_NORM_MATRIX, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_normalize_matrix(normalize_matrix);
      set_controls();
      break;
    }

    case IDC_CHK_EXPAND_STEREO:
    {
      bool expand_stereo = (SendDlgItemMessage(hwnd, IDC_CHK_EXPAND_STEREO, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_expand_stereo(expand_stereo);
      set_controls();
      break;
    }

    case IDC_CHK_VOICE_CONTROL:
    {
      bool voice_control = (SendDlgItemMessage(hwnd, IDC_CHK_VOICE_CONTROL, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_voice_control(voice_control);
      set_controls();
      break;
    }

    case IDC_CHK_BASS_REDIR:
    {
      bool bass_redir = (SendDlgItemMessage(hwnd, IDC_CHK_BASS_REDIR, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_bass_redir(bass_redir);
      set_controls();
      break;
    }

    /////////////////////////////////////
    // Equalizer

    case IDC_CHK_EQ:
    {
      bool eq_on = (SendDlgItemMessage(hwnd, IDC_CHK_EQ, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_eq_on(eq_on);
      set_controls();
      break;
    }

    case IDC_EDT_EQ9:
    case IDC_EDT_EQ8:
    case IDC_EDT_EQ7:
    case IDC_EDT_EQ6:
    case IDC_EDT_EQ5:
    case IDC_EDT_EQ4:
    case IDC_EDT_EQ3:
    case IDC_EDT_EQ2:
    case IDC_EDT_EQ1:
      if (message == CB_ENTER)
      {
        sample_t func[9];
        for (int i = 0; i < 9; i++)
          func[i] = db2value(edt_eq[i].value);
        filter->set_eq9(func);
        set_controls();
      }
      break;

    case IDC_EQ9:
    case IDC_EQ8:
    case IDC_EQ7:
    case IDC_EQ6:
    case IDC_EQ5:
    case IDC_EQ4:
    case IDC_EQ3:
    case IDC_EQ2:
    case IDC_EQ1:
      if (message == TB_THUMBPOSITION || message == TB_ENDTRACK)
      {
        sample_t eq[9];
        for (int i = 0; i < 9; i++)
          eq[i] = db2value(-double(SendDlgItemMessage(hwnd, ctl_eq_slider[i], TBM_GETPOS, 0, 0))/ticks);
        filter->set_eq9(eq);
        set_controls();
      }
      break;

    /////////////////////////////////////
    // Delay

    case IDC_CHK_DELAY:
    {
      bool delay_on = (SendDlgItemMessage(hwnd, IDC_CHK_DELAY, BM_GETCHECK, 0, 0) == BST_CHECKED);
      filter->set_delay_on(delay_on);
      set_controls();
      break;
    }

    case IDC_EDT_DL:
    case IDC_EDT_DC:
    case IDC_EDT_DR:
    case IDC_EDT_DSL:
    case IDC_EDT_DSR:
    case IDC_EDT_DLFE:
      if (message == CB_ENTER)
      {
        BSI bsi;                
        int delay[6];

        filter->get_bsi(&bsi);
        double factor = unit2factor(delay_units, bsi.sample_rate);

        for (int i = 0; i < 6; i++)
          delay[i] = int(edt_delay[i].value * factor);

        filter->set_delay(delay);
        set_controls();
      }
      break;

    case IDC_CMB_UNITS:
      if (message == CBN_SELENDOK)
      {
        delay_units = SendDlgItemMessage(hwnd, IDC_CMB_UNITS, CB_GETCURSEL, 0, 0);
        set_controls();

        RegistryKey reg("Software\\WinampAC3");
        reg.set_int32("delay_units", delay_units);
      }
      break;

    /////////////////////////////////////
    // Preset

    case IDC_CMB_PRESET:
      if (message == CBN_SELENDOK)
      {
        char buf[256];
        SendDlgItemMessage(hwnd, IDC_CMB_PRESET, CB_GETLBTEXT, SendDlgItemMessage(hwnd, IDC_CMB_PRESET, CB_GETCURSEL, 0, 0), (LONG)buf);
        SendDlgItemMessage(hwnd, IDC_CMB_PRESET, WM_SETTEXT, 0, (LONG)buf);
        filter->load_params(buf);
        set_controls();
      }
      if (message == CB_ENTER)
      {
        char buf[256];
        SendDlgItemMessage(hwnd, IDC_CMB_PRESET, WM_GETTEXT, 256, (LONG)buf);
        filter->save_params(buf);
        set_controls();
      }

      break;

    case IDC_BTN_PRESET_SAVE:
    {
      char buf[256];
      SendDlgItemMessage(hwnd, IDC_CMB_PRESET, WM_GETTEXT, 256, (LONG)buf);
      filter->save_params(buf);
      set_controls();
      break;
    }

    case IDC_BTN_PRESET_DELETE:
    {
      char buf[256];
      char preset[256];
      SendDlgItemMessage(hwnd, IDC_CMB_PRESET, WM_GETTEXT, 256, (LONG)preset);

      sprintf(buf, "Are you sure you want to delete '%s' preset?", preset);
      if (MessageBox(hwnd, buf, "Delete confirmation", MB_ICONEXCLAMATION | MB_YESNO) == IDYES)
      {     
        sprintf(buf, "Software\\WinampAC3\\preset\\%s", preset);
        delete_reg_key(buf, HKEY_CURRENT_USER);
        SendDlgItemMessage(hwnd, IDC_CMB_PRESET, WM_SETTEXT, 0, (LONG)"");
        set_controls();
      }
      break;
    }

    case IDC_BTN_PRESET_FILE:
    {
      char filename[MAX_PATH];

      if FAILED(filter->get_config_file(filename, MAX_PATH))
        filename[0] = 0;

      FileDlg dlg(hwnd, filename);
      switch (dlg.exec())
      {
      case IDC_BTN_FILE_SAVE:
        if (dlg.preset) filter->save_params(dlg.filename, true);
        if (dlg.matrix) filter->save_matrix(dlg.filename, true);
        if (dlg.delay)  filter->save_delay (dlg.filename, true);
        if (dlg.eq)     filter->save_eq9(dlg.filename, true);
        break;

      case IDC_BTN_FILE_LOAD:
        if (dlg.preset) filter->load_params(dlg.filename, true);
        if (dlg.matrix) filter->load_matrix(dlg.filename, true);
        if (dlg.delay)  filter->load_delay (dlg.filename, true);
        if (dlg.eq)     filter->load_eq9(dlg.filename, true);
        break;
      }
      break;
    }

    /////////////////////////////////////
    // Matrix preset

    case IDC_CMB_MATRIX:
      if (message == CBN_SELENDOK)
      {
        char buf[256];
        SendDlgItemMessage(hwnd, IDC_CMB_MATRIX, CB_GETLBTEXT, SendDlgItemMessage(hwnd, IDC_CMB_MATRIX, CB_GETCURSEL, 0, 0), (LONG)buf);
        SendDlgItemMessage(hwnd, IDC_CMB_MATRIX, WM_SETTEXT, 0, (LONG)buf);
        filter->set_auto_matrix(false);
        filter->load_matrix(buf);
        set_controls();
      }
      if (message == CB_ENTER)
      {
        char buf[256];
        SendDlgItemMessage(hwnd, IDC_CMB_MATRIX, WM_GETTEXT, 256, (LONG)buf);
        filter->save_matrix(buf);                    
        set_controls();
      }
      break;

    case IDC_BTN_MATRIX_SAVE:
    {
      char buf[256];
      SendDlgItemMessage(hwnd, IDC_CMB_MATRIX, WM_GETTEXT, 256, (LONG)buf);
      filter->save_matrix(buf);
      set_controls();
      break;
    }

    case IDC_BTN_MATRIX_DELETE:
    {
      char buf[256];
      char preset[256];
      SendDlgItemMessage(hwnd, IDC_CMB_MATRIX, WM_GETTEXT, 256, (LONG)preset);

      sprintf(buf, "Are you sure you want to delete '%s' matrix?", preset);
      if (MessageBox(hwnd, buf, "Delete confirmation", MB_ICONEXCLAMATION | MB_YESNO) == IDYES)
      {     
        sprintf(buf, "Software\\WinampAC3\\matrix\\%s", preset);
        delete_reg_key(buf, HKEY_CURRENT_USER);
        SendDlgItemMessage(hwnd, IDC_CMB_MATRIX, WM_SETTEXT, 0, (LONG)"");
        filter->set_auto_matrix(true);
        set_controls();
      }
      break;
    }

    /////////////////////////////////////
    // Delay preset

    case IDC_CMB_DELAY:
      if (message == CBN_SELENDOK)
      {
        char buf[256];
        SendDlgItemMessage(hwnd, IDC_CMB_DELAY, CB_GETLBTEXT, SendDlgItemMessage(hwnd, IDC_CMB_DELAY, CB_GETCURSEL, 0, 0), (LONG)buf);
        SendDlgItemMessage(hwnd, IDC_CMB_DELAY, WM_SETTEXT, 0, (LONG)buf);
        filter->set_delay_on(true);
        filter->load_delay(buf);
        set_controls();
      }
      if (message == CB_ENTER)
      {
        char buf[256];
        SendDlgItemMessage(hwnd, IDC_CMB_DELAY, WM_GETTEXT, 256, (LONG)buf);
        filter->save_delay(buf);                    
        set_controls();
      }
      break;

    case IDC_BTN_DELAY_SAVE:
    {
      char buf[256];
      SendDlgItemMessage(hwnd, IDC_CMB_DELAY, WM_GETTEXT, 256, (LONG)buf);
      filter->save_delay(buf);
      set_controls();
      break;
    }

    case IDC_BTN_DELAY_DELETE:
    {
      char buf[256];
      char preset[256];
      SendDlgItemMessage(hwnd, IDC_CMB_DELAY, WM_GETTEXT, 256, (LONG)preset);

      sprintf(buf, "Are you sure you want to delete '%s' delay preset?", preset);
      if (MessageBox(hwnd, buf, "Delete confirmation", MB_ICONEXCLAMATION | MB_YESNO) == IDYES)
      {     
        sprintf(buf, "Software\\WinampAC3\\delay\\%s", preset);
        delete_reg_key(buf, HKEY_CURRENT_USER);
        SendDlgItemMessage(hwnd, IDC_CMB_DELAY, WM_SETTEXT, 0, (LONG)"");
        filter->set_delay_on(false);
        set_controls();
      }
      break;
    }

    /////////////////////////////////////
    // Equalizer preset

    case IDC_CMB_EQ:
      if (message == CBN_SELENDOK)
      {
        char buf[256];
        SendDlgItemMessage(hwnd, IDC_CMB_EQ, CB_GETLBTEXT, SendDlgItemMessage(hwnd, IDC_CMB_EQ, CB_GETCURSEL, 0, 0), (LONG)buf);
        SendDlgItemMessage(hwnd, IDC_CMB_EQ, WM_SETTEXT, 0, (LONG)buf);
        filter->set_eq_on(true);
        filter->load_eq9(buf);
        set_controls();
      }
      if (message == CB_ENTER)
      {
        char buf[256];
        SendDlgItemMessage(hwnd, IDC_CMB_EQ, WM_GETTEXT, 256, (LONG)buf);
        filter->save_eq9(buf);                    
        set_controls();
      }
      break;

    case IDC_BTN_EQ_SAVE:
    {
      char buf[256];
      SendDlgItemMessage(hwnd, IDC_CMB_EQ, WM_GETTEXT, 256, (LONG)buf);
      filter->save_eq9(buf);
      set_controls();
      break;
    }

    case IDC_BTN_EQ_DELETE:
    {
      char buf[256];
      char preset[256];
      SendDlgItemMessage(hwnd, IDC_CMB_EQ, WM_GETTEXT, 256, (LONG)preset);

      sprintf(buf, "Are you sure you want to delete '%s' equalizer?", preset);
      if (MessageBox(hwnd, buf, "Delete confirmation", MB_ICONEXCLAMATION | MB_YESNO) == IDYES)
      {     
        sprintf(buf, "Software\\WinampAC3\\equalizer\\%s", preset);
        delete_reg_key(buf, HKEY_CURRENT_USER);
        SendDlgItemMessage(hwnd, IDC_CMB_EQ, WM_SETTEXT, 0, (LONG)"");
        filter->set_eq_on(false);
        set_controls();
      }
      break;
    }

  }
}





FileDlg::FileDlg(HWND _parent, const char *_filename)
{
  parent   = _parent;
  hwnd     = 0;
  preset   = true;
  matrix   = false;
  delay    = false;
  eq       = false;

  if (filename)
  {
    memcpy(filename, _filename, min(strlen(_filename)+1, 256));
    filename[255] = 0;
  }
}

FileDlg::~FileDlg()
{}

int
FileDlg::exec()
{
  return DialogBoxParam(GetModuleHandle("in_vac3.dll"), MAKEINTRESOURCE(IDD_FILE), parent, FileDlgProc, (LONG)this);
}



BOOL CALLBACK FileDlg::FileDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
  switch (msg)
  { 
    case WM_INITDIALOG:
    {
      FileDlg *iam = (FileDlg*)lParam;
      SetWindowLong(hwnd, GWL_USERDATA, (LONG)iam);
      if (!iam) return TRUE;

      SetDlgItemText(hwnd, IDC_EDT_FILE_NAME,   iam->filename);
      CheckDlgButton(hwnd, IDC_CHK_FILE_PRESET, iam->preset? BST_CHECKED: BST_UNCHECKED); 
      CheckDlgButton(hwnd, IDC_CHK_FILE_MATRIX, iam->matrix? BST_CHECKED: BST_UNCHECKED); 
      CheckDlgButton(hwnd, IDC_CHK_FILE_DELAY,  iam->delay?  BST_CHECKED: BST_UNCHECKED); 
      CheckDlgButton(hwnd, IDC_CHK_FILE_EQ,     iam->eq?     BST_CHECKED: BST_UNCHECKED); 
      return TRUE;
    }

    case WM_COMMAND:
    {
      FileDlg *iam = (FileDlg *)GetWindowLong(hwnd, GWL_USERDATA);
      if (!iam) return TRUE;

      switch (LOWORD(wParam))
      {

        case IDC_BTN_FILE_CHOOSE:
        {
          OPENFILENAME ofn;

          ofn.lStructSize       = sizeof(OPENFILENAME);
          ofn.hwndOwner         = hwnd;
          ofn.lpstrFilter       = "AC3Filter config files (*.a3f)\0*.a3f\0\0";
          ofn.lpstrCustomFilter = 0;
          ofn.nFilterIndex      = 1;
          ofn.lpstrFile         = iam->filename;
          ofn.nMaxFile          = MAX_PATH;
          ofn.lpstrFileTitle    = 0;
          ofn.lpstrInitialDir   = 0;
          ofn.lpstrTitle        = "WinampAC3 config";
          ofn.lpstrDefExt       = "a3f";
          ofn.Flags             = OFN_ENABLESIZING | OFN_NOCHANGEDIR | OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST;
          GetOpenFileName(&ofn);
          SetDlgItemText(hwnd, IDC_EDT_FILE_NAME, iam->filename);
          return TRUE;
        }

        case IDC_BTN_FILE_SAVE:
        case IDC_BTN_FILE_LOAD:
          GetDlgItemText(hwnd, IDC_EDT_FILE_NAME, iam->filename, MAX_PATH);
          iam->preset = 0 != IsDlgButtonChecked(hwnd, IDC_CHK_FILE_PRESET); 
          iam->matrix = 0 != IsDlgButtonChecked(hwnd, IDC_CHK_FILE_MATRIX); 
          iam->delay  = 0 != IsDlgButtonChecked(hwnd, IDC_CHK_FILE_DELAY); 
          iam->eq     = 0 != IsDlgButtonChecked(hwnd, IDC_CHK_FILE_EQ); 
          // return button ID as result
          EndDialog(hwnd, LOWORD(wParam));
          return TRUE;

        case IDCANCEL:
          EndDialog(hwnd, 0);
          return TRUE;
      }
    }
  }
  return FALSE;      
}
