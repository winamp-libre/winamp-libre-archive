/*
  CPU usage measurement
*/

#ifndef CPU_H
#define CPU_H

#include <windows.h>

class CPUMeter
{
private:
  HANDLE   thread;
  __int64  thread_time;
  __int64  system_time_begin;
  __int64  thread_time_begin;
  __int64  thread_time_total;

public:

  CPUMeter();

  void    reset();
  void    start_measure();
  void    stop_measure();
  double  usage();
  __int64 time();
};

#endif
