#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <commctrl.h>
#include <math.h>
#include "resource.h"
#include "dlg_info.h"


#define dlg_printf(dlg, ctrl, format, params)                     \
{                                                                 \
  char buf[255];                                                  \
  sprintf(buf, format, ##params);                                 \
  SendDlgItemMessage(dlg, ctrl, WM_SETTEXT, 0, (LONG)(LPSTR)buf); \
}

const char *info_ac3_modes[] = 
{
  "1+1 - Dual mono",
  "1/0 - mono",
  "2/0 - stereo",
  "3/0 - 3 front",
  "2/1 - surround",
  "3/1 - surround",
  "2/2 - quadro",
  "3/2 - 5 channels",
  "1+1+LFE Dual mono+LFE",
  "1/0+LFE 1.1 mono",
  "2/0+LFE 2.1 stereo",
  "3/0+LFE 3.1 front",
  "2/1+LFE 3.1 surround",
  "3/1+LFE 4.1 surround",
  "2/2+LFE 4.1 quadro",
  "3/2+LFE 5.1 channels",
  "Dolby Surround",
  "Dolby Surround + LFE",
};

///////////////////////////////////////////////////////////////////////////////
// Initialization / Deinitialization
///////////////////////////////////////////////////////////////////////////////

INT_PTR CALLBACK
InfoDlg::DialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  InfoDlg *dlg;
  if (uMsg == WM_INITDIALOG)
  {
    SetWindowLongPtr(hwnd, DWLP_USER, lParam);

    dlg = (InfoDlg *)lParam;
    if (!dlg) return TRUE;
    dlg->hwnd = hwnd;
  }

  dlg = (InfoDlg *)GetWindowLongPtr(hwnd, DWLP_USER);
  if (!dlg)
    return FALSE;

  return dlg->message(hwnd, uMsg, wParam, lParam);
}

InfoDlg::InfoDlg(HINSTANCE _hinstance, HWND _parent, const char *_filename) 
:dec(_filename)
{
  hinstance = _hinstance;
  parent    = _parent;
  dec.probe();
}

InfoDlg::~InfoDlg()
{
}


int
InfoDlg::run()
{
  return DialogBoxParam(hinstance, MAKEINTRESOURCE(IDD_INFO), parent, DialogProc, (LPARAM)this);
}

///////////////////////////////////////////////////////////////////////////////
// Handle messages
///////////////////////////////////////////////////////////////////////////////

BOOL 
InfoDlg::message(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{        
  switch (uMsg)
  {
    case WM_ACTIVATE:
      init_controls();
      return TRUE;

    case WM_COMMAND:
      if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
        EndDialog(hwnd, LOWORD(wParam));
      return TRUE;
  }
  return FALSE;
}

///////////////////////////////////////////////////////////////////////////////
// Controls initalization/update
///////////////////////////////////////////////////////////////////////////////

void 
InfoDlg::init_controls()
{
  /////////////////////////////////////
  // Stream information

  long len = 0;
  bool pes = false;
  bool inv = false;
  BSI  bsi;
  memset(&bsi, 0, sizeof(bsi));
  if (dec.is_open())
  {
    len = dec.get_length() / 1000;
    pes = dec.is_pes;
    inv = dec.inverse;
    memcpy(&bsi, dec.get_bsi(), sizeof(bsi));
  }

  dlg_printf(hwnd, IDC_EDT_FILE,          "%s", dec.get_filename());
  dlg_printf(hwnd, IDC_EDT_BITRATE,       "%d", bsi.bitrate);
  dlg_printf(hwnd, IDC_EDT_SAMPLE_RATE,   "%d", bsi.sample_rate);
  dlg_printf(hwnd, IDC_EDT_FREQ_COUPLING, "%2.3f", double(bsi.cplbegf)/1000);
  dlg_printf(hwnd, IDC_EDT_FREQ_HIGH,     "%2.3f", double(bsi.chendf[0])/1000);
  SendDlgItemMessage(hwnd, IDC_CHK_PES, BM_SETCHECK, pes? BST_CHECKED: BST_UNCHECKED, 1);
  SendDlgItemMessage(hwnd, IDC_CHK_INV, BM_SETCHECK, inv? BST_CHECKED: BST_UNCHECKED, 1);

  char buf[255];
  sprintf(buf, "%i:%02i:%02i", len/3600, len%3600 / 60, len%3600%60);
  SendDlgItemMessage(hwnd, IDC_EDT_LENGTH, WM_SETTEXT, 0, (LONG)(LPSTR)buf);

  int mode = bsi.spk.mode & 15;
  if (bsi.spk.dolby) 
    mode = (bsi.spk.mode & MODE_LFE)? 17: 16;
  SendDlgItemMessage(hwnd, IDC_EDT_CHANNELS, WM_SETTEXT, 0, (DWORD) (LPSTR)info_ac3_modes[mode]);
}
