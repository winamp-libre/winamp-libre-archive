#include <windows.h>
#include <stdio.h>
#include <io.h>
#include "thread.h"
#include "ac3decoder.h"
#include "sink.h"
#include "vac3dec\ac3file.h"
#include "dlg_conf.h"
#include "dlg_info.h"
#include "resource.h"


///////////////////////////////////////////////////////////////////////////////
//
// WINAMP InMiniSDK
//
///////////////////////////////////////////////////////////////////////////////

// post this to the main window at end of file (after playback as stopped)
#define WM_WA_MPEG_EOF WM_USER+2

typedef struct 
{
  int version;                            // module version (OUT_VER)
  char *description;                      // description of module, with version string
  int id;                                 // module id. each input module gets its own. non-nullsoft modules should
                                          // be >= 65536. 
  
  HWND hMainWindow;                       // winamp's main window (filled in by winamp)
  HINSTANCE hDllInstance;                 // DLL instance handle (filled in by winamp)
  
  void (*Config)(HWND hwndParent);        // configuration dialog 
  void (*About)(HWND hwndParent);         // about dialog
  
  void (*Init)();                         // called when loaded
  void (*Quit)();                         // called when unloaded
  
  int  (*Open)(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms); 
  void (*Close)();                        // close the ol' output device.
  int  (*Write)(char *buf, int len);       
  int  (*CanWrite)();                     // returns number of bytes possible to write at a given time. 
  int  (*IsPlaying)();                    // non0 if output is still going or if data in buffers waiting to be
  int  (*Pause)(int pause);               // returns previous pause state
  void (*SetVolume)(int volume);          // volume is 0-255
  void (*SetPan)(int pan);                // pan is -128 to 128
  void (*Flush)(int t);                   // flushes buffers and restarts output at time t (in ms) 
  int  (*GetOutputTime)();                // returns played time in MS
  int  (*GetWrittenTime)();               // returns time written in MS (used for synching up vis stuff)
  
} Out_Module;



typedef struct 
{
  int version;                            // module type (IN_VER)
  char *description;                      // description of module, with version string
  
  HWND hMainWindow;                       // winamp's main window (filled in by winamp)
  HINSTANCE hDllInstance;                 // DLL instance handle (Also filled in by winamp)
  
  char *FileExtensions;                   // "mp3\0Layer 3 MPEG\0mp2\0Layer 2 MPEG\0mpg\0Layer 1 MPEG\0"
                                          // May be altered from Config, so the user can select what they want
  
  int is_seekable;                        // is this stream seekable? 
  int UsesOutputPlug;                     // does this plug-in use the output plug-ins? (musn't ever change, ever :)
  
  void (*Config)(HWND hwndParent);        // configuration dialog
  void (*About)(HWND hwndParent);         // about dialog
  
  void (*Init)();                         // called at program init
  void (*Quit)();                         // called at program quit
  
  void (*GetFileInfo)(char *file, char *title, int *length_in_ms); // if file == NULL, current playing is used
  int  (*InfoBox)(char *file, HWND hwndParent);
  
  int  (*IsOurFile)(char *fn);            // called before extension checks, to allow detection of mms://, etc

  int  (*Play)(char *fn);                 // return zero on success, -1 on file-not-found, some other value on other (stopping winamp) error
  void (*Pause)();                        // pause stream
  void (*UnPause)();                      // unpause stream
  int  (*IsPaused)();                     // ispaused? return 1 if paused, 0 if not
  void (*Stop)();                         // stop (unload) stream
  
  int  (*GetLength)();                    // get length in ms
  int  (*GetOutputTime)();                // returns current output time in ms. (usually returns outMod->GetOutputTime()
  void (*SetOutputTime)(int time_in_ms);  // seeks to point in stream (in ms). Usually you signal yoru thread to seek, which seeks and calls outMod->Flush()..
  
  void (*SetVolume)(int volume);          // from 0 to 255.. usually just call outMod->SetVolume
  void (*SetPan)(int pan);                // from -127 to 127.. usually just call outMod->SetPan
  
  void (*SAVSAInit)(int maxlatency_in_ms, int srate);   // call once in Play(). maxlatency_in_ms should be the value returned from outMod->Open()
  void (*SAVSADeInit)();                  // call in Stop()
  
  
  void (*SAAddPCMData)(void *PCMData, int nch, int bps, int timestamp); 
  int  (*SAGetMode)();                    // gets csa (the current type (4=ws,2=osc,1=spec))
  void (*SAAdd)(void *data, int timestamp, int csa); // sets the spec data, filled in by winamp
  
  void (*VSAAddPCMData)(void *PCMData, int nch, int bps, int timestamp); // sets the vis data directly from PCM data
  int  (*VSAGetMode)(int *specNch, int *waveNch); // use to figure out what to give to VSAAdd
  void (*VSAAdd)(void *data, int timestamp); // filled in by winamp, called by plug-in
  void (*VSASetInfo)(int nch, int srate);
  
  int  (*dsp_isactive)(); 
  int  (*dsp_dosamples)(short int *samples, int numsamples, int bps, int nch, int srate);
  void (*EQSet)(int on, char data[10], int preamp); // 0-64 each, 31 is +0, 0 is +12, 63 is -12. Do nothing to ignore.
  void (*SetInfo)(int bitrate, int srate, int stereo, int synched); // if -1, changes ignored? :)
  
  Out_Module *outMod; // filled in by winamp, optionally used :)
} In_Module;



///////////////////////////////////////////////////////////////////////////////
//
// Decoder Thread
//
///////////////////////////////////////////////////////////////////////////////

class DecoderThread : public DecoderControl, public Thread
{
protected:
  AC3Speakers spk;
  AC3Speakers spk_new;
  AudioSink  *sink;
  In_Module  *mod;
  CPUMeter    cpu;

  HANDLE      ev_play;
  HANDLE      ev_stop;

  int         seek_pos;
  double      pos;

  enum { state_start, state_stop, state_flush, state_read, state_write }
              state;

  STDMETHODIMP get_cpu_load(double *cpu_load);
  STDMETHODIMP get_config_file(char *filename, int size);

  STDMETHODIMP get_speakers(AC3Speakers *spk);
  STDMETHODIMP set_speakers(AC3Speakers  spk);

public:
  DecoderThread(AudioSink *sink, In_Module *mod);
  ~DecoderThread();

  DWORD process();

  void  seek(int _seek_pos) { seek_pos = _seek_pos; }
  int   get_pos()           { return int(pos);   }

  bool play(const char *filename);
  bool stop();
};

DecoderThread::DecoderThread(AudioSink *_sink, In_Module *_mod):
Thread(true)
{
  spk      = AC3Speakers(MODE_STEREO);
  spk_new  = spk;

  seek_pos = -1;
  state    = state_stop;

  sink    = _sink;
  mod     = _mod;

  ev_play = CreateEvent(0, true, false, 0);
  ev_stop = CreateEvent(0, true, true,  0);

  resume();
}

DecoderThread::~DecoderThread()
{
  stop();
  f_terminate = true;               
  state = state_stop;
  SetEvent(ev_play);

  CloseHandle(ev_play);
  CloseHandle(ev_stop);
}

STDMETHODIMP 
DecoderThread::get_cpu_load(double *cpu_load)
{
  if (cpu_load)
    *cpu_load = cpu.usage();
  return S_OK;
}

STDMETHODIMP 
DecoderThread::get_config_file(char *_filename, int _size)
{
  if (_filename)
    *filename = 0;
  return S_OK;
}

STDMETHODIMP 
DecoderThread::get_speakers(AC3Speakers *_spk)
{
  if (_spk)
    *_spk = spk_new;
  return S_OK;
}

STDMETHODIMP 
DecoderThread::set_speakers(AC3Speakers  _spk)
{
  if (sink->query(_spk, 48000))
  {
    spk_new = _spk;
    return S_OK;
  }
  else
    return E_FAIL;
}

bool 
DecoderThread::play(const char *_filename)
{
  if (!stop()) return false;

  // open file
  open(_filename);
  if (!probe()) return false;

  // open output
  if (sink->query(spk_new, bsi.sample_rate))
    spk = spk_new;
  else
    spk_new = spk;

  if (!sink->open(spk, bsi.sample_rate)) return false;

  sink->get_order(&spk);
  set_mode(spk);
  switch (spk.fmt)
  {
    case FORMAT_PCM16: mixer.level = 32767.0;       break;
    case FORMAT_PCM24: mixer.level = 8388607.0;     break;
    case FORMAT_PCM32: mixer.level = 2147483647.0;  break;
    case FORMAT_FLOAT: mixer.level = 1.0;           break;
  }

  // prepare
  mod->SetInfo(bsi.bitrate / 1000, bsi.sample_rate / 1000, 2, 1);
  reset();

  // run!
  state = state_start;
  SetEvent(ev_play);
  return true;
}

bool 
DecoderThread::stop()
{
  // syncronisation
  ResetEvent(ev_play);
  WaitForSingleObject(ev_stop, 2000);

  // reset all
  if (sink->is_open())
  {
    sink->flush(0);
    sink->close();
  }

  pos      = 0;
  seek_pos = -1;
  state = state_stop;
  
  close();
  reset();

  return true;
}


DWORD 
DecoderThread::process()
{
  WORD out_buf[1536 * 2];  // SPDIF output buffer

  cpu.start_measure();
  while (1)
  {
    // syncronization
    SetEvent(ev_stop);
    WaitForSingleObject(ev_play, INFINITE);
    ResetEvent(ev_stop);

    // termination
    if (f_terminate)
      return 0;

    // decode
    if (seek_pos != -1)
    {
      pos      = seek_pos;
      seek_pos = -1;

      FileDecoder::seek(int(pos));
      sink->flush(int(pos));
      state = state_start;
    }

    switch (state)
    {
    case state_start:
      state = state_read;
      break;

    case state_stop:
      ResetEvent(ev_play);
      break;

    case state_flush:
      PostMessage(mod->hMainWindow, WM_WA_MPEG_EOF, 0, 0);
      state = state_stop;
      break;
/*
      if (!mod->outMod->IsPlaying())
      {
        PostMessage(mod->hMainWindow, WM_WA_MPEG_EOF, 0, 0);
        state = state_stop;
        break;
      }
      else
        Sleep(10);
      break;
*/

    case state_read:
      if (eof())
      {
        state = state_flush;
        break;
      }

      if (!spk.spdif)
      {
        if (!block()) break;
        state = state_write;
      }
      else
      {
        if (!frame()) break;

        memset(out_buf, 0, sizeof(out_buf));

        out_buf[0] = 0xf872;            // Pa  sync word 1 
        out_buf[1] = 0x4e1f;            // Pb  sync word 2 
        out_buf[2] = 0x0001;            // Pc  burst-info (data-type = AC3) 
        out_buf[3] = bsi.frame_size*8;  // Pd  length-code (bits)     
        _swab((char *)buf, (char *)(out_buf+4), bsi.frame_size);

        state = state_write;
      }

    case state_write:
      if (!spk.spdif)
      {
        if (sink->can_write())
        {
          sink->write((const sample_buffer_t *)&samples);
          pos += 256000.0 / double(bsi.sample_rate);
          state = state_read;
        }
        else
          Sleep(50);
      }
      else
      {
        if (sink->can_write_raw(sizeof(out_buf)))
        {
          sink->write_raw(buf, sizeof(out_buf));
          pos += 256000.0 * 6 / double(bsi.sample_rate);
        }
        else
          Sleep(50);
        break;
      }
    }
  }
  cpu.stop_measure();
  return 0;
}

///////////////////////////////////////////////////////////////////////////////
//
//  Winamp In module and support functions
//
///////////////////////////////////////////////////////////////////////////////

void config(HWND parent);
void about(HWND parent);

void init();
void quit();

int  isourfile(char *fn);

int  play(char *filename);
void pause();
void unpause();
int  ispaused();
void stop();

int  getlength();
int  getoutputtime();
void setoutputtime(int seek_pos);

void setvolume(int volume);
void setpan(int pan);

int  infoDlg(char *fn, HWND hwnd);
void getfileinfo(char *filename, char *title, int *length_in_ms);
void eq_set(int on, char data[10], int preamp);

In_Module mod = 
{
  0x100,
  "Valex's AC3 decoder for Winamp v0.5b",
  0,      // hMainWindow
  0,      // hDllInstance
  "AC3\0AC3 Audio File (*.AC3)\0",
  1,      // is_seekable
  0,      // uses output
  config,
  about,
  init,
  quit,
  getfileinfo,
  infoDlg,
  isourfile,
  play,
  pause,
  unpause,
  ispaused,
  stop,

  getlength,
  getoutputtime,
  setoutputtime,
    
  setvolume,
  setpan,
    
  0,0,0,0,0,0,0,0,0, // vis stuff
    
    
  0,0, // dsp
    
  eq_set,
    
  NULL,           // setinfo
    
  0 // out_mod
};

/*
In_Module mod = 
{
  0x100,
  "Valex's AC3 decoder for Winamp v0.6b",
  0,      // hMainWindow
  0,      // hDllInstance
  "AC3\0AC3 Audio File (*.AC3)\0",
  1,      // is_seekable
  0,      // uses output

  config,
  about,

  init,
  quit,

  getfileinfo,
  info_dlg,
  isourfile,

  play,
  pause,
  unpause,
  ispaused,
  stop,

  getlength,
  getoutputtime,
  setoutputtime,
    
  setvolume,
  setpan,
    
  0,0,0,0,0,0,0,0,0, // vis stuff
    
    
  0,0, // dsp
    
  eq_set,
    
  NULL,           // setinfo
    
  0 // out_mod
};
*/



DecoderThread *decoder;
AudioSink     *sink;

int            paused;
HINSTANCE      hinstance;


void config(HWND parent)
{
  TabDlg dlg(hinstance, MAKEINTRESOURCE(IDD_TABDLG), parent); 
  CWinampAC3_conf *sheet;
  sheet = CWinampAC3_conf::create_main(hinstance, decoder);
  dlg.add_page(0, sheet, "Main");
  sheet = CWinampAC3_conf::create_mixer(hinstance, decoder);
  dlg.add_page(1, sheet, "Mixer");
  sheet = CWinampAC3_conf::create_eq(hinstance, decoder);
  dlg.add_page(2, sheet, "Equalizer");
  sheet = CWinampAC3_conf::create_about(hinstance, decoder);
  dlg.add_page(3, sheet, "About");
  dlg.exec("WinampAC3 configuration");
}

void about(HWND parent)
{
  TabDlg dlg(hinstance, MAKEINTRESOURCE(IDD_TABDLG), parent); 
  CWinampAC3_conf *sheet;
  sheet = CWinampAC3_conf::create_about(hinstance, decoder);
  dlg.add_page(0, sheet, "About");
  dlg.exec("WinampAC3 configuration");
}

void init() 
{
  sink    = new DSSink(mod.hMainWindow);
  decoder = new DecoderThread(sink, &mod);
  decoder->load_params();
}

void quit() 
{
  decoder->save_params();
  decoder->save_eq9();
  decoder->save_delay();
  decoder->save_matrix();

  delete decoder;
  delete sink;
}


void getfileinfo(char *filename, char *title, int *length_in_ms)
{
  if (!filename || !*filename)  // currently playing file
  {
    if (length_in_ms) *length_in_ms = decoder->get_length();
    if (title)         
    {
      const char *fn = decoder->get_filename();
      const char *p = fn + strlen(fn);
      while (*p != '\\' && p >= fn) p--;
      strcpy(title, ++p);
    }
  }
  else if (length_in_ms || title) // some other file
  {
    if (length_in_ms) *length_in_ms = 0;
    if (title)        *title = 0;

    // title
    if (title)
    {
      char *p = filename + strlen(filename);
      while (*p != '\\' && p >= filename) p--;
      strcpy(title, ++p);
    }

    // probe file
    FileDecoder probe(filename);
    if (!probe.probe()) return;

    // set info
    if (length_in_ms) 
      *length_in_ms = probe.get_length();
  }
}

int infoDlg(char *filename, HWND hwndParent)
{
  // probe file
  FileDecoder probe(filename);
  if (!probe.probe()) 
  {
    MessageBox(hwndParent, "Not an AC3 file!", "Error", MB_OK | MB_ICONSTOP);
    return 0;
  }

  InfoDlg dlg(hinstance, hwndParent, filename, probe.get_length(), probe.get_bsi(), probe.is_pes); 
  dlg.run();
  return 0;
}

// used for detecting URL streams.. unused here. strncmp(fn,"http://",7) to detect HTTP streams, etc
int isourfile(char *fn) 
{
  return 0; 
} 


int  play(char *filename)  { return decoder->play(filename); }
void pause()               { sink->pause();                  }
void unpause()             { sink->unpause();                }
int  ispaused()            { return sink->is_paused();       }
void stop()                { decoder->stop();                }

int  getlength()           { return decoder->get_length();   } 
int  getoutputtime()       { return decoder->get_pos() - sink->get_lag_time(); }
void setoutputtime(int seek_pos) { decoder->seek(seek_pos);  }

void setvolume(int volume) { sink->set_volume(volume);       }
void setpan(int pan)       { sink->set_pan(pan);             }

void eq_set(int on, char data[10], int preamp) {}




BOOL APIENTRY DllMain(HINSTANCE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
  hinstance = hModule;
  return TRUE;
}

__declspec( dllexport ) In_Module * winampGetInModule2()
{
  return &mod;
}
