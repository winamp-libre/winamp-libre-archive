#ifndef WINAMPAC3_GUIDS_H
#define WINAMPAC3_GUIDS_H

#include <objbase.h>
#include "vac3dec\defs.h"

// SPDIF mode
#define NO_SPDIF     0  // No SPDIF
#define SPDIF_AUTO   1  // Auto SPDIF configuration (=SPDIF_MODE1 by now)
#define SPDIF_MODE1  2  // SPDIF timing mode 1: transmit only timestamps received from upstream
#define SPDIF_MODE2  3  // SPDIF timing mode 2: calculate timestamps

// Sample formats
#define FORMAT_PCM16 0  // PCM 16bit (default)
#define FORMAT_PCM24 2  // PCM 24bit
#define FORMAT_PCM32 3  // PCM 32bit
#define FORMAT_FLOAT 4  // PCM Float

// Output sink
#define SINK_WINAMP   0
#define SINK_DSOUND   1
#define SINK_DSOUND3D 2
#define SINK_FILE     3

#define REG_WINAMPAC3 "Software\\WinampAC3"

class AC3Speakers : public Speakers
{
public:
  // SPDIF mode
  // SPDIF_XXXX constants
  int spdif;

  // Sample format
  // SAMPLE_XXXX constants
  int fmt;

  AC3Speakers(int _mode = MODE_STEREO, int _dolby = NO_DOLBY, int _fmt = FORMAT_PCM16, int _spdif = NO_SPDIF):
  Speakers(_mode, _dolby)
  {
    fmt = _fmt;
    spdif = _spdif;
  }

  inline bool operator ==(AC3Speakers &spk) const
  { 
    return spdif || spk.spdif? spdif == spk.spdif:
           dolby || spk.dolby? dolby == spk.dolby && fmt == spk.fmt:
           mode == spk.mode && fmt == spk.fmt;
  }

  inline bool operator !=(AC3Speakers &spk) const
  { 
    return spdif || spk.spdif? spdif != spk.spdif:
           dolby || spk.dolby? dolby != spk.dolby || fmt != spk.fmt: 
           mode != spk.mode || fmt != spk.fmt;
  }
};


///////////////////////////////////////////////////////////////////////////////
// Interface definitions
///////////////////////////////////////////////////////////////////////////////

class IWinampAC3
{
public:
  // System
  STDMETHOD (get_speakers)  (AC3Speakers *spk) = 0;                                                                 
  STDMETHOD (set_speakers)  (AC3Speakers  spk) = 0; 
  STDMETHOD (query_speakers)(AC3Speakers  spk, bool *supported) = 0;

  STDMETHOD (get_sink)      (int *sink) = 0;
  STDMETHOD (set_sink)      (int  sink) = 0;

  // bit stream information
  STDMETHOD (get_bsi)       (BSI *bsi) = 0;                                                                          
  STDMETHOD (get_cpu_load)  (double *cpu_load) = 0;                                                                
  STDMETHOD (get_stat)      (int *frames, int *errors) = 0; 

  // Gain control
  STDMETHOD (get_gain)      (sample_t *master, sample_t *gain) = 0;                                                  // mixer
  STDMETHOD (set_gain)      (sample_t  master) = 0;                                                                  // mixer
  STDMETHOD (get_gains)     (sample_t *slev, sample_t *clev, sample_t *lfelev) = 0;                                  // mixer
  STDMETHOD (set_gains)     (sample_t  slev, sample_t  clev, sample_t  lfelev) = 0;                                  // mixer
  STDMETHOD (get_bsi_locks) (bool *slev_lock, bool *clev_lock, bool *lfe_lock) = 0;                                  // decoder
  STDMETHOD (set_bsi_locks) (bool  slev_lock, bool  clev_lock, bool  lfe_lock) = 0;                                  // decoder
  STDMETHOD (get_auto_gain) (bool *auto_gain) = 0;                                                                   // mixer
  STDMETHOD (set_auto_gain) (bool  auto_gain) = 0;                                                                   // mixer
  STDMETHOD (get_normalize) (bool *normalize) = 0;                                                                   // mixer
  STDMETHOD (set_normalize) (bool  normalize) = 0;                                                                   // mixer
  STDMETHOD (get_levels)    (sample_t *source, sample_t *max_source, sample_t *speaker, sample_t *max_speaker) = 0;  // mixer

  // DRC
  STDMETHOD (get_dynrng)    (bool *dynrng, sample_t *dynrng_level, sample_t *dynrng_power) = 0;                      // decoder
  STDMETHOD (set_dynrng)    (bool  dynrng, sample_t  dynrng_power) = 0;                                              // decoder

  // Matrix params
  STDMETHOD (get_matrix)    (mixer_matrix_t *matrix) = 0;                                                            // mixer
  STDMETHOD (set_matrix)    (mixer_matrix_t *matrix) = 0;                                                            // mixer
  STDMETHOD (get_auto_matrix)(bool *auto_matrix) = 0;                                                                // decoder
  STDMETHOD (set_auto_matrix)(bool  auto_matrix) = 0;                                                                // decoder
  STDMETHOD (get_normalize_matrix)(bool *normalize_matrix) = 0;                                                      // decoder
  STDMETHOD (set_normalize_matrix)(bool  normalize_matrix) = 0;                                                      // decoder
  STDMETHOD (get_expand_stereo)(bool *expand_stereo) = 0;                                                            // mixer
  STDMETHOD (set_expand_stereo)(bool  expand_stereo) = 0;                                                            // mixer
  STDMETHOD (get_voice_control)(bool *voice_control) = 0;                                                            // mixer
  STDMETHOD (set_voice_control)(bool  voice_control) = 0;                                                            // mixer
  STDMETHOD (get_bass_redir)(bool *bass_redir) = 0;                                                                  // mixer
  STDMETHOD (set_bass_redir)(bool  bass_redir) = 0;                                                                  // mixer

  // Delay
  STDMETHOD (get_delay_on)  (bool *on) = 0;
  STDMETHOD (set_delay_on)  (bool  on) = 0;
  STDMETHOD (get_delay)     (int *delay) = 0;     
  STDMETHOD (set_delay)     (int *delay) = 0;

  // Equalizer
  STDMETHOD (get_eq_on)     (bool *on) = 0;
  STDMETHOD (set_eq_on)     (bool  on) = 0;
  STDMETHOD (get_eq9)       (sample_t *func) = 0;     
  STDMETHOD (set_eq9)       (sample_t *func) = 0;
  STDMETHOD (get_eq9_levels)(sample_t *func) = 0;
  
  // Registry interface
  STDMETHOD (get_config_file)(char *filename, int size)  = 0;
//  STDMETHOD (get_config_autoload)(bool *config_autoload) = 0;
//  STDMETHOD (set_config_autoload)(bool  config_autoload) = 0;

  STDMETHOD (load_params)   (const char *preset = 0, bool file = false) = 0;
  STDMETHOD (save_params)   (const char *preset = 0, bool file = false) = 0;
  STDMETHOD (load_matrix)   (const char *preset = 0, bool file = false) = 0;
  STDMETHOD (save_matrix)   (const char *preset = 0, bool file = false) = 0;
  STDMETHOD (load_delay)    (const char *preset = 0, bool file = false) = 0;
  STDMETHOD (save_delay)    (const char *preset = 0, bool file = false) = 0;
  STDMETHOD (load_eq9)      (const char *preset = 0, bool file = false) = 0;
  STDMETHOD (save_eq9)      (const char *preset = 0, bool file = false) = 0;
};                          

#endif
