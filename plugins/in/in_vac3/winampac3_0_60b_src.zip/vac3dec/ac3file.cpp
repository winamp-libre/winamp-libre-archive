#include <string.h>
#include "ac3file.h"

#define swab16(x) (((x) >> 8) & 0xff | (((x) & 0xff) << 8))


FileDecoder::FileDecoder(const char *_filename, Speakers _spk):
PullDecoder(_spk)
{
  f = 0;
  filename = 0;
  sync_dist = 0;
  inverse = false;
  odd = false;

  open(_filename);
}

FileDecoder::FileDecoder(Speakers _spk):
PullDecoder(_spk)
{
  filename = 0;
  sync_dist = 0;
  inverse = false;
  odd = false;
  f = 0;
}

FileDecoder::~FileDecoder()
{
  close();
}


bool 
FileDecoder::open(const char *_filename)
{
  if (f) close();
  f = fopen(_filename, "rb");
  if (!f) return false;
  filename = strdup(_filename);
  reset();
  return true;
}

void 
FileDecoder::close()
{
  if (f) fclose(f);
  if (filename) 
  {
    delete filename;
    filename = 0;
  }
  sync_dist = 0;
  odd = false;
}

int  
FileDecoder::get_length()    
{ 
  if (sync_dist)
    return filelength(f->_file) / sync_dist * 1536 / (bsi.sample_rate / 1000); 
  if (bsi.frame_size && bsi.sample_rate)
    return filelength(f->_file) / bsi.frame_size * 1536 / (bsi.sample_rate / 1000);
  return 0;
};


bool 
FileDecoder::probe()
{
  if (!f) return false;

  int pos = ftell(f);
  // do not count stat when probing
  int old_frames = frames;
  int old_errors = errors;

  int  i;
  bool failed;

  /////////////////////////////////////////////////////////
  // Try as pure ac3

  reset();
  fseek(f, SEEK_SET, pos);
  is_pes = false;
  inverse = false;
  failed = false;
  for (i = 0; i < 60; i++)  // try to decode 10 frames
    if (!block())
    {
      failed = true;
      break;
    }

  if (!failed) goto probe_ok;

  /////////////////////////////////////////////////////////
  // Try as PES ac3

  reset();
  fseek(f, SEEK_SET, pos);
  is_pes = true;
  inverse = false;
  failed = false;
  for (i = 0; i < 60; i++)  // try to decode 10 frames
    if (!block())
    {
      failed = true;
      break;
    }

  if (!failed) goto probe_ok;

  /////////////////////////////////////////////////////////
  // Try as inverse byteorder ac3

  reset();
  fseek(f, SEEK_SET, pos);
  is_pes = false;
  inverse = true;
  failed = false;
  for (i = 0; i < 60; i++)  // try to decode 10 frames
    if (!block())
    {
      failed = true;
      break;
    }

  if (!failed) goto probe_ok;

  // probe failed
  reset();
  frames = old_frames;
  errors = old_errors;
  fseek(f, pos, SEEK_SET);
  return false;

probe_ok:
  // probe succeeded
  sync_dist = (ftell(f) - bsi.frame_size - pos) / 9;
  reset();
  frames = old_frames;
  errors = old_errors;
  fseek(f, pos, SEEK_SET);
  return true;
}



void
FileDecoder::seek(int pos_ms)
{
  double frame_size = sync_dist? sync_dist: bsi.frame_size;
  int filepos = int(double(pos_ms) * double(frame_size) * double(bsi.sample_rate) / 1536000.0);
  filepos &= ~1; // should be even
  fseek(f, filepos, SEEK_SET);
  reset();
}



long
FileDecoder::get(uint8_t *buf, int len)
{
  if (!f) return 0;
  if (!inverse)
    return fread(buf, 1, len, f);
  else
  {
    uint8_t *orig = buf;
    if (odd && len)
    {
      *buf++ = saved_byte;
      len--;
    }

    int read_len = fread(buf, 1, len & ~1, f);
    uint16_t *buf16 = (uint16_t *)buf;
    for (int i = 0; i < (read_len >> 1); i++)
      buf16[i] = swab16(buf16[i]);

    buf += read_len;
    len -= read_len;

    if (len == 1)
    {
      if (fread(&saved_byte, 1, 1, f))
        buf += fread(buf, 1, 1, f);
      odd = true;
    }
    else
      odd = false;

    return buf - orig;
  }
}
