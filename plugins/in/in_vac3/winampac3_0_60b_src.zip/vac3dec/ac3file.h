#ifndef AC3FILE_H
#define AC3FILE_H

#include <stdio.h>
#include "decoder.h"

class FileDecoder : public PullDecoder
{
protected:
  FILE *f;
  char *filename;
  int   sync_dist;

  bool odd;
  uint8_t saved_byte;
  virtual long get(uint8_t *buf, int len);

public:
  bool inverse;

  FileDecoder(const char *filename, Speakers spk = Speakers(MODE_STEREO));
  FileDecoder(Speakers spk = Speakers(MODE_STEREO));
  ~FileDecoder();

  bool open(const char *filename);
  void close();
  bool probe();

  void seek(int pos_ms);

  bool is_open()       { return f != 0; }
  bool eof()           { return feof(f) != 0; }

  const char *get_filename() { return filename; };
  int  get_filesize()  { return filelength(f->_file); };
  int  get_length();
};


#endif
