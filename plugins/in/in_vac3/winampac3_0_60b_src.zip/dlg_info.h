#ifndef DLG_INFO_H
#define DLG_INFO_H

#include <windows.h>
#include "vac3dec\ac3file.h"
#include "controls.h"


class InfoDlg
{
private:
  static INT_PTR CALLBACK DialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

protected:
  HWND      hwnd;
  HWND      parent;
  HINSTANCE hinstance;

  FileDecoder dec;

  BOOL message(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
  void init_controls();

public:
  InfoDlg(HINSTANCE hinstance, HWND parent, const char *filename);
  ~InfoDlg();

  int run();
};

#endif

