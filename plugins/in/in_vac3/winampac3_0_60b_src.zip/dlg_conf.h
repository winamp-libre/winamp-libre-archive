#ifndef DLG_CONF_H
#define DLG_CONF_H

#include <streams.h>
#include "vac3dec\defs.h"
#include "controls.h"
#include "tab.h"
#include "guids.h"
            

class CWinampAC3_conf : public TabSheet
{
public:
  static CWinampAC3_conf *create_main (HMODULE hmodule, IWinampAC3 *filter);
  static CWinampAC3_conf *create_mixer(HMODULE hmodule, IWinampAC3 *filter);
  static CWinampAC3_conf *create_eq   (HMODULE hmodule, IWinampAC3 *filter);
  static CWinampAC3_conf *create_about(HMODULE hmodule, IWinampAC3 *filter);

  CWinampAC3_conf(HMODULE hmodule, LPCSTR dlg_res, IWinampAC3 *filter, int flags);

private:
  IWinampAC3 *filter;
  bool        visible;
  int         flags;

  /////////////////////////////////////////////////////////
  // Filter state

  // Stats
  AC3Speakers spk;
  int      sink;
  BSI      bsi;
  int      frames, errors;
  double   cpu_load;

  sample_t in_levels[6];
  sample_t out_levels[6];
  sample_t in_level, out_level;

  // Gains
  sample_t master, gain;
  sample_t slev, clev, lfelev;
  bool     slev_lock, clev_lock, lfelev_lock;
  // Matrix
  bool     auto_matrix;
  bool     normalize_matrix;
  // AGC
  bool     auto_gain;
  bool     normalize;
  bool     expand_stereo;
  bool     voice_control;
  bool     bass_redir;
  // DRC
  bool     dynrng;
  sample_t dynrng_level, dynrng_power;
  // Delay
  bool     delay_on;
  int      delay[6];
  // Equalzier
  bool     eq_on;
  sample_t eq[9];
  sample_t eq_levels[9];

  /////////////////////////////////////////////////////////
  // Controls

  ComboBox    cmb_preset;
  // Gains
  DoubleEdit  edt_master;
  DoubleEdit  edt_gain;
  DoubleEdit  edt_voice;
  DoubleEdit  edt_sur;
  DoubleEdit  edt_lfe;
  // Matrix
  ComboBox    cmb_matrix;
  DoubleEdit  edt_matrix[6][6];
  // Delay
  ComboBox    cmb_delay;
  ComboBox    cmb_units;
  int         delay_units;
  DoubleEdit  edt_delay[6];
  // Equalzier
  ComboBox    cmb_eq;
  DoubleEdit  edt_eq[9];
  // Links
  // AC3Filter links
  LinkButton  lnk_ac3filter;
  LinkButton  lnk_sourceforge;
  LinkButton  lnk_forum;
  // Related projects
  LinkButton  lnk_matrix_mixer;
  LinkButton  lnk_winampac3;
  LinkButton  lnk_liba52;
  // Mail
  LinkButton  lnk_email;

  virtual BOOL message(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

  void switch_on();
  void switch_off();

  void reload_state();
  void init_controls();
  void set_dynamic_controls();
  void set_controls();
  void set_matrix_controls();

  void command(int control, int message);
};

class FileDlg
{
protected:
  HWND hwnd;
  HWND parent;
  static BOOL CALLBACK FileDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

public:
  char filename[MAX_PATH];
  bool preset;
  bool matrix;
  bool delay;
  bool eq;

  FileDlg(HWND _parent, const char *_filename = 0);
  ~FileDlg();

  int exec();
};


#endif

