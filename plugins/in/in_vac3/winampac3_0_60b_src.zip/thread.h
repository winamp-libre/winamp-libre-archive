#ifndef CTHREAD_H
#define CTHREAD_H

#include <windows.h>

class Thread
{
private:
  HANDLE f_thread;
  DWORD  f_threadId;
  bool   f_suspended;

  static DWORD WINAPI ThreadProc(LPVOID param);

protected:
  volatile bool   f_terminate;
  virtual DWORD process() = 0;

public:
  Thread(bool suspended = false);
  virtual ~Thread();

  void suspend();
  void resume();
  void terminate(int timeout = 10, DWORD exit_code = 0);

  HANDLE handle()      { return f_thread; }
  bool   terminating() { return f_terminate; }
  bool   terminated()  { return !f_thread; }
  bool   suspended()   { return f_thread? f_suspended: true; }

};


class CritSec 
{
protected:
  CritSec(const CritSec &refCritSec);
  CritSec &operator=(const CritSec &refCritSec);

  CRITICAL_SECTION crit_sec;

public:
  CritSec()     { InitializeCriticalSection(&crit_sec); };
  ~CritSec()    { DeleteCriticalSection(&crit_sec);     };

  void lock()   { EnterCriticalSection(&crit_sec);      };
  void unlock() { LeaveCriticalSection(&crit_sec);      };
};


class AutoLock 
{
protected:
  AutoLock(const AutoLock &refAutoLock);
  AutoLock &operator=(const AutoLock &refAutoLock);

  CritSec *lock;

public:
  AutoLock(CritSec *_lock)
  {
    lock = _lock;
    lock->lock();
  };

  ~AutoLock() 
  {
    lock->unlock();
  };
};



#endif
