#include <objbase.h>
#include <initguid.h>
#include "guids.h"
