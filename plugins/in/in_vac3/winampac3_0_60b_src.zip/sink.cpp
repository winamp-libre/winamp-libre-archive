#include <dsound.h>
#include <mmreg.h>
#include <ks.h>
#include <ksmedia.h>
#include "math.h"
#include "vac3dec\defs.h"
#include "sink.h"

#define SAFE_DELETE(p)  { delete p; p = 0; }
#define SAFE_RELEASE(p) { p->Release(); p = 0; }


#define MAX_CACHE 256
class SpeakersCache
{
protected:
  AC3Speakers allow_cache[MAX_CACHE];
  int         allow_sample_rate[MAX_CACHE];
  AC3Speakers deny_cache[MAX_CACHE];
  int         deny_sample_rate[MAX_CACHE];
  int allow_cache_size;
  int deny_cache_size;

public:
  SpeakersCache(): allow_cache_size(0), deny_cache_size(0) {};

  bool is_allowed(AC3Speakers spk, int sample_rate)
  {
    for (int i = 0; i < allow_cache_size; i++)
      if (spk == allow_cache[i] && sample_rate == allow_sample_rate[i])
        return true;
    return false;
  }

  bool is_denied(AC3Speakers spk, int sample_rate)
  {
    for (int i = 0; i < deny_cache_size; i++)
      if (spk == deny_cache[i] && sample_rate == deny_sample_rate[i])
        return true;
    return false;
  }

  void allow(AC3Speakers spk, int sample_rate)
  {
    if (allow_cache_size < MAX_CACHE)
    {
      allow_cache[allow_cache_size] = spk;
      allow_sample_rate[allow_cache_size] = sample_rate;
      allow_cache_size++;
    }
  }

  void deny(AC3Speakers spk, int sample_rate)
  {
    if (deny_cache_size < MAX_CACHE)
    {
      deny_cache[deny_cache_size] = spk;
      deny_sample_rate[deny_cache_size] = sample_rate;
      deny_cache_size++;
    }
  }

};

SpeakersCache ds_cache;



const int ds_channels[16] = 
{
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_RIGHT,  // double mono as stereo
  SPEAKER_FRONT_CENTER,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_RIGHT,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_CENTER | SPEAKER_FRONT_RIGHT,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_RIGHT  | SPEAKER_BACK_CENTER,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_CENTER | SPEAKER_FRONT_RIGHT  | SPEAKER_BACK_CENTER,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_RIGHT  | SPEAKER_BACK_LEFT    | SPEAKER_BACK_RIGHT,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_CENTER | SPEAKER_FRONT_RIGHT  | SPEAKER_BACK_LEFT    | SPEAKER_BACK_RIGHT,

  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_RIGHT  | SPEAKER_LOW_FREQUENCY,  // double mono as stereo
  SPEAKER_FRONT_CENTER | SPEAKER_LOW_FREQUENCY,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_RIGHT  | SPEAKER_LOW_FREQUENCY,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_CENTER | SPEAKER_FRONT_RIGHT  | SPEAKER_LOW_FREQUENCY,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_RIGHT  | SPEAKER_BACK_CENTER  | SPEAKER_LOW_FREQUENCY,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_CENTER | SPEAKER_FRONT_RIGHT  | SPEAKER_BACK_CENTER  | SPEAKER_LOW_FREQUENCY,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_RIGHT  | SPEAKER_BACK_LEFT    | SPEAKER_BACK_RIGHT   | SPEAKER_LOW_FREQUENCY,
  SPEAKER_FRONT_LEFT   | SPEAKER_FRONT_CENTER | SPEAKER_FRONT_RIGHT  | SPEAKER_BACK_LEFT    | SPEAKER_BACK_RIGHT     | SPEAKER_LOW_FREQUENCY
};

const int ds_order[16][6] = 
{
  { CH_L,   CH_R,     CH_NONE,  CH_NONE,  CH_NONE,  CH_NONE },
  { CH_M,   CH_NONE,  CH_NONE,  CH_NONE,  CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_NONE,  CH_NONE,  CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_C,     CH_NONE,  CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_S,     CH_NONE,  CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_C,     CH_S,     CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_SL,    CH_SR,    CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_C,     CH_SL,    CH_SR,    CH_NONE },

  { CH_L,   CH_R,     CH_LFE,   CH_NONE,  CH_NONE,  CH_NONE },
  { CH_M,   CH_LFE,   CH_NONE,  CH_NONE,  CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_LFE,   CH_NONE,  CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_C,     CH_LFE,   CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_LFE,   CH_S,     CH_NONE,  CH_NONE },
  { CH_L,   CH_R,     CH_C,     CH_LFE,   CH_S,     CH_NONE },
  { CH_L,   CH_R,     CH_LFE,   CH_SL,    CH_SR,    CH_NONE },
  { CH_L,   CH_R,     CH_C,     CH_LFE,   CH_SL,    CH_SR   }
};

const int wa_order[5][6] = 
{
  { CH_M,   CH_NONE,  CH_NONE,  CH_NONE,  CH_NONE,  CH_NONE },  // mono
  { CH_L,   CH_R,     CH_NONE,  CH_NONE,  CH_NONE,  CH_NONE },  // stereo
  { CH_L,   CH_R,     CH_SL,    CH_SR,    CH_NONE,  CH_NONE },  // quadro
  { CH_L,   CH_R,     CH_C,     CH_SL,    CH_SR,    CH_NONE },  // 5 channels
  { CH_L,   CH_R,     CH_C,     CH_LFE,   CH_SL,    CH_SR   }   // 5.1 channels
};

bool spk2wfx(WAVEFORMATEXTENSIBLE *wfx, AC3Speakers spk, int sample_rate, int *buffer_size_ptr = 0)
{
  int buffer_size;

  memset(wfx, 0, sizeof(WAVEFORMATEXTENSIBLE));
  int nchannels = spk.nchans();

  if (!spk.spdif)
  {
    // non-SPDIF format
    switch (spk.fmt)
    {
    case FORMAT_PCM16:
      wfx->Format.wFormatTag = (spk.mode == MODE_STEREO || spk.mode == MODE_MONO || spk.dolby)? WAVE_FORMAT_PCM: WAVE_FORMAT_EXTENSIBLE;
      wfx->Format.nChannels = nchannels;
      wfx->Format.nSamplesPerSec = sample_rate;
      wfx->Format.wBitsPerSample = 16;
      wfx->Format.nBlockAlign = wfx->Format.wBitsPerSample / 8 * wfx->Format.nChannels;
      wfx->Format.nAvgBytesPerSec = wfx->Format.nSamplesPerSec * wfx->Format.nBlockAlign;
      wfx->Format.cbSize = (spk.mode == MODE_STEREO || spk.mode == MODE_MONO)? 0: 22;

      wfx->SubFormat = KSDATAFORMAT_SUBTYPE_PCM;
      wfx->Samples.wValidBitsPerSample = 16;
      wfx->dwChannelMask = ds_channels[spk.mode & 15];

      buffer_size = NSAMPLES * wfx->Format.nBlockAlign;
      break;

    case FORMAT_PCM24:
      wfx->Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
      wfx->Format.nChannels = nchannels;
      wfx->Format.nSamplesPerSec = sample_rate;
      wfx->Format.wBitsPerSample = 24;
      wfx->Format.nBlockAlign = wfx->Format.wBitsPerSample / 8 * wfx->Format.nChannels;
      wfx->Format.nAvgBytesPerSec = wfx->Format.nSamplesPerSec * wfx->Format.nBlockAlign;
      wfx->Format.cbSize = 22;

      wfx->SubFormat = KSDATAFORMAT_SUBTYPE_PCM;
      wfx->Samples.wValidBitsPerSample = 24;
      wfx->dwChannelMask = ds_channels[spk.mode & 15];

      buffer_size = NSAMPLES * wfx->Format.nBlockAlign;
      break;

    case FORMAT_PCM32:
      wfx->Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
      wfx->Format.nChannels = nchannels;
      wfx->Format.nSamplesPerSec = sample_rate;
      wfx->Format.wBitsPerSample = 32;
      wfx->Format.nBlockAlign = wfx->Format.wBitsPerSample / 8 * wfx->Format.nChannels;
      wfx->Format.nAvgBytesPerSec = wfx->Format.nSamplesPerSec * wfx->Format.nBlockAlign;
      wfx->Format.cbSize = 22;

      wfx->SubFormat = KSDATAFORMAT_SUBTYPE_PCM;
      wfx->Samples.wValidBitsPerSample = 32;
      wfx->dwChannelMask = ds_channels[spk.mode & 15];

      buffer_size = NSAMPLES * wfx->Format.nBlockAlign;
      break;

    case FORMAT_FLOAT:
      wfx->Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
      wfx->Format.nChannels = nchannels;
      wfx->Format.nSamplesPerSec = sample_rate;
      wfx->Format.wBitsPerSample = 32;
      wfx->Format.nBlockAlign = wfx->Format.wBitsPerSample / 8 * wfx->Format.nChannels;
      wfx->Format.nAvgBytesPerSec = wfx->Format.nSamplesPerSec * wfx->Format.nBlockAlign;
      wfx->Format.cbSize = 22;

      wfx->SubFormat = KSDATAFORMAT_SUBTYPE_IEEE_FLOAT;
      wfx->Samples.wValidBitsPerSample = 32;
      wfx->dwChannelMask = ds_channels[spk.mode & 15];

      buffer_size = NSAMPLES * wfx->Format.nBlockAlign;
      break;
    }
  }
  if (spk.spdif)
  {
    // SPDIF format
    wfx->Format.wFormatTag = WAVE_FORMAT_DOLBY_AC3_SPDIF;
    wfx->Format.nChannels = 2;
    wfx->Format.nSamplesPerSec = sample_rate;
    wfx->Format.wBitsPerSample = 16;
    wfx->Format.nBlockAlign = 4;
    wfx->Format.nAvgBytesPerSec = wfx->Format.nSamplesPerSec * wfx->Format.nBlockAlign;
    wfx->Format.cbSize = 0;

    buffer_size = 0x1800;
  }

  if (buffer_size_ptr) 
    *buffer_size_ptr = buffer_size;

  return true;
};

void fill_buf(uint8_t *sample_buf, const sample_buffer_t *samples, AC3Speakers spk)
{
  if (!sample_buf || !samples) return;

  int nchannels = spk.nchans();
  int i, ch;

  switch (spk.fmt)
  {
    case FORMAT_PCM16:
    {
      int16_t *buf16 = (int16_t *)sample_buf;
      for (i = 0; i < NSAMPLES; i++) 
      {
        int base = i*nchannels;
        for (ch = 0; ch < nchannels; ch++)
          buf16[base + ch] = (int16_t)(*samples)[ch][i];
      }
      break;
    }

    case FORMAT_PCM24:
    {
      #pragma pack(push, 1)   // do not justify following structure
      struct sample24 {
        uint16_t low; 
        int8_t   high;
      };
      #pragma pack(pop)

      sample24 *buf24 = (sample24 *)sample_buf;
      for (i = 0; i < NSAMPLES; i++)
      {
        int base = i*nchannels;
        for (ch = 0; ch < nchannels; ch++)
        {
          int s = (int)(*samples)[ch][i];
          buf24[base + ch].low  = uint16_t(s & 0xFFFF);
          buf24[base + ch].high = int8_t(s >> 16);
        }
      }
      break;
    }

    case FORMAT_PCM32:
    {
      int32_t *buf32 = (int32_t *)sample_buf;
      for (i = 0; i < NSAMPLES; i++)
      {
        int base = i*nchannels;
        for (ch = 0; ch < nchannels; ch++)
          buf32[base + ch] = (int32_t)(*samples)[ch][i];
      }
      break;
    }

    case FORMAT_FLOAT:
    {  
      float *buffl = (float *)sample_buf;
      for (i = 0; i < NSAMPLES; i++)        
      {
        int base = i*nchannels;
        for (ch = 0; ch < nchannels; ch++)
          buffl[base + ch] = (float)(*samples)[ch][i];
      }
      break;
    }
  }
}


DSSink::DSSink(HWND _hwnd, int _ds_buf_size_ms, int _preload_ms)
{
  hwnd = _hwnd;
  if (!hwnd) hwnd = GetForegroundWindow();
  if (!hwnd) hwnd = GetDesktopWindow();

  ds = 0;
  ds_buf   = 0;
//  ds_buf_prim = 0;
  memset(&wfx, 0, sizeof(wfx));

  sample_buf      = 0;
  sample_buf_size = 0;

  buf_size        = 0;
  buf_size_ms     = _ds_buf_size_ms;
  preload_size    = 0;
  preload_ms      = _preload_ms;
  cur             = 0;
  written_time    = 0;

  spk      = AC3Speakers(MODE_STEREO);
  playing  = false;
  paused   = true;

  volume   = 255;
  pan      = 0;

  if FAILED(DirectSoundCreate(0, &ds, 0))
  {
    ds = 0;
    return;
  }

  if FAILED(ds->SetCooperativeLevel(hwnd, DSSCL_PRIORITY))
  {
    SAFE_RELEASE(ds);
    return;
  }
/*
  DSBUFFERDESC dsbdesc;
  ZeroMemory(&dsbdesc, sizeof(DSBUFFERDESC));
  dsbdesc.dwSize  = sizeof(DSBUFFERDESC);
  dsbdesc.dwFlags = DSBCAPS_PRIMARYBUFFER;
 
  if FAILED(ds->CreateSoundBuffer(&dsbdesc, &ds_buf_prim, 0))
  {
    SAFE_RELEASE(ds);
    return;
  }
*/
}

DSSink::~DSSink()
{
  close();
  if (ds) ds->Release();
}

bool DSSink::query(AC3Speakers _spk, int _sample_rate)
{
  if (!ds) return false;

  if (ds_cache.is_allowed(_spk, _sample_rate)) return true;
  if (ds_cache.is_denied (_spk, _sample_rate)) return false;

  AutoLock autolock(&lock);

  IDirectSoundBuffer  *ds_buf_test;
  WAVEFORMATEXTENSIBLE wfx_test;
  int sample_buf_size_test;

  if (!spk2wfx(&wfx_test, _spk, _sample_rate, &sample_buf_size_test))
  {
    ds_cache.deny(_spk, _sample_rate);
    return false;
  }

  DSBUFFERDESC dsbdesc;
  ZeroMemory(&dsbdesc, sizeof(DSBUFFERDESC));
  dsbdesc.dwSize        = sizeof(DSBUFFERDESC);
  dsbdesc.dwFlags       = DSBCAPS_GETCURRENTPOSITION2 | DSBCAPS_GLOBALFOCUS;
  if (!_spk.spdif)
    dsbdesc.dwFlags    |= DSBCAPS_CTRLVOLUME | DSBCAPS_CTRLPAN;
  dsbdesc.dwBufferBytes = buf_size_ms * wfx_test.Format.nSamplesPerSec * wfx_test.Format.nBlockAlign / 1000;
  dsbdesc.lpwfxFormat   = (WAVEFORMATEX *)&wfx_test;

  if FAILED(ds->CreateSoundBuffer(&dsbdesc, &ds_buf_test, 0)) 
  {
    ds_cache.deny(_spk, _sample_rate);
    return false;
  }

  ds_buf_test->Release();
  ds_cache.allow(_spk, _sample_rate);
  return true;
}

bool DSSink::open(AC3Speakers _spk, int _sample_rate)
{
  if (!ds) return false;
  if (!query(_spk, _sample_rate)) return false;   // update cache

  AutoLock autolock(&lock);

  if (ds_buf) close();

  spk = _spk;
  if (!spk2wfx(&wfx, spk, _sample_rate, &sample_buf_size))
    return false;

  buf_size = buf_size_ms * wfx.Format.nSamplesPerSec * wfx.Format.nBlockAlign / 1000;
  preload_size = preload_ms * wfx.Format.nSamplesPerSec * wfx.Format.nBlockAlign / 1000;
  if (preload_size + sample_buf_size >= buf_size)
    preload_size = buf_size - sample_buf_size;

  DSBUFFERDESC dsbdesc;
  ZeroMemory(&dsbdesc, sizeof(DSBUFFERDESC));
  dsbdesc.dwSize        = sizeof(DSBUFFERDESC);
  dsbdesc.dwFlags       = DSBCAPS_GETCURRENTPOSITION2 | DSBCAPS_GLOBALFOCUS;
  if (!spk.spdif)
    dsbdesc.dwFlags    |= DSBCAPS_CTRLVOLUME | DSBCAPS_CTRLPAN;
  dsbdesc.dwBufferBytes = buf_size;
  dsbdesc.lpwfxFormat   = (WAVEFORMATEX *)&wfx;

  if FAILED(ds->CreateSoundBuffer(&dsbdesc, &ds_buf, 0)) return false;

  void *data;
  DWORD data_bytes;
  if FAILED(ds_buf->Lock(0, buf_size, &data, &data_bytes, 0, 0, 0)) 
  {
    SAFE_RELEASE(ds_buf);
    return false;
  }

  ZeroMemory(data, data_bytes);
  if FAILED(ds_buf->Unlock(data, data_bytes, 0, 0))
  {
    SAFE_RELEASE(ds_buf);
    return false;
  }

  sample_buf = new uint8_t[sample_buf_size];

  ds_buf->SetCurrentPosition(0);
  playing = false;
  paused = false;
  cur = 0;

  set_volume(volume);
  set_pan(pan);

  return true;
}

void DSSink::close()
{
  AutoLock autolock(&lock);

  if (ds_buf)     SAFE_RELEASE(ds_buf);
  if (sample_buf) SAFE_DELETE(sample_buf);
}

void DSSink::flush(int time)
{
  AutoLock autolock(&lock);

  if (!ds_buf) return;

  ds_buf->Stop();
  ds_buf->SetCurrentPosition(0);
  cur = 0;

  playing = false;
  paused = false;
  written_time = time;
  return;
}

void DSSink::get_order(AC3Speakers *spk)
{
  AutoLock autolock(&lock);

  if (!ds_buf) return;
  memcpy(spk->order, ds_order[spk->mode&15], sizeof(spk->order)); // DirectSound channels order
}



bool DSSink::is_open()
{
  AutoLock autolock(&lock);

  return ds_buf != 0;
}

bool DSSink::is_paused()
{
  AutoLock autolock(&lock);

  return paused;
}



int  
DSSink::get_output_time()
{
  AutoLock autolock(&lock);

  return int(written_time - get_lag_time());
}

int  
DSSink::get_written_time()
{
  AutoLock autolock(&lock);

  return int(written_time);
}

int  
DSSink::get_lag_time()
{
  AutoLock autolock(&lock);

  if (!ds_buf) return 0;
  DWORD play_cur, write_cur;
  ds_buf->GetCurrentPosition(&play_cur, &write_cur);
  if (play_cur < cur)
    return (cur - play_cur) * 1000 / wfx.Format.nBlockAlign / wfx.Format.nSamplesPerSec;
  else if (play_cur > cur)
    return (buf_size - play_cur + cur) * 1000 / wfx.Format.nBlockAlign / wfx.Format.nSamplesPerSec;
  else
    return 0;
}



void DSSink::pause()
{
  AutoLock autolock(&lock);

  if (!ds_buf) return;
  ds_buf->Stop();
  paused = true;
}

void DSSink::unpause()
{
  AutoLock autolock(&lock);

  if (!ds_buf) return;
  if (playing)
    ds_buf->Play(0, 0, DSBPLAY_LOOPING);
  paused = false;
}



void DSSink::set_volume(int _volume)
{
  AutoLock autolock(&lock);

  volume = _volume;
  if (ds_buf)
  {
    // Convert volume [0;255] to decibels
    // The volume is specified in hundredths of decibels
    // Zero volume is converted to -100dB
    int v = -10000;
    if (volume)
      v = int(log(double(volume)/255) * 2000);
    ds_buf->SetVolume(int(v));
  }
}

int DSSink::get_volume()
{
  AutoLock autolock(&lock);

  return volume;
}

void DSSink::set_pan(int _pan)
{
  AutoLock autolock(&lock);

  pan = _pan;

  if (ds_buf)
  {
    // Convert value [-128;+128] to decibels
    // The volume is specified in hundredths of decibels
    // Boundaries are converted to +/-100dB
    int p = 0;
    if (pan >= 127)       p = +10000;
    else if (pan <= -127) p = -10000;
    else if (pan > 0)     p = int(-log(1-double(+pan)/128) * 2000);
    else if (pan < 0)     p = int(+log(1-double(-pan)/128) * 2000);
    ds_buf->SetPan(int(p));
  }
}

int DSSink::get_pan()
{
  AutoLock autolock(&lock);

  return pan;
}



bool DSSink::can_write()
{
  AutoLock autolock(&lock);

  if (!ds_buf) return false;
  DWORD play_cur, write_cur;
  bool result;

  ds_buf->GetCurrentPosition(&play_cur, &write_cur);
  if (play_cur > cur)
    result = play_cur - cur >= sample_buf_size;
  else if (play_cur < cur)
    result = play_cur + buf_size - cur >= sample_buf_size;
  else // play_cur = cur
    return !playing;

  return result;
}

bool DSSink::can_write_raw(int size)
{
  AutoLock autolock(&lock);

  if (!ds_buf) return false;
  DWORD play_cur, write_cur;
  bool result;

  ds_buf->GetCurrentPosition(&play_cur, &write_cur);
  if (play_cur > cur)
    result = play_cur - cur >= size;
  else if (play_cur < cur)
    result = play_cur + buf_size - cur >= size;
  else // play_cur = cur
    return !playing && (size < buf_size);

  return result;
}

bool DSSink::write(const sample_buffer_t *samples)
{
  AutoLock autolock(&lock);

  if (!ds_buf) return false;
  if (!can_write()) return false;
  void *data1, *data2;
  DWORD data1_bytes, data2_bytes;

  fill_buf(sample_buf, samples, spk);

  if FAILED(ds_buf->Lock(cur, sample_buf_size, &data1, &data1_bytes, &data2, &data2_bytes, 0))
  {
    close();
    return false;
  }

  memcpy(data1, sample_buf, data1_bytes);
  if (data2_bytes)
    memcpy(data2, sample_buf + data1_bytes, data2_bytes);

  cur += sample_buf_size;
  written_time += sample_buf_size * 1000 / wfx.Format.nBlockAlign / wfx.Format.nSamplesPerSec;

  if FAILED(ds_buf->Unlock(data1, data1_bytes, data2, data2_bytes))
  {
    close();
    return false;
  }

  if (!playing && cur > preload_size)
  {
    if (!paused)
      ds_buf->Play(0, 0, DSBPLAY_LOOPING);
    playing = true;
  }

  if (cur >= buf_size)
    cur -= buf_size;

  return true;
}

bool DSSink::write_raw(uint8_t *buf, int size)
{
  AutoLock autolock(&lock);

  if (!ds_buf) return false;
  if (!can_write_raw(size)) return false;
  void *data1, *data2;
  DWORD data1_bytes, data2_bytes;

  if FAILED(ds_buf->Lock(cur, size, &data1, &data1_bytes, &data2, &data2_bytes, 0))
  {
    close();
    return false;
  }

  memcpy(data1, buf, data1_bytes);
  if (data2_bytes)
    memcpy(data2, buf + data1_bytes, data2_bytes);

  cur += size;
  written_time += buf_size * 1000 / wfx.Format.nBlockAlign / wfx.Format.nSamplesPerSec;
  
  if FAILED(ds_buf->Unlock(data1, data1_bytes, data2, data2_bytes))
  {
    close();
    return false;
  }

  if (!playing && cur > preload_size)
  {
    if (!paused)
      ds_buf->Play(0, 0, DSBPLAY_LOOPING);
    playing = true;
  }

  if (cur >= buf_size)
    cur -= buf_size;

  return true;
}






WinampSink::WinampSink(In_Module *_in)
{
  in = _in;
  out = 0;
  paused = false;
  volume = 0;
  pan = 0;

  sample_buf = 0;
  sample_buf_size = 0;

  spk = AC3Speakers(MODE_STEREO);
  sample_rate = 48000;
}

bool WinampSink::query(AC3Speakers spk, int sample_rate)
{
  if (spk.spdif) return false;

  switch (spk.fmt)
  {
    case FORMAT_PCM16: break;
    case FORMAT_PCM24: break;
    case FORMAT_PCM32: break;
    default: return false;
  }

  if (spk.dolby) return true;

  switch (spk.mode)
  {
    case MODE_1_0: return true;
    case MODE_2_0: return true;
    case MODE_2_2: return true;
    case MODE_3_2: return true;
    case MODE_5_1: return true;
    default: return false;
  }
}

bool WinampSink::open(AC3Speakers _spk, int _sample_rate)
{
  close();


  if (!query(_spk, _sample_rate)) return false;

  int nchannels;
  int bitspersample;

  spk = _spk;
  sample_rate = _sample_rate;
  switch (spk.mode)
  {
    case MODE_1_0: nchannels = 1; break;
    case MODE_2_0: nchannels = 2; break;
    case MODE_2_2: nchannels = 4; break;
    case MODE_3_2: nchannels = 5; break;
    case MODE_5_1: nchannels = 6; break;
    default: return false;
  }

  switch (spk.fmt)
  {
    case FORMAT_PCM16: bitspersample = 16; break;
    case FORMAT_PCM24: bitspersample = 24; break;
    case FORMAT_PCM32: bitspersample = 32; break;
    default: return false;
  }

  out = in->outMod;
  if (!out) return false;

  if (!out->Open(sample_rate, nchannels, bitspersample, -1, -1))
  {
    out = 0;
    return false;
  }

  out->SetVolume(-666);

  WAVEFORMATEXTENSIBLE wfx;
  spk2wfx(&wfx, spk, sample_rate, &sample_buf_size);
  sample_buf = new uint8_t[sample_buf_size];

  return true;
}

void WinampSink::close()
{
  if (out) 
    out->Close();

  if (sample_buf)
    SAFE_DELETE(sample_buf);
  sample_buf_size = 0;

  paused = false;
  out = 0;
}

void WinampSink::flush(int time)
{
  out->Flush(time);
}


void WinampSink::get_order(AC3Speakers *spk)
{
  switch (spk->mode)
  {
    case MODE_1_0: memcpy(spk->order, wa_order[0], sizeof(spk->order)); break;
    case MODE_2_0: memcpy(spk->order, wa_order[1], sizeof(spk->order)); break;
    case MODE_2_2: memcpy(spk->order, wa_order[2], sizeof(spk->order)); break;
    case MODE_3_2: memcpy(spk->order, wa_order[3], sizeof(spk->order)); break;
    case MODE_5_1: memcpy(spk->order, wa_order[4], sizeof(spk->order)); break;
  }
}


bool WinampSink::can_write()
{
  return out->CanWrite() >= sample_buf_size;
}

bool WinampSink::can_write_raw(int size)
{
  return out->CanWrite() >= size;
}

bool WinampSink::write(const sample_buffer_t *samples)
{
  fill_buf(sample_buf, samples, spk);
  return out->Write((char *)sample_buf, sample_buf_size) >= sample_buf_size;
}

bool WinampSink::write_raw(uint8_t *buf, int size)
{
  return out->Write((char *)buf, size) >= size;
}
