#include <windows.h>
#include <winreg.h>
#include <stdio.h>
#include <math.h>
#include "guids.h"
#include "ac3decoder.h"
#include "registry.h"

///////////////////////////////////////////////////////////////////////////////
// Decoder Control
///////////////////////////////////////////////////////////////////////////////

DecoderControl::DecoderControl()
{}

DecoderControl::~DecoderControl()
{}

STDMETHODIMP DecoderControl::get_bsi(BSI *_bsi)
{
  if (_bsi) memcpy(_bsi, &bsi, sizeof(bsi));
  return S_OK;
}

STDMETHODIMP DecoderControl::get_stat(int *_frames, int *_errors)                                                        
{
  if (_frames) *_frames = frames;
  if (_errors) *_errors = errors;
  return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// Gain control

STDMETHODIMP DecoderControl::get_gain(sample_t *_master, sample_t *_gain)
{
  if (_master) *_master = mixer.master;
  if (_gain)   *_gain   = mixer.gain;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_gain(sample_t _master)
{
  mixer.master = _master;
  mixer.gain = _master;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_gains(sample_t *_slev, sample_t *_clev, sample_t *_lfelev)                                 
{
  if (_slev)   *_slev   = mixer.slev;
  if (_clev)   *_clev   = mixer.clev;
  if (_lfelev) *_lfelev = mixer.lfelev;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_gains(sample_t _slev, sample_t _clev, sample_t _lfelev)                                 
{
  mixer.slev   = _slev;
  mixer.clev   = _clev;
  mixer.lfelev = _lfelev;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_bsi_locks(bool *_slev_lock, bool *_clev_lock, bool *_lfe_lock)                                 
{
  if (_slev_lock) *_slev_lock = slev_lock;
  if (_clev_lock) *_clev_lock = clev_lock;
  if (_lfe_lock)  *_lfe_lock  = lfelev_lock;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_bsi_locks(bool _slev_lock, bool _clev_lock, bool _lfe_lock)                                 
{
  slev_lock   = _slev_lock;
  clev_lock   = _clev_lock;
  lfelev_lock = _lfe_lock;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_auto_gain(bool *_auto_gain)                                                                  
{
  if (_auto_gain) *_auto_gain = mixer.auto_gain;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_auto_gain(bool _auto_gain)                                                                  
{
  mixer.auto_gain = _auto_gain;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_normalize(bool *_normalize)                                                                  
{
  if (_normalize) *_normalize = mixer.normalize;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_normalize(bool _normalize)                                                                  
{
  mixer.normalize = _normalize;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_levels(sample_t *_source, sample_t *_max_source, sample_t *_speaker, sample_t *_max_speaker)
{
  if (_max_source)  *_max_source  = 1.0;
  if (_max_speaker) *_max_speaker = mixer.level;
  if (_source)      
  {
    memcpy(_source,  &mixer.in_levels, sizeof(mixer.in_levels));
    memset(&mixer.in_levels, 0, sizeof(mixer.in_levels));
  }
  if (_speaker)     
  {
    memcpy(_speaker, &mixer.out_levels, sizeof(mixer.out_levels));
    memset(&mixer.out_levels, 0, sizeof(mixer.out_levels));
  }
  return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// DRC

STDMETHODIMP DecoderControl::get_dynrng(bool *_dynrng, sample_t *_dynrng_level, sample_t *_dynrng_power)
{
  if (_dynrng)       *_dynrng = dynrng;
  if (_dynrng_level) *_dynrng_level = mixer.dynrng;
  if (_dynrng_power) *_dynrng_power = dynrng_power;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_dynrng(bool _dynrng, sample_t _dynrng_power)
{
  dynrng = _dynrng;
  dynrng_power = _dynrng_power;
  return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// Matrix params

STDMETHODIMP DecoderControl::get_matrix(mixer_matrix_t *_matrix)                                    
{
  if (_matrix) memcpy(_matrix, mixer.matrix, sizeof(mixer_matrix_t));
  return S_OK;
}

STDMETHODIMP DecoderControl::set_matrix(mixer_matrix_t *_matrix)                                                           
{
  if (_matrix) memcpy(mixer.matrix, _matrix, sizeof(mixer_matrix_t));
  return S_OK;
}

STDMETHODIMP DecoderControl::get_auto_matrix(bool *_auto_matrix)                                                              
{
  if (_auto_matrix) *_auto_matrix = auto_matrix;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_auto_matrix(bool _auto_matrix)                                                              
{
  auto_matrix = _auto_matrix;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_normalize_matrix(bool *_normalize_matrix)                                                                  
{
  if (_normalize_matrix) *_normalize_matrix = normalize_matrix;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_normalize_matrix(bool _normalize_matrix)                                                                  
{
  normalize_matrix = _normalize_matrix;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_expand_stereo(bool *_expand_stereo)
{
  if (_expand_stereo) *_expand_stereo = mixer.expand_stereo;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_expand_stereo(bool  _expand_stereo)
{
  mixer.expand_stereo = _expand_stereo;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_voice_control(bool *_voice_control)
{
  if (_voice_control) *_voice_control = mixer.voice_control;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_voice_control(bool  _voice_control)
{
  mixer.voice_control = _voice_control;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_bass_redir(bool *_bass_redir)
{
  if (_bass_redir) *_bass_redir = bass_redir;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_bass_redir(bool  _bass_redir)
{
  bass_redir = _bass_redir;
  return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// Delay

STDMETHODIMP DecoderControl::get_delay_on(bool *on)
{
  if (on) *on = d.get_on();
  return S_OK;
}

STDMETHODIMP DecoderControl::set_delay_on(bool  on)
{
  d.set_on(on);
  return S_OK;
}

STDMETHODIMP DecoderControl::get_delay(int *delay)
{
  if (delay) d.get_delay(delay);
  return S_OK;
}

STDMETHODIMP DecoderControl::set_delay(int *delay)
{
  if (delay) d.set_delay(delay);
  return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// Equalizer

STDMETHODIMP DecoderControl::get_eq_on(bool *on)
{
  if (on) *on = eq.on;
  return S_OK;
}

STDMETHODIMP DecoderControl::set_eq_on(bool  on)
{
  eq.on = on;
  return S_OK;
}

STDMETHODIMP DecoderControl::get_eq9(sample_t *func)
{
  if (func) eq.get_func9(func);
  return S_OK;
}

STDMETHODIMP DecoderControl::set_eq9(sample_t *func)
{
  if (func) eq.set_func9(func);
  return S_OK;
}

STDMETHODIMP DecoderControl::get_eq9_levels(sample_t *func)
{
  if (func) eq.get_levels9(func);
  return S_OK;
}

///////////////////////////////////////////////////////////////////////////////
// Registry interface

STDMETHODIMP DecoderControl::load_params(const char *_preset, bool file)
{
  // Speaker config
  AC3Speakers spk;
  int mode;
  int dolby;
  int spdif;
  int fmt;
  int sink;
  // Config autoload
//  bool config_autoload;
  // Gain control
  sample_t master, gain;
  sample_t slev, clev, lfelev;
  bool slev_lock, clev_lock, lfelev_lock;
  bool auto_gain;
  bool normalize;
  // DRC
  bool dynrng;
  sample_t dynrng_level, dynrng_power;
  // Matrix params
  bool auto_matrix;
  bool normalize_matrix;
  bool expand_stereo;
  bool voice_control;
  bool bass_redir;
  char matrix[256];
  // Equalizer & Delay
  bool eq_on;
  bool delay_on;
  char eq9[256];
  char delay[256];

  Config *conf = 0;

  if (file)
    conf = new FileConfig(_preset, "preset");
  else
  {
    /////////////////////////////////////
    // Open registry

    char preset[256];
    if (_preset)
      sprintf(preset, "Software\\WinampAC3\\preset\\%s", _preset);
    else
      sprintf(preset, "Software\\WinampAC3\\preset\\_default");

    // if registry key does not exist then default values will be loaded
    conf = new RegistryKey (preset);
  }

  if (!conf) return S_FALSE;

  /////////////////////////////////////
  // Load current state

  // Speakers
  get_speakers(&spk);
  mode = spk.mode;
  dolby = spk.dolby;
  spdif = spk.spdif;
  fmt = spk.fmt;
  get_sink(&sink);
  // Config autoload
//  get_config_autoload(&config_autoload);
  // Gain coltrol
  get_gain(&master, &gain);
  get_gains(&slev, &clev, &lfelev);
  get_bsi_locks(&slev_lock, &clev_lock, &lfelev_lock);
  get_auto_gain(&auto_gain);
  get_normalize(&normalize);
  // DRC
  get_dynrng(&dynrng, &dynrng_level, &dynrng_power);
  // Matrix params
  get_auto_matrix(&auto_matrix);
  get_normalize_matrix(&normalize_matrix);
  get_expand_stereo(&expand_stereo);
  get_voice_control(&voice_control);
  get_bass_redir(&bass_redir);
  // Equalzier & Delay
  get_eq_on(&eq_on);
  get_delay_on(&delay_on);

  /////////////////////////////////////
  // Load registry

  // Speaker config
  conf->get_int32 ("mode",             mode            );
  conf->get_int32 ("dolby",            dolby           );
  conf->get_int32 ("spdif",            spdif           );
  conf->get_int32 ("format",           fmt             );
  conf->get_int32 ("sink",             sink            );
  // Config autoload
//  conf->get_bool  ("config_autoload",  config_autoload );
  // Gain control
  conf->get_double("master",           master          );
  conf->get_double("clev",             clev            );
  conf->get_double("slev",             slev            );
  conf->get_double("lfelev",           lfelev          );
  conf->get_bool  ("slev_lock",        slev_lock       );
  conf->get_bool  ("clev_lock",        clev_lock       );
  conf->get_bool  ("lfelev_lock",      lfelev_lock     );
  conf->get_bool  ("auto_gain",        auto_gain       );
  conf->get_bool  ("normalize",        normalize       );
  // DRC
  conf->get_bool  ("dynrng",           dynrng          );
  conf->get_double("dynrng_power",     dynrng_power    );
  // Matrix params                                                     
  conf->get_bool  ("auto_matrix",      auto_matrix     );
  conf->get_bool  ("normalize_matrix", normalize_matrix);
  conf->get_bool  ("expand_stereo",    expand_stereo   );
  conf->get_bool  ("voice_control",    voice_control   );
  conf->get_bool  ("bass_redir",       bass_redir      );
  // Equalizer & Delay
  conf->get_bool  ("eq_on",            eq_on           );
  conf->get_bool  ("delay_on",         delay_on        );

  /////////////////////////////////////
  // Set params

  // Speaker config
  spk = AC3Speakers(mode, dolby, fmt, spdif);
  if (!spk.error())
    set_speakers(spk);
  set_sink(sink);
  // Config autoload
//  set_config_autoload(config_autoload);
  // gain control
  set_gain(master);
  set_gains(slev, clev, lfelev);
  set_bsi_locks(slev_lock, clev_lock, lfelev_lock);
  set_auto_gain(auto_gain);
  set_normalize(normalize);
  // DRC
  set_dynrng(dynrng, dynrng_power);
  // Matrix params
  set_auto_matrix(auto_matrix);
  set_normalize_matrix(normalize_matrix);
  set_expand_stereo(expand_stereo);
  set_voice_control(voice_control);
  set_bass_redir(bass_redir);

  if (conf->get_text("matrix", matrix, 256))
    load_matrix(matrix);

  // Equalizer & Delay
  if (conf->get_text("eq9", eq9, 256)) 
    load_eq9(eq9);

  if (conf->get_text("delay", delay, 256)) 
    load_delay(delay);

  set_eq_on(eq_on);
  set_delay_on(delay_on);

  return S_OK;
}

STDMETHODIMP DecoderControl::save_params(const char *_preset, bool file)
{
  // Speaker config
  AC3Speakers spk;
  int sink;
  // Config autoload
//  bool config_autoload;
  // Gain control
  sample_t master, gain;
  sample_t slev, clev, lfelev;
  bool slev_lock, clev_lock, lfelev_lock;
  bool auto_gain;
  bool normalize;
  // DRC
  bool dynrng;
  sample_t dynrng_power, dynrng_level;
  // Matrix params
  bool auto_matrix;
  bool normalize_matrix;
  bool expand_stereo;
  bool voice_control;
  bool bass_redir;
  // Equalizer & Delay
  bool eq_on;
  bool delay_on;

  Config *conf = 0;

  if (file)
  {
    conf = new FileConfig(_preset, "preset");
    if (!conf) return S_FALSE;
  }
  else
  {
    /////////////////////////////////////
    // Open registry

    char preset[256];
    if (_preset)
      sprintf(preset, "Software\\WinampAC3\\preset\\%s", _preset);
    else
      sprintf(preset, "Software\\WinampAC3\\preset\\_default");

    RegistryKey *reg = new RegistryKey(preset);
    if (!reg) return S_FALSE;

    if (!reg->is_ok())
    {
      // try to create new key for new preset
      reg->create_key("Software", "WinampAC3");
      reg->create_key("Software\\WinampAC3", "preset");
      if (_preset)
        reg->create_key("Software\\WinampAC3\\preset", _preset);
      else
        reg->create_key("Software\\WinampAC3\\preset", "_default");
    }

    if (!reg->is_ok()) return S_FALSE;
    conf = reg;
  }

  /////////////////////////////////////
  // Load values

  // Speakers
  get_speakers(&spk);
  get_sink(&sink);
  // Config autoload
//  get_config_autoload(&config_autoload);
  // Gain coltrol
  get_gain(&master, &gain);
  get_gains(&slev, &clev, &lfelev);
  get_bsi_locks(&slev_lock, &clev_lock, &lfelev_lock);
  get_auto_gain(&auto_gain);
  get_normalize(&normalize);
  // DRC
  get_dynrng(&dynrng, &dynrng_level, &dynrng_power);
  // Matrix params
  get_auto_matrix(&auto_matrix);
  get_normalize_matrix(&normalize_matrix);
  get_expand_stereo(&expand_stereo);
  get_voice_control(&voice_control);
  get_bass_redir(&bass_redir);
  // Equalzier & Delay
  get_eq_on(&eq_on);
  get_delay_on(&delay_on);

  /////////////////////////////////////
  // Save values to registry

  if (!file && !_preset)
  {
    conf->set_int32 ("mode"             ,spk.mode        );
    conf->set_int32 ("dolby"            ,spk.dolby       );
    conf->set_int32 ("spdif"            ,spk.spdif       );
    conf->set_int32 ("format"           ,spk.fmt         );
    conf->set_int32 ("sink"             ,sink            );
    // Config autoload
//    conf->set_bool  ("config_autoload"  ,config_autoload );
  }
  // Gain control
  conf->set_double  ("master"           ,master          );
  conf->set_double  ("clev"             ,clev            );
  conf->set_double  ("slev"             ,slev            );
  conf->set_double  ("lfelev"           ,lfelev          );
  conf->set_bool    ("clev_lock"        ,clev_lock       );
  conf->set_bool    ("slev_lock"        ,slev_lock       );
  conf->set_bool    ("lfelev_lock"      ,lfelev_lock     );
  conf->set_bool    ("auto_gain"        ,auto_gain       );
  conf->set_bool    ("normalize"        ,normalize       );
  // DRC
  conf->set_bool    ("dynrng"           ,dynrng          );
  conf->set_double  ("dynrng_power"     ,dynrng_power    );
  // Matrix params
  conf->set_bool    ("normalize_matrix" ,normalize_matrix);
  conf->set_bool    ("auto_matrix"      ,auto_matrix     );
  conf->set_bool    ("expand_stereo"    ,expand_stereo   );
  conf->set_bool    ("voice_control"    ,voice_control   );
  conf->set_bool    ("bass_redir"       ,bass_redir      );
  // Equalizer & Delay
  conf->set_bool    ("eq_on"            ,eq_on           );
  conf->set_bool    ("delay_on"         ,delay_on        );

  return S_OK;
}

STDMETHODIMP DecoderControl::load_matrix(const char *_preset, bool file)
{
  mixer_matrix_t matrix;
  get_matrix(&matrix);

  Config *conf = 0;

  if (file)
    conf = new FileConfig(_preset, "matrix");
  else
  {
    /////////////////////////////////////
    // Open registry

    char preset[256];
    if (_preset)
      sprintf(preset, "Software\\WinampAC3\\matrix\\%s", _preset);
    else
      sprintf(preset, "Software\\WinampAC3\\matrix\\_default");

    // if registry key does not exist then default values will be loaded
    conf = new RegistryKey(preset);
  }

  if (!conf) return S_FALSE;

  /////////////////////////////////////
  // Load registry

  conf->get_double("L_L",     matrix[0][0]);
  conf->get_double("L_C",     matrix[0][1]);
  conf->get_double("L_R",     matrix[0][2]);
  conf->get_double("L_SL",    matrix[0][3]);
  conf->get_double("L_SR",    matrix[0][4]);
  conf->get_double("L_LFE",   matrix[0][5]);
                                          
  conf->get_double("C_L",     matrix[1][0]);
  conf->get_double("C_C",     matrix[1][1]);
  conf->get_double("C_R",     matrix[1][2]);
  conf->get_double("C_SL",    matrix[1][3]);
  conf->get_double("C_SR",    matrix[1][4]);
  conf->get_double("C_LFE",   matrix[1][5]);
                                          
  conf->get_double("R_L",     matrix[2][0]);
  conf->get_double("R_C",     matrix[2][1]);
  conf->get_double("R_R",     matrix[2][2]);
  conf->get_double("R_SL",    matrix[2][3]);
  conf->get_double("R_SR",    matrix[2][4]);
  conf->get_double("R_LFE",   matrix[2][5]);
                                          
  conf->get_double("SL_L",    matrix[3][0]);
  conf->get_double("SL_C",    matrix[3][1]);
  conf->get_double("SL_R",    matrix[3][2]);
  conf->get_double("SL_SL",   matrix[3][3]);
  conf->get_double("SL_SR",   matrix[3][4]);
  conf->get_double("SL_LFE",  matrix[3][5]);
                                          
  conf->get_double("SR_L",    matrix[4][0]);
  conf->get_double("SR_C",    matrix[4][1]);
  conf->get_double("SR_R",    matrix[4][2]);
  conf->get_double("SR_SL",   matrix[4][3]);
  conf->get_double("SR_SR",   matrix[4][4]);
  conf->get_double("SR_LFE",  matrix[4][5]);
                                          
  conf->get_double("LFE_L",   matrix[5][0]);
  conf->get_double("LFE_C",   matrix[5][1]);
  conf->get_double("LFE_R",   matrix[5][2]);
  conf->get_double("LFE_SL",  matrix[5][3]);
  conf->get_double("LFE_SR",  matrix[5][4]);
  conf->get_double("LFE_LFE", matrix[5][5]);

  /////////////////////////////////////
  // Set params

  set_matrix(&matrix);

  return S_OK;
}

STDMETHODIMP DecoderControl::save_matrix(const char *_preset, bool file)
{
  mixer_matrix_t matrix;
  get_matrix(&matrix);

  Config *conf = 0;

  if (file)
  {
    conf = new FileConfig(_preset, "matrix");
    if (!conf) return S_FALSE;
  }
  else
  {
    /////////////////////////////////////
    // Open registry

    char preset[256];
    if (_preset)
      sprintf(preset, "Software\\WinampAC3\\matrix\\%s", _preset);
    else
      sprintf(preset, "Software\\WinampAC3\\matrix\\_default");

    RegistryKey *reg = new RegistryKey(preset);
    if (!reg) return S_FALSE;

    if (!reg->is_ok())
    {
      // try to create key for new preset
      reg->create_key("Software", "WinampAC3");
      reg->create_key("Software\\WinampAC3", "matrix");
      if (_preset)
        reg->create_key("Software\\WinampAC3\\matrix", _preset);
      else
        reg->create_key("Software\\WinampAC3\\matrix", "_default");
    }

    if (!reg->is_ok()) return S_FALSE;
    conf = reg;
  }


  /////////////////////////////////////
  // Save values to registry

  conf->set_double("L_L",    matrix[0][0]);
  conf->set_double("L_C",    matrix[0][1]);
  conf->set_double("L_R",    matrix[0][2]);
  conf->set_double("L_SL",   matrix[0][3]);
  conf->set_double("L_SR",   matrix[0][4]);
  conf->set_double("L_LFE",  matrix[0][5]);
                                       
  conf->set_double("C_L",    matrix[1][0]);
  conf->set_double("C_C",    matrix[1][1]);
  conf->set_double("C_R",    matrix[1][2]);
  conf->set_double("C_SL",   matrix[1][3]);
  conf->set_double("C_SR",   matrix[1][4]);
  conf->set_double("C_LFE",  matrix[1][5]);
                                       
  conf->set_double("R_L",    matrix[2][0]);
  conf->set_double("R_C",    matrix[2][1]);
  conf->set_double("R_R",    matrix[2][2]);
  conf->set_double("R_SL",   matrix[2][3]);
  conf->set_double("R_SR",   matrix[2][4]);
  conf->set_double("R_LFE",  matrix[2][5]);
      
  conf->set_double("SL_L",   matrix[3][0]);
  conf->set_double("SL_C",   matrix[3][1]);
  conf->set_double("SL_R",   matrix[3][2]);
  conf->set_double("SL_SL",  matrix[3][3]);
  conf->set_double("SL_SR",  matrix[3][4]);
  conf->set_double("SL_LFE", matrix[3][5]);
                                       
  conf->set_double("SR_L",   matrix[4][0]);
  conf->set_double("SR_C",   matrix[4][1]);
  conf->set_double("SR_R",   matrix[4][2]);
  conf->set_double("SR_SL",  matrix[4][3]);
  conf->set_double("SR_SR",  matrix[4][4]);
  conf->set_double("SR_LFE", matrix[4][5]);

  conf->set_double("LFE_L",  matrix[5][0]);
  conf->set_double("LFE_C",  matrix[5][1]);
  conf->set_double("LFE_R",  matrix[5][2]);
  conf->set_double("LFE_SL", matrix[5][3]);
  conf->set_double("LFE_SR", matrix[5][4]);
  conf->set_double("LFE_LFE",matrix[5][5]);

  return S_OK;
}

STDMETHODIMP DecoderControl::load_delay(const char *_preset, bool file)
{
  int delay[NCHANNELS];
  get_delay(delay);

  Config *conf = 0;

  if (file)
    conf = new FileConfig(_preset, "delay");
  else
  {
    /////////////////////////////////////
    // Open registry

    char preset[256];
    if (_preset)
      sprintf(preset, "Software\\WinampAC3\\delay\\%s", _preset);
    else
      sprintf(preset, "Software\\WinampAC3\\delay\\_default");

    // if registry key does not exist then default values will be loaded
    conf = new RegistryKey(preset);
  }

  if (!conf) return S_FALSE;

  /////////////////////////////////////
  // Load registry

  conf->get_int32("L",   delay[CH_L]  );
  conf->get_int32("C",   delay[CH_C]  );
  conf->get_int32("R",   delay[CH_R]  );
  conf->get_int32("SL",  delay[CH_SL] );
  conf->get_int32("SR",  delay[CH_SR] );
  conf->get_int32("LFE", delay[CH_LFE]);

  /////////////////////////////////////
  // Set params

  set_delay(delay);

  return S_OK;
}

STDMETHODIMP DecoderControl::save_delay(const char *_preset, bool file)
{
  int delay[NCHANNELS];
  get_delay(delay);

  Config *conf = 0;

  if (file)
  {
    conf = new FileConfig(_preset, "delay");
    if (!conf) return S_FALSE;
  }
  else
  {
    /////////////////////////////////////
    // Open registry

    char preset[256];
    if (_preset)
      sprintf(preset, "Software\\WinampAC3\\delay\\%s", _preset);
    else
      sprintf(preset, "Software\\WinampAC3\\delay\\_default");

    RegistryKey *reg = new RegistryKey(preset);
    if (!reg) return S_FALSE;

    if (!reg->is_ok())
    {
      // try to create key for new preset
      reg->create_key("Software", "WinampAC3");
      reg->create_key("Software\\WinampAC3", "delay");
      if (_preset)
        reg->create_key("Software\\WinampAC3\\delay", _preset);
      else
        reg->create_key("Software\\WinampAC3\\delay", "_default");
    }

    if (!reg->is_ok()) return S_FALSE;
    conf = reg;
  }

  /////////////////////////////////////
  // Save values to registry

  conf->set_int32("L"  , delay[CH_L]);
  conf->set_int32("C"  , delay[CH_C]);
  conf->set_int32("R"  , delay[CH_R]);
  conf->set_int32("SL" , delay[CH_SL]);
  conf->set_int32("SR" , delay[CH_SR]);
  conf->set_int32("LFE", delay[CH_LFE]);

  return S_OK;
}

STDMETHODIMP DecoderControl::load_eq9(const char *_preset, bool file)
{
  Config *conf = 0;

  if (file)
    conf = new FileConfig(_preset, "eq9");
  else
  {
    /////////////////////////////////////
    // Open registry

    char preset[256];
    if (_preset)
      sprintf(preset, "Software\\WinampAC3\\equalizer\\%s", _preset);
    else
      sprintf(preset, "Software\\WinampAC3\\equalizer\\_default");

    // if registry key does not exist then default values will be loaded
    conf = new RegistryKey(preset);
  }

  if (!conf) return S_FALSE;

  /////////////////////////////////////
  // Load registry

  char bin[9];
  sample_t func[9];
  eq.get_func9(func);
  for (int i = 0; i < 9; i++)
  {
    sprintf(bin, "eq9_%i", i);
    conf->get_double(bin, func[i]);
  }

  /////////////////////////////////////
  // Set params

  eq.set_func9(func);

  return S_OK;
}

STDMETHODIMP DecoderControl::save_eq9(const char *_preset, bool file)
{
  Config *conf = 0;

  if (file)
  {
    conf = new FileConfig(_preset, "eq9");
    if (!conf) return S_FALSE;
  }
  else
  {
    /////////////////////////////////////
    // Open registry

    char preset[256];
    if (_preset)
      sprintf(preset, "Software\\WinampAC3\\equalizer\\%s", _preset);
    else
      sprintf(preset, "Software\\WinampAC3\\equalizer\\_default");

    RegistryKey *reg = new RegistryKey(preset);
    if (!reg->is_ok())
    {
      // try to create key for new preset
      reg->create_key("Software", "WinampAC3");
      reg->create_key("Software\\WinampAC3", "equalizer");
      if (_preset)
        reg->create_key("Software\\WinampAC3\\equalizer", _preset);
      else
        reg->create_key("Software\\WinampAC3\\equalizer", "_default");
    }

    if (!reg->is_ok()) return S_FALSE;
    conf = reg;
  }

  /////////////////////////////////////
  // Save values to registry

  char bin[9];
  sample_t func[9];
  eq.get_func9(func);
  for (int i = 0; i < 9; i++)
  {
    sprintf(bin, "eq9_%i", i);
    conf->set_double(bin, func[i]);
  }

  return S_OK;
}
                                           
