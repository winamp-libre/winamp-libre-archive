This program is a Winamp 2.x input plugin to decode .ac3 files.
Distributed under GNU General Public License version 2.

Home page:        http://winampac3.sourceforge.net
Sourceforge:      http://sourceforge.net/projects/winampac3

Contact Author: mailto:xvalex@mail.ru?Subject=WinampAC3

Copyright (c) 2002-2003 by Alexander Vigovsky (xvalex@mail.ru)
