/*
  DecoderControl

  Controllable decoder class.
  Controls decoder via COM interface. 
  Registry interface (state load/save).
  CPU measurement.
  ISpecifyPropertyPages
*/


#ifndef AC3DECODER_H
#define AC3DECODER_H

#include "vac3dec\ac3file.h"
#include "guids.h"
#include "cpu.h"

///////////////////////////////////////////////////////////////////////////////
// DecoderControl class
///////////////////////////////////////////////////////////////////////////////

class DecoderControl: 
  public FileDecoder, 
  public IWinampAC3
{
public:
  DecoderControl();
  ~DecoderControl();

public:
  /////////////////////////////////////////////////////////
  // IAC3Filter

  // bit stream information
  STDMETHODIMP get_bsi      (BSI *bsi);
//  STDMETHODIMP get_speakers (AC3Speakers *spk);
//  STDMETHODIMP set_speakers (AC3Speakers  spk);    // only filter itself knows how to set speakers
//  STDMETHODIMP get_cpu_load (double *cpu_load);                                                                
  STDMETHODIMP get_stat     (int *frames, int *errors);                                                          

  // Gain control
  STDMETHODIMP get_gain     (sample_t *master, sample_t *gain);                                                 
  STDMETHODIMP set_gain     (sample_t  master);                                                                 
  STDMETHODIMP get_gains    (sample_t *slev, sample_t *clev, sample_t *lfelev);                                 
  STDMETHODIMP set_gains    (sample_t  slev, sample_t  clev, sample_t  lfelev);                                 
  STDMETHODIMP get_bsi_locks(bool *slev_lock, bool *clev_lock, bool *lfe_lock);                                 
  STDMETHODIMP set_bsi_locks(bool  slev_lock, bool  clev_lock, bool  lfe_lock);                                 
  STDMETHODIMP get_auto_gain(bool *auto_gain);
  STDMETHODIMP set_auto_gain(bool  auto_gain);
  STDMETHODIMP get_normalize(bool *normalize);                                                                  
  STDMETHODIMP set_normalize(bool  normalize);  
  STDMETHODIMP get_levels   (sample_t *source, sample_t *max_source, sample_t *speaker, sample_t *max_speaker); 

  // DRC
  STDMETHODIMP get_dynrng   (bool *dynrng, sample_t *dynrng_level, sample_t *dynrng_power);                     
  STDMETHODIMP set_dynrng   (bool  dynrng, sample_t  dynrng_power);                                             

  // Matrix params
  STDMETHODIMP get_matrix   (mixer_matrix_t *matrix);                                                           
  STDMETHODIMP set_matrix   (mixer_matrix_t *matrix);                                                           
  STDMETHODIMP get_auto_matrix(bool *auto_matrix);                                                              
  STDMETHODIMP set_auto_matrix(bool  auto_matrix);                                                              
  STDMETHODIMP get_normalize_matrix(bool *normalize_matrix);
  STDMETHODIMP set_normalize_matrix(bool  normalize_matrix);
  STDMETHODIMP get_expand_stereo(bool *expand_stereo);
  STDMETHODIMP set_expand_stereo(bool  expand_stereo);
  STDMETHODIMP get_voice_control(bool *voice_control);
  STDMETHODIMP set_voice_control(bool  voice_control);
  STDMETHODIMP get_bass_redir(bool *bass_redir);
  STDMETHODIMP set_bass_redir(bool  bass_redir);

  // Delay
  STDMETHODIMP get_delay_on (bool *on);
  STDMETHODIMP set_delay_on (bool  on);
  STDMETHODIMP get_delay    (int *delay);
  STDMETHODIMP set_delay    (int *delay);

  // Equalizer
  STDMETHODIMP get_eq_on    (bool *on);
  STDMETHODIMP set_eq_on    (bool  on);
  STDMETHODIMP get_eq9      (sample_t *func);
  STDMETHODIMP set_eq9      (sample_t *func);
  STDMETHODIMP get_eq9_levels(sample_t *func);

  // load/save parameters from registry
  STDMETHODIMP load_params(const char *preset = 0, bool file = false);
  STDMETHODIMP save_params(const char *preset = 0, bool file = false);
  STDMETHODIMP load_matrix(const char *preset = 0, bool file = false);
  STDMETHODIMP save_matrix(const char *preset = 0, bool file = false);
  STDMETHODIMP load_delay (const char *preset = 0, bool file = false);
  STDMETHODIMP save_delay (const char *preset = 0, bool file = false);
  STDMETHODIMP load_eq9   (const char *preset = 0, bool file = false);
  STDMETHODIMP save_eq9   (const char *preset = 0, bool file = false);
};


#endif