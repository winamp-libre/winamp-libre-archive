#include "winamp.h"
#include "vac3dec\ac3file.h"
#include "ac3thread.h"
#include "sink.h"
#include "dlg_conf.h"
#include "dlg_info.h"
#include "resource.h"

///////////////////////////////////////////////////////////////////////////////
//
//  Winamp In module and support functions
//
///////////////////////////////////////////////////////////////////////////////

void config(HWND parent);
void about(HWND parent);

void init();
void quit();

int  isourfile(char *fn);

int  play(char *filename);
void pause();
void unpause();
int  ispaused();
void stop();

int  getlength();
int  getoutputtime();
void setoutputtime(int seek_pos);

void setvolume(int volume);
void setpan(int pan);

int  infodlg(char *fn, HWND hwnd);
void getfileinfo(char *filename, char *title, int *length_in_ms);
void eq_set(int on, char data[10], int preamp);

In_Module mod = 
{
  0x100,
  "Valex's AC3 decoder for Winamp v0.60b",
  0,      // hMainWindow
  0,      // hDllInstance
  "AC3\0AC3 Audio File (*.AC3)\0",
  1,      // is_seekable
  1,      // uses output
  config,
  about,
  init,
  quit,
  getfileinfo,
  infodlg,
  isourfile,
  play,
  pause,
  unpause,
  ispaused,
  stop,

  getlength,
  getoutputtime,
  setoutputtime,
    
  setvolume,
  setpan,
    
  0,0,0,0,0,0,0,0,0, // vis stuff
    
    
  0,0, // dsp
    
  eq_set,
    
  NULL,           // setinfo
    
  0 // out_mod
};



DecoderThread *decoder;
HINSTANCE      hinstance;


void config(HWND parent)
{
  TabDlg dlg(hinstance, MAKEINTRESOURCE(IDD_TABDLG), parent); 
  CWinampAC3_conf *sheet;
  sheet = CWinampAC3_conf::create_main(hinstance, decoder);
  dlg.add_page(0, sheet, "Main");
  sheet = CWinampAC3_conf::create_mixer(hinstance, decoder);
  dlg.add_page(1, sheet, "Mixer");
  sheet = CWinampAC3_conf::create_eq(hinstance, decoder);
  dlg.add_page(2, sheet, "Equalizer");
  sheet = CWinampAC3_conf::create_about(hinstance, decoder);
  dlg.add_page(3, sheet, "About");
  dlg.exec("WinampAC3 configuration");
}

void about(HWND parent)
{
  TabDlg dlg(hinstance, MAKEINTRESOURCE(IDD_TABDLG), parent); 
  CWinampAC3_conf *sheet;
  sheet = CWinampAC3_conf::create_about(hinstance, decoder);
  dlg.add_page(0, sheet, "About");
  dlg.exec("WinampAC3 configuration");
}

void init() 
{
//  sink    = new DSSink(mod.hMainWindow);
//  sink    = new WinampSink(&mod);
  decoder = new DecoderThread(&mod);
  decoder->load_params();
}

void quit() 
{
  decoder->save_params();
  decoder->save_eq9();
  decoder->save_delay();
  decoder->save_matrix();

  delete decoder;
}


void getfileinfo(char *filename, char *title, int *length_in_ms)
{
  if (!filename || !*filename)  // currently playing file
  {
    if (length_in_ms) *length_in_ms = decoder->get_length();
    if (title)         
    {
      const char *fn = decoder->get_filename();
      const char *p = fn + strlen(fn);
      while (*p != '\\' && p >= fn) p--;
      strcpy(title, ++p);
    }
  }
  else if (length_in_ms || title) // some other file
  {
    if (length_in_ms) *length_in_ms = 0;
    if (title)        *title = 0;

    // title
    if (title)
    {
      char *p = filename + strlen(filename);
      while (*p != '\\' && p >= filename) p--;
      strcpy(title, ++p);
    }

    // probe file
    FileDecoder probe(filename);
    if (!probe.probe()) return;

    // set info
    if (length_in_ms) 
      *length_in_ms = probe.get_length();
  }
}

int infodlg(char *filename, HWND hwndParent)
{
  InfoDlg dlg(hinstance, hwndParent, filename); 
  dlg.run();
  return 0;
}

// used for detecting URL streams.. unused here. strncmp(fn,"http://",7) to detect HTTP streams, etc
int isourfile(char *fn) 
{
  return 0; 
} 


int  play(char *filename)  { return !decoder->play(filename); }
void pause()               { decoder->pause();                }
void unpause()             { decoder->unpause();              }
int  ispaused()            { return decoder->is_paused();     }
void stop()                { decoder->stop();                 }

int  getlength()           { return decoder->get_length();    } 
int  getoutputtime()       { return decoder->get_pos() - decoder->get_lag_time(); }
void setoutputtime(int seek_pos) { decoder->seek(seek_pos);   }

void setvolume(int volume) { decoder->set_volume(volume);     }
void setpan(int pan)       { decoder->set_pan(pan);           }

void eq_set(int on, char data[10], int preamp) {}




BOOL APIENTRY DllMain(HINSTANCE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
  hinstance = hModule;
  return TRUE;
}

__declspec( dllexport ) In_Module * winampGetInModule2()
{
  return &mod;
}
