#ifndef WINAMPAC3_SINK_H
#define WINAMPAC3_SINK_H

#include <dsound.h>
#include "thread.h"
#include "mmreg.h"
#include "guids.h"
#include "winamp.h"
#include "tab.h"

class AudioSink
{
public:
  virtual bool query(AC3Speakers spk, int sample_rate) = 0;
  virtual bool open(AC3Speakers spk, int sample_rate) = 0;
  virtual void close() = 0;
  virtual void flush(int time) = 0;

  virtual void get_order(AC3Speakers *spk) = 0;

  virtual bool is_open() = 0;
  virtual bool is_paused() = 0;

  virtual int  get_output_time() = 0;
  virtual int  get_written_time() = 0;
  virtual int  get_lag_time() = 0;

  virtual void pause() = 0;
  virtual void unpause() = 0;

  virtual void set_volume(int volume) = 0;
  virtual int  get_volume() = 0;
  virtual void set_pan(int pan) = 0;
  virtual int  get_pan() = 0;

  virtual bool can_write() = 0;
  virtual bool can_write_raw(int size) = 0;
  virtual bool write(const sample_buffer_t *samples) = 0;
  virtual bool write_raw(uint8_t *buf, int size) = 0;
};

// DirectSound audio sink
class DSSink : public AudioSink
{
protected:
  IDirectSound        *ds;
//  IDirectSoundBuffer  *ds_buf_prim;
  IDirectSoundBuffer  *ds_buf;
  WAVEFORMATEXTENSIBLE wfx;

  HWND                hwnd;
  CritSec             lock;

  uint8_t            *sample_buf;
  int                 sample_buf_size;

  int                 buf_size_ms;
  int                 buf_size;
  int                 preload_ms;
  int                 preload_size;
  DWORD               cur;     // Cursor in sound buffer
  double              written_time;

  AC3Speakers         spk;
  AC3Speakers         spk_new;
  bool                playing;
  bool                paused;
  
  int                 volume;
  int                 pan;

public:
  DSSink(HWND hwnd, int buf_size_ms = 2000, int preload_ms = 500);
  ~DSSink();

  bool query(AC3Speakers spk, int sample_rate);
  bool open(AC3Speakers spk, int sample_rate);
  void close();
  void flush(int time);
  void get_order(AC3Speakers *spk);

  bool is_open();
  bool is_paused();

  int  get_output_time();
  int  get_written_time();
  int  get_lag_time();

  void pause();
  void unpause();

  void set_volume(int volume);
  int  get_volume();
  void set_pan(int pan);
  int  get_pan();

  bool can_write();
  bool can_write_raw(int size);
  bool write(const sample_buffer_t *samples);
  bool write_raw(uint8_t *buf, int size);
};

// Winamp sink
class WinampSink : public AudioSink
{
protected:
  In_Module  *in;
  Out_Module *out;
  bool paused;
  int  volume;
  int  pan;

  AC3Speakers spk;
  int sample_rate;

  uint8_t *sample_buf;
  int      sample_buf_size;

public:
  WinampSink(In_Module *_in);

  bool query(AC3Speakers spk, int sample_rate);
  bool open(AC3Speakers spk, int sample_rate);
  void close();
  void flush(int time);

  void get_order(AC3Speakers *spk);

  bool is_open()                { return out != 0; }
  bool is_paused()              { return paused; }

  int  get_output_time()        { return out? out->GetOutputTime()  : 0; }
  int  get_written_time()       { return out? out->GetWrittenTime() : 0; }
  int  get_lag_time()           { return out? out->GetWrittenTime() - out->GetOutputTime() : 0; }

  void pause()                  { if (out && !paused) paused = !out->Pause(1); }
  void unpause()                { if (out && paused)  paused = !out->Pause(0); }

  void set_volume(int _volume)  { if (_volume != -666) volume = _volume; if (out) out->SetVolume(_volume); }
  int  get_volume()             { return volume; }
  void set_pan(int _pan)        { pan = _pan; if (out) out->SetPan(_pan); }
  int  get_pan()                { return pan; }

  bool can_write();
  bool can_write_raw(int size);
  bool write(const sample_buffer_t *samples);
  bool write_raw(uint8_t *buf, int size);
};


#endif