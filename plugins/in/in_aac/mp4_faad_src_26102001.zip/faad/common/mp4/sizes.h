#ifndef QUICKTIME_SIZES_H
#define QUICKTIME_SIZES_H

#define QUICKTIME_INT16 short int
#define MAX_FILESIZE ((unsigned long)0xff << (sizeof(long) - 13))

#endif
