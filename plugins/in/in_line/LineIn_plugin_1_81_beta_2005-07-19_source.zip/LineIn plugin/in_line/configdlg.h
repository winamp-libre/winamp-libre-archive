
#ifndef CONFIGDLGH
#define CONFIGDLGH

// STL includes
#include <string>
using namespace std;

// Windows includes
#include <windows.h>

// Resource include
#include "resource.h"

void config(HWND hwndParent);

#endif // CONFIGDLGH