//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script1.rc
//
#define IDC_ADDLOCWIZARDBUT             2
#define IDD_CONFIGDLG                   101
#define IDD_PRESETDLG                   102
#define IDD_DXDEVALIASDLG               103
#define DLG_DEVSANDFMT                  106
#define DLG_START                       107
#define DLG_STOP                        108
#define IDC_DEVLIST                     1001
#define IDC_PRESETLIST                  1002
#define IDC_ADDPRESETBUT                1003
#define IDC_REMOVEPRESETBUT             1004
#define IDC_PRESETNAME                  1004
#define IDC_PRESETVAL                   1005
#define IDC_DEVLISTTAB                  1006
#define IDC_WAVEDEVTEXT                 1007
#define IDC_GUID                        1008
#define IDC_DXDEVTEXT                   1009
#define IDC_ALIAS                       1009
#define IDC_DEVICEID                    1010
#define IDC_DEVICEGUID                  1011
#define IDC_HANGONSTOPCHECK             1012
#define IDC_ALWTITLE                    1013
#define IDC_ALWSTDFMTCHECK              1014
#define IDC_ALWSRATE                    1015
#define IDC_ALWNCH                      1016
#define IDC_ALWBPS                      1017
#define IDC_ALWDEVCOMBO                 1020
#define IDC_ALWMAKEPRESET               1021
#define IDC_ALWADDTOPLAYLIST            1022
#define IDC_ALWPRESETNAME               1023
#define IDC_ALWPRESETNAMESTATIC         1024
#define IDC_ALWURL                      1025
#define IDC_REPREPARECHECK              1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
