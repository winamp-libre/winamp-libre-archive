
#ifndef LINEIN_COMMON_H
#define LINEIN_COMMON_H

#include "in.h"

extern In_Module mod;
#define out mod

extern const std::wstring msgbox_program_title;

#endif //LINEIN_COMMON_H
