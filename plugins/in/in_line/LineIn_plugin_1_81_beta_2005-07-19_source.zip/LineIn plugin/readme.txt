This directory contains the source code for the LineIn plugin for Winamp, as well as a class
to ease writing to files.

The project contains numerous builds, but the most interesting are simply the normal Debug and
Release builds (and possibly the Logged builds, although those are mostly interesting when
having to debug a problem on a different computer). I'd recommend using the Debug build when
developing (WARNING: the debug build is set to automatically put the dll in the Winamp\plugins
directory, so be sure to adjust this path BEFORE you build it).

alg\
  This directory is used by both the LineIn plugin and the File Writer plugin.

alg\audio_conversions.h
  At the moment this just defines a struct that can be used as a 24bit integer (used by the
  channel remapper).

alg\gen.*
  Some useful helper functions, if you want to display an error or warning, use the functions
  defined here. Other functions include date/time handling functions, multibyte/wide string
  conversion routines (wrappers for the relevant Win32 API functions) and array size macro and
  a logical XOR (sometimes useful).

alg\msgbox.*
  A custom message box class. This basically mimics the normal Windows message boxes but lets
  you choose your own buttons (with virtually no restrictions). I've found this useful to
  provide users with buttons that say a little more than just Ok or Cancel and it is used by
  the Error and Warning functions in gen.cpp.

Expander\
  A stripped-down version of the expander project used by the LineIn plugin (contains just the
  ExpandLib part, but not the project files, test program, etc.).

file_t\
  File class which I find useful, it supports pretty much anything I've ever needed. The primary
  reason for creating it was to ease support of 64bit file sizes btw.

in_line\
  The LineIn plugin source, including MSVC6 project files. I use STLPort to compile it, but any
  other STL should also work with only slight modifications needed.

in_line\aliases.*
  The files that are responsible for resolving device aliases.

in_line\audiotools.h
  A reasonably efficient channel remapper. Not assembly optimized or anything, but about as
  efficient as I could get it without resorting to assembly (let alone MMX, SSE, etc.).

in_line\common.h
  Contains a few declarations needed throughout the plugin.

in_line\configdlg.*
  The configuration dialog, as well as a wizard for adding line:// URLs to the playlist.
  I wouldn't even look at this unless you have to (over a thousand lines of very boring code).

in_line\in.h,out.h
  Headers describing the Winamp plugin structures for input and output plugins (part of the
  Winamp SDK).

in_line\in_line.cpp
  This is the main part of the plugin, this implements the Winamp plugin interface, along with
  a host of helper functions. I'd recommend steering clear of most of this file (as there are
  numerous subtle potential problem areas in this file), except for a few functions you probably
  will want to touch:
    ProcessBuffer:
          This is the function that handles each block of audio, so this is probably the ideal
          place to handle storing the incoming audio. I'd recommend simply dumping all incoming
          data to a file that contains a fixed number of samples(!!!). If you reach the end of
          the file I'd start at the beginning again. Please note that I mentioned SAMPLES, I'd
          recommend first determining how many samples you want to store and then multiply it
          with BLOCKALIGN to get the number of bytes to store. You can choose to either store
          the original samples or the remapped samples (these will normally be the same, unless
          the channel remapper is used), storing remapped samples is probably easiest, so you'd
          need BLOCKALIGN_OUT. You can also choose to store them before running them through
          the DSP plugin or not, I'd recommend storing them after running them through the DSP
          plugin (that way the DSP plugin sees a continuous stream of data and the user will
          get the exact same sound as the first time when he goes back a bit).
    init: If you need to initialize anything when the plugin is loaded (probably not), this is
          where it should be done.
    quit: This is called when Winamp is quitting and can be used to uninitialize anything you
          initialized in init.
    play: You'll most likely want to retrieve some settings at the start of this function (and
          open a file for output?).
    stop: This is where you'll want to delete the file you wrote for example.
    getlength/getoutputtime/setoutputtime:
          One way of creating an interface for this would be to use these methods to let the
          user "seek" back and forward. I haven't tried this though, so I don't know how Winamp
          would react to this. It would also make it impossible for the user to see how long
          the plugin has been playing, so you may want to simply create a separate UI for it.
          (if you do, have a good look at the Winamp 5 SDK, I believe it contains an API for
          creating skinnable windows and other nice additions)

in_line\preset.*
  Takes care of loading/storing presets.

in_line\tool.*
  Title expanding, parameter parsing and some other miscellaneous things. One thing that might
  be useful if you're going to use a textbox or something somewhere is the Set/GetWindowText
  wrapper which works with std::string instead of char*. The stopme function can also be useful.

in_line\wa_ipc.h
  Part of the Winamp SDK, contains some defines for messages that can be sent to Winamp.
