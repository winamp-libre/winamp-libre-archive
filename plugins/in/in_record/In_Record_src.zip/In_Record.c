/*
** Example Winamp input plug-in
** Copyright (c) 1998, Justin Frankel/Nullsoft Inc.
*/

#include <windows.h>
#include <windowsx.h>
#include <mmreg.h>
#include <msacm.h>
#include "resource.h"

#include "in2.h"

// post this to the main window at end of file (after playback as stopped)
#define WM_WA_MPEG_EOF WM_USER+2


extern In_Module mod;

int paused;
int playing;
int Length;

LPCTSTR lpAppName = "Recording Input plug-in";
LPCTSTR lpFileName = "winamp.ini";

int killDecodeThread=0;
DWORD ThreadId;
int _chkstk;

HANDLE thread_handle = INVALID_HANDLE_VALUE;

int nChannels = 2;
int nBitRate = 44100;
int nBitsPerSamp = 16;
BOOL bSendToOutput = TRUE;

DWORD WINAPI __stdcall PlayThread(void *b);

long IndexToSampleRate(long SampleIndex)
{
	switch(SampleIndex)
	{
	case 0:
		return 8000;
	case 1:
		return 11025;
	case 2:
		return 12000;
	case 3:
		return 16000;
	case 4:
		return 22050;
	case 5:
		return 24000;
	case 6:
		return 32000;
	case 8:
		return 48000;
	case 7:
	default:
		return 44100;
	}
}

long SampleRateToIndex(long SampleRate)
{
	switch(SampleRate)
	{
	case 8000:
		return 0;
	case 11025:
		return 1;
	case 12000:
		return 2;
	case 16000:
		return 3;
	case 22050:
		return 4;
	case 24000:
		return 5;
	case 32000:
		return 6;
	case 48000:
		return 8;
	case 44100:
	default:
		return 7;
	}
}

BOOL WritePrivateProfileInt(LPCTSTR lpAppName, LPCTSTR lpKeyName, int nInteger, LPCTSTR lpFileName)
{
    TCHAR lpString[1024];

    wsprintf(lpString, "%d", nInteger);
    return WritePrivateProfileString(lpAppName, lpKeyName, lpString, lpFileName);
}

void SaveConfig(HWND hwnd)
{
	nChannels = ComboBox_GetCurSel(GetDlgItem(hwnd, ID_CHANNELS)) + 1;
	nBitRate = IndexToSampleRate(ComboBox_GetCurSel(GetDlgItem(hwnd, ID_SAMPLERATE)));
	nBitsPerSamp = (ComboBox_GetCurSel(GetDlgItem(hwnd, ID_BITSPERSAMP)) == 1)? 16 : 8;
	bSendToOutput = (Button_GetCheck(GetDlgItem(hwnd, IDC_SENDOUT)) == BST_CHECKED)?TRUE:FALSE;

	WritePrivateProfileInt(lpAppName, "nChannels",      nChannels,      lpFileName);
    WritePrivateProfileInt(lpAppName, "nBitRate", nBitRate, lpFileName);
    WritePrivateProfileInt(lpAppName, "nBitsPerSamp", nBitsPerSamp, lpFileName);
    WritePrivateProfileInt(lpAppName, "bSendToOutput", bSendToOutput, lpFileName);
}

///////////////////////////////////////////////////////////////////////////////
void Config_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
   switch (id)
   {
   case IDOK:
	  SaveConfig(hwnd);
      EndDialog(hwnd, 0); 
      break;
   case IDCANCEL: 
      EndDialog(hwnd, 0); 
      break;
   default:
	   break;
   }
}

BOOL Config_OnInitDlg(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	ComboBox_ResetContent(GetDlgItem(hwnd, ID_CHANNELS));
	ComboBox_AddString(GetDlgItem(hwnd, ID_CHANNELS), "Mono");
	ComboBox_AddString(GetDlgItem(hwnd, ID_CHANNELS), "Stereo");
	ComboBox_SetCurSel(GetDlgItem(hwnd, ID_CHANNELS), nChannels - 1);

	ComboBox_ResetContent(GetDlgItem(hwnd, ID_BITSPERSAMP));
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITSPERSAMP), "8");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITSPERSAMP), "16");
	ComboBox_SetCurSel(GetDlgItem(hwnd, ID_BITSPERSAMP), (nBitsPerSamp == 16)?1:0);

	ComboBox_ResetContent(GetDlgItem(hwnd, ID_SAMPLERATE));
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "8 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "11.025 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "12 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "16 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "22.05 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "24 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "32 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "44.1 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "48 kHz");
	ComboBox_SetCurSel(GetDlgItem(hwnd, ID_SAMPLERATE), SampleRateToIndex(nBitRate));

	Button_SetCheck(GetDlgItem(hwnd, IDC_SENDOUT), bSendToOutput? BST_CHECKED : BST_UNCHECKED);
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
BOOL WINAPI Config_DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

   switch (uMsg)
   {
      HANDLE_MSG(hwnd, WM_COMMAND, Config_OnCommand);
      HANDLE_MSG(hwnd, WM_INITDIALOG, Config_OnInitDlg);
   }
   return(FALSE);

}

void config(HWND hwndParent)
{
	if(playing == 0)
	{
		DialogBox(mod.hDllInstance, MAKEINTRESOURCE(IDD_CONFIG),  NULL, Config_DlgProc);
	}
	else
	{
		MessageBox(hwndParent,"Can't change config while recording!","Record Plug-in", MB_OK);
	}
}

void about(HWND hwndParent)
{
	MessageBox(hwndParent,"Record Plug-in, by John Adcock","About Record Plug-in", MB_OK);
}

void init()
{
    nChannels = GetPrivateProfileInt(lpAppName, "nChannels", 2,      lpFileName);
    nBitRate = GetPrivateProfileInt(lpAppName, "nBitRate", 44100, lpFileName);
    nBitsPerSamp = GetPrivateProfileInt(lpAppName, "nBitsPerSamp", 16, lpFileName);
	bSendToOutput = GetPrivateProfileInt(lpAppName, "bSendToOutput", TRUE, lpFileName);
	playing = 0;
}

void quit()
{
}

int isourfile(char *fn) 
{ 
	char buf[7];
	lstrcpyn(buf, fn, 7);
	return lstrcmp(buf,"rec://")?0:1;
}

int play(char *fn)
{ 
	int maxlatency;

	paused=0;
	playing = 0;

	// read length in mins
	Length = atoi(fn + 6);
	if(Length <= 0)
	{
		Length = -1000;
	}
	else
	{
		Length *= 60 * 1000;
	}

	maxlatency = mod.outMod->Open(nBitRate ,nChannels, nBitsPerSamp, -1, -1);
	if (maxlatency < 0)
	{
		return 1;
	}

	playing = 1;
	mod.SetInfo(nBitRate * nChannels * nBitsPerSamp / 1000 ,nBitRate / 1000, nChannels,1);

	mod.SAVSAInit(maxlatency,nBitRate);
	mod.VSASetInfo(nBitRate,nChannels);
	mod.outMod->SetVolume(-666);		

	killDecodeThread=0;
	thread_handle = (HANDLE) CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) PlayThread,(void *) &killDecodeThread,0,&ThreadId);
	
	return 0; 
}

void pause()
{ 
	paused=1; 
	mod.outMod->Pause(1);
}

void unpause()
{
	paused=0; 
	mod.outMod->Pause(0);
}

int ispaused()
{
	return paused;
}

void stop()
{ 
	playing = 0;
	if (thread_handle != INVALID_HANDLE_VALUE)
	{
		PostThreadMessage(ThreadId, WM_QUIT, 0,0);
		if (WaitForSingleObject(thread_handle,INFINITE) == WAIT_TIMEOUT)
		{
			MessageBox(mod.hMainWindow,"error asking thread to die!\n","error killing decode thread",0);
			TerminateThread(thread_handle,0);
		}
		CloseHandle(thread_handle);
		thread_handle = INVALID_HANDLE_VALUE;
	}

	mod.outMod->Close();
	mod.SAVSADeInit();
}

int getlength()
{
	return Length;
}

int getoutputtime()
{
	return mod.outMod->GetOutputTime();
}

void setoutputtime(int time_in_ms)
{
}

void setvolume(int volume)
{
	mod.outMod->SetVolume(volume);
}

void setpan(int pan)
{
	mod.outMod->SetPan(pan);
}

int infoDlg(char *fn, HWND hwnd)
{
	return 0;
}

void getfileinfo(char *filename, char *title, int *length_in_ms)
{
	wsprintf(title,"Recording");
	if (length_in_ms)
	{
		*length_in_ms = Length;
	}
}

void eq_set(int on, char data[10], int preamp) 
{ 
}


In_Module mod = 
{
	IN_VER,
	"Recording Plug-in v0.0 "
#ifdef __alpha
	"(AXP)"
#else
	"(x86)"
#endif
	,
	0,	// hMainWindow
	0,  // hDllInstance
	"\0"
	,
	0,	// is_seekable
	1, // uses output
	config,
	about,
	init,
	quit,
	getfileinfo,
	infoDlg,
	isourfile,
	play,
	pause,
	unpause,
	ispaused,
	stop,
	
	getlength,
	getoutputtime,
	setoutputtime,

	setvolume,
	setpan,

	0,0,0,0,0,0,0,0,0, // vis stuff


	0,0, // dsp

	eq_set,

	NULL,		// setinfo

	0 // out_mod

};

__declspec( dllexport ) In_Module * winampGetInModule2()
{
	return &mod;
}

void ErrorHandler(LPCSTR Function, MMRESULT ErrorCode)
{
	char Buff[2056];
	wsprintf(Buff, "Function %s failed with code %d", Function, ErrorCode);
	MessageBox(mod.hMainWindow, Buff, "Recording Failure", MB_OK);
}

int PrepareHeader(HWAVEIN hWin, WAVEHDR* pWaveHdr, BYTE* pSampleBuffer, DWORD Flags)
{
	MMRESULT mmr;

	ZeroMemory(pWaveHdr, sizeof(WAVEHDR));
	pWaveHdr->lpData = pSampleBuffer;
	pWaveHdr->dwBufferLength = 576 * nBitsPerSamp * nChannels / 8;
	pWaveHdr->dwFlags = Flags;

	if((mmr = waveInPrepareHeader(hWin, pWaveHdr, sizeof(WAVEHDR))) != MMSYSERR_NOERROR)
	{
		ErrorHandler("waveInPrepareHeader", mmr);
		return -1;
	}
	return 0;
}


DWORD WINAPI PlayThread(void *b)
{
	WAVEHDR Whdr[4];
	MMRESULT mmr;
	HWAVEIN hWin;
	int bufindex = 0;
	int Counter = 0;
	int BytesCanWrite;
	int l;
	WAVEFORMATEX Wfx;
    MSG msg;

	short sample_buffer1[576*2*2];
	short sample_buffer2[576*2*2];
	short sample_buffer3[576*2*2];
	short sample_buffer4[576*2*2];


	// Open WaveIn
	Wfx.wFormatTag = WAVE_FORMAT_PCM;
	Wfx.nChannels = nChannels;
	Wfx.nSamplesPerSec = nBitRate;
	Wfx.wBitsPerSample = nBitsPerSamp;
	Wfx.nAvgBytesPerSec = nBitRate * nChannels * nBitsPerSamp / 8;
	Wfx.nBlockAlign = nBitsPerSamp * nChannels / 8;
	Wfx.cbSize = 0;

	if((mmr = waveInOpen(&hWin, WAVE_MAPPER, &Wfx, ThreadId, 0, CALLBACK_THREAD)) != MMSYSERR_NOERROR)
	{
		ErrorHandler("waveInOpen", mmr);
		goto error;
	}

	// set up Buffers
	ZeroMemory(sample_buffer1, sizeof(sample_buffer1));
	ZeroMemory(sample_buffer2, sizeof(sample_buffer2));
	ZeroMemory(sample_buffer3, sizeof(sample_buffer3));
	ZeroMemory(sample_buffer4, sizeof(sample_buffer4));

	if(PrepareHeader(hWin, &Whdr[0], (BYTE*) sample_buffer1, WHDR_BEGINLOOP) != 0)
	{
		goto error;
	}

	if(PrepareHeader(hWin, &Whdr[1], (BYTE*) sample_buffer2, 0) != 0)
	{
		goto error;
	}
	
	if(PrepareHeader(hWin, &Whdr[2], (BYTE*) sample_buffer3, 0) != 0)
	{
		goto error;
	}

	if(PrepareHeader(hWin, &Whdr[3], (BYTE*) sample_buffer3, 0) != 0)
	{
		goto error;
	}

	if((mmr = waveInAddBuffer(hWin, &Whdr[0], sizeof(WAVEHDR))) != MMSYSERR_NOERROR)
	{
		ErrorHandler("waveInAddBuffer", mmr);
		goto error;
	}
	if((mmr = waveInAddBuffer(hWin, &Whdr[1], sizeof(WAVEHDR))) != MMSYSERR_NOERROR)
	{
		ErrorHandler("waveInAddBuffer", mmr);
		goto error;
	}
	if((mmr = waveInAddBuffer(hWin, &Whdr[2], sizeof(WAVEHDR))) != MMSYSERR_NOERROR)
	{
		ErrorHandler("waveInAddBuffer", mmr);
		goto error;
	}
	
	bufindex = 3;
	Counter = 3;

	if((mmr = waveInStart(hWin)) != MMSYSERR_NOERROR)
	{
		ErrorHandler("waveInStart", mmr);
		goto error;
	}
 

    while (GetMessage(&msg, 0, 0, 0))
	{
		if(msg.message == WIM_DATA)
		{
			Whdr[bufindex].dwFlags = WHDR_PREPARED;
			if((mmr = waveInAddBuffer(hWin, &Whdr[(bufindex % 4)], sizeof(WAVEHDR))) != MMSYSERR_NOERROR)
			{
				ErrorHandler("waveInAddBuffer", mmr);
				goto error;
			}

			++Counter;
			bufindex = Counter % 4;

			BytesCanWrite = mod.outMod->CanWrite();

			while((DWORD)mod.outMod->CanWrite() < Whdr[bufindex].dwBytesRecorded)
			{
				Sleep(10);
			}

			{
				int t=mod.outMod->GetWrittenTime();
				if(Length > 0 && t > Length)
				{
					PostMessage(mod.hMainWindow,WM_WA_MPEG_EOF,0,0);
					goto error;
				}
				mod.SAAddPCMData(Whdr[bufindex].lpData, nChannels, nBitsPerSamp ,t);
				mod.VSAAddPCMData(Whdr[bufindex].lpData, nChannels, nBitsPerSamp,t);
			}

			// get Number Of Samples To Write
			l = mod.dsp_dosamples((short*)Whdr[bufindex].lpData, 576, nBitsPerSamp, nChannels, nBitRate);

			if(bSendToOutput == TRUE)
			{
				// Num of Bytes is Sizeof(short) * Num channels more
				mod.outMod->Write(Whdr[bufindex].lpData, l * nBitsPerSamp * nChannels / 8);
			}
		}
        DispatchMessage(&msg);
	}

error:
	mmr = waveInUnprepareHeader(hWin, &Whdr[0], sizeof(WAVEHDR));
	mmr = waveInUnprepareHeader(hWin, &Whdr[1], sizeof(WAVEHDR));
	mmr = waveInUnprepareHeader(hWin, &Whdr[2], sizeof(WAVEHDR));
	mmr = waveInUnprepareHeader(hWin, &Whdr[3], sizeof(WAVEHDR));
	mmr = waveInReset(hWin);
	mmr = waveInStop(hWin);
	mmr = waveInClose(hWin);
	playing = 0;
	return 0;
}