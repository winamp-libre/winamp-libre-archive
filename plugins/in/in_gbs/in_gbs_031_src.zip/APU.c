#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "gbz80\z80.h"

#define UINT32 unsigned int
#define INT32  int
#define UINT16 unsigned short int
#define INT16  short
#define UINT8  unsigned char
#define INT8   char

#define NCH 2
#define SAMPLERATE 44100
#define BPS 16
#define BYTES 735
#define CLOCK 4194304 * 2
#define OVERSAMPLE 95

static const UINT32 nDutyLookUpTable[]={
  0x02 * 2, 0x04  * 2, 0x08  * 2, 0x0c  * 2
};

static const UINT32 nNoiseFrequencyRatio[]={
  1048576, 524288, 370728, 262144, 220436, 185363, 155872, 131072
};

static const UINT32 nNoiseFrequencyShift[]={
  0x2, 0x4, 0x8, 0x10, 0x20, 0x40, 0x80, 0x100, 0x200, 0x400, 0x800, 0x1000, 0x2000, 0x4000, 0x8000, 0x10000
};

extern UINT32    nBufferLength;
extern UINT32    nBufferInc;
extern UINT32    nFPS;
extern UINT8     pCPU[0x10000];

//square channels
struct{
  UINT8  nRegister[5];
  INT32  nLengthCounter;
  INT32  nFrequency;
  INT32  nLinearCounterPhase;
  UINT8  nDutyCyclePhase;
  INT32  nSweepPhase;
  INT32  nEnvelopePhase;
  UINT8  nEnvelopeVolume;
  UINT32 nEnabled;
}APUSQUARE[2];

//pcm channel
struct{
  UINT8  nRegister[5];
  UINT32 nLengthCounter;
  INT32  nLinearCounterPhase;
  UINT8  nCurrentByte;
  INT32  nFrequency;
  UINT32 nEnabled;
}APUPCM;

//noise channel
struct{
  UINT8  nRegister[4];
  UINT32 nCurrentPosition;
  INT32  nLengthCounter;
  INT32  nLinearCounterPhase;
  INT32  nEnvelopePhase;
  UINT8  nEnvelopeVolume;
  INT32  nFrequency;
  UINT32 nEnabled;
}APUNOISE;


INT8 mAPUSquare0()
{
static INT32 nEnvDelay;
static INT32 nSweepDelay;
static INT8  nOutput;

  //APU is powered off
  if((pCPU[0xFF26] & 0x80) == 0) return(0);

  //length counter
  if(APUSQUARE[0].nRegister[4] & 0x40){
    if(APUSQUARE[0].nLengthCounter==0){
      APUSQUARE[0].nEnabled=0;
      return(0);
    }
    APUSQUARE[0].nLengthCounter--;
  }

  //exit if the channel is off
  if(APUSQUARE[0].nEnabled==0) return(0);

  //envelope decay unit
  if(APUSQUARE[0].nRegister[0] & 0x7){
    nEnvDelay=(APUSQUARE[0].nRegister[0] & 0x7) * nBufferLength;
    APUSQUARE[0].nEnvelopePhase-=64 / 60;
    while(APUSQUARE[0].nEnvelopePhase < 0){
      APUSQUARE[0].nEnvelopePhase += nEnvDelay;
      if((APUSQUARE[0].nRegister[0] & 0x8) && APUSQUARE[0].nEnvelopeVolume < 15) APUSQUARE[0].nEnvelopeVolume++;
      if(!(APUSQUARE[0].nRegister[0] & 0x8) && APUSQUARE[0].nEnvelopeVolume > 0) APUSQUARE[0].nEnvelopeVolume--;
    }
  }

  //sweep unit
  if(((APUSQUARE[0].nRegister[1] >> 4) & 7) && (APUSQUARE[0].nRegister[1] & 7)){
    nSweepDelay=(((APUSQUARE[0].nRegister[1] >> 4) & 7)) * nBufferLength;
    APUSQUARE[0].nSweepPhase-=128 / 60;
    while(APUSQUARE[0].nSweepPhase < 0){
      APUSQUARE[0].nSweepPhase += nSweepDelay;
      if(APUSQUARE[0].nRegister[1] & 0x8) APUSQUARE[0].nFrequency -= (APUSQUARE[0].nFrequency >> (APUSQUARE[0].nRegister[1] & 7));
      else APUSQUARE[0].nFrequency += (APUSQUARE[0].nFrequency >> (APUSQUARE[0].nRegister[1] & 7));
    }
  }

  //linear frequency counter
  APUSQUARE[0].nLinearCounterPhase -= nBufferInc;
  while(APUSQUARE[0].nLinearCounterPhase < 0){
    APUSQUARE[0].nLinearCounterPhase += APUSQUARE[0].nFrequency;
    APUSQUARE[0].nDutyCyclePhase=(APUSQUARE[0].nDutyCyclePhase + 1) & 0x01f;
  }

  nOutput=APUSQUARE[0].nEnvelopeVolume;

  //check duty cycle to see if we are up or down
  if(APUSQUARE[0].nDutyCyclePhase < (nDutyLookUpTable[APUSQUARE[0].nRegister[2] >> 6])) nOutput=-nOutput;

  return(nOutput);
}

INT8 mAPUSquare1()
{
static INT32 nEnvDelay;
static INT8  nOutput;

  //APU is powered off
  if((pCPU[0xFF26] & 0x80) == 0) return(0);

  //length counter
  if(APUSQUARE[1].nRegister[4] & 0x40){
    if(APUSQUARE[1].nLengthCounter==0){
      APUSQUARE[1].nEnabled=0;
      return(0);
    }
    APUSQUARE[1].nLengthCounter--;
  }

  //exit if the channel is off
  if(APUSQUARE[1].nEnabled==0) return(0);

  //envelope decay unit
  if(APUSQUARE[1].nRegister[0] & 0x7){
    nEnvDelay=((APUSQUARE[1].nRegister[0] & 0x7)) * nBufferLength;
    APUSQUARE[1].nEnvelopePhase-=64 / 60;
    while(APUSQUARE[1].nEnvelopePhase<0 && (APUSQUARE[1].nRegister[0] & 0x7)){
      APUSQUARE[1].nEnvelopePhase += nEnvDelay;
        if((APUSQUARE[1].nRegister[0] & 0x8) && APUSQUARE[1].nEnvelopeVolume < 15) APUSQUARE[1].nEnvelopeVolume++;
        if(!(APUSQUARE[1].nRegister[0] & 0x8) && APUSQUARE[1].nEnvelopeVolume > 0) APUSQUARE[1].nEnvelopeVolume--;
    }
  }

  //linear frequency counter
  APUSQUARE[1].nLinearCounterPhase -= nBufferInc;
  while(APUSQUARE[1].nLinearCounterPhase < 0){
    APUSQUARE[1].nLinearCounterPhase += (APUSQUARE[1].nFrequency);
    APUSQUARE[1].nDutyCyclePhase=(APUSQUARE[1].nDutyCyclePhase + 1) & 0x01f;
  }

  nOutput=APUSQUARE[1].nEnvelopeVolume;

  //check duty cycle to see if we are up or down
  if(APUSQUARE[1].nDutyCyclePhase < (nDutyLookUpTable[APUSQUARE[1].nRegister[2] >> 6])) nOutput=-nOutput;

  return(nOutput);
}

INT8 mAPUPCM()
{
static INT8  nOutput;
UINT8 nNibble;

  //APU is powered off
  if((pCPU[0xFF26] & 0x80) == 0) return(0);

  //length counter
  if(APUPCM.nRegister[4] & 0x40){
    if(APUPCM.nLengthCounter==0){
      APUPCM.nEnabled=0;
      return(0);
    }
    APUPCM.nLengthCounter--;
  }

  //exit if the channel is off
  if(!APUPCM.nEnabled) return(0);

  //linear frequency counter
  APUPCM.nLinearCounterPhase -= nBufferInc;
  while(APUPCM.nLinearCounterPhase < 0){
    APUPCM.nLinearCounterPhase += (APUPCM.nFrequency);
//    APUPCM.nCurrentByte = (APUPCM.nCurrentByte + 1) & 0x3f;
    APUPCM.nCurrentByte = (APUPCM.nCurrentByte + 1) & 0x1f;
//    APUPCM.nCurrentByte = (APUPCM.nCurrentByte + 1) & 0x1f;
  }
  nNibble=pCPU[0xFF30 + (APUPCM.nCurrentByte / 2)];
  if(APUPCM.nCurrentByte % 2) nNibble = (nNibble >> 0) & 0xf;
  else nNibble = (nNibble >> 4) & 0xf;

  if(((APUPCM.nRegister[2] >> 5) & 0x3)==0) nOutput = 0;
  if(((APUPCM.nRegister[2] >> 5) & 0x3)==1) nOutput = nNibble;
  if(((APUPCM.nRegister[2] >> 5) & 0x3)==2) nOutput = nNibble / 2;
  if(((APUPCM.nRegister[2] >> 5) & 0x3)==3) nOutput = nNibble / 4;

  return(nOutput);
}

//HANDLES THE NOISE CHANNEL
INT8 mAPUNoise()
{
static INT32  nFrequency, nEnvDelay;
static UINT32 I;
static INT8   nOutput;

  //APU is powered off
  if((pCPU[0xFF26] & 0x80) == 0) return(0);

  //length counter
  if(APUNOISE.nRegister[3] & 0x40){
    if(APUNOISE.nLengthCounter==0){
      APUNOISE.nEnabled=0;
      return(0);
    }
    APUNOISE.nLengthCounter--;
  }

  //exit if the channel is off
  if(APUNOISE.nEnabled==0) return(0);

  //envelope decay unit
  if(APUNOISE.nRegister[0] & 0x7){
    nEnvDelay=(APUNOISE.nRegister[0] & 0x7) * nBufferLength;
    APUNOISE.nEnvelopePhase-=64 / 60;
    while(APUNOISE.nEnvelopePhase < 0){
      APUNOISE.nEnvelopePhase += nEnvDelay;
      if((APUNOISE.nRegister[0] & 0x8) && APUNOISE.nEnvelopeVolume < 15) APUNOISE.nEnvelopeVolume++;
      if(!(APUNOISE.nRegister[0] & 0x8) && APUNOISE.nEnvelopeVolume > 0) APUNOISE.nEnvelopeVolume--;
    }
  }

  //linear nFrequency counter
  APUNOISE.nLinearCounterPhase -= nBufferInc;
  while(APUNOISE.nLinearCounterPhase < 0){
    APUNOISE.nLinearCounterPhase += APUNOISE.nFrequency;
    APUNOISE.nCurrentPosition=APUNOISE.nCurrentPosition << 1;
    //7 bit noise
    if(APUNOISE.nRegister[2] & 0x8){
      I=((APUNOISE.nCurrentPosition >> 6) & 1) ^ ((APUNOISE.nCurrentPosition >> 7) & 1);
      APUNOISE.nCurrentPosition=APUNOISE.nCurrentPosition & 0xfffe;
      APUNOISE.nCurrentPosition=APUNOISE.nCurrentPosition | I;
      I=(APUNOISE.nCurrentPosition >> 7) & 0x1;
    }
    //15 bit noise
    else{
      I=((APUNOISE.nCurrentPosition >> 14) & 1) ^ ((APUNOISE.nCurrentPosition >> 15) & 1);
      APUNOISE.nCurrentPosition=APUNOISE.nCurrentPosition & 0xfffe;
      APUNOISE.nCurrentPosition=APUNOISE.nCurrentPosition | I;
      I=(APUNOISE.nCurrentPosition >> 15) & 0x1;
    }
  }

  nOutput=APUNOISE.nEnvelopeVolume;
  if(!(I)) nOutput=-nOutput;

  return(nOutput);
}

void gbAPUWrite(UINT16 nAddress, UINT8 nData)
{
#ifdef DEBUG
  gbLog("APU Write $%02x at $%04x\n", nData, nAddress);
#endif

  switch(nAddress){
    //Square Channel 0
    case 0xFF10:
      //Sweep Register
      APUSQUARE[0].nRegister[1]=nData;
      break;
    case 0xFF11:
      //Duty Cycle and Length Counter
      APUSQUARE[0].nRegister[2]=nData;
      APUSQUARE[0].nLengthCounter=(64 - (APUSQUARE[0].nRegister[2] & 0x3f)) * nBufferLength / 4;
      break;
    case 0xFF12:
      //Volume Register
      APUSQUARE[0].nRegister[0]=nData;
      APUSQUARE[0].nEnvelopeVolume=(nData >> 4) & 0xf;
      if(APUSQUARE[0].nEnvelopeVolume==0) APUSQUARE[0].nEnabled=0;
      break;
    case 0xFF13:
      //Frequency Low 8
      APUSQUARE[0].nRegister[3]=nData;
      APUSQUARE[0].nFrequency=2048 - (((APUSQUARE[0].nRegister[4] & 0x7) << 8) | APUSQUARE[0].nRegister[3]);
      break;
    case 0xFF14:
      //Frequency High 3 and Init
      APUSQUARE[0].nRegister[4]=nData;
      APUSQUARE[0].nFrequency=2048 - (((APUSQUARE[0].nRegister[4] & 0x7) << 8) | APUSQUARE[0].nRegister[3]);
      if(APUSQUARE[0].nEnabled == 0) APUSQUARE[0].nEnabled=nData & 0x80;
//      APUSQUARE[0].nEnabled=nData & 0x80;
      break;

    //Square Channel 1
    case 0xFF16:
      //Duty Cycle and Length Counter
      APUSQUARE[1].nRegister[2]=nData;
      APUSQUARE[1].nLengthCounter=(64 - (APUSQUARE[1].nRegister[2] & 0x3f)) * nBufferLength / 4;
      break;
    case 0xFF17:
      //Volume Register
      APUSQUARE[1].nRegister[0]=nData;
      APUSQUARE[1].nEnvelopeVolume=(nData >> 4) & 0xf;
      if(APUSQUARE[1].nEnvelopeVolume==0) APUSQUARE[1].nEnabled=0;
      break;
    case 0xFF18:
      //Frequency Low 8
      APUSQUARE[1].nRegister[3]=nData;
      APUSQUARE[1].nFrequency=2048 - (((APUSQUARE[1].nRegister[4] & 0x7) << 8) | APUSQUARE[1].nRegister[3]);
      break;
    case 0xFF19:
      //Frequency High 3 and Init
      APUSQUARE[1].nRegister[4]=nData;
      APUSQUARE[1].nFrequency=2048 - (((APUSQUARE[1].nRegister[4] & 0x7) << 8) | APUSQUARE[1].nRegister[3]);
      if(APUSQUARE[1].nEnabled == 0) APUSQUARE[1].nEnabled=nData & 0x80;
//      APUSQUARE[1].nEnabled=nData & 0x80;
      break;

    //PCM Channel
    case 0xFF1A:
      //Master ON/OFF
      APUPCM.nRegister[0]=nData;
      APUPCM.nEnabled=nData & 0x80;
      break;
    case 0xFF1B:
      //Length Counter
      APUPCM.nRegister[1]=nData;
      APUPCM.nLengthCounter=(256 - APUPCM.nRegister[1]) * nBufferLength / 4;
      break;
    case 0xFF1C:
      //Volume Level
      APUPCM.nRegister[2]=nData;
      break;
    case 0xFF1D:
      //Frequency Low 8
      APUPCM.nRegister[3]=nData;
      APUPCM.nFrequency=2048 - (((APUPCM.nRegister[4] & 0x7) << 8) | APUPCM.nRegister[3]);
      APUPCM.nFrequency *= 2;
      break;
    case 0xFF1E:
      //Frequency High 3 and Init
      APUPCM.nRegister[4]=nData;
      APUPCM.nFrequency=2048 - (((APUPCM.nRegister[4] & 0x7) << 8) | APUPCM.nRegister[3]);
      APUPCM.nFrequency *= 2;
      if(nData & 0x80) APUPCM.nCurrentByte=0;
      break;

    //Noise Channel
    case 0xFF20:
      APUNOISE.nRegister[1]=nData;
      APUNOISE.nLengthCounter=(64 - (nData & 0x3f)) * nBufferLength / 4;
      break;
    case 0xFF21:
      //Volume Register
      APUNOISE.nRegister[0]=nData;
      APUNOISE.nEnvelopeVolume=(nData >> 4) & 0xf;
      if(APUNOISE.nEnvelopeVolume==0) APUNOISE.nEnvelopeVolume=0;
      break;
    case 0xFF22:
      APUNOISE.nRegister[2]=nData;
      APUNOISE.nFrequency=nNoiseFrequencyRatio[nData & 0x7];
      APUNOISE.nFrequency=APUNOISE.nFrequency / nNoiseFrequencyShift[(nData >> 4) & 0xf];
      APUNOISE.nFrequency=4194304 / APUNOISE.nFrequency;
      break;
    case 0xFF23:
      APUNOISE.nRegister[3]=nData;
      if(APUNOISE.nEnabled == 0){
        APUNOISE.nEnabled=nData & 0x80;
        APUNOISE.nCurrentPosition=0xff;
      }
      break;

  }
  pCPU[nAddress]=nData;
}

UINT8 gbAPURead(UINT16 nAddress)
{
UINT8 nValue;

#ifdef DEBUG
  gbLog("APU READ: %04x\n", nAddress);
#endif
  switch(nAddress){
    case 0xFF26:
      nValue=pCPU[0xFF26] & 0x80;
      if(APUSQUARE[0].nEnabled) nValue |= 0x01;
      if(APUSQUARE[1].nEnabled) nValue |= 0x02;
      if(APUPCM.nEnabled) nValue |= 0x04;
      if(APUNOISE.nEnabled) nValue |= 0x08;
      return(nValue);
    default:
      return(pCPU[nAddress]);
  }
}

void gbAPUReset()
{
  ZeroMemory(&APUSQUARE[0], sizeof(APUSQUARE[0]));
  ZeroMemory(&APUSQUARE[1], sizeof(APUSQUARE[1]));
  ZeroMemory(&APUPCM, sizeof(APUPCM));
  ZeroMemory(&APUNOISE, sizeof(APUNOISE));
  gbAPUWrite(0xff10,0x80);
  gbAPUWrite(0xff11,0xbf);
  gbAPUWrite(0xff12,0xf3);
  gbAPUWrite(0xff13,0xff);
  gbAPUWrite(0xff14,0xbf);
  gbAPUWrite(0xff15,0xff);
  gbAPUWrite(0xff16,0x3f);
  gbAPUWrite(0xff17,0x0);
  gbAPUWrite(0xff18,0xff);
  gbAPUWrite(0xff19,0xbf);
  gbAPUWrite(0xff1a,0x7f);
  gbAPUWrite(0xff1b,0xff);
  gbAPUWrite(0xff1c,0x9f);
  gbAPUWrite(0xff1d,0xff);
  gbAPUWrite(0xff1e,0xbf);
  gbAPUWrite(0xff1f,0xff);
  gbAPUWrite(0xff20,0xff);
  gbAPUWrite(0xff21,0x0);
  gbAPUWrite(0xff22,0x0);
  gbAPUWrite(0xff23,0xbf);
  gbAPUWrite(0xff24,0x77);
  gbAPUWrite(0xff25,0xf3);
  gbAPUWrite(0xff26,0xf1);

  gbAPUWrite(0xff30,0xac);
  gbAPUWrite(0xff31,0xdd);
  gbAPUWrite(0xff32,0xda);
  gbAPUWrite(0xff33,0x48);
  gbAPUWrite(0xff34,0x36);
  gbAPUWrite(0xff35,0x02);
  gbAPUWrite(0xff36,0xcf);
  gbAPUWrite(0xff37,0x16);
  gbAPUWrite(0xff38,0x2c);
  gbAPUWrite(0xff39,0x04);
  gbAPUWrite(0xff3a,0xe5);
  gbAPUWrite(0xff3b,0x2c);
  gbAPUWrite(0xff3c,0xac);
  gbAPUWrite(0xff3d,0xdd);
  gbAPUWrite(0xff3e,0xda);
  gbAPUWrite(0xff3f,0x48);
}