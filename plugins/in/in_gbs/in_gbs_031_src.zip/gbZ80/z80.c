#include <stdio.h>
#include "z80.h"

static UINT8 nOPCycles[256] =
{
  4,10, 7, 6, 4, 4, 7, 4, 4,11, 7, 6, 4, 4, 7, 4,
  8,10, 7, 6, 4, 4, 7, 4,12,11, 7, 6, 4, 4, 7, 4,
  7,10,16, 6, 4, 4, 7, 4, 7,11,16, 6, 4, 4, 7, 4,
  7,10,13, 6,11,11,10, 4, 7,11,13, 6, 4, 4, 7, 4,
  4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
  4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
  4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
  7, 7, 7, 7, 7, 7, 4, 7, 4, 4, 4, 4, 4, 4, 7, 4,
  4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
  4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
  4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
  4, 4, 4, 4, 4, 4, 7, 4, 4, 4, 4, 4, 4, 4, 7, 4,
  5,10,10,10,10,11, 7,11, 5,10,10, 0,10,17, 7,11,
  5,10,10,11,10,11, 7,11, 5, 4,10,11,10, 0, 7,11,
  5,10,10,19,10,11, 7,11, 5, 4,10, 4,10, 0, 7,11,
  5,10,10, 4,10,11, 7,11, 5, 6,10, 4,10, 0, 7,11 
};

static UINT8 nOPCyclesCB[256] =
{
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,12, 8, 8, 8, 8, 8, 8, 8,12, 8,
  8, 8, 8, 8, 8, 8,12, 8, 8, 8, 8, 8, 8, 8,12, 8,
  8, 8, 8, 8, 8, 8,12, 8, 8, 8, 8, 8, 8, 8,12, 8,
  8, 8, 8, 8, 8, 8,12, 8, 8, 8, 8, 8, 8, 8,12, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8,
  8, 8, 8, 8, 8, 8,15, 8, 8, 8, 8, 8, 8, 8,15, 8 
};

void gbLog(char *string, ...);
UINT16 gbReadWord(UINT16 nAddress);
void gbWriteWord(UINT16 nAddress, UINT16 nData);
UINT8 gbReadByte(UINT16 nAddress);
void gbWriteByte(UINT16 nAddress, UINT8 nData);

struct Z80CPU{
  union
  {
    struct { UINT8   F, A, C, B, E, D, L, H;} b;
    struct { UINT16  AF, BC, DE, HL;} w;
  };
  UINT16 SP, PC, RST;
} Z80CPU;

//Flags
#define FLAG_Z 0x80
#define FLAG_N 0x40
#define FLAG_H 0x20
#define FLAG_C 0x10

//Registers
#define AF  Z80CPU.w.AF
#define BC  Z80CPU.w.BC
#define DE  Z80CPU.w.DE
#define HL  Z80CPU.w.HL

#define A   Z80CPU.b.A
#define F   Z80CPU.b.F
#define B   Z80CPU.b.B
#define C   Z80CPU.b.C
#define D   Z80CPU.b.D
#define E   Z80CPU.b.E
#define H   Z80CPU.b.H
#define L   Z80CPU.b.L

#define SP  Z80CPU.SP
#define PC  Z80CPU.PC
#define RST Z80CPU.RST

//Bit Manipulations
#define SETBIT(R, S)    R |= S
#define CLEARBIT(R, S)  R &= ~S
#define TOGGLEBIT(R, S) R ^= S

//Memory Operations
#define RM8(J)                gbReadByte(J)
#define RM16(J)               gbReadWord(J)
#define WM8(J, K)             gbWriteByte(J, K)
#define WM16(J, K)            gbWriteWord(J, K)
#define PUSH(R)               {SP-=2; WM16(SP, R);}
#define POP(R)                {R=RM16(SP); SP+=2;}

//Math Operations
#define INC8(V)               {                                                                     \
                                V++;                                                                \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                if((V & 0xf) == 0) SETBIT(F, FLAG_H);                               \
                                else CLEARBIT(F, FLAG_H);                                           \
                              }
#define DEC8(V)               {                                                                     \
                                V--;                                                                \
                                SETBIT(F, FLAG_N);                                                  \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                if((V & 0xf) == 0xf) CLEARBIT(F, FLAG_H);                           \
                                else SETBIT(F, FLAG_H);                                             \
                              }
#define INC16(V)              {                                                                     \
                                V++;                                                                \
                              }
#define DEC16(V)              {                                                                     \
                                V--;                                                                \
                              }
#define INCHL                 {                                                                     \
                                UINT8 V;                                                            \
                                V=RM8(HL);                                                          \
                                V++;                                                                \
                                WM8(HL, V);                                                         \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                if((V & 0xf) == 0) SETBIT(F, FLAG_H);                               \
                                else CLEARBIT(F, FLAG_H);                                           \
                              }
#define DECHL                 {                                                                     \
                                UINT8 V;                                                            \
                                V=RM8(HL);                                                          \
                                V--;                                                                \
                                WM8(HL, V);                                                         \
                                SETBIT(F, FLAG_N);                                                  \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                if((V & 0xf) == 0xf) CLEARBIT(F, FLAG_H);                           \
                                else SETBIT(F, FLAG_H);                                             \
                              }
#define ADD(V)                {                                                                     \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(((UINT16)A + (UINT16)V) & 0x100) SETBIT(F, FLAG_C);              \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(((A & 0xf) + (V & 0xf)) & 0x10) SETBIT(F, FLAG_H);               \
                                else CLEARBIT(F, FLAG_H);                                           \
                                A=A+V;                                                              \
                                if(A==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define ADDHL(V)              {                                                                     \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(((UINT32)HL + (UINT32)V) & 0x10000) SETBIT(F, FLAG_C);           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(((HL & 0xfff) + (V & 0xfff)) & 0x1000) SETBIT(F, FLAG_H);        \
                                else CLEARBIT(F, FLAG_H);                                           \
                                HL=HL+V;                                                            \
                              }
#define ADDSP(V)              {                                                                     \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_Z);                                                \
                                if(((UINT32)(SP + V)) & 0x10000) SETBIT(F, FLAG_C);                 \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(((SP & 0xfff) + (V & 0xfff)) & 0x1000) SETBIT(F, FLAG_H);        \
                                else CLEARBIT(F, FLAG_H);                                           \
                                SP=SP+V;                                                            \
                              }
#define ADC(V)                {                                                                     \
                                UINT8 CF=((F & FLAG_C) ? 1 : 0);                                    \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(((UINT16)A + (UINT16)V + CF) & 0x100) SETBIT(F, FLAG_C);         \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(((A & 0xf) + (V & 0xf) + CF) & 0x10) SETBIT(F, FLAG_H);          \
                                else CLEARBIT(F, FLAG_H);                                           \
                                A=A+V+CF;                                                           \
                                if(A==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define SUB(V)                {                                                                     \
                                SETBIT(F, FLAG_N);                                                  \
                                if(((UINT16)A - (UINT16)V) & 0x100) SETBIT(F, FLAG_C);              \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(((A & 0xf) - (V & 0xf)) & 0x10) SETBIT(F, FLAG_H);               \
                                else CLEARBIT(F, FLAG_H);                                           \
                                A=A-V;                                                              \
                                if(A==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define SBC(V)                {                                                                     \
                                UINT8 CF=((F & FLAG_C) ? 1 : 0);                                    \
                                SETBIT(F, FLAG_N);                                                  \
                                if(((UINT16)A - (UINT16)V - CF) & 0x100) SETBIT(F, FLAG_C);         \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(((A & 0xf) - (V & 0xf) - CF) & 0x10) SETBIT(F, FLAG_H);          \
                                else CLEARBIT(F, FLAG_H);                                           \
                                A=A-V-CF;                                                           \
                                if(A==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define AND(V)                {                                                                     \
                                A&=V;                                                               \
                                SETBIT(F, FLAG_H);                                                  \
                                CLEARBIT(F, FLAG_C);                                                \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(A==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define OR(V)                 {                                                                     \
                                A|=V;                                                               \
                                CLEARBIT(F, FLAG_H);                                                \
                                CLEARBIT(F, FLAG_C);                                                \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(A==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define XOR(V)                {                                                                     \
                                A^=V;                                                               \
                                CLEARBIT(F, FLAG_H);                                                \
                                CLEARBIT(F, FLAG_C);                                                \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(A==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define CP(V)                 {                                                                     \
                                SETBIT(F, FLAG_N);                                                  \
                                if(((UINT16)A - (UINT16)V) & 0x100) SETBIT(F, FLAG_C);              \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(((A & 0xf) - (V & 0xf)) & 0x10) SETBIT(F, FLAG_H);               \
                                else CLEARBIT(F, FLAG_H);                                           \
                                if(A==V) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                if(A<V) SETBIT(F, FLAG_C);                                          \
                              }

//Bit Operations
#define BIT(V,X)              {                                                                     \
                                SETBIT(F, FLAG_H);                                                  \
                                CLEARBIT(F, FLAG_N);                                                \
                                if(V & X) CLEARBIT(F, FLAG_Z);                                      \
                                else SETBIT(F, FLAG_Z);                                             \
                              }
#define SET8(V,X)             {                                                                     \
                                SETBIT(V, X);                                                       \
                              }
#define SETHL(X)              {                                                                     \
                                UINT8 V;                                                            \
                                V=RM8(HL);                                                          \
                                SETBIT(V, X);                                                       \
                                WM8(HL, V);                                                         \
                              }
#define RES8(V,X)             {                                                                     \
                                CLEARBIT(V, X);                                                     \
                              }
#define RESHL(X)              {                                                                     \
                                UINT8 V;                                                            \
                                V=RM8(HL);                                                          \
                                CLEARBIT(V, X);                                                     \
                                WM8(HL, V);                                                         \
                              }
#define CCF                   {                                                                     \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                if(F & FLAG_C) CLEARBIT(F, FLAG_C);                                 \
                                else SETBIT(F, FLAG_C);                                             \
                              }
#define SCF                   {                                                                     \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                SETBIT(F, FLAG_C);                                                  \
                              }
#define CPL                   {                                                                     \
                                A=~A;                                                               \
                                SETBIT(F, FLAG_N);                                                  \
                                SETBIT(F, FLAG_H);                                                  \
                              }

//Rotates and Shifts
#define RLA                   {                                                                     \
                                UINT8 CF=A & 0x80;                                                  \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                CLEARBIT(F, FLAG_Z);                                                \
                                A=A<<1;                                                             \
                                if(F & FLAG_C) A |= 0x1;                                            \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                              }
#define RLCA                  {                                                                     \
                                UINT8 CF=A & 0x80;                                                  \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                CLEARBIT(F, FLAG_Z);                                                \
                                A=A<<1;                                                             \
                                if(F & FLAG_C) A |= 0x1;                                            \
                              }
#define RRA                   {                                                                     \
                                UINT8 CF=A & 0x1;                                                   \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                CLEARBIT(F, FLAG_Z);                                                \
                                A=A>>1;                                                             \
                                if(F & FLAG_C) A |= 0x80;                                           \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                              }
#define RRCA                  {                                                                     \
                                UINT8 CF=A & 0x1;                                                   \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                CLEARBIT(F, FLAG_Z);                                                \
                                A=A>>1;                                                             \
                                if(F & FLAG_C) A |= 0x80;                                           \
                              }
#define RL8(V)                {                                                                     \
                                UINT8 CF=V & 0x80;                                                  \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V<<1;                                                             \
                                if(F & FLAG_C) V |= 0x1;                                            \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define RLC8(V)               {                                                                     \
                                UINT8 CF=V & 0x80;                                                  \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V<<1;                                                             \
                                if(F & FLAG_C) V |= 0x1;                                            \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define RLHL                  {                                                                     \
                                UINT8 V;                                                            \
                                UINT8 CF;                                                           \
                                V=RM8(HL);                                                          \
                                CF=V & 0x80;                                                        \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V<<1;                                                             \
                                if(F & FLAG_C) V |= 0x1;                                            \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                WM8(HL, V);                                                         \
                              }
#define RLCHL                 {                                                                     \
                                UINT8 V;                                                            \
                                UINT8 CF;                                                           \
                                V=RM8(HL);                                                          \
                                CF=V & 0x80;                                                        \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V<<1;                                                             \
                                if(F & FLAG_C) V |= 0x1;                                            \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                WM8(HL, V);                                                         \
                              }
#define RR8(V)                {                                                                     \
                                UINT8 CF=V & 0x1;                                                   \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V>>1;                                                             \
                                if(F & FLAG_C) V |= 0x80;                                           \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define RRC8(V)               {                                                                     \
                                UINT8 CF=V & 0x1;                                                   \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V>>1;                                                             \
                                if(F & FLAG_C) V |= 0x80;                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define RRHL                  {                                                                     \
                                UINT8 V;                                                            \
                                UINT8 CF;                                                           \
                                V=RM8(HL);                                                          \
                                CF=V & 0x1;                                                         \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V>>1;                                                             \
                                if(F & FLAG_C) V |= 0x80;                                           \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                WM8(HL, V);                                                         \
                              }
#define RRCHL                 {                                                                     \
                                UINT8 V;                                                            \
                                UINT8 CF;                                                           \
                                V=RM8(HL);                                                          \
                                CF=V & 0x1;                                                         \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V>>1;                                                             \
                                if(F & FLAG_C) V |= 0x80;                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                WM8(HL, V);                                                         \
                              }
#define SLA8(V)               {                                                                     \
                                UINT8 CF=V & 0x80;                                                  \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V<<1;                                                             \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define SLAHL                 {                                                                     \
                                UINT8 V;                                                            \
                                UINT8 CF;                                                           \
                                V=RM8(HL);                                                          \
                                CF=V & 0x80;                                                        \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V<<1;                                                             \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                WM8(HL, V);                                                         \
                              }
#define SRL8(V)               {                                                                     \
                                UINT8 CF=V & 0x1;                                                   \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V>>1;                                                             \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define SRLHL                 {                                                                     \
                                UINT8 V;                                                            \
                                UINT8 CF;                                                           \
                                V=RM8(HL);                                                          \
                                CF=V & 0x1;                                                         \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V>>1;                                                             \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                WM8(HL, V);                                                         \
                              }
#define SRA8(V)               {                                                                     \
                                UINT8 CF=V & 0x1;                                                   \
                                UINT8 SA=V & 0x80;                                                  \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V>>1;                                                             \
                                V |= SA;                                                            \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define SRAHL                 {                                                                     \
                                UINT8 V;                                                            \
                                UINT8 CF;                                                           \
                                UINT8 SA;                                                           \
                                V=RM8(HL);                                                          \
                                CF=V & 0x1;                                                         \
                                SA=V & 0x80;                                                        \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                V=V>>1;                                                             \
                                V |= SA;                                                            \
                                if(CF) SETBIT(F, FLAG_C);                                           \
                                else CLEARBIT(F, FLAG_C);                                           \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                WM8(HL, V);                                                         \
                              }
//Misc
#define SWAP8(V)              {                                                                     \
                                V=(V >> 4) | (V << 4);                                              \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                CLEARBIT(F, FLAG_C);                                                \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                              }
#define SWAPHL                {                                                                     \
                                UINT8 V;                                                            \
                                V=RM8(HL);                                                          \
                                V=(V >> 4) | (V << 4);                                              \
                                CLEARBIT(F, FLAG_N);                                                \
                                CLEARBIT(F, FLAG_H);                                                \
                                CLEARBIT(F, FLAG_C);                                                \
                                if(V==0) SETBIT(F, FLAG_Z);                                         \
                                else CLEARBIT(F, FLAG_Z);                                           \
                                WM8(HL, V);                                                         \
                              }



//Set one register on the CPU.
void z80SetRegister(UINT32 nReg, UINT32 nVal)
{
  switch(nReg){
    case Z80GB_PC:  PC  = nVal & 0xffff; break;
    case Z80GB_SP:  SP  = nVal & 0xffff; break;
    case Z80GB_AF:  AF  = nVal & 0xffff; break;
    case Z80GB_BC:  BC  = nVal & 0xffff; break;
    case Z80GB_DE:  DE  = nVal & 0xffff; break;
    case Z80GB_HL:  HL  = nVal & 0xffff; break;
    case Z80GB_RST: RST = nVal & 0xffff; break;
    case Z80GB_A:   A   = nVal & 0xff;   break;
    case Z80GB_F:   F   = nVal & 0xff;   break;
    case Z80GB_B:   B   = nVal & 0xff;   break;
    case Z80GB_C:   C   = nVal & 0xff;   break;
    case Z80GB_D:   D   = nVal & 0xff;   break;
    case Z80GB_E:   E   = nVal & 0xff;   break;
    case Z80GB_H:   H   = nVal & 0xff;   break;
    case Z80GB_L:   L   = nVal & 0xff;   break;
  }
}

//Reset the CPU.
void z80Reset()
{
  AF  = 0x01B0;
  BC  = 0x0013;
  DE  = 0x00D8;
  HL  = 0x014D;
  SP  = 0xFFFE;
  PC  = 0x0100;
  RST = 0;
}

//Execute a CB Opcode.
INT32 z80ExecuteCB(INT32 nCycles)
{
UINT8  nOpcode;

  nOpcode=gbReadByte(PC);
  PC++;
  switch (nOpcode)
  {
    case 0x0:  //RLC B
      RLC8(B);
      break;
    case 0x1:  //RLC C
      RLC8(C);
      break;
    case 0x2:  //RLC D
      RLC8(D);
      break;
    case 0x3:  //RLC E
      RLC8(E);
      break;
    case 0x4:  //RLC H
      RLC8(H);
      break;
    case 0x5:  //RLC L
      RLC8(L);
      break;
    case 0x6:  //RLC (HL)
      RLCHL(RM8(HL));
      break;
    case 0x7:  //RLC A
      RLC8(A);
      break;
    case 0x8:  //RRC B
      RRC8(B);
      break;
    case 0x9:  //RRC C
      RRC8(C);
      break;
    case 0xA:  //RRC D
      RRC8(D);
      break;
    case 0xB:  //RRC E
      RRC8(E);
      break;
    case 0xC:  //RRC H
      RRC8(H);
      break;
    case 0xD:  //RRC L
      RRC8(L);
      break;
    case 0xE:  //RRC (HL)
      RRCHL(RM8(HL));
      break;
    case 0xF:  //RRC A
      RRC8(A);
      break;
    case 0x10:  //RL B
      RL8(B);
      break;
    case 0x11:  //RL C
      RL8(C);
      break;
    case 0x12:  //RL D
      RL8(D);
      break;
    case 0x13:  //RL E
      RL8(E);
      break;
    case 0x14:  //RL H
      RL8(H);
      break;
    case 0x15:  //RL L
      RL8(L);
      break;
    case 0x16:  //RL (HL)
      RLHL(RM8(HL));
      break;
    case 0x17:  //RL A
      RL8(A);
      break;
    case 0x18:  //RR B
      RR8(B);
      break;
    case 0x19:  //RR C
      RR8(C);
      break;
    case 0x1A:  //RR D
      RR8(D);
      break;
    case 0x1B:  //RR E
      RR8(E);
      break;
    case 0x1C:  //RR H
      RR8(H);
      break;
    case 0x1D:  //RR L
      RR8(L);
      break;
    case 0x1E:  //RR (HL)
      RRHL(RM8(HL));
      break;
    case 0x1F:  //RR A
      RR8(A);
      break;
    case 0x20:  //SLA B
      SLA8(B);
      break;
    case 0x21:  //SLA C
      SLA8(C);
      break;
    case 0x22:  //SLA D
      SLA8(D);
      break;
    case 0x23:  //SLA E
      SLA8(E);
      break;
    case 0x24:  //SLA H
      SLA8(H);
      break;
    case 0x25:  //SLA L
      SLA8(L);
      break;
    case 0x26:  //SLA (HL)
      SLAHL(RM8(HL));
      break;
    case 0x27:  //SLA A
      SLA8(A);
      break;
    case 0x28:  //SRA B
      SRA8(B);
      break;
    case 0x29:  //SRA C
      SRA8(C);
      break;
    case 0x2A:  //SRA D
      SRA8(D);
      break;
    case 0x2B:  //SRA E
      SRA8(E);
      break;
    case 0x2C:  //SRA H
      SRA8(H);
      break;
    case 0x2D:  //SRA L
      SRA8(L);
      break;
    case 0x2E:  //SRA (HL)
      SRAHL(RM8(HL));
      break;
    case 0x2F:  //SRA A
      SRA8(A);
      break;
    case 0x30:  //SWAP B
      SWAP8(B);
      break;
    case 0x31:  //SWAP C
      SWAP8(C);
      break;
    case 0x32:  //SWAP D
      SWAP8(D);
      break;
    case 0x33:  //SWAP E
      SWAP8(E);
      break;
    case 0x34:  //SWAP H
      SWAP8(H);
      break;
    case 0x35:  //SWAP L
      SWAP8(H);
      break;
    case 0x36:  //SWAP (HL)
      SWAPHL;
      break;
    case 0x37:  //SWAP A
      SWAP8(A);
      break;
    case 0x38:  //SRL B
      SRL8(B);
      break;
    case 0x39:  //SRL C
      SRL8(C);
      break;
    case 0x3A:  //SRL D
      SRL8(D);
      break;
    case 0x3B:  //SRL E
      SRL8(E);
      break;
    case 0x3C:  //SRL H
      SRL8(H);
      break;
    case 0x3D:  //SRL L
      SRL8(L);
      break;
    case 0x3E:  //SRL (HL)
      SRLHL(RM8(HL));
      break;
    case 0x3F:  //SRL A
      SRL8(A);
      break;
    case 0x40:  //BIT B, 0
      BIT(B, 0x1);
      break;
    case 0x41:  //BIT C, 0
      BIT(C, 0x1);
      break;
    case 0x42:  //BIT D, 0
      BIT(D, 0x1);
      break;
    case 0x43:  //BIT E, 0
      BIT(E, 0x1);
      break;
    case 0x44:  //BIT H, 0
      BIT(H, 0x1);
      break;
    case 0x45:  //BIT L, 0
      BIT(L, 0x1);
      break;
    case 0x46:  //BIT (HL), 0
      BIT(RM8(HL), 0x1);
      break;
    case 0x47:  //BIT A, 0
      BIT(A, 0x1);
      break;
    case 0x48:  //BIT B, 1
      BIT(B, 0x2);
      break;
    case 0x49:  //BIT C, 1
      BIT(C, 0x2);
      break;
    case 0x4A:  //BIT D, 1
      BIT(D, 0x2);
      break;
    case 0x4B:  //BIT E, 1
      BIT(E, 0x2);
      break;
    case 0x4C:  //BIT H, 1
      BIT(H, 0x2);
      break;
    case 0x4D:  //BIT L, 1
      BIT(L, 0x2);
      break;
    case 0x4E:  //BIT (HL), 1
      BIT(RM8(HL), 0x2);
      break;
    case 0x4F:  //BIT A, 1
      BIT(A, 0x2);
      break;
    case 0x50:  //BIT B, 2
      BIT(B, 0x4);
      break;
    case 0x51:  //BIT C, 2
      BIT(C, 0x4);
      break;
    case 0x52:  //BIT D, 2
      BIT(D, 0x4);
      break;
    case 0x53:  //BIT E, 2
      BIT(E, 0x4);
      break;
    case 0x54:  //BIT H, 2
      BIT(H, 0x4);
      break;
    case 0x55:  //BIT L, 2
      BIT(L, 0x4);
      break;
    case 0x56:  //BIT (HL), 2
      BIT(RM8(HL), 0x4);
      break;
    case 0x57:  //BIT A, 2
      BIT(A, 0x4);
      break;
    case 0x58:  //BIT B, 3
      BIT(B, 0x8);
      break;
    case 0x59:  //BIT C, 3
      BIT(C, 0x8);
      break;
    case 0x5A:  //BIT D, 3
      BIT(D, 0x8);
      break;
    case 0x5B:  //BIT E, 3
      BIT(E, 0x8);
      break;
    case 0x5C:  //BIT H, 3
      BIT(H, 0x8);
      break;
    case 0x5D:  //BIT L, 3
      BIT(L, 0x8);
      break;
    case 0x5E:  //BIT (HL), 3
      BIT(RM8(HL), 0x8);
      break;
    case 0x5F:  //BIT A, 3
      BIT(A, 0x8);
      break;
    case 0x60:  //BIT B, 4
      BIT(B, 0x10);
      break;
    case 0x61:  //BIT C, 4
      BIT(C, 0x10);
      break;
    case 0x62:  //BIT D, 4
      BIT(D, 0x10);
      break;
    case 0x63:  //BIT E, 4
      BIT(E, 0x10);
      break;
    case 0x64:  //BIT H, 4
      BIT(H, 0x10);
      break;
    case 0x65:  //BIT L, 4
      BIT(L, 0x10);
      break;
    case 0x66:  //BIT (HL), 4
      BIT(RM8(HL), 0x10);
      break;
    case 0x67:  //BIT A, 4
      BIT(A, 0x10);
      break;
    case 0x68:  //BIT B, 5
      BIT(B, 0x20);
      break;
    case 0x69:  //BIT C, 5
      BIT(C, 0x20);
      break;
    case 0x6A:  //BIT D, 5
      BIT(D, 0x20);
      break;
    case 0x6B:  //BIT E, 5
      BIT(E, 0x20);
      break;
    case 0x6C:  //BIT H, 5
      BIT(H, 0x20);
      break;
    case 0x6D:  //BIT L, 5
      BIT(L, 0x20);
      break;
    case 0x6E:  //BIT (HL), 5
      BIT(RM8(HL), 0x20);
      break;
    case 0x6F:  //BIT A, 5
      BIT(A, 0x20);
      break;
    case 0x70:  //BIT B, 6
      BIT(B, 0x40);
      break;
    case 0x71:  //BIT C, 6
      BIT(C, 0x40);
      break;
    case 0x72:  //BIT D, 6
      BIT(D, 0x40);
      break;
    case 0x73:  //BIT E, 6
      BIT(E, 0x40);
      break;
    case 0x74:  //BIT H, 6
      BIT(H, 0x40);
      break;
    case 0x75:  //BIT L, 6
      BIT(L, 0x40);
      break;
    case 0x76:  //BIT (HL), 6
      BIT(RM8(HL), 0x40);
      break;
    case 0x77:  //BIT A, 6
      BIT(A, 0x40);
      break;
    case 0x78:  //BIT B, 7
      BIT(B, 0x80);
      break;
    case 0x79:  //BIT C, 7
      BIT(C, 0x80);
      break;
    case 0x7A:  //BIT D, 7
      BIT(D, 0x80);
      break;
    case 0x7B:  //BIT E, 7
      BIT(E, 0x80);
      break;
    case 0x7C:  //BIT H, 7
      BIT(H, 0x80);
      break;
    case 0x7D:  //BIT L, 7
      BIT(L, 0x80);
      break;
    case 0x7E:  //BIT (HL), 7
      BIT(RM8(HL), 0x80);
      break;
    case 0x7F:  //BIT A, 7
      BIT(A, 0x80);
      break;
    case 0x80:  //RES B, 0
      RES8(B, 0x1);
      break;
    case 0x81:  //RES C, 0
      RES8(C, 0x1);
      break;
    case 0x82:  //RES D, 0
      RES8(D, 0x1);
      break;
    case 0x83:  //RES E, 0
      RES8(E, 0x1);
      break;
    case 0x84:  //RES H, 0
      RES8(H, 0x1);
      break;
    case 0x85:  //RES L, 0
      RES8(L, 0x1);
      break;
    case 0x86:  //RES (HL), 0
      RESHL(0x1);
      break;
    case 0x87:  //RES A, 0
      RES8(A, 0x1);
      break;
    case 0x88:  //RES B, 1
      RES8(B, 0x2);
      break;
    case 0x89:  //RES C, 1
      RES8(C, 0x2);
      break;
    case 0x8A:  //RES D, 1
      RES8(D, 0x2);
      break;
    case 0x8B:  //RES E, 1
      RES8(E, 0x2);
      break;
    case 0x8C:  //RES H, 1
      RES8(H, 0x2);
      break;
    case 0x8D:  //RES L, 1
      RES8(L, 0x2);
      break;
    case 0x8E:  //RES (HL), 1
      RESHL(0x2);
      break;
    case 0x8F:  //RES A, 1
      RES8(A, 0x2);
      break;
    case 0x90:  //RES B, 2
      RES8(B, 0x4);
      break;
    case 0x91:  //RES C, 2
      RES8(C, 0x4);
      break;
    case 0x92:  //RES D, 2
      RES8(D, 0x4);
      break;
    case 0x93:  //RES E, 2
      RES8(E, 0x4);
      break;
    case 0x94:  //RES H, 2
      RES8(H, 0x4);
      break;
    case 0x95:  //RES L, 2
      RES8(L, 0x4);
      break;
    case 0x96:  //RES (HL), 2
      RESHL(0x4);
      break;
    case 0x97:  //RES A, 2
      RES8(A, 0x4);
      break;
    case 0x98:  //RES B, 3
      RES8(B, 0x8);
      break;
    case 0x99:  //RES C, 3
      RES8(C, 0x8);
      break;
    case 0x9A:  //RES D, 3
      RES8(D, 0x8);
      break;
    case 0x9B:  //RES E, 3
      RES8(E, 0x8);
      break;
    case 0x9C:  //RES H, 3
      RES8(H, 0x8);
      break;
    case 0x9D:  //RES L, 3
      RES8(L, 0x8);
      break;
    case 0x9E:  //RES (HL), 3
      RESHL(0x8);
      break;
    case 0x9F:  //RES A, 3
      RES8(A, 0x8);
      break;
    case 0xA0:  //RES B, 4
      RES8(B, 0x10);
      break;
    case 0xA1:  //RES C, 4
      RES8(C, 0x10);
      break;
    case 0xA2:  //RES D, 4
      RES8(D, 0x10);
      break;
    case 0xA3:  //RES E, 4
      RES8(E, 0x10);
      break;
    case 0xA4:  //RES H, 4
      RES8(H, 0x10);
      break;
    case 0xA5:  //RES L, 4
      RES8(L, 0x10);
      break;
    case 0xA6:  //RES (HL), 4
      RESHL(0x10);
      break;
    case 0xA7:  //RES A, 4
      RES8(A, 0x10);
      break;
    case 0xA8:  //RES B, 5
      RES8(B, 0x20);
      break;
    case 0xA9:  //RES C, 5
      RES8(C, 0x20);
      break;
    case 0xAA:  //RES D, 5
      RES8(D, 0x20);
      break;
    case 0xAB:  //RES E, 5
      RES8(E, 0x20);
      break;
    case 0xAC:  //RES H, 5
      RES8(H, 0x20);
      break;
    case 0xAD:  //RES L, 5
      RES8(L, 0x20);
      break;
    case 0xAE:  //RES (HL), 5
      RESHL(0x20);
      break;
    case 0xAF:  //RES A, 5
      RES8(A, 0x20);
      break;
    case 0xB0:  //RES B, 6
      RES8(B, 0x40);
      break;
    case 0xB1:  //RES C, 6
      RES8(C, 0x40);
      break;
    case 0xB2:  //RES D, 6
      RES8(D, 0x40);
      break;
    case 0xB3:  //RES E, 6
      RES8(E, 0x40);
      break;
    case 0xB4:  //RES H, 6
      RES8(H, 0x40);
      break;
    case 0xB5:  //RES L, 6
      RES8(L, 0x40);
      break;
    case 0xB6:  //RES (HL), 6
      RESHL(0x40);
      break;
    case 0xB7:  //RES A, 6
      RES8(A, 0x40);
      break;
    case 0xB8:  //RES B, 7
      RES8(B, 0x80);
      break;
    case 0xB9:  //RES C, 7
      RES8(C, 0x80);
      break;
    case 0xBA:  //RES D, 7
      RES8(D, 0x80);
      break;
    case 0xBB:  //RES E, 7
      RES8(E, 0x80);
      break;
    case 0xBC:  //RES H, 7
      RES8(H, 0x80);
      break;
    case 0xBD:  //RES L, 7
      RES8(L, 0x80);
      break;
    case 0xBE:  //RES (HL), 7
      RESHL(0x80);
      break;
    case 0xBF:  //RES A, 7
      RES8(A, 0x80);
      break;
    case 0xC0:  //SET B, 0
      SET8(B, 0x1);
      break;
    case 0xC1:  //SET C, 0
      SET8(C, 0x1);
      break;
    case 0xC2:  //SET D, 0
      SET8(D, 0x1);
      break;
    case 0xC3:  //SET E, 0
      SET8(E, 0x1);
      break;
    case 0xC4:  //SET H, 0
      SET8(H, 0x1);
      break;
    case 0xC5:  //SET L, 0
      SET8(L, 0x1);
      break;
    case 0xC6:  //SET (HL), 0
      SETHL(0x1);
      break;
    case 0xC7:  //SET A, 0
      SET8(A, 0x1);
      break;
    case 0xC8:  //SET B, 1
      SET8(B, 0x2);
      break;
    case 0xC9:  //SET C, 1
      SET8(C, 0x2);
      break;
    case 0xCA:  //SET D, 1
      SET8(D, 0x2);
      break;
    case 0xCB:  //SET E, 1
      SET8(E, 0x2);
      break;
    case 0xCC:  //SET H, 1
      SET8(H, 0x2);
      break;
    case 0xCD:  //SET L, 1
      SET8(L, 0x2);
      break;
    case 0xCE:  //SET (HL), 1
      SETHL(0x2);
      break;
    case 0xCF:  //SET A, 1
      SET8(A, 0x2);
      break;
    case 0xD0:  //SET B, 2
      SET8(B, 0x4);
      break;
    case 0xD1:  //SET C, 2
      SET8(C, 0x4);
      break;
    case 0xD2:  //SET D, 2
      SET8(D, 0x4);
      break;
    case 0xD3:  //SET E, 2
      SET8(E, 0x4);
      break;
    case 0xD4:  //SET H, 2
      SET8(H, 0x4);
      break;
    case 0xD5:  //SET L, 2
      SET8(L, 0x4);
      break;
    case 0xD6:  //SET (HL), 2
      SETHL(0x4);
      break;
    case 0xD7:  //SET A, 2
      SET8(A, 0x4);
      break;
    case 0xD8:  //SET B, 3
      SET8(B, 0x8);
      break;
    case 0xD9:  //SET C, 3
      SET8(C, 0x8);
      break;
    case 0xDA:  //SET D, 3
      SET8(D, 0x8);
      break;
    case 0xDB:  //SET E, 3
      SET8(E, 0x8);
      break;
    case 0xDC:  //SET H, 3
      SET8(H, 0x8);
      break;
    case 0xDD:  //SET L, 3
      SET8(L, 0x8);
      break;
    case 0xDE:  //SET (HL), 3
      SETHL(0x8);
      break;
    case 0xDF:  //SET A, 3
      SET8(A, 0x8);
      break;
    case 0xE0:  //SET B, 4
      SET8(B, 0x10);
      break;
    case 0xE1:  //SET C, 4
      SET8(C, 0x10);
      break;
    case 0xE2:  //SET D, 4
      SET8(D, 0x10);
      break;
    case 0xE3:  //SET E, 4
      SET8(E, 0x10);
      break;
    case 0xE4:  //SET H, 4
      SET8(H, 0x10);
      break;
    case 0xE5:  //SET L, 4
      SET8(L, 0x10);
      break;
    case 0xE6:  //SET (HL), 4
      SETHL(0x10);
      break;
    case 0xE7:  //SET A, 4
      SET8(A, 0x10);
      break;
    case 0xE8:  //SET B, 5
      SET8(B, 0x20);
      break;
    case 0xE9:  //SET C, 5
      SET8(C, 0x20);
      break;
    case 0xEA:  //SET D, 5
      SET8(D, 0x20);
      break;
    case 0xEB:  //SET E, 5
      SET8(E, 0x20);
      break;
    case 0xEC:  //SET H, 5
      SET8(H, 0x20);
      break;
    case 0xED:  //SET L, 5
      SET8(L, 0x20);
      break;
    case 0xEE:  //SET (HL), 5
      SETHL(0x20);
      break;
    case 0xEF:  //SET A, 5
      SET8(A, 0x20);
      break;
    case 0xF0:  //SET B, 6
      SET8(B, 0x40);
      break;
    case 0xF1:  //SET C, 6
      SET8(C, 0x40);
      break;
    case 0xF2:  //SET D, 6
      SET8(D, 0x40);
      break;
    case 0xF3:  //SET E, 6
      SET8(E, 0x40);
      break;
    case 0xF4:  //SET H, 6
      SET8(H, 0x40);
      break;
    case 0xF5:  //SET L, 6
      SET8(L, 0x40);
      break;
    case 0xF6:  //SET (HL), 6
      SETHL(0x40);
      break;
    case 0xF7:  //SET A, 6
      SET8(A, 0x40);
      break;
    case 0xF8:  //SET B, 7
      SET8(B, 0x80);
      break;
    case 0xF9:  //SET C, 7
      SET8(C, 0x80);
      break;
    case 0xFA:  //SET D, 7
      SET8(D, 0x80);
      break;
    case 0xFB:  //SET E, 7
      SET8(E, 0x80);
      break;
    case 0xFC:  //SET H, 7
      SET8(H, 0x80);
      break;
    case 0xFD:  //SET L, 7
      SET8(L, 0x80);
      break;
    case 0xFE:  //SET (HL), 7
      SETHL(0x80);
      break;
    case 0xFF:  //SET A, 7
      SET8(A, 0x80);
      break;
    default:
//      gbLog("ERROR: CB %x\n", nOpcode);
      break;
  }
  nCycles-=nOPCyclesCB[nOpcode];
  return(nCycles);
}

//Execute a number of cycles on the CPU.
void z80Execute(INT32 nCycles)
{
UINT8  nOpcode;
UINT16 nAddress;
INT8   nOffset;

  while(nCycles > 0){
#ifdef DEBUG
//    gbDisassemble(PC, 1, A, B, C, D, E, H, L, SP, F);
#endif
    nOpcode=gbReadByte(PC++);
    switch (nOpcode)
    {
      case 0x00:  //NOP
        break;
      case 0x01:  //LD BC, $xxyy
        BC=RM16(PC);
        PC+=2;
        break;
      case 0x02:  //LD (BC), A
        WM8(BC, A);
        break;
      case 0x03:  //INC BC
        INC16(BC);
        break;
      case 0x04:  //INC B
        INC8(B);
        break;
      case 0x05:  //DEC B
        DEC8(B);
        break;
      case 0x06:  //LD B, $xx
        B=RM8(PC);
        PC++;
        break;
      case 0x07:  //RLCA
        RLCA;
        break;
      case 0x08:  //LD ($xxyy), SP
        nAddress=RM16(PC);
        PC+=2;
        WM16(nAddress, SP);
        break;
      case 0x09:  //ADD HL, BC
        ADDHL(BC);
        break;
      case 0x0A:  //LD A, (BC)
        A=RM8(BC);
        break;
      case 0x0B:  //DEC BC
        DEC16(BC);
        break;
      case 0x0C:  //INC C
        INC8(C);
        break;
      case 0x0D:  //DEC C
        DEC8(C);
        break;
      case 0x0E:  //LD C, $xx
        C=RM8(PC);
        PC++;
        break;
      case 0x0F:  //RRCA
        RRCA;
        break;
      case 0x10:  //STOP
        nCycles=0;
        break;
      case 0x11:  //LD DE $xxyy
        DE=RM16(PC);
        PC+=2;
        break;
      case 0x12:  //LD (DE), A
        WM8(DE, A);
        break;
      case 0x13:  //INC DE
        INC16(DE);
        break;
      case 0x14:  //INC D
        INC8(D);
        break;
      case 0x15:  //DEC D
        DEC8(D);
        break;
      case 0x16:  //LD D, $xx
        D=RM8(PC);
        PC++;
        break;
      case 0x17:  //RLA
        RLA;
        break;
      case 0x18:  //JR $xx
        nOffset=RM8(PC);
        PC++;
        PC=PC + nOffset;
        break;
      case 0x19:  //ADD HL, DE
        ADDHL(DE);
        break;
      case 0x1A:  //LD A, (DE)
        A=RM8(DE);
        break;
      case 0x1B:  //DEC DE
        DEC16(DE);
        break;
      case 0x1C:  //INC E
        INC8(E);
        break;
      case 0x1D:  //DEC E
        DEC8(E);
        break;
      case 0x1E:  //LD E, $xx
        E=RM8(PC);
        PC++;
        break;
      case 0x1F:  //RRA
        RRA;
        break;
      case 0x20:  //JR NZ, $xx
        nOffset=RM8(PC);
        PC++;
        if((F & FLAG_Z)==0) PC=PC + nOffset;
        break;
      case 0x21:  //LD HL $xxyy
        HL=RM16(PC);
        PC+=2;
        break;
      case 0x22:  //LD (HLI), A
        WM8(HL, A);
        HL++;
        break;
      case 0x23:  //INC HL
        INC16(HL);
        break;
      case 0x24:  //INC H
        INC8(H);
        break;
      case 0x25:  //DEC H
        DEC8(H);
        break;
      case 0x26:  //LD H, $xx
        H=RM8(PC);
        PC++;
        break;
      case 0x27:  //DAA
        break;
      case 0x28:  //JR Z, $xx
        nOffset=RM8(PC);
        PC++;
        if(F & FLAG_Z) PC=PC + nOffset;
        break;
      case 0x29:  //ADD HL, HL
        ADDHL(HL);
        break;
      case 0x2A:  //LD A, (HLI)
        A=RM8(HL);
        HL++;
        break;
      case 0x2B:  //DEC HL
        DEC16(HL);
        break;
      case 0x2C:  //INC L
        INC8(L);
        break;
      case 0x2D:  //DEC L
        DEC8(L);
        break;
      case 0x2E:  //LD L, $xx
        L=RM8(PC);
        PC++;
        break;
      case 0x2F:  //CPL
        CPL;
        break;
      case 0x30:  //JR NC, $xx
        nOffset=RM8(PC);
        PC++;
        if((F & FLAG_C) == 0) PC=PC + nOffset;
        break;
      case 0x31:  //LD SP $xxyy
        SP=RM16(PC);
        PC+=2;
        break;
      case 0x32:  //LD (HLD), A
        WM8(HL, A);
        HL--;
        break;
      case 0x33:  //INC SP
        INC16(SP);
        break;
      case 0x34:  //INC (HL)
        INCHL;
        break;
      case 0x35:  //DEC (HL)
        DECHL;
        break;
      case 0x36:  //LD (HL), $xx
        WM8(HL, RM8(PC));
        PC++;
        break;
      case 0x37:  //SCF
        SCF;
        break;
      case 0x38:  //JR C, $xx
        nOffset=RM8(PC);
        PC++;
        if(F & FLAG_C) PC=PC + nOffset;
        break;
      case 0x39:  //ADD HL, SP
        ADDHL(SP);
        break;
      case 0x3A:  //LD A, (HLD)
        A=RM8(HL);
        HL--;
        break;
      case 0x3B:  //DEC SP
        DEC16(SP);
        break;
      case 0x3C:  //INC A
        INC8(A);
        break;
      case 0x3D:  //DEC A
        DEC8(A);
        break;
      case 0x3E:  //LD A, $xx
        A=RM8(PC);
        PC++;
        break;
      case 0x3F:  //CCF
        CCF;
        break;
      case 0x40:  //LD B, B
        B=B;
        break;
      case 0x41:  //LD B, C
        B=C;
        break;
      case 0x42:  //LD B, D
        B=D;
        break;
      case 0x43:  //LD B, E
        B=E;
        break;
      case 0x44:  //LD B, H
        B=H;
        break;
      case 0x45:  //LD B, L
        B=L;
        break;
      case 0x46:  //LD B, (HL)
        B=RM8(HL) ;
        break;
      case 0x47:  //LD B, A
        B=A;
        break;
      case 0x48:  //LD C, B
        C=B;
        break;
      case 0x49:  //LD C, C
        C=C;
        break;
      case 0x4A:  //LD C, D
        C=D;
        break;
      case 0x4B:  //LD C, E
        C=E;
        break;
      case 0x4C:  //LD C, H
        C=H;
        break;
      case 0x4D:  //LD C, L
        C=L;
        break;
      case 0x4E:  //LD C, (HL)
        C=RM8(HL) ;
        break;
      case 0x4F:  //LD C, A
        C=A;
        break;
      case 0x50:  //LD D, B
        D=B;
        break;
      case 0x51:  //LD D, C
        D=C;
        break;
      case 0x52:  //LD D, D
        D=D;
        break;
      case 0x53:  //LD D, E
        D=E;
        break;
      case 0x54:  //LD D, H
        D=H;
        break;
      case 0x55:  //LD D, L
        D=L;
        break;
      case 0x56:  //LD D, (HL)
        D=RM8(HL) ;
        break;
      case 0x57:  //LD D, A
        D=A;
        break;
      case 0x58:  //LD E, B
        E=B;
        break;
      case 0x59:  //LD E, C
        E=C;
        break;
      case 0x5A:  //LD E, D
        E=D;
        break;
      case 0x5B:  //LD E, E
        E=E;
        break;
      case 0x5C:  //LD E, H
        E=H;
        break;
      case 0x5D:  //LD E, L
        E=L;
        break;
      case 0x5E:  //LD E, (HL)
        E=RM8(HL) ;
        break;
      case 0x5F:  //LD E, A
        E=A;
        break;
      case 0x60:  //LD H, B
        H=B;
        break;
      case 0x61:  //LD H, C
        H=C;
        break;
      case 0x62:  //LD H, D
        H=D;
        break;
      case 0x63:  //LD H, E
        H=E;
        break;
      case 0x64:  //LD H, H
        H=H;
        break;
      case 0x65:  //LD H, L
        H=L;
        break;
      case 0x66:  //LD H, (HL)
        H=RM8(HL) ;
        break;
      case 0x67:  //LD H, A
        H=A;
        break;
      case 0x68:  //LD L, B
        L=B;
        break;
      case 0x69:  //LD L, C
        L=C;
        break;
      case 0x6A:  //LD L, D
        L=D;
        break;
      case 0x6B:  //LD L, E
        L=E;
        break;
      case 0x6C:  //LD L, H
        L=H;
        break;
      case 0x6D:  //LD L, L
        L=L;
        break;
      case 0x6E:  //LD L, (HL)
        L=RM8(HL) ;
        break;
      case 0x6F:  //LD L, A
        L=A;
        break;
      case 0x70:  //LD (HL), B
        WM8(HL, B);
        break;
      case 0x71:  //LD (HL), C
        WM8(HL, C);
        break;
      case 0x72:  //LD (HL), D
        WM8(HL, D);
        break;
      case 0x73:  //LD (HL), E
        WM8(HL, E);
        break;
      case 0x74:  //LD (HL), H
        WM8(HL, H);
        break;
      case 0x75:  //LD (HL), L
        WM8(HL, L);
        break;
      case 0x76:  //HALT
        nCycles=0;
        break;
      case 0x77:  //LD (HL), A
        WM8(HL, A);
        break;
      case 0x78:  //LD A, B
        A=B;
        break;
      case 0x79:  //LD A, C
        A=C;
        break;
      case 0x7A:  //LD A, D
        A=D;
        break;
      case 0x7B:  //LD A, E
        A=E;
        break;
      case 0x7C:  //LD A, H
        A=H;
        break;
      case 0x7D:  //LD A, L
        A=L;
        break;
      case 0x7E:  //LD A, (HL)
        A=RM8(HL) ;
        break;
      case 0x7F:  //LD A, A
        A=A;
        break;
      case 0x80:  //ADD A, B
        ADD(B);
        break;
      case 0x81:  //ADD A, C
        ADD(C);
        break;
      case 0x82:  //ADD A, D
        ADD(D);
        break;
      case 0x83:  //ADD A, E
        ADD(E);
        break;
      case 0x84:  //ADD A, H
        ADD(H);
        break;
      case 0x85:  //ADD A, L
        ADD(L);
        break;
      case 0x86:  //ADD A, (HL)
        ADD(RM8(HL));
        break;
      case 0x87:  //ADD A, A
        ADD(A);
        break;
      case 0x88:  //ADC A, B
        ADC(B);
        break;
      case 0x89:  //ADC A, C
        ADC(C);
        break;
      case 0x8A:  //ADC A, D
        ADC(D);
        break;
      case 0x8B:  //ADC A, E
        ADC(E);
        break;
      case 0x8C:  //ADC A, H
        ADC(H);
        break;
      case 0x8D:  //ADC A, L
        ADC(L);
        break;
      case 0x8E:  //ADC A, (HL)
        ADC(RM8(HL));
        break;
      case 0x8F:  //ADC A, A
        ADC(A);
        break;
      case 0x90:  //SUB A, B
        SUB(B);
        break;
      case 0x91:  //SUB A, C
        SUB(C);
        break;
      case 0x92:  //SUB A, D
        SUB(D);
        break;
      case 0x93:  //SUB A, E
        SUB(E);
        break;
      case 0x94:  //SUB A, H
        SUB(H);
        break;
      case 0x95:  //SUB A, L
        SUB(L);
        break;
      case 0x96:  //SUB A, (HL)
        SUB(RM8(HL));
        break;
      case 0x97:  //SUB A, A
        SUB(A);
        break;
      case 0x98:  //SBC A, B
        SBC(B);
        break;
      case 0x99:  //SBC A, C
        SBC(C);
        break;
      case 0x9A:  //SBC A, D
        SBC(D);
        break;
      case 0x9B:  //SBC A, E
        SBC(E);
        break;
      case 0x9C:  //SBC A, H
        SBC(H);
        break;
      case 0x9D:  //SBC A, L
        SBC(L);
        break;
      case 0x9E:  //SBC A, (HL)
        SBC(RM8(HL));
        break;
      case 0x9F:  //SBC A, A
        SBC(A);
        break;
      case 0xA0:  //AND A, B
        AND(B);
        break;
      case 0xA1:  //AND A, C
        AND(C);
        break;
      case 0xA2:  //AND A, D
        AND(D);
        break;
      case 0xA3:  //AND A, E
        AND(E);
        break;
      case 0xA4:  //AND A, H
        AND(H);
        break;
      case 0xA5:  //AND A, L
        AND(L);
        break;
      case 0xA6:  //AND A, (HL)
        AND(RM8(HL));
        break;
      case 0xA7:  //AND A, A
        AND(A);
        break;
      case 0xA8:  //XOR A, B
        XOR(B);
        break;
      case 0xA9:  //XOR A, C
        XOR(C);
        break;
      case 0xAA:  //XOR A, D
        XOR(D);
        break;
      case 0xAB:  //XOR A, E
        XOR(E);
        break;
      case 0xAC:  //XOR A, H
        XOR(H);
        break;
      case 0xAD:  //XOR A, L
        XOR(L);
        break;
      case 0xAE:  //XOR A, (HL)
        XOR(RM8(HL));
        break;
      case 0xAF:  //XOR A, A
        XOR(A);
        break;
      case 0xB0:  //OR A, B
        OR(B);
        break;
      case 0xB1:  //OR A, C
        OR(C);
        break;
      case 0xB2:  //OR A, D
        OR(D);
        break;
      case 0xB3:  //OR A, E
        OR(E);
        break;
      case 0xB4:  //OR A, H
        OR(H);
        break;
      case 0xB5:  //OR A, L
        OR(L);
        break;
      case 0xB6:  //OR A, (HL)
        OR(RM8(HL));
        break;
      case 0xB7:  //OR A, A
        OR(A);
        break;
      case 0xB8:  //CP A, B
        CP(B);
        break;
      case 0xB9:  //CP A, C
        CP(C);
        break;
      case 0xBA:  //CP A, D
        CP(D);
        break;
      case 0xBB:  //CP A, E
        CP(E);
        break;
      case 0xBC:  //CP A, H
        CP(H);
        break;
      case 0xBD:  //CP A, L
        CP(L);
        break;
      case 0xBE:  //CP A, (HL)
        CP(RM8(HL));
        break;
      case 0xBF:  //CP A, A
        CP(A);
        break;
      case 0xC0:  //RET NZ
        if((F & FLAG_Z) == 0) POP(PC);
        break;
      case 0xC1:  //POP BC
        POP(BC);
        break;
      case 0xC2:  //JP NZ, $xxyy
        nAddress=RM16(PC);
        PC+=2;
        if((F & FLAG_Z) == 0) PC=nAddress;
        break;
      case 0xC3:  //JP $xxyy
        nAddress=RM16(PC);
        PC=nAddress;
        break;
      case 0xC4:  //CALL NZ, $xxyy
        nAddress=RM16(PC);
        PC+=2;
        if((F & FLAG_Z) == 0)
        {
          PUSH(PC);
          PC=nAddress;
        }
        break;
      case 0xC5:  //PUSH BC
        PUSH(BC);
        break;
      case 0xC6:  //ADD A, $xx
        ADD(RM8(PC));
        PC++;
        break;
      case 0xC7:  //RST 0x00
        PUSH(PC);
        PC=RST + 0x00;
        break;
      case 0xC8:  //RET Z
        if(F & FLAG_Z) POP(PC);
        break;
      case 0xC9:  //RET
        POP(PC);
        break;
      case 0xCA:  //JP Z, $xxyy
        nAddress=RM16(PC);
        PC+=2;
        if(F & FLAG_Z) PC=nAddress;
        break;
      case 0xCB:  //CB opcodes
        nCycles=z80ExecuteCB(nCycles);
        break;
      case 0xCC:  //CALL Z, $xxyy
        nAddress=RM16(PC);
        PC+=2;
        if(F & FLAG_Z)
        {
          PUSH(PC);
          PC=nAddress;
        }
        break;
      case 0xCD:  //CALL $xxyy
        nAddress=RM16(PC);
        PC+=2;
        PUSH(PC);
        PC=nAddress;
        break;
      case 0xCE:  //ADC A, $xx
        ADC(RM8(PC));
        PC++;
        break;
      case 0xCF:  //RST 0x08
        PUSH(PC);
        PC=RST + 0x08;
        break;
      case 0xD0:  //RET NC
        if((F & FLAG_C) == 0) POP(PC);
        break;
      case 0xD1:  //POP DE
        POP(DE);
        break;
      case 0xD2:  //JP NC, $xxyy
        nAddress=RM16(PC);
        PC+=2;
        if((F & FLAG_C) == 0) PC=nAddress;
        break;
      case 0xD4:  //CALL NC, $xxyy
        nAddress=RM16(PC);
        PC+=2;
        if((F & FLAG_C) == 0)
        {
          PUSH(PC);
          PC=nAddress;
        }
        break;
      case 0xD5:  //PUSH DE
        PUSH(DE);
        break;
      case 0xD6:  //SUB A, $xx
        SUB(RM8(PC));
        PC++;
        break;
      case 0xD7:  //RST 0x10
        PUSH(PC);
        PC=RST + 0x10;
        break;
      case 0xD8:  //RET C
        if(F & FLAG_C) POP(PC);
        break;
      case 0xD9:  //RET
        POP(PC);
        break;
      case 0xDA:  //JP C, $xxyy
        nAddress=RM16(PC);
        PC+=2;
        if(F & FLAG_C) PC=nAddress;
        break;
      case 0xDC:  //CALL C, $xxyy
        nAddress=RM16(PC);
        PC+=2;
        if(F & FLAG_C)
        {
          PUSH(PC);
          PC=nAddress;
        }
        break;
      case 0xDE:  //SBC A, $xx
        SBC(RM8(PC));
        PC++;
        break;
      case 0xDF:  //RST 0x18
        PUSH(PC);
        PC=RST + 0x18;
        break;
      case 0xE0:  //LD (0xff00 + $xx), A
        WM8(0xff00 | RM8(PC), A);
        PC++;
        break;
      case 0xE1:  //POP HL
        POP(HL);
        break;
      case 0xE2:  //LD (0xff00 + C), A
        WM8(0xff00 | C, A);
        break;
      case 0xE5:  //PUSH HL
        PUSH(HL);
        break;
      case 0xE6:  //AND A, $xx
        AND(RM8(PC));
        PC++;
        break;
      case 0xE7:  //RST 0x20
        PUSH(PC);
        PC=RST + 0x20;
        break;
      case 0xE8:  //ADD SP, $xx
        nOffset=RM8(PC);
        PC++;
        ADDSP(nOffset);
        break;
      case 0xE9:  //JP (HL)
        PC=HL;
        break;
      case 0xEA:  //LD ($aabb), A
        nAddress=RM16(PC);
        PC+=2;
        WM8(nAddress, A);
        break;
      case 0xEE:  //XOR A, $xx
        XOR(RM8(PC));
        PC++;
        break;
      case 0xEF:  //RST 0x28
        PUSH(PC);
        PC=RST + 0x28;
        break;
      case 0xF0:  //LD A, (0xff00 + $xx)
        A=RM8(0xff00 | RM8(PC));
        PC++;
        break;
      case 0xF1:  //POP AF
        POP(AF);
        break;
      case 0xF2:  //LD A, (0xff00 + C)
        A=RM8(0xff00 | C);
        break;
      case 0xF3:  //DI
        break;
      case 0xF5:  //PUSH AF
        PUSH(AF);
        break;
      case 0xF6:  //OR A, $xx
        OR(RM8(PC));
        PC++;
        break;
      case 0xF7:  //RST 0x30
        PUSH(PC);
        PC=RST + 0x30;
        break;
      case 0xF8:  //LD HL, SP
        nOffset=RM8(PC);
        PC++;
        HL=SP + nOffset;
        if(((UINT32)HL + (UINT32)(SP + nOffset)) & 0x10000) SETBIT(F, FLAG_C);
        else CLEARBIT(F, FLAG_C);
        if(((HL & 0xfff) + ((SP + nOffset) & 0xfff)) & 0x1000) SETBIT(F, FLAG_H);
        else CLEARBIT(F, FLAG_H);
        CLEARBIT(F, FLAG_N);
        CLEARBIT(F, FLAG_Z);
        break;
      case 0xF9:  //LD SP, HL
        SP=HL;
        break;
      case 0xFA:  //LD A, ($xxyy)
        nAddress=RM16(PC);
        PC+=2;
        A=RM8(nAddress);
        break;
      case 0xFB:  //EI
        break;
      case 0xFE:  //CP A, $xx
        CP(RM8(PC));
        PC++;
        break;
      case 0xFF:  //RST 0x38
        PUSH(PC);
        PC=RST + 0x38;
        break;
      default:
//        gbLog("ERROR: %x\n", nOpcode);
        break;
    }
    nCycles-=nOPCycles[nOpcode];
  }
}
