#define UINT32 unsigned int
#define INT32  int
#define UINT16 unsigned short int
#define INT16  short
#define UINT8  unsigned char
#define INT8   char

//#define DEBUG

enum
{
  Z80GB_PC=1, 
  Z80GB_SP, 
  Z80GB_AF, 
  Z80GB_BC, 
  Z80GB_DE, 
  Z80GB_HL, 
  Z80GB_RST, 
  Z80GB_A,
  Z80GB_F,
  Z80GB_B,
  Z80GB_C,
  Z80GB_D,
  Z80GB_E,
  Z80GB_H,
  Z80GB_L
};

void z80Execute(INT32 nCycles);
void z80SetRegister(UINT32 nReg, UINT32 nVal);
void z80Reset();