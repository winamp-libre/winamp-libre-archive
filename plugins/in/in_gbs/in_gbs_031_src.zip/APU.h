#define UINT32 unsigned int
#define INT32  int
#define UINT16 unsigned short int
#define INT16  short
#define UINT8  unsigned char
#define INT8   char

void gbAPUWrite(UINT16 nAddress, UINT8 nData);
UINT8 gbAPURead(UINT16 nAddress);
void gbAPUReset();

INT8 mAPUSquare0();
INT8 mAPUSquare1();
INT8 mAPUPCM();
INT8 mAPUNoise();