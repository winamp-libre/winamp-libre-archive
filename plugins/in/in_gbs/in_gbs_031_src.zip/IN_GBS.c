#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include "gbZ80\z80.h"
//#include "z80\z80.h"
#include "APU.h"
#include "in2.h"
#include "resource.h"

#define WM_WA_MPEG_EOF WM_USER+2

#define NCH 2
#define SAMPLERATE 44100
#define BPS 16
#define BYTES 735
#define CLOCK 4194304 * 2
#define OVERSAMPLE 95
//#define OVERSAMPLE 1

#define PLAY 0x0
#define NEXT 0x1
#define LAST 0x2

UINT8  pCPU[0x10000];
UINT8 *pFILE=NULL;
UINT8 *pTFILE=NULL;

UINT32 nChannelEnable[4]={1, 1, 1, 1};

In_Module mod;
INT8      szLastFilename[MAX_PATH]="\0";
UINT32    nFileLength;
UINT32    nPaused;
INT8      pSampleBuffer[1000 * NCH * (BPS / 8) * 2];
UINT32    nKillDecodeThread=0;
HANDLE    hThread=INVALID_HANDLE_VALUE;
UINT32    nLastButton=0;
UINT32    nDecodePosition;

UINT32    nBufferLength=0;
UINT32    nBufferInc=0;
UINT32    nFPS=60;

INT32     nCurrentSong=0;

UINT32    nPageOffset;

WNDPROC   pOrigProc=NULL;

LRESULT CALLBACK HookWinampWnd(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
DWORD WINAPI __stdcall DecodeThread(void *b);

typedef struct tagGBSHEADER
{
  UINT8  nID[3];
  UINT8  nVersion;
  UINT8  nSongs;
  UINT8  nFirstSong;
  UINT16 nLoadAddr;
  UINT16 nInitAddr;
  UINT16 nPlayAddr;
  UINT16 nStackAddr;
  UINT8  nTimerMod;
  UINT8  nTimerCon;
  UINT8  szTitle[32];
  UINT8  szAuthor[32];
  UINT8  szCopyright[32];
} GBSHEADER;

GBSHEADER tHeader;

void gbLog(char *string, ...)
{
va_list arg;
char szBuffer[1024];
FILE *fp;

  va_start(arg, string);
  vsprintf(szBuffer, string, arg);
  va_end(arg);
  fp=fopen("log.txt", "a+t");
  if(fp==NULL) return;
  fprintf(fp, "%s", szBuffer);
  fclose(fp);
}

void gbWriteByte(UINT16 nAddress, UINT8 nData)
{
UINT32 nRate[]={4096, 262144, 65536, 16384};
INT32 nSize;

  //ROM write
  if(nAddress < 0x8000){
    //bankswitch ROM
    if(nAddress>=0x2000 && nAddress<=0x3fff){
      nData &=0x1f;
      nSize=nFileLength - (0x4000 * nData);
      if(nSize > 0x4000) nSize=0x4000;
      if(nSize <= 0x0) nSize=0x0;
      if(nSize > 0x0){
        ZeroMemory(pCPU + 0x4000, 0x4000);
        CopyMemory(pCPU + 0x4000, pFILE + (0x4000 * nData), nSize);
      }
    }
    //yeah right!
    else return;
  }
  //RAM write
  else if(nAddress >= 0x8000 && nAddress <= 0xffff){
    //timer write
    if(nAddress>=0xff05 && nAddress<=0xff07){
      pCPU[nAddress]=nData;
      if(pCPU[0xff07] & 0x4) nFPS=nRate[pCPU[0xff07] & 0x3] / (256 - pCPU[0xff06]);
      else nFPS=30;
      if(pCPU[0xff07] & 0x80){
        nFPS*=2;
      }
      nBufferLength=(44100 * OVERSAMPLE) / nFPS;
    }
    //sound hardware write
    else if(nAddress>=0xff10 && nAddress<=0xff3f) gbAPUWrite(nAddress, nData);
    //everything else
    else pCPU[nAddress]=nData;
  }
}

UINT8 gbReadByte(UINT16 nAddress)
{
  if(nAddress>=0xff10 && nAddress<=0xff3f) return(gbAPURead(nAddress));
//  else if(nAddress >= 0xa000 && nAddress <= 0xdfff) return(pCPU[nAddress]);
  else return(pCPU[nAddress]);
}

UINT16 gbReadWord(UINT16 nAddress)
{
UINT16 nData;

  nData=gbReadByte(nAddress + 1) << 8;
  nData |= gbReadByte(nAddress);
  return nData;
}

void gbWriteWord(UINT16 nAddress, UINT16 nData)
{
  gbWriteByte(nAddress, nData & 0xFF);
  gbWriteByte(nAddress + 1, nData >> 8);
}

void gbSoundReset()
{
  gbAPUReset();
  nFPS=60;
  nBufferInc=CLOCK / (44100 * OVERSAMPLE) / 2;
  if(tHeader.nTimerCon || tHeader.nTimerMod){
    gbWriteByte(0xff06,tHeader.nTimerMod);
    gbWriteByte(0xff07,tHeader.nTimerCon);
  }
  else nBufferLength=(44100 * OVERSAMPLE) / nFPS;
}

// avoid CRT. Evil. Big. Bloated.
BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
  return(TRUE);
}

BOOL CALLBACK DlgProc(HWND hWnd, UINT nMsg, WPARAM wParam, LPARAM lParam)
{
  switch(nMsg){
    case WM_INITDIALOG:
      if(nChannelEnable[0]) SendMessage(GetDlgItem(hWnd, IDC_CHECK1), BM_SETCHECK, BST_CHECKED, 0);
      else SendMessage(GetDlgItem(hWnd, IDC_CHECK1), BM_SETCHECK, BST_UNCHECKED, 0);
      if(nChannelEnable[1]) SendMessage(GetDlgItem(hWnd, IDC_CHECK2), BM_SETCHECK, BST_CHECKED, 0);
      else SendMessage(GetDlgItem(hWnd, IDC_CHECK1), BM_SETCHECK, BST_UNCHECKED, 0);
      if(nChannelEnable[2]) SendMessage(GetDlgItem(hWnd, IDC_CHECK3), BM_SETCHECK, BST_CHECKED, 0);
      else SendMessage(GetDlgItem(hWnd, IDC_CHECK1), BM_SETCHECK, BST_UNCHECKED, 0);
      if(nChannelEnable[3]) SendMessage(GetDlgItem(hWnd, IDC_CHECK4), BM_SETCHECK, BST_CHECKED, 0);
      else SendMessage(GetDlgItem(hWnd, IDC_CHECK1), BM_SETCHECK, BST_UNCHECKED, 0);

    case WM_COMMAND:
      if(SendMessage(GetDlgItem(hWnd, IDC_CHECK1), BM_GETCHECK, BST_CHECKED, 0)==BST_CHECKED) nChannelEnable[0]=1;
      else nChannelEnable[0]=0;
      if(SendMessage(GetDlgItem(hWnd, IDC_CHECK2), BM_GETCHECK, BST_CHECKED, 0)==BST_CHECKED) nChannelEnable[1]=1;
      else nChannelEnable[1]=0;
      if(SendMessage(GetDlgItem(hWnd, IDC_CHECK3), BM_GETCHECK, BST_CHECKED, 0)==BST_CHECKED) nChannelEnable[2]=1;
      else nChannelEnable[2]=0;
      if(SendMessage(GetDlgItem(hWnd, IDC_CHECK4), BM_GETCHECK, BST_CHECKED, 0)==BST_CHECKED) nChannelEnable[3]=1;
      else nChannelEnable[3]=0;

      return(0);

    case WM_CLOSE:

      if(SendMessage(GetDlgItem(hWnd, IDC_CHECK1), BM_GETCHECK, BST_CHECKED, 0)==BST_CHECKED) nChannelEnable[0]=1;
      else nChannelEnable[0]=0;
      if(SendMessage(GetDlgItem(hWnd, IDC_CHECK2), BM_GETCHECK, BST_CHECKED, 0)==BST_CHECKED) nChannelEnable[1]=1;
      else nChannelEnable[1]=0;
      if(SendMessage(GetDlgItem(hWnd, IDC_CHECK3), BM_GETCHECK, BST_CHECKED, 0)==BST_CHECKED) nChannelEnable[2]=1;
      else nChannelEnable[2]=0;
      if(SendMessage(GetDlgItem(hWnd, IDC_CHECK4), BM_GETCHECK, BST_CHECKED, 0)==BST_CHECKED) nChannelEnable[3]=1;
      else nChannelEnable[3]=0;

      EndDialog(hWnd, 0);
      return 1;
  }
  return 0;
}

void gbConfig(HWND hParent)
{
  DialogBox(mod.hDllInstance, MAKEINTRESOURCE(CONFIG_DIALOG), hParent, DlgProc);
}

void gbAbout(HWND hParent)
{
  MessageBox(hParent,"Meridian GBS Player, by Jason Cline","About Meridian GBS Player",MB_OK);
}

void gbInit()
{

}

void gbQuit()
{
}

int gbIsOurFile(INT8 *szFilename)
{
  return(0);
} 

INT32 gbReadFile(INT8 *szFilename, INT8 *pBuf)
{
HANDLE hFile;
UINT32 nSize, nRead=0;

  hFile=CreateFile(szFilename, GENERIC_READ, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
  if(hFile == INVALID_HANDLE_VALUE) return(0);
  nSize=GetFileSize(hFile, NULL);
  if(pBuf){
    ReadFile(hFile, pBuf, nSize, &nRead, NULL);
    CloseHandle(hFile);
    return(nRead);
  }
  CloseHandle(hFile);
  return(nSize);
}


INT32 gbLoad(INT8 *szFilename)
{
  nFileLength=gbReadFile(szFilename, NULL);
  if(nFileLength==0) return(1);
  pTFILE=(UINT8 *)malloc(nFileLength);
  gbReadFile(szFilename, pTFILE);
  CopyMemory(&tHeader, pTFILE, sizeof(GBSHEADER));
  return(0);
}


INT32 gbPlay(INT8 *szFilename) 
{ 
INT32  nMaxLatency;
INT32  nThreadID;
UINT32 nLength;

  //hook the winamp message thread
  if(pOrigProc==NULL) pOrigProc=(WNDPROC)SetWindowLong(mod.hMainWindow, GWL_WNDPROC, (LONG)HookWinampWnd);
  //do some winamp stuff
  nMaxLatency = mod.outMod->Open(SAMPLERATE, NCH, BPS, -1,-1);
  if(nMaxLatency < 0) return(1);
  mod.SetInfo((SAMPLERATE * BPS * NCH) / 1000, SAMPLERATE / 1000, NCH, 1);
  mod.SAVSAInit(nMaxLatency, SAMPLERATE);
  mod.VSASetInfo(SAMPLERATE, NCH);
  mod.outMod->SetVolume(-666);
  //load the file
  if(gbLoad(szFilename)==1) return(1);
  pFILE=(UINT8 *)malloc(nFileLength + tHeader.nLoadAddr - sizeof(GBSHEADER));
  ZeroMemory(pFILE, nFileLength + tHeader.nLoadAddr - sizeof(GBSHEADER));
  CopyMemory(pFILE + tHeader.nLoadAddr, pTFILE + sizeof(GBSHEADER), nFileLength - sizeof(GBSHEADER));
  nFileLength+=tHeader.nLoadAddr - sizeof(GBSHEADER);
  free(pTFILE);
  //reset the song counter to 0 on file load
  if(strcmp(szLastFilename, szFilename)){
    strcpy(szLastFilename, szFilename);
    nCurrentSong=tHeader.nFirstSong - 1;
  }
  //load the data into the cpu's two ROM banks
  ZeroMemory(pCPU, 0x10000);
  nLength=0x8000;
  if(nLength > nFileLength) nLength=nFileLength;
  CopyMemory(pCPU, pFILE, nLength);
  //reset the cpu
  z80Reset();
  z80SetRegister(Z80GB_A, nCurrentSong);
  z80SetRegister(Z80GB_SP, tHeader.nStackAddr);
  z80SetRegister(Z80GB_RST, tHeader.nLoadAddr);
  //reset the sound
  gbSoundReset();
  //run the init sequence
  pCPU[0x200]=0xCD;
  pCPU[0x201]=tHeader.nInitAddr & 0xff;
  pCPU[0x202]=(tHeader.nInitAddr >> 8) & 0xff;
  pCPU[0x203]=0x10;
  z80SetRegister(Z80GB_PC, 0x200);
  z80Execute(4194304);
#ifdef DEBUG
  gbLog("\n\n");
#endif

  //misc
  nPaused=0;
  nDecodePosition=0;
  //start the decode thread
  nKillDecodeThread=0;
  hThread = (HANDLE) CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)DecodeThread, (void *)&nKillDecodeThread, 0, &nThreadID);
  return(0); 
}

void gbPause()
{
  nPaused=1;
  mod.outMod->Pause(1);
}

void gbUnpause()
{
  nPaused=0;
  mod.outMod->Pause(0);
}

INT32 gbIsPaused()
{
  return(nPaused);
}

void gbStop()
{ 
  if(hThread != INVALID_HANDLE_VALUE){
    nKillDecodeThread=1;
    if(WaitForSingleObject(hThread,INFINITE) == WAIT_TIMEOUT) TerminateThread(hThread,0);
    CloseHandle(hThread);
    hThread = INVALID_HANDLE_VALUE;
  }
  mod.outMod->Close();
  mod.SAVSADeInit();
  if(pFILE) free(pFILE);
  pFILE=NULL;

  SetWindowLong(mod.hMainWindow, GWL_WNDPROC, (LONG)pOrigProc);
  pOrigProc=NULL;
}

void gbSetVolume(INT32 nVolume)
{
  mod.outMod->SetVolume(nVolume);
}

void gbSetPan(INT32 nPan)
{
  mod.outMod->SetPan(nPan);
}

int gbInfoDlg(INT8 *szFilename, HWND hWnd)
{
  return(0);
}

void gbEqSet(INT32 nOn, INT8 pData[10], INT32 nPreamp)
{ 
}

int gbGetLength()
{
  return(-1000);
}

int gbGetOutputTime()
{
  return(mod.outMod->GetOutputTime());
}

void gbSetOutputTime(INT32 nTimeInMS)
{
}

void gbGetFileInfo(INT8 *szFilename, INT8 *szTitle, INT32 *nLengthInMS)
{
char szT[256];

  if(!szFilename || !*szFilename) szFilename=szLastFilename;
  if(szTitle){
    ZeroMemory(szT, sizeof(szT));
    CopyMemory(szT, tHeader.szTitle, 32);
    wsprintf(szTitle,"%s - Track %d/%d  ", szT, nCurrentSong + 1, tHeader.nSongs);
  }
  if(nLengthInMS) *nLengthInMS=-1000;
}

DWORD WINAPI __stdcall DecodeThread(void *b)
{
INT32 i, j;
INT32 nLength;
INT16 nSquare0, nSquare1, nPCM, nNoise;
INT16 nOutputLeft, nOutputRight;

  while (! *((int *)b)){
    if(mod.outMod->CanWrite() >= (((nBufferLength / OVERSAMPLE)*NCH*(BPS/8))<<(mod.dsp_isactive()?1:0))){  
      //run one frame worth of sound
      pCPU[0x200]=0xCD;
      pCPU[0x201]=tHeader.nPlayAddr & 0xff;
      pCPU[0x202]=(tHeader.nPlayAddr >> 8) & 0xff;
      pCPU[0x203]=0x10;
      z80SetRegister(Z80GB_PC, 0x200);
      z80Execute(4194304 / 60);

#ifdef DEBUG
      gbLog("\n\n");
#endif

      //decode the music
      nLength=(nBufferLength / OVERSAMPLE) * NCH * (BPS / 8);
      for(i=0; i<(nBufferLength / OVERSAMPLE); i++){
        nOutputLeft=nOutputRight=0;
        nSquare0=nSquare1=nPCM=nNoise=0;
        for(j=0; j<OVERSAMPLE; j++){
          nSquare0+=mAPUSquare0();
          nSquare1+=mAPUSquare1();
          nPCM+=mAPUPCM();
          nNoise+=mAPUNoise();
        }

        if(nChannelEnable[0]==0) nSquare0=0;
        if(nChannelEnable[1]==0) nSquare1=0;
        if(nChannelEnable[2]==0) nNoise=0;
        if(nChannelEnable[3]==0) nPCM=0;

        //left channel
        if(pCPU[0xFF25] & 0x10) nOutputLeft+=nSquare0;
        if(pCPU[0xFF25] & 0x20) nOutputLeft+=nSquare1;
        if(pCPU[0xFF25] & 0x40) nOutputLeft+=nPCM;
        if(pCPU[0xFF25] & 0x80) nOutputLeft+=nNoise;

        if(pCPU[0xFF25] & 0x01) nOutputRight+=nSquare0;
        if(pCPU[0xFF25] & 0x02) nOutputRight+=nSquare1;
        if(pCPU[0xFF25] & 0x04) nOutputRight+=nPCM;
        if(pCPU[0xFF25] & 0x08) nOutputRight+=nNoise;
        //right channel
        nOutputLeft /= OVERSAMPLE;
        nOutputRight /= OVERSAMPLE;
        //scale the output
        nOutputLeft=(nOutputLeft + (((nOutputLeft * ((pCPU[0xFF24] >> 4) & 0x7)) / 7)));
        nOutputRight=(nOutputRight + (((nOutputRight * (pCPU[0xFF24] & 0x7)) / 7)));
        //put it in the buffer
        pSampleBuffer[(i*4)+0]=(nOutputLeft >> 8) & 0xff;
        pSampleBuffer[(i*4)+1]=nOutputLeft & 0xff;
        pSampleBuffer[(i*4)+2]=(nOutputRight >> 8) & 0xff;
        pSampleBuffer[(i*4)+3]=nOutputRight & 0xff;
      }
      //send the music to winamp
      nDecodePosition=mod.outMod->GetWrittenTime();
      mod.SAAddPCMData((INT8 *)pSampleBuffer, NCH, BPS, nDecodePosition);
      mod.VSAAddPCMData((INT8 *)pSampleBuffer, NCH, BPS, nDecodePosition);
      if (mod.dsp_isactive()) nLength=mod.dsp_dosamples(pSampleBuffer, nLength / NCH / (BPS / 8), BPS, NCH, SAMPLERATE)*(NCH*(BPS/8));
      mod.outMod->Write(pSampleBuffer, nLength);
    }
  else Sleep(10);
  }
  return(0);
}

LRESULT CALLBACK HookWinampWnd(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch(uMsg) { 
    case WM_COMMAND:
    case WM_SYSCOMMAND:
      switch(LOWORD(wParam)){
        case 40044: //rewind
          nCurrentSong--;
          if(nCurrentSong<0) nCurrentSong=tHeader.nSongs - 1;
          gbStop();
          mod.outMod->Flush(0);
          gbPlay(szLastFilename);
          return(0);
        case 40048: //fast forward
          nCurrentSong++;
          if(nCurrentSong>=tHeader.nSongs) nCurrentSong=0;
          gbStop();
          mod.outMod->Flush(0);
          gbPlay(szLastFilename);
          return(0);
      }
      return CallWindowProc(pOrigProc, hWnd, uMsg, wParam, lParam);
    case WM_KEYDOWN:
      switch(LOWORD(wParam)){
        case 'z':
        case 'Z':
        case VK_NUMPAD4: //rewind
          nCurrentSong--;
          if(nCurrentSong<0) nCurrentSong=tHeader.nSongs - 1;
          gbStop();
          mod.outMod->Flush(0);
          gbPlay(szLastFilename);
          return(0);
        case 'b':
        case 'B':
        case VK_NUMPAD6: //fast forward
          nCurrentSong++;
          if(nCurrentSong>=tHeader.nSongs) nCurrentSong=0;
          gbStop();
          mod.outMod->Flush(0);
          gbPlay(szLastFilename);
          return(0);
      }
      return CallWindowProc(pOrigProc, hWnd, uMsg, wParam, lParam);
    case WM_CLOSE:
      //stop playing and unhook the message thread
      SendMessage(hWnd, WM_COMMAND, 40047, 0);
      //now close winamp
      PostMessage(hWnd, WM_COMMAND, 40001, 0);
      return(0);
  }
  return CallWindowProc(pOrigProc, hWnd, uMsg, wParam, lParam);
}

In_Module mod = 
{
  IN_VER,
  "Meridian GBS Player v0.3.1",


  0,
  0,
  "GBS\0Gameboy Sound File (*.GBS)\0",

  0,
  1,
  gbConfig,
  gbAbout,
  gbInit,
  gbQuit,
  gbGetFileInfo,
  gbInfoDlg,
  gbIsOurFile,
  gbPlay,
  gbPause,
  gbUnpause,
  gbIsPaused,
  gbStop,
  
  gbGetLength,
  gbGetOutputTime,
  gbSetOutputTime,

  gbSetVolume,
  gbSetPan,

  0,0,0,0,0,0,0,0,0,

  0,0,

  gbEqSet,

  NULL,

  0
};

__declspec( dllexport ) In_Module * winampGetInModule2()
{
  return &mod;
}
