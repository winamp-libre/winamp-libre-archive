#undef Log_x86Code
#define CPU_Message