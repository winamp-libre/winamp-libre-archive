extern BOOL ConditionalMove;
extern BOOL ShowErrors;
extern DWORD CPUCore;

extern HANDLE hMutex;

#define InterpreterCPU	0
#define RecompilerCPU	1

#define RSPOpcodeName(x1,x2) NULL