//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDHELPBUTTON                    3
#define IDD_INFO_WINDOW                 101
#define IDD_CONFIG_WINDOW               102
#define IDD_RAWTAG_WINDOW               103
#define IDD_ABOUTBOX                    107
#define IDB_64THLOGO                    110
#define IDD_HELPBOX                     119
#define IDC_TITLE                       1001
#define IDC_ARTIST                      1002
#define IDC_GAME                        1003
#define IDC_YEAR                        1004
#define IDC_COPYRIGHT                   1005
#define IDC_LENGTH                      1006
#define IDC_FADE                        1007
#define IDC_TRACK                       1008
#define IDC_USFBY                       1009
#define IDC_AUDIOHLE                    1009
#define IDC_FASTSEEK                    1010
#define IDC_COMMENT                     1010
#define IDC_DISABLECOUNT                1011
#define IDC_GENRE                       1011
#define IDC_TITLEFMT                    1012
#define IDC_TAGGER                      1012
#define IDC_VIEWRAW                     1013
#define IDC_LAUNCHCONFIG                1014
#define IDC_RAWTAG                      1015
#define IDC_NOLENGTH                    1016
#define IDC_DETSIL                      1017
#define IDC_RECOMPILER                  1018
#define IDC_REVERB                      1019
#define IDC_CANCEL                      1020
#define IDC_NOWBUT                      1021
#define IDC_DETSILVAL                   1023
#define IDC_DEFLEN                      1026
#define IDC_DEFLENVAL                   1027
#define IDC_DEFFADEVAL                  1028
#define IDC_PRISLIDER                   1036
#define IDC_CPUPRI                      1039
#define IDC_FILENAME                    1042
#define IDC_RELVOL                      1043
#define IDC_VOLUME                      1045
#define IDC_SECTIONS                    1047
#define IDC_SOFTAMP                     1049
#define IDC_FNONMISSINGTAG              1050
#define IDC_ROUNDFREQ                   1051
#define IDC_RICHEDIT1                   1052
#define IDC_SETLEN                      1054
#define IDC_DISPERROR                   1056
#define IDC_BACKWARDS                   1057
#define IDC_HELPTEXT                    1061
#define IDC_FADETYPE                    1066
#define IDC_ABOUT                       1067
#define IDC_AUTOAUDIOHLE                1069
#define IDC_CHECK1                      1075
#define IDC_TITLEGAME                   1075

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        120
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1076
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
