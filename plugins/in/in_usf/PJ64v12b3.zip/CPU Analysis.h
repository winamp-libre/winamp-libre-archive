int DelaySlotEffectsCompare (DWORD PC, DWORD Reg1, DWORD Reg2);
