1) Build mplayer.dll:

Unpack MPlayer's source code from http://www.mplayerhq.hu/ into a temporary folder,
then copy the files from mplayersrc\ into it. Then run "conf" and type "make", it'll
build mplayer.dll that you need to copy into the winamp plugins folder.

2) Build in_mplayer.dll:

Launch in_mplayer.dsw (into Visual C++ 6.0) then do "Build", it'll generate
C:\Program Files\Winamp\Plugins\in_mplayer.dll

