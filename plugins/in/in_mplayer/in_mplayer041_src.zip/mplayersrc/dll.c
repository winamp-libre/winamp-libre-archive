#include <stdarg.h>
#include <windows.h>

#include "cpudetect.h"
#include "version.h"

extern int parse_codec_cfg(char *cfgfile);
extern void * open_stream(char* filename,char** options,int* file_format); 
extern void * demux_open(void *stream,int file_format,int aid,int vid,int sid,char* filename);
extern int init_best_audio_codec(void *sh_audio,char** audio_codec_list,char** audio_fm_list); 
extern int init_best_video_codec(void *sh_video,char** video_codec_list,char** video_fm_list);
extern void *init_best_video_out(char** vo_list); 
extern int video_read_properties(void *sh_video); 
extern int demux_info_print(void *demuxer); 
extern int video_read_frame(void * sh_video,float* frame_time_ptr,unsigned char** start,int force_fps); 
extern int decode_video(void *sh_video,unsigned char *start,int in_size,int drop_frame); 
extern int decode_audio(void *sh_audio,unsigned char *buf,int minlen,int maxlen); 
extern void* vf_open_filter(void* next, char *name, char **args); 
extern void* append_filters(void* last); 
unsigned long demuxer_get_time_length(void *demuxer);   
extern void uninit_audio(void *sh_audio); 
extern void uninit_video(void *sh_video); 
extern void free_demuxer(void *demuxer); 
extern int demux_seek(void *demuxer,float rel_seek_secs,int flags); 
extern void free_stream(void *s); 
extern int divx_quality;
extern char* dvd_device; 
extern int dvd_chapter, dvd_last_chapter, dvd_angle; 
extern int stream_enable_cache(void *stream,int size,int min,int prefill);

__declspec(dllexport) void exp_init()
{
  GetCpuCaps(&gCpuCaps);
}

__declspec(dllexport) int exp_parse_codec_cfg(char *cfgfile)
{
return parse_codec_cfg(cfgfile);
}

__declspec(dllexport) void *exp_open_stream(char* filename,char** options,int* file_format)
{
return open_stream(filename,options,file_format);
}

__declspec(dllexport) void *exp_demux_open(void *stream,int file_format,int aid,int vid,int sid,char* filename)
{
return demux_open(stream,file_format,aid,vid,sid,filename);
}

__declspec(dllexport) int exp_init_best_audio_codec(void *sh_audio,char** audio_codec_list,char** audio_fm_list)
{
return init_best_audio_codec(sh_audio,audio_codec_list,audio_fm_list); 
}

__declspec(dllexport) int exp_init_best_video_codec(void *sh_video,char** video_codec_list,char** video_fm_list)
{
return init_best_video_codec(sh_video,video_codec_list,video_fm_list); 
}

__declspec(dllexport) void *exp_init_best_video_out(char** vo_list)
{
return init_best_video_out(vo_list); 
}

__declspec(dllexport) int exp_video_read_properties(void *sh_video)
{
return video_read_properties(sh_video);
}

__declspec(dllexport) int exp_demux_info_print(void *demuxer)
{
return demux_info_print(demuxer);
}

__declspec(dllexport) int exp_video_read_frame(void * sh_video,float* frame_time_ptr,unsigned char** start,int force_fps)
{
return video_read_frame(sh_video,frame_time_ptr,start,force_fps); 
}

__declspec(dllexport) int exp_decode_video(void *sh_video,unsigned char *start,int in_size,int drop_frame)
{
return decode_video(sh_video,start,in_size,drop_frame);
}

__declspec(dllexport) int exp_decode_audio(void *sh_audio,unsigned char *buf,int minlen,int maxlen)
{
return decode_audio(sh_audio,buf,minlen,maxlen);
}

__declspec(dllexport) void *exp_vf_open_filter(void* next, char *name, char **args)
{
return vf_open_filter(next,name,args);
}

__declspec(dllexport) void *exp_append_filters(void* last)
{
return append_filters(last);
}

__declspec(dllexport) unsigned long exp_demuxer_get_time_length(void* demuxer)
{
return demuxer_get_time_length(demuxer);
}

__declspec(dllexport) void exp_uninit_audio(void* sh_audio)
{
uninit_audio(sh_audio);
}

__declspec(dllexport) void exp_uninit_video(void* sh_video)
{
uninit_video(sh_video);
}

__declspec(dllexport) void exp_free_demuxer(void* d)
{
free_demuxer(d);
}

__declspec(dllexport) int exp_demux_seek(void *demuxer,float rel_seek_secs,int flags)
{
return demux_seek(demuxer,rel_seek_secs,flags); 
}

__declspec(dllexport) void exp_free_stream(void* s)
{
free_stream(s);
}

__declspec(dllexport) void exp_set_pp(int q) //0...6   0=disabled  6=max
{
divx_quality=q;
}

__declspec(dllexport) void exp_set_dvd_device(char *dvd)
{
static char dev[MAX_PATH];
strcpy(dev,dvd);
dvd_device=dev;
}

__declspec(dllexport) void exp_set_dvd_chapter(int chapter, int last_chapter, int angle)
{
dvd_chapter=chapter;
dvd_last_chapter=last_chapter;
dvd_angle=angle;
}

__declspec(dllexport) int exp_stream_enable_cache(void *stream,int size,int min,int prefill)
{
return stream_enable_cache(stream,size,min,prefill);
}

__declspec(dllexport) char *exp_get_version()
{
return VERSION;
}

//mp_msg stuff
void mp_msg_init()
{
}

void mp_msg_set_level(int verbose)
{
}

char *dbgbuf=NULL;
int allocbuf=0;

void mp_msg_c( int x, const char *format, ... )
{
  va_list va;

  if((x&255)>5) return;

  va_start(va, format);
  char tmp[4096];
  vsprintf(tmp,format,va);

  OutputDebugString(tmp);
  
  int l=strlen(tmp);
  if(l && tmp[l-1]==0x0a)
	{
	  strcpy(tmp+l-1,"\r\n");
	}

  if(dbgbuf==NULL)
	{
	  dbgbuf=(char *)malloc(4096);
	  dbgbuf[0]=0;
	  allocbuf=4096;
	}

  while((strlen(dbgbuf)+strlen(tmp)+1)>allocbuf)
	{
	  allocbuf*=2;
	  dbgbuf=realloc(dbgbuf,allocbuf);
	}

  strcpy(dbgbuf+strlen(dbgbuf),tmp);

  va_end(va);
}

__declspec(dllexport) char * exp_get_dbgtext()
{
return dbgbuf;
}

__declspec(dllexport) void exp_reset_dbgtext()
{
free(dbgbuf);
dbgbuf=NULL;
allocbuf=0;
}