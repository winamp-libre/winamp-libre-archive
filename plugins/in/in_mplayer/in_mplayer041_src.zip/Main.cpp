#include <windows.h>
#include <stdio.h>
#include <stdarg.h> 
#include <math.h>
#include <float.h>
#include <commctrl.h>

#include "resource.h"

#include "in2.h"

extern In_Module mod;			// the output module (filled in near the bottom of this file)
static char m_ini[MAX_PATH];

char m_extlist[512]="MPG;MPEG;M2V;AVI;ASF;WMV;VOB";

#define WM_WA_IPC WM_USER

#define WM_WA_MPEG_EOF WM_USER+2 
#define IPC_GETINIFILE 334
#define IPC_GET_IVIDEOOUTPUT 500
#define VIDEO_MAKETYPE(A,B,C,D) ((A) | ((B)<<8) | ((C)<<16) | ((D)<<24))
#define VIDUSER_SET_INFOSTRING 0x1000

static DWORD WINAPI playProc(LPVOID lpParameter);

extern "C" {

typedef long off_t; 

typedef int stream_t;

#include "mplayer/codec-cfg.h"
#include "mplayer/demuxer.h"
#include "mplayer/stheader.h"
#include "mplayer/video_out.h"
#include "mplayer/mp_image.h"
#include "mplayer/vfcap.h"

};

void about(HWND hwndParent)
{
	MessageBox(hwndParent,"MPlayer Video Decoder (c) 2003 MPlayer","About MPlayer Video Decoder",MB_OK);
}

//  extern "C" void init_layer3(int down_sample_sblimit);
//void (*init_layer3)(int down);

void (*exp_init)(); 
int (*exp_parse_codec_cfg)(char *cfgfile);
stream_t *(*exp_open_stream)(char* filename,char** options,int* file_format); 
demuxer_t* (*exp_demux_open)(stream_t *stream,int file_format,int aid,int vid,int sid,char* filename);
int (*exp_init_best_audio_codec)(sh_audio_t *sh_audio,char** audio_codec_list,char** audio_fm_list); 
int (*exp_init_best_video_codec)(sh_video_t *sh_video,char** video_codec_list,char** video_fm_list);
vo_functions_s *(*exp_init_best_video_out)(char** vo_list); 
int (*exp_video_read_properties)(void *sh_video); 
int (*exp_demux_info_print)(demuxer_t *demuxer); 
int (*exp_video_read_frame)(sh_video_t* sh_video,float* frame_time_ptr,unsigned char** start,int force_fps); 
int (*exp_decode_video)(sh_video_t *sh_video,unsigned char *start,int in_size,int drop_frame); 
int (*exp_decode_audio)(sh_audio_t *sh_audio,unsigned char *buf,int minlen,int maxlen); 
void* (*exp_vf_open_filter)(void* next, char *name, char **args); 
void* (*exp_append_filters)(void* last); 
unsigned long (*exp_demuxer_get_time_length)(demuxer_t *demuxer);
void (*exp_uninit_audio)(sh_audio_t *sh_audio); 
void (*exp_uninit_video)(sh_video_t *sh_video); 
void (*exp_free_demuxer)(demuxer_t *demuxer); 
int (*exp_demux_seek)(demuxer_t *demuxer,float rel_seek_secs,int flags); 
void (*exp_free_stream)(stream_t *s); 
char * (*exp_get_dbgtext)();
void (*exp_reset_dbgtext)();
void (*exp_set_pp)(int q); //0...6   0=disabled  6=max
void (*exp_set_dvd_device)(char *dvd);
void (*exp_set_dvd_chapter)(int chapter, int last_chapter, int angle);
void (*exp_stream_enable_cache)(void *stream,int size,int min,int prefill);
char * (*exp_get_version)();

HMODULE m_mplayer_mod;

void init() 
{
  char path[MAX_PATH],fn[MAX_PATH];
  GetModuleFileName(mod.hDllInstance,path,sizeof(path));
	char *p=path+strlen(path);
	while (*p != '\\' && p >= path) p--;
  *p=0;
  wsprintf(fn,"%s\\mplayer.dll",path);
  wsprintf(m_ini,"%s\\mplayer.ini",path);

  m_mplayer_mod=LoadLibrary(fn);
  if(!m_mplayer_mod) return;

#define DLLGET(n) *((void **)&exp_##n)=GetProcAddress(m_mplayer_mod,"exp_"#n); if(!exp_##n) failed=1;

  int failed=0;

  DLLGET(init)
  DLLGET(parse_codec_cfg)
  DLLGET(open_stream)
  DLLGET(demux_open)
  DLLGET(init_best_audio_codec)
  DLLGET(init_best_video_codec)
  DLLGET(init_best_video_out)
  DLLGET(video_read_properties)
  DLLGET(demux_info_print)
  DLLGET(video_read_frame)
  DLLGET(decode_video);
  DLLGET(decode_audio);
  DLLGET(vf_open_filter);
  DLLGET(append_filters);
  DLLGET(demuxer_get_time_length);
  DLLGET(uninit_audio);
  DLLGET(uninit_video);
  DLLGET(free_demuxer);
  DLLGET(demux_seek);
  DLLGET(free_stream);
  DLLGET(get_dbgtext);
  DLLGET(reset_dbgtext);
  DLLGET(set_pp);
  DLLGET(set_dvd_device);
  DLLGET(set_dvd_chapter);
  DLLGET(stream_enable_cache);
  DLLGET(get_version);
  
  if(failed)
  {
    FreeLibrary(m_mplayer_mod);
    m_mplayer_mod=NULL;
    return;
  }
  
  exp_init();

  //parse_codec_cfg("codecs.conf");
  exp_parse_codec_cfg(NULL);

  //  vo_init_osd();

  GetPrivateProfileString("in_mplayer","extlist",m_extlist,m_extlist,sizeof(m_extlist)-1,m_ini);
}

void quit() { 
}

char *scanstr_back(char *str, char *toscan, char *defval)
{
	char *s=str+strlen(str)-1;
	if (strlen(str) < 1) return defval;
	if (strlen(toscan) < 1) return defval;
	while (1)
	{
		char *t=toscan;
		while (*t)
			if (*t++ == *s) return s;
		t=CharPrev(str,s);
		if (t==s) return defval;
		s=t;
	}
}

char *extension(char *fn) 
{
  char *s = scanstr_back(fn,".\\",fn-1);
  if (s < fn) return "";
  if (*s == '\\') return "";
  return (s+1);
}

int isourfile(char *fn) { 
  if(!strnicmp(fn,"dvd://",6)) return 1;
  if(GetPrivateProfileInt("in_mplayer","enable",1,m_ini))
  {
    char *ext=extension(fn);
    if(!ext[0]) return 0;
    char tmplist[512];
    strcpy(tmplist,m_extlist);
    char *p=tmplist;
    while(1)
    {
      char *p2=strstr(p,";");
      if(p2) *p2=0;
      if(!stricmp(ext,p)) return 1;
      if(!p2) break;
      p=p2+1;
    }
  }
  return 0;
}

int CALLBACK configProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch(uMsg)
  {
  case WM_INITDIALOG:
    SendMessage(GetDlgItem(hwndDlg,IDC_SLIDER1),TBM_SETRANGEMAX,0,6);
    SendMessage(GetDlgItem(hwndDlg,IDC_SLIDER1),TBM_SETRANGEMIN,0,0);
		SendMessage(GetDlgItem(hwndDlg,IDC_SLIDER1),TBM_SETPOS,1,GetPrivateProfileInt("in_mplayer","pp",0,m_ini));
    {
      char tmp[512];
      GetPrivateProfileString("in_mplayer","cache","0",tmp,sizeof(tmp)-1,m_ini);
      SetDlgItemText(hwndDlg,IDC_CACHE,tmp);
      GetPrivateProfileString("in_mplayer","cachedvd","1024",tmp,sizeof(tmp)-1,m_ini);
      SetDlgItemText(hwndDlg,IDC_DVDCACHE,tmp);
      SetDlgItemText(hwndDlg,IDC_EXT,m_extlist);
    }
    CheckDlgButton(hwndDlg,IDC_DEINT,GetPrivateProfileInt("in_mplayer","deint",0,m_ini));
    CheckDlgButton(hwndDlg,IDC_ENABLE,GetPrivateProfileInt("in_mplayer","enable",1,m_ini));
    break;
  case WM_COMMAND:
    switch(LOWORD(wParam))
    {
    case IDOK:
      {
        char tmp[32];
        wsprintf(tmp,"%d",SendDlgItemMessage(hwndDlg,IDC_SLIDER1,TBM_GETPOS,0,0));
        WritePrivateProfileString("in_mplayer","pp",tmp,m_ini);
        GetDlgItemText(hwndDlg,IDC_CACHE,tmp,sizeof(tmp)-1);
        WritePrivateProfileString("in_mplayer","cache",tmp,m_ini);
        GetDlgItemText(hwndDlg,IDC_DVDCACHE,tmp,sizeof(tmp)-1);
        WritePrivateProfileString("in_mplayer","cachedvd",tmp,m_ini);
        wsprintf(tmp,"%d",IsDlgButtonChecked(hwndDlg,IDC_DEINT));
        WritePrivateProfileString("in_mplayer","deint",tmp,m_ini);
        wsprintf(tmp,"%d",IsDlgButtonChecked(hwndDlg,IDC_ENABLE));
        WritePrivateProfileString("in_mplayer","enable",tmp,m_ini);
        GetDlgItemText(hwndDlg,IDC_EXT,m_extlist,sizeof(m_extlist)-1);
        WritePrivateProfileString("in_mplayer","extlist",m_extlist,m_ini);
      }
    case IDCANCEL:
      EndDialog(hwndDlg,0);
      break;
     }
    break;
  }
  return FALSE;
}

void config(HWND hwndParent)
{
  DialogBox(mod.hDllInstance,MAKEINTRESOURCE(IDD_CONFIG),hwndParent,configProc);
}

static stream_t *m_stream=NULL; 
static demuxer_t *m_demuxer=NULL;

static demux_stream_t *d_video=NULL; 
static demux_stream_t *d_audio=NULL; 

static sh_audio_t *sh_audio=NULL; 
static sh_video_t *sh_video=NULL; 

char **audio_codec_list=NULL; // override audio codec
char **video_codec_list=NULL; // override video codec 
char **audio_fm_list=NULL;    // override audio codec family 
char **video_fm_list=NULL;    // override video codec family 
char** video_driver_list=NULL; 

vo_functions_t *video_out=NULL; 

int m_length, m_kill, m_needseek, paused;

HANDLE hThread;

char lastfn[MAX_PATH];	// currently playing file (used for getting info on the current file)

static char m_buf[65536];
static int m_inbuf;

static DWORD m_audio_time; //for audioless videos

class IVideoOutput
{
  public:
    virtual ~IVideoOutput() { }
    virtual int open(int w, int h, int vflip, double aspectratio, unsigned int fmt)=0;
    virtual void setcallback(LRESULT (*msgcallback)(void *token, HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam), void *token) { }
    virtual void close()=0;
    virtual void draw(void *frame)=0;
    virtual void drawSubtitle(/*SubsItem **/ void *item) { }
    virtual void showStatusMsg(const char *text) { }
    virtual int get_latency() { return 0; }
    virtual void notifyBufferState(int bufferstate) { } /* 0-255*/

    virtual int extended(int param1, int param2, int param3) { return 0; } // Dispatchable, eat this!
};

typedef	struct {
  unsigned char*	baseAddr;
	long			rowBytes;
} YV12_PLANE;

typedef	struct {
	YV12_PLANE	y;
	YV12_PLANE	u;
	YV12_PLANE	v;
} YV12_PLANES;

static IVideoOutput *m_video_output=NULL;
int video_mediatype, video_w, video_h;

static uint32_t vo_preinit(const char *arg)
{ 
  return 0;
}

static uint32_t vo_config(uint32_t width, uint32_t height, uint32_t d_width, uint32_t d_height, uint32_t options, char *title, uint32_t format)
{ 
  double aspect=((double)width/(double)d_width) / ((double)height/(double)d_height);

  video_mediatype=format;
  video_w=width;
  video_h=height;
  m_video_output->open(width,height,0,aspect,video_mediatype);

  {
    char text[512];
    sprintf(text,"MPlayer: Video:%s,%dx%d@%5.2ffps (%dkbps)",sh_video->codec->name,video_w,video_h,sh_video->fps,(sh_video->i_bps*8)/1000);
    if(sh_audio)
    {
      sprintf(text+strlen(text)," Audio:%s,%dkhz,%dbps,%dch (%dkbps)",sh_audio->codec->name,sh_audio->samplerate/1000,sh_audio->sample_format,sh_audio->channels,(sh_audio->i_bps*8)/1000);
    }
    m_video_output->extended(VIDUSER_SET_INFOSTRING,(int)text,0);
  }

  return 0;
}

static uint32_t vo_control(uint32_t request, void *data, ...)
{ 
  switch(request)
  {
    case VOCTRL_QUERY_FORMAT:
      {
        uint32_t type=*((uint32_t*)data);
        //FUCKO: needs to ask winamp what it can display
        if(type==VIDEO_MAKETYPE('Y','V','1','2') ||
           type==VIDEO_MAKETYPE('Y','U','Y','2'))
          return VFCAP_CSP_SUPPORTED |VFCAP_OSD |VFCAP_CSP_SUPPORTED_BY_HW | VFCAP_HWSCALE_UP;
      }
      return 0; 
    case VOCTRL_DRAW_IMAGE:
      {
        mp_image_t *mpi=(mp_image_t *)data;
        uint32_t w = mpi->w;
	      uint32_t h = mpi->h;
        unsigned short f=mpi->flags;

        //char tmp[512];
        //wsprintf(tmp,"DirectFB: Put_image entered %i %i %i %i %i %i\n",mpi->x,mpi->y,mpi->w,mpi->h,mpi->width,mpi->height); 
        //OutputDebugString(tmp);
        //if(!(f&MP_IMGFLAG_READABLE)) return VO_TRUE;

/*          if((mpi->flags&(MP_IMGFLAG_DIRECT|MP_IMGFLAG_DRAW_CALLBACK))) {
//        if (verbose) printf("DirectFB: Put_image - nothing todo\n");
	return VO_TRUE;
    } */
        
        if(video_mediatype==VIDEO_MAKETYPE('Y','V','1','2')) {
            // YV12 needs to pass a YV12_PLANES structure.
            static YV12_PLANES yv12planes;
            yv12planes.y.baseAddr=(unsigned char *)mpi->planes[0];
            yv12planes.y.rowBytes=w;
            yv12planes.v.baseAddr=(unsigned char *)mpi->planes[2];
            yv12planes.v.rowBytes=w/2;
            yv12planes.u.baseAddr=(unsigned char *)mpi->planes[1];
            yv12planes.u.rowBytes=w/2;
            m_video_output->draw((void *)&yv12planes);
        } else {
          m_video_output->draw((void *)mpi->planes[0]);
        }
        return VO_TRUE;
      }
      break;
  }
  return VO_NOTIMPL;
}

static uint32_t vo_draw_frame(uint8_t *src[])
{
  	//memcpy( image, *src, dstride * image_height );
	return 0;
} 

static uint32_t vo_draw_slice(uint8_t *src[], int stride[], int w,int h,int x,int y )
{ 
  //FUCKO
  return 0;
}

static void vo_draw_osd(void)
{ 
}

static void vo_flip_page(void)
{ 
  //FUCKO
}

static void vo_check_events(void)
{ 
}

static void vo_uninit(void)
{ 
  if(m_video_output) m_video_output->close();
}

static vo_info_t vo_info =
{
	"Winamp renderer",
	"winamp",
	"Nullsoft",
	""
}; 

vo_functions_t myVideoOut={
  &vo_info,
	vo_preinit,
	vo_config,
	vo_control,
	vo_draw_frame,
	vo_draw_slice,
  vo_draw_osd,
	vo_flip_page,
	vo_check_events,
	vo_uninit     
};

int play(char *fn) 
{
  if(!m_mplayer_mod) return 1;

  m_stream=NULL;
  m_demuxer=NULL;
  m_kill=0;
  m_needseek=-1;
  exp_reset_dbgtext();
  exp_set_pp(GetPrivateProfileInt("in_mplayer","pp",0,m_ini));

  m_video_output=(IVideoOutput *)SendMessage(mod.hMainWindow,WM_USER,0,IPC_GET_IVIDEOOUTPUT);
  if(!m_video_output) 
  {
    return 1;
  }

  int file_format=0;//DEMUXER_TYPE_UNKNOWN; 

  int is_dvd=0;

  if(!strnicmp(fn,"dvd://",6))
  {
    static char tmp[64];
    wsprintf(tmp,"%c:/",fn[6]);
    exp_set_dvd_device(tmp);
    exp_set_dvd_chapter(1,0,1);
    wsprintf(tmp,"dvd://%s",fn+8);
    m_stream=exp_open_stream(tmp,0,&file_format); 
    is_dvd=1;
  }
  else
    m_stream=exp_open_stream(fn,0,&file_format); 
  if(!m_stream) return 1;

  int stream_cache_size=GetPrivateProfileInt("in_mplayer","cache",0,m_ini);
  if(is_dvd) stream_cache_size=GetPrivateProfileInt("in_mplayer","cachedvd",1024,m_ini);
  if(stream_cache_size)
    exp_stream_enable_cache(m_stream,stream_cache_size*1024,stream_cache_size*1024/5,stream_cache_size*1024/20);

  int audio_id=-1; //128;//-1;
  int video_id=-1;
  int dvdsub_id=-1; 

  m_demuxer=exp_demux_open(m_stream,file_format,audio_id,video_id,dvdsub_id,fn); 
  if(!m_demuxer)
  {
    exp_free_stream(m_stream);
    m_stream=NULL;
    return 1;
  }

  d_audio=m_demuxer->audio; 
  d_video=m_demuxer->video;
  sh_audio=(sh_audio_t *)d_audio->sh; 
  sh_video=(sh_video_t *)d_video->sh; 
  
  if(sh_video)
  {
    if(!exp_video_read_properties(sh_video)) 
    {
      sh_video=NULL;
      d_video->sh=NULL;
    }
  }

  exp_demux_info_print(m_demuxer);

  if(sh_audio && !exp_init_best_audio_codec(sh_audio,audio_codec_list,audio_fm_list))
  {
    sh_audio=NULL;
    d_audio->sh=NULL; // failed to init :(
  }

  m_length=exp_demuxer_get_time_length(m_demuxer);
  if(m_length<=0)
  {
    if(sh_video && !sh_video->i_bps) //VBR, get some average bitrate by reading the first few video frames
    {
      int b=0;
      for(int i=0;i<32;i++)
      {
        unsigned char* start=NULL; 
        float force_fps=0; 
        float frame_time=0; 
        float next_frame_time=0; 
        b+=exp_video_read_frame(sh_video,&next_frame_time,&start,(int)force_fps);
      }
      b/=(double)sh_video->num_frames_decoded*sh_video->frametime;
      sh_video->i_bps=b;//*8/1000;
      m_length=exp_demuxer_get_time_length(m_demuxer);
      exp_demux_seek(m_demuxer,0,1);
    } 
    else if(sh_video)
    {
      unsigned int e=(unsigned int)m_demuxer->movi_end;
      unsigned int s=(unsigned int)m_demuxer->movi_start;
      unsigned int l=(e-s)/sh_video->i_bps; 
      m_length=l;
    }
  }

  /*if(!(video_out=exp_init_best_video_out(video_driver_list)))
  {
    return 1; //FUCKO:close stuff
  } */
  video_out=&myVideoOut;

  d_video->sh=NULL;
  if(sh_video)
  {
    sh_video->video_out=video_out; 
    
    {
      char* vf_arg[] = { "_oldargs_", (char*)video_out , NULL };
      sh_video->vfilter=(void*)exp_vf_open_filter(NULL,"vo",vf_arg);
    } 
    
    if(GetPrivateProfileInt("in_mplayer","deint",0,m_ini))
    {
      char *param[]={"_oldargs_","lb",NULL};
      sh_video->vfilter=exp_vf_open_filter(sh_video->vfilter,"pp",param);
    }
    sh_video->vfilter=(void*)exp_append_filters(sh_video->vfilter); 
    
    exp_init_best_video_codec(sh_video,video_codec_list,video_fm_list); 
    
    if(!sh_video->inited)
    {
      if(!sh_audio) return 1; //FUCKO: close stuff
      sh_video = NULL;
      d_video->sh = NULL; 
    }
  }

  if(sh_audio)
  {
    //open audio
    int maxlat=mod.outMod->Open(sh_audio->samplerate,sh_audio->channels,sh_audio->sample_format,-1,-1);
    if(maxlat<0) 
    {
      //FUCKO: close stuff
      return 1;
    }
    int audio_srate=sh_audio->samplerate;
    int audio_nch=sh_audio->channels;
    int bitrate=((sh_video?sh_video->i_bps*8:0)+sh_audio->i_bps*8)/1000;
    mod.SetInfo(bitrate,audio_srate/1000,audio_nch,1);
	  mod.SAVSAInit(maxlat,audio_srate);
	  mod.VSASetInfo(audio_srate,audio_nch);
    mod.outMod->SetVolume(-666); 
  }

  strcpy(lastfn,fn);

  m_inbuf=0;
  m_audio_time=0;

  DWORD thread_id;
  hThread=CreateThread(NULL,NULL,&playProc,(LPVOID)NULL,NULL,&thread_id);
  return 0;
}

static DWORD WINAPI playProc(LPVOID lpParameter)
{
  int eof=0;
  float next_frame_time=0; 
  int nbdecfr=0;
  float lastseek=0;

  while(!m_kill)
  {
    if(m_needseek!=-1)
    {
      float t=((float)m_needseek)/1000;
      if(exp_demux_seek(m_demuxer,t,1))
      {
        if(sh_video) sh_video->pts=d_video->pts; 
        mod.outMod->Flush(m_needseek);
        if(sh_video) sh_video->timer=t;
        lastseek=t;
        nbdecfr=0;
        m_inbuf=0;
        m_needseek=-1;
        if(!sh_audio) m_audio_time=GetTickCount()-m_needseek;
      }
    }

    //decode & buffer audio

    if(sh_audio)
    {
      while(mod.outMod->CanWrite())
      {
        if(!m_inbuf)
        {
          int ret=exp_decode_audio(sh_audio,(unsigned char *)&m_buf,1024,sizeof(m_buf));
          if(ret<=0)
          {
            eof=1;
            break;
          }
          m_inbuf+=ret;
        }
        int l=min(m_inbuf,mod.outMod->CanWrite());
        if(l)
        {
          int audio_nch=sh_audio->channels;
          int audio_bps=sh_audio->sample_format;
          int decode_pos_ms=mod.outMod->GetWrittenTime();
          mod.SAAddPCMData(m_buf,audio_nch,audio_bps,decode_pos_ms);	
          mod.VSAAddPCMData(m_buf,audio_nch,audio_bps,decode_pos_ms);
          mod.outMod->Write(m_buf,l);
          m_inbuf-=l;
          if(m_inbuf) memcpy(m_buf,m_buf+l,m_inbuf);
        }
      }
    }
    else
    {
      //audioless
      if(!m_audio_time) m_audio_time=GetTickCount();
    }
    if(eof) break;

    int blit_frame=0; 

    //decode video
    if(sh_video)
    {
      unsigned char* start=NULL; 
      float force_fps=0; 
      float frame_time=next_frame_time; 
      int in_size=exp_video_read_frame(sh_video,&next_frame_time,&start,(int)force_fps);
      float towait=sh_video->timer;
      sh_video->timer+=frame_time; 
      if(in_size<0)
      { 
        eof=1; 
        break; 
      }
      
      int drop_frame=0;     // current dropping status 
      blit_frame=exp_decode_video(sh_video,start,in_size,drop_frame); 
      
      //fix for desync
      towait=(float)(nbdecfr++)*sh_video->frametime;
      towait+=lastseek;
      
      //if(blit_frame)
      {
        if(sh_audio)
        {
          while(mod.outMod->GetOutputTime()<(towait*1000) && !m_kill && m_needseek==-1) Sleep(1);
        }
        else
        {
          while((GetTickCount()-m_audio_time)<(towait*1000) && !m_kill && m_needseek==-1) Sleep(1);
        }
      }
    }
    else
    {
      //no video but audio
      while(!mod.outMod->CanWrite()) Sleep(1);
    }
  }
  if(eof)
  {
    PostMessage(mod.hMainWindow,WM_WA_MPEG_EOF,0,0);
  }
  return 0;
}

void pause() 
{ 
  paused=1;
  mod.outMod->Pause(1);
}

void unpause() 
{ 
  paused=0;
  mod.outMod->Pause(0); 
}

int ispaused() 
{ 
  return paused; 
}

void stop()
{
  m_kill=1;
  WaitForSingleObject(hThread,3000);

  mod.outMod->Close();
  
  stream_t *stream=NULL;
  if(sh_audio) exp_uninit_audio(sh_audio);
  sh_audio=NULL; 
  if(sh_video) exp_uninit_video(sh_video);
  sh_video=NULL; 
  if(m_demuxer){
	  stream=m_demuxer->stream;
	  exp_free_demuxer(m_demuxer);
  }
  m_demuxer=NULL;
  if(stream) exp_free_stream(stream);
  stream=NULL; 
  if(video_out)
  {
    video_out->uninit();
    video_out=NULL;
    /*
    //eat postquitmessage
    MSG msg;
    while (GetMessage(&msg,NULL,0,0)) 
	  {
      DispatchMessage(&msg);
    }
    */
  }
}

int getlength() 
{
  return m_length*1000;
}

int getoutputtime() 
{
  if(sh_audio) return mod.outMod->GetOutputTime();
  if(m_audio_time) return GetTickCount()-m_audio_time;
  return 0;
}

void setoutputtime(int time_in_ms) 
{
  m_needseek=time_in_ms;
}

void setvolume(int volume) { mod.outMod->SetVolume(volume); }
void setpan(int pan) { mod.outMod->SetPan(pan); }

int CALLBACK infoProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  switch(uMsg)
  {
  case WM_INITDIALOG:
    SetWindowText(hwndDlg,lastfn);
    {
      char text[65536];
      wsprintf(text,"MPlayer version: %s\r\n\r\n%s",exp_get_version(),exp_get_dbgtext());
      SetDlgItemText(hwndDlg,IDC_EDIT1,text);
    }
    SetFocus(hwndDlg);
    break;
  case WM_COMMAND:
    switch(LOWORD(wParam))
    {
    case IDOK:
    case IDCANCEL:
      EndDialog(hwndDlg,0);
      break;
     }
    break;
  }
  return FALSE;
}

int infoDlg(char *fn, HWND hwnd)
{
  static int running=0;
  if(running) return 0;
  running=1;
  if(!strcmp(fn,lastfn))
  {
    DialogBox(mod.hDllInstance,MAKEINTRESOURCE(IDD_INFO),hwnd,infoProc);
  }
  running=0;
  return 0;
}

void getfileinfo(char *filename, char *title, int *length_in_ms)
{
	if (!filename || !*filename)  // currently playing file
	{
		if (length_in_ms) *length_in_ms=getlength();
		if (title) // get non-path portion.of filename
		{
			char *p=lastfn+strlen(lastfn);
			while (*p != '\\' && p >= lastfn) p--;
      p++;

/*      if (lastfn_status[0])
      {
        char buf[4096];
        wsprintf(buf,"[%s] %s",lastfn_status,p);
        strncpy(title,buf,255);
      } else */
      {
        strcpy(title,p);
      }
		}
  }
  else // some other file
	{
		if (length_in_ms) // calculate length
		{
      *length_in_ms=-1000; // the default is unknown file length (-1000).
    }
    if (title) // get non path portion of filename
		{
			char *p=filename+strlen(filename);
			while (*p != '\\' && p >= filename) p--;
			strcpy(title,++p);
		}
	}
}

void eq_set(int on, char data[10], int preamp) 
{ 
}

// module definition.

In_Module mod = 
{
	IN_VER,	// defined in IN2.H
	"MPlayer Video Decoder v0.41"
	,
	0,	// hMainWindow (filled in by winamp)
	0,  // hDllInstance (filled in by winamp)
	"MPG;MPEG;M2V\0MPG File (*.MPG;*.MPEG;*.M2V)\0"
	"AVI\0AVI File (*.AVI)\0"
	"ASF;WMV\0ASF/WMV File (*.ASF;*.WMV)\0"
  "VOB\0VOB File (*.VOB)\0"
	// this is a double-null limited list. "EXT\0Description\0EXT\0Description\0" etc.
	,
	1,	// is_seekable
	1,	// uses output plug-in system
	config,
	about,
	init,
	quit,
	getfileinfo,
	infoDlg,
	isourfile,
	play,
	pause,
	unpause,
	ispaused,
	stop,
	
	getlength,
	getoutputtime,
	setoutputtime,

	setvolume,
	setpan,

	0,0,0,0,0,0,0,0,0, // visualization calls filled in by winamp

	0,0, // dsp calls filled in by winamp

	eq_set,

	NULL,		// setinfo call filled in by winamp

	0 // out_mod filled in by winamp
};

extern "C" {

__declspec( dllexport ) In_Module * winampGetInModule2()
{
	return &mod;
}

}