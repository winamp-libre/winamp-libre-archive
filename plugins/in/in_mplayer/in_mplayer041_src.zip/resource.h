//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by in_mplayer.rc
//
#define IDD_INFO                        101
#define IDD_CONFIG                      102
#define IDC_EDIT1                       1000
#define IDC_CHECK2                      1002
#define IDC_DEINT                       1002
#define IDC_SLIDER1                     1003
#define IDC_DVDCACHE                    1005
#define IDC_CACHE                       1006
#define IDC_ENABLE                      1007
#define IDC_EXT                         1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
