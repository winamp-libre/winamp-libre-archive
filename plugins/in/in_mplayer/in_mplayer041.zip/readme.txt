IN_MPLAYER v0.41 - MPlayer decoding for Winamp 2.9x/5.x
----------------

1) About

This plugin plays avi, mpeg 1-2, vob (dvds), asf, wmv, etc...

To play dvd's, use dvd://[drive letter],[title] like dvd://G,1
(Very experimental tho, someone please fix it :)

This version is using mplayer 1.0pre4.

2) Copyright

in_mplayer code (c) 2004 Christophe Thibault (http://inmplayer.sourceforge.net/)
MPlayer code (c) The MPlayer team (http://www.mplayerhq.hu/)

This program is released under the GPL license. Read the LICENSE file for more
information.

3) Installation

-Close Winamp
-Extract the zip into your Winamp plugins folder 
 (Usually C:\Program Files\Winamp\Plugins)
-Launch Winamp and configure the plugin in 
  Options->Preferences->Plug-ins->Input->MPlayer Video Decoder
-Enjoy!
