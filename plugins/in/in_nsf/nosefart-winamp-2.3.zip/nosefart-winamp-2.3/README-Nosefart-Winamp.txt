INSTALLATION

To install the plugin, put in_nsf.dll in your Winamp plugins folder
(probably something like C:\Program Files\Winamp\Plugins\) and restart 
Winamp.  It should work with Winamp 2.x and 5.x.


COMPILING

The plugin can be compiled with at least Microsoft Visual C++ 6 and probably
open source tools as well.  If you got just this file and the DLL, you can
download the source from http://sf.net/projects/nosefart


**************************************************************************

Below is Matt Conte's original readme file for the Winamp plugin.

**************************************************************************

                        
			===========================
                        Nosefart Winamp Plugin 1.92
                        Powered by Shady Matt Conte
                        ===========================
                        =   http://nofrendo.org   =
                        ===========================

* NOTE: This file lives in your Winamp directory, should you need to
		peruse it in the future.


Recent History
==============
1.92 (07.04.00)
 - Code released under GNU GPL. Happy Independence Day.
 - Linux port, thanks to Neil Stevens
 - More authentic channel mixing
 - GPF bug fix
 - Speed optimizations

1.91 (06.19.00)
 - MMC5 sound
 - VRC7 sound, thanks to Charles MacDonald
 - APU fixes

1.90 (06.13.00)
 - Fixed playlist display
 - Removed trackbar, using native Winamp controls
 - The most accurate Nosefart ever!
 - Core optimizations/speedups/cleanups
 - More accurate NES channel emulation


Features
========
 - Cycle exact emulation of custom NES 6502 CPU
 - Extremely accurate NES audio hardware emulation
 - Konami VRC6 soundchip emulation
 - Konami VRC7 soundchip emulation
 - Nitendo MMC5 soundchip emulation
 - Braindead easy-to-use user interface
 - Andre Lamothe in his Blade outfit


Tell me
=======
Nosefart is an NSF plug-in for Winamp.  That means it is a plug-in
for Winamp which plays NSF files.

NSFs are files which contain the music code and data from NES games.
All that you need to accurately play the music tracks back are 
accurate 6502 and NES sound register emulation.

You can always get the latest version of Nosefart at:

	http://www.nofrendo.org

Winamp lives here:

	http://www.winamp.com

You can find a pornographic amount of NSFs at:

	http://www.zophar.net


Things you may need
===================
- Working copy of Winamp
- Some NSFs


Make it go
==========
PIMP installer installs program files in the right places.

Getting an NSF file to run requires two steps:

1. Load up an NSF file with Winamp. 
2. Press the play button.

That's it.


Thanks
======
Kevin Horton.Neal Tew.Darren Ranalli.Chris Moeller.Brad Taylor.
Charles MacDonald.

Later,
shady [ zeus at nofrendo dot org ]
