//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dsp.rc
//
#define IDD_CONFIG                      101
#define IDC_LOOPS                       1000
#define IDC_FADELEN                     1001
#define IDC_LOWVOL                      1002
#define IDC_FADEDELAY                   1003
#define IDC_ONECHAN                     1004
#define IDC_CHANNUM                     1005
#define IDC_PRISLIDER                   1006
#define IDC_CPUPRI                      1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
