/*

  in_cube Gamecube Stream Player for Winamp
  by hcs

  includes work by Destop and bero

*/

// 16-bit PCM
#include <windows.h>
#include <string.h>
#include "wamain.h"
#include "cube.h"


void strrep(char *src,char *find,char *rep)
{
	char remaining[MAX_PATH*2]; /*pointer to the left over part */
	int count = 0; /* no.of replacements*/

	size_t find_len = strlen(find);/*length of find string*/
	size_t rep_len = strlen(rep);/*length of replace string*/

	if(find_len == 0) return; /* nothing to find */

	/* get the matching position*/
	while( (src = strstr(src,find)) != NULL )
	{
		count++; /*Count the num of replacements*/
		strcpy(remaining,src + find_len); /*store left over string */
		strcpy(src,rep); /*make the replacement*/
		src += rep_len; /*move to end of replacement*/
		strcpy(src,remaining); /*copy back the left over part*/
	}
}

// inputfile == NULL means file is already opened, just reload
// return 1 if valid ADP not detected, 0 on success
int InitPCMFILE(char * inputfile, CUBEFILE * pcm) {
	char readbuf[0x400];
	int l;


	if (inputfile) {
		pcm->ch[0].infile=pcm->ch[1].infile=INVALID_HANDLE_VALUE;

		pcm->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

		if (pcm->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
			return 1;
	} else if (pcm->ch[0].type!=type_rsdpcm) return 1; // we don't have the file name to recheck

	pcm->ch[1].infile=pcm->ch[0].infile;
	pcm->ch[0].readloc=pcm->ch[0].writeloc=0;

	ReadFile(pcm->ch[0].infile,readbuf,0x100,&l,NULL);

	pcm->file_length=GetFileSize(pcm->ch[0].infile,NULL);

	if (!memcmp(readbuf,"RSD3PCMB",8) || !memcmp(readbuf,"RSD2PCMB",8)) {
		// RSD (PCM type(s))
		
		pcm->NCH = get32bitL(readbuf+8); // I think
		pcm->ch[0].sample_rate = get32bitL(readbuf+0x10);
		pcm->ch[0].chanstart = get32bitL(readbuf+0x18);
		pcm->ch[0].num_samples = (GetFileSize(pcm->ch[0].infile,&l)-pcm->ch[0].chanstart)/(2*pcm->NCH);
		pcm->ch[0].loop_flag=0;
		pcm->ch[0].type = type_rsdpcm;
	} else if (!memcmp(readbuf, "STRM",4) &&
		((pcm->file_length-0x40) == (unsigned long)get32bit(readbuf+4)) &&
		!memcmp(readbuf+0x40,"BLCK",4) &&
		!memcmp(readbuf+0x48,"\0\0\0\0\0\0\0\0",8) &&
		get16bit(readbuf+8)==0x0001) { // PCM=0001, AFC ADPCM=0000
		// AST (PCM with interleaved blocks)
		pcm->NCH = 2; // 'cause dat's all I gots
		pcm->ch[0].sample_rate = get32bit(readbuf+0x10);
		pcm->ch[0].chanstart = 0x40;
		pcm->ch[1].chanstart = 0x40;
		pcm->ch[0].num_samples = get32bit(readbuf+0x14);
		pcm->ch[0].loop_flag = get16bit(readbuf+0xe);
		pcm->ch[0].sa = pcm->ch[1].sa = get32bit(readbuf+0x18);
		pcm->ch[0].ea = pcm->ch[1].ea = get32bit(readbuf+0x1c);

		pcm->samplesdone = 0;

		// uses a very HALP-like mechanism, BLCK
		pcm->nexthalp=0x40;
		pcm->halpsize=0;
		
		// invalidate loop context so it'll be remembered when we hit the start
		pcm->loophalpsize=-1;
		
		pcm->ch[0].type = type_astpcm;
	} else if (!memcmp(readbuf, "\0\0\0\x06", 4)) {
		// WAV (Hitman2's specific header format, unpacked from large WAV chunk using WHD headers)
	    pcm->NCH = get32bit(readbuf+0x1C); // I think
	    pcm->ch[0].sample_rate = get32bit(readbuf+0xc);
	    pcm->ch[0].offs=pcm->ch[0].chanstart = 0x30;
	    if (pcm->NCH==2) {
		pcm->ch[0].interleave = 0x8000;
		pcm->ch[1].offs=pcm->ch[1].chanstart = 0x30+0x8000;
	    } else
		pcm->ch[0].interleave = 0;
	    pcm->ch[0].num_samples = (GetFileSize(pcm->ch[0].infile,&l)-pcm->ch[0].chanstart)/(2*pcm->NCH);
	    pcm->ch[0].loop_flag=0;
	    pcm->ch[0].type=type_whdpcm;
	}
	else if (!memcmp("RSTM",readbuf,4)) {
		long headOffset=0;
		long headLength=0;
		long numSamples=0;
		long fileLength;
		
		headOffset=get32bit(readbuf+0x10);
		headLength=get32bit(readbuf+0x14);
		fileLength=get32bit(readbuf+0x08);

		SetFilePointer(pcm->ch[0].infile,headOffset,0,FILE_BEGIN);
		ReadFile(pcm->ch[0].infile, &readbuf, headLength, &l, NULL);

		// 1 = pcm
		if (readbuf[0x20]!=1) {
			CloseHandle(pcm->ch[0].infile);
			return 1;
		}

		pcm->ch[0].chanstart=pcm->ch[1].chanstart=get32bit(readbuf+0x30);
		pcm->NCH = readbuf[0x22];

		pcm->ch[0].num_samples=get32bit(readbuf+0x2c);
		
		pcm->ch[0].sample_rate=pcm->ch[1].sample_rate=get16bit(readbuf+0x24);
		pcm->ch[0].loop_flag=pcm->ch[1].loop_flag=readbuf[0x21]; 
		pcm->ch[0].interleave=pcm->ch[1].interleave=get32bit(readbuf+0x38);
		pcm->ch[1].chanstart+=pcm->ch[0].interleave;
		pcm->ch[0].ea=pcm->ch[1].ea=pcm->ch[0].num_samples;
		pcm->ch[0].sa=pcm->ch[1].sa=get32bit(readbuf+0x28);

		pcm->ch[0].offs=pcm->ch[0].chanstart;
		pcm->ch[1].offs=pcm->ch[1].chanstart;

		pcm->ch[0].bps=8;
		pcm->ch[1].bps=8;

		pcm->ch[0].type=type_rstmpcm_wii;
	} else if ((!memcmp("STRM",readbuf,4)) && (!memcmp("\xff\xfe\x00\x01",readbuf+4,4)) &&
		(!memcmp("\x10\x00\x02\x0",readbuf+0xc,4)) &&
		(!memcmp("HEAD\x50\x00\x00\x00",readbuf+0x10,8))) { // && ((readbuf[0x18]==1) || (readbuf[0x19]==1))) {
		
		pcm->ch[0].chanstart=pcm->ch[1].chanstart=get32bitL(readbuf+0x28);
		pcm->NCH = readbuf[0x1a];
		pcm->ch[0].num_samples=get32bitL(readbuf+0x24);
		
		pcm->ch[0].sample_rate=pcm->ch[1].sample_rate=get16bitL(readbuf+0x1c);
		pcm->ch[0].loop_flag=pcm->ch[1].loop_flag=readbuf[0x19]; 
		
		pcm->ch[1].chanstart=pcm->ch[0].chanstart;

		pcm->ch[0].ea=pcm->ch[1].ea=get32bitL(readbuf+0x24);
		pcm->ch[0].sa=pcm->ch[1].sa=get32bitL(readbuf+0x20);

		pcm->ch[0].bps=8;
		pcm->ch[1].bps=8;
		
		pcm->ch[0].blockSize=pcm->ch[1].blockSize=get32bitL(readbuf+0x30);
		pcm->ch[0].lastBlockSize=pcm->ch[1].lastBlockSize=get32bitL(readbuf+0x38);
		//pcm->ch[1].offs+=pcm->ch[1].blockSize;
		pcm->ch[0].type=type_strm_nds_ima;
		pcm->ch[0].IMABlockLength=pcm->ch[1].IMABlockLength=get32bitL(readbuf+0x2C);
		pcm->ch[0].IMABlockCount=pcm->ch[1].IMABlockCount=0;

		if(readbuf[0x18]==1) { // 16 bits
			pcm->ch[0].type=type_strm_nds;
			pcm->ch[1].chanstart+=pcm->ch[1].blockSize;
		} else if(readbuf[0x18]==0) { // 8 bits
			pcm->ch[0].type=type_strm_nds_8bits;
			pcm->ch[1].chanstart+=pcm->ch[1].blockSize;
		}

		pcm->ch[0].offs=pcm->ch[0].chanstart;
		pcm->ch[1].offs=pcm->ch[1].chanstart;

	} else if (!memcmp(readbuf,"kRAW",4)) {
		char othername[MAX_PATH+1];
		// kRAW
		//pcm->ch[1].infile=INVALID_HANDLE_VALUE;

		pcm->ch[0].sample_rate = pcm->ch[1].sample_rate = 32000;
		pcm->ch[0].interleave=0;
		pcm->ch[0].chanstart = pcm->ch[1].chanstart = 0x08;
		pcm->ch[0].num_samples = pcm->ch[1].num_samples = get32bit(readbuf+0x04)/2;
		pcm->ch[0].sa=pcm->ch[1].sa=0;
		pcm->ch[0].ea=pcm->ch[1].ea=pcm->ch[0].num_samples;
		pcm->ch[0].loop_flag=pcm->ch[1].loop_flag=1;
		pcm->ch[0].type = pcm->ch[1].type = type_kraw;
		pcm->NCH=1;

		strcpy(othername,inputfile);

		if (strstr(inputfile,"Left")) {

			strrep(othername,"Left","Right");

			pcm->ch[1].infile = CreateFile(othername,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
				OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
			if (pcm->ch[1].infile != INVALID_HANDLE_VALUE) 
			{
				pcm->NCH=2;
			}
		} else if (strstr(inputfile,"Right")) {
			CUBESTREAM temp = pcm->ch[1];
			
			strrep(othername,"Right","Left");
			temp.infile = CreateFile(othername,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
				OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
			if (temp.infile != INVALID_HANDLE_VALUE) {
				pcm->NCH=2;
				pcm->ch[1]=pcm->ch[0];
				pcm->ch[0]=temp;
			}
		}
		pcm->ch[0].offs=pcm->ch[0].chanstart;
		pcm->ch[1].offs=pcm->ch[1].chanstart;

	} else if (!memcmp("KNON",readbuf,4) && !memcmp("KPST",readbuf+0x20,4)) {

		pcm->NCH = get16bit(readbuf+0x64);
	    pcm->ch[0].sample_rate = get16bit(readbuf+0x42);
	    pcm->ch[0].offs=pcm->ch[0].chanstart = 0x800;
		pcm->ch[0].interleave = 0;
	    pcm->ch[0].num_samples = get32bit(readbuf+0x3c)/(2*pcm->NCH);
		pcm->ch[0].sa=get32bit(readbuf+0x44)/(2*2*pcm->NCH);
		pcm->ch[0].ea=get32bit(readbuf+0x48)/(2*2*pcm->NCH);
	    pcm->ch[0].loop_flag=(pcm->ch[0].ea!=0);
	    pcm->ch[0].type=type_knon_pcm;
		pcm->ch[0].bps=pcm->ch[1].bps=8;

	} else if (!memcmp("xmd",readbuf,3)) {

		pcm->NCH = (int)readbuf[3];
	    pcm->ch[0].sample_rate = get16bitL(readbuf+0x04);
	    pcm->ch[0].offs=pcm->ch[0].chanstart = 0x0;
		pcm->ch[0].interleave = pcm->ch[1].interleave =28;
		pcm->ch[1].offs=pcm->ch[0].offs+pcm->ch[0].interleave;
	    pcm->ch[0].num_samples = get32bitL(readbuf+0x6)/(2*pcm->NCH);
	    pcm->ch[0].type=type_rstmpcm_wii;
		pcm->ch[0].bps=pcm->ch[1].bps=8;

	} else if (!memcmp("SWAV",readbuf,4) && !memcmp("DATA",readbuf+0x10,4)) {

		// this one sucks, but i have found no other way to check
		// for mono or stereo :((
		if((get16bitL(readbuf+0x28)==0) && (get16bitL(readbuf+0x2c)!=0) && (readbuf[0x1d]<=2))
			pcm->NCH = 2; 
		else
			pcm->NCH = 1;

	    pcm->ch[0].sample_rate = get16bitL(readbuf+0x1a);
	    pcm->ch[0].offs=pcm->ch[0].chanstart = 0x24;
		pcm->ch[0].blockSize = pcm->ch[1].blockSize = 0x100; // do stuff by block of 0x100 bytes ...
		pcm->ch[0].IMABlockLength=pcm->ch[1].IMABlockLength=(((int)(get32bitL(readbuf+0x08)-0x28)/0x100)*pcm->NCH) +1;
		pcm->ch[0].lastBlockSize = pcm->ch[1].lastBlockSize = ((get32bitL(readbuf+0x08)-0x28) % 0x100);
	    pcm->ch[0].num_samples = ((get32bitL(readbuf+0x08)-0x28)*2); ///pcm->NCH;
		pcm->ch[0].sa=pcm->ch[1].sa=(get16bitL(readbuf+0x1e))<<1;
		pcm->ch[0].ea=pcm->ch[1].ea=(get32bitL(readbuf+0x20))<<2;
	    pcm->ch[0].loop_flag=(readbuf[0x19]!=0); // strange ....
	    pcm->ch[0].type=type_strm_nds_swav;
		pcm->ch[0].bps=pcm->ch[1].bps=16;

		if(readbuf[0x18]==1) { // 16 bits
			pcm->ch[0].type=type_strm_nds;
		} else if(readbuf[0x18]==0) { // 8 bits
			pcm->ch[0].type=type_strm_nds_8bits;
		}
	} else if (!memcmp("MUSX",readbuf,4) && !memcmp("GC__",readbuf+0x10,4)) {

		pcm->NCH = 2; 
	    pcm->ch[0].sample_rate = 32000;
	    pcm->ch[0].offs=pcm->ch[0].chanstart = get32bit(readbuf+0x28);
	    pcm->ch[0].num_samples = ((get32bit(readbuf+0x2c)/0x20)*(0x1c*pcm->NCH))/pcm->NCH; ///pcm->NCH;
	    pcm->ch[0].type=type_musx;
		pcm->ch[0].bps=pcm->ch[1].bps=16;

		SetFilePointer(pcm->ch[0].infile,get32bit(readbuf+0x20),0,FILE_BEGIN);
		ReadFile(pcm->ch[0].infile,readbuf,0x100,&l,NULL);

		pcm->loop_start_offset=get32bit(readbuf+0x30)+pcm->ch[0].chanstart;
		pcm->loop_end_offset=get32bit(readbuf+0x48)+pcm->ch[0].chanstart;
		pcm->ch[0].loopoffs=0;

		pcm->ch[0].sa = ((get32bit(readbuf+0x30)/0x20)*(0x1c*pcm->NCH))/pcm->NCH;
		pcm->ch[0].ea = ((get32bit(readbuf+0x48)/0x20)*(0x1c*pcm->NCH))/pcm->NCH;
		pcm->ch[0].loop_flag=(pcm->ch[0].ea!=0);

	} else if (!memcmp("RIFF",readbuf,4) && !memcmp("IMA ",readbuf+0x08,4)) {

		pcm->NCH = 2; 
	    pcm->ch[0].sample_rate = get32bitL(readbuf+0x0c);
	    pcm->ch[0].offs=pcm->ch[0].chanstart = 0x20;
	    pcm->ch[0].num_samples = ((get32bitL(readbuf+0x04)-0x20)*2)/pcm->NCH;
	    pcm->ch[0].type=type_riff_ima;
		pcm->ch[0].bps=pcm->ch[1].bps=16;
		pcm->ch[0].loop_flag=0;
	} else if (!memcmp("WBND",readbuf,4) && get32bitL(readbuf+0x2C)==1) {

		if(get32bitL(readbuf+0x04)==3) {
			pcm->NCH = (get32bitL(readbuf+0x54) >> (2)) & ((1 <<  3) - 1);
			pcm->ch[0].sample_rate =(get32bitL(readbuf+0x54) >> (2 + 3)) & ((1 << 18) - 1);
		}

	    pcm->ch[0].offs=pcm->ch[0].chanstart = 0x800;
	    pcm->nrsamples=pcm->ch[0].num_samples = get32bitL(readbuf+0x5C)/4;

	    pcm->ch[0].type=type_raw;
		pcm->ch[0].bps=pcm->ch[1].bps=16;
		pcm->ch[0].sa=get32bitL(readbuf+0x60)/4;
		pcm->ch[0].ea=pcm->ch[0].num_samples;
		pcm->ch[0].loop_flag=(pcm->ch[0].sa!=0);

		if(!CheckSampleRate(pcm->ch[0].sample_rate))
			return 1;

	} else {
		
		//CloseHandle(pcm->ch[0].infile);
		//pcm->ch[0].infile=INVALID_HANDLE_VALUE;
		CloseHandle(pcm->ch[0].infile);
		return 1;
	}

	pcm->lastchunk=0;

	if (!pcm->ch[0].loop_flag) pcm->nrsamples = pcm->ch[0].num_samples;
	else
		pcm->nrsamples=pcm->ch[0].sa+looptimes*(pcm->ch[0].ea-pcm->ch[0].sa)+(fadelength+fadedelay)*pcm->ch[0].sample_rate;
	
	pcm->ch[0].readloc=pcm->ch[1].readloc=pcm->ch[0].writeloc=pcm->ch[1].writeloc=0;
	
	SetFilePointer(pcm->ch[0].infile,pcm->ch[0].chanstart,NULL,FILE_BEGIN);

	return 0;
}

// standard sample-level interleave

void fillbufferPCM(CUBEFILE * pcm) {
	int l,i;
	char PCMbuf[8];

	if (SetFilePointer(pcm->ch[0].infile,0,0,FILE_CURRENT) >= pcm->file_length) {
		pcm->ch[0].readloc=pcm->ch[1].readloc=pcm->ch[0].writeloc-1;
		return;
	}

	do {
		ReadFile(pcm->ch[0].infile, PCMbuf, pcm->NCH*2, &l, NULL);
		if (l<pcm->NCH*2) return;

		for (i=0;i<pcm->NCH;i++) {
			pcm->ch[i].chanbuf[pcm->ch[i].writeloc]=get16bit(PCMbuf+i*2);
			pcm->ch[i].writeloc++;
			if (pcm->ch[i].writeloc>=BUFFER_SIZE/8*14) pcm->ch[i].writeloc=0;
		}
	} while (pcm->ch[0].writeloc != pcm->ch[0].readloc);

}

void fillbufferPCM_noint(CUBESTREAM * stream) {
	int l;
	char PCMbuf[2];

	SetFilePointer(stream->infile,stream->offs,0,FILE_BEGIN);

	do {
		ReadFile(stream->infile, PCMbuf, 2, &l, NULL);
		if (l<2) return;
		stream->offs+=2;

		if (stream->loop_flag && stream->offs-stream->chanstart >= stream->ea*2) {
			stream->offs = stream->chanstart + stream->sa*2;
			SetFilePointer(stream->infile,stream->offs,0,FILE_BEGIN);
		}

		stream->chanbuf[stream->writeloc]=get16bit(PCMbuf);
		stream->writeloc++;
		if (stream->writeloc>=BUFFER_SIZE/8*14) stream->writeloc=0;
	} while (stream->writeloc != stream->readloc);
}

// no interleave, in BACKWARDS LAND

void fillbufferPCM_LE_noint8bits(CUBESTREAM * stream) {
	int l;
	char PCMbuf[1];

	SetFilePointer(stream->infile,stream->offs,0,FILE_BEGIN);

	do {
		ReadFile(stream->infile, PCMbuf, 1, &l, NULL);
		if (l<1) return;
		stream->offs+=1;

		if (stream->loop_flag && stream->offs-stream->chanstart >= stream->ea) {
			DisplayError("loop to %d",stream->sa);
			stream->offs = stream->chanstart + stream->sa;
			SetFilePointer(stream->infile,stream->offs,0,FILE_BEGIN);
		}

		stream->chanbuf[stream->writeloc]=(short)(PCMbuf[0]<<8); // get16bitL(PCMbuf);
		stream->writeloc++;
		if (stream->writeloc>=BUFFER_SIZE/8*14) stream->writeloc=0;
	} while (stream->writeloc != stream->readloc);
}

void fillbufferPCM_LE_noint(CUBESTREAM * stream) {
	int l;
	char PCMbuf[2];

	SetFilePointer(stream->infile,stream->offs,0,FILE_BEGIN);

	do {
		ReadFile(stream->infile, PCMbuf, 2, &l, NULL);
		if (l<2) return;
		stream->offs+=2;

		if (stream->loop_flag && stream->offs-stream->chanstart >= stream->ea*2) {
			stream->offs = stream->chanstart + stream->sa*2;
			SetFilePointer(stream->infile,stream->offs,0,FILE_BEGIN);
		}

		stream->chanbuf[stream->writeloc]=get16bitL(PCMbuf);
		stream->writeloc++;
		if (stream->writeloc>=BUFFER_SIZE/8*14) stream->writeloc=0;
	} while (stream->writeloc != stream->readloc);
}

// PCM w/ interleave
void fillbufferPCMinterleave(CUBEFILE * pcm) {
	int l;
	char PCMbuf1[2];
	char PCMbuf2[2];

	if (SetFilePointer(pcm->ch[0].infile,0,0,FILE_CURRENT) >= pcm->file_length) {
		pcm->ch[0].readloc=pcm->ch[1].readloc=pcm->ch[0].writeloc-1;
		DisplayError("EOF! file pointer = %d, file length = %d\nch[0].offs=%d ch[1].offs=%d\ninterleave=%d",SetFilePointer(pcm->ch[0].infile,0,0,FILE_CURRENT), pcm->file_length,pcm->ch[0].offs,pcm->ch[1].offs,pcm->ch[0].interleave);
		return;
	}

	do {
		SetFilePointer(pcm->ch[0].infile,pcm->ch[0].offs,0,FILE_BEGIN);
		ReadFile(pcm->ch[0].infile, PCMbuf1, 2, &l, NULL);
		SetFilePointer(pcm->ch[1].infile,pcm->ch[1].offs,0,FILE_BEGIN);
		ReadFile(pcm->ch[1].infile, PCMbuf2, 2, &l, NULL);

		pcm->ch[0].chanbuf[pcm->ch[0].writeloc]=get16bit(PCMbuf1);
		pcm->ch[0].offs+=2;
		pcm->ch[1].chanbuf[pcm->ch[1].writeloc]=get16bit(PCMbuf2);
		pcm->ch[1].offs+=2;

		if (pcm->ch[0].interleave && !pcm->lastchunk &&
		 !((pcm->ch[0].offs-pcm->ch[0].chanstart)%pcm->ch[0].interleave)) {
		    pcm->ch[0].offs+=pcm->ch[0].interleave;
			pcm->ch[1].offs+=pcm->ch[1].interleave;
			if (pcm->ch[0].type==type_rstmpcm_wii && pcm->ch[1].offs+pcm->ch[1].interleave > pcm->file_length) {
					pcm->ch[1].offs=pcm->ch[0].offs+(pcm->file_length-pcm->ch[0].offs)/2;
					pcm->lastchunk=1;
			}
		}

		if (pcm->ch[0].loop_flag &&
			((!pcm->lastchunk && pcm->ch[1].offs-pcm->ch[0].chanstart >=
		   pcm->ch[0].ea*2*2)) ||
		   ((pcm->lastchunk && pcm->ch[1].offs >=
		   pcm->file_length)))
		{
			//DisplayError("loop\nch=%d\nwriteloc=%d",i,pcm->ch[i].writeloc);
			pcm->ch[0].offs=pcm->ch[0].chanstart+pcm->ch[0].sa*2*2;
			pcm->ch[1].offs=pcm->ch[1].chanstart+pcm->ch[1].sa*2*2;
			pcm->lastchunk=0;
		}

		pcm->ch[0].writeloc++;
		pcm->ch[1].writeloc++;
		if (pcm->ch[0].writeloc>=BUFFER_SIZE/8*14) pcm->ch[0].writeloc=0;
		if (pcm->ch[1].writeloc>=BUFFER_SIZE/8*14) pcm->ch[1].writeloc=0;
    } while (pcm->ch[0].writeloc != pcm->ch[0].readloc);
}

// AST blocked interleave (adapted from HALPST decoder)


// faster (but inaccurarate upon looping) 4-samples-at-a-time version
/*void fillbufferASTPCM(CUBEFILE * pcm) {
	int l,i,c;
	char PCMbuf1[8],PCMbuf2[8];

	if (pcm->halpsize==0 && (long)pcm->nexthalp == 0) pcm->ch[0].readloc=pcm->ch[1].readloc=pcm->ch[0].writeloc-1;

	i=0;
	
	do {
		if (i==0) {
			// handle BLCK headers
			if (pcm->halpsize==0) {
				if ((long)pcm->nexthalp == 0) return;
				pcm->ch[0].offs=pcm->nexthalp+0x20;
				SetFilePointer(pcm->ch[0].infile, pcm->nexthalp,0,FILE_BEGIN);
				ReadFile(pcm->ch[0].infile, PCMbuf1, 8, &l, NULL);
				if (l<8) return;
				pcm->halpsize=get32bit(PCMbuf1+4)*2; // interleave amount (this whole BLCK is 2x)
								
				pcm->ch[1].offs=pcm->nexthalp+0x20+get32bit(PCMbuf1+4);
				pcm->nexthalp+=get32bit(PCMbuf1+4)*2+0x20;
			}

			SetFilePointer(pcm->ch[0].infile, pcm->ch[0].offs,0,FILE_BEGIN);
			ReadFile(pcm->ch[0].infile, PCMbuf1, 8, &l, NULL);

			SetFilePointer(pcm->ch[0].infile, pcm->ch[1].offs,0,FILE_BEGIN);
			ReadFile(pcm->ch[0].infile, PCMbuf2, 8, &l, NULL);			

			pcm->ch[0].offs+=8;
			pcm->ch[1].offs+=8;
			
			pcm->halpsize-=0x10;
			if (pcm->halpsize<0x10) pcm->halpsize=0;

			
			c=0;
			i=4;
		}

		pcm->ch[0].chanbuf[pcm->ch[0].writeloc++]=get16bit(PCMbuf1+c);
		pcm->ch[1].chanbuf[pcm->ch[1].writeloc++]=get16bit(PCMbuf2+c);

		pcm->samplesdone++;
		if (pcm->ch[0].loop_flag && pcm->loophalpsize < 0 && pcm->samplesdone >= (int)pcm->ch[0].sa) {
			// a lot of these values could probably just be recalculated, but it's easy to save them
			pcm->loophalpsize = pcm->halpsize-2*c;
			pcm->loopnexthalp = pcm->nexthalp;
			pcm->ch[0].loopoffs = pcm->ch[0].offs-8+c;
			pcm->ch[1].loopoffs = pcm->ch[1].offs-8+c;
		} else if (pcm->ch[0].loop_flag && pcm->samplesdone >= (int)pcm->ch[0].ea) {
			pcm->halpsize = pcm->loophalpsize;
			pcm->nexthalp = pcm->loopnexthalp;
			pcm->ch[0].offs = pcm->ch[0].loopoffs;
			pcm->ch[1].offs = pcm->ch[1].loopoffs;
			pcm->samplesdone = pcm->ch[0].sa;
			i=0;
		} else {
			i--;
			c+=2;
		}
			
		if (pcm->ch[0].writeloc>=0x8000/8*14) pcm->ch[0].writeloc=0;
		if (pcm->ch[1].writeloc>=0x8000/8*14) pcm->ch[1].writeloc=0;
	} while (pcm->ch[0].writeloc != pcm->ch[0].readloc);
}*/

// one sample (pair) at a time, quite slow on the reading but makes accuracy easier
void fillbufferASTPCM(CUBEFILE * pcm) {
	int l;
	char PCMbuf1[16],PCMbuf2[8];

	if (pcm->halpsize==0 && (long)pcm->nexthalp == 0) pcm->ch[0].readloc=pcm->ch[1].readloc=pcm->ch[0].writeloc-1;
	
	do {
			// handle BLCK headers
			if (pcm->halpsize==0) {
				if ((long)pcm->nexthalp == 0) return;
				pcm->ch[0].offs=pcm->nexthalp+0x20;
				SetFilePointer(pcm->ch[0].infile, pcm->nexthalp,0,FILE_BEGIN);
				ReadFile(pcm->ch[0].infile, PCMbuf1, 16, &l, NULL);
				if (l<16) return;
				if (get32bit(PCMbuf1+8)!=0) return; /* not a PCM file */
				pcm->halpsize=get32bit(PCMbuf1+4)*2; // interleave amount (this whole BLCK is 2x)
								
				pcm->ch[1].offs=pcm->nexthalp+0x20+get32bit(PCMbuf1+4);
				pcm->nexthalp+=get32bit(PCMbuf1+4)*2+0x20;
			}

			SetFilePointer(pcm->ch[0].infile, pcm->ch[0].offs,0,FILE_BEGIN);
			ReadFile(pcm->ch[0].infile, PCMbuf1, 2, &l, NULL);

			SetFilePointer(pcm->ch[0].infile, pcm->ch[1].offs,0,FILE_BEGIN);
			ReadFile(pcm->ch[0].infile, PCMbuf2, 2, &l, NULL);			

			pcm->ch[0].offs+=2;
			pcm->ch[1].offs+=2;
			
			pcm->halpsize-=4;
			if (pcm->halpsize<4) pcm->halpsize=0;

			pcm->samplesdone++;
			if (pcm->loophalpsize < 0 && (pcm->samplesdone >= (int)pcm->ch[0].sa)) {
				// a lot of these values could probably just be recalculated, but it's easy to save them
				pcm->loophalpsize = pcm->halpsize;
				pcm->loopnexthalp = pcm->nexthalp;
				pcm->ch[0].loopoffs = pcm->ch[0].offs;
				pcm->ch[1].loopoffs = pcm->ch[1].offs;
			}
			if (pcm->samplesdone >= (int)pcm->ch[0].ea) {
				pcm->halpsize = pcm->loophalpsize;
				pcm->nexthalp = pcm->loopnexthalp;
				pcm->ch[0].offs = pcm->ch[0].loopoffs;
				pcm->ch[1].offs = pcm->ch[1].loopoffs;
				pcm->samplesdone = pcm->ch[0].sa;
			}
		
			pcm->ch[0].chanbuf[pcm->ch[0].writeloc++]=get16bit(PCMbuf1);
			pcm->ch[1].chanbuf[pcm->ch[1].writeloc++]=get16bit(PCMbuf2);
			
			if (pcm->ch[0].writeloc>=BUFFER_SIZE/8*14) pcm->ch[0].writeloc=0;
			if (pcm->ch[1].writeloc>=BUFFER_SIZE/8*14) pcm->ch[1].writeloc=0;
	} while (pcm->ch[0].writeloc != pcm->ch[0].readloc);
}

