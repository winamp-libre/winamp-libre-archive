//============================================
//=== Audio XA decoding
//=== Kazzuya
//============================================
//=== Modified by linuzappz / yokota
//============================================
//=== C# Conversion by FastElbJa / Romsland
//============================================
#include <windows.h>
#include "wamain.h"
#include "cube.h"

const byte SH = 4;
const byte SHC = 10;
const byte BLKSIZ = 28; // block size (32 - 4 nibbles) 
byte  m_CurrentChannel = 0;

//============================================
//===  ADPCM DECODING ROUTINES
//============================================

double K0[4] = { 0.0, 0.9375, 1.796875,  1.53125};
double K1[4] = { 0.0,    0.0,  -0.8125,-0.859375};

int IK0(int fid)
{ return ((int)((-K0[fid]) * (1 << SHC))); }

int IK1(int fid)
{ return ((int)((-K1[fid]) * (1 << SHC))); }

int CLAMP(int value, int Minim, int Maxim)
{
    if (value < Minim) value = Minim;
    if (value > Maxim) value = Maxim;
    return value;
}

//============================================
//===  XA SPECIFIC ROUTINES
//============================================

const byte SUB_SUB_EOF = (1 << 7);  // end of file
const byte SUB_SUB_RT = (1 << 6);  // real-time sector
const byte SUB_SUB_FORM = (1 << 5);  // 0 form1  1 form2
const byte SUB_SUB_TRIGGER = (1 << 4);  // used for interrupt
const byte SUB_SUB_DATA = (1 << 3);  // contains data
const byte SUB_SUB_AUDIO = (1 << 2);  // contains audio
const byte SUB_SUB_VIDEO = (1 << 1);  // contains video
const byte SUB_SUB_EOR = (1 << 0);  // end of record

byte AUDIO_CODING_GET_STEREO(byte value)
{
    return (byte)(value & 3);
}

byte AUDIO_CODING_GET_FREQ(byte value)
{
    return (byte)(((value) >> 2) & 3);
}

byte AUDIO_CODING_GET_BPS(byte value)
{
    return (byte)(((value) >> 4) & 3);
}

byte AUDIO_CODING_GET_EMPHASIS(byte value)
{
    return (byte)(((value) >> 6) & 1);
}

const byte SUB_UNKNOWN = 0;
const byte SUB_VIDEO = 1;
const byte SUB_AUDIO = 2;

struct 
{
    byte FileNumber;
    byte Channel;
    byte SubMode;
    byte Coding;
    byte FileNumber2;
    byte Channel2;
    byte SubMode2;
    byte Coding2;
} m_SubHeader;

int InitXAFile(char * infile, CUBEFILE * xa)
{
    byte buffer[2352];
	DWORD l;

	if (infile) {
		xa->ch[0].infile=xa->ch[1].infile=INVALID_HANDLE_VALUE;

		xa->ch[0].infile = CreateFile(infile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

		if (xa->ch[0].infile == INVALID_HANDLE_VALUE)
			return 1;

	} else if (xa->ch[0].type!=type_vag) return 1; 


	ReadFile(xa->ch[0].infile,buffer,0x3C,&l,NULL);

	if((memcmp(buffer,"RIFF",4) || memcmp(buffer+8,"CDXAfmt ",8)))	{
		CloseCUBEFILE(xa);
		return 1; 
	}

	ReadFile(xa->ch[0].infile,buffer,2352,&l,NULL);

	if (l == 2352)
    {
		xa->file_length=GetFileSize(xa->ch[0].infile,NULL);

        m_SubHeader.FileNumber = buffer[0];
        m_SubHeader.Channel = buffer[1];
        m_SubHeader.SubMode = buffer[2];
        m_SubHeader.Coding = buffer[3];

        m_CurrentChannel = m_SubHeader.Channel;

        xa->ch[0].type=type_xa;

        switch (AUDIO_CODING_GET_FREQ(m_SubHeader.Coding))
        {
            case 0: xa->ch[0].sample_rate = 37800; break;
            case 1: xa->ch[0].sample_rate = 18900; break;
            default: xa->ch[0].sample_rate = 0; break;
        }
        switch (AUDIO_CODING_GET_BPS(m_SubHeader.Coding))
        {
            case 0: xa->XABits = 4; break;
            case 1: xa->XABits = 8; break;
            default: xa->XABits = 0; break;
        }
        switch (AUDIO_CODING_GET_STEREO(m_SubHeader.Coding))
        {
            case 0: xa->NCH = 1; break;
            case 1: xa->NCH = 2; break;
            default: xa->NCH = 0; break;
        }

        xa->nrsamples =(((xa->file_length-0x3c)/2352)*0x1f80)/(2*xa->NCH);
        xa->ch[0].hist1 = xa->ch[0].hist2 = 0;
        xa->ch[1].hist1 = xa->ch[1].hist2 = 0;
		xa->ch[0].readloc=xa->ch[1].readloc=xa->ch[0].writeloc=xa->ch[1].writeloc=0;
		xa->ch[0].bps=xa->ch[1].bps=8;
		xa->ch[0].ea=xa->ch[0].sa=0;
		xa->ch[0].offs=xa->ch[1].offs=0x3c;
		xa->ch[0].loop_flag=0;
    }
	else {
		CloseCUBEFILE(xa);
		return 1;
	}

	return 0;
}

void ADPCM_DecodeBlock16(CUBESTREAM *stream,
                         byte FilterRange,
                         short *SoundData)
{
    int i;
    int range, filterid;
    int fy0, fy1;
    int readOffset = 0;

    filterid = (FilterRange >> 4) & 0x0f;
    range = (FilterRange >> 0) & 0x0f;

    fy0 = stream->lhist1; 
    fy1 = stream->lhist2;


    for (i = BLKSIZ / 4; i > 0; --i)
    {
        int y;
        int x0, x1, x2, x3;

		y = SoundData[readOffset++];
        x3 = (short)(y & 0xf000) >> range; x3 <<= SH;
        x2 = (short)((y << 4) & 0xf000) >> range; x2 <<= SH;
        x1 = (short)((y << 8) & 0xf000) >> range; x1 <<= SH;
        x0 = (short)((y << 12) & 0xf000) >> range; x0 <<= SH;

        x0 -= (IK0(filterid) * fy0 + (IK1(filterid) * fy1)) >> SHC; fy1 = fy0; fy0 = x0;
        x1 -= (IK0(filterid) * fy0 + (IK1(filterid) * fy1)) >> SHC; fy1 = fy0; fy0 = x1;
        x2 -= (IK0(filterid) * fy0 + (IK1(filterid) * fy1)) >> SHC; fy1 = fy0; fy0 = x2;
        x3 -= (IK0(filterid) * fy0 + (IK1(filterid) * fy1)) >> SHC; fy1 = fy0; fy0 = x3;

        x0 = CLAMP(x0, -32768 << SH, 32767 << SH);
		stream->chanbuf[stream->writeloc++]= (short)(x0 >> SH);
        x1 = CLAMP(x1, -32768 << SH, 32767 << SH);
        stream->chanbuf[stream->writeloc++]= (short)(x1 >> SH);
        x2 = CLAMP(x2, -32768 << SH, 32767 << SH);
        stream->chanbuf[stream->writeloc++]= (short)(x2 >> SH);
        x3 = CLAMP(x3, -32768 << SH, 32767 << SH);
        stream->chanbuf[stream->writeloc++]= (short)(x3 >> SH);

        stream->lhist1 = fy0;
        stream->lhist2 = fy1;

		if (stream->writeloc>=BUFFER_SIZE/8*14) 
			stream->writeloc=0;
    }
}

//===========================================
void XA_Decode_Data(CUBEFILE *xa, byte *buffer)
{
    byte SoundGroupSP[16];
    short SoundData[0x900];
    int HeadTable[4]= { 0, 2, 8, 10 };

    int i = 0;
    int j = 0;
    int k = 0;
    int l = 0;
    int increment = 0;

    byte NbOfBits = 2;

    if (xa->XABits == 4)
        NbOfBits = 4;

    if (xa->NCH == 2)
    {
        if ((xa->XABits == 8) && (xa->ch[0].sample_rate == 37800))
        {
            // Level A
            for (j = 0; j < 18; j++)
            {
                // Copy Sound Group headers
				memcpy(SoundGroupSP,&buffer[j*128],16);

                for (i = 0; i < NbOfBits; i++)
                {
                    l = 0;

                    for (k = 0, l = 0; k < 7; k++, ++l)
                    {
                        increment = (unsigned short)((j * 128) + 16 + (k * 8) + i);
                        SoundData[l] = (short)((buffer[increment] & 0x0f) |
                                               ((buffer[increment + 4] & 0x0f) << 8));
                    }
                    ADPCM_DecodeBlock16(&xa->ch[0],
                                        SoundGroupSP[HeadTable[i] + 0],
                                        SoundData);

                    xa->samplesdone += 28;

                    l = 0;

                    for (k = 0, l = 0; k < 7; k++, ++l)
                    {
                        increment = (unsigned short)((j * 128) + 16 + (k * 8) + i);
                        SoundData[l] = (short)((buffer[increment] >> 4) |
                                               ((buffer[increment + 4] >> 4) << 8));
                    }
                    ADPCM_DecodeBlock16(&xa->ch[1],
                                        SoundGroupSP[HeadTable[i] + 1],
                                        SoundData);

                    xa->samplesdone += 28;
                }
            }
        }
        else
        {
            // Level B/C
            for (j = 0; j < 18; j++)
            {
                // Copy Sound Group headers
				memcpy(SoundGroupSP,&buffer[j*128],16);

                for (i = 0; i < NbOfBits; i++)
                {
                    l = 0;

                    for (k = 0, l = 0; k < 7; k++, ++l)
                    {
                        increment = (unsigned short)((j * 128) + 16 + (k * 16) + i);
                        SoundData[l] = (short)((buffer[increment] & 0x0f) |
                                               ((buffer[increment + 4] & 0x0f) << 4) |
                                               ((buffer[increment + 8] & 0x0f) << 8) |
                                               ((buffer[increment + 12] & 0x0f) << 12));
                    }
                    ADPCM_DecodeBlock16(&xa->ch[0],
                                        SoundGroupSP[HeadTable[i] + 0],
                                        SoundData);

                    xa->samplesdone += 28;

                    l = 0;

                    for (k = 0, l = 0; k < 7; k++, ++l)
                    {
                        increment = (unsigned short)((j * 128) + 16 + (k * 16) + i);
                        SoundData[l] = (short)((buffer[increment] >> 4) |
                                               ((buffer[increment + 4] >> 4) << 4) |
                                               ((buffer[increment + 8] >> 4) << 8) |
                                               ((buffer[increment + 12] >> 4) << 12));
                    }
                    ADPCM_DecodeBlock16(&xa->ch[1],
                                        SoundGroupSP[HeadTable[i] + 1],
                                        SoundData);
                    
                    xa->samplesdone += 28;
                }
            }
        }
    }
    else
    {
        if ((xa->XABits == 8) && (xa->ch[0].sample_rate == 37800))
        {
            // Level B/C
            for (j = 0; j < 18; j++)
            {
                // Copy Sound Group headers
				memcpy(SoundGroupSP,&buffer[j*128],16);

                for (i = 0; i < NbOfBits; i++)
                {
                    l = 0;

                    for (k = 0, l = 0; k < 7; k++, ++l)
                    {
                        increment = (unsigned short)((j * 128) + 16 + (k * 8) + i);
                        SoundData[l] = (short)((buffer[increment] & 0x0f) |
                                               ((buffer[increment + 4] & 0x0f) << 8));
                    }
                    ADPCM_DecodeBlock16(&xa->ch[0],
                                        SoundGroupSP[HeadTable[i] + 0],
                                        SoundData);

                    xa->samplesdone += 28;

                }
            }
        }
        else
        {
            // Level A
            for (j = 0; j < 18; j++)
            {
                // Copy Sound Group headers
				memcpy(SoundGroupSP,&buffer[j*128],16);

                for (i = 0; i < NbOfBits; i++)
                {
                    l = 0;

                    for (k = 0, l = 0; k < 7; k++, ++l)
                    {
                        increment = (unsigned short)((j * 128) + 16 + (k * 16) + i);
                        SoundData[l] = (short)((buffer[increment] & 0x0f) |
                                               ((buffer[increment + 4] & 0x0f) << 4) |
                                               ((buffer[increment + 8] & 0x0f) << 8) |
                                               ((buffer[increment + 12] & 0x0f) << 12));
                    }
                    ADPCM_DecodeBlock16(&xa->ch[0],
                                        SoundGroupSP[HeadTable[i] + 0],
                                        SoundData);

                    xa->samplesdone += 28;

                    l = 0;

                    for (k = 0, l = 0; k < 7; k++, ++l)
                    {
                        increment = (unsigned short)((j * 128) + 16 + (k * 16) + i);
                        SoundData[l] = (short)((buffer[increment] >> 4) |
                                               ((buffer[increment + 4] >> 4) << 4) |
                                               ((buffer[increment + 8] >> 4) << 8) |
                                               ((buffer[increment + 12] >> 4) << 12));
                    }
                    ADPCM_DecodeBlock16(&xa->ch[0],
                                        SoundGroupSP[HeadTable[i] + 1],
                                        SoundData);

                    xa->samplesdone += 28;
                }
            }
        }
    }
}

//============================================
int Parse_XA_Audio_Sector(CUBEFILE *xa,
                          byte *buffer,
                          byte ChannelNumber)
{

    if ((m_SubHeader.Channel == ChannelNumber) && (m_SubHeader.SubMode == 0x64))
    {
        XA_Decode_Data(xa, buffer);
        return 0;
    }
    else
        return -1;
}


void fillbufferXA(CUBEFILE *xa)
{
    byte buffer[2352];
    DWORD byteRead = 0;

	SetFilePointer(xa->ch[0].infile,xa->ch[0].offs,0,FILE_BEGIN);

	do
	{
		ReadFile(xa->ch[0].infile,buffer,8,&byteRead,NULL);

		if (byteRead > 0)
		{
	        m_SubHeader.FileNumber = buffer[0];
		    m_SubHeader.Channel = buffer[1];
	        m_SubHeader.SubMode = buffer[2];
		    m_SubHeader.Coding = buffer[3];
		
			ReadFile(xa->ch[0].infile,buffer,2344,&byteRead,NULL);
			if (byteRead > 0)
			{
				if ((m_SubHeader.SubMode == 0xe4) && (m_SubHeader.Channel == m_CurrentChannel))
					return;
				else
				{
					if ((m_SubHeader.SubMode == 0x64) && (m_SubHeader.Channel == m_CurrentChannel))
						XA_Decode_Data(xa, buffer);
					xa->ch[0].offs += 2352;
				}
			}
		}
	} while (m_SubHeader.Channel!=m_CurrentChannel);
}
