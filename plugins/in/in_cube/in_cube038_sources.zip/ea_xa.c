/*

  EA-XA Stream Player for Winamp
  by Fastelbja

*/

// EA-XA : Electronic Arts XA Format

#include <windows.h>
#include "wamain.h"
#include "cube.h"

long EA_XA_TABLE[28] = {0,0,240,0,460,-208,0x0188,-220,
					      0x0000,0x0000,0x00F0,0x0000,
					      0x01CC,0x0000,0x0188,0x0000,
					      0x0000,0x0000,0x0000,0x0000,
					                  -208,-1,-220,-1,
					      0x0000,0x0000,0x0000,0x3F70};

// Platform Values ...
#define EA_PC	0x00
#define EA_PSX	0x01
#define EA_PS2	0x05
#define EA_GC	0x06
#define EA_XBOX	0x07
#define EA_X360 0x09

// Sample Compression Values ..
#define EA_VAG  0x01
#define EA_EAXA	0x0A

unsigned int SwapUnsignedInt(unsigned int x)
{
    return ((x << 24) | ((x & 0xff00) << 8) | ((x & 0xff0000) >> 8) | (x >> 24));
}

// read stuff and increase buffer pointer
// *(*pBuffer) contain the n� of bytes to read
unsigned long readBytes_EAXA(unsigned char ** pBuffer)
{
    unsigned long dwResult = 0;
	int bCount;
	int i;

	bCount=*(*pBuffer)++;

    for (i = 0; i < bCount; i++) {
        dwResult <<= 8;
        dwResult += *(*pBuffer)++;
    }

    return dwResult;
}

// read stuff and increase buffer pointer
int get16bit_EAXA(unsigned char ** pBuffer) {
    short result;
    result = (short)((*(*pBuffer+1) << 8) | *(*pBuffer));
    *pBuffer += 2;
    return result;
}

// read stuff and increase buffer pointer
int get16bitLE_EAXA(unsigned char ** pBuffer) {
    short result;
    result = (short)(((*(*pBuffer)) << 8) | *(*pBuffer+1));
    *pBuffer += 2;
    return result;
}

// convert 32bits value
// depending of the 32bits representation of the origin platform
void convert32bits_EAXA(int* value, CUBEFILE* eaxa) {
	if ((eaxa->ch[0].EAXAPlatform != EA_PC) && 
		(eaxa->ch[0].EAXAPlatform != EA_PS2) &&
	    (eaxa->ch[0].EAXAPlatform != EA_XBOX) && 
		(eaxa->ch[0].EAXAPlatform != EA_PSX))
		(*value)=SwapUnsignedInt(*value);
}

// EA-XA decoding function
void Decode_EAXA_ADPCM(unsigned char ** pBuffer, CUBESTREAM *CurrentChannel)
{
    byte InputByte;
    long lPredictorCoeff1;
    long lPredictorCoeff2;
    int lShift,j;
    long lSample1;
    long lSample2;

    InputByte = *(*pBuffer)++;

    lPredictorCoeff1 = EA_XA_TABLE[((InputByte >> 4) & 0xF) << 1];
    lPredictorCoeff2 = EA_XA_TABLE[(((InputByte >> 4) & 0xF) << 1) + 1];
    lShift = (InputByte & 0x0F) + 8;

    for (j = 0; j < 14; j++)
    {
        InputByte = *(*pBuffer)++;
        lSample1 = ((lPredictorCoeff1 * CurrentChannel->lhist2) + (lPredictorCoeff2 * CurrentChannel->lhist1) + ((((InputByte >> 4) & 0x0F) << 0x1c) >> lShift)) >> 8;

        if (lSample1 < -32768) lSample1 = -32768;
		if (lSample1 > 32767) lSample1 = 32767;

        CurrentChannel->chanbuf[CurrentChannel->writeloc++] = (short)lSample1;

		if (CurrentChannel->writeloc>=BUFFER_SIZE/8*14) CurrentChannel->writeloc=0;

        lSample2 = ((lPredictorCoeff1 * lSample1) + (lPredictorCoeff2 * CurrentChannel->lhist2) + (((InputByte & 0x0F) << 0x1c) >> lShift)) >> 8;
        
		if (lSample2 < -32768) lSample2 = -32768;
		if (lSample2 > 32767) lSample2 = 32767;

		CurrentChannel->chanbuf[CurrentChannel->writeloc++] = (short)lSample2;

		if (CurrentChannel->writeloc>=BUFFER_SIZE/8*14) CurrentChannel->writeloc=0;

        CurrentChannel->lhist1 = lSample1;
        CurrentChannel->lhist2 = lSample2;
    }
}

void Decode_EAXA_Block(unsigned char* pBuffer, CUBESTREAM *channel, int nbSampleToDecode)
{
    int nbSamples = 0;

	int j;

	switch(channel->EAXASampleCompression)
	{
		case EA_EAXA:
  			// Needed for .MUS format 
			// all headers contain samples predictors
			if (channel->GetFromHeader==1) {
				if ((channel->sample_rate == 44100 || channel->EAXAPlatform == EA_PC) || 
					 channel->EAXAPlatform == EA_PS2 || channel->EAXAPlatform== EA_XBOX) {
					channel->lhist2 =  (long)get16bit_EAXA(&pBuffer);
					channel->lhist1 =  (long)get16bit_EAXA(&pBuffer);
				} else {
					channel->lhist2 = (long)get16bitLE_EAXA(&pBuffer);
					channel->lhist1 = (long)get16bitLE_EAXA(&pBuffer);
				}
			}

		    do {
				// Unpacked section with samples predictors
				if (*pBuffer==0xee) {
					pBuffer++;

					channel->lhist2=(long)get16bitLE_EAXA(&pBuffer);
					channel->lhist1=(long)get16bitLE_EAXA(&pBuffer);

					for (j = 0; j < 28; j++) {
						channel->chanbuf[channel->writeloc++] = (short) get16bitLE_EAXA(&pBuffer);
						if (channel->writeloc>=BUFFER_SIZE/8*14) channel->writeloc=0;
					}
					nbSamples += 28;
				} else {
					// The predictors are only set on the first "sample" ...
					if ((get32bit(pBuffer) == 0) && nbSamples==0) {
						if (channel->GetFromHeader==0) {
							channel->GetFromHeader = 1;
							channel->lhist1 = channel->lhist2 = 0;
							pBuffer += 4;
						}
					}
					Decode_EAXA_ADPCM(&pBuffer, channel);
					nbSamples += 28;
				}
		    } while (nbSamples < nbSampleToDecode);
			break;

		case EA_VAG:
			j=0;
			do {
				VAGdecodebuffer(pBuffer+j,channel->chanbuf+channel->writeloc,&channel->hist1, &channel->hist2);
				channel->writeloc+=28;
				if (channel->writeloc>=BUFFER_SIZE/8*14) 
					channel->writeloc=0;
				nbSamples+=28;
				j+=0x10;
			} while (nbSamples < nbSampleToDecode);
			break;
	}

	// Prevent "pop" 
	if((nbSamples>nbSampleToDecode) && (channel->writeloc-nbSamples-nbSampleToDecode>=0))
		channel->writeloc-=(nbSamples-nbSampleToDecode);
}

void ParseTPHeader(unsigned char* pBuffer, CUBEFILE *eaxa, int length)
{
    byte ByteRead;
	unsigned char* pBufferSave=pBuffer;
	
	if(!memcmp(pBuffer,"GSTR",4))
	{
		pBuffer+=8;
		length-=4;
	} else {
		pBuffer+=2;
		eaxa->ch[0].EAXAPlatform = eaxa->ch[1].EAXAPlatform = *(pBuffer++);
	}

	do {
		ByteRead = *pBuffer++;
		
        switch (ByteRead) { // parse header code
            case 0xFF: // end of header
            case 0xFE: // skip
            case 0xFC: // skip
            case 0xFD: // subheader starts...
                break;
            case 0x82:
                eaxa->NCH = readBytes_EAXA(&pBuffer);
                break;
            case 0x83:
                eaxa->EAXACompression = readBytes_EAXA(&pBuffer);
                break;
            case 0x84:
                eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate = (int)readBytes_EAXA(&pBuffer);
                break;
            case 0x85:
                eaxa->nrsamples = readBytes_EAXA(&pBuffer);
                break;
            case 0x86:
                eaxa->ch[0].sa = readBytes_EAXA(&pBuffer);
                break;
            case 0x87:
                eaxa->ch[0].sa = readBytes_EAXA(&pBuffer);
                break;
            case 0x88:
                eaxa->ch[0].interleave=eaxa->ch[1].interleave = readBytes_EAXA(&pBuffer);
                break;
            case 0x8C:
			case 0x9C:
			case 0x9D: // Unknown TAGs ...
                readBytes_EAXA(&pBuffer);
                break;
            case 0x92:
                eaxa->ch[0].bps=eaxa->ch[1].bps = (short)readBytes_EAXA(&pBuffer);
                break;
            case 0x80: 
                eaxa->EAXASplit = (int)readBytes_EAXA(&pBuffer);
                break;
            case 0xA0: // Sample Representation
                eaxa->ch[0].EAXASampleCompression = eaxa->ch[1].EAXASampleCompression = (int)readBytes_EAXA(&pBuffer);
                break;
        }
	} while ((pBuffer-pBufferSave)<=length);
	
	if(eaxa->NCH==0) eaxa->NCH=1;
	if(!CheckSampleRate(eaxa->ch[0].sample_rate))
		eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate=0;
	if((eaxa->ch[0].EAXASampleCompression>0x17) || (eaxa->ch[0].EAXASampleCompression<0))
		eaxa->ch[0].EAXASampleCompression=0x0a;

	//eaxa->nrsamples/=eaxa->NCH;

	// Force no loops
	eaxa->ch[0].sa=eaxa->ch[0].ea=0;
	eaxa->ch[1].sa=eaxa->ch[1].ea=0;
	eaxa->ch[0].loop_flag=0;
}

void fillBufferEAXA(CUBEFILE *eaxa)
{
    unsigned char ADPCMBuf[0x10000];
	unsigned long offset[8];

    int HeaderLength=0;
    int chLeftLength=0;
    int chRightLength=0;
    int nbSamplesToDecode;

	DWORD bytesRead;

	int i;

	SetFilePointer(eaxa->ch[0].infile,eaxa->ch[0].offs,0,FILE_BEGIN);
	ReadFile(eaxa->ch[0].infile, &ADPCMBuf,4,&bytesRead,NULL);

	if (bytesRead == 0)
		return;

	if (!memcmp(ADPCMBuf,"SCDl",4))	
	{
		ReadFile(eaxa->ch[0].infile , &HeaderLength, 4, &bytesRead,NULL);
		ReadFile(eaxa->ch[0].infile , &nbSamplesToDecode, 4, &bytesRead,NULL);
		convert32bits_EAXA(&nbSamplesToDecode,eaxa);
		
		for(i=0; i<eaxa->EAXA_NCH;i++) {
			ReadFile(eaxa->ch[0].infile , &offset[i], 4, &bytesRead,NULL);
			convert32bits_EAXA(&offset[i],eaxa);
		}			

		if(eaxa->ch[0].EAXAPlatform==EA_PSX) {
			nbSamplesToDecode=offset[0];
			offset[0]=0;
			SetFilePointer(eaxa->ch[0].infile,-4,0,FILE_CURRENT);
			HeaderLength-=16;
			offset[1]=HeaderLength/2;
		}
		else
			HeaderLength-=12+(4*eaxa->EAXA_NCH);

		ReadFile(eaxa->ch[0].infile,&ADPCMBuf,HeaderLength,&bytesRead,NULL);

		for(i=0; i<eaxa->NCH;i++) {
			if(i<2)
				Decode_EAXA_Block(ADPCMBuf+offset[i], &eaxa->ch[i], nbSamplesToDecode);
		}
	}
	else if (!memcmp(ADPCMBuf, "SCEl",4))
	{
		// Search for next SCDl
		ReadFile(eaxa->ch[0].infile,&ADPCMBuf, 8192, &bytesRead,NULL);

		for (i = 0; i < 8192 - 4; i++) {
			if (!memcmp(ADPCMBuf+i , "SCDl",4)) {
				SetFilePointer(eaxa->ch[0].infile,- 8192 + i,0,FILE_CURRENT);
				eaxa->ch[0].readloc=eaxa->ch[1].readloc=eaxa->ch[0].writeloc-1;
				break;
			}
		}
	}
	eaxa->ch[0].offs = SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT);
}

int InitEAXA(char * inputfile, CUBEFILE * eaxa)
{
	unsigned char PTHeader[0x2000];
	unsigned char buffer[0x2000];
	unsigned long Offset=0;
	
	CUBEFILE	eaxaSave;

    int  HeaderLength;

	DWORD bytesRead,i;

    eaxa->ch[0].EAXAPlatform = eaxa->ch[1].EAXAPlatform = -1;
	
	// Force EA/XA
	eaxa->ch[0].EAXASampleCompression=eaxa->ch[1].EAXASampleCompression=EA_EAXA;

	if (inputfile) {
		eaxa->ch[0].infile=eaxa->ch[1].infile=INVALID_HANDLE_VALUE;

		eaxa->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

		if (eaxa->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
			return 1;

	} else if (eaxa->ch[0].type!=type_eaxa) return 1; // we don't have the file name to recheck


	eaxa->ch[0].readloc=eaxa->ch[1].readloc=0;
	eaxa->ch[0].writeloc=eaxa->ch[1].writeloc=0;
	eaxa->ch[0].offs=0;

	eaxa->file_length=GetFileSize(eaxa->ch[0].infile,NULL);

    eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate=0;
    eaxa->NCH = 1;

	SetFilePointer(eaxa->ch[0].infile,4,0,FILE_BEGIN);
	ReadFile(eaxa->ch[0].infile,&HeaderLength,4,&bytesRead,NULL);

    
	ReadFile(eaxa->ch[0].infile,&PTHeader,HeaderLength-8,&bytesRead,NULL);

    if (!memcmp(PTHeader, "PT",2) || !memcmp(PTHeader, "GSTR",4) || !memcmp(PTHeader + 4, "PT",2))
    {
		if(!memcmp(PTHeader + 4, "PT",2))
			ParseTPHeader(PTHeader+4, eaxa, (HeaderLength-8));
		else
			ParseTPHeader(PTHeader, eaxa, (HeaderLength-8));

		eaxa->ch[0].sa=eaxa->ch[0].ea=0;
		eaxa->ch[0].loop_flag=0;
		eaxa->ch[0].hist1 = eaxa->ch[0].hist2 = 0;
		eaxa->ch[1].hist1 = eaxa->ch[1].hist2 = 0;

        // if sample rate is not define in the header
        // make it by default to 24khz
		if (eaxa->ch[0].sample_rate == 0) {
			if(eaxa->ch[0].EAXAPlatform==EA_XBOX)
	            eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate = 24000;
			else
				eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate = 22050;
		}

        if (eaxa->ch[0].EAXAPlatform == EA_X360)
            eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate = 44100;

		eaxa->EAXA_NCH=eaxa->NCH;
		if (eaxa->NCH>2) eaxa->NCH=2;

		eaxa->nrsamples=eaxa->nrsamples/(eaxa->NCH==2?1:2);

		if (!strcmpi(inputfile+strlen(inputfile)-4,".eam") && 
			!strcmpi(inputfile+strlen(inputfile)-4,".EAM")) {
			
			unsigned long nbsamples=0;

			// Save stuff ...
			eaxa->ch[0].offs=SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT);
			memcpy(&eaxaSave,eaxa,sizeof(CUBEFILE));

			SetFilePointer(eaxa->ch[0].infile,0,0,FILE_BEGIN);


	        // Skip SCCl Header
			do {
				Offset=SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT);

				ReadFile(eaxa->ch[0].infile,&PTHeader,sizeof(PTHeader),&bytesRead,NULL);
				if((bytesRead==0) || (bytesRead<sizeof(PTHeader)))
					break;
				for(i=0; i<bytesRead;i++) {
					if (!memcmp(PTHeader+i, "PT",2) || !memcmp(PTHeader+i, "GSTR",4)) {
						ParseTPHeader(PTHeader+i, eaxa, (HeaderLength-8));
						nbsamples += eaxa->nrsamples;
					}

					if(!memcmp(PTHeader+i, "SCDl",4)) {
						// Keep track of the first SCDl header
						if(eaxa->ch[0].offs==0) eaxa->ch[0].offs=i;
						
						SetFilePointer(eaxa->ch[0].infile,get32bitL(PTHeader+i+4)-(sizeof(PTHeader)-i) ,0,FILE_CURRENT);
						break;
					}
				}
			} while (SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT)<=eaxa->file_length);

			// Restore ...
			memcpy(eaxa,&eaxaSave,sizeof(CUBEFILE));
			eaxa->nrsamples=nbsamples;
			SetFilePointer(eaxa->ch[0].infile,eaxa->ch[0].offs,0,FILE_BEGIN);
		} 
		
		// Search for first SCDl
		SetFilePointer(eaxa->ch[0].infile,0,0,FILE_BEGIN);
		ReadFile(eaxa->ch[0].infile,&buffer, 0x2000, &bytesRead,NULL);

		for (i = 0; i < 0x2000 - 4; i++) {
			if (!memcmp(buffer+i , "SCDl",4)) {
				eaxa->ch[0].offs = i;
				break;
			}
		}
        eaxa->ch[0].type = type_eaxa;
		eaxa->ch[0].GetFromHeader=eaxa->ch[1].GetFromHeader=0;
		
		// special for PSX
		if(eaxa->ch[0].EAXAPlatform==1)
			eaxa->ch[0].EAXASampleCompression=eaxa->ch[1].EAXASampleCompression=EA_VAG;

		return 0;
    } else {
		CloseCUBEFILE(eaxa);
		return 1;
	}
}
