/*

  in_cube Gamecube Stream Player for Winamp
  by hcs

  includes work by Destop and bero

*/

// not specific to formats

#include <windows.h>
#include "cube.h"

int get16bit(unsigned char* p)
{
	return (p[0] << 8) | p[1];
}

int get32bit(unsigned char* p)
{
	return (p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3];
}

int get16bitL(unsigned char* p)
{
	return p[0] | (p[1] << 8);
}

int get32bitL(unsigned char* p)
{
	return p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
}

void fillbuffers(CUBEFILE * cf) {
	switch (cf->ch[0].type) {
	case type_adx03:
	case type_adx04:
		fillbufferADX(cf);
		break;
	case type_adp:
		fillbufferADP(cf);
		break;
	case type_rsdpcm:
	case type_knon_pcm:
		fillbufferPCM(cf);
		break;
	case type_astpcm:
		fillbufferASTPCM(cf);
		break;
	case type_kraw:
		fillbufferPCM_noint(&cf->ch[0]);
		if (cf->NCH==2)
			fillbufferPCM_noint(&cf->ch[1]);
		break;
	case type_whdpcm:
	case type_rstmpcm_wii:
		fillbufferPCMinterleave(cf);
		break;
	case type_afc:
		fillbufferAFC(cf);
		break;
	case type_astafc:
		fillbufferASTAFC(cf);
		break;
	case type_halp:
		fillbufferHALP(cf);
		break;
	case type_vag:
		if(cf->NCH==1) 
			fillbufferVAG(cf);
		else
			fillbufferVAGinterleave(cf);
		break;
	case type_ads:
	case type_npsf:
	case type_rws:
	case type_rxws:
	case type_svag:
	case type_mib:
	case type_psh:
	case type_vpk:
	case type_musc:
	case type_ccc:
	case type_fag:
	case type_ps2fsb:
	case type_vag_2ch:
	case type_i80:
	case type_i100:
	case type_rstm:
	case type_ass:
	case type_kecs:
	case type_psw:
	case type_rsd6:
	case type_rkv:
	case type_mih:
	case type_gms:
	case type_dxh:
	case type_i400:
	case type_aus:
	case type_fil:
	case type_ster:
	case type_svag_kce:
	case type_leg:
	case type_ild:
	case type_vas:
		fillbufferVAGinterleave(cf);
		break;
	case type_vs:
		fillbufferVS(cf);
		break;
	case type_rsf:
		fillbufferRSF(&cf->ch[0]);
		if (cf->NCH==2)
			fillbufferRSF(&cf->ch[1]);
		break;
	case type_xa:
		fillbufferXA(cf);
		break;
	case type_eaxa:
		fillBufferEAXA(cf);
		break;
	case type_xbox:
	case type_xmu:
	case type_xbfsb:
		fillBufferXBOX(cf);
		break;
	case type_raw:
		fillBufferRAW(cf);
		break;
	case type_int:
		fillBufferRAWInterleave(cf);
		break;
	case type_fsb3wii:
		fillbufferDSPfsb3(cf);
		break;
	case type_strm_nds:
		fillbufferPCM_LE_noint(&cf->ch[0]);
		if (cf->NCH==2)
			fillbufferPCM_LE_noint(&cf->ch[1]);
		break;
	case type_strm_nds_8bits:
		fillbufferPCM_LE_noint8bits(&cf->ch[0]);
		if (cf->NCH==2)
			fillbufferPCM_LE_noint8bits(&cf->ch[1]);
		break;
	case type_thp:
		fillbufferTHP(cf);
		break;
	case type_strm_nds_ima:
		fillbufferIMA(cf);
		break;
	case type_strm_nds_swav:
	case type_ima_fsb:
		fillbufferIMASWAV(cf);
		break;
	case type_riff_ima:
		fillBufferRIFF_IMA(cf);
		break;
	case type_caf:
		fillbufferCAF(cf);
		break;
	case type_gsp_gsb:
		fillbufferGSP(cf);
		break;
	case type_musx:
		fillBufferMUSX(cf);
		break;
	default:
		if (cf->ch[0].interleave) {
			fillbufferDSPinterleave(cf);
		} else {
			fillbufferDSP(&cf->ch[0]);
			if (cf->NCH==2)
				fillbufferDSP(&cf->ch[1]);
		}
	}
}

int InitCUBEFILE(char * fn, CUBEFILE * cf) {
	//if (!InitPCMFILE(fn,&cf) || !InitADPFILE(fn,&cf) || !InitADXFILE(fn,&cf) || !InitDSPFILE(fn,&cf)) return 0;
	return InitRAW(fn,cf) && InitXBOX(fn, cf) && InitRSFFILE(fn,cf) && InitAFCFILE(fn,cf) && InitPCMFILE(fn,cf) && InitADPFILE(fn,cf) && InitADXFILE(fn,cf) && InitVAGFILE(fn,cf) && InitTHPFILE(fn,cf) && InitDSPFILE(fn,cf) && InitXAFile(fn,cf) && InitEAXA(fn, cf);
}

void CloseCUBEFILE(CUBEFILE * cf) {

	if (cf->ch[0].infile != INVALID_HANDLE_VALUE) 
		CloseHandle(cf->ch[0].infile);
	if (cf->ch[1].infile != cf->ch[0].infile && cf->ch[1].infile != INVALID_HANDLE_VALUE) 
		CloseHandle(cf->ch[1].infile);
	memset(cf,0,sizeof(CUBEFILE));
	cf->ch[0].infile=cf->ch[1].infile=INVALID_HANDLE_VALUE;
}

// return true for good sample rate
int CheckSampleRate(int sr) {
	// I got a threshold for the abuse I'll take.
	// (sample rate outside of this range indicates a bad file)
	return !(sr<1000 || sr>96000);
}