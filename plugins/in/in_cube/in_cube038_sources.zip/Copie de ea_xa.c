/*

  EA-XA Stream Player for Winamp
  by Fastelbja

*/

// EA-XA : Electronic Arts XA Format

#include <windows.h>
#include "wamain.h"
#include "cube.h"

int EA_XA_TABLE[28] = {0,0,240,0,460,-208,0x0188,-220,
					      0x0000,0x0000,0x00F0,0x0000,
					      0x01CC,0x0000,0x0188,0x0000,
					      0x0000,0x0000,0x0000,0x0000,
					                  -208,-1,-220,-1,
					      0x0000,0x0000,0x0000,0x3F70};

int SampleRate;
int bTakeRefFromHeader = 0;
int TPBufferOffset=0;

unsigned int ReadBytes(unsigned char* InputBuffer, int bCount)
{
    unsigned int dwResult = 0;
	int i;

    for (i = 0; i < bCount; i++)
    {
        dwResult <<= 8;
        dwResult += InputBuffer[TPBufferOffset++];
    }

    return dwResult;
}

int get16bit_EAXA(unsigned char* InputBuffer, int *Offset)
{
    short result;
    result = (short)((InputBuffer[1 + *Offset] << 8) | InputBuffer[*Offset]);
    *Offset += 2;
    return result;
}

int get16bitLE_EAXA(unsigned char* InputBuffer, int *Offset)
{

    short result;
    result = (short)((InputBuffer[*Offset] << 8) | InputBuffer[1 + *Offset]);
    *Offset += 2;
    return result;
}

void Decode_EAXA_ADPCM(unsigned char* pBuffer, CUBESTREAM *CurrentChannel)
{
    byte InputByte;
    int lPredictorCoeff1;
    int lPredictorCoeff2;
    int lShift,j;
    long lSample1;
    long lSample2;

    InputByte = pBuffer[CurrentChannel->bufferOffset++];

    lPredictorCoeff1 = EA_XA_TABLE[((InputByte >> 4) & 0xF) << 1];
    lPredictorCoeff2 = EA_XA_TABLE[(((InputByte >> 4) & 0xF) << 1) + 1];
    lShift = (InputByte & 0x0F) + 8;

    for (j = 0; j < 14; j++)
    {
        InputByte = pBuffer[CurrentChannel->bufferOffset++];
        lSample1 = ((lPredictorCoeff1 * CurrentChannel->lhist2) + (lPredictorCoeff2 * CurrentChannel->lhist1) + ((((InputByte >> 4) & 0x0F) << 0x1c) >> lShift)) >> 8;

        if (lSample1 < -32768)
			lSample1 = -32768;
		else if (lSample1 > 32767)
            lSample1 = 32767;

        CurrentChannel->chanbuf[CurrentChannel->writeloc++] = (short)lSample1;

		if (CurrentChannel->writeloc>=BUFFER_SIZE/8*14) CurrentChannel->writeloc=0;

        lSample2 = ((lPredictorCoeff1 * lSample1) + (lPredictorCoeff2 * CurrentChannel->lhist2) + (((InputByte & 0x0F) << 0x1c) >> lShift)) >> 8;
        if (lSample2 < -32768)
            lSample2 = -32768;
		else if (lSample2 > 32767)
            lSample2 = 32767;

		CurrentChannel->chanbuf[CurrentChannel->writeloc++] = (short)lSample2;

		if (CurrentChannel->writeloc>=BUFFER_SIZE/8*14) CurrentChannel->writeloc=0;

        CurrentChannel->lhist1 = lSample1;
        CurrentChannel->lhist2 = lSample2;
    }
}


unsigned int Decode_EAXA_Block(unsigned char* pBuffer, CUBESTREAM *channel, int dwBytesToRead)
{
    unsigned int nbSamples = 0;
	int j;

    channel->bufferOffset = 0;

    // Needed for .MUS format
    if (channel->GetFromHeader==1)
    {
        if ((channel->sample_rate == 44100 || channel->format == 0) || channel->format == 5 || channel->format==7)
        {
            channel->lhist2 =  (long)get16bit_EAXA(pBuffer, &channel->bufferOffset);
            channel->lhist1 =  (long)get16bit_EAXA(pBuffer, &channel->bufferOffset);
        }
        else
        {
            channel->lhist2 = (long)get16bitLE_EAXA(pBuffer, &channel->bufferOffset);
            channel->lhist1 = (long)get16bitLE_EAXA(pBuffer, &channel->bufferOffset);
        }
    }

    do
    {
        if ((byte)pBuffer[channel->bufferOffset]==(byte)0xee)
		{
            channel->bufferOffset++;
            channel->lhist2 = (long)get16bitLE_EAXA(pBuffer, &channel->bufferOffset);
            channel->lhist1 = (long)get16bitLE_EAXA(pBuffer, &channel->bufferOffset);
            for (j = 0; j < 28; j++)
            {
                channel->chanbuf[channel->writeloc++] = (short) get16bitLE_EAXA(pBuffer, &channel->bufferOffset);
				if (channel->writeloc>=BUFFER_SIZE/8*14) channel->writeloc=0;
            }
            nbSamples += 28;
		}
		else                
		{
            if (pBuffer[channel->bufferOffset] == 0)
            {
                // Skip bytes used to make block modulo of 4
                if (dwBytesToRead - channel->bufferOffset< 4)
                {
                    channel->bufferOffset++;
                    break;
                }
                // The reference is only set on the first byte ...
                else
                {
                    if ((pBuffer[channel->bufferOffset + 1] == 0)
                     && (pBuffer[channel->bufferOffset + 2] == 0)
                     && (pBuffer[channel->bufferOffset + 3] == 0)
                     && (channel->bufferOffset == 0))
                    {
                        if (channel->GetFromHeader==0)
                        {
                            channel->GetFromHeader = 1;
                            channel->hist1 = 0;
                            channel->hist2 = 0;
                            channel->bufferOffset += 4;
                        }
                    }
                }
            }
            Decode_EAXA_ADPCM(pBuffer, channel);
            nbSamples += 28;
        }
    } while (channel->bufferOffset < dwBytesToRead);
    return nbSamples;
}

unsigned int SwapUnsignedInt(unsigned int x)
{
    return ((x << 24) | ((x & 0xff00) << 8) | ((x & 0xff0000) >> 8) | (x >> 24));
}

void ParseTPHeader(unsigned char* pBuffer, CUBEFILE *eaxa, int length)
{
    byte ByteRead;
    unsigned int dwTemp;
    TPBufferOffset = 0;

    do
    {
        ByteRead = pBuffer[TPBufferOffset++];
        length--;

        switch (ByteRead) // parse header code
        {
            case 0xFF: // end of header
                //length = 0;
                //break;
            case 0xFE: // skip
            case 0xFC: // skip
            case 0xFD: // subheader starts...
                length--;
                break;
            case 0x82:
                ByteRead = (pBuffer[TPBufferOffset++]);
                length -= ByteRead + 1;
                eaxa->NCH = ReadBytes(pBuffer, ByteRead);
                break;
            case 0x83:
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->EAXACompression = (int)ReadBytes(pBuffer, ByteRead);
                break;
            case 0x84:
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate = (int)ReadBytes(pBuffer, ByteRead);
                SampleRate = eaxa->ch[0].sample_rate;
                break;
            case 0x85:
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->nrsamples = ReadBytes(pBuffer, ByteRead)*2;
                break;
            case 0x86:
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->ch[0].sa = ReadBytes(pBuffer, ByteRead);
                break;
            case 0x87:
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->ch[0].sa = ReadBytes(pBuffer, ByteRead);
                break;
            case 0x88:
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->ch[0].interleave=eaxa->ch[1].interleave = ReadBytes(pBuffer, ByteRead);
                break;
            case 0x8C:
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                dwTemp = ReadBytes(pBuffer, ByteRead);
                break;
            case 0x92:
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->ch[0].bps=eaxa->ch[1].bps = ReadBytes(pBuffer, ByteRead);
                break;
            case 0x80: // ???
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->EAXASplit = (int)ReadBytes(pBuffer, ByteRead);
                break;
            case 0xA0: // ???
                ByteRead = pBuffer[TPBufferOffset++];
                length -= ByteRead + 1;
                eaxa->EAXASplitCompression = (int)ReadBytes(pBuffer, ByteRead);
                break;
        }
    } while (length >= 0);
	eaxa->nrsamples/=eaxa->NCH;

	// Force no loops
	eaxa->ch[0].sa=eaxa->ch[0].ea=0;
	eaxa->ch[1].sa=eaxa->ch[1].ea=0;
	eaxa->ch[0].loop_flag=0;
}

void fillBufferEAXA(CUBEFILE *eaxa)
{
    unsigned char ADPCMBuf[0x10000];

    int HeaderLength=0;
    unsigned int C1Offset=0;
    unsigned int C2Offset=0;
    unsigned char Tampon[4];
    int TamponOffset = 2;
    unsigned char Header[4];
    unsigned int nbSamplesToDecode;
    unsigned int nbSamplesDecoded=0;
    unsigned int Offset;
	DWORD bytesRead;
    unsigned char buffer[8192];
    int SCDL_FOUND = 0;
	int i;


	do {

		SetFilePointer(eaxa->ch[0].infile,eaxa->ch[0].offs,0,FILE_BEGIN);
		ReadFile(eaxa->ch[0].infile, &Header,4,&bytesRead,NULL);
		Offset = (long)SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT);

		if (bytesRead == 0)
			return;

		if ((Header[0] == 'S') && (Header[1] == 'C') && (Header[2] == 'D') && (Header[3] == 'l'))
		{
			// Reset Variables ...
			eaxa->ch[0].bufferOffset = 0;
			eaxa->ch[1].bufferOffset = 0;
			
			ReadFile(eaxa->ch[0].infile , &HeaderLength, 4, &bytesRead,NULL);

			if ((eaxa->ch[0].format == 0) || (eaxa->ch[0].format == 5) || (eaxa->ch[0].format == 7))
			{
				ReadFile(eaxa->ch[0].infile , &nbSamplesToDecode, 4, &bytesRead,NULL);
			}
			else
			{
				ReadFile(eaxa->ch[0].infile , &Tampon, 4, &bytesRead,NULL);
				TamponOffset = 2;
				nbSamplesToDecode = (unsigned int)get16bitLE_EAXA(Tampon, &TamponOffset);
			}

			if (eaxa->NCH == 1)
			{
				if (eaxa->ch[0].format == 0 || eaxa->ch[0].format == 5 || eaxa->ch[0].format == 7)
				{
					ReadFile(eaxa->ch[0].infile , &C1Offset, 4, &bytesRead,NULL);
				}
				else
				{
					ReadFile(eaxa->ch[0].infile , &Tampon, 4, &bytesRead,NULL);
					TamponOffset = 2;
					C1Offset = (unsigned int)get16bitLE_EAXA(Tampon, &TamponOffset);
				}
			}
			else
			{
				if (eaxa->ch[0].format == 0 || eaxa->ch[0].format == 5 || eaxa->ch[0].format == 7)
				{
					ReadFile(eaxa->ch[0].infile , &C1Offset, 4, &bytesRead,NULL);
				}
				else
				{
					ReadFile(eaxa->ch[0].infile , &Tampon, 4, &bytesRead,NULL);
					TamponOffset = 2;
					C1Offset = (unsigned int)get16bitLE_EAXA(Tampon, &TamponOffset);
				}

				TamponOffset = 2;
				ReadFile(eaxa->ch[0].infile , &Tampon, 4, &bytesRead,NULL);
				C2Offset = (unsigned int)get16bitLE_EAXA(Tampon, &TamponOffset);
				if (((unsigned int)(C2Offset) > (unsigned int)(HeaderLength)) || C2Offset == 0 || eaxa->ch[0].format == 0)
				{
					if (eaxa->ch[0].format == 0 || eaxa->ch[0].format == 5 || eaxa->ch[0].format == 7)
					{
						SetFilePointer(eaxa->ch[0].infile,-8,0,FILE_CURRENT);
						ReadFile(eaxa->ch[0].infile , &C1Offset, 4, &bytesRead,NULL);
						ReadFile(eaxa->ch[0].infile , &C2Offset, 4, &bytesRead,NULL);
					}
					else
					{
						if (eaxa->ch[0].format == 9) 
						{
							C2Offset = (unsigned int)get32bit(Tampon);
						}
						else
						{
							C1Offset = SwapUnsignedInt(C1Offset);
							C2Offset = SwapUnsignedInt(C2Offset);
						}
					}
				}
			}

			if (eaxa->NCH == 1)
			{
				ReadFile(eaxa->ch[0].infile,&ADPCMBuf,HeaderLength-16,&bytesRead,NULL);
				eaxa->samplesdone += Decode_EAXA_Block(ADPCMBuf, &eaxa->ch[0], (int)(HeaderLength - 16));
			}
			else
			{
				ReadFile(eaxa->ch[0].infile,&ADPCMBuf,C2Offset,&bytesRead,NULL);
				eaxa->samplesdone = Decode_EAXA_Block(ADPCMBuf, &eaxa->ch[0], (int)C2Offset);
				
				if(eaxa->samplesdone!=nbSamplesToDecode)
					eaxa->ch[0].writeloc-=(eaxa->samplesdone-nbSamplesToDecode);

				ReadFile(eaxa->ch[0].infile,&ADPCMBuf,HeaderLength - C2Offset - 20,&bytesRead,NULL);
				eaxa->samplesdone = Decode_EAXA_Block(ADPCMBuf, &eaxa->ch[1], (int)(HeaderLength - C2Offset - 20));

				if(eaxa->samplesdone!=nbSamplesToDecode)
					eaxa->ch[1].writeloc-=(eaxa->samplesdone-nbSamplesToDecode);

			}
		}
		else if ((Header[0] == 'S') && (Header[1] == 'C') && (Header[2] == 'E') && (Header[3] == 'l'))
		{
			// Search for next SCDl
			SCDL_FOUND = 0;

			ReadFile(eaxa->ch[0].infile,&buffer, 8192, &bytesRead,NULL);

			for (i = 0; i < 8192 - 4; i++)
			{
				if ((buffer[i + 0] == 'S') && (buffer[i + 1] == 'C') && (buffer[i + 2] == 'D') && (buffer[i + 3] == 'l'))
				{
					SCDL_FOUND = 1;
					Offset = (SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT) - 8192 + i);
					eaxa->ch[0].readloc=eaxa->ch[1].readloc=eaxa->ch[0].writeloc-1;
					break;
				}
			}
			
		}
		eaxa->ch[0].offs = Offset;
	} while (eaxa->ch[0].writeloc == eaxa->ch[0].readloc);
}

int InitEAXA(char * inputfile, CUBEFILE * eaxa)
{
	unsigned char PTHeader[0x10000];
	unsigned char Header[4];
    int  HeaderLength;
    byte SCCL[4];
	DWORD bytesRead;

    eaxa->ch[0].format = -1;

	if (inputfile) {
		eaxa->ch[0].infile=eaxa->ch[1].infile=INVALID_HANDLE_VALUE;

		eaxa->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

		if (eaxa->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
			return 1;

	} else if (eaxa->ch[0].type!=type_eaxa) return 1; // we don't have the file name to recheck


	eaxa->ch[0].readloc=eaxa->ch[1].readloc=0;
	eaxa->ch[0].writeloc=eaxa->ch[1].writeloc=0;

	eaxa->file_length=GetFileSize(eaxa->ch[0].infile,NULL);

    eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate=0;
    eaxa->NCH = 1;

	SetFilePointer(eaxa->ch[0].infile,4,0,FILE_BEGIN);
	ReadFile(eaxa->ch[0].infile,&HeaderLength,4,&bytesRead,NULL);

    
	ReadFile(eaxa->ch[0].infile,&PTHeader,HeaderLength-8,&bytesRead,NULL);

    if (((PTHeader[0] == 'P') && (PTHeader[1] == 'T')) || ((PTHeader[0] == 'G') && (PTHeader[1] == 'S') && (PTHeader[2] == 'T') && (PTHeader[3] == 'R')))
    {
        if ((PTHeader[0] == 'P') && (PTHeader[1] == 'T'))
            eaxa->ch[0].format = eaxa->ch[1].format= (int)PTHeader[2];
        ParseTPHeader(PTHeader, eaxa, (HeaderLength-8));

		eaxa->ch[0].sa=eaxa->ch[0].ea=0;
		eaxa->ch[0].loop_flag=0;
		eaxa->ch[0].hist1 = eaxa->ch[0].hist2 = 0;
		eaxa->ch[1].hist1 = eaxa->ch[1].hist2 = 0;

        // if sample rate is not define in the header
        // make it by default to 24khz
        if (eaxa->ch[0].sample_rate == 0)
            eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate = 24000;

        if (eaxa->ch[0].format == 0x09)
            eaxa->ch[0].sample_rate=eaxa->ch[1].sample_rate = 44100;

        //if (ADPCMFile.NbOfChannels > 2)
        //    ADPCMFile.NbOfChannels = 2;
		
		if (!strcmpi(inputfile+strlen(inputfile)-4,".eam") && !strcmpi(inputfile+strlen(inputfile)-4,".EAM"))
		{
			unsigned long nbsamples=0;
		 	nbsamples += eaxa->nrsamples;

	        // Skip SCCl Header
			ReadFile(eaxa->ch[0].infile,&SCCL,4,&bytesRead,NULL);
			if ((SCCL[0]== 'S') && (SCCL[1]== 'C') && (SCCL[2]== 'C') && (SCCL[3]== 'l'))
	        {
				SetFilePointer(eaxa->ch[0].infile,8,0,FILE_CURRENT);
				eaxa->ch[0].offs = SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT);
	        }
		    else
				eaxa->ch[0].offs = SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT);

			do 
			{
				ReadFile(eaxa->ch[0].infile,&Header,4,&bytesRead,NULL);
				if(bytesRead==0)
					break;
				if((Header[0] == 'S') && (Header[1] == 'C') && (Header[2] == 'H') && (Header[3] == 'l'))
				{
					// SetFilePointer(eaxa->ch[0].infile,-4,0,FILE_CURRENT);
					ReadFile(eaxa->ch[0].infile,&HeaderLength,4,&bytesRead,NULL);

    
					ReadFile(eaxa->ch[0].infile,&PTHeader,HeaderLength-8,&bytesRead,NULL);

					if (((PTHeader[0] == 'P') && (PTHeader[1] == 'T')) || ((PTHeader[0] == 'G') && (PTHeader[1] == 'S') && (PTHeader[2] == 'T') && (PTHeader[3] == 'R')))
					{
						ParseTPHeader(PTHeader, eaxa, (HeaderLength-8));
						nbsamples += eaxa->nrsamples;
					}
				}

				if((Header[0] == 'S') && (Header[1] == 'C') && (Header[2] == 'D') && (Header[3] == 'l'))
				{
					ReadFile(eaxa->ch[0].infile,&HeaderLength,4,&bytesRead,NULL);
					if ((SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT)+HeaderLength)<=eaxa->file_length)
					{
						SetFilePointer(eaxa->ch[0].infile,HeaderLength-4,0,FILE_CURRENT);
					}
				}

			} while (SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT)<=eaxa->file_length);
			eaxa->nrsamples=nbsamples;
		}
		else
		{

	        // Skip SCCl Header
			ReadFile(eaxa->ch[0].infile,&SCCL,4,&bytesRead,NULL);
			if ((SCCL[0]== 'S') && (SCCL[1]== 'C') && (SCCL[2]== 'C') && (SCCL[3]== 'l'))
	        {
				SetFilePointer(eaxa->ch[0].infile,8,0,FILE_CURRENT);
				eaxa->ch[0].offs = SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT);
	        }
		    else
				eaxa->ch[0].offs = SetFilePointer(eaxa->ch[0].infile,0,0,FILE_CURRENT);
		}

        eaxa->ch[0].type = type_eaxa;
		eaxa->ch[0].GetFromHeader=eaxa->ch[1].GetFromHeader=0;

		return 0;
    }
	else
	{
		CloseCUBEFILE(eaxa);
		return 1;
	}
}

