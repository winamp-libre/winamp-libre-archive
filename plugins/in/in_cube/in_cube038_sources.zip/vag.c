/*

  in_cube Gamecube Stream Player for Winamp
  by hcs

  includes work by Destop and bero

*/

// VAG (Sony "Very Audio Good")

#include <windows.h>
#include "wamain.h"
#include "cube.h"

// inputfile == NULL means file is already opened, just reload
// return 1 if valid VAG not detected, 0 on success
int InitVAGFILE(char * inputfile, CUBEFILE * vag) {
	int l,i;
	unsigned char readbuf[0x80];
	unsigned char mib_buf[0x10];
	unsigned char empty_buf[0x10]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

	int MaskID=0,temp_MaskID=0,temp_id=0;
	char infile[MAX_PATH],infile2[MAX_PATH]; // file name, second file name (for dual-file stereo)
	int dfs=-1; // dual-file stereo (0 if we have the name of left channel, 1 if right)
	char * ext, * ext2;
	unsigned char tempbuffer[0x4000];
	unsigned long length;
	unsigned long readOffset=0;
	
	HANDLE mihFile=0;

	vag->loopsamplesdone=0;
	vag->samplesdone=0;
	vag->uncompressed=0;
	vag->loop_end_offset=0;
	vag->loop_start_offset=0;
	vag->ch[0].offs=0;
	vag->ch[0].hist1 = vag->ch[0].hist2 = 0;
	vag->ch[1].hist1 = vag->ch[1].hist2 = 0;
	vag->ch[0].readloc=vag->ch[1].readloc=0;
	vag->ch[0].writeloc=vag->ch[1].writeloc=0;
	vag->ch[0].bps=vag->ch[1].bps=8;
	vag->ch[0].ea=vag->ch[0].sa=0;
	vag->ch[1].ea=vag->ch[1].sa=0;
	vag->ch[0].loop_flag=vag->ch[1].loop_flag=0;

	if (inputfile) {
		vag->ch[0].infile=vag->ch[1].infile=INVALID_HANDLE_VALUE;

		//if (strcmpi(inputfile+strlen(inputfile)-4,".vag")) return 1;

		vag->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

		if (vag->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
			return 1;

	} else if (vag->ch[0].type!=type_vag) return 1; // we don't have the file name to recheck

	vag->file_length=GetFileSize(vag->ch[0].infile,NULL);
	vag->ch[1].infile=vag->ch[0].infile;
	
	length=vag->file_length;

	// Check by extension ...
	if ((!strcmpi(inputfile+strlen(inputfile)-4,".mib") && !strcmpi(inputfile+strlen(inputfile)-4,".MIB")) || 
		(!strcmpi(inputfile+strlen(inputfile)-4,".mi4") && !strcmpi(inputfile+strlen(inputfile)-4,".MI4")) || 
		(!strcmpi(inputfile+strlen(inputfile)-4,".xag") && !strcmpi(inputfile+strlen(inputfile)-4,".XAG")))
	{
		// Search for .MIH
		strcpy(infile,inputfile);
		infile[strlen(infile)-3]='M';
		infile[strlen(infile)-2]='I';
		infile[strlen(infile)-1]='H';
		mihFile = CreateFile(infile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if(mihFile!=INVALID_HANDLE_VALUE)
		{
			ReadFile(mihFile, &readbuf, 0x80,&l,NULL);
            vag->NCH = get32bitL(readbuf + 0x08);
			vag->ch[0].sample_rate = vag->ch[1].sample_rate = get32bitL(readbuf + 0x0C);
			vag->ch[0].interleave = vag->ch[1].interleave = get32bitL(readbuf + 0x10);
            vag->ch[0].type = type_mib;
            vag->nrsamples =(vag->file_length/16*14);
			vag->ch[0].sa = get32bitL(readbuf + 0x14)*28;
			vag->ch[0].ea = (get32bitL(readbuf + 0x04)*2)/16*28/2;
			vag->ch[0].loop_flag=0; //!(vag->ch[0].sa==0);
			vag->ch[0].chanstart=0;
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
			vag->ch[0].type=type_mih;

			if(vag->ch[0].interleave==0) {
				// try to catch the interleave ...
				ReadFile(vag->ch[0].infile, &MaskID, 4,&l,NULL);
				SetFilePointer(vag->ch[0].infile,0x0c,0,FILE_CURRENT);
				vag->ch[0].interleave=0;
				
				do
				{
					//lblInterleave.Text = "Searching Interleave @ 0x" + m_ADPCMFile.Interleave.ToString("x");
					//Application.DoEvents();

					ReadFile(vag->ch[0].infile, &temp_MaskID, 4,&l,NULL);

					vag->ch[0].interleave += 0x10;
	            
					if (SetFilePointer(vag->ch[0].infile,0,0,FILE_CURRENT) >= (vag->file_length))
						break;

				} while (!((temp_MaskID == MaskID) && (temp_id == 0)));

				if ((vag->ch[0].interleave <=(long)(vag->file_length - 0x20))
					&& (vag->ch[0].interleave >= 0x10) && (vag->ch[0].interleave <= 0x20000))
				{
					vag->ch[1].interleave=vag->ch[0].interleave;
				} else
					return 1;
			}
		}
		else
		{
		
			// try to catch the interleave ...
			if (!strcmpi(inputfile+strlen(inputfile)-4,".xag") && !strcmpi(inputfile+strlen(inputfile)-4,".XAG")) {
				vag->ch[0].sample_rate=48000;
				vag->ch[0].interleave=0x4000;
			} else {
				SetFilePointer(vag->ch[0].infile,0x0,0,FILE_BEGIN);
				ReadFile(vag->ch[0].infile, &mib_buf, 0x10,&l,NULL);
				vag->ch[0].interleave=0;
				
				do
				{
					//lblInterleave.Text = "Searching Interleave @ 0x" + m_ADPCMFile.Interleave.ToString("x");
					//Application.DoEvents();

					ReadFile(vag->ch[0].infile, &mib_buf, 0x10,&l,NULL);
					vag->ch[0].interleave += 0x10;
	            
					if (SetFilePointer(vag->ch[0].infile,0,0,FILE_CURRENT) >= (vag->file_length))
						break;

				} while (memcmp(mib_buf,empty_buf,0x10));
			}
			
			if ((vag->ch[0].interleave <=(long)(vag->file_length - 0x10))
				&& (vag->ch[0].interleave >= 0x10))
			{
				if((long)vag->file_length-vag->ch[0].interleave==0x10) {
					// force 16k ... just to handle kick ass samples (voices & sfx)
					vag->NCH=1;
					vag->ch[0].sample_rate=44100; // which is really arbitary :(
				} else {
					vag->NCH=2;
					if ((!strcmpi(inputfile+strlen(inputfile)-4,".mi4") && !strcmpi(inputfile+strlen(inputfile)-4,".MI4")) || 
						(!strcmpi(inputfile+strlen(inputfile)-4,".xag") && !strcmpi(inputfile+strlen(inputfile)-4,".XAG")))
						vag->ch[0].sample_rate=48000;
					else
						vag->ch[0].sample_rate=44100;
				}

				vag->ch[0].type = type_mib;
				vag->ch[1].interleave=vag->ch[0].interleave;
				vag->ch[0].offs = 0; //0x10;
				vag->nrsamples = ((vag->file_length / 16) * 28)/vag->NCH;
				vag->ch[0].chanstart=0;
				vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;

				// Search for loop values ...
				SetFilePointer(vag->ch[0].infile,0,0,FILE_BEGIN);
				vag->ch[0].sa=vag->ch[1].sa=0;
				vag->ch[0].ea=vag->ch[1].ea=0;

				do {
					if(length>0x4000) 
						ReadFile(vag->ch[0].infile,tempbuffer,0x4000,&l,NULL);
					else
						ReadFile(vag->ch[0].infile,tempbuffer,length,&l,NULL);
					
					for(i=0; i<l;i+=0x10) {
						if(tempbuffer[i+1]==0x06) {
							if(vag->ch[0].sa==0) {
								vag->loop_start_offset=readOffset+i;
								vag->ch[0].sa=(((readOffset+i)/ 16) * 28)/vag->NCH;
								vag->ch[0].loop_flag=1;
								break;
							}
						}
						if(tempbuffer[i+1]==0x01) {
							vag->loop_start_offset=vag->ch[0].chanstart;
							vag->loop_end_offset=readOffset+i;
							vag->ch[0].sa=0;
							vag->ch[0].loop_flag=1;
							break;
						}
					}

					readOffset+=l;
					length-=l;
				} while (length>0);
				
				vag->ch[0].ea=vag->nrsamples;
				vag->ch[0].bps=vag->ch[1].bps=8;
			}
		}
	} else if (!strcmpi(inputfile+strlen(inputfile)-4,".mic") && !strcmpi(inputfile+strlen(inputfile)-4,".MIC")) {
		ReadFile(vag->ch[0].infile, readbuf, 0x80,&l,NULL);

		vag->ch[0].chanstart=get32bitL(readbuf);
        vag->NCH = get32bitL(readbuf + 0x08);
		vag->ch[0].sample_rate = vag->ch[1].sample_rate = get32bitL(readbuf + 0x0C);
		vag->ch[0].interleave = vag->ch[1].interleave = get32bitL(readbuf + 0x10);
        vag->ch[0].type = type_mib;
        vag->nrsamples = get32bitL(readbuf + 0x10)*14*vag->NCH;
		vag->ch[0].sa = get32bitL(readbuf + 0x14);
		vag->ch[0].ea = get32bitL(readbuf + 0x10)*28;
		vag->ch[0].loop_flag= !(vag->ch[0].sa==0);
		vag->ch[0].type=type_mih;

		if(!CheckSampleRate(vag->ch[0].sample_rate)) {
			vag->ch[0].sample_rate = vag->ch[1].sample_rate = get32bitL(readbuf + 0x04);
			vag->ch[0].interleave = vag->ch[1].interleave = get32bitL(readbuf + 0x0C);
			vag->ch[0].loop_flag = 0;
			
			if(vag->ch[0].sa != 1) {
				vag->ch[0].loop_flag=1;
				vag->ch[0].sa*=28;
			}
		}

		vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
	}
	 else if (!strcmpi(inputfile+strlen(inputfile)-4,".VAS") && !strcmpi(inputfile+strlen(inputfile)-4,".VAS")) {
		ReadFile(vag->ch[0].infile, readbuf, 0x80,&l,NULL);

		vag->ch[0].chanstart=0x800;
        vag->NCH = 2;
		vag->ch[0].sample_rate = vag->ch[1].sample_rate = get32bitL(readbuf + 0x04);
		vag->ch[0].interleave = vag->ch[1].interleave = 0x200;
        vag->ch[0].type = type_vas;
        vag->nrsamples = get32bitL(readbuf)/16*28/vag->NCH;
		vag->ch[0].sa = get32bitL(readbuf + 0x14)/16*28/vag->NCH;
		vag->ch[0].ea = vag->nrsamples;
		vag->ch[0].loop_flag= !(vag->ch[0].sa==0);
		vag->ch[0].type=type_vas;
		vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".ccc") && !strcmpi(inputfile+strlen(inputfile)-4,".CCC"))
	{
		ReadFile(vag->ch[0].infile, readbuf, 0x80,&l,NULL);
        if ((get32bitL(readbuf+0x40) == (int)0xCCCCCCCC) && 
			(get32bitL(readbuf+0x44) == (int)0xCCCCCCCC) && 
			(get32bitL(readbuf+0x48) == (int)0xCCCCCCCC) && 
			(get32bitL(readbuf+0x4C) == (int)0xCCCCCCCC))
        {
            vag->NCH = 2;
			vag->ch[0].loop_flag=0;
            vag->ch[0].type = type_ccc;
            vag->ch[0].sample_rate = vag->ch[1].sample_rate = get32bitL(readbuf + 0x04);
            vag->ch[0].interleave = vag->ch[1].interleave = 0x2000;
            vag->ch[0].chanstart = 0x50;
			vag->ch[1].chanstart = 0x2050;
            vag->nrsamples =(get32bitL(readbuf+0x08)/16)*28/2;
        }
		else
		{
			CloseCUBEFILE(vag);
			return 1;
		}
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".ass") && !strcmpi(inputfile+strlen(inputfile)-4,".ASS"))
	{
		ReadFile(vag->ch[0].infile, readbuf, 0x80,&l,NULL);
        if ((get32bitL(readbuf+0x00) <= 0x02) && 
			(get32bitL(readbuf+0x04) != 0) && 
			(get32bitL(readbuf+0x04) <= (int)0xbb80))
        {
            vag->NCH = get32bitL(readbuf+0x00);
			vag->ch[0].loop_flag=0;
            vag->ch[0].type = type_ass;
            vag->ch[0].sample_rate = vag->ch[1].sample_rate = get32bitL(readbuf + 0x04);
			
			vag->nrsamples = (get32bitL(readbuf + 0x08)/16)*28;

            vag->ch[0].interleave = vag->ch[1].interleave = get32bitL(readbuf + 0x0C);
            vag->ch[0].chanstart = 0x800;
			vag->ch[1].chanstart = vag->ch[0].chanstart + vag->ch[0].interleave;
        }
		else
		{
			CloseCUBEFILE(vag);
			return 1;
		}
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".tgt") && !strcmpi(inputfile+strlen(inputfile)-4,".TGT"))
	{
        vag->NCH = 2;
		vag->ch[0].loop_flag=0;
        vag->ch[0].type = type_svag;
        vag->ch[0].sample_rate = vag->ch[1].sample_rate = 44100;
        vag->ch[0].interleave = vag->ch[1].interleave = 0x400;
        vag->ch[0].chanstart = 0x0;
		vag->ch[1].chanstart = 0x400;
        vag->nrsamples =((vag->file_length)/16)*28/2;
		SetFilePointer(vag->ch[0].infile,vag->file_length-0x10,0,FILE_BEGIN);
		ReadFile(vag->ch[0].infile, readbuf, 0x4,&l,NULL);
        if (get16bitL(readbuf) != (int)0x0c)
		{
			vag->ch[0].sa=vag->ch[1].sa=0;
			vag->ch[0].loop_flag=1;
			vag->ch[0].ea=vag->ch[1].ea=vag->file_length;		
		}
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-3,".vs") && !strcmpi(inputfile+strlen(inputfile)-3,".VS"))
	{
		ReadFile(vag->ch[0].infile, readbuf, 0x80,&l,NULL);
        if (get32bitL(readbuf) == (int)0x000000C8)
        {
            vag->ch[0].type= type_vs;
            vag->ch[0].chanstart = 0x08;
            vag->NCH = 2;
            vag->ch[0].sample_rate=vag->ch[1].sample_rate = get32bitL(readbuf+0x04);
            vag->nrsamples=(vag->file_length/16)*28/2;
            vag->ch[0].interleave = vag->ch[1].interleave = get32bitL(readbuf+0x08);
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
        }
		else
		{
			CloseCUBEFILE(vag);
			return 1;
		}
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".fag") && !strcmpi(inputfile+strlen(inputfile)-4,".FAG"))
	{
		ReadFile(vag->ch[0].infile, readbuf, 0x80,&l,NULL);

        if (get32bitL(readbuf) == (int)0x00000001)
		{
            vag->ch[0].type = type_fag;
            vag->nrsamples = ((vag->file_length-0x800) / 16) * 28/2;
            vag->NCH = 2;
            vag->ch[0].sample_rate=vag->ch[1].sample_rate = 24000;
            vag->ch[0].chanstart=0x800;
            vag->ch[0].interleave=vag->ch[1].interleave= 0x8000;
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
        }
		else
		{
			CloseCUBEFILE(vag);
			return 1;
		}
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".leg") && !strcmpi(inputfile+strlen(inputfile)-4,".LEG"))
	{
		ReadFile(vag->ch[0].infile, readbuf, 0x80,&l,NULL);

        vag->ch[0].type = type_leg;
        vag->nrsamples = ((vag->file_length-0x4c) / 16) * 28/2;
        vag->NCH = 2;
        vag->ch[0].sample_rate=vag->ch[1].sample_rate = get32bitL(readbuf+0x40);
        vag->ch[0].chanstart=0x4c;
        vag->ch[0].interleave=vag->ch[1].interleave= 0x400;
		vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
		vag->ch[0].sa=vag->ch[1].sa=get32bitL(readbuf+0x44)*0x400*28/16;
		vag->ch[0].ea=vag->ch[1].ea=get32bitL(readbuf+0x48)*0x400*28/16;
		vag->ch[0].loop_flag=(vag->ch[0].sa!=0);
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".psh") && !strcmpi(inputfile+strlen(inputfile)-4,".PSH"))
	{
		ReadFile(vag->ch[0].infile, &MaskID, 4,&l,NULL);
        if ((MaskID & 0xff00ff00) == 0x00004000)
        {
			ReadFile(vag->ch[0].infile,readbuf,0x80,&l,NULL);
            vag->NCH = 2;
			// Have to check the loop point for this one ...
			vag->ch[0].ea=vag->ch[1].sa=get16bitL(readbuf+0x08)*0x400*28/16;
			if(get16bitL(readbuf+0x02)==0) {
				vag->ch[0].loop_flag=vag->ch[1].loop_flag=0;
			} else {
				vag->ch[0].sa=vag->ch[1].ea=(get16bitL(readbuf+0x02) - 0x8000)*0x400*28/16;
				vag->ch[0].loop_flag = 1;
			}
			//vag->ch[0].ea = (get16bit(readbuf) * 0x20) + 0x800;
			//vag->ch[0].sa = (get16bit(readbuf+0x02) << 1) ;
            
			//vag->ch[0].loop_flag=0;
            vag->ch[0].type = type_psh;
            vag->ch[0].sample_rate = vag->ch[1].sample_rate = (u32)get16bitL(readbuf + 0x04);
            vag->ch[0].interleave = vag->ch[1].interleave = 0x800;
            vag->ch[0].chanstart = 0x0;
			vag->ch[1].chanstart = 0x800;
            vag->nrsamples = ((vag->file_length / 16) * 28)/2;
        }
		else
		{
			CloseCUBEFILE(vag);
			return 1;
		}
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".i80") && !strcmpi(inputfile+strlen(inputfile)-4,".I80"))
	{
        vag->NCH = 2;
		vag->ch[0].loop_flag=0;
        vag->ch[0].type = type_i80;
        vag->ch[0].sample_rate = vag->ch[1].sample_rate = 44100;
        vag->ch[0].interleave = vag->ch[1].interleave = 0x800;
        vag->ch[0].chanstart = 0x0;
		vag->ch[1].chanstart = 0x800;
        vag->nrsamples = ((vag->file_length / 16) * 28)/2;
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-5,".i100") && !strcmpi(inputfile+strlen(inputfile)-5,".I100"))
	{
		// i know this kind of code sucks, but as their is no header
		// i don't know how to do ... :(
        vag->NCH = 2;
		vag->ch[0].loop_flag=0;
        vag->ch[0].type = type_i100;
        vag->ch[0].sample_rate = vag->ch[1].sample_rate = 32000;
        vag->ch[0].interleave = vag->ch[1].interleave = 0x1000;
        vag->ch[0].chanstart = 0x0;
		vag->ch[1].chanstart = 0x1000;
        vag->nrsamples = ((vag->file_length / 16) * 28)/2;
	} else if (!strcmpi(inputfile+strlen(inputfile)-5,".i400") && !strcmpi(inputfile+strlen(inputfile)-5,".I400"))
	{
		// i know this kind of code sucks, but as their is no header
		// i don't know how to do ... :(
        vag->NCH = 2;
        vag->ch[0].type = type_i400;
        vag->ch[0].sample_rate = vag->ch[1].sample_rate = 44100;
        vag->ch[0].interleave = vag->ch[1].interleave = 0x4000;
        vag->ch[0].chanstart = 0x0;
		vag->ch[1].chanstart = 0x4000;
        vag->nrsamples = ((vag->file_length / 16) * 28)/2;

		// Search for loop values ...
		SetFilePointer(vag->ch[0].infile,0,0,FILE_BEGIN);
		vag->ch[0].sa=vag->ch[1].sa=0;
		vag->ch[0].ea=vag->ch[1].ea=0;

		do {
			if(length>0x4000) 
				ReadFile(vag->ch[0].infile,tempbuffer,0x4000,&l,NULL);
			else
				ReadFile(vag->ch[0].infile,tempbuffer,length,&l,NULL);
			
			for(i=0; i<l;i+=0x10) {
				if(tempbuffer[i+1]==0x06) {
					if(vag->ch[0].sa==0) {
						vag->loop_start_offset=readOffset+i;
						vag->ch[0].sa=(((readOffset+i)/ 16) * 28)/vag->NCH;
						break;
					}
				}
			}

			readOffset+=l;
			length-=l;
		} while (length>0);
				
		vag->ch[0].loop_flag=vag->ch[0].sa!=0;
		vag->ch[0].ea=vag->ch[1].ea=vag->file_length;		
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".gms") && !strcmpi(inputfile+strlen(inputfile)-4,".GMS"))
	{
		// i know this kind of code sucks, but as their is no header
		// i don't know how to do ... :(
		ReadFile(vag->ch[0].infile, readbuf, 0x80,&l,NULL);
        vag->NCH = get32bitL(readbuf);
        vag->nrsamples = (vag->file_length-0x800)/16*(14*vag->NCH);
        vag->ch[0].type = type_gms;
        vag->ch[0].sample_rate = vag->ch[1].sample_rate = get32bitL(readbuf+0x04);
        vag->ch[0].interleave = vag->ch[1].interleave = 0x800;
        vag->ch[0].chanstart = 0x800;
		vag->ch[1].chanstart = 0x1000;
		vag->loop_start_offset=get32bitL(readbuf+0x10);
		vag->loop_end_offset=get32bitL(readbuf+0x18);
		vag->ch[0].sa=vag->ch[1].sa=get32bitL(readbuf+0x14);
		vag->ch[0].ea=vag->ch[1].ea=get32bitL(readbuf+0x1c);
		vag->ch[0].loop_flag=(get32bitL(readbuf+0x20)==0);
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".psw") && !strcmpi(inputfile+strlen(inputfile)-4,".PSW"))
	{
		ReadFile(vag->ch[0].infile,readbuf,0x80,&l,NULL);

		if ((!memcmp(readbuf,"RIFF",4)) && (!memcmp(readbuf+ 0x08,"WAVEfmt ",8)))
		{
			if ((get16bitL(readbuf + 0x14)==0xffff) && (get32bitL(readbuf+0x10)==0x0012))
			{
				vag->NCH = get16bitL(readbuf + 0x16);
				vag->ch[0].loop_flag=0;
				vag->ch[0].type = type_psw;
				vag->ch[0].sample_rate = vag->ch[1].sample_rate = get16bitL(readbuf + 0x18);
				vag->ch[0].interleave = vag->ch[1].interleave = 0x6400;
				vag->ch[0].chanstart = 0x2e;
				vag->ch[1].chanstart = vag->ch[0].chanstart + vag->ch[0].interleave;
				vag->nrsamples = ((get32bitL(readbuf + 0x04) / 16) * 28)/2;
			}
		}
	}
	else if (!strcmpi(inputfile+strlen(inputfile)-4,".rkv") && !strcmpi(inputfile+strlen(inputfile)-4,".RKV"))
	{
		ReadFile(vag->ch[0].infile,readbuf,0x80,&l,NULL);

		if ((get32bitL(readbuf)==0) && ((get32bitL(readbuf+ 0x10)==0) || (get32bitL(readbuf+ 0x10)==1)))
		{
			if ((get32bitL(readbuf + 0x04)>=11025) && (get32bitL(readbuf+0x04)<=44100))
			{
				vag->NCH = get16bitL(readbuf + 0x10)+1;
				vag->ch[0].type = type_rkv;
				vag->ch[0].sample_rate = vag->ch[1].sample_rate = get16bitL(readbuf + 0x04);
				vag->ch[0].interleave = vag->ch[1].interleave = 0x400;

				vag->ch[0].loop_flag=0;
				vag->ch[0].sa=get32bitL(readbuf + 0x08);
				vag->ch[0].ea=(get32bitL(readbuf + 0x0c)*16/28);

				if (vag->ch[0].sa==0xFFFFFFFF)
					vag->ch[0].loop_flag=0;
//				else
//					vag->ch[0].sa;

				vag->ch[0].chanstart = 0x800;
				vag->ch[1].chanstart = vag->ch[0].chanstart + vag->ch[0].interleave;
				vag->nrsamples = get32bitL(readbuf + 0x0c);
			}
		}
	}
	else
	{
		ReadFile(vag->ch[0].infile,readbuf,0x80,&l,NULL);
		
		if (!memcmp(readbuf,"VAGp",4)) {
			vag->ch[0].type=type_vag;
			if(get32bit(readbuf+0x04)==0x04) {
				vag->ch[0].sa=get32bit(readbuf+0x14);
				vag->ch[0].ea=get32bit(readbuf+0x18);
				vag->ch[0].loop_flag=(vag->ch[0].sa!=0);
				vag->ch[0].chanstart=0x80;
				vag->NCH = 2;
			} else {
				vag->ch[0].chanstart=0x40;
				vag->NCH = 1;
				vag->ch[0].loop_flag=0;
			}
			vag->ch[0].sample_rate = get32bit(readbuf+0x10);
			vag->ch[0].interleave=vag->ch[1].interleave=0x10;
			vag->nrsamples = get32bit(readbuf+0xc)*28/16/vag->NCH;

			if(!strcmpi(inputfile+strlen(inputfile)-11,"_LOOPED.VAG")) {
				vag->ch[0].loop_flag=vag->ch[1].loop_flag=1;
				vag->ch[0].sa=0;
				vag->ch[0].ea=vag->file_length;
			} else {
				if(vag->ch[0].sa==0) {
					// Search for loop values ...
					SetFilePointer(vag->ch[0].infile,0,0,FILE_BEGIN);
					vag->ch[0].sa=vag->ch[1].sa=0;
					vag->ch[0].ea=vag->ch[1].ea=0;

					do {
						if(length>0x4000) 
							ReadFile(vag->ch[0].infile,tempbuffer,0x4000,&l,NULL);
						else
							ReadFile(vag->ch[0].infile,tempbuffer,length,&l,NULL);
						
						for(i=0; i<l;i+=0x10) {
							if(tempbuffer[i+1]==0x06) {
								if(vag->ch[0].sa==0) {
									vag->loop_start_offset=readOffset+i;
									vag->ch[0].sa=(((readOffset+i)/ 16) * 28)/vag->NCH;
									vag->ch[0].ea=vag->nrsamples;
									vag->ch[0].loop_flag=(vag->ch[0].sa!=0);
									break;
								}
							}
						}

						readOffset+=l;
						length-=l;
					} while (length>0);
				}				
			}

			// Dual file stereo
			strcpy(infile,inputfile);
			ext=strrchr(infile,'.')+1;
			strcpy(infile2,infile);
			ext2=ext-infile+infile2;
			ext2[-1]='\0';
			if (!strcmpi(ext2-2,"L")) { 
				ext2[-2]='R';
				dfs=0;
			} else if (!strcmpi(ext2-2,"R")) {
				ext2[-2]='L';
				dfs=1;
			} 

			infile2[strlen(infile2)]='.';
			
			if (dfs==0) { // left channel already opened, load right
				vag->ch[1].infile=CreateFile(infile2,GENERIC_READ,
				FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
				
				if (vag->ch[1].infile==INVALID_HANDLE_VALUE) 
					vag->ch[1].infile=vag->ch[0].infile;
			} else if (dfs==1) { // right channel already opened, load left
				vag->ch[1].infile=vag->ch[0].infile;
				vag->ch[0].infile=CreateFile(infile2,GENERIC_READ,
				FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
				
				if (vag->ch[0].infile==INVALID_HANDLE_VALUE) 
					vag->ch[0].infile=vag->ch[1].infile;
			} else vag->ch[1].infile=vag->ch[0].infile;

			if (vag->ch[0].infile!=vag->ch[1].infile)
			{
				if(vag->ch[0].loop_flag)
					vag->ch[0].ea=vag->ch[1].ea=vag->nrsamples/vag->NCH;

				vag->ch[0].type=type_vag_2ch;
				vag->NCH=2;
				vag->ch[1].sample_rate=vag->ch[0].sample_rate;
				vag->ch[1].chanstart=vag->ch[0].chanstart;
				vag->ch[0].interleave=vag->ch[1].interleave=0x10;
			}


		} else if (!memcmp(readbuf,"SShd",4) && !memcmp(readbuf+0x20,"SSbd",4)) {

			vag->ch[0].type=type_ads;
			vag->uncompressed=(get32bitL(readbuf+0x08) != 0x10);
			vag->NCH = get32bitL(readbuf+0x10);
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bitL(readbuf+0xc);
		    
			vag->ch[1].interleave=vag->ch[0].interleave=get32bitL(readbuf+0x14);

			if((get32bitL(readbuf+0x28)==0) && (get32bitL(readbuf+0x38)==0) && !vag->uncompressed) {
				vag->ch[0].interleave=vag->ch[1].interleave=0x400;
				vag->ch[0].chanstart=0x800;
				vag->ch[1].chanstart=0x800+vag->ch[0].interleave;
			} else {

				vag->ch[0].chanstart=0x28;
				vag->ch[1].chanstart=0x28+vag->ch[0].interleave;
			}
			if (vag->uncompressed==0)
				vag->nrsamples = get32bitL(readbuf+0x24)*28/16/vag->NCH;
			else
				vag->nrsamples = get32bitL(readbuf+0x24)/(2*vag->NCH);

			// mmm... not sure of the loop flag :P
			vag->ch[0].sa=get32bitL(readbuf+0x18)*28/16;
			vag->loop_start_offset=get32bitL(readbuf+0x18)*0x20;
			vag->loop_end_offset=get32bitL(readbuf+0x1c)*0x20;
			vag->ch[0].ea=vag->nrsamples;
			if(vag->ch[0].sa!=0xffffffff)
				vag->ch[0].loop_flag = vag->ch[1].loop_flag = (vag->ch[0].sa<vag->ch[0].ea);

		} else if(!memcmp(readbuf, "AUS ", 4)) {
			// MegaMan Anniversary Collection (PS2)
			// MarkGrass - February 21, 2008
			vag->NCH = get32bitL(readbuf+0xC);
			if(vag->NCH == 1) vag->nrsamples = (vag->file_length*28/16) - (0x7F0*28/16);
			else vag->nrsamples = (vag->file_length*28/16) / 2 - (0x7F0*28/16);

			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bitL(readbuf+0x10);
			vag->ch[1].loop_flag = vag->ch[0].loop_flag = 0;
			vag->ch[1].type = vag->ch[0].type = type_aus;

			vag->ch[1].interleave = vag->ch[0].interleave = 0x800;
			vag->ch[0].chanstart = 0x7F0;
			vag->ch[1].chanstart = vag->ch[0].interleave;

		} else if(!memcmp(readbuf, "STER", 4)) {
			// STER
			vag->nrsamples = (get32bitL(readbuf+0x04)*28/16); //get32bitL(readbuf+0x04)*2;
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bit(readbuf+0x10);
			vag->ch[1].type = vag->ch[0].type = type_ster;

			vag->ch[0].interleave = vag->ch[1].interleave = 0x10;
			vag->ch[0].chanstart = 0x50;
			vag->ch[1].chanstart = vag->ch[0].chanstart + vag->ch[0].interleave;

			vag->ch[0].sa=vag->ch[1].sa=get32bitL(readbuf+0x08);
			vag->ch[0].ea=vag->ch[1].ea=vag->nrsamples;
			
			vag->ch[0].loop_flag=vag->ch[1].loop_flag=(vag->ch[0].sa!=0xFFFFFFFF);
			vag->ch[0].sa=vag->ch[1].sa=(get32bitL(readbuf+0x08))*28/16/2;
			vag->NCH = 2;

		} else if(!memcmp(readbuf, "FILp", 4)) {
			// Resident Evil Dead Aim
			// MarkGrass - February 22, 2008
			vag->NCH = 2;
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = 32000;
			vag->ch[1].loop_flag = vag->ch[0].loop_flag = 0;
			vag->file_length = get32bitL(readbuf+0xC);
			vag->ch[1].type = vag->ch[0].type = type_fil;

			vag->head_amount = get32bitL(readbuf+0x10);
			vag->nexthalp = get32bitL(readbuf+0x18);

			vag->nrsamples = ((vag->file_length*28/16) / 2 - ((0x800*28/16) * (vag->head_amount - 1)));

			vag->ch[1].interleave = vag->ch[0].interleave = get32bitL(readbuf+0x20);
			vag->ch[0].chanstart = 0x800;
			vag->ch[1].chanstart = (get32bitL(readbuf+0x20)/0x800) + 0x800;

		} else if(!memcmp(readbuf, "NPSF", 4)) {
			// Namco Ace Combat Radio & BGM format
			vag->ch[0].type=type_npsf;
			vag->NCH = get32bitL(readbuf+0xc);
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bitL(readbuf+0x18);

			// 2007-11-11 - Fastelbja : nrsamples count fixed
			vag->nrsamples = get32bitL(readbuf+0x8)*28/16;

			// 2007-11-11 - Fastelbja : interleave (*2) is on 0x04 
			vag->ch[1].interleave=vag->ch[0].interleave=get32bitL(readbuf+0x04)/2;

			// HACK
			if(vag->NCH == 1)
				vag->ch[1].interleave=vag->ch[0].interleave=0xffffffff;
			
			// 2007-11-11 - Fastelbja : chanstart value is on 0x10
			vag->ch[0].chanstart=get32bitL(readbuf + 0x10);
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;

			// 2007-11-11 - Fastelbja : Loop entry point is on 0x14
			//							End loop point is always end of file
			vag->ch[0].sa=vag->ch[1].sa=get32bitL(readbuf + 0x14);
			vag->ch[0].ea=vag->ch[1].ea=vag->file_length;
			
			if (vag->ch[0].sa==0xffffffff)
			{
				vag->ch[0].loop_flag=vag->ch[1].loop_flag=0;
				vag->ch[0].ea=vag->ch[1].ea=0;
				vag->ch[0].sa=vag->ch[1].sa=0;
			}
			else
				vag->ch[0].loop_flag = vag->ch[1].loop_flag = 1;

			
		}
		else if(get32bitL(readbuf)== (int)0x0000080d) 
		{
			// RWS (Ghost Rider)
			vag->file_length = get32bitL(readbuf+0x04);
			vag->nrsamples = (vag->file_length*28/16)/2;
			vag->ch[0].type=type_rws;
			vag->NCH = 2;
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = 44100;

			vag->ch[1].interleave=vag->ch[0].interleave=get32bitL(readbuf+0x4c)/2;

			vag->ch[0].chanstart=get32bitL(readbuf+0x48);
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;

		} else if(!memcmp(readbuf, "pGAV", 4) && 
			     ((!memcmp(readbuf+0x20, "Stereo", 6)) || (!memcmp(readbuf+0x20, "Mono", 4)))) {
			// Stereo VAG
			if(!memcmp(readbuf+0x20, "Stereo", 6))
				vag->NCH = 2;
			if(!memcmp(readbuf+0x20, "Mono", 4))
				vag->NCH = 1;

			vag->ch[0].type=type_svag;
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bitL(readbuf+0x10);

			vag->nrsamples = (get32bitL(readbuf+0x0C)*28/16)/2;
			vag->ch[1].interleave=vag->ch[0].interleave=0x2000;

			vag->ch[0].chanstart=0x0;
			vag->ch[0].loop_flag = vag->ch[1].loop_flag = 0;

			// Jak X hack
			SetFilePointer(vag->ch[0].infile,0x1000,0,FILE_BEGIN);
			ReadFile(vag->ch[0].infile,&readbuf,0x80,&l,NULL);
			if(!memcmp(readbuf,"pGAV",4))
				vag->ch[0].interleave=vag->ch[1].interleave=0x1000;

			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
		}	
		else if(!memcmp(readbuf, "RXWS", 4)) {
			// RXWS
			vag->ch[0].type=type_rxws;
			vag->NCH = 2;
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bitL(readbuf+0x2E);
			vag->nrsamples = (get32bitL(readbuf+0x38)*28/16)/2;
			vag->ch[1].interleave=vag->ch[0].interleave=get32bitL(readbuf+0x1c)+0x10;

			// HACK
			if(vag->NCH == 1)
				vag->ch[1].interleave=vag->ch[0].interleave=0xffffffff;
			
			vag->ch[0].chanstart=0x40;
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
			vag->ch[0].sa=vag->ch[1].sa=get32bitL(readbuf + 0x3C);
			vag->ch[0].ea=vag->ch[1].ea=vag->file_length;
			vag->ch[0].bps=vag->ch[1].bps=8;

			if (vag->ch[0].sa==0xffffffff)
			{
				vag->ch[0].loop_flag=vag->ch[1].loop_flag=0;
				vag->ch[0].ea=vag->ch[1].ea=0;
				vag->ch[0].sa=vag->ch[1].sa=0;
			}
			else
				vag->ch[0].loop_flag = vag->ch[1].loop_flag = 1;
		} else if(!memcmp(readbuf, " KPV", 4)) {
			// VPK Fomart
			vag->ch[0].type=type_vpk;
			vag->NCH = get32bitL(readbuf+0x14);
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bitL(readbuf+0x10);
			vag->ch[1].interleave=vag->ch[0].interleave=get32bitL(readbuf+0x0c)/2;
			vag->ch[0].chanstart=get32bitL(readbuf + 0x08);
			vag->nrsamples = (get32bitL(readbuf + 0x04)*vag->NCH)*28/16/vag->NCH;
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
			vag->ch[0].ea=vag->ch[1].ea=vag->nrsamples;
			SetFilePointer(vag->ch[0].infile,vag->ch[0].chanstart-4,0,FILE_BEGIN);
			ReadFile(vag->ch[0].infile,&vag->loop_start_offset,4,&l,NULL);
			vag->ch[0].sa=vag->ch[1].sa=vag->loop_start_offset*28/16;
			vag->ch[0].loop_flag=vag->ch[0].sa!=0;

		} else if(!memcmp(readbuf, "MUSC", 4)) {
			// MUSC Fomart
			vag->ch[0].type=type_musc;
			vag->NCH = 2;
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bitL(readbuf+0x06);
			vag->nrsamples = (vag->file_length*28/16)/2;
			vag->ch[1].interleave=vag->ch[0].interleave=get32bitL(readbuf+0x18)/2;
			vag->ch[0].chanstart=get32bitL(readbuf + 0x10);
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
		} else if((!memcmp(readbuf, "RSD6", 4)) || (!memcmp(readbuf, "RSD4", 4))) {
			// RSD6
			vag->ch[0].type=type_rsd6;
			vag->NCH = get32bitL(readbuf+0x08);
			vag->ch[1].sample_rate = vag->ch[0].sample_rate = get32bitL(readbuf+0x10);
			vag->nrsamples = ((vag->file_length-0x800)*28/16)/vag->NCH;
			vag->ch[1].interleave=vag->ch[0].interleave=get32bitL(readbuf+0x0C);
			vag->ch[0].chanstart=0x800;
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
			vag->ch[0].ea=vag->ch[1].ea=vag->nrsamples;
			vag->ch[0].sa=vag->ch[1].sa=28;
			vag->ch[0].loop_flag=vag->ch[1].loop_flag=1;
		} else if(!memcmp(readbuf,"FSB",3)) {
			// FSB PS2
			if((get32bitL(readbuf+0x48)== (int)0x00880042) ||
			  (get32bitL(readbuf+0x48)== (int)0x00880041) ||
			  (get32bitL(readbuf+0x48)== (int)0x00880040))
			{
				vag->ch[0].type = type_ps2fsb;
				vag->NCH = 2;
	            vag->file_length = get32bitL(readbuf + 0x0c) + 0x58;
				vag->nrsamples = (vag->file_length *28/16)/2;
				vag->ch[0].chanstart = 0x58;
				vag->ch[0].sample_rate=vag->ch[1].sample_rate=get32bitL(readbuf+0x4c);
                vag->ch[0].interleave=vag->ch[1].interleave= 0x10;
				vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
			}
			else {
				CloseCUBEFILE(vag);
				return 1;
			}

		} else if(!memcmp(readbuf,"Svag",4)) {
			// Svag
			if(get32bitL(readbuf+0x0c)<= (int)0x00000002)
			{
				vag->ch[0].type = type_svag_kce;
				vag->NCH = get32bitL(readbuf+0x0c);
				vag->nrsamples = (get32bitL(readbuf+0x04) *28/16)/vag->NCH;

				if(!memcmp(readbuf+0x1c," ALL",4)) {
					vag->ch[0].chanstart=0x800;

				} else {
					vag->ch[0].chanstart=0x400;
				}
				vag->ch[0].sample_rate=vag->ch[1].sample_rate=get32bitL(readbuf+0x08);
                vag->ch[0].interleave=vag->ch[1].interleave= get32bitL(readbuf+0x10);

				if (vag->ch[0].interleave==0)
					vag->ch[0].interleave=vag->ch[1].interleave=0x10;

				vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
				
				vag->ch[0].sa=vag->ch[1].sa=get32bitL(readbuf+0x18)*28/16;
				vag->ch[0].ea=vag->nrsamples;
				vag->ch[0].loop_flag=(get32bitL(readbuf+0x14)==1);
				vag->ch[0].bps=vag->ch[1].bps=8;
				vag->startinterleave=vag->ch[0].interleave;
				if(get32bitL(readbuf+0x04)%(vag->NCH*vag->ch[0].interleave)<(vag->NCH*vag->ch[0].interleave)) 
					vag->lastchunk=get32bitL(readbuf+0x04)%(vag->NCH*vag->ch[0].interleave);
			}
		}

		else if(!memcmp(readbuf,"RSTM",4)) {
			// RSTM
			if((get32bitL(readbuf+0x0c)<= (int)0x00000002) && ((!memcmp(readbuf+0x40,"HEAD",4)) || (get32bitL(readbuf+0x40)==0)))
			{
				vag->ch[0].type = type_rstm;
				vag->NCH = get32bitL(readbuf+0x0C);
				vag->nrsamples = (get32bitL(readbuf+0x18) *28/16)/vag->NCH;
				vag->ch[0].chanstart = 0x800;
				vag->ch[0].sample_rate=vag->ch[1].sample_rate=get32bitL(readbuf+0x08);
                //vag->ch[0].interleave=vag->ch[1].interleave= get32bitL(readbuf+0x1c)/2;
				vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;

				vag->ch[0].sa=vag->ch[1].sa=get32bitL(readbuf + 0x1c)*28/16/vag->NCH;
				vag->ch[0].ea=vag->ch[1].ea=get32bitL(readbuf + 0x20)*28/16/vag->NCH;
				vag->loop_end_offset=get32bitL(readbuf + 0x20)+vag->ch[0].chanstart;
				vag->loop_start_offset=get32bitL(readbuf + 0x1c)+vag->ch[0].chanstart;
				vag->ch[0].bps=vag->ch[1].bps=16;
				
				vag->ch[0].interleave=vag->ch[1].interleave=0x10;

				if ((vag->ch[0].sa==0xFFFFFFFF) || (get32bitL(readbuf + 0x18)==get32bitL(readbuf + 0x20)))
				{
					vag->ch[0].loop_flag=vag->ch[1].loop_flag=0;
					vag->ch[0].ea=vag->ch[1].ea=0;
					vag->ch[0].sa=vag->ch[1].sa=0;
				}
				else
				{
					vag->ch[0].loop_flag = vag->ch[1].loop_flag = 1;
					//vag->ch[0].sa = vag->ch[0].sa - get32bitL(readbuf + 0x20);
				}
			}
			else {
				CloseCUBEFILE(vag);
				return 1;
			}
		}
		else if(!memcmp(readbuf+1,"DXH",3)) {
			// DXH
			vag->ch[0].type = type_dxh;
			vag->NCH = get32bitL(readbuf+0x08);
			vag->nrsamples = ((vag->file_length-0x800) *28/16)/2;
			vag->ch[0].chanstart = get32bitL(readbuf+0x14);
			vag->ch[0].sample_rate=vag->ch[1].sample_rate=get32bitL(readbuf+0x20);
            vag->ch[0].interleave=vag->ch[1].interleave= get32bitL(readbuf+0x04)/2;
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;

			vag->ch[0].sa=vag->ch[1].sa=((get32bitL(readbuf + 0x50)*32)*28/16)/2;
			vag->ch[0].ea=vag->ch[1].ea=((get32bitL(readbuf + 0x54)*32)*28/16)/2;
			vag->loop_start_offset=get32bitL(readbuf + 0x50)*32;
			vag->loop_end_offset=get32bitL(readbuf + 0x54)*32;
			vag->ch[0].bps=vag->ch[1].bps=16;

			vag->ch[0].loop_flag = vag->ch[1].loop_flag = (vag->ch[0].sa!=0);
		}
		else if(!memcmp(readbuf,"ILD",3)) {
			// ILD
			vag->ch[0].type = type_ild;
			vag->NCH = get32bitL(readbuf+0x04);
			vag->nrsamples = get32bitL(readbuf+0x0C);
			vag->ch[0].chanstart = get32bitL(readbuf+0x08);
			vag->ch[0].sample_rate=vag->ch[1].sample_rate=get32bitL(readbuf+0x28);
            vag->ch[0].interleave=vag->ch[1].interleave= get32bitL(readbuf+0x18)/2;
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;

			vag->ch[0].sa=vag->ch[1].sa=((get32bitL(readbuf + 0x2c))*28/16);
			vag->ch[0].ea=vag->ch[1].ea=((get32bitL(readbuf + 0x30))*28/16);
			vag->ch[0].bps=vag->ch[1].bps=8;

			vag->ch[0].loop_flag = vag->ch[1].loop_flag = (vag->ch[0].sa!=0);
		}
		else if ((get32bitL(readbuf) == 0x08640001) &&
                 (get32bitL(readbuf + 4) == 0) &&
                 (get32bitL(readbuf + 8) == 0x800) &&
                 (get32bitL(readbuf + 16) == 0) &&
                 (get32bitL(readbuf + 20) == 0) &&
                 (get32bitL(readbuf + 24) == 0xac44))
		{
			// KCES
            vag->ch[0].type = type_kecs;
            vag->ch[0].sample_rate=vag->ch[1].sample_rate = (int)get32bitL(readbuf + 0x18);
            vag->NCH = (int)get32bitL(readbuf + 0x1c);
            vag->nrsamples = ((vag->file_length - 0x800) / 16 * 28)/vag->NCH;
			vag->ch[0].interleave=vag->ch[1].interleave=get32bitL(readbuf + 0x24);
			if (vag->ch[0].interleave==0)
				vag->ch[0].interleave=vag->ch[1].interleave=0x10;
			vag->ch[0].chanstart=get32bitL(readbuf + 0x08);
			vag->ch[1].chanstart=vag->ch[0].chanstart+vag->ch[0].interleave;
        }

		else
		{
			CloseCUBEFILE(vag);
			return 1;
		}
	}
	
	if(vag->NCH==1)
		vag->ch[0].interleave=vag->ch[1].interleave=0x10;

	vag->NextFrameSize=0;

	vag->ch[0].offs=vag->ch[0].chanstart;
	vag->ch[1].offs=vag->ch[1].chanstart;
	SetFilePointer(vag->ch[0].infile,vag->ch[0].chanstart,0,FILE_BEGIN);

	if (vag->ch[0].loop_flag)
	if((vag->ch[0].type==type_mib) || (vag->ch[0].type==type_gms) || (vag->ch[0].type==type_rstm))
		vag->nrsamples=(vag->ch[0].sa-vag->ch[0].chanstart+(vag->ch[0].ea-vag->ch[0].sa)*looptimes)+(fadelength+fadedelay)*vag->ch[0].sample_rate;
	else
		vag->nrsamples=(vag->ch[0].sa-vag->ch[0].chanstart+(vag->ch[0].ea-vag->ch[0].sa)*looptimes)*28/16/vag->NCH+(fadelength+fadedelay)*vag->ch[0].sample_rate;
	return 0;
}

void fillbufferVAG(CUBEFILE * vag) {
	int l;
	char ADPCMbuf[16];

	if (SetFilePointer(vag->ch[0].infile,0,0,FILE_CURRENT) >= vag->file_length) {
		vag->ch[0].readloc=vag->ch[0].writeloc-1;
		return;
	}

	do {

		ReadFile(vag->ch[0].infile, ADPCMbuf, 16, &l, NULL);

		if (((l==0) || (ADPCMbuf[1]==0x07))  && vag->ch[0].loop_flag)
		{
			vag->ch[1].offs=vag->ch[0].offs + vag->ch[0].chanstart;
			SetFilePointer(vag->ch[0].infile, vag->ch[0].offs,0,FILE_BEGIN);
			ReadFile(vag->ch[0].infile,ADPCMbuf,16,&l,NULL);
		}

		//if (l<16) return;
		VAGdecodebuffer(ADPCMbuf,vag->ch[0].chanbuf+vag->ch[0].writeloc,
					&vag->ch[0].hist1, &vag->ch[0].hist2);

		vag->ch[0].writeloc+=28;

		if (vag->ch[0].writeloc>=BUFFER_SIZE/8*14) vag->ch[0].writeloc=0;
	} while (vag->ch[0].writeloc != vag->ch[0].readloc);
}

void fillbufferVAGinterleave(CUBEFILE * vag) 
{
    int l,i,j;
    unsigned char ADPCMbuf[16];
	byte ADPCMbufEmpty = 0;
	short sample;

    do 
	{
		SetFilePointer(vag->ch[0].infile, vag->ch[0].offs,0,FILE_BEGIN);
		ReadFile(vag->ch[0].infile,ADPCMbuf,16,&l,NULL);
		
		if(ADPCMbuf[1]!=0x00)
			ADPCMbuf[1]==0x00;

		if(l!=0) {
			// Fill buffer to not hear click 
			if (((vag->ch[0].type==type_svag) && (vag->samplesdone<(28*4*2))) ||
				(vag->ch[0].type==type_psh) && (vag->samplesdone<28*2))
			{
				for(i=0; i<16;i++)
					ADPCMbuf[i]=0;
			}

			if (vag->uncompressed==0)
			{
				if ((ADPCMbuf[1]!=0x07) && !(ADPCMbuf[0]==0xC0 && vag->ch[0].type==type_vpk))
				{
					VAGdecodebuffer(ADPCMbuf,vag->ch[0].chanbuf+vag->ch[0].writeloc,&vag->ch[0].hist1,&vag->ch[0].hist2);
					vag->ch[0].writeloc+=28;
				}
				else {

					for(i=0; i<28; i++) {
						vag->ch[0].chanbuf[vag->ch[0].writeloc++]=0;
						if (vag->ch[0].writeloc>=BUFFER_SIZE/8*14) vag->ch[0].writeloc=0;
					}
				}

			}
			else
			{
				// Just copy buf to channel ...
				for (i = 0, j = 0; i < 8; i++, j+=2)
				{
					sample = get16bitL(ADPCMbuf + j);
					vag->ch[0].chanbuf[vag->ch[0].writeloc++] = sample;
				}
			}                   

			if (vag->ch[0].writeloc>=BUFFER_SIZE/8*14) vag->ch[0].writeloc=0;

			if(vag->NCH==2)
			{
				SetFilePointer(vag->ch[1].infile, vag->ch[1].offs,0,FILE_BEGIN);
				ReadFile(vag->ch[1].infile,ADPCMbuf,16,&l,NULL);

				if(ADPCMbuf[1]!=0x00)
					ADPCMbuf[1]==0x00;

				// Fill buffer to not hear click 
				if ((vag->ch[0].type==type_svag) && (vag->samplesdone<(28*4*2)))
				{
					for(i=0; i<16;i++)
						ADPCMbuf[i]=0;
				}

				if (vag->uncompressed==0)
				{
					if ((ADPCMbuf[1]!=0x07) && !(ADPCMbuf[0]==0xC0 && vag->ch[0].type==type_vpk))
					{
						VAGdecodebuffer(ADPCMbuf,vag->ch[1].chanbuf+vag->ch[1].writeloc,&vag->ch[1].hist1,&vag->ch[1].hist2);
						vag->ch[1].writeloc+=28;
					}
					else {

						for(i=0; i<28; i++) {
							vag->ch[0].chanbuf[vag->ch[0].writeloc++]=0;
							if (vag->ch[0].writeloc>=BUFFER_SIZE/8*14) vag->ch[0].writeloc=0;
						}
					}
				}
				else
				{
					// Just copy buf to channel ...
					for (i = 0, j = 0; i < 8; i++, j+=2)
					{
						sample = get16bitL(ADPCMbuf + j);
						vag->ch[1].chanbuf[vag->ch[1].writeloc++] = sample;
					}
				}                   
				if (vag->ch[1].writeloc>=BUFFER_SIZE/8*14) vag->ch[1].writeloc=0;
			}

			vag->samplesdone+=28;

			// if we get to the end of file (with no more reads), or empty buffer
			// make the loop if one have been set
			if(vag->lastchunk!=0) {
				if(vag->ch[0].offs==vag->file_length-vag->lastchunk) 
					vag->ch[0].interleave=vag->ch[1].interleave=vag->lastchunk/2;
				else
					vag->ch[0].interleave=vag->ch[1].interleave=vag->startinterleave;
			}

			// Set the loop point ...

			vag->ch[0].offs+=16;
			vag->ch[1].offs+=16;
			vag->NextFrameSize+=0x10;
			
			if(vag->NextFrameSize==vag->ch[0].interleave) {
				vag->ch[0].offs+=vag->ch[0].interleave;
				if(vag->NCH==2) 
					vag->ch[1].offs+=vag->ch[1].interleave;
				if(vag->lastchunk!=0)
					vag->ch[0].interleave=vag->ch[1].interleave=vag->startinterleave;
				vag->NextFrameSize=0;
			}
		}

		if((vag->loopsamplesdone==0) && 
			((vag->samplesdone >=vag->ch[0].sa) && (vag->ch[0].loop_flag!=0) ||
			(((vag->ch[0].offs-16)>=vag->loop_start_offset) && (vag->loop_start_offset!=0))) || 
			(ADPCMbuf[1]==0x06))
		{
			if ((vag->ch[0].type==type_rxws))
				vag->loopsamplesdone=vag->ch[0].sa+vag->ch[0].chanstart;
			else
				vag->loopsamplesdone=vag->ch[0].offs-16; // SetFilePointer(vag->ch[0].infile,0,0,FILE_CURRENT);
			vag->loopnexthalp=vag->samplesdone-28; // blurp :(
			vag->nexthalp=vag->NextFrameSize-0x10;
		}

		if (((vag->samplesdone>=vag->ch[0].ea) && vag->ch[0].loop_flag) || 
			(ADPCMbuf[1]==0x03 || ADPCMbuf[1]==0x01) || 
			(ADPCMbuf[0]==0xC0 && vag->ch[0].type==type_vpk) || 
			(vag->ch[0].offs>=vag->file_length) ||
			((vag->loop_end_offset!=0) && (vag->ch[0].offs>=vag->loop_end_offset)) && 
			vag->loopsamplesdone!=0)
		{
			if(vag->ch[0].loop_flag) {
				vag->samplesdone=vag->loopnexthalp;
				vag->NextFrameSize=vag->nexthalp;
				if(vag->ch[0].type==type_rstm) {
					vag->ch[0].offs=vag->loop_start_offset;

					vag->ch[1].offs=vag->ch[0].offs + vag->ch[0].interleave;
				}
				else {
					vag->ch[0].offs=vag->loopsamplesdone;
					vag->ch[1].offs=vag->ch[0].offs + vag->ch[0].interleave;
				}
			}
		}
		
		if(vag->ch[0].offs>=vag->file_length)
			return;

	} while (vag->ch[0].writeloc != vag->ch[0].readloc);
}

void fillbufferVS(CUBEFILE * vag) 
{

    byte ADPCMbuf[0x10];
    byte ADPCMread[0x4000];
    int ADPCMLength=0,i,j,l;

	
	for(j=0;j<vag->NCH;j++)
	{
		vag->ch[j].bufferOffset=0;

		SetFilePointer(vag->ch[0].infile, vag->ch[0].offs,0,FILE_BEGIN);
		ReadFile(vag->ch[0].infile,&ADPCMLength,4,&l,NULL);
		//SetFilePointer(vag->ch[j].infile, ADPCMLength+4,0,FILE_CURRENT);
		vag->ch[0].offs+=ADPCMLength+4;

		ReadFile(vag->ch[0].infile,ADPCMread,ADPCMLength,&l,NULL);

	    // Say the thread we get to the end of file (with no loop)
		if (l != 0)
		{
			// Ok then decode the buffer
			do
			{
				for (i = 0; i < 0x10; i++)
					ADPCMbuf[i] = ADPCMread[i + vag->ch[j].bufferOffset];
				VAGdecodebuffer(ADPCMbuf,vag->ch[j].chanbuf+vag->ch[j].writeloc,&vag->ch[j].hist1,&vag->ch[j].hist2);
				
				vag->ch[j].writeloc+=28;

				if (vag->ch[j].writeloc>=BUFFER_SIZE/8*14) 
					vag->ch[j].writeloc=0;

				vag->ch[j].bufferOffset+=0x10;
				ADPCMLength -= 0x10;
			} while (ADPCMLength>0);
		}
	}
}

