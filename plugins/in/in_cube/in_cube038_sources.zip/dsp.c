/*

  in_cube Gamecube Stream Player for Winamp
  by hcs

  includes work by Destop and bero

*/

// DSP family

#include <windows.h>
#include "cube.h"
#include "wamain.h"

// standard devkit version
void get_dspheaderstd(CUBESTREAM *dsp,unsigned char *buf)
{
	int i;
	dsp->num_samples=get32bit(buf);
	dsp->num_adpcm_nibbles=get32bit(buf+4);
	dsp->sample_rate=get32bit(buf+8);
	dsp->loop_flag=get16bit(buf+0xC);
	dsp->format=get16bit(buf+0xE);
	dsp->sa=get32bit(buf+0x10);
	dsp->ea=get32bit(buf+0x14);
	dsp->ca=get32bit(buf+0x18);
	//DisplayError("get_dspheaderstd:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//	"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x1C+i*2);
	dsp->gain=get16bit(buf+0x3C);
	dsp->ps=get16bit(buf+0x3E);
	dsp->yn1=get16bit(buf+0x40);
	dsp->yn2=get16bit(buf+0x42);
	dsp->lps=get16bit(buf+0x44);
	dsp->lyn1=get16bit(buf+0x46);
	dsp->lyn2=get16bit(buf+0x48);
}

// SF Assault version
void get_dspheadersfa(CUBESTREAM *dsp,unsigned char *buf)
{
	int i;
	buf+=0x20; // for SF Assault
	dsp->num_samples=get32bit(buf);
	dsp->num_adpcm_nibbles=get32bit(buf+4);
	dsp->sample_rate=get32bit(buf+8);
	dsp->loop_flag=get16bit(buf+0xC);
	dsp->format=get16bit(buf+0xE);
	dsp->sa=get32bit(buf+0x10);
	dsp->ea=get32bit(buf+0x14);
	dsp->ca=get32bit(buf+0x18);
	//DisplayError("get_dspheadersfa:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x1C+i*2);
	dsp->gain=get16bit(buf+0x3C);
	dsp->ps=get16bit(buf+0x3E);
	dsp->yn1=get16bit(buf+0x40);
	dsp->yn2=get16bit(buf+0x42);
	dsp->lps=get16bit(buf+0x44);
	dsp->lyn1=get16bit(buf+0x46);
	dsp->lyn2=get16bit(buf+0x48);
}

// Metroid Prime 2 version
void get_dspheadermp2(CUBESTREAM *dsp,unsigned char *buf)
{
	int i;
	dsp->num_samples=get32bit(buf+0x8);
	dsp->num_adpcm_nibbles=get32bit(buf+0x10);
	dsp->sample_rate=get32bit(buf+0x0c);
	dsp->loop_flag=get16bit(buf+0x14);
	dsp->format=get16bit(buf+0xE);
	dsp->sa=get32bit(buf+0x18);
	dsp->ea=get32bit(buf+0x1c);
	//DisplayError("get_dspheadermp2:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//	"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x20+i*2);
	dsp->yn1=dsp->yn2=dsp->lyn1=dsp->lyn2=0;
}

// Metroid Prime 2 version (second channel)
void get_dspheadermp22(CUBESTREAM *dsp,unsigned char *buf)
{
	int i;
	dsp->num_samples=get32bit(buf+0x8);
	dsp->num_adpcm_nibbles=get32bit(buf+0x10);
	dsp->sample_rate=get32bit(buf+0x0c);
	dsp->loop_flag=get16bit(buf+0x14);
	dsp->format=get16bit(buf+0xE);
	dsp->sa=get32bit(buf+0x18);
	dsp->ea=get32bit(buf+0x1c);
	//DisplayError("get_dspheadermp22:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//	"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x40+i*2);
	dsp->yn1=dsp->yn2=dsp->lyn1=dsp->lyn2=0;
}

// SSB:M HALPST version
void get_dspheaderhalp(CUBESTREAM *dsp,unsigned char *buf)
{
	int i;
	dsp->num_samples=get32bit(buf+0x18)*14/16; // I'm using the same as the loop endpoint...
	dsp->num_adpcm_nibbles=get32bit(buf+0x18)*2; // ditto
	dsp->sample_rate=get32bit(buf+0x08);
	dsp->sa=get32bit(buf+0x14);
	dsp->ea=get32bit(buf+0x18);
	//DisplayError("get_dspheaderhalp:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//	"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x20+i*2);
	dsp->yn1=dsp->yn2=dsp->lyn1=dsp->lyn2=0;
}

// SSB:M HALPST version (second channel)
void get_dspheaderhalp2(CUBESTREAM *dsp,unsigned char *buf)
{
	int i;
	dsp->num_samples=get32bit(buf+0x50)*14/16; // I'm using the same as the loop endpoint...
	dsp->num_adpcm_nibbles=get32bit(buf+0x50)*2; // ditto
	dsp->sample_rate=get32bit(buf+0x08);
	dsp->sa=get32bit(buf+0x4c);
	dsp->ea=get32bit(buf+0x50);
	//DisplayError("get_dspheaderhalp2:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//	"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x58+i*2);
	dsp->yn1=dsp->yn2=dsp->lyn1=dsp->lyn2=0;
}

// Metroid Prime 2 demo's stereo fmt
void get_dspheadermp2d(CUBESTREAM *dsp,unsigned char *buf) {
	int i;
	dsp->num_samples=get32bit(buf+0xc);
	dsp->num_adpcm_nibbles=get32bit(buf+0xc)*2;
	dsp->sample_rate=get32bit(buf+0x8);
	dsp->loop_flag=get16bit(buf+0x10);
	dsp->format=get16bit(buf+0x12);
	dsp->sa=get32bit(buf+0);
	dsp->ea=get32bit(buf+4);
	//DisplayError("get_dspheadermp2d:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//	"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x1c+i*2);
	dsp->yn1=dsp->yn2=dsp->lyn1=dsp->lyn2=0;
}

// Metroid Prime 2 demo's stereo fmt (chan 2)
void get_dspheadermp2d2(CUBESTREAM *dsp,unsigned char *buf) {
	int i;
	dsp->num_samples=get32bit(buf+0x18);
	dsp->num_adpcm_nibbles=get32bit(buf+0x18)*2;
	dsp->sample_rate=get32bit(buf+0x8);
	dsp->loop_flag=get16bit(buf+0x10);
	dsp->format=get16bit(buf+0x12);
	dsp->sa=get32bit(buf+0);
	dsp->ea=get32bit(buf+4);
	//DisplayError("get_dspheadermp2d2:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//	"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x3c+i*2);
	dsp->yn1=dsp->yn2=dsp->lyn1=dsp->lyn2=0;
}

// spt header (seperate file)
void get_dspheaderspt(CUBESTREAM *dsp,unsigned char *buf)
{
	int i;
	//dsp->num_samples=get32bit(buf);
	//dsp->num_adpcm_nibbles=get32bit(buf+4);
	dsp->sample_rate=get32bit(buf+8);
	dsp->loop_flag=get32bit(buf+4); // "type" field, 0=nonlooped ADPCM, 1=looped ADPCM
	dsp->format=0; //get16bit(buf+0xE);
	dsp->sa=get32bit(buf+0x0C);
	dsp->ea=get32bit(buf+0x10);
	//dsp->ea=get32bit(buf+0x14);
	
	dsp->ca=get32bit(buf+0x18);
	//DisplayError("get_dspheaderspt:\nnum_samples=%li\nnum_adpcm_nibbles=%li\nsample_rate=%li\n"
	//	"loop_flag=%04x\nformat=%04x\nsa=%08x\nea=%08x\nca=%08x",dsp->num_samples,dsp->num_adpcm_nibbles,
	//	dsp->sample_rate,dsp->loop_flag,dsp->format,dsp->sa,dsp->ea,dsp->ca);
	for (i=0;i<16;i++)
	dsp->coef[i]=get16bit(buf+0x20+i*2);
	dsp->gain=get16bit(buf+0x40);
	dsp->ps=get16bit(buf+0x42);
	dsp->yn1=get16bit(buf+0x44);
	dsp->yn2=get16bit(buf+0x46);
	dsp->lps=get16bit(buf+0x48);
	dsp->lyn1=get16bit(buf+0x4A);
	dsp->lyn2=get16bit(buf+0x4C);
}

// ish (I_SF) header (no point in two fcns...)
void get_dspheaderish(CUBESTREAM *dsp1, CUBESTREAM *dsp2, unsigned char * buf) {
	int i;
	dsp1->sample_rate=get32bit(buf+0x08);
	dsp1->num_samples=get32bit(buf+0x0c);
	dsp1->num_adpcm_nibbles=get32bit(buf+0x10);
	dsp1->ca=get32bit(buf+0x14);
	// 0x00008000 at 0x18 might be interleave
	dsp1->loop_flag=get16bit(buf+0x1E);
	dsp1->sa=get32bit(buf+0x20);
	dsp1->ea=get32bit(buf+0x24);
	//dsp1->ea=get32bit(buf+0x28);
	memcpy(dsp2,dsp1,sizeof(CUBESTREAM));

	for (i=0;i<16;i++)
	dsp1->coef[i]=get16bit(buf+0x40+i*2);
	dsp1->ps=get16bit(buf+0x62);
	dsp1->yn1=get16bit(buf+0x64);
	dsp1->yn2=get16bit(buf+0x66);
	dsp1->lps=get16bit(buf+0x68);
	dsp1->lyn1=get16bit(buf+0x6A);
	dsp1->lyn2=get16bit(buf+0x6C);

	for (i=0;i<16;i++)
	dsp2->coef[i]=get16bit(buf+0x80+i*2);
	dsp2->ps=get16bit(buf+0xA2);
	dsp2->yn1=get16bit(buf+0xA4);
	dsp2->yn2=get16bit(buf+0xA6);
	dsp2->lps=get16bit(buf+0xA8);
	dsp2->lyn1=get16bit(buf+0xAA);
	dsp2->lyn2=get16bit(buf+0xAC);
}

// ymf

void get_dspheaderymf(CUBESTREAM * dsp, unsigned char * buf) {
	int i;
	
	//memset(dsp,0,sizeof(CUBESTREAM));
	//dsp->
	dsp->loop_flag=0;
	dsp->yn1=dsp->yn2=dsp->lyn1=dsp->lyn2=0;
	dsp->sample_rate=get32bit(buf+0x08);
	dsp->num_samples=get32bit(buf+0x3c);
	dsp->num_adpcm_nibbles=get32bit(buf+0x40);
	
	for (i=0;i<16;i++) dsp->coef[i]=get16bit(buf+0x0e+i*2);
}


// rsd (GC ADPCM)
void get_dspheaderrsd(CUBESTREAM * dsp, unsigned char * buf) {
	int i;
	
	dsp->loop_flag=0;

	dsp->sample_rate=get32bitL(buf+0x10);
	
	for (i=0;i<16;i++) dsp->coef[i]=get16bitL(buf+0x1c+2*i);
	
	//gain=get16bitL(buf+0x3c);
	dsp->ps=get16bitL(buf+0x3e);
	dsp->yn1=get16bitL(buf+0x40);
	dsp->yn2=get16bitL(buf+0x42);

	dsp->lps=get16bitL(buf+0x44);
	dsp->lyn1=get16bitL(buf+0x46);
	dsp->lyn2=get16bitL(buf+0x48);
}

// GCub
void get_dspheadergcub(CUBESTREAM * dsp1, CUBESTREAM * dsp2, unsigned char * buf) {
    int i;
    dsp1->loop_flag=dsp2->loop_flag=0;
    dsp1->sample_rate=dsp2->sample_rate=get32bit(buf+8);
    dsp1->num_adpcm_nibbles=dsp2->num_adpcm_nibbles=get32bit(buf+12)/2*2;
    dsp1->num_samples=dsp2->num_samples=get32bit(buf+12)/2*14/8;
    for (i=0;i<16;i++) dsp1->coef[i]=get16bit(buf+0x10+(i*2));
    for (i=0;i<16;i++) dsp2->coef[i]=get16bit(buf+0x30+(i*2));
}

long mp2round(long addr) {
	return (addr%0x8f00)+(addr/0x8f00*2*0x8f00);
}

long mp2roundup(long addr) {
	return (0x8f00+addr%0x8f00)+(addr/0x8f00*2*0x8f00);
}

#define SPM22count 117
const char * const SPM22names[SPM22count] = {
"btl_boss_middle1_44k_lp.brstm",
"btl_boss_stg1_22k_lp.brstm",
"btl_boss_stg2_22k_lp.brstm",
"btl_boss_stg3_44k_lp.brstm",
"btl_boss_stg4_lp.brstm",
"btl_boss_stg5_e3_44k_lp.brstm",
"btl_boss_stg6_44k_lp.brstm",
"btl_boss_stg7_44k_lp.brstm",
"btl_demen1_44k_lp.brstm",
"btl_demenL_44k_lp.brstm",
"btl_dodontas2_44k_lp.brstm",
"btl_koopa1_44k_lp.brstm",
"btl_manera1_44k_lp.brstm",
"btl_mr_zigen1_44k_lp.brstm",
"b_happy_flower_44k_lp.brstm",
"evt_angel_44k_lp.brstm",
"evt_area_start1_44k_lp..brstm",
"evt_cooking1_44k_lp.brstm",
"evt_danger1_44k_lp.brstm",
"evt_demen_appear1_44k_lp.brstm",
"evt_Dliigi_appear1_44k_lp.brstm",
"evt_dodontas_appear1_44k_lp.brstm",
"evt_dotabata1_44k_e4_lp.brstm",
"evt_exective_appear1_44k_lp.brstm",
"evt_exective_soudan1_44k_lp.brstm",
"evt_fairlin_magin1_44k_lp.brstm",
"evt_gesso_appear1_44k_lp.brstm",
"evt_hamerustone1_44k_lp.brstm",
"evt_hana_appear1_44k_lp.brstm",
"evt_happy_flower_44k.brstm",
"evt_hiroshi1_44k_lp.brstm",
"evt_kaisou_stg1_44k_lp.brstm",
"evt_kaisou_stg2_44k_lp.brstm",
"evt_kaisou_stg3_44k_lp.brstm",
"evt_kaisou_stg4_44k_lp.brstm",
"evt_konton1_44k_lp.brstm",
"evt_koopa_catsle_44k_lp.brstm",
"evt_manela_appear2_44k_lp.brstm",
"evt_manuke1_44k_lp.brstm",
"evt_mario_house1_44k_lp.brstm",
"evt_op_book_s_lp.brstm",
"evt_op_peach1_e1_lp.brstm",
"evt_peach_hen1_44k_lp.brstm",
"evt_plo4_open1_44k_lp.brstm",
"evt_quiz1_44k_lp.brstm",
"evt_quiz_s_e1_lp.brstm",
"evt_sini_appear_44k_lp.brstm",
"evt_star1_44k_lp.brstm",
"evt_stg1_crystale1_44k_lp.brstm",
"evt_stg3_adv1_22k_lp_e1.brstm",
"evt_stg6_syoumetsu1_e1.brstm",
"evt_stg7_rpg1_e2_44k_lp.brstm",
"evt_stg7_rpg_e3_44k_lp.brstm",
"evt_stg7_rpg_ff1_e2_44k.brstm",
"evt_stg8_end_44k_lp.brstm",
"evt_stg8_escape1_lp.brstm",
"evt_stg8_pure_born1_lp.brstm",
"evt_stg8_pure_go1_44k_lp.brstm",
"evt_stg8_world_break1_44k_lp.brstm",
"evt_uranai_44k_lp.brstm",
"evt_wedding1_44k_lp.brstm",
"evt_zigen_appear1_44k_lp.brstm",
"evt_zunbaba_appear1_44k_lp.brstm",
"ff_areastart_44k_lp.brstm",
"ff_card_get1_lp.brstm",
"ff_companion1_44k_lp.brstm",
"ff_correct1_32k.brstm",
"ff_pureheart1_44k_lp.brstm",
"ff_pureheartget1_s_lp.brstm",
"ff_pureheart_get_s2_lp.brstm",
"ff_umai1_e1_lp.brstm",
"ff_yado1_44k_lp.brstm",
"ff_zigenwaza_get1_44k_lp.brstm",
"map_100f_44k_lp.brstm",
"map_dungeon1_22k_lp.brstm",
"map_room1_22k_lp.brstm",
"map_stg1_1_44k_e_lp.brstm",
"map_stg1_sabaku_lp.brstm",
"map_stg1_start1_44k_lp.brstm",
"map_stg2_1_e3_44k_lp.brstm",
"map_stg2_start1_44k_lp.brstm",
"map_stg2_yakata_e6_lp.brstm",
"map_stg2_yakata_out1_lp.brstm",
"map_stg3_1_e6_44k_lp.brstm",
"map_stg3_castle1_22k_lp.brstm",
"map_stg3_room1_44k_lp.brstm",
"map_stg3_start1_44k_lp.brstm",
"map_stg3_water1_22k_lp.brstm",
"map_stg4_4d1_44k_lp.brstm",
"map_stg4_44k_lp.brstm",
"map_stg4_start1_44k_lp.brstm",
"map_stg5_1_e5_lp.brstm",
"map_stg5_2_e14_lp.brstm",
"map_stg5_start1_44k_lp.brstm",
"map_stg5_truck2_44k_lp.brstm",
"map_stg6_2_44k_lp.brstm",
"map_stg6_3_44k_lp.brstm",
"map_stg6_44k_lp.brstm",
"map_stg6_start1_44k_lp.brstm",
"map_stg7_3_44k_lp.brstm",
"map_stg7_44k_lp.brstm",
"map_stg7_sanzu1_44k_lp.brstm",
"map_stg7_start1_44k_lp.brstm",
"map_stg8_1_44k_lp.brstm",
"map_stg8_start1_44k_lp.brstm",
"map_town_omote1_44k_lp.brstm",
"map_town_ura1_44k_lp.brstm",
"minigame_gura_44k_lp.brstm",
"minigame_hayauti1_44k_e2_lp.brstm",
"minigame_hayauti1_e7_lp.brstm",
"minigame_hayauti1_e8_lp.brstm",
"minigame_koura1_44k_lp.brstm",
"minigame_panel_lp.brstm",
"sys_gameover1_44k_lp.brstm",
"sys_stage_clear_E3_lp.brstm",
"sys_title1_44k_lp.brstm",
"sys_yarare1_44k_lp.brstm",
};

int checkSPM22(char * infile) {
	char * basename = strrchr(infile,'\\');
	int i=0;
	if (basename==NULL) basename=infile;
	else basename++;

	for (i=0;i<SPM22count;i++) {
		if (!strcmp(basename,SPM22names[i])) return 1;
	}
	return 0;
}

// call with infile = NULL if file is already opened
// return 1 on failure, 0 on success
int InitDSPFILE(char * inputfile, CUBEFILE * dsp) {
	unsigned char readbuf[0x400];
	char infile[MAX_PATH],infile2[MAX_PATH]; // file name, second file name (for dual-file stereo)
	char * ext, * ext2; // file extension
	int l;
	int IDSP=0; // IDSP header detected?
	int IDSP2=0; // another file called IDSP w/ variable interleave
	int MSS=0; // MSS (standard stereo, 0x1000 interleave)
	int MPDSP=0; // MPDSP (Monopoly Party, single header stereo)
	int GCM=0; // GCM (standard stereo, 0x8000 interleave)
	int SPT=0; // seperate header file (SPT) detected
	int YMF=0; // YMF
	int WVS=0; // WVS
	int dfs=-1; // dual-file stereo (0 if we have the name of left channel, 1 if right)
	int SPM22=0; // hack to get Super Paper Mario to use 22.1khz
	int ZWDSP=0; // Zack & Wiki srt+ssd
	int GSP=0; // GSP & GSB (Super Swing Golf Season 2)
	dsp->ch[0].interleave=dsp->ch[1].interleave=0;

	if (inputfile) {
		strcpy(infile,inputfile);
		//dsp->ch[0].infile=dsp->ch[1].infile=INVALID_HANDLE_VALUE;

		ext=strrchr(infile,'.')+1;
		if (ext!=(char*)1) { // extension-specific handling
			//DisplayError("ex=%s",ext);
			if (!strcmpi(ext,"spt")) { // we've been passed the header
				dsp->ch[0].infile=CreateFile(infile,GENERIC_READ,
			FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
				if (dsp->ch[0].infile==INVALID_HANDLE_VALUE) return 1;
				
				ReadFile(dsp->ch[0].infile, &readbuf, 0x4e, &l, NULL);
				get_dspheaderspt(&dsp->ch[0],readbuf);

				CloseHandle(dsp->ch[0].infile);
				dsp->ch[0].infile=INVALID_HANDLE_VALUE;

				ext[2]='d'; // open the SPD next
				SPT=1;
			} else if (!strcmpi(ext,"spd")) {
				ext[2]='t';

				dsp->ch[0].infile=CreateFile(infile,GENERIC_READ,
			FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
				if (dsp->ch[0].infile==INVALID_HANDLE_VALUE) return 1;
				
				ReadFile(dsp->ch[0].infile, &readbuf, 0x4e, &l, NULL);
				get_dspheaderspt(&dsp->ch[0],readbuf);

				CloseHandle(dsp->ch[0].infile);
				dsp->ch[0].infile=INVALID_HANDLE_VALUE;

				ext[2]='d';

				SPT=1;
			} else if (!strcmpi(ext,"mss")) {
				MSS=1;
			} else if (!strcmpi(ext,"gcm")) {
				GCM=1;
			} else if (!strcmpi(ext,"mpdsp")) {
				MPDSP=1;
			} else if (!strcmpi(ext,"ymf")) {
				YMF=1;
			} else if (!strcmpi(ext,"wvs")) {
				WVS=1;
			} else if (!strcmpi(ext,"adx")) {
				return 1;
			} else if (!strcmp(ext,"brstm") && checkSPM22(infile)) {
				SPM22=1;
			} else if (!strcmpi(ext,"zwdsp")) {
				ZWDSP=1;
			}
		}

		dsp->ch[0].infile=CreateFile(infile,GENERIC_READ,
			FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

		if (dsp->ch[0].infile==INVALID_HANDLE_VALUE) return 1;

		// Dual file stereo
		strcpy(infile2,infile);
		ext2=ext-infile+infile2;
		ext2[-1]='\0';
		if (!strcmpi(ext2-2,"L")) { // L/R, Metroid Prime, etc
			ext2[-2]='R';
			dfs=0;
		} else if (!strcmpi(ext2-2,"R")) {
			ext2[-2]='L';
			dfs=1;
		} else if (!strcmpi(ext2-3,"_0")) { // _0/_1, Wario World
			ext2[-2]='1';
			dfs=0;
		} else if (!strcmpi(ext2-3,"_1")) {
			ext2[-2]='0';
			dfs=1;
		} else if (!strcmpi(ext2-5,"left")) { // left/right, NFL Blitz 2003
			strcpy(ext2-5,"right");
			strcpy(ext2+1,ext);
			dfs=0;
		} else if (!strcmpi(ext2-6,"right")) {
			strcpy(ext2-6,"left");
			strcpy(ext2-1,ext);
			dfs=1;
		}
		infile2[strlen(infile2)]='.';
		
		if (dfs==0) { // left channel already opened, load right
			dsp->ch[1].infile=CreateFile(infile2,GENERIC_READ,
			FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
			
			if (dsp->ch[1].infile==INVALID_HANDLE_VALUE) dsp->ch[1].infile=dsp->ch[0].infile;
		} else if (dfs==1) { // right channel already opened, load left
			dsp->ch[1].infile=dsp->ch[0].infile;
			dsp->ch[0].infile=CreateFile(infile2,GENERIC_READ,
			FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
			
			if (dsp->ch[0].infile==INVALID_HANDLE_VALUE) dsp->ch[0].infile=dsp->ch[1].infile;
		} else dsp->ch[1].infile=dsp->ch[0].infile;

	}// else return 1;

	dsp->file_length=GetFileSize(dsp->ch[0].infile,NULL);
	SetFilePointer(dsp->ch[0].infile,0,0,FILE_BEGIN);

	if (!SPT) ReadFile(dsp->ch[0].infile, &readbuf, 0x200, &l, NULL);

	if (SPT) {
		// SPT+SPD
		
		// only play single archives.
		if (get32bit(readbuf)!=1) {
			CloseCUBEFILE(dsp);
			return 1;
		}

		dsp->ch[0].num_adpcm_nibbles=dsp->ch[1].num_adpcm_nibbles=
			GetFileSize(dsp->ch[0].infile,NULL)*2;
		dsp->ch[0].num_samples=dsp->ch[1].num_samples=
			GetFileSize(dsp->ch[0].infile,NULL)*14/8;

		dsp->NCH=1;
		dsp->ch[0].chanstart=0;
		dsp->ch[0].type=type_spt;
		dsp->ch[0].bps=4;
	} else if (YMF) {
		// YMF

		get_dspheaderymf(&dsp->ch[0],readbuf+get32bit(readbuf+0x34));
		get_dspheaderymf(&dsp->ch[1],readbuf+get32bit(readbuf+0x34)+0x60);

		dsp->NCH=2;
		dsp->ch[0].interleave=dsp->ch[1].interleave=0x20000;
		dsp->ch[0].chanstart=get32bit(readbuf+0);
		dsp->ch[1].chanstart=get32bit(readbuf+0)+dsp->ch[0].interleave;
		dsp->ch[0].bps=dsp->ch[1].bps=8;
		dsp->ch[0].type=dsp->ch[1].type=type_ymf;
	} else if (WVS && !memcmp("\0\0\0\x2",readbuf,4)) {
		// WVS

		int i;
		dsp->ch[1].sample_rate=dsp->ch[0].sample_rate=32000;
		dsp->NCH=get32bit(readbuf);
		dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+0xc);
		dsp->ch[0].chanstart=0x60;
		dsp->ch[1].chanstart=0x60+dsp->ch[0].interleave;

		dsp->ch[1].loop_flag=dsp->ch[0].loop_flag=0;

		dsp->ch[1].num_adpcm_nibbles=dsp->ch[0].num_adpcm_nibbles=get32bit(readbuf+0x14);
		dsp->ch[1].num_samples=dsp->ch[0].num_samples=dsp->ch[0].num_adpcm_nibbles*14/8;

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x18)+i*2);
		for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+(0x38)+i*2);

		dsp->ch[0].bps=dsp->ch[1].bps=8;
		dsp->ch[0].type=dsp->ch[1].type=type_wvs;
	} else if (!memcmp("RS\x00\x03",readbuf,4)) {
		// Metroid Prime 2 "RS03"
		if (get16bit(readbuf+6)==2) { // channel count
			get_dspheadermp2(&dsp->ch[0],readbuf);
			get_dspheadermp22(&dsp->ch[1],readbuf);

			dsp->ch[0].sa=mp2round(dsp->ch[0].sa);
			dsp->ch[1].sa=mp2round(dsp->ch[1].sa);

			dsp->ch[0].ea*=2;
			dsp->ch[1].ea*=2;

			if (GetFileSize(dsp->ch[0].infile,NULL)-dsp->ch[0].ea > 0x8f00/2)
				dsp->ch[0].ea=dsp->ch[1].ea=mp2roundup(dsp->ch[0].ea/2);

			dsp->NCH=2;
			dsp->ch[0].interleave=dsp->ch[1].interleave=0x8f00;

			dsp->ch[0].chanstart=0x60;
			dsp->ch[1].chanstart=0x8f60;

			dsp->ch[0].type=dsp->ch[1].type=type_mp2;
			dsp->ch[0].bps=dsp->ch[1].bps=8;
		} else {
			// mono variant, haven't seen any of these loop
			get_dspheadermp2(&dsp->ch[0],readbuf);
			
			dsp->ch[0].sa*=2;
			
			dsp->NCH=1;
			dsp->ch[0].interleave=0;

			dsp->ch[0].chanstart=0x60;

			dsp->ch[0].type=type_mp2;
			dsp->ch[0].bps=dsp->ch[1].bps=4;
		}
	} else if (!memcmp("Cstr",readbuf,4)) {
		// Star Fox Assault "Cstr"
		get_dspheadersfa(&dsp->ch[0],readbuf);
		get_dspheadersfa(&dsp->ch[1],readbuf+0x60);

		// weird but needed
		dsp->ch[0].sa*=2;

		// second header has odd values for sa and ea
		dsp->ch[1].ea=dsp->ch[0].ea;
		dsp->ch[1].sa=dsp->ch[0].sa;

		dsp->NCH=2;
		dsp->ch[0].interleave=dsp->ch[1].interleave=0x800;

		dsp->ch[0].chanstart=0xe0;
		dsp->ch[1].chanstart=0x8e0;

		dsp->ch[0].type=dsp->ch[1].type=type_sfass;
		dsp->ch[0].bps=dsp->ch[1].bps=8;
	} 
	else if (!memcmp("\x02\x00",readbuf,2) && !memcmp(readbuf+2,readbuf+0x4a,2)) { // srate is in STM header
		// Paper Mario 2 "STM"
		get_dspheaderstd(&dsp->ch[0],readbuf+0x40);
		get_dspheaderstd(&dsp->ch[1],readbuf+0xa0);
		
		dsp->NCH=2;
		dsp->ch[0].interleave=dsp->ch[1].interleave=0;

		dsp->ch[0].chanstart=0x100;
		dsp->ch[1].chanstart=0x100+get32bit(readbuf+8); // the offset of chan2 is in several places...

		// easy way to detect mono form
		if (dsp->ch[0].num_adpcm_nibbles!=dsp->ch[1].num_adpcm_nibbles ||
			dsp->ch[0].num_samples!=dsp->ch[1].num_samples) {
			dsp->NCH=1;
			dsp->ch[0].chanstart=0xa0;
		}

		dsp->ch[0].type=dsp->ch[1].type=type_pm2;
		dsp->ch[0].bps=dsp->ch[1].bps=4;
	} else if (!memcmp("iSWS",readbuf,4)) { // srate is in STM header
		// Sega Tennis (WII)
		int i;
		dsp->ch[1].sample_rate=dsp->ch[0].sample_rate=get32bit(readbuf+0x28);
		if(get32bit(readbuf+0x20)==get32bit(readbuf+0x80))
			dsp->NCH=2;
		else
			dsp->NCH=1;
		dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+0x10);
		if(dsp->NCH==2) {
			dsp->ch[0].chanstart=0xe8;
			dsp->ch[1].chanstart=0xe8+dsp->ch[0].interleave;
			for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x3C)+i*2);
			for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+(0x9C)+i*2);
		} else {
			dsp->ch[0].chanstart=dsp->ch[1].chanstart=0x80;
			for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x3C)+i*2);
		}

		dsp->ch[1].loop_flag=dsp->ch[0].loop_flag=0;
		dsp->ch[1].num_samples=dsp->ch[0].num_samples=get32bit(readbuf+0x20);
		dsp->ch[0].bps=dsp->ch[1].bps=8;
		dsp->ch[0].type=dsp->ch[1].type=type_iSWS;
	}
	else if (!memcmp(" HALPST",readbuf,7)) {
		// Super Smash Bros. Melee "HALPST"

		dsp->NCH=get32bit(readbuf+0xc);

		get_dspheaderhalp(&dsp->ch[0],readbuf);
		get_dspheaderhalp2(&dsp->ch[1],readbuf);

		// just fill in something
		dsp->ch[0].interleave=dsp->ch[1].interleave=0x8000;
		
		dsp->ch[0].chanstart=0x80;
		dsp->ch[1].chanstart=0x80;
		
		dsp->ch[0].type=dsp->ch[1].type=type_halp;
		dsp->ch[0].bps=dsp->ch[1].bps=8;

		dsp->nexthalp=0x80;
		dsp->halpsize=0;

		// determine if a HALPST file loops
		{
			long c=0x80,lastc=0,size,bytecount=0;
			while (c > lastc) {
				lastc=c;
				SetFilePointer(dsp->ch[0].infile,c+4,0,FILE_BEGIN);
				ReadFile(dsp->ch[0].infile,&size,4,&l,NULL);
				ReadFile(dsp->ch[0].infile,&c,4,&l,NULL);
				bytecount+=(get32bit((char*)&size)+1);
				c=get32bit((char*)&c);
			}
			dsp->ch[0].loop_flag=dsp->ch[1].loop_flag=((c<0)?0:1);

			if (dsp->ch[0].loop_flag) {
				long startc;

				dsp->ch[0].ea=bytecount;
				
				// one more pass to get start byte count

				startc=c;
				bytecount=0;
				c=0x80;
				while (c < startc) {
					SetFilePointer(dsp->ch[0].infile,c+4,0,FILE_BEGIN);
					ReadFile(dsp->ch[0].infile,&size,4,&l,NULL);
					ReadFile(dsp->ch[0].infile,&c,4,&l,NULL);
					bytecount+=(get32bit((char*)&size)+1);
					c=get32bit((char*)&c);
				}
				dsp->ch[0].sa=bytecount;
			}
			
			//DisplayError("loop start: %x\nloop end %x+%x=%x\nsa: %x\n ea: %x",c,lastc,get32bit((char*)&size),lastc+get32bit((char*)&size),dsp->ch[0].sa,dsp->ch[0].ea);

			dsp->ch[0].sa=bytecount;
			
		}

	} else if (!memcmp("I_SF ",readbuf,4)) {
		// ISH+ISD (I_SF in header)
		WIN32_FIND_DATA finddata;
		HANDLE findhandle;
		int isdfound;
		char *t;

		CloseHandle(dsp->ch[0].infile);
		dsp->ch[0].infile=dsp->ch[1].infile=INVALID_HANDLE_VALUE;

		// read header

		get_dspheaderish(&dsp->ch[0],&dsp->ch[1],readbuf);

		dsp->NCH=2;
		dsp->ch[0].interleave=dsp->ch[1].interleave=0x8000;
		dsp->ch[0].chanstart=0;
		dsp->ch[1].chanstart=0x8000;

		dsp->ch[0].type=dsp->ch[1].type=type_ish;
		dsp->ch[0].bps=dsp->ch[1].bps=8;

		// have to screw with the loop start point
		dsp->ch[0].sa=(dsp->ch[0].sa&0xffff)/2 | (dsp->ch[0].sa&0xffff0000);
								
		dsp->ch[1].sa=dsp->ch[0].sa;

		// attempt to open data (ISD) file, should have same name, diff ext.

		strcpy(infile2,infile);
		ext=strrchr(infile2,(char)'.');
		ext[1]='*';
		ext[2]='\0';

		findhandle=FindFirstFile(infile2,&finddata);

		if (findhandle==INVALID_HANDLE_VALUE) {
			CloseCUBEFILE(dsp);
			return 1;
		}

		isdfound=0;
		do {
			if (finddata.nFileSizeLow==(dsp->ch[0].num_adpcm_nibbles+0xffff)/0x10000*0x10000) {isdfound=1; break;}
		} while (FindNextFile(findhandle,&finddata));

		if (!isdfound) {
			CloseCUBEFILE(dsp);
			return 1;
		}

		t=strrchr(infile2,'\\');
		if (!t) t=infile2;
		else t++;
		strcpy(t,finddata.cFileName);

		dsp->ch[0].infile=dsp->ch[1].infile=CreateFile(infile2,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
			NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

		if (dsp->ch[0].infile==INVALID_HANDLE_VALUE) {
			CloseCUBEFILE(dsp);
			return 1;
		}
	} else if (!memcmp("RSD3GADP",readbuf,8)) {
		// RSD (ADPCM type)

		get_dspheaderrsd(&dsp->ch[0],readbuf);

		dsp->ch[0].chanstart=get32bitL(readbuf+0x18);

		dsp->ch[0].num_adpcm_nibbles=dsp->ch[1].num_adpcm_nibbles=
			(GetFileSize(dsp->ch[0].infile,NULL)-dsp->ch[0].chanstart)*2;
		dsp->ch[0].num_samples=dsp->ch[1].num_samples=
			(GetFileSize(dsp->ch[0].infile,NULL)-dsp->ch[0].chanstart)*7/4;

		dsp->ch[0].bps = dsp->ch[1].bps = 4;

		dsp->NCH=1;
		dsp->ch[0].interleave=0;

		dsp->ch[0].type=type_rsddsp;
	} else if (!memcmp("GCub",readbuf,4)) {
		// GCub

        get_dspheadergcub(&dsp->ch[0],&dsp->ch[1],readbuf);

        dsp->ch[0].chanstart=dsp->ch[1].chanstart=0x60;
        dsp->ch[0].bps=dsp->ch[1].bps=4;
        dsp->NCH=2;
        dsp->ch[0].interleave=dsp->ch[1].interleave=0x8000;


        dsp->ch[0].type=dsp->ch[1].type=type_gcub;
	} else if (!memcmp("RIFF",readbuf,4) && !memcmp("WAVEfmt ",readbuf+8,8) && !memcmp("\xfe\xff",readbuf+0x14,2)) {
		int i,l;

		dsp->NCH=get16bitL(readbuf+0x16);
		dsp->ch[0].sample_rate=get32bitL(readbuf+0x18);
		dsp->ch[0].chanstart=0x5c;
		dsp->ch[0].num_adpcm_nibbles=get32bitL(readbuf+0x2a)/dsp->NCH-0x2a;
		dsp->ch[0].num_samples=get32bitL(readbuf+0x2a)/dsp->NCH*14/8;
		dsp->ch[0].loop_flag=dsp->ch[1].loop_flag=1;
		dsp->ch[1].ea=dsp->ch[0].ea=dsp->ch[0].num_adpcm_nibbles;
		dsp->ch[1].sa=dsp->ch[0].sa=0;

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x2e)+i*2);

		if (dsp->NCH==2) {
			char coeffs[0x20];

			dsp->ch[1].num_adpcm_nibbles=dsp->ch[0].num_adpcm_nibbles;
			dsp->ch[1].num_samples=dsp->ch[0].num_samples;
			
			dsp->ch[1].sample_rate=dsp->ch[0].sample_rate;
			dsp->ch[1].chanstart=0x58+get32bitL(readbuf+0x2a)/2+0x32;

			SetFilePointer(dsp->ch[0].infile,0x58+get32bitL(readbuf+0x2a)/2+4,0,FILE_BEGIN);
			ReadFile(dsp->ch[0].infile,coeffs,0x20,&l,NULL);

			for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(coeffs+i*2);

		}

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_wam;
	} else if ((!memcmp("FSB3",readbuf,4)) && ((get16bitL(readbuf+0x4A)==0x0608) || (get16bitL(readbuf+0x4A)==0x0208))) {
		int i;

		dsp->NCH=2;
		dsp->ch[0].sample_rate=get32bitL(readbuf+0x4C);
		dsp->ch[0].chanstart=dsp->ch[1].chanstart=0xc4;
		//dsp->ch[0].num_adpcm_nibbles=get32bitL(readbuf+0x2a)/dsp->NCH-0x2a;
		dsp->ch[0].num_samples=get32bitL(readbuf+0x38);
		dsp->ch[1].ea=dsp->ch[0].ea=get32bitL(readbuf+0x44)/14*8; //*dsp->NCH;
		dsp->ch[1].sa=dsp->ch[0].sa=get32bitL(readbuf+0x40)/14*8;
		dsp->ch[0].loop_flag=dsp->ch[1].loop_flag=(dsp->ch[0].sa!=0);
		

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x68)+i*2);
		for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+(0x96)+i*2);

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_fsb3wii;
	} else if ((!memcmp("RWSD",readbuf,4)) && (!memcmp("DATA",readbuf+0x20,4))) {
		int i;

		long waveOffset=0;
		long waveLength=0;
		long coefOffset=0;

		dsp->ch[0].chanstart=dsp->ch[1].chanstart=get32bit(readbuf+0x08);
		waveOffset=get32bit(readbuf+0x18);
		waveLength=get32bit(readbuf+0x1c);

		// DATA Section is useless for the moment ...
		SetFilePointer(dsp->ch[0].infile,waveOffset,0,FILE_BEGIN);
		ReadFile(dsp->ch[0].infile, &readbuf, waveLength, &l, NULL);
		
		dsp->NCH = get16bit(readbuf+0x1A);
		
		if (get32bit(readbuf+0x08)!=1) {
			DisplayError("RWSD Multi files not implemented yet !");
			return 1;
		}

		dsp->ch[0].sample_rate=dsp->ch[1].sample_rate=get16bit(readbuf+0x14);
		dsp->ch[0].num_samples=get32bit(readbuf+0x1C)/dsp->NCH*14/8;
		dsp->ch[0].loop_flag=dsp->ch[1].loop_flag=0; //(dsp->ch[0].sa!=0);

		dsp->ch[1].chanstart+=get32bit(readbuf+0x50);

		coefOffset = get32bit(readbuf+0x38)+0x10;
		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+coefOffset+i*2);
		coefOffset = get32bit(readbuf+0x54)+0x10;
		for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+coefOffset+i*2);

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_rwsd_wii;
	}
	else if (!memcmp("RSTM",readbuf,4)) {

		int coef_pointer,coef_pointer_2,coef_pointer_1;
		int i;

		long headOffset=0;
		long headLength=0;
		long coefOffset=0;
		long numSamples=0;
		long fileLength;
		
		headOffset=get32bit(readbuf+0x10);
		headLength=get32bit(readbuf+0x14);
		fileLength=get32bit(readbuf+0x08);

		SetFilePointer(dsp->ch[0].infile,headOffset,0,FILE_BEGIN);
		ReadFile(dsp->ch[0].infile, &readbuf, headLength, &l, NULL);

		// 2 = adpcm
		if (readbuf[0x20]!=2) {
			CloseCUBEFILE(dsp);
			return 1;
		}

		dsp->ch[0].chanstart=dsp->ch[1].chanstart=get32bit(readbuf+0x30);
		dsp->NCH = readbuf[0x22];

		numSamples=(fileLength-dsp->ch[0].chanstart)*14/8/dsp->NCH;
		
		dsp->ch[0].num_samples=get32bit(readbuf+0x2c);
		//DisplayError("numSamples from DATA block size=%d\nnumSamples from 0x2c=%d",numSamples,get32bit(readbuf+0x2c));
		
		dsp->ch[0].sample_rate=dsp->ch[1].sample_rate=get16bit(readbuf+0x24);
		dsp->ch[0].loop_flag=dsp->ch[1].loop_flag=readbuf[0x21]; 

		if(dsp->NCH==2) {
			dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+0x38);
			dsp->ch[1].chanstart+=dsp->ch[0].interleave;
		}

		dsp->ch[0].ea=dsp->ch[1].ea=dsp->ch[0].num_samples/14*8*dsp->NCH;
		dsp->ch[0].sa=dsp->ch[1].sa=get32bit(readbuf+0x28)/14*8*dsp->NCH;

		coef_pointer_1=get32bit(readbuf+0x1c);
		coef_pointer_2=get32bit(readbuf+0x10+coef_pointer_1);
		coef_pointer=coef_pointer_2+0x10;

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+coef_pointer+i*2);

		if (dsp->NCH==2) {	
			for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+coef_pointer+0x38+i*2);
		}
		
		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		/* This is a hack to get Super Paper Mario tracks playing at (apparently) the
		right speed. */
		if (SPM22 && dsp->ch[0].sample_rate==44100) {
			dsp->ch[0].sample_rate=dsp->ch[1].sample_rate=22050;
			dsp->ch[0].type=type_spmrstm_wii;
		} else {
			dsp->ch[0].type=type_rstm_wii;
		}
	}
	else if (!memcmp("idsp",readbuf,4)) {
		int i;
		dsp->ch[0].chanstart=0x1c0;
		dsp->ch[0].num_samples=get32bit(readbuf+0x14)-dsp->ch[0].chanstart;

		dsp->NCH = get32bit(readbuf+0xC4);
		dsp->ch[0].num_samples=(dsp->ch[0].num_samples/dsp->NCH*14/8);
		dsp->ch[0].sample_rate=dsp->ch[1].sample_rate=get32bit(readbuf+0xc8);
		
		dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+0xd8);

		dsp->ch[1].chanstart=0x1c0+dsp->ch[0].interleave;
		dsp->ch[0].ea=dsp->ch[1].ea=get32bit(readbuf+0xd4)/14/2*2*8*dsp->NCH;
		dsp->ch[0].sa=dsp->ch[1].sa=get32bit(readbuf+0xd0)/14/2*2*8*dsp->NCH;
		dsp->ch[0].loop_flag=dsp->ch[1].loop_flag=dsp->ch[0].ea!=0;

		if (dsp->NCH==1)
		{
			for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+0x78+i*2);
		}
		else
		{
			for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+0x118+i*2);
			for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+0x178+i*2);
		}

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_idsp_wii;
	} else if (!memcmp("GCA1",readbuf,4)) {

		int i;

		dsp->NCH=1;
		dsp->ch[0].sample_rate=get16bit(readbuf+0x2C);
		dsp->ch[0].chanstart=dsp->ch[1].chanstart=0x40;
		dsp->ch[0].num_samples=get32bit(readbuf+0x2E);
		dsp->ch[0].ea=dsp->ch[1].ea=dsp->ch[0].num_samples/14*8;
		dsp->ch[0].sa=dsp->ch[1].sa=get16bit(readbuf+0x32)/14*8;
		dsp->ch[0].loop_flag = dsp->ch[1].loop_flag = (dsp->ch[0].sa!=0);

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x04)+i*2);

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_gca1;
	} else if ((!memcmp("IDSP",readbuf,4)) && (!memcmp("\x00\x00\x6B\x40",readbuf+0x04,4))) {

		int i;

		dsp->NCH=get32bit(readbuf+0x24);
		dsp->ch[0].sample_rate=get32bit(readbuf+0x14);
		dsp->ch[0].chanstart=dsp->ch[1].chanstart=0xD4;
		dsp->ch[0].num_samples=get32bit(readbuf+0x20);
		dsp->ch[0].ea=dsp->ch[1].ea=dsp->ch[0].num_samples;
		dsp->ch[0].sa=dsp->ch[1].sa=get32bit(readbuf+0x54)/14*8;
		dsp->ch[0].loop_flag = dsp->ch[1].loop_flag = 0; //(dsp->ch[0].sa!=0);
		dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+0x04);
		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x28)+i*2);
		for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+(0x88)+i*2);

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_gca1;
	} else if (!memcmp("YDSP",readbuf,4)) {

		int i;

		dsp->NCH=get16bit(readbuf+0x10);
		dsp->ch[0].sample_rate=get32bit(readbuf+0x0c);
		dsp->ch[0].chanstart=0x120;
		dsp->ch[1].chanstart=0x120+8;
		dsp->ch[0].num_samples=(get32bit(readbuf+0x08)/dsp->NCH)/8*14;
		dsp->ch[0].ea=dsp->ch[1].ea=get32bit(readbuf+0xb4)/14*8*dsp->NCH;;
		dsp->ch[0].sa=dsp->ch[1].sa=get32bit(readbuf+0xb0)/14*8*dsp->NCH;;
		dsp->ch[0].loop_flag = dsp->ch[1].loop_flag = (dsp->ch[0].sa>0x20);

		if(dsp->NCH==2) 
			dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+0x14);

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x20)+i*2);
		for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+(0x44)+i*2);

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_ydsp;
	} else if (!memcmp("THP\0x00",readbuf,4)) {
		// to prevent DSP checking...
		return 1;
	} else if (ZWDSP) {
		int i;

		dsp->NCH=2;
		dsp->ch[0].sample_rate=get32bit(readbuf+0x8);
		dsp->ch[0].chanstart=0x90;
		dsp->ch[1].chanstart=(GetFileSize(dsp->ch[0].infile,NULL)-0x90)/2+0x90;
		dsp->ch[0].num_samples=get32bit(readbuf+0x18)/dsp->NCH/8*14;
		dsp->ch[0].ea=dsp->ch[1].ea=get32bit(readbuf+0x14)/dsp->NCH;
		dsp->ch[0].sa=dsp->ch[1].sa=get32bit(readbuf+0x10)/dsp->NCH;
		dsp->ch[0].loop_flag = dsp->ch[1].loop_flag = (dsp->ch[0].ea!=0);

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x20)+i*2);
		for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+(0x60)+i*2);

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_zwdsp;
	}
	else if (!memcmp("KNON",readbuf,4) && !memcmp("KAST",readbuf+0x20,4)) {
		int i;

		dsp->NCH=get16bit(readbuf+0x64);
		dsp->ch[0].sample_rate=get16bit(readbuf+0x42);
		dsp->ch[0].chanstart=0x800;
		dsp->ch[1].chanstart=0x810;
		dsp->ch[0].interleave=dsp->ch[1].interleave=0x10;
		dsp->ch[0].num_samples=get32bit(readbuf+0x3c)/dsp->NCH/8*14;;
		dsp->ch[0].ea=dsp->ch[1].ea=get32bit(readbuf+0x48);
		dsp->ch[0].sa=dsp->ch[1].sa=get32bit(readbuf+0x44);
		dsp->ch[0].loop_flag = dsp->ch[1].loop_flag = (dsp->ch[0].ea!=0);

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+(0x8c)+i*2);
		for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+(0xec)+i*2);

		dsp->ch[0].bps=8;
		dsp->ch[1].bps=8;

		dsp->ch[0].type=type_knon_dsp;
	}
	else if (!memcmp("CAF ",readbuf,4)) {
		
		unsigned long readLength = 0;
		unsigned long nextChunk=0;
		int i=0;

		dsp->NCH=2;
		dsp->ch[0].sample_rate=dsp->ch[1].sample_rate=32000;
		dsp->ch[0].chanstart=dsp->ch[1].chanstart=0;
		dsp->ch[0].num_samples=0;
		dsp->ch[0].bps=dsp->ch[1].bps=8;
		dsp->loopnexthalp=get32bit(readbuf+0x20);
		dsp->ch[0].type=type_caf;

		// Calculate sample length ...
		SetFilePointer(dsp->ch[0].infile,0,0,FILE_BEGIN);
		
		do {
			ReadFile(dsp->ch[0].infile,readbuf,0x20,&l,NULL);
			nextChunk=get32bit(readbuf+0x04);

 			dsp->ch[0].num_samples+=get32bit(readbuf+0x14)/8*14;

			if(dsp->loopnexthalp==i) {
				dsp->ch[0].sa=dsp->ch[0].num_samples-get32bit(readbuf+0x14)/8*14;
				dsp->loopnexthalp=SetFilePointer(dsp->ch[0].infile,0,0,FILE_CURRENT)-0x20;
			}

			SetFilePointer(dsp->ch[0].infile,nextChunk-0x20,0,FILE_CURRENT);
			readLength+=nextChunk;
			i++;
		}  while(readLength<dsp->file_length);

		dsp->ch[0].ea=dsp->ch[0].num_samples;
		dsp->ch[0].loop_flag=(dsp->loopnexthalp!=0xFFFFFFFF);

	}
	else if (!memcmp("GSND",readbuf,4) && (get32bit(readbuf+0x08)==0x00000001)) {
		
		unsigned long headOffset, dataOffset, bsicOffset, nameOffset, gcexOffset;
		int i;

		headOffset=get32bit(readbuf+0x10);
		dataOffset=headOffset+get32bit(readbuf+headOffset+0x04);
		dsp->NCH=get16bit(readbuf+dataOffset+0x16);
		dsp->ch[0].num_samples=get32bit(readbuf+dataOffset+0x08)/8*14/dsp->NCH;
		dsp->ch[0].sample_rate=dsp->ch[1].sample_rate=get32bit(readbuf+dataOffset+0x10);

		bsicOffset=dataOffset + get32bit(readbuf+dataOffset+0x04);
		nameOffset=bsicOffset + get32bit(readbuf+bsicOffset+0x04);
		gcexOffset=nameOffset + get32bit(readbuf+nameOffset+0x04);

		dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+gcexOffset+0x08);
		dsp->ch[0].chanstart=dsp->ch[1].chanstart=0x20;
		dsp->ch[1].chanstart=dsp->ch[0].chanstart+dsp->ch[0].interleave;

		for (i=0;i<16;i++) dsp->ch[0].coef[i]=get16bit(readbuf+gcexOffset+(0x20)+i*2);
		for (i=0;i<16;i++) dsp->ch[1].coef[i]=get16bit(readbuf+gcexOffset+(0x50)+i*2);
		
		CloseHandle(dsp->ch[0].infile);
		ext[2]='b';

		dsp->ch[0].infile=CreateFile(infile,GENERIC_READ,
			FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if (dsp->ch[0].infile==INVALID_HANDLE_VALUE) return 1;

		dsp->ch[0].sa=dsp->ch[1].sa=get32bit(readbuf+bsicOffset+0x18);
		dsp->ch[0].ea=dsp->ch[1].ea=get32bit(readbuf+bsicOffset+0x1c);
		dsp->ch[0].bps=dsp->ch[1].bps=8;
		dsp->ch[0].type=type_gsp_gsb;
		dsp->ch[0].loop_flag=(dsp->ch[0].sa!=0);
		dsp->ch[0].loopoffs=dsp->ch[1].loopoffs=0;
	}
	else {
		// assume standard devkit (or other formats without signature)

		// check for MP2 demo stereo format
		/*get_dspheadermp2d(&dsp->ch[0],readbuf);
		get_dspheadermp2d2(&dsp->ch[1],readbuf);
		if (dsp->ch[0].num_samples==dsp->ch[1].num_samples) {
				DisplayError("MP2 demo");
				// stereo
				dsp->NCH=2;
				dsp->ch[0].interleave=dsp->ch[1].interleave=0x8000;

				dsp->ch[0].chanstart=0x68;
				dsp->ch[1].chanstart=0x8068;

				dsp->ch[0].type=dsp->ch[1].type=type_mp2d;
				dsp->ch[0].bps=dsp->ch[1].bps=8;
		} else { // if MP2 demo*/

			// IDSP in Mario Smash Football
			if (!memcmp("IDSP",readbuf,4)) IDSP=1;
			// IDSP (no relation) in Harvest Moon - Another Wonderful Life
			if (!memcmp("\x00\x00\x00\x00\x00\x01\x00\x02",readbuf,8))  IDSP2=1;
			
			if (IDSP) {
				get_dspheaderstd(&dsp->ch[0],readbuf+0xC);
				get_dspheaderstd(&dsp->ch[1],readbuf+0x6C); // header for channel 2

				if (!CheckSampleRate(dsp->ch[0].sample_rate))
				{
					get_dspheaderstd(&dsp->ch[0],readbuf+0x20);
					get_dspheaderstd(&dsp->ch[1],readbuf+0x80);
					dsp->NCH=2;
					dsp->ch[0].interleave=dsp->ch[1].interleave=0x08;
					dsp->ch[0].chanstart=0xe0;
					dsp->ch[1].chanstart=0xe8;
					dsp->ch[0].type=type_std;
					goto init;
				}
			} else if (IDSP2) {
				get_dspheaderstd(&dsp->ch[0],readbuf+0x40);
				get_dspheaderstd(&dsp->ch[1],readbuf+0xa0);
			} else {
				get_dspheaderstd(&dsp->ch[0],readbuf);
				get_dspheaderstd(&dsp->ch[1],readbuf+0x60); // header for channel 2
			}
			
			// if a valid second header (agrees with first)
			if (abs(dsp->ch[0].num_adpcm_nibbles-dsp->ch[1].num_adpcm_nibbles)<=1 &&
				abs(dsp->ch[0].num_samples-dsp->ch[1].num_samples)<=1) {

				// stereo
				dsp->NCH=2;

				if (IDSP) {
					dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+4); //0x6b40;
					dsp->ch[0].chanstart=0xcc;
					dsp->ch[1].chanstart=0xcc+dsp->ch[0].interleave;
				} else if (IDSP2) {
					dsp->ch[0].interleave=dsp->ch[1].interleave=get32bit(readbuf+8);
					dsp->ch[0].chanstart=0x100;
					dsp->ch[1].chanstart=0x100+dsp->ch[0].interleave;
				} else if (MSS) {
					dsp->ch[0].interleave=dsp->ch[1].interleave=0x1000;
					dsp->ch[0].chanstart=0xc0;
					dsp->ch[1].chanstart=0x10c0;
				} else if (GCM) {
					dsp->ch[0].interleave=dsp->ch[1].interleave=0x8000;
					dsp->ch[0].chanstart=0xc0;
					dsp->ch[1].chanstart=0x80c0;
				} else {
					dsp->ch[0].interleave=dsp->ch[1].interleave=0x14180;
					dsp->ch[0].chanstart=0xc0;
					dsp->ch[1].chanstart=0x14180+0xc0;
				}					

				dsp->ch[0].type=dsp->ch[1].type=type_std;
				dsp->ch[0].bps=dsp->ch[1].bps=8;
			} else { // if valid second header (standard)
				// mono
				//DisplayError("mono");
				dsp->ch[0].interleave=0;

				dsp->ch[0].type=type_std;

				dsp->ch[0].bps=4;

				if (IDSP) dsp->ch[0].chanstart=0x6c;
				else dsp->ch[0].chanstart=0x60;

				if (dsp->ch[0].infile != dsp->ch[1].infile) { // dual-file stereo
					DisplayError("dual-file stereo");

					SetFilePointer(dsp->ch[1].infile,0,0,FILE_BEGIN);

					ReadFile(dsp->ch[1].infile, &readbuf, 0x100, &l, NULL);
					
					get_dspheaderstd(&dsp->ch[1],readbuf);

					dsp->NCH=2;
					dsp->ch[1].interleave=0;

					dsp->ch[1].type=type_std;

					dsp->ch[1].bps=4;

					dsp->ch[1].chanstart=0x60;

				} else dsp->NCH=1; // if dual-file stereo

				// Single header stereo (Monopoly Party)
				if (MPDSP) {
					DisplayError("monopoly");
					dsp->NCH=2;

					dsp->ch[0].interleave=0xf000;
					dsp->ch[0].num_samples/=2;
					memcpy(&dsp->ch[1],&dsp->ch[0],sizeof(CUBESTREAM));
					dsp->ch[0].chanstart=0x60;
					dsp->ch[1].chanstart=0x60+0xf000;

					dsp->ch[0].type=dsp->ch[1].type=type_mpdsp;
				}


			} // if valid second header (standard)

			if (IDSP) dsp->ch[0].type=dsp->ch[1].type=type_idsp;
			if (IDSP2) dsp->ch[0].type=dsp->ch[1].type=type_idsp2;
			if (MSS) dsp->ch[0].type=dsp->ch[1].type=type_mss;
	}
init:
	// initialize
	dsp->ch[0].offs=dsp->ch[0].chanstart;
	dsp->ch[1].offs=dsp->ch[1].chanstart;
	dsp->startinterleave=dsp->ch[0].interleave;
	dsp->lastchunk=0;

	dsp->ch[0].hist1=dsp->ch[0].yn1;
	dsp->ch[0].hist2=dsp->ch[0].yn2;
	dsp->ch[1].hist1=dsp->ch[1].yn1;
	dsp->ch[1].hist2=dsp->ch[1].yn2;

	dsp->ch[0].readloc=dsp->ch[1].readloc=dsp->ch[0].writeloc=dsp->ch[1].writeloc=0;

	// check for Metroid Prime over-world (a special case, to remove the blip at the beginning
	// (which seems to have been an error in the source WAV))
	{
		unsigned char data[28] = {
		0x00, 0x73, 0x09, 0xBD, 0x00, 0x83, 0x78, 0xD9, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x01, 0x00,
		0x00, 0x00, 0x01, 0x3A, 0x6E, 0x00, 0x83, 0x78, 0xD8, 0x00, 0x00, 0x00, 0x02
		};

		unsigned char data2[19] = {
		0xD8, 0x21, 0x13, 0x00, 0x05, 0x00, 0x00, 0x00, 0x78, 0x6F, 0xE8, 0x77, 0xD8, 0xFE, 0x12,
		0x00, 0x0C, 0x00, 0x63
		};

		SetFilePointer(dsp->ch[0].infile,0,0,FILE_BEGIN);

		if (!memcmp(data,readbuf,28) && !memcmp(data2,readbuf+0x50,19)) {
			dsp->ch[0].offs+=0x38;
			dsp->ch[1].offs+=0x38;
		}
	}

	// Disney's Magical Mirror loop oddity (samples instead of nibbles)
	if (dsp->ch[0].type==type_std && dsp->NCH==2 && !(dsp->ch[0].sa&0xf) && !(dsp->ch[0].ea&0xf) && !(dsp->ch[1].sa&0xf) && !(dsp->ch[1].ea&0xf))
	{
		dsp->ch[0].sa=dsp->ch[0].sa*16/14;
		dsp->ch[0].ea=dsp->ch[0].ea*16/14;
		dsp->ch[1].sa=dsp->ch[1].sa*16/14;
		dsp->ch[1].ea=dsp->ch[1].ea*16/14;

		//MessageBox(NULL,"disney","yo",MB_OK);
	}

	// start and end points equal...
	// why would they do this? to screw with you
	if (dsp->ch[0].sa==dsp->ch[0].ea) dsp->ch[0].loop_flag=0;
	if (dsp->ch[1].sa==dsp->ch[1].ea) dsp->ch[1].loop_flag=0;

	//check sample rate
	if (!CheckSampleRate(dsp->ch[0].sample_rate)) {
		//DisplayError("bad srate %d",dsp->ch[0].sample_rate);
		CloseCUBEFILE(dsp);
		return 1;
	}

	// get file size
	dsp->file_length=GetFileSize(dsp->ch[0].infile,NULL);

	// Adjust file size, except for IDSP (has strange file sizes)
	if (!IDSP) dsp->file_length=(dsp->file_length+0xf)&(~0xf);

	// in case loop end offset is beyond EOF... (MMX:CM)
	// breaks Metroid Prime 2 looping
	//if (dsp->ch[0].ea*dsp->ch[0].bps/8>dsp->file_length-dsp->ch[0].chanstart) dsp->ch[0].ea=(dsp->file_length-dsp->ch[0].chanstart)*8/dsp->ch[0].bps;
	//if (dsp->NCH==2 && dsp->ch[1].ea*dsp->ch[1].bps/8>dsp->file_length-dsp->ch[1].chanstart) dsp->ch[1].ea=(dsp->file_length-dsp->ch[1].chanstart)*8/dsp->ch[1].bps;
	
	// calculate how long to play
	if (!dsp->ch[0].loop_flag) dsp->nrsamples = dsp->ch[0].num_samples;
	else if (dsp->ch[0].interleave)
		dsp->nrsamples=(dsp->ch[0].sa+looptimes*(dsp->ch[0].ea-dsp->ch[0].sa))*14/(8*8/dsp->ch[0].bps)/dsp->NCH+(fadelength+fadedelay)*dsp->ch[0].sample_rate;
	else
		dsp->nrsamples=(dsp->ch[0].sa+looptimes*(dsp->ch[0].ea-dsp->ch[0].sa))*14/(8*8/dsp->ch[0].bps)+(fadelength+fadedelay)*dsp->ch[0].sample_rate;
	
	return 0;
}

// Note that for both of these I don't bother loading the loop context. Sounds great the
// way it is, why mess with a good thing?

// for noninterleaved files (mono, STM)
// also for reading two mono Metroid Prime files simultaneously as stereo
void fillbufferDSP(CUBESTREAM * stream) {
	int i,j,l;
	short decodebuf[14];
	char ADPCMbuf[8];

	SetFilePointer(stream->infile,stream->offs,0,FILE_BEGIN);

	i=0;
	do {
		if (i==0) {
			ReadFile(stream->infile, ADPCMbuf, 8, &l, NULL);
			DSPdecodebuffer(ADPCMbuf,decodebuf,stream->coef,&stream->hist1,&stream->hist2);
			i=14;
			j=14;
			stream->offs+=8;
						
			if (stream->loop_flag && (stream->offs-stream->chanstart+8)>=((stream->ea*stream->bps/8)&(~7))) {
				DisplayError("loop from %08x to %08x",stream->offs,stream->chanstart+((stream->sa*stream->bps/8)&(~7)));
stream->offs=SetFilePointer(stream->infile,stream->chanstart+((stream->sa*stream->bps/8)&(~7)),0,FILE_BEGIN);
			}

			/*if (stream->loop_flag && (stream->offs-stream->chanstart)>=stream->ea*stream->bps/8) {
				stream->offs=SetFilePointer(stream->infile,stream->chanstart+(stream->sa&(~0xf))*stream->bps/8,0,FILE_BEGIN);
				DisplayError("loop");
			}*/
		}
		stream->chanbuf[stream->writeloc++]=decodebuf[j-i];
		i--;
		if (stream->writeloc>=BUFFER_SIZE/8*14) stream->writeloc=0;
	} while (stream->writeloc != stream->readloc);
}

void fillbufferCAF(CUBEFILE * caf) {

	unsigned char buffer[0x100];
	short decodebuf[14];
	int bytesRead=0x100,buffOffset;
	int i,nChannel;

begin:

	if((caf->halpsize!=0) && (caf->halpsize<0x100))
		bytesRead=caf->halpsize;

	if((caf->halpsize==0) && (caf->nexthalp!=0))
		caf->ch[0].offs=caf->nexthalp;

	if((caf->samplesdone==caf->ch[0].ea) && (caf->ch[0].loop_flag)) {
		caf->ch[0].offs=caf->loopnexthalp;
		caf->samplesdone=caf->ch[0].sa;
	}

	caf->halpsize-=bytesRead;

	for(nChannel=0;nChannel<2;nChannel++) {

		buffOffset=0;

		SetFilePointer(caf->ch[nChannel].infile, caf->ch[nChannel].offs, 0, FILE_BEGIN);
		ReadFile(caf->ch[nChannel].infile,buffer,bytesRead, &bytesRead,NULL);

		if(!memcmp(buffer,"CAF ",4)) {
			// Initialize block
			caf->halpsize=get32bit(buffer+0x14);
			caf->nexthalp=caf->ch[0].offs+get32bit(buffer+0x04);
			caf->ch[1].offs=caf->ch[0].offs+get32bit(buffer+0x18);
			caf->ch[0].offs+=get32bit(buffer+0x10);

			// Get Coeffs
			for(i=0; i<16; i++) {
				caf->ch[0].coef[i]=get16bit(buffer+0x34+(i*2));
				caf->ch[1].coef[i]=get16bit(buffer+0x60+(i*2));
			}
			goto begin; // sorry about that :(
		}

		caf->ch[nChannel].offs+=bytesRead;
	
		do {
			DSPdecodebuffer(buffer+buffOffset,decodebuf,caf->ch[nChannel].coef, &caf->ch[nChannel].hist1,&caf->ch[nChannel].hist2);
			
			for(i=0;i<14;i++) {
				caf->ch[nChannel].chanbuf[caf->ch[nChannel].writeloc++]=decodebuf[i];
				if(caf->ch[nChannel].writeloc>=BUFFER_SIZE/8*14) caf->ch[nChannel].writeloc=0;
			}
			buffOffset+=8;

			if(nChannel==0) caf->samplesdone+=14;

		} while(buffOffset<bytesRead);
	}
}

// each HALP block contains the address of the next one and the size of the current one
void fillbufferHALP(CUBEFILE * dsp) {
	int c,i,l;
	short decodebuf1[28];
	short decodebuf2[28];
	char ADPCMbuf[16];

	if (dsp->halpsize==0 && (long)dsp->nexthalp < 0) dsp->ch[0].readloc=dsp->ch[1].readloc=dsp->ch[0].writeloc-1;
	
	i=0;
	do {
		if (i==0) {
			
			// handle HALPST headers
			if (dsp->halpsize==0) {
				if ((long)dsp->nexthalp < 0) {
					//for (c=0;c<0x8000/8*14;c++) dsp->ch[0].chanbuf[c]=dsp->ch[1].chanbuf[c]=0;
					//dsp->ch[0].writeloc=dsp->ch[1].writeloc=0;
					//dsp->ch[0].readloc=dsp->ch[1].readloc=dsp->ch[0].writeloc-1;
					return;
				}

				if (dsp->nexthalp+0x20 < dsp->ch[0].offs) DisplayError("HALP loop");

				dsp->ch[0].offs=dsp->nexthalp+0x20;
				SetFilePointer(dsp->ch[0].infile, dsp->nexthalp,0,FILE_BEGIN);
				ReadFile(dsp->ch[0].infile, ADPCMbuf, 16, &l, NULL);
				dsp->halpsize=get32bit(ADPCMbuf+4)+1; // size to read?
				
				dsp->ch[1].offs=dsp->nexthalp+0x20+get32bit(ADPCMbuf)/2;
				dsp->nexthalp=get32bit(ADPCMbuf+8);
			}

			SetFilePointer(dsp->ch[0].infile, dsp->ch[0].offs,0,FILE_BEGIN);
			ReadFile(dsp->ch[0].infile, ADPCMbuf, 16, &l, NULL);
			DSPdecodebuffer(ADPCMbuf,decodebuf1,dsp->ch[0].coef,&dsp->ch[0].hist1,&dsp->ch[0].hist2);
			DSPdecodebuffer(ADPCMbuf+8,decodebuf1+14,dsp->ch[0].coef,&dsp->ch[0].hist1,&dsp->ch[0].hist2);

			SetFilePointer(dsp->ch[1].infile, dsp->ch[1].offs,0,FILE_BEGIN);
			ReadFile(dsp->ch[1].infile, ADPCMbuf, 16, &l, NULL);			
			DSPdecodebuffer(ADPCMbuf,decodebuf2,dsp->ch[1].coef,&dsp->ch[1].hist1,&dsp->ch[1].hist2);
			DSPdecodebuffer(ADPCMbuf+8,decodebuf2+14,dsp->ch[1].coef,&dsp->ch[1].hist1,&dsp->ch[1].hist2);

			i=28;
			c=0;
			dsp->ch[0].offs+=0x10;
			dsp->ch[1].offs+=0x10;
			
			dsp->halpsize-=0x20;
			if (dsp->halpsize<0x20) dsp->halpsize=0;
		}
		dsp->ch[0].chanbuf[dsp->ch[0].writeloc++]=decodebuf1[c];
		dsp->ch[1].chanbuf[dsp->ch[1].writeloc++]=decodebuf2[c];
		c++; i--;
		if (dsp->ch[0].writeloc>=BUFFER_SIZE/8*14) dsp->ch[0].writeloc=0;
		if (dsp->ch[1].writeloc>=BUFFER_SIZE/8*14) dsp->ch[1].writeloc=0;
	} while (dsp->ch[0].writeloc != dsp->ch[0].readloc);
}

// interleaved files requires streams with knowledge of each other (for proper looping)
void fillbufferDSPinterleave(CUBEFILE * dsp) {
	int i,l;
	short decodebuf1[14];
	short decodebuf2[14];
	char ADPCMbuf[8];

	i=0;
	do {
		if (i==0) {

			SetFilePointer(dsp->ch[0].infile, dsp->ch[0].offs,0,FILE_BEGIN);
			ReadFile(dsp->ch[0].infile, ADPCMbuf, 8, &l, NULL);
			DSPdecodebuffer(ADPCMbuf,decodebuf1,dsp->ch[0].coef,&dsp->ch[0].hist1,&dsp->ch[0].hist2);

			SetFilePointer(dsp->ch[1].infile, dsp->ch[1].offs,0,FILE_BEGIN);
			ReadFile(dsp->ch[1].infile, ADPCMbuf, 8, &l, NULL);
			DSPdecodebuffer(ADPCMbuf,decodebuf2,dsp->ch[1].coef,&dsp->ch[1].hist1,&dsp->ch[1].hist2);
			i=14;
			dsp->ch[0].offs+=8;
			dsp->ch[1].offs+=8;

			// handle interleave
			if (dsp->ch[0].interleave!=0)
			{
				if (!dsp->lastchunk && (dsp->ch[0].offs-dsp->ch[0].chanstart)%dsp->ch[0].interleave==0) {
					dsp->ch[0].offs+=dsp->ch[0].interleave;

					//if (dsp->lastchunk) DisplayError("chanstart with lastchunk\noffset=%08x",dsp->ch[0].offs);
				}
				if (!dsp->lastchunk && (dsp->ch[1].offs-dsp->ch[1].chanstart)%dsp->ch[1].interleave==0) {
					dsp->ch[1].offs+=dsp->ch[1].interleave;

					// metroid prime 2, IDSP has smaller interleave for last chunk
					if (!dsp->lastchunk &&
						(dsp->ch[0].type==type_mp2 || dsp->ch[0].type==type_idsp ||
						dsp->ch[0].type==type_rstm_wii || dsp->ch[0].type==type_spmrstm_wii) && 
						dsp->ch[1].offs+dsp->ch[1].interleave>dsp->file_length) {
						
						dsp->ch[0].interleave=dsp->ch[1].interleave=
							(dsp->file_length-dsp->ch[0].offs)/2;
						dsp->ch[1].offs=dsp->ch[0].offs+dsp->ch[1].interleave;

						dsp->lastchunk=1;

						//DisplayError("smallchunk, ch[0].offs=%08x ch[0].interleave=%08x\nfilesize=%08x",dsp->ch[0].offs,dsp->ch[0].interleave,dsp->file_length);
					}
				}
			}
			
			if (dsp->ch[0].loop_flag && (
				(dsp->ch[0].offs-dsp->ch[0].chanstart)>=dsp->ch[0].ea*dsp->ch[0].bps/8 ||
				(dsp->ch[1].offs-dsp->ch[0].chanstart)>=dsp->ch[1].ea*dsp->ch[1].bps/8)) {
			
				if (dsp->ch[0].type==type_sfass && (dsp->ch[0].sa/dsp->ch[0].interleave)%2 == 1) {
					dsp->ch[1].offs=dsp->ch[0].chanstart+(dsp->ch[0].sa&(~7))*dsp->ch[0].bps/8;
					dsp->ch[0].offs=dsp->ch[1].offs-dsp->ch[0].interleave;
				} else {
					dsp->ch[0].offs=dsp->ch[0].chanstart+(dsp->ch[0].sa&(~7))*dsp->ch[0].bps/8;
					dsp->ch[1].offs=dsp->ch[1].chanstart+(dsp->ch[1].sa&(~7))*dsp->ch[1].bps/8;
				}

				DisplayError("loop\nch[1].offs=%08x",dsp->ch[1].offs);

				dsp->ch[0].interleave=dsp->ch[1].interleave=dsp->startinterleave;
				dsp->lastchunk=0;
			}
		}
		dsp->ch[0].chanbuf[dsp->ch[0].writeloc++]=decodebuf1[14-i];
		dsp->ch[1].chanbuf[dsp->ch[1].writeloc++]=decodebuf2[14-i];
		i--;
		if (dsp->ch[0].writeloc>=BUFFER_SIZE/8*14) dsp->ch[0].writeloc=0;
		if (dsp->ch[1].writeloc>=BUFFER_SIZE/8*14) dsp->ch[1].writeloc=0;
	} while (dsp->ch[0].writeloc != dsp->ch[0].readloc);
}

// interleaved files requires streams with knowledge of each other (for proper looping)
void fillbufferGSP(CUBEFILE * dsp) {
	int i,l;
	short decodebuf1[14];
	short decodebuf2[14];
	char ADPCMbuf[8];

	i=0;
	do {

		// make loop
		if ((dsp->ch[0].loop_flag) && (dsp->samplesdone>=dsp->ch[0].ea)) {
			dsp->ch[0].chanstart=dsp->ch[0].loopoffs;
			dsp->ch[1].chanstart=dsp->ch[1].loopoffs;

			dsp->ch[0].offs=dsp->ch[0].sa;
			dsp->ch[1].offs=dsp->ch[1].sa;
			dsp->samplesdone=dsp->loopsamplesdone;

			i=dsp->loophalpsize;
		}

		if(i==0) {
			
			// decode stuff
			SetFilePointer(dsp->ch[0].infile, dsp->ch[0].offs,0,FILE_BEGIN);
			ReadFile(dsp->ch[0].infile, ADPCMbuf, 8, &l, NULL);
			DSPdecodebuffer(ADPCMbuf,decodebuf1,dsp->ch[0].coef,&dsp->ch[0].hist1,&dsp->ch[0].hist2);

			SetFilePointer(dsp->ch[0].infile, dsp->ch[1].offs,0,FILE_BEGIN);
			ReadFile(dsp->ch[1].infile, ADPCMbuf, 8, &l, NULL);
			DSPdecodebuffer(ADPCMbuf,decodebuf2,dsp->ch[1].coef,&dsp->ch[1].hist1,&dsp->ch[1].hist2);

			i=14;

			dsp->ch[0].offs+=8;
			dsp->ch[1].offs+=8;

			// handle interleave
			if (dsp->ch[0].interleave!=0) {
				if ((dsp->ch[0].offs-dsp->ch[0].chanstart)%dsp->ch[0].interleave==0) {
					if(dsp->NCH==2) dsp->ch[0].offs+=dsp->ch[0].interleave;
					dsp->ch[0].chanstart+=0x20;
					dsp->ch[0].offs+=0x20; 
				}

				if ((dsp->ch[1].offs-dsp->ch[1].chanstart)%dsp->ch[1].interleave==0) {
					dsp->ch[1].offs+=dsp->ch[1].interleave;
					dsp->ch[1].chanstart+=0x20;
					dsp->ch[1].offs+=0x20;
				}
			}
		}

		dsp->samplesdone++;
		
		// Do Loop ...
		if ((dsp->ch[0].loop_flag && dsp->samplesdone==dsp->ch[0].sa) && dsp->ch[0].loopoffs==0) {
			dsp->loopsamplesdone=dsp->samplesdone;
			dsp->ch[0].loopoffs=dsp->ch[0].chanstart;
			dsp->ch[1].loopoffs=dsp->ch[1].chanstart;
			dsp->ch[0].sa=dsp->ch[0].offs;
			dsp->ch[1].sa=dsp->ch[1].offs;
			dsp->loophalpsize=i;
		}

		dsp->ch[0].chanbuf[dsp->ch[0].writeloc++]=decodebuf1[14-i];
		dsp->ch[1].chanbuf[dsp->ch[1].writeloc++]=decodebuf2[14-i];
		i--;
		if (dsp->ch[0].writeloc>=BUFFER_SIZE/8*14) dsp->ch[0].writeloc=0;
		if (dsp->ch[1].writeloc>=BUFFER_SIZE/8*14) dsp->ch[1].writeloc=0;

	} while (dsp->ch[0].writeloc != dsp->ch[0].readloc);
}


// the streams are byte-interleaved, causing no end of confusion
void fillbufferDSPfsb3(CUBEFILE * dsp) {
	int i,l,j;
	short decodebuf1[14];
	short decodebuf2[14];
	char ADPCMbuf[8];
	char readbuf[16];

	i=0;
	do {
		if (i==0) {

			SetFilePointer(dsp->ch[0].infile, dsp->ch[0].offs,0,FILE_BEGIN);
				
			ReadFile(dsp->ch[0].infile, readbuf, 16, &l, NULL);
				
			for(i=0, j=0;i<8;) {
				ADPCMbuf[i++]=readbuf[j++];
				ADPCMbuf[i++]=readbuf[j++];
				j+=2;
			}
				
			DSPdecodebuffer(ADPCMbuf,decodebuf1,dsp->ch[0].coef,&dsp->ch[0].hist1,&dsp->ch[0].hist2);

			for(i=0, j=2;i<8;) {
				ADPCMbuf[i++]=readbuf[j++];
				ADPCMbuf[i++]=readbuf[j++];
				j+=2;
			}
			DSPdecodebuffer(ADPCMbuf,decodebuf2,dsp->ch[1].coef,&dsp->ch[1].hist1,&dsp->ch[1].hist2);

			i=14;
			dsp->ch[0].offs+=16;

			if (dsp->ch[0].loop_flag && (
				(dsp->ch[0].offs-dsp->ch[0].chanstart)>=dsp->ch[0].ea*dsp->ch[0].bps/8*2)) {
			
				dsp->ch[0].offs=dsp->ch[0].chanstart+(dsp->ch[0].sa&(~7))*dsp->ch[0].bps/8*2;
				dsp->ch[1].offs=dsp->ch[1].chanstart+(dsp->ch[1].sa&(~7))*dsp->ch[1].bps/8*2;
				
				DisplayError("loop\nch[1].offs=%08x",dsp->ch[1].offs);
			}
		}
		dsp->ch[0].chanbuf[dsp->ch[0].writeloc++]=decodebuf1[14-i];
		dsp->ch[1].chanbuf[dsp->ch[1].writeloc++]=decodebuf2[14-i];
		i--;
		if (dsp->ch[0].writeloc>=BUFFER_SIZE/8*14) dsp->ch[0].writeloc=0;
		if (dsp->ch[1].writeloc>=BUFFER_SIZE/8*14) dsp->ch[1].writeloc=0;
	} while (dsp->ch[0].writeloc != dsp->ch[0].readloc);
}
