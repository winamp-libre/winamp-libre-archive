/**
 * based on work
 * by loveemu
*/
#include <windows.h>
#include "wamain.h"
#include "cube.h"

const unsigned ADPCMTable[89] = 
{
	7, 8, 9, 10, 11, 12, 13, 14,
	16, 17, 19, 21, 23, 25, 28, 31,
	34, 37, 41, 45, 50, 55, 60, 66,
	73, 80, 88, 97, 107, 118, 130, 143,
	157, 173, 190, 209, 230, 253, 279, 307,
	337, 371, 408, 449, 494, 544, 598, 658,
	724, 796, 876, 963, 1060, 1166, 1282, 1411,
	1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024,
	3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484,
	7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899,
	15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
	32767
};

const int IMA_IndexTable[16] = 
{
	-1, -1, -1, -1, 2, 4, 6, 8,
	-1, -1, -1, -1, 2, 4, 6, 8 
};

void clamp_step_index(int* stepIndex)
{
  if (*stepIndex < 0 ) *stepIndex = 0;
  if (*stepIndex > 88) *stepIndex = 88;
}

void clamp_sample(int* decompSample)
{
  if (*decompSample < -32768) *decompSample = -32768;
  if (*decompSample >  32767) *decompSample =  32767;
}

void process_nibble(unsigned char code, int* stepIndex, int* decompSample)
{

  //unsigned step;
  //int diff;
  s32 step;
  s32 diff;

  code &= 0x0F;

  step = ADPCMTable[*stepIndex];
  diff = step >> 3;
  if (code & 1) diff += step >> 2;
  if (code & 2) diff += step >> 1;
  if (code & 4) diff += step;
  if (code & 8) *decompSample -= diff;
  else          *decompSample += diff;
  clamp_sample(decompSample);
  (*stepIndex) += IMA_IndexTable[code];
  clamp_step_index(stepIndex);
}

__inline int mput2l(int value, byte* data)
{
  int lastPut = value;
  data[0] = lastPut & 0xff;
  lastPut /= 0x0100;
  data[1] = lastPut & 0xff;
  return lastPut & 0xff;
}

/* unsigned 2bytes to signed */
__inline int utos2(unsigned int value)
{
  return (value & 0x8000) ? -(signed)(value ^ 0xffff)-1 : value;
}

void fillbufferIMA(CUBEFILE *imapcm) {
	unsigned long readBytes;
	unsigned long i;
	unsigned long currBlockSize;
	unsigned char PCMbuf[0x800];
	byte	iChannel=0;
	byte	code;

	for(iChannel=0;iChannel<imapcm->NCH;iChannel++)
	{
		imapcm->ch[iChannel].IMABlockCount++;

		if (imapcm->ch[iChannel].IMABlockCount<imapcm->ch[iChannel].IMABlockLength) 
			currBlockSize=imapcm->ch[iChannel].blockSize;
		else
			currBlockSize=imapcm->ch[iChannel].lastBlockSize;

		SetFilePointer(imapcm->ch[iChannel].infile,imapcm->ch[iChannel].offs+currBlockSize*iChannel,0,FILE_BEGIN);
		ReadFile(imapcm->ch[iChannel].infile,PCMbuf,currBlockSize,&readBytes,NULL);

		if (readBytes!=currBlockSize) {
			DisplayError("bad read %d expected %d",readBytes,currBlockSize);
			return;
		}

		// Get sample value & index from header ...
		imapcm->ch[iChannel].IMASample=utos2(get16bitL(PCMbuf));
		imapcm->ch[iChannel].IMAIndex=get16bitL(PCMbuf+2);

		// Decode samples ...
		if (imapcm->ch[iChannel].loop_hit) {
			imapcm->ch[iChannel].loop_hit=0;
			i=imapcm->ch[iChannel].loop_nibbles_into_block;
		} else i=0;
		for (;i<(currBlockSize-4)*2;i++) {
			// do decode
			code = PCMbuf[i/2+4];

			if (!(i&1)) {
				process_nibble(code,&imapcm->ch[iChannel].IMAIndex,&imapcm->ch[iChannel].IMASample);

				mput2l(imapcm->ch[iChannel].IMASample,(byte*)&imapcm->ch[iChannel].chanbuf[imapcm->ch[iChannel].writeloc++]);
				if (imapcm->ch[iChannel].writeloc>=BUFFER_SIZE/8*14) imapcm->ch[iChannel].writeloc=0;
			} else {

				process_nibble(code >> 4,&imapcm->ch[iChannel].IMAIndex,&imapcm->ch[iChannel].IMASample);

				mput2l(imapcm->ch[iChannel].IMASample,(byte*)&imapcm->ch[iChannel].chanbuf[imapcm->ch[iChannel].writeloc++]);
				if (imapcm->ch[iChannel].writeloc>=BUFFER_SIZE/8*14) imapcm->ch[iChannel].writeloc=0;
			}

			// Set Loop ...

			if((imapcm->ch[iChannel].loop_flag!=0) && (imapcm->ch[iChannel].loopoffs==0) && (imapcm->ch[iChannel].num_adpcm_nibbles==imapcm->ch[iChannel].sa))
			{
				//DisplayError("loop start ch%d\nnum_adpcm_nibbles=%x\noffset=%x\nbytesin=%d",iChannel,imapcm->ch[iChannel].num_adpcm_nibbles,imapcm->ch[iChannel].offs,i);
				imapcm->ch[iChannel].loopadpcm_nibbles=imapcm->ch[iChannel].num_adpcm_nibbles;
				imapcm->ch[iChannel].loop_nibbles_into_block=i;
				imapcm->ch[iChannel].loopoffs=imapcm->ch[iChannel].offs;
				imapcm->ch[iChannel].IMABlockCountSave=imapcm->ch[iChannel].IMABlockCount-1;
			}

			// Do Loop ...
			if((imapcm->ch[iChannel].loop_flag!=0) && (imapcm->ch[iChannel].num_adpcm_nibbles==imapcm->ch[iChannel].ea)) {
				DisplayError("loop end ch%d\nnum_adpcm_nibbles=%x\noffset=%x\nbytesin=%d",iChannel,imapcm->ch[iChannel].num_adpcm_nibbles,imapcm->ch[iChannel].offs,i);
				
				imapcm->ch[iChannel].num_adpcm_nibbles=imapcm->ch[iChannel].loopadpcm_nibbles;
				imapcm->ch[iChannel].offs=imapcm->ch[iChannel].loopoffs-currBlockSize*imapcm->NCH;
				imapcm->ch[iChannel].IMABlockCount=imapcm->ch[iChannel].IMABlockCountSave;
				imapcm->ch[iChannel].loop_hit=1;

				break;
			}

			imapcm->ch[iChannel].num_adpcm_nibbles++;
		}

		// Do Loop ... one more time, loop end tends to be right after
		if((imapcm->ch[iChannel].loop_flag!=0) && (imapcm->ch[iChannel].num_adpcm_nibbles==imapcm->ch[iChannel].ea)) {
			DisplayError("loop end (end of block) ch%d\nnum_adpcm_nibbles=%x\noffset=%x\nbytesin=%d",iChannel,imapcm->ch[iChannel].num_adpcm_nibbles,imapcm->ch[iChannel].offs,i);
				
			imapcm->ch[iChannel].num_adpcm_nibbles=imapcm->ch[iChannel].loopadpcm_nibbles;
			imapcm->ch[iChannel].offs=imapcm->ch[iChannel].loopoffs-currBlockSize*imapcm->NCH;
			imapcm->ch[iChannel].IMABlockCount=imapcm->ch[iChannel].IMABlockCountSave;
			imapcm->ch[iChannel].loop_hit=1;

		}

		imapcm->ch[iChannel].offs+=currBlockSize*imapcm->NCH;
	}
}

void fillbufferIMASWAV(CUBEFILE *imapcm) {
	unsigned long readBytes;
	unsigned long i;
	unsigned long currBlockSize;
	unsigned char PCMbuf[0x800];
	byte	iChannel=0;
	byte	code;

	imapcm->ch[0].IMABlockCount++;
	
	if(imapcm->ch[0].IMABlockCount>imapcm->ch[0].IMABlockLength)
		return;

	if (imapcm->ch[0].IMABlockCount<imapcm->ch[0].IMABlockLength) 
		currBlockSize=imapcm->ch[0].blockSize;
	else
		currBlockSize=imapcm->ch[0].lastBlockSize;

	SetFilePointer(imapcm->ch[0].infile,imapcm->ch[0].offs,0,FILE_BEGIN);

	// Get sample value & index from header ...
	if(imapcm->ch[0].IMABlockCount==1) {
		for(iChannel=0;iChannel<imapcm->NCH;iChannel++)
		{
			ReadFile(imapcm->ch[0].infile,PCMbuf,4,&readBytes,NULL);
			imapcm->ch[iChannel].IMASample=utos2(get16bitL(PCMbuf));
			imapcm->ch[iChannel].IMAIndex=get16bitL(PCMbuf+2);
		}
	}

	ReadFile(imapcm->ch[0].infile,PCMbuf,currBlockSize,&readBytes,NULL);

	if (readBytes!=currBlockSize) {
		DisplayError("bad read %d expected %d",readBytes,currBlockSize);
		return;
	}

	// Decode samples ...
	if (imapcm->ch[0].loop_hit) {
		imapcm->ch[0].loop_hit=0;
		i=imapcm->ch[0].loop_nibbles_into_block;
	} else i=0;

	// do decode
	iChannel=0;

	for(i = 0; i < currBlockSize; i+=imapcm->NCH) {
		for(iChannel=0;iChannel<imapcm->NCH;iChannel++)	{
			code = PCMbuf[iChannel+i];

			process_nibble(code,&imapcm->ch[iChannel].IMAIndex,&imapcm->ch[iChannel].IMASample);

			mput2l(imapcm->ch[iChannel].IMASample,(byte*)&imapcm->ch[iChannel].chanbuf[imapcm->ch[iChannel].writeloc++]);
			if (imapcm->ch[iChannel].writeloc>=BUFFER_SIZE/8*14) imapcm->ch[iChannel].writeloc=0;

			process_nibble(code >> 4,&imapcm->ch[iChannel].IMAIndex,&imapcm->ch[iChannel].IMASample);

			mput2l(imapcm->ch[iChannel].IMASample,(byte*)&imapcm->ch[iChannel].chanbuf[imapcm->ch[iChannel].writeloc++]);
			if (imapcm->ch[iChannel].writeloc>=BUFFER_SIZE/8*14) imapcm->ch[iChannel].writeloc=0;

			// Set Loop ...

			if((imapcm->ch[iChannel].loop_flag!=0) && (imapcm->ch[iChannel].loopoffs==0) && (imapcm->ch[iChannel].num_adpcm_nibbles==imapcm->ch[iChannel].sa))
			{
				//DisplayError("loop start ch%d\nnum_adpcm_nibbles=%x\noffset=%x\nbytesin=%d",iChannel,imapcm->ch[iChannel].num_adpcm_nibbles,imapcm->ch[iChannel].offs,i);
				imapcm->ch[iChannel].loopadpcm_nibbles=imapcm->ch[iChannel].num_adpcm_nibbles;
				imapcm->ch[iChannel].loop_nibbles_into_block=i;
				imapcm->ch[iChannel].loopoffs=imapcm->ch[iChannel].offs;
				imapcm->ch[iChannel].IMABlockCountSave=imapcm->ch[iChannel].IMABlockCount-1;
			}

			// Do Loop ...
			if((imapcm->ch[iChannel].loop_flag!=0) && (imapcm->ch[iChannel].num_adpcm_nibbles==imapcm->ch[iChannel].ea)) {
				DisplayError("loop end ch%d\nnum_adpcm_nibbles=%x\noffset=%x\nbytesin=%d",iChannel,imapcm->ch[iChannel].num_adpcm_nibbles,imapcm->ch[iChannel].offs,i);
				
				imapcm->ch[iChannel].num_adpcm_nibbles=imapcm->ch[iChannel].loopadpcm_nibbles;
				imapcm->ch[iChannel].offs=imapcm->ch[iChannel].loopoffs-currBlockSize*imapcm->NCH;
				imapcm->ch[iChannel].IMABlockCount=imapcm->ch[iChannel].IMABlockCountSave;
				imapcm->ch[iChannel].loop_hit=1;
				
				break;
			}
			imapcm->ch[iChannel].num_adpcm_nibbles++;
		}
	}

	// Do Loop ...
	if((imapcm->ch[iChannel].loop_flag!=0) && (imapcm->ch[iChannel].num_adpcm_nibbles==imapcm->ch[iChannel].ea)) {
		DisplayError("loop end ch%d\nnum_adpcm_nibbles=%x\noffset=%x\nbytesin=%d",iChannel,imapcm->ch[iChannel].num_adpcm_nibbles,imapcm->ch[iChannel].offs,i);
		
		imapcm->ch[iChannel].num_adpcm_nibbles=imapcm->ch[iChannel].loopadpcm_nibbles;
		imapcm->ch[iChannel].offs=imapcm->ch[iChannel].loopoffs-currBlockSize*imapcm->NCH;
		imapcm->ch[iChannel].IMABlockCount=imapcm->ch[iChannel].IMABlockCountSave;
		imapcm->ch[iChannel].loop_hit=1;
	}

	imapcm->ch[0].offs+=currBlockSize;
}

void fillBufferMUSX(CUBEFILE *musx)
{

	unsigned char buffer[0x20];
	int i,iChannel;
	unsigned long byteRead;
	byte	code;

	for(iChannel=0; iChannel<musx->NCH; iChannel++) {

		SetFilePointer(musx->ch[0].infile,musx->ch[0].offs,0,FILE_BEGIN);
		ReadFile(musx->ch[0].infile,buffer,0x20,&byteRead,NULL);
		
		musx->ch[iChannel].IMASample=utos2(get16bitL(buffer));
		musx->ch[iChannel].IMAIndex=buffer[2];

		for(i = 4; i < 0x20; i++) {

			code = buffer[i];

			process_nibble(code >> 4,&musx->ch[iChannel].IMAIndex,&musx->ch[iChannel].IMASample);

			mput2l(musx->ch[iChannel].IMASample,(byte*)&musx->ch[iChannel].chanbuf[musx->ch[iChannel].writeloc++]);
			if (musx->ch[iChannel].writeloc>=BUFFER_SIZE/8*14) musx->ch[iChannel].writeloc=0;

			process_nibble(code ,&musx->ch[iChannel].IMAIndex,&musx->ch[iChannel].IMASample);

			mput2l(musx->ch[iChannel].IMASample,(byte*)&musx->ch[iChannel].chanbuf[musx->ch[iChannel].writeloc++]);
			if (musx->ch[iChannel].writeloc>=BUFFER_SIZE/8*14) musx->ch[iChannel].writeloc=0;

			// Make Loop ...
			if((musx->ch[0].loop_flag) && (musx->ch[0].offs+i>=musx->loop_start_offset) && (musx->ch[0].loopoffs==0)) {
				if(iChannel==1)
					musx->ch[0].loopoffs=musx->ch[0].offs;
			}

			// Do Loop (not very accurate, but it makes no difference)
			if((musx->ch[0].loop_flag) && (musx->ch[0].offs+i>=musx->loop_end_offset)) {
				if(iChannel==1) 
					musx->ch[0].offs=musx->ch[0].loopoffs;
			}
		}
		musx->ch[0].offs+=0x20;
	}
}

void fillBufferRIFF_IMA(CUBEFILE *riff)
{

	unsigned char buffer[0x100];
	int i,iChannel;
	unsigned long byteRead;
	byte	code;

	if(riff->ch[0].IMABlockCount==0) {
		SetFilePointer(riff->ch[0].infile,riff->ch[0].offs,0,FILE_BEGIN);
		ReadFile(riff->ch[0].infile,buffer,0x20,&byteRead,NULL);
		riff->ch[0].IMASample=0; //utos2(get16bitL(buffer));
		riff->ch[0].IMAIndex=0; //get16bitL(buffer+0x02);
		riff->ch[0].IMASample=0; //utos2(get16bitL(buffer+0x04));
		riff->ch[0].IMAIndex=0; //get16bitL(buffer+0x06);
		riff->ch[0].offs+=0x0C;
	}

	for(iChannel=0; iChannel<riff->NCH; iChannel++) {

		SetFilePointer(riff->ch[0].infile,riff->ch[0].offs,0,FILE_BEGIN);
		ReadFile(riff->ch[0].infile,buffer,0x80,&byteRead,NULL);
		
		for(i = 0; i < 0x80; i++) {

			code = buffer[i];

			process_nibble(code >> 4,&riff->ch[iChannel].IMAIndex,&riff->ch[iChannel].IMASample);

			mput2l(riff->ch[iChannel].IMASample,(byte*)&riff->ch[iChannel].chanbuf[riff->ch[iChannel].writeloc++]);
			if (riff->ch[iChannel].writeloc>=BUFFER_SIZE/8*14) riff->ch[iChannel].writeloc=0;

			process_nibble(code  ,&riff->ch[iChannel].IMAIndex,&riff->ch[iChannel].IMASample);

			mput2l(riff->ch[iChannel].IMASample,(byte*)&riff->ch[iChannel].chanbuf[riff->ch[iChannel].writeloc++]);
			if (riff->ch[iChannel].writeloc>=BUFFER_SIZE/8*14) riff->ch[iChannel].writeloc=0;

/*			// Make Loop ...
			if((riff->ch[0].loop_flag) && (riff->ch[0].offs+i>=riff->loop_start_offset) && (riff->ch[0].loopoffs==0)) {
				if(iChannel==1)
					riff->ch[0].loopoffs=riff->ch[0].offs;
			}

			// Do Loop (not very accurate, but it makes no difference)
			if((riff->ch[0].loop_flag) && (riff->ch[0].offs+i>=riff->loop_end_offset)) {
				if(iChannel==1) 
					riff->ch[0].offs=riff->ch[0].loopoffs;
			} 
*/		}
		riff->ch[0].IMABlockCount++;
		riff->ch[0].offs+=0x80;
	}
}


void fillBufferXBOX(CUBEFILE *xbox)
{
    unsigned char buffer[80], *pBuffer;
	int	bytesRead;

    unsigned int NbSamplesPlayed = 0;
	byte CodeBuf=0;
	int i,j,nChannel;

	if ((SetFilePointer(xbox->ch[0].infile,0,0,FILE_CURRENT) - xbox->ch[0].chanstart) > xbox->file_length)
		return;

	pBuffer=&buffer;

	SetFilePointer(xbox->ch[0].infile,xbox->ch[0].offs,0,FILE_BEGIN);
	ReadFile(xbox->ch[0].infile, buffer,0x48,&bytesRead,NULL);
	
	xbox->ch[0].offs += (36 * xbox->NCH);

	for(nChannel=0;nChannel<xbox->NCH;nChannel++) {
		xbox->ch[nChannel].IMASample= utos2(get16bitL(buffer+(nChannel*4)));
		xbox->ch[nChannel].IMAIndex = get16bitL(buffer+2+(nChannel*4));
		xbox->ch[nChannel].chanbuf[xbox->ch[nChannel].writeloc++]=(short)xbox->ch[nChannel].IMASample;
	}
	
	pBuffer+=(4*xbox->NCH);

	for(i = 0; i < 8; i++) {
		for(nChannel=0;nChannel<xbox->NCH;nChannel++)	{
			for(j = 0; j < 4; j++) 	{
				CodeBuf = *pBuffer++;

				process_nibble(CodeBuf ,&xbox->ch[nChannel].IMAIndex, &xbox->ch[nChannel].IMASample);
				//mput2l(xbox->ch[nChannel].IMASample,(byte*)&xbox->ch[nChannel].chanbuf[xbox->ch[nChannel].writeloc++]);
				xbox->ch[nChannel].chanbuf[xbox->ch[nChannel].writeloc++]=(short)xbox->ch[nChannel].IMASample;
				if (xbox->ch[nChannel].writeloc>=BUFFER_SIZE/8*14) xbox->ch[nChannel].writeloc=0;

				CodeBuf >>= 4;

				process_nibble(CodeBuf ,&xbox->ch[nChannel].IMAIndex, &xbox->ch[nChannel].IMASample);
				//mput2l(xbox->ch[nChannel].IMASample,(byte*)&xbox->ch[nChannel].chanbuf[xbox->ch[nChannel].writeloc++]);
				xbox->ch[nChannel].chanbuf[xbox->ch[nChannel].writeloc++]=(short)xbox->ch[nChannel].IMASample;
				if (xbox->ch[nChannel].writeloc>=BUFFER_SIZE/8*14) xbox->ch[nChannel].writeloc=0;
			}

		}
	}
}

int InitXBOX(char * inputfile, CUBEFILE * xbox)
{
	unsigned char readbuf[0x80];
	char tampon[4];
	int l;

	if (inputfile) 
	{
		xbox->ch[0].infile=xbox->ch[1].infile=INVALID_HANDLE_VALUE;
		xbox->ch[0].readloc=xbox->ch[0].writeloc=0;
		xbox->ch[1].readloc=xbox->ch[1].writeloc=0;
		xbox->ch[0].ea=xbox->ch[1].ea=0;
		xbox->ch[0].loop_flag=xbox->ch[1].loop_flag=0;
		xbox->ch[0].chanstart=0;
		xbox->ch[0].bps=xbox->ch[1].bps=16;
		
		if (!strcmpi(inputfile+strlen(inputfile)-5,".wavm")) 
		{

			xbox->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
				OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

			if (xbox->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
				return 1;

			xbox->ch[0].Predictor=xbox->ch[1].Predictor=0;
			xbox->ch[0].StepSize=xbox->ch[1].StepSize=0;
			xbox->ch[0].index=xbox->ch[1].index=0;
			xbox->ch[0].Predictor=xbox->ch[1].Predictor=0;
			xbox->ch[0].type=type_xbox;
			xbox->NCH=2;
			xbox->ch[0].sample_rate=xbox->ch[1].sample_rate=44100;
			xbox->file_length=GetFileSize(xbox->ch[0].infile,NULL);
			xbox->nrsamples= ((xbox->file_length / (36 * xbox->NCH)) * 130)/2;
			xbox->ch[0].offs=0;
			xbox->ch[0].chanstart=0;
			return 0;
		}
		else
		{
			xbox->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
				OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

			if (xbox->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
				return 1;
	
			ReadFile(xbox->ch[0].infile,readbuf,0x80, &l,NULL);
			xbox->file_length=GetFileSize(xbox->ch[0].infile,NULL);

			if (!memcmp(readbuf,"xbaud",5))
			{
				xbox->ch[0].type=type_xmu;
                xbox->NCH = get16bitL(readbuf+0x0a);
				xbox->ch[0].sample_rate = get32bitL(readbuf + 0x0c);
                xbox->nrsamples = ((xbox->file_length / 36 ) * 130)/xbox->NCH;
                xbox->ch[0].offs = xbox->ch[0].chanstart= 0x20;
				return 0;
			} else if(!memcmp(readbuf,"FSB",3)) {
				// FSB XBOX
				if((get32bitL(readbuf+0x48)== (int)0x00480041) || 
				  (!memcmp(readbuf+0x48,"\x40\x00\x40",3)))
				{
					xbox->ch[0].type = type_xbfsb;
					xbox->NCH = 2;
					xbox->file_length = get32bitL(readbuf + 0x0c) + 0x58;
					xbox->nrsamples = (xbox->file_length / 36 * 130)/4;
					xbox->ch[0].sample_rate=xbox->ch[1].sample_rate=get32bitL(readbuf+0x4c);
                    if(get32bitL(readbuf+0x14)==0x0030001)
                        xbox->ch[0].offs = 0x68;
                    else if (!memcmp(readbuf+0x48,"\x40\x00\x40",3))
						if(!memcmp(readbuf+0x68,"SYNC",4))
							xbox->ch[0].offs=0x380;
						else
							xbox->ch[0].offs = 0x70;
					else
                        xbox->ch[0].offs = 0x58;
                    return 0;
				}
			}
			else if (!memcmp(readbuf,"RIFF",4))
			{
				if (!memcmp(readbuf+0x08,"WAVEfmt",7))
				{
					if (get16bitL(readbuf+0x14) == (int)0x0069)
					{
						xbox->ch[0].type=type_xbox;
						xbox->NCH = get16bitL(readbuf+0x16);
						xbox->ch[0].sample_rate=get32bitL(readbuf+0x18);

						// Search for "data"
						SetFilePointer(xbox->ch[0].infile,0x1C,0,FILE_BEGIN);
						do
						{
							ReadFile(xbox->ch[0].infile,tampon,4,&l,NULL);
							if(!memcmp(tampon,"data",4))
								break;
						} while (l!=0);
						
						if (l==0)
						{
							CloseCUBEFILE(xbox);
							return 1;
						}

						xbox->ch[0].offs=xbox->ch[0].chanstart=SetFilePointer(xbox->ch[0].infile,0,0,FILE_CURRENT)+4;
						ReadFile(xbox->ch[0].infile,tampon,4,&l,NULL);
						xbox->nrsamples=(xbox->file_length / 36 * 130)/4;
						return 0;

					}
				}
			}
		}
	}
	
	CloseCUBEFILE(xbox);
	return 1;
}