/*

  thp player
  by fastelbja

  based upon the work of thakis 

*/
#include <windows.h>
#include "wamain.h"
#include "cube.h"

extern unsigned int SwapUnsignedInt(unsigned int x);

typedef struct 
{
  u32 numComponents; //usually 1 or 2 (video or video + audio)

  //component type 0 is video, type 1 is audio,
  //type 0xff is "no component" (numComponent many entries
  //are != 0xff)
  u8 componentTypes[16];
} ThpComponents;

typedef struct 
{
  u32 numChannels;
  u32 frequency;
  u32 numSamples;
  u32 numData; //only for version 1.1 - that many
               //audio blocks are after each video block
               //(for surround sound?)
} ThpAudioInfo;

int InitTHPFILE(char * inputfile, CUBEFILE * thp) {

	u8 readBuffer[0x60];
	u32	bytesRead=0,i=0;
	u32	maxFrameSize=0;
	u32	maxAudioSize=0;

	ThpComponents	thpComp;
	ThpAudioInfo	thpAudio;

	if (inputfile) {
		thp->ch[0].infile=thp->ch[1].infile=INVALID_HANDLE_VALUE;

		thp->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

		if (thp->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
			return 1;

	} else if (thp->ch[0].type!=type_thp) return 1; // we don't have the file name to recheck

	ReadFile(thp->ch[0].infile,readBuffer,0x60,&bytesRead,NULL);

	if (memcmp(&readBuffer,"THP\0",4)) {
		CloseCUBEFILE(thp);
		return 1;
	}
	
	maxFrameSize = get32bit(readBuffer+0x08);
	maxAudioSize = get32bit(readBuffer+0x0C);
	
	if(maxAudioSize==0) {
		CloseCUBEFILE(thp);
		return 1;
	}

	thp->ch[0].chanstart=thp->ch[0].offs=get32bit(readBuffer+0x28);
	thp->NextFrameSize=get32bit(readBuffer+0x18);

	thp->ch[0].bps=thp->ch[1].bps=16;

	SetFilePointer(thp->ch[0].infile,get32bit(readBuffer+0x20),0,FILE_BEGIN);
	ReadFile(thp->ch[0].infile,&thpComp,sizeof(ThpComponents),&bytesRead,NULL);
	thpComp.numComponents=SwapUnsignedInt(thpComp.numComponents);
	
	for(i=0;i<thpComp.numComponents;i++) {
		if(thpComp.componentTypes[i]==0) 
			SetFilePointer(thp->ch[0].infile,0x0c,0,FILE_CURRENT);

		if(thpComp.componentTypes[i]==1) {
			ReadFile(thp->ch[0].infile,&thpAudio,sizeof(ThpAudioInfo),&bytesRead,NULL);
			thp->NCH=SwapUnsignedInt(thpAudio.numChannels);
			thp->ch[0].sample_rate=thp->ch[1].sample_rate=SwapUnsignedInt(thpAudio.frequency);
			thp->nrsamples=SwapUnsignedInt(thpAudio.numSamples);
		}
	}

	//check sample rate
	if (!CheckSampleRate(thp->ch[0].sample_rate)) {
		//DisplayError("bad srate %d",thp->ch[0].sample_rate);
		CloseCUBEFILE(thp);
		return 1;
	}

	thp->ch[0].type=thp->ch[1].type=type_thp;
	return 0;
}

void fillbufferTHP(CUBEFILE * thp) {

	u32	soundOffset;

	int i,l;
	short decodebuf[14];
	char ADPCMbuf[8];
	u8	frameData[0x8000]; // hope it will be enough :P
	u32	sizeBuffer,j;
	u32	bytesRead=0;
	u32	nextFrameSize=0;

	SetFilePointer(thp->ch[0].infile,thp->ch[0].offs,0,FILE_BEGIN);
	ReadFile(thp->ch[0].infile,&frameData,0x50,&bytesRead,NULL);

	soundOffset=get32bit(frameData+0x08)+0x10;
	nextFrameSize=get32bit(frameData);

	SetFilePointer(thp->ch[0].infile,thp->ch[0].offs+soundOffset,0,FILE_BEGIN);
	ReadFile(thp->ch[0].infile,&frameData,0x08,&bytesRead,NULL);
	sizeBuffer = get32bit(frameData);

	ReadFile(thp->ch[0].infile,&frameData,(sizeBuffer*thp->NCH)+0x48,&bytesRead,NULL);

	// Channel 1 ...
	// Copy Coeff & initialize the hist sample value
	for(i=0; i<16; i++)
		thp->ch[0].coef[i]=get16bit(frameData+(2*i));

	thp->ch[0].hist1=get16bit(frameData+0x40);
	thp->ch[0].hist2=get16bit(frameData+0x42);

	// Channel 2 ...
	// Copy Coeff & initialize the hist sample value
	if(thp->NCH==2)
	{
		for(i=0; i<16; i++)
			thp->ch[1].coef[i]=get16bit(frameData+0x20+(2*i));

		thp->ch[1].hist1=get16bit(frameData+0x44);
		thp->ch[1].hist2=get16bit(frameData+0x46);
	}

	soundOffset=0;
	for(i=0;i<thp->NCH;i++) {

		for(j=0; j<sizeBuffer;j+=8) {
			memcpy(ADPCMbuf,frameData+soundOffset+0x48+j,8);
			DSPdecodebuffer(ADPCMbuf,decodebuf,thp->ch[i].coef,&thp->ch[i].lhist1,&thp->ch[i].lhist2);
			for(l=14;l>0;l--) {
				thp->ch[i].chanbuf[thp->ch[i].writeloc++]=decodebuf[14-l];
				if (thp->ch[i].writeloc>=BUFFER_SIZE/8*14) thp->ch[i].writeloc=0;
			}
		}
		soundOffset+=sizeBuffer;
	}

	thp->ch[0].offs+=thp->NextFrameSize;
	thp->NextFrameSize=nextFrameSize;
}


