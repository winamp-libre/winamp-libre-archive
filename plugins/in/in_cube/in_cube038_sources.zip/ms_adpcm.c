#include <windows.h>
#include "wamain.h"
#include "cube.h"

extern void clamp_sample(int* decompSample);

static const int AdaptationTable[] = {
        230, 230, 230, 230, 307, 409, 512, 614,
        768, 614, 512, 409, 307, 230, 230, 230
};

static const int AdaptCoeff1[] = {
        256, 512, 0, 192, 240, 460, 392
};

static const int AdaptCoeff2[] = {
        0, -256, 0, 64, 0, -208, -232
};

short adpcm_ms_expand_nibble(CUBESTREAM *channel, char nibble)
{
    int predictor;

    predictor = (((channel->hist1) * (channel->coef[0]))) + ((channel->hist2) * (channel->coef[1])) / 256;
    predictor += (signed)((nibble & 0x08)?(nibble - 0x10):(nibble)) * channel->index;
	clamp_sample(&predictor);

    channel->hist2 = channel->hist1;
    channel->hist1 = predictor;
    channel->index = (AdaptationTable[(int)nibble] * channel->index) >> 8;
    if (channel->index < 16) channel->index = 16;

    return (short)predictor;
}

void fillBufferMSG3(CUBEFILE *ima)
{

	unsigned char buffer[0x110], *pBuffer;
	int i,j,nChannel;
	unsigned long byteRead;
	byte	CodeBuf;
	short sample1;
	short sample2;
	short sample;

	int coeff1;
	int coeff2;
	int idelta;

	SetFilePointer(ima->ch[0].infile,ima->ch[0].offs,0,FILE_BEGIN);
	ReadFile(ima->ch[0].infile,buffer,0x110,&byteRead,NULL);
	if(!memcmp(buffer,ima->sync,16)) {
		ima->ch[0].offs+=0x10;
		SetFilePointer(ima->ch[0].infile,ima->ch[0].offs,0,FILE_BEGIN);
		ReadFile(ima->ch[0].infile,buffer,0x110,&byteRead,NULL);
	}
		
	//ima->ch[0].

	pBuffer = buffer;

	pBuffer+=0x3;
	
	ima->ch[0].coef[0]=AdaptCoeff1[*pBuffer];
	ima->ch[0].coef[1]=AdaptCoeff2[*pBuffer];
	ima->ch[1].coef[0]=AdaptCoeff1[*pBuffer];
	ima->ch[1].coef[1]=AdaptCoeff2[*pBuffer++];
	ima->ch[0].index=get16bitL(pBuffer);
	pBuffer+=2;
	ima->ch[1].index=get16bitL(pBuffer);
	pBuffer+=2;
	ima->ch[0].hist1=get16bitL(pBuffer);
	pBuffer+=2;
	ima->ch[0].hist2=get16bitL(pBuffer);
	pBuffer+=2;
	ima->ch[1].hist1=get16bitL(pBuffer);
	pBuffer+=2;
	ima->ch[1].hist2=get16bitL(pBuffer);
	pBuffer+=2;

	for(nChannel=0;nChannel<ima->NCH;nChannel++)	
	{
		ima->ch[nChannel].chanbuf[ima->ch[nChannel].writeloc++]=ima->ch[nChannel].hist1;
		if (ima->ch[nChannel].writeloc>=BUFFER_SIZE/8*14) ima->ch[nChannel].writeloc=0;

		for(j = 0; j < (byteRead-0x10)/2 ; j++) 	
		{
			CodeBuf = *pBuffer;


			sample=adpcm_ms_expand_nibble(&ima->ch[nChannel], CodeBuf & 0x0f );
			ima->ch[nChannel].chanbuf[ima->ch[nChannel].writeloc++]=sample;
			if (ima->ch[nChannel].writeloc>=BUFFER_SIZE/8*14) ima->ch[nChannel].writeloc=0;

			CodeBuf >>= 4;

			sample=adpcm_ms_expand_nibble(&ima->ch[nChannel], CodeBuf & 0x0f );
			ima->ch[nChannel].chanbuf[ima->ch[nChannel].writeloc++]=sample;
			if (ima->ch[nChannel].writeloc>=BUFFER_SIZE/8*14) ima->ch[nChannel].writeloc=0;
		}

	}
	ima->ch[0].offs+=0x110;
}

