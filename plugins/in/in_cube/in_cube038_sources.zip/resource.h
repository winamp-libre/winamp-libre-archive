//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dsp.rc
//
#define IDD_CONFIG                      101
#define IDD_INFO                        102
#define IDC_LOOPS                       1000
#define IDC_FADELEN                     1001
#define IDC_LOWVOL                      1002
#define IDC_FADEDELAY                   1003
#define IDC_ONECHAN                     1004
#define IDC_CHANNUM                     1005
#define IDC_PRISLIDER                   1006
#define IDC_CPUPRI                      1007
#define IDC_RSFCOEF1                    1008
#define IDC_RSFCOEF2                    1009
#define IDC_FILENAME                    1009
#define IDC_FORMAT                      1009
#define IDC_FILELENGTH                  1010
#define IDC_RSFCOEF3                    1010
#define IDC_ADXCUTOFF                   1010
#define IDC_LENGTH                      1011
#define IDC_TYPE                        1012
#define IDC_CHANNELS                    1013
#define IDC_FREQUENCY                   1014
#define IDC_LOOP                        1015
#define IDC_LOOPSTART                   1016
#define IDC_LOOPEND                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
