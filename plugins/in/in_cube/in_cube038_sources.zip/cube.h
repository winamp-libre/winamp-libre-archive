/*

  in_cube Gamecube Stream Player for Winamp
  by hcs

  includes work by Destop and bero

*/

// CUBEFILE structure, prototypes for everything

#ifndef _CUBE_H

#define _CUBE_H

#pragma warning(disable:4996) 

#define f32 float
#define u8	unsigned char
#define s8	signed char
#define s16 signed short
#define u16 unsigned short
#define s32 signed long
#define u32 unsigned long

#define BPS 16
#define BUFFER_SIZE 0x8000

int get16bit(unsigned char* p);
int get32bit(unsigned char* p);
int get16bitL(unsigned char* p);
int get32bitL(unsigned char* p);

// both header and file type
typedef enum {
	type_std,   // devkit standard DSP
	type_sfass, // Star Fox Assault Cstr (DSP)
	type_mp2,   // Metroid Prime 2 RS03 (DSP)
	type_pm2,   // Paper Mario 2 STM (DSP)
	type_halp,  // HALPST (DSP)
	type_mp2d,  // Metroid Prime 2 Demo (DSP)
	type_idsp,  // IDSP (DSP)
	type_spt,   // SPT+SPD (DSP)
	type_mss,   // MSS (DSP)
	type_gcm,   // GCM (DSP)
	type_mpdsp, // Monopoly Party hack (DSP)
	type_ish,   // ISH+ISD (DSP)
	type_ymf,   // YMF (DSP)
	type_rsddsp,// RSD (DSP)
	type_idsp2, // IDSP (Harvest Moon - Another Wonderful Life) (DSP)
	type_gcub,  // GCub (DSP)
	type_wam,   // WAM (RIFF) (DSP)
	type_wvs,   // WVS (DSP)
	type_adx03, // ADX type 03
	type_adx04, // ADX type 04
	type_adp,   // ADP
	type_rsdpcm,// RSD (PCM)
	type_astpcm,// AST (PCM)
	type_whdpcm,// (from WHD, Hitman 2) (PCM)
	type_rstmpcm_wii, // RSTM (PCM)
	type_strm_nds, // STRM (PCM)
	type_strm_nds_8bits, // STRM (PCM) 8 bits
	type_strm_nds_ima, // ADPCM interleaved
	type_kraw,  // kRAW (PCM)
	type_afc,   // AFC
	type_astafc, // AFC in an AST wrapper
	type_vag,   // VAG
	type_ads,   // ASD (VAG)
	type_rsf,   // RSF
	type_npsf,	// NPSF
	type_xa,	// CD-XA
	type_rws,	// RWS
	type_eaxa,	// EA-XA
	type_rxws,	// RXWS
	type_svag,	// SVAG
	type_xbox,	// XBOX
	type_mib,	// MIB
	type_raw,	// RAW Format7
	type_psh,	// PSH
	type_vpk,	// VPK
	type_musc,	// MUSC
	type_xmu,	// XMU
	type_ccc,	// CCC
	type_fag,	// FAG
	type_ps2fsb,// FSB (PS2)
	type_xbfsb,	// FSB (XBOX)
	type_vs,	// VS
	type_vag_2ch,	//VAG Dual Channels
	type_i80,
	type_int,
	type_rstm,
	type_ass,
	type_kecs,
	type_psw,
	type_rsd6,
	type_rkv,
	type_fsb3wii,
	type_rwsd_wii,
	type_rstm_wii,
	type_spmrstm_wii, // Super Paper Mario 44khz->22khz hack
	type_idsp_wii,
	type_gca1,
	type_thp,
	type_zwdsp,
	type_knon_dsp,
	type_knon_pcm,
	type_i100,
	type_strm_nds_swav,
	type_ima_fsb,
	type_caf,
	type_gsp_gsb,
	type_musx,
	type_mih,
	type_riff_ima,
	type_ydsp,
	type_gms,
	type_dxh,
	type_i400,
	type_iSWS,
	type_aus,
	type_fil,
	type_svag_kce,
	type_ster,
	type_leg,
	type_ild,
	type_vas,
} filetype;

// structure for a single channel
typedef struct {
	HANDLE infile; // processing on a single channel needs this,also this allows for seperate L/R files to be played at once
	
	// header data
	u32 num_samples;
	u32 num_adpcm_nibbles;
	u32 sample_rate;
	u16 loop_flag;
	u16 format;
	u32 sa,ea,ca;
	s16 coef[16];
	u16 gain; // never used anyway
	u16 ps,yn1,yn2;
	u16 lps,lyn1,lyn2;

	short chanbuf[BUFFER_SIZE/8*14];
	int readloc,writeloc; // offsets into the chanbuf
	filetype type;
	short bps; // bits per "size", 4 if offsets specified in nibbles, 8 if bytes
	u32 chanstart; // offset in file of start of this channel
	u32 offs; // current location
	s32 loopoffs;
	union { // sample history (either long or short, ADP uses long, others use short)
		long lhist1;
		short hist1;
	};
	union {
		long lhist2;
		short hist2;
	};
	long interleave; // _bytes_ of interleave, 0 if none
	
	int bufferOffset;  // Needed in EA-XA Decoder
	int	GetFromHeader; // Needed in EA-XA Decoder
	
	s16 StepSize;	// for XBOX
	s32 Predictor;	// for XBOX
	s16 index;		// for XBOX
	u8  mus;		// for EA/XA . MUS

	// for IMA
	u32 blockSize;
	u32 lastBlockSize;
	int IMAIndex;
	int loopadpcm_nibbles;
	int loop_nibbles_into_block;
	int loop_hit;
	int IMASample;
	
	int IMASampleLoop;
	int IMAIndexLoop;

	u32	IMABlockCount;
	u32	IMABlockCountSave;
	u32 IMABlockLength;
	
	// for EAXA
	int EAXASampleCompression;
	int EAXAPlatform;

	// for ADX
	double adxcoef[2];

} CUBESTREAM;

// structure represents a DSP file
typedef struct {
	CUBESTREAM ch[2];
	int NCH;
	int ADXCH; // number of channels in an ADX (may be different from number being rendered)
	unsigned long nrsamples;
	u32 file_length;
	u32 head_amount;	// Amount of Headers(streams)
	u32 head_current;	// Current Header(stream)
	u32 head_next;		// Location of next Header(stream)
	u32 nexthalp; // next HALPST header
	long halpsize;
	long samplesdone,loopsamplesdone,loopnexthalp,loophalpsize;
	int lastchunk;
	long startinterleave;

	int uncompressed;

	// for XA
	int	XABits;

	// for EA-XA
	int EAXACompression;
	int EAXASplit;
	int	EAXACompleted;
	int EAXASplitCompression;
	int	EAXA_NCH;

	// for THP
	u32	NextFrameSize;

	// for MUSX & others ...
	u32	loop_start_offset;
	u32	loop_end_offset;

} CUBEFILE;

int InitDSPFILE(char * infile, CUBEFILE * dsp);
int InitADXFILE(char * infile, CUBEFILE * adx);
int InitADPFILE(char * infile, CUBEFILE * adp);
int InitPCMFILE(char * infile, CUBEFILE * pcm);
int InitAFCFILE(char * infile, CUBEFILE * afc);
int InitVAGFILE(char * infile, CUBEFILE * vag);
int InitRSFFILE(char * infile, CUBEFILE * rsf);
int InitXAFile(char * infile, CUBEFILE * xa);
int InitEAXA(char * infile, CUBEFILE * eaxa);
int InitXBOX(char * infile, CUBEFILE * xbox);
int InitRAW(char * infile, CUBEFILE * raw);
int InitTHPFILE(char * infile, CUBEFILE * thp);

int InitCUBEFILE(char * fn, CUBEFILE * cf);
void CloseCUBEFILE(CUBEFILE * dsp);

int CheckSampleRate(int sr);

void DSPdecodebuffer
(
    u8			*input, // location of encoded source samples
    s16         *out,   // location of destination buffer (16 bits / sample)
    short		coef[16],   // location of decode coefficients
	short * histp,
	short * hist2p
);


void AFCdecodebuffer
(
    u8			*input, // location of encoded source samples
    s16         *out,   // location of destination buffer (16 bits / sample)
    short * histp,
	short * hist2p
);

int ADXdecodebuffer
(
    u8			*input, // location of encoded source samples
    s16         *out,   // location of destination buffer (16 bits / sample)
	short * histp,
	short * hist2p,
	double * coef
);

int ADPdecodebuffer(
	unsigned char *input,
	short *outl,
	short *outr,
	long *histl1,
	long *histl2,
	long *histr1,
	long *histr2
);

int VAGdecodebuffer(
	unsigned char * input,
	short * out,
	short * hist1p,
	short * hist2p
);

void RSFdecodebuffer(
	unsigned char in,
	short *out,
	long *hist1p,
	long *hist2p
);

void fillbuffers(CUBEFILE * dsp);

void fillbufferDSP(CUBESTREAM * stream);
void fillbufferDSPinterleave(CUBEFILE * stream);
void fillbufferHALP(CUBEFILE * stream);
void fillbufferDSPfsb3(CUBEFILE * stream);
void fillbufferADX(CUBEFILE * adx);
void fillbufferADP(CUBEFILE * adp);
void fillbufferPCM(CUBEFILE * pcm);
void fillbufferPCM_LE_noint(CUBESTREAM * stream);
void fillbufferPCM_LE_noint8bits(CUBESTREAM * pcm);
void fillbufferPCM_noint(CUBESTREAM * stream);
void fillbufferAFC(CUBEFILE * afc);
void fillbufferASTAFC(CUBEFILE * pcm);
void fillbufferASTPCM(CUBEFILE * pcm);
void fillbufferPCMinterleave(CUBEFILE * pcm);
void fillbufferVAG(CUBEFILE * vag);
void fillbufferVAGinterleave(CUBEFILE * vag);
void fillbufferRSF(CUBESTREAM * stream);
void fillbufferXA(CUBEFILE *xa);
void fillBufferEAXA(CUBEFILE *eaxa);
void fillBufferXBOX(CUBEFILE *xbox);
void fillBufferRAW(CUBEFILE *raw);
void fillbufferVS(CUBEFILE * vag);
void fillBufferRAWInterleave(CUBEFILE * raw);
void fillbufferTHP(CUBEFILE * thp); 
void fillbufferIMA(CUBEFILE *imapcm);
void fillbufferIMASWAV(CUBEFILE *imapcm);
void fillbufferCAF(CUBEFILE * caf);
void fillbufferGSP(CUBEFILE * gsp);
void fillBufferMUSX(CUBEFILE * musx);
void fillBufferRIFF_IMA(CUBEFILE *riff);

// configurable ADX parameters
extern int adx_cutoff;
extern int adxonechan;

// configurable RSF parameters
extern short RSFCOEF1;
extern short RSFCOEF2;

#endif
