#include <windows.h>
#include "wamain.h"
#include "cube.h"

void fillBufferRAW(CUBEFILE * raw) 
{
	short ADPCMbuf[BUFFER_SIZE/8*14];
	unsigned int i,l;

	SetFilePointer(raw->ch[0].infile,raw->ch[0].offs,0,FILE_BEGIN);
	ReadFile(raw->ch[0].infile, ADPCMbuf, (BUFFER_SIZE/8*14)*sizeof(short), &l, NULL);
	raw->ch[0].offs+=l;
	
	i=0;

	do
	{
		raw->ch[0].chanbuf[raw->ch[0].writeloc++]=ADPCMbuf[i++];
		if (raw->ch[0].writeloc>=BUFFER_SIZE/8*14) 
			raw->ch[0].writeloc=0;
		raw->ch[1].chanbuf[raw->ch[1].writeloc++]=ADPCMbuf[i++];
		if (raw->ch[1].writeloc>=BUFFER_SIZE/8*14) 
			raw->ch[1].writeloc=0;

		raw->samplesdone++;

		if((raw->samplesdone>=raw->ch[0].ea) && (raw->ch[0].loop_flag)) {
			raw->ch[0].offs=(raw->ch[0].sa*2*raw->NCH)+raw->ch[0].chanstart;
			raw->samplesdone=raw->ch[0].sa;
			break;
		}

	} while (i<l/sizeof(short));
}

void fillBufferRAWInterleave(CUBEFILE * raw) 
{
	short ADPCMbuf[0x200];
	unsigned int i,l;

	ReadFile(raw->ch[0].infile, ADPCMbuf, raw->ch[0].interleave, &l, NULL);
	
	i=0;
	do
	{
		raw->ch[0].chanbuf[raw->ch[0].writeloc++]=ADPCMbuf[i++];
		if (raw->ch[0].writeloc>=BUFFER_SIZE/8*14) 
			raw->ch[0].writeloc=0;
	} while (i<l/sizeof(short));

	ReadFile(raw->ch[0].infile, ADPCMbuf, raw->ch[0].interleave, &l, NULL);
	
	i=0;
	do
	{
		raw->ch[1].chanbuf[raw->ch[1].writeloc++]=ADPCMbuf[i++];
		if (raw->ch[1].writeloc>=BUFFER_SIZE/8*14) 
			raw->ch[1].writeloc=0;
	} while (i<l/sizeof(short));
}

int InitRAW(char * inputfile, CUBEFILE * raw)
{
	int l;
	char buffer[0x80];

	if (inputfile) 
	{
		raw->ch[0].infile=raw->ch[1].infile=INVALID_HANDLE_VALUE;
		raw->ch[0].ea=raw->ch[1].sa=0;
		raw->ch[0].loop_flag=raw->ch[1].loop_flag=0;
		raw->ch[0].bps=8;

		if (!strcmpi(inputfile+strlen(inputfile)-4,".raw") && 
			!strcmpi(inputfile+strlen(inputfile)-4,".RAW")) 
		{
			raw->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
				OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

			if (raw->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
				return 1;
			
			raw->ch[0].type=type_raw;
			raw->file_length=GetFileSize(raw->ch[0].infile,NULL);
			raw->NCH=2;
			raw->ch[0].interleave=0;
			raw->ch[0].sample_rate=44100;
			raw->nrsamples=(raw->file_length)/4;
			raw->ch[0].writeloc=raw->ch[0].readloc=0;
			raw->ch[1].writeloc=raw->ch[1].readloc=0;
			raw->ch[0].offs=0;
		} else if (!strcmpi(inputfile+strlen(inputfile)-4,".pcm") && 
			!strcmpi(inputfile+strlen(inputfile)-4,".PCM")) 
		{
			raw->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
				OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

			if (raw->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
				return 1;
			
			ReadFile(raw->ch[0].infile,buffer,0x80,&l,NULL);

			raw->ch[0].type=type_raw;
			raw->file_length=GetFileSize(raw->ch[0].infile,NULL)-0x800;
			raw->NCH=2;
			raw->ch[0].interleave=0;
			raw->ch[0].sample_rate=24000;
			raw->nrsamples=(raw->file_length)/4;
			raw->ch[0].writeloc=raw->ch[0].readloc=0;
			raw->ch[1].writeloc=raw->ch[1].readloc=0;
			raw->ch[0].sa=get32bitL(buffer+0x08);
			raw->ch[0].ea=get32bitL(buffer+0x0c);
			raw->ch[0].loop_flag=(raw->ch[0].sa!=0);
			raw->ch[0].offs=raw->ch[0].chanstart=0x800;
		}
		else if (!strcmpi(inputfile+strlen(inputfile)-4,".int") && 
			!strcmpi(inputfile+strlen(inputfile)-4,".INT")) 
		{
			raw->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
				OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

			if (raw->ch[0].infile == INVALID_HANDLE_VALUE) // error opening file
				return 1;
			
			raw->ch[0].type=type_int;
			raw->file_length=GetFileSize(raw->ch[0].infile,NULL);
			raw->NCH=2;
			raw->ch[0].interleave=0;
			raw->ch[0].sample_rate=48000;
			raw->nrsamples=(raw->file_length)/4;
			raw->ch[0].writeloc=raw->ch[0].readloc=0;
			raw->ch[1].writeloc=raw->ch[1].readloc=0;
			raw->ch[0].offs=0;
			raw->ch[0].interleave=raw->ch[1].interleave=0x200;
		}

		else 
		{
			raw->ch[0].infile = CreateFile(inputfile,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
				OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);

			ReadFile(raw->ch[0].infile,buffer,0x80,&l,NULL);
			if (!memcmp(buffer,"RAWX",4))
			{
				raw->ch[0].type=type_raw;
				raw->file_length=GetFileSize(raw->ch[0].infile,NULL);
				raw->NCH=2;
				raw->ch[0].interleave=0;
				raw->ch[0].sample_rate=get32bitL(buffer+0x08);
				raw->nrsamples=(raw->file_length)/4;
				raw->ch[0].writeloc=raw->ch[0].readloc=0;
				raw->ch[1].writeloc=raw->ch[1].readloc=0;
				raw->ch[0].offs=0;
				raw->ch[0].ea=raw->ch[0].sa=raw->ch[0].loop_flag=0;
			}
			else {
				CloseCUBEFILE(raw);
				return 1;
			}
		}
	}
	
	if (raw->ch[0].loop_flag) 
		raw->nrsamples=(raw->ch[0].sa+looptimes*(raw->ch[0].ea-raw->ch[0].sa))+(fadelength+fadedelay)*raw->ch[0].sample_rate;

	return 0;
}