//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_CONFIG                      101
#define IDD_INFO                        102
#define IDD_ABOUT                       103
#define IDI_INFO_ICON                   108
#define IDC_FILE_LOCATION               1001
#define IDC_PLUGIN_VERSION              1002
#define IDC_ID3_ARTIST                  1011
#define IDC_ID3_TITLE                   1012
#define IDC_ID3_ALBUM                   1013
#define IDC_ID3_YEAR                    1014
#define IDC_ID3_GENRE                   1015
#define IDC_ID3_TRACK                   1016
#define IDC_ID3_COMMENT                 1017
#define IDC_TTA_LEVEL                   1028
#define IDC_TTA_CHANNELS                1029
#define IDC_TTA_FILESIZE                1030
#define IDC_TTA_SAMPLERATE              1031
#define IDC_TTA_BPS                     1032
#define IDC_TTA_COMPRESSION             1033
#define IDC_ID3_DELETE                  1055
#define IDC_ID3_SWITCH                  1056
#define IDC_ID3_EDITOR                  1057

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
