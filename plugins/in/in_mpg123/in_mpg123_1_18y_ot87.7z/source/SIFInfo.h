// SIFInfo.h: CSIFInfo �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIFINFO_H__CFD24BDC_5EE2_4E95_82E4_999F9F20735E__INCLUDED_)
#define AFX_SIFINFO_H__CFD24BDC_5EE2_4E95_82E4_999F9F20735E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "mmsystem.h"

typedef struct mmioParam {
    HMMIO           hmmio;
	MMCKINFO*       mmckinfoParent;
	MMCKINFO*       mmckinfoSubchunk;
	MMCKINFO*       mmckinfoSubSubchunk;
	WAVEFORMATEX	*pFormat;
} mmioParam;

class CSIFInfo : public CObject
{
public:
	CSIFInfo();
	virtual ~CSIFInfo();

	void Init();
	int GetSIFInfo(char *fn);
	bool GetTitleFromSIF(Tag::TagInfo* Info);

	CString m_file;
	CString m_title;
	CString m_artist;
	CString m_album;
	CString m_track;
	CString m_year;
	CString m_comment;
	CString m_genre;
	CString m_engineer;
	CString m_copyright;
	CString m_source;
	CString m_software;
	UINT m_datasize;
	UINT m_filesize;
	bool m_enable;

private:
	void GetSIFInfoString(mmioParam* mmio, CString* str);
	void GetSIFInfoDelete(mmioParam* mmio);
	void GetSIFInfoNew(mmioParam* mmio);

};

#endif // !defined(AFX_SIFINFO_H__CFD24BDC_5EE2_4E95_82E4_999F9F20735E__INCLUDED_)
