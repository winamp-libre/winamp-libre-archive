#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// ReplaygainDialog �_�C�A���O

class CReplayGainDialog : public CPropertyPage
{
	DECLARE_DYNAMIC(CReplayGainDialog)

public:
	CReplayGainDialog();
	virtual ~CReplayGainDialog();

	void SetParam();
	CIn_mpg123dParam* pr;

// �_�C�A���O �f�[�^
	enum { IDD = IDD_REPLAYGAIN_DIALOG };
	BOOL m_bReplayGainEnable;
	CComboBox m_comboReplayGainMode;
	BOOL m_bReplayGainHardLimit;
	CSliderCtrl m_trackReplayGainPreAmpWithRG;
	CStatic m_ReplayGainPreAmpWithRG_DB;
	CSliderCtrl m_trackReplayGainPreAmpWithoutRG;
	CStatic m_ReplayGainPreAmpWithoutRG_DB;

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

private:
	void ShowDB(int Pos, CStatic* DB);

protected:
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnBnClickedChReplayGainEnable();
	afx_msg void OnBnClickedChReplayGainHardlimit();
	afx_msg void OnCbnSelchangeComboReplayGainMode();
	afx_msg void OnHScroll(UINT, UINT, CScrollBar* pScrollBar);
	DECLARE_MESSAGE_MAP()
};

