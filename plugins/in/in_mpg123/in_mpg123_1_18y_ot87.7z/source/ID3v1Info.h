
//
//  ID3v1�^�O���擾����(�w�b�_)
//
//  Written by Otachan
//  http://www3.cypress.ne.jp/otachan/
//

struct
id3tag
{
	char	tag[3];
	char	title[30];
	char	artist[30];
	char	album[30];
	char	year[4];
	char	comment[30];
	unsigned char	genre;
};

bool	GetTitleFromID3v1(Tag::TagInfo* Info);

