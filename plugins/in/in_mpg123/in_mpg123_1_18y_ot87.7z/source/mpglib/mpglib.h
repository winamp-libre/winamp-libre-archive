
#if ( defined(_MSC_VER) || defined(__BORLANDC__) )
	typedef int BOOL; /* windef.h contains the same definition */
#else
	#define BOOL int
#endif

#define	MPG123_USE_GAIN

#define	MP3_OK			0
#define	MP3_ERR			-1
#define	MP3_WAR			-2
#define	MP3_NEED_MORE	1

struct
framebuf
{
	unsigned char*	pnt;
	long	size;
	long	pos;
	framebuf*	next;
	framebuf*	prev;
};

class
mpg123
{
public:
	enum
	{
		DATA_FORMAT_LINEAR_PCM,
		DATA_FORMAT_IEEE_FLOAT,
	};
	int		totalFramesize;
	int		nframe;
	int		currentBitrate;

	mpg123(
		int _Format = DATA_FORMAT_LINEAR_PCM,
		int _OutputBps = 16,
		real _Gain = 0.,
		bool _HardLimit = false,
		real _Peak = 0.);
	~mpg123(void);

	int		get_frequency(void);
	int		get_channel(void);
	void	flush(void);
	int		decode(char* inmemory, int inmemsize, char* outmemory, int outmemsize, int* done);

private:
	int		Format;
	int		OutputBps;
	real	Gain;
	bool	HardLimit;
	real	Peak;

	bool	First;
	int		Max_osize;

#ifdef MPG123_USE_GAIN

	real	Scale;
	bool	Compress;

#endif

	int		bitindex;
	unsigned char*	wordpointer;
	framebuf*	head;
	framebuf*	tail;
	int		bsize;
	int		framesize;
	int		fsizeold;
	frame	First_fr;
	frame	fr;
	int		bsnum;
	unsigned char	bsspace[2][MAXFRAMESIZE + 512]; /* MAXFRAMESIZE */
	int		hybrid_blc[2];
	real	hybrid_block[2][2][SBLIMIT * SSLIMIT];
	int		synth_bo;
	real	synth_buffs[2][2][0x110];

	DO_LAYER123_FUNC	do_layer123_func;
	SYNTH_1TO1_MONO_FUNC	synth_1to1_mono_func;
	SYNTH_1TO1_FUNC	synth_1to1_func;

	void	init(
				int _Format,
				int _OutputBps,
				real _Gain,
				bool _HardLimit,
				real _Peak,
				int _totalFramesize,
				int _nframe,
				int _currentBitrate);
	void	release(void);
	framebuf*	addbuf(char* buf, int size);
	void	remove_buf(void);

	unsigned long	read_head(void);
	int		read_buf_byte(void);
	int		set_pointer(/*int ssize,*/long backstep);

	unsigned int	getbits(int number_of_bits);
	unsigned int	getbits_fast(int number_of_bits);
	unsigned int	get1bit(void);

	void	I_step_one(unsigned int balloc[], unsigned int scale_index[2][SBLIMIT]);
	void	I_step_two(
					real fraction[2][SBLIMIT],
					unsigned int balloc[2 * SBLIMIT],
					unsigned int scale_index[2][SBLIMIT]);
	int		do_layer1(unsigned char* pcm_sample, int* pcm_point);

	void	II_step_one(unsigned int* bit_alloc, int* scale);
	void	II_step_two(unsigned int* bit_alloc, real fraction[2][4][SBLIMIT], int* scale, int x1);
	void	II_select_table(void);
	int		do_layer2(unsigned char* pcm_sample, int* pcm_point);

	int		III_get_side_info(III_sideinfo* si, int ms_stereo, int single);
	int		III_get_scale_factors_1(int* scf, gr_info_s* gr_info);
	int		III_get_scale_factors_2(int* scf, gr_info_s* gr_info, int i_stereo);
	int		III_dequantize_sample(
								real xr[SBLIMIT][SSLIMIT],
								int* scf,
								gr_info_s* gr_info,
								int part2bits);
	void	III_i_stereo(
					real xr_buf[2][SBLIMIT][SSLIMIT],
					int* scalefac,
					gr_info_s* gr_info,
					int ms_stereo);
	void	III_antialias(real xr[SBLIMIT][SSLIMIT], gr_info_s* gr_info);
	void	III_hybrid(
					real fsIn[SBLIMIT][SSLIMIT],
					real tsOut[SSLIMIT][SBLIMIT],
					int ch,
					gr_info_s* gr_info);
	int		do_layer3(unsigned char* pcm_sample, int* pcm_point);

	void	synth_1to1_int16(real*, int, unsigned char*, int*);
	void	synth_1to1_int24(real*, int, unsigned char*, int*);
	void	synth_1to1_int32(real*, int, unsigned char*, int*);
	void	synth_1to1_float32(real*, int, unsigned char*, int*);
	void	synth_1to1_float64(real*, int, unsigned char*, int*);

	void	synth_1to1_mono_int16(real*, unsigned char*, int*);
	void	synth_1to1_mono_int24(real*, unsigned char*, int*);
	void	synth_1to1_mono_int32(real*, unsigned char*, int*);
	void	synth_1to1_mono_float32(real*, unsigned char*, int*);
	void	synth_1to1_mono_float64(real*, unsigned char*, int*);
};

