
#include <windows.h>
#include <float.h>

#include "mpg123.h"
#include "mpglib.h"

//char*	errorstring = "no error";

mpg123::mpg123(int _Format, int _OutputBps, real _Gain, bool _HardLimit, real _Peak)
{
	static bool	InitTable = false;

	if(InitTable == false) {
		make_decode_tables(1);
		init_layer2();
		init_layer3(SBLIMIT);
		InitTable = true;
	}

	init(_Format, _OutputBps, _Gain, _HardLimit, _Peak, 0, 0, 0);
}

mpg123::~mpg123(void)
{
	release();
}

void
mpg123::init(
		int _Format,
		int _OutputBps,
		real _Gain,
		bool _HardLimit,
		real _Peak,
		int _totalFramesize,
		int _nframe,
		int _currentBitrate)
{
	memset(this, 0, sizeof *this);

	Format = _Format;
	OutputBps = _OutputBps;
	Gain = _Gain;
	HardLimit = _HardLimit;
	Peak = _Peak;

	totalFramesize = _totalFramesize;
	nframe = _nframe;
	currentBitrate = _currentBitrate;

	First = true;

	head = NULL;
	tail = NULL;
	bsize = 0;
	framesize = 0;
	fsizeold = -1;
	fr.single = -1;
	bsnum = 0;
	synth_bo = 1;

	Max_osize = 1152 * (_OutputBps >> 3) * 2;

#ifdef MPG123_USE_GAIN

	Scale = pow(10., _Gain / 20.);
	Compress = _HardLimit && ((_Peak * Scale) > 1.);

#endif

	switch(_Format) {
	case DATA_FORMAT_LINEAR_PCM:
		switch(_OutputBps) {
		case 16:
			synth_1to1_mono_func = &mpg123::synth_1to1_mono_int16;
			synth_1to1_func = &mpg123::synth_1to1_int16;
			break;
		case 24:
			synth_1to1_mono_func = &mpg123::synth_1to1_mono_int24;
			synth_1to1_func = &mpg123::synth_1to1_int24;
			break;
		case 32:
			synth_1to1_mono_func = &mpg123::synth_1to1_mono_int32;
			synth_1to1_func = &mpg123::synth_1to1_int32;
			break;
		}
		break;
	case DATA_FORMAT_IEEE_FLOAT:
		switch(_OutputBps) {
		case 32:
			synth_1to1_mono_func = &mpg123::synth_1to1_mono_float32;
			synth_1to1_func = &mpg123::synth_1to1_float32;
			break;
		case 64:
			synth_1to1_mono_func = &mpg123::synth_1to1_mono_float64;
			synth_1to1_func = &mpg123::synth_1to1_float64;
			break;
		}
		break;
	}
}

void
mpg123::release(void)
{
	framebuf*	b = tail;
	framebuf*	bn;

	while(b) {
		delete[] b->pnt;
		bn = b->next;
		delete b;
		b = bn;
	}
}

int
mpg123::get_frequency(void)
{
	return freqs[fr.frequency];
}

int
mpg123::get_channel(void)
{
	return fr.stereo;
}

void
mpg123::flush(void)
{
	release();
	init(Format, OutputBps, Gain, HardLimit, Peak, totalFramesize, nframe, currentBitrate);
}

int
mpg123::decode(char* in, int isize, char* out, int osize, int* done)
{
//	errorstring = "no error or unknown error";

	if(osize < Max_osize) {
//		errorstring = "output buffer is too small";
		return MP3_ERR;
	}

	if(in && (addbuf(in, isize) == NULL)) return MP3_ERR;

	/* First decode header */
	if(framesize == 0) {
		if(bsize < 4) return MP3_NEED_MORE;

		unsigned long	header = read_head();

		if(decode_header(&fr, header) == false) return MP3_ERR;

		if(First) {
			switch(fr.lay) {
			case 3:
				do_layer123_func = &mpg123::do_layer3;
				break;
			case 2:
				do_layer123_func = &mpg123::do_layer2;
				break;
			case 1:
				do_layer123_func = &mpg123::do_layer1;
				break;
			}

			First_fr = fr;
			First = false;
		} else {
			if(		(fr.mpeg25 != First_fr.mpeg25) ||
					(fr.lsf != First_fr.lsf) ||
					(fr.lay != First_fr.lay) ||
					(fr.frequency != First_fr.frequency) ||
					(fr.stereo != First_fr.stereo)) {
				return MP3_ERR;
			}
		}

		framesize = fr.framesize;
		totalFramesize += framesize + 4;
		currentBitrate = tabsel_123[fr.lsf][fr.lay - 1][fr.bitrate];
		nframe++;
	}

//	  printf(" fr.framesize = %i \n",mp->fr.framesize);
//	  printf(" bsize        = %i \n",mp->bsize);

	if(bsize < fr.framesize) return MP3_NEED_MORE;

	wordpointer = bsspace[bsnum] + 512;
	bsnum = (bsnum + 1) & 0x1;
	bitindex = 0;

	int		len = 0;

	while(len < framesize) {
		int		nlen;
		int		blen = tail->size - tail->pos;

		if((framesize - len) <= blen) {
			nlen = framesize - len;
		} else {
			nlen = blen;
		}

		memcpy(wordpointer + len, tail->pnt + tail->pos, nlen);
		len += nlen;
		tail->pos += nlen;
		bsize -= nlen;

		if(tail->pos == tail->size) remove_buf();
	}

	if(fr.error_protection) {
		/* skip crc, we are byte aligned here */
		getbits(16);
	}

	*done = 0;

	const int	ret_code = (this->*do_layer123_func)(reinterpret_cast<unsigned char*>(out), done);

	fsizeold = framesize;
	framesize = 0;

	return (ret_code >= 0) ? MP3_OK : ret_code;
}

framebuf*
mpg123::addbuf(char* buf, int size)
{
	framebuf*	nbuf = new framebuf;

	if(nbuf == NULL) {
//		errorstring = "Out of memory";
//		fprintf(stderr,"Out of memory!\n");
		return NULL;
	}

	nbuf->pnt = new unsigned char[size];

	if(nbuf->pnt == NULL) {
		delete nbuf;
		return NULL;
	}

	nbuf->size = size;
	memcpy(nbuf->pnt, buf, size);
	nbuf->next = NULL;
	nbuf->prev = head;
	nbuf->pos = 0;

	if(tail) {
		head->next = nbuf;
	} else {
		tail = nbuf;
	}

	head = nbuf;
	bsize += size;

	return nbuf;
}

void
mpg123::remove_buf(void)
{
	framebuf*	buf = tail;

	tail = buf->next;

	if(tail) {
		tail->prev = NULL;
	} else {
		head = NULL;
		tail = NULL;
	}

	delete[] buf->pnt;
	delete buf;
}

unsigned long
mpg123::read_head(void)
{
	unsigned long	header;

	header = read_buf_byte();
	header <<= 8;
	header |= read_buf_byte();
	header <<= 8;
	header |= read_buf_byte();
	header <<= 8;
	header |= read_buf_byte();

	return header;
}

int
mpg123::read_buf_byte(void)
{
	int		pos = tail->pos;

	while(pos >= tail->size) {
		remove_buf();
		if(tail == NULL) {
//			errorstring = "read_buf_byte error";
//			fprintf(stderr,"Fatal error!\n");
			return 0;
		}
		pos = tail->pos;
	}

	bsize--;
	tail->pos++;

	return tail->pnt[pos];
}

int
mpg123::set_pointer(/*int ssize,*/long backstep)
{
	if((fsizeold < 0) && (backstep > 0)) {
//		fprintf(stderr,"Can't step back %ld!\n",backstep);
		return MP3_ERR; 
	}

	wordpointer -= backstep;
	if(backstep) memcpy(wordpointer, bsspace[bsnum] + 512 + fsizeold - backstep, backstep);
	bitindex = 0;

	return MP3_OK;
}

