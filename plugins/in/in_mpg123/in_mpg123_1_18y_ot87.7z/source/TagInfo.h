
#define	MAX_MUSICTEXT	512

#define	MAX_GENRE		148

class	CSIFInfo;

class
Tag
{
public:
	struct
	TagInfo
	{
		int		Length;
		char	FileName[MAX_PATHLEN];
		char	Title[MAX_MUSICTEXT];
		char	Artist[MAX_MUSICTEXT];
		char	Comment[MAX_MUSICTEXT];
		char	Album[MAX_MUSICTEXT];
		char	Year[MAX_MUSICTEXT];
		char	Genre[MAX_MUSICTEXT];
		char	Track[MAX_MUSICTEXT];
		char	Composer[MAX_MUSICTEXT];
		char	OrgArtist[MAX_MUSICTEXT];
		char	Copyright[MAX_MUSICTEXT];
		char	Encoder[MAX_MUSICTEXT];
	};
	struct
	ReplayGainInfo
	{
		bool	ValidTrackGain;
		bool	ValidTrackPeak;
		bool	ValidAlbumGain;
		bool	ValidAlbumPeak;
		double	TrackGain;
		double	TrackPeak;
		double	AlbumGain;
		double	AlbumPeak;
	};
	enum
	{
		REPLAYGAIN_NONE,
		REPLAYGAIN_TRACK_GAIN,
		REPLAYGAIN_TRACK_PEAK,
		REPLAYGAIN_ALBUM_GAIN,
		REPLAYGAIN_ALBUM_PEAK,
	};

	Tag(void);
	~Tag(void);

	void	FlushCache(void);
	bool	Get(const char* FileName, CSIFInfo* sif, const char* Format, char* Title);
	bool	GetReplayGainInfo(const char* FileName, ReplayGainInfo* Info);
	int		GetExtendedFileInfo(extendedFileInfoStruct* ExtendedFileInfo);

private:
	CRITICAL_SECTION	CriticalSection;
	TagInfo	Cache;
	DWORD	GetTagTime;

	bool	GetTitleFromID3v2(
							TagInfo* Info,
							ReplayGainInfo* GainInfo = NULL,
							const char* FileName = NULL);
	bool	GetTitleFromAPE(
						TagInfo* Info,
						ReplayGainInfo* GainInfo = NULL,
						const char* FileName = NULL);
	void	StoreReplayGainInfo(const int ReplayGainFieldName, char* Buff, ReplayGainInfo* Info);
	void	DoFormat(const TagInfo* Info, const char* Format, char* Title);
};

#include "APEInfo.h"
#include "SIFInfo.h"
#include "ID3v1Info.h"

