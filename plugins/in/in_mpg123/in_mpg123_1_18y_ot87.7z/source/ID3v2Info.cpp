
//
//  ID3v2�^�O���擾����
//
//  Written by Otachan
//  http://www3.cypress.ne.jp/otachan/
//

#include "stdafx.h"

#include "wa_ipc.h"

#include "CommonFunc.h"

#include "in_mpg123.h"

#include "TagInfo.h"
#include "ID3v2Info.h"

extern const char*	GenreList[];

bool
Tag::GetTitleFromID3v2(TagInfo* Info, ReplayGainInfo* GainInfo, const char* FileName)
{
	::SetLastError(NO_ERROR);

	HANDLE	hF = ::CreateFile(
							Info ? Info->FileName : FileName,
							GENERIC_READ,
							FILE_SHARE_READ,
							NULL,
							OPEN_EXISTING,
							FILE_FLAG_RANDOM_ACCESS,
							NULL);

	if(::GetLastError() != NO_ERROR) return false;

	bool	RetCode;
	bool	FindGainInfo;
	DWORD	FileSize = ::GetFileSize(hF, NULL);

	if(FileSize >= 10) {
		unsigned char	Tag[10];
		DWORD	ReadByte;

		memset(Tag, '\0', 3);
		::ReadFile(hF, Tag, 10, &ReadByte, NULL);

		bool	FindTag;
		bool	FindTagFooter;
		unsigned char	TagVersion;

		if((*Tag == 'I') && (*(Tag + 1) == 'D') && (*(Tag + 2) == '3') &&
										 ((TagVersion = *(Tag + 3)) >= 3)) {
			FindTag = true;
			FindTagFooter = false;
		} else {
			memset(Tag, '\0', 3);
			::SetFilePointer(hF, FileSize - 10, NULL, FILE_BEGIN);
			::ReadFile(hF, Tag, 10, &ReadByte, NULL);

			if((*Tag == '3') && (*(Tag + 1) == 'D') && (*(Tag + 2) == 'I') &&
											 ((TagVersion = *(Tag + 3)) >= 4)) {
				FindTag = true;
				FindTagFooter = true;
			} else {
				FindTag = false;
			}
		}

		if(FindTag) {
			UINT	TagSize =	(*(Tag + 6) << 21) +
								(*(Tag + 7) << 14) +
								(*(Tag + 8) << 7) +
								*(Tag + 9);

			if(FileSize >= (10 + TagSize)) {
				const unsigned char	TagFlag = *(Tag + 5);
				const bool	TagUnsynchronization = (TagFlag & 0x80) != 0;
				const bool	TagExtendedHeader = (TagFlag & 0x40) != 0;
				unsigned char*	TagData = new unsigned char[TagSize];

				if(FindTagFooter) ::SetFilePointer(hF, FileSize - 10 - TagSize, NULL, FILE_BEGIN);
				::ReadFile(hF, TagData, TagSize, &ReadByte, NULL);

				::CloseHandle(hF);

				if(TagUnsynchronization) {
					TagSize = ID3v2DecodeUnsynchronization(TagData, TagSize, true);
				}

				unsigned char*	TagDataPnt = TagData;
				unsigned char*	MaxTagDataPnt = TagDataPnt + TagSize;

				if(TagExtendedHeader) {
					if(TagVersion >= 4) {	// Ver. 2.4
						TagDataPnt +=	(*(TagDataPnt + 0) << 21) +
										(*(TagDataPnt + 1) << 14) +
										(*(TagDataPnt + 2) << 7) +
										*(TagDataPnt + 3);
					} else {				// Ver. 2.3
						TagDataPnt +=	4 +
										(*(TagDataPnt + 0) << 24) +
										(*(TagDataPnt + 1) << 16) +
										(*(TagDataPnt + 2) << 8) +
										*(TagDataPnt + 3);
						MaxTagDataPnt -=	(*(TagDataPnt + 6) << 24) +
											(*(TagDataPnt + 7) << 16) +
											(*(TagDataPnt + 8) << 8) +
											*(TagDataPnt + 9);
					}
				}

				bool	TitleSc = false;
				bool	ArtistSc = false;
				bool	CommentSc = false;
				bool	AlbumSc = false;
				bool	YearSc = false;
				bool	GenreSc = false;
				bool	TrackSc = false;
				bool	ComposerSc = false;
				bool	OrgArtistSc = false;
				bool	CopyrightSc = false;
				bool	EncoderSc = false;
				bool	ReplayGainTrackGainSc = false;
				bool	ReplayGainTrackPeakSc = false;
				bool	ReplayGainAlbumGainSc = false;
				bool	ReplayGainAlbumPeakSc = false;

				while(TagDataPnt < MaxTagDataPnt) {
					const unsigned char FrameID0 = *TagDataPnt++;

					if(FrameID0 == '\0') break;

					const unsigned char FrameID1 = *TagDataPnt++;
					const unsigned char FrameID2 = *TagDataPnt++;
					const unsigned char FrameID3 = *TagDataPnt++;

					const unsigned char	FrameFlag2 = *(TagDataPnt + 5);
					UINT	FrameSize;
					bool	FrameCompression;
					bool	FrameCoded;
					bool	FrameUnsynchronization;

					if(TagVersion >= 4) {	// Ver. 2.4
						FrameSize =	(*(TagDataPnt + 0) << 21) +
									(*(TagDataPnt + 1) << 14) +
									(*(TagDataPnt + 2) << 7) +
									*(TagDataPnt + 3);
						FrameCompression = (FrameFlag2 & 0x08) != 0;
						FrameCoded = (FrameFlag2 & 0x04) != 0;
						FrameUnsynchronization = (FrameFlag2 & 0x02) != 0;
					} else {				// Ver. 2.3
						FrameSize =	(*(TagDataPnt + 0) << 24) +
									(*(TagDataPnt + 1) << 16) +
									(*(TagDataPnt + 2) << 8) +
									*(TagDataPnt + 3);
						FrameCompression = (FrameFlag2 & 0x80) != 0;
						FrameCoded = (FrameFlag2 & 0x40) != 0;
						FrameUnsynchronization = false;
					}

					TagDataPnt += 6;

					if((FrameCompression == false) && (FrameCoded == false)) {
						if(FrameID0 == 'T') {
							if(Info) {
								char*	Buff;
								UINT	BuffSize;

								if((TitleSc == false) &&			(FrameID1 == 'I') &&
																	(FrameID2 == 'T') &&
																	(FrameID3 == '2')) {
									Buff = Info->Title;
									BuffSize = MAX_MUSICTEXT;
									TitleSc = true;
								} else if((ArtistSc == false) &&	(FrameID1 == 'P') &&
																	(FrameID2 == 'E') &&
																	(FrameID3 == '1')) {
									Buff = Info->Artist;
									BuffSize = MAX_MUSICTEXT;
									ArtistSc = true;
								} else if((AlbumSc == false) &&		(FrameID1 == 'A') &&
																	(FrameID2 == 'L') &&
																	(FrameID3 == 'B')) {
									Buff = Info->Album;
									BuffSize = MAX_MUSICTEXT;
									AlbumSc = true;
								} else if((YearSc == false) && (TagVersion >= 4) &&
																	(FrameID1 == 'D') &&
																	(FrameID2 == 'R') &&
																	(FrameID3 == 'C')) {
									Buff = Info->Year;
									BuffSize = MAX_MUSICTEXT;
									YearSc = true;
								} else if((YearSc == false) && (TagVersion == 3) &&
																	(FrameID1 == 'Y') &&
																	(FrameID2 == 'E') &&
																	(FrameID3 == 'R')) {
									Buff = Info->Year;
									BuffSize = MAX_MUSICTEXT;
									YearSc = true;
								} else if((GenreSc == false) &&		(FrameID1 == 'C') &&
																	(FrameID2 == 'O') &&
																	(FrameID3 == 'N')) {
									Buff = Info->Genre;
									BuffSize = MAX_MUSICTEXT;
									GenreSc = true;
								} else if((TrackSc == false) &&		(FrameID1 == 'R') &&
																	(FrameID2 == 'C') &&
																	(FrameID3 == 'K')) {
									Buff = Info->Track;
									BuffSize = MAX_MUSICTEXT;
									TrackSc = true;
								} else if((ComposerSc == false) &&	(FrameID1 == 'C') &&
																	(FrameID2 == 'O') &&
																	(FrameID3 == 'M')) {
									Buff = Info->Composer;
									BuffSize = MAX_MUSICTEXT;
									ComposerSc = true;
								} else if((OrgArtistSc == false) &&	(FrameID1 == 'O') &&
																	(FrameID2 == 'P') &&
																	(FrameID3 == 'E')) {
									Buff = Info->OrgArtist;
									BuffSize = MAX_MUSICTEXT;
									OrgArtistSc = true;
								} else if((CopyrightSc == false) &&	(FrameID1 == 'C') &&
																	(FrameID2 == 'O') &&
																	(FrameID3 == 'P')) {
									Buff = Info->Copyright;
									BuffSize = MAX_MUSICTEXT;
									CopyrightSc = true;
								} else if((EncoderSc == false) &&	(FrameID1 == 'E') &&
																	(FrameID2 == 'N') &&
																	(FrameID3 == 'C')) {
									Buff = Info->Encoder;
									BuffSize = MAX_MUSICTEXT;
									EncoderSc = true;
								} else {
									BuffSize = 0;
								}

								if(BuffSize) {
									ID3v2FrameTEXT(
												TagDataPnt,
												FrameSize,
												Buff,
												BuffSize,
												FrameUnsynchronization);
								}
							} else if(GainInfo) {
								if(									(FrameID1 == 'X') &&
																	(FrameID2 == 'X') &&
																	(FrameID3 == 'X')) {
									char	FieldName[MAX_MUSICTEXT];
									char	FieldData[MAX_MUSICTEXT];

									ID3v2FrameTXXX(
												TagDataPnt,
												FrameSize,
												FieldName,
												sizeof FieldName,
												FieldData,
												sizeof FieldData,
												FrameUnsynchronization);

									int		ReplayGainFieldName;

									if((ReplayGainTrackGainSc == false) &&
											_stricmp(FieldName, APE_TAG_FIELD_REPLAYGAIN_TRACK_GAIN) ==
																								0) {
										ReplayGainFieldName = REPLAYGAIN_TRACK_GAIN;
										ReplayGainTrackGainSc = true;
									} else if((ReplayGainTrackPeakSc == false) &&
											_stricmp(FieldName, APE_TAG_FIELD_REPLAYGAIN_TRACK_PEAK) ==
																								0) {
										ReplayGainFieldName = REPLAYGAIN_TRACK_PEAK;
										ReplayGainTrackPeakSc = true;
									} else if((ReplayGainAlbumGainSc == false) &&
											_stricmp(FieldName, APE_TAG_FIELD_REPLAYGAIN_ALBUM_GAIN) ==
																								0) {
										ReplayGainFieldName = REPLAYGAIN_ALBUM_GAIN;
										ReplayGainAlbumGainSc = true;
									} else if((ReplayGainAlbumPeakSc == false) &&
											_stricmp(FieldName, APE_TAG_FIELD_REPLAYGAIN_ALBUM_PEAK) ==
																								0) {
										ReplayGainFieldName = REPLAYGAIN_ALBUM_PEAK;
										ReplayGainAlbumPeakSc = true;
									} else {
										ReplayGainFieldName = REPLAYGAIN_NONE;
									}

									if(ReplayGainFieldName != REPLAYGAIN_NONE) {
										StoreReplayGainInfo(ReplayGainFieldName, FieldData, GainInfo);
									}
								}
							}
						} else if(Info && (CommentSc == false) &&	(FrameID0 == 'C') &&
																	(FrameID1 == 'O') &&
																	(FrameID2 == 'M') &&
																	(FrameID3 == 'M')) {
							ID3v2FrameCOMM(
										TagDataPnt,
										FrameSize,
										Info->Comment,
										MAX_MUSICTEXT,
										FrameUnsynchronization);
							CommentSc = true;
						}
					}

					TagDataPnt += FrameSize;
				}

				delete[] TagData;

				RetCode = true;

				if(Info) {
					if(TitleSc == false) *Info->Title = '\0';
					if(ArtistSc == false) *Info->Artist = '\0';
					if(CommentSc == false) *Info->Comment = '\0';
					if(AlbumSc == false) *Info->Album = '\0';
					if(YearSc == false) *Info->Year = '\0';
					if(GenreSc) {
						if(*Info->Genre == '(') {
							char*	GenreBuff;

							for(GenreBuff = Info->Genre; *GenreBuff; GenreBuff++) {
								if(*GenreBuff == ')') {
									*GenreBuff = '\0';
									GenreBuff++;
									break;
								}
							}

							if(*GenreBuff) {
								memmove(Info->Genre, GenreBuff, strlen(GenreBuff) + 1);
							} else {
								const int	Genre = atoi(Info->Genre + 1);

								if(Genre < MAX_GENRE) {
									strcpy_s(Info->Genre, sizeof Info->Genre, GenreList[Genre]);
								} else {
									*Info->Genre = '\0';
								}
							}
						}
					} else {
						*Info->Genre = '\0';
					}
					if(TrackSc == false) *Info->Track = '\0';
					if(ComposerSc == false) *Info->Composer = '\0';
					if(OrgArtistSc == false) *Info->OrgArtist = '\0';
					if(CopyrightSc == false) *Info->Copyright = '\0';
					if(EncoderSc == false) *Info->Encoder = '\0';
				} else if(GainInfo) {
					FindGainInfo = GainInfo->ValidTrackGain || GainInfo->ValidAlbumGain;
				}
			} else {
				RetCode = false;
			}
		} else {
			RetCode = false;
		}
	} else {
		RetCode = false;
	}

	if(RetCode == false) {
		::CloseHandle(hF);

		FindGainInfo = false;
	}

	return (Info || (GainInfo == NULL)) ? RetCode : FindGainInfo;
}

inline void
ID3v2FrameTEXT(
			unsigned char* TagDataPnt,
			UINT FrameSize,
			char* Buff,
			const UINT BuffSize,
			const bool FrameUnsynchronization)
{
	if(FrameUnsynchronization) {
		FrameSize = ID3v2DecodeUnsynchronization(TagDataPnt, FrameSize, false);
	}

	const UINT	FrameStrSize = FrameSize - 1;
	char*	FrameStrPnt = reinterpret_cast<char*>(TagDataPnt + 1);
	bool	UnicodeUseBOM;
	const UINT	StrCode = *TagDataPnt;

	switch(StrCode) {
	case 0x00:		// ISO-8859-1
		KanjiStrncpy(Buff, FrameStrPnt, Min(FrameStrSize, BuffSize - 1));
		break;
	case 0x01:		// Unicode(UTF-16 Use BOM)
		UnicodeUseBOM = true;
	case 0x02:		// Unicode(UTF-16 BigEndian)
		if(StrCode == 0x02) UnicodeUseBOM = false;

		WideToMultiStrcpy(
						Buff,
						reinterpret_cast<WCHAR*>(FrameStrPnt),
						BuffSize,
						FrameStrSize,
						CP_ACP,
						UnicodeUseBOM,
						true);
		break;
	case 0x03:		// Unicode(UTF-8)
		UTF8ToMultiStrcpy(Buff, FrameStrPnt, BuffSize, FrameStrSize);
		break;
	}
}

inline void
ID3v2FrameTXXX(
			unsigned char* TagDataPnt,
			UINT FrameSize,
			char* FieldName,
			const UINT FieldNameSize,
			char* FieldData,
			const UINT FieldDataSize,
			const bool FrameUnsynchronization)
{
	if(FrameUnsynchronization) {
		FrameSize = ID3v2DecodeUnsynchronization(TagDataPnt, FrameSize, false);
	}

	const UINT	FrameStrSize = FrameSize - 1;
	char*	FrameStrPnt = reinterpret_cast<char*>(TagDataPnt + 1);
	const UINT	StrCode = *TagDataPnt;
	UINT	SimpleStrSize;
	UINT	DetailStrSize;
	bool	UnicodeUseBOM;

	switch(StrCode) {
	case 0x00:		// ISO-8859-1
		SimpleStrSize = strlen(FrameStrPnt);
		DetailStrSize = FrameStrSize - SimpleStrSize - 1;

		KanjiStrncpy(
				FieldName,
				FrameStrPnt,
				Min(SimpleStrSize, FieldNameSize - 1));
		KanjiStrncpy(
				FieldData,
				FrameStrPnt + SimpleStrSize + 1,
				Min(DetailStrSize, FieldDataSize - 1));
		break;
	case 0x01:		// Unicode(UTF-16 Use BOM)
		UnicodeUseBOM = true;
	case 0x02:		// Unicode(UTF-16 BigEndian)
		if(StrCode == 0x02) UnicodeUseBOM = false;

		SimpleStrSize = WideStrSize(reinterpret_cast<WCHAR*>(FrameStrPnt), FrameStrSize);
		DetailStrSize = FrameStrSize - SimpleStrSize;

		WideToMultiStrcpy(
						FieldName,
						reinterpret_cast<WCHAR*>(FrameStrPnt),
						FieldNameSize,
						SimpleStrSize,
						CP_ACP,
						UnicodeUseBOM,
						true);
		WideToMultiStrcpy(
						FieldData,
						reinterpret_cast<WCHAR*>(FrameStrPnt + SimpleStrSize),
						FieldDataSize,
						DetailStrSize,
						CP_ACP,
						UnicodeUseBOM,
						true);
		break;
	case 0x03:		// Unicode(UTF-8)
		SimpleStrSize = strlen(FrameStrPnt) + 1;
		DetailStrSize = FrameStrSize - SimpleStrSize;

		UTF8ToMultiStrcpy(FieldName, FrameStrPnt, FieldNameSize, SimpleStrSize);
		UTF8ToMultiStrcpy(FieldData, FrameStrPnt + SimpleStrSize, FieldDataSize, DetailStrSize);
		break;
	}
}

inline void
ID3v2FrameCOMM(
			unsigned char* TagDataPnt,
			UINT FrameSize,
			char* Buff,
			const UINT BuffSize,
			const bool FrameUnsynchronization)
{
	if(FrameUnsynchronization) {
		FrameSize = ID3v2DecodeUnsynchronization(TagDataPnt, FrameSize, false);
	}

	const UINT	FrameStrSize = FrameSize - 1 - 3;
	char*	FrameStrPnt = reinterpret_cast<char*>(TagDataPnt + 1 + 3);
	const UINT	StrCode = *TagDataPnt;
	UINT	SimpleStrSize;
	UINT	DetailStrSize;
	bool	UnicodeUseBOM;

	switch(StrCode) {
	case 0x00:		// ISO-8859-1
		SimpleStrSize = strlen(FrameStrPnt);
		DetailStrSize = FrameStrSize - SimpleStrSize - 1;

		if(DetailStrSize >= 1) {
			KanjiStrncpy(Buff, FrameStrPnt + SimpleStrSize + 1, Min(DetailStrSize, BuffSize - 1));
		} else {
			KanjiStrncpy(Buff, FrameStrPnt, Min(SimpleStrSize, BuffSize - 1));
		}
		break;
	case 0x01:		// Unicode(UTF-16 Use BOM)
		UnicodeUseBOM = true;
	case 0x02:		// Unicode(UTF-16 BigEndian)
		if(StrCode == 0x02) UnicodeUseBOM = false;

		SimpleStrSize = WideStrSize(reinterpret_cast<WCHAR*>(FrameStrPnt), FrameStrSize);
		DetailStrSize = FrameStrSize - SimpleStrSize;

		if(DetailStrSize >= 2) {
			WideToMultiStrcpy(
							Buff,
							reinterpret_cast<WCHAR*>(FrameStrPnt + SimpleStrSize),
							BuffSize,
							DetailStrSize,
							CP_ACP,
							UnicodeUseBOM,
							true);
		} else {
			WideToMultiStrcpy(
							Buff,
							reinterpret_cast<WCHAR*>(FrameStrPnt),
							BuffSize,
							SimpleStrSize,
							CP_ACP,
							UnicodeUseBOM,
							true);
		}
		break;
	case 0x03:		// Unicode(UTF-8)
		SimpleStrSize = strlen(FrameStrPnt) + 1;
		DetailStrSize = FrameStrSize - SimpleStrSize;

		if(DetailStrSize >= 1) {
			UTF8ToMultiStrcpy(Buff, FrameStrPnt + SimpleStrSize, BuffSize, DetailStrSize);
		} else {
			UTF8ToMultiStrcpy(Buff, FrameStrPnt, BuffSize, SimpleStrSize);
		}
		break;
	}
}

UINT
ID3v2DecodeUnsynchronization(unsigned char* Data, const UINT Size, const bool SetZero)
{
	unsigned char*	WriteData = Data;
	UINT	DecodeSize = 0;
	bool	FullBits = false;

	for(UINT Idx = 0; Idx < Size; Idx++) {
		const unsigned char	DataPnt = *Data++;

		if(DataPnt == 0xff) {
			FullBits = true;
		} else {
		 	if(FullBits) {
				FullBits = false;
				if(DataPnt == 0x00) continue;
			}
		}

		*WriteData++ = DataPnt;
		DecodeSize++;
	}

	if(SetZero) memset(WriteData, 0, Size - DecodeSize);

	return DecodeSize;
}

