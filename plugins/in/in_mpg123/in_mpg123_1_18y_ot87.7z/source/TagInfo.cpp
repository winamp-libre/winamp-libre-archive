
#include "stdafx.h"

#include "wa_ipc.h"

#include "CommonFunc.h"

#include "in_mpg123.h"

#include "TagInfo.h"
#include "VbrTag.h"

bool	getmp3info(bool Decode, char* fn, mp3info* info, VBRTAGDATA* vbr_tag, CSIFInfo* sif);

const char*	GenreList[MAX_GENRE] =
{
	"Blues", "Classic Rock", "Country", "Dance", "Disco",
	"Funk", "Grunge", "Hip-Hop", "Jazz", "Metal",
	"New Age", "Oldies", "Other", "Pop", "R&B",
	"Rap", "Reggae", "Rock", "Techno", "Industrial",
	"Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack",
	"Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk",
	"Fusion", "Trance", "Classical", "Instrumental", "Acid",
	"House", "Game", "Sound Clip", "Gospel", "Noise",
	"AlternRock", "Bass", "Soul", "Punk", "Space",
	"Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic",
	"Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance",
	"Dream", "Southern Rock", "Comedy", "Cult", "Gangsta",
	"Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American",
	"Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes",
	"Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz",
	"Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock",
	"Folk", "Folk/Rock", "National Folk", "Swing", "Fast-Fusion",
	"Bebob", "Latin", "Revival", "Celtic", "Bluegrass",
	"Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock",
	"Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic",
	"Humour", "Speech", "Chanson", "Opera", "Chamber Music",
	"Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove",
	"Satire", "Slow Jam", "Club", "Tango", "Samba",
	"Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle",
	"Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House",
	"Dance Hall", "Goa", "Drum & Bass", "Club House", "Hardcore",
	"Terror", "Indie", "BritPop", "NegerPunk", "Polsk Punk",
	"Beat", "Christian Gangsta", "Heavy Metal", "Black Metal", "Crossover",
	"Contemporary C", "Christian Rock", "Merengue", "Salsa", "Thrash Metal",
	"Anime", "JPop", "SynthPop",
};

Tag::Tag(void)
{
	::InitializeCriticalSection(&CriticalSection);

	FlushCache();
}

Tag::~Tag(void)
{
	::DeleteCriticalSection(&CriticalSection);
}

void
Tag::FlushCache(void)
{
	::EnterCriticalSection(&CriticalSection);

	*Cache.FileName = '\0';
	GetTagTime = 0;

	::LeaveCriticalSection(&CriticalSection);
}

bool
Tag::Get(const char* FileName, CSIFInfo* sif, const char* Format, char* Title)
{
	bool	RetCode;
	TagInfo	Info;

	strcpy_s(Info.FileName, sizeof Info.FileName, FileName);

	if(GetTitleFromID3v2(&Info) ||
			GetTitleFromAPE(&Info) ||
			sif->GetTitleFromSIF(&Info) ||
			GetTitleFromID3v1(&Info)) {
		DoFormat(&Info, Format, Title);
		RetCode = true;
	} else {
		RetCode = false;
	}

	return RetCode;
}

bool
Tag::GetReplayGainInfo(const char* FileName, ReplayGainInfo* Info)
{
	return GetTitleFromID3v2(NULL, Info, FileName) || GetTitleFromAPE(NULL, Info, FileName);
}

void
Tag::StoreReplayGainInfo(const int ReplayGainFieldName, char* Buff, ReplayGainInfo* Info)
{
	if((ReplayGainFieldName == REPLAYGAIN_TRACK_GAIN) ||
			(ReplayGainFieldName == REPLAYGAIN_ALBUM_GAIN)) {
		char*	dB = strstr(Buff, " dB");

		if(dB) *dB = '\0';
	}

	const double	GainPeak = atof(Buff);

	switch(ReplayGainFieldName) {
	case REPLAYGAIN_TRACK_GAIN:
		Info->ValidTrackGain = true;
		Info->TrackGain = GainPeak;
		break;
	case REPLAYGAIN_TRACK_PEAK:
		Info->ValidTrackPeak = true;
		Info->TrackPeak = GainPeak;
		break;
	case REPLAYGAIN_ALBUM_GAIN:
		Info->ValidAlbumGain = true;
		Info->AlbumGain = GainPeak;
		break;
	case REPLAYGAIN_ALBUM_PEAK:
		Info->ValidAlbumPeak = true;
		Info->AlbumPeak = GainPeak;
		break;
	}
}

int
Tag::GetExtendedFileInfo(extendedFileInfoStruct* ExtendedFileInfo)
{
	::EnterCriticalSection(&CriticalSection);

	bool	FindTag = *ExtendedFileInfo->filename &&
						(strcmp(ExtendedFileInfo->filename, Cache.FileName) == 0) &&
						((::timeGetTime() - GetTagTime) <= 2000);

	if(FindTag) {
		GetTagTime = ::timeGetTime();
	} else {
		mp3info	info;
		VBRTAGDATA	vbr_tag;
		CSIFInfo	sif;

		if(memcmp(ExtendedFileInfo->filename, "http://", 7) &&
				getmp3info(false, ExtendedFileInfo->filename, &info, &vbr_tag, &sif)) {
			char	BackFileName[MAX_PATHLEN];

			strcpy_s(BackFileName, sizeof BackFileName, Cache.FileName);
			strcpy_s(Cache.FileName, sizeof Cache.FileName, ExtendedFileInfo->filename);

			FindTag = GetTitleFromID3v2(&Cache) ||
						GetTitleFromAPE(&Cache) ||
						sif.GetTitleFromSIF(&Cache) ||
						GetTitleFromID3v1(&Cache);

			if(FindTag) {
				Cache.Length = info.length;
				GetTagTime = ::timeGetTime();
			} else {
				strcpy_s(Cache.FileName, sizeof Cache.FileName, BackFileName);
			}
		}
	}

	int		RetCode;

	if(FindTag) {
		char	Buff[16];
		char*	RetBuff;
		const char*	MetaData = ExtendedFileInfo->metadata;

		if(_stricmp(MetaData, "length") == 0) {
			_itoa_s(Cache.Length, Buff, sizeof Buff, 10);
			RetBuff = Buff;
			RetCode = 1;
		} else if(_stricmp(MetaData, "title") == 0) {
			RetBuff = Cache.Title;
			RetCode = 1;
		} else if(_stricmp(MetaData, "artist") == 0) {
			RetBuff = Cache.Artist;
			RetCode = 1;
		} else if(_stricmp(MetaData, "comment") == 0) {
			RetBuff = Cache.Comment;
			RetCode = 1;
		} else if(_stricmp(MetaData, "album") == 0) {
			RetBuff = Cache.Album;
			RetCode = 1;
		} else if(_stricmp(MetaData, "year") == 0) {
			RetBuff = Cache.Year;
			RetCode = 1;
		} else if(_stricmp(MetaData, "genre") == 0) {
			RetBuff = Cache.Genre;
			RetCode = 1;
		} else if(_stricmp(MetaData, "track") == 0) {
			RetBuff = Cache.Track;
			RetCode = 1;
		} else {
			RetCode = 0;
		}

		if(RetCode && ExtendedFileInfo->retlen) {
			KanjiStrncpy(ExtendedFileInfo->ret, RetBuff, ExtendedFileInfo->retlen - 1);
		}
	} else {
		RetCode = 0;
	}

	::LeaveCriticalSection(&CriticalSection);

	return RetCode;
}

void
Tag::DoFormat(const TagInfo* Info, const char* Format, char* Title)
{
	const char*	p;
	char*	q = Title;
	int		remain = MAX_PATH - 1;
	int		StrLen;

	for(p = Format; *p != '\0' && remain > 0;) {
		if(*p != '%') {
			*q++ = *p++;
			remain--;
			continue;
		}

		switch(*++p) {
		case '%':
			*q++ = '%';
			remain--;
			break;
		case '1':
			StrLen = strlen(Info->Artist);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Artist, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case '2':
			StrLen = strlen(Info->Title);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Title, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case '3':
			StrLen = strlen(Info->Album);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Album, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case '4':
			StrLen = strlen(Info->Year);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Year, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case '5':
			StrLen = strlen(Info->Comment);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Comment, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case '6':
			{
				const char*	GenreBuff = Info->Genre;

				if(*GenreBuff == '(') {
					for(; *GenreBuff; GenreBuff++) {
						if(*GenreBuff == ')') {
							GenreBuff++;
							break;
						}
					}
				}

				StrLen = strlen(GenreBuff);

				if(remain >= StrLen) {
					KanjiStrncpy(q, GenreBuff, remain);
					remain -= StrLen;
					q += StrLen;
				} else {
					remain = 0;
				}
			}
			break;
		case '7':
			{
				char	Name[MAX_PATHLEN];
				char	NameOnly[MAX_PATHLEN];

				CutPathFileName(Info->FileName, NULL, Name);
				CutFileNameExt(Name, NameOnly, NULL);

				StrLen = strlen(NameOnly);

				if(remain >= StrLen) {
					KanjiStrncpy(q, NameOnly, remain);
					remain -= StrLen;
					q += StrLen;
				} else {
					remain = 0;
				}
			}
			break;
		case '8':
			{
				char	Path[MAX_PATHLEN];

				CutPathFileName(Info->FileName, Path, NULL);

				StrLen = strlen(Path);

				if(remain >= StrLen) {
					KanjiStrncpy(q, Path, remain);
					remain -= StrLen;
					q += StrLen;
				} else {
					remain = 0;
				}
			}
			break;
		case '9':
			{
				char	Ext[MAX_PATHLEN];

				CutFileNameExt(Info->FileName, NULL, Ext);

				StrLen = strlen(Ext);

				if(remain >= StrLen) {
					KanjiStrncpy(q, Ext, remain);
					remain -= StrLen;
					q += StrLen;
				} else {
					remain = 0;
				}
			}
			break;
		case 'a':
			StrLen = strlen(Info->Track);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Track, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case 'b':
			StrLen = strlen(Info->Composer);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Composer, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case 'c':
			StrLen = strlen(Info->OrgArtist);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->OrgArtist, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case 'd':
			StrLen = strlen(Info->Copyright);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Copyright, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		case 'e':
			StrLen = strlen(Info->Encoder);

			if(remain >= StrLen) {
				KanjiStrncpy(q, Info->Encoder, remain);
				remain -= StrLen;
				q += StrLen;
			} else {
				remain = 0;
			}
			break;
		default:
			if(remain >= 1) {
				*q++ = '%';
				remain--;
			}
			if(remain >= 1) {
				*q++ = *p;
				remain--;
			}
			break;
		}

		p++;
	}

	*q = '\0';
}

