
//
//  ID3v1�^�O���擾����
//
//  Written by Otachan
//  http://www3.cypress.ne.jp/otachan/
//

#include "stdafx.h"

#include "wa_ipc.h"

#include "CommonFunc.h"

#include "in_mpg123.h"

#include "TagInfo.h"

extern const char*	GenreList[];

bool
GetTitleFromID3v1(Tag::TagInfo* Info)
{
	::SetLastError(NO_ERROR);

	HANDLE	hF = ::CreateFile(
							Info->FileName,
							GENERIC_READ,
							FILE_SHARE_READ,
							NULL,
							OPEN_EXISTING,
							FILE_FLAG_RANDOM_ACCESS,
							NULL);

	if(::GetLastError() != NO_ERROR) return false;

	DWORD	FileSize = ::GetFileSize(hF, NULL);

	if(FileSize < sizeof(id3tag)) {
		::CloseHandle(hF);
		return false;
	}

	id3tag	ID3tag;
	DWORD	ReadByte;

	memset(ID3tag.tag, '\0', 3);
	::SetFilePointer(hF, FileSize - sizeof ID3tag, NULL, FILE_BEGIN);
	::ReadFile(hF, &ID3tag, sizeof ID3tag, &ReadByte, NULL);

	::CloseHandle(hF);

	if((*ID3tag.tag != 'T') || (*(ID3tag.tag + 1) != 'A') || (*(ID3tag.tag + 2) != 'G')) return false;

	memcpy(Info->Title, ID3tag.title, 30);
	EraseSpace(Info->Title, 30);

	if(ID3tag.genre < MAX_GENRE) {
		strcpy_s(Info->Genre, sizeof Info->Genre, GenreList[ID3tag.genre]);
	} else {
		*Info->Genre = '\0';
	}

	memcpy(Info->Year, ID3tag.year, 4);
	EraseSpace(Info->Year, 4);

	memcpy(Info->Artist, ID3tag.artist, 30);
	EraseSpace(Info->Artist, 30);

	memcpy(Info->Album, ID3tag.album, 30);
	EraseSpace(Info->Album, 30);

	int		CommentLen;

	if(ID3tag.comment[28] == '\0') {
		const int	Track = static_cast<unsigned char>(ID3tag.comment[29]);

		if(Track) {
			_itoa_s(Track, Info->Track, sizeof Info->Track, 10);
		} else {
			*Info->Track = '\0';
		}

		CommentLen = 28;
	} else {
		*Info->Track = '\0';
		CommentLen = 30;
	}

	memcpy(Info->Comment, ID3tag.comment, CommentLen);
	EraseSpace(Info->Comment, CommentLen);

	*Info->Composer = '\0';
	*Info->OrgArtist = '\0';
	*Info->Copyright = '\0';
	*Info->Encoder = '\0';

	return true;
}

