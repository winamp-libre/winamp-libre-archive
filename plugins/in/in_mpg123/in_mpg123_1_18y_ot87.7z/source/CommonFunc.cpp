
//
//  �ėp�֐�
//
//  Written by Otachan
//  http://www3.cypress.ne.jp/otachan/
//

#define	STRICT

#include <windows.h>
#include <mbctype.h>

#include "CommonFunc.h"

#pragma warning(disable:4996)

bool
CutPathFileName(const char* FullName, char* FileNamePath, char* FileName)
{
	unsigned char	Str;
	int		cnt = 0;
	int		BackSlashCnt = -1;
	bool	Kanji = false;

	while((Str = *(FullName + cnt)) != '\0') {
		if(!Kanji) {
			if(_ismbblead(Str)) {
				Kanji = true;
			} else {
				if((Str == '\\') || (Str == '/')) {
					BackSlashCnt = cnt;
				}
			}
		} else {
			Kanji = false;
		}
		cnt++;
	}

	if(FileNamePath) {
		memcpy(FileNamePath, FullName, BackSlashCnt + 1);
		*(FileNamePath + 1 + BackSlashCnt) = '\0';
	}

	if(FileName) {
		strcpy(FileName, FullName + 1 + BackSlashCnt);
	}

	return BackSlashCnt != -1;
}

void
CutFileNameExt(const char* FullName, char* FileName, char* FileExt)
{
	char	Str = '\0';
	int		ExtCnt;
	const int	FullNameLen = strlen(FullName);

	for(ExtCnt = FullNameLen - 1; ExtCnt >= 0; ExtCnt--) {
		Str = *(FullName + ExtCnt);
		if((Str == '.') || (Str == '\\')  || (Str == '/')) break;
	}

	if(Str != '.') ExtCnt = FullNameLen;

	if(FileName) {
		memcpy(FileName, FullName, ExtCnt);
		*(FileName + ExtCnt) = '\0';
	}

	if(FileExt) {
		if(Str == '.') {
			strcpy(FileExt, FullName + ExtCnt + 1);
		} else {
			*FileExt = '\0';
		}
	}
}

char*
KanjiStrncpy(char* OutBuff, const char* InBuff, const int Len)
{
	char*	RetOutBuff = OutBuff;
	unsigned char	Str;
	bool	Kanji = false;

	for(int cnt = 0; (cnt < Len) && ((Str = *(InBuff + cnt)) != '\0'); cnt++) {
		if(!Kanji) {
			if(_ismbblead(Str)) {
				Kanji = true;
			}
		} else {
			Kanji = false;
		}
		*OutBuff++ = Str;
	}

	*(OutBuff - (Kanji ? 1 : 0)) = '\0';

	return RetOutBuff;
}

char*
WideToMultiStrcpy(
				char* OutBuff,
				WCHAR* InBuff,
				UINT OutBuffSize,
				UINT InBuffSize,
				UINT CodePage,
				bool UseBOM,
				bool BigEndian)
{
	InBuffSize /= 2;

	if(UseBOM && (InBuffSize >= 1)) {
		if((*reinterpret_cast<unsigned char*>(InBuff) == 0xfe) &&
					(*(reinterpret_cast<unsigned char*>(InBuff) + 1) == 0xff)) {
							// �r�b�O�G���f�B�A��
			InBuff++;
			InBuffSize--;
			BigEndian = true;
		} else if((*reinterpret_cast<unsigned char*>(InBuff) == 0xff) &&
					(*(reinterpret_cast<unsigned char*>(InBuff) + 1) == 0xfe)) {
							// ���g���G���f�B�A��
			InBuff++;
			InBuffSize--;
			BigEndian = false;
		}
	}

	WCHAR*	WorkBuff;

	if(BigEndian) {
		WorkBuff = new WCHAR[InBuffSize];

		unsigned short*	InBuffPnt = reinterpret_cast<unsigned short*>(InBuff);
		unsigned short*	WorkBuffPnt = reinterpret_cast<unsigned short*>(WorkBuff);

		for(UINT Idx = 0; Idx < InBuffSize; Idx++) {
			*WorkBuffPnt++ = BSwap16(*InBuffPnt++);
		}
	} else {
		WorkBuff = InBuff;
	}

	const int	WorkOutBuffSize =
					::WideCharToMultiByte(CodePage, 0, WorkBuff, InBuffSize, NULL, 0, NULL, NULL);

	if(WorkOutBuffSize > 0) {
		char*	WorkOutBuff = new char[WorkOutBuffSize + 1];

		::WideCharToMultiByte(CodePage, 0, WorkBuff, InBuffSize, WorkOutBuff, WorkOutBuffSize,
																					NULL, NULL);
		*(WorkOutBuff + WorkOutBuffSize) = '\0';
		KanjiStrncpy(OutBuff, WorkOutBuff, OutBuffSize - 1);

		delete[] WorkOutBuff;
	} else {
		*OutBuff = '\0';
	}

	if(BigEndian) delete[] WorkBuff;

	return OutBuff;
}

char*
UTF8ToMultiStrcpy(char* OutBuff, const char* InBuff, UINT OutBuffSize, int InBuffSize)
{
	if(InBuffSize == -1) InBuffSize = strlen(InBuff);

	const int	WorkBuffSize = ::MultiByteToWideChar(CP_UTF8, 0, InBuff, InBuffSize, NULL, 0);

	if(WorkBuffSize > 0) {
		WCHAR*	WorkBuff = new WCHAR[WorkBuffSize];

		::MultiByteToWideChar(CP_UTF8, 0, InBuff, InBuffSize, WorkBuff, WorkBuffSize);
		WideToMultiStrcpy(OutBuff, WorkBuff, OutBuffSize, WorkBuffSize * 2, CP_ACP, false, false);

		delete[] WorkBuff;
	} else {
		*OutBuff = '\0';
	}

	return OutBuff;
}

UINT
WideStrSize(WCHAR* InBuff, const UINT MaxSize)
{
	unsigned char*	InBuffPnt = reinterpret_cast<unsigned char*>(InBuff);
	bool	FirstByte = true;
	bool	ZeroBits = false;
	UINT	Size;

	for(Size = 0; Size < MaxSize; Size++) {
		unsigned char	Str = *InBuffPnt++;

		if(Str == 0x00) {
			if(ZeroBits && (FirstByte == false)) {
				Size++;
				break;
			}
			ZeroBits = true;
		} else {
			ZeroBits = false;
		}

		FirstByte = !FirstByte;
	}

	return Size;
}

// �����񒆁A���̗]���ȃX�y�[�X����菜��

bool
EraseSpace(char* InBuff, const int Len)
{
	int		Idx;

	for(Idx = Len - 1; Idx >= 0; Idx--) {
		char*	InBuffIdx = InBuff + Idx;

		if((*InBuffIdx != 0x20) && (*InBuffIdx != '\0')) break;
	}

	if(Idx < 0) {
		*InBuff = '\0';
		return true;
	}

	bool	Kanji = false;

	for(int KanjiIdx = 0; KanjiIdx <= Idx; KanjiIdx++) {
		if(!Kanji) {
			if(_ismbblead(*(InBuff + KanjiIdx))) Kanji = true;
		} else {
			Kanji = false;
		}
	}

	if(Kanji) {
		if(Idx < (Len - 1)) Idx++;
	}

	// ������̍Ō��CR+LF����菜��

	bool	CrLf;

	if(Idx >= 1) {
		if((*(InBuff + Idx - 1) == 0x0d) && (*(InBuff + Idx) == 0x0a)) {
			CrLf = true;
		} else {
			CrLf = false;
		}
	} else {
		CrLf = false;
	}

	if(CrLf) {
		*(InBuff + Idx - 1) = '\0';
		if(Idx == 1) return true;
	} else {
		*(InBuff + Idx + 1) = '\0';
	}

	return false;
}

