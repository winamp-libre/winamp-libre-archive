
//
//  ID3v2�^�O���擾����(�w�b�_)
//
//  Written by Otachan
//  http://www3.cypress.ne.jp/otachan/
//

inline void	ID3v2FrameTEXT(
						unsigned char* TagDataPnt,
						UINT FrameSize,
						char* Buff,
						const UINT BuffSize,
						const bool FrameUnsynchronization);
inline void	ID3v2FrameTXXX(
						unsigned char* TagDataPnt,
						UINT FrameSize,
						char* FieldName,
						const UINT FieldNameSize,
						char* FieldData,
						const UINT FieldDataSize,
						const bool FrameUnsynchronization);
inline void	ID3v2FrameCOMM(
						unsigned char* TagDataPnt,
						UINT FrameSize,
						char* Buff,
						const UINT BuffSize,
						const bool FrameUnsynchronization);
UINT	ID3v2DecodeUnsynchronization(unsigned char* Data, const UINT Size, const bool SetZero);

