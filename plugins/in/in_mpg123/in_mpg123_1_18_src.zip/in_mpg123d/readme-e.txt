
This is a mpg123 based mp3 decoder plugin for winamp.

Copy in_mpg123.dll to the plugin directory, uncheck Layer III checkbox on the
General tab in in_mp3.dll(the original nitrane decoder) configuration panel.
And, restart winamp.


*** ID3 tag editor is not fully tested. Backup your file before using this function. ***


History
1.18   Streaming support. (basic functions only)
       RMP(RIFF MP3 file) support by YunaSoft.
       Accurate time display by YunaSoft
       Made dialogs and documents bilingual.
       some other bugfixes.
1.17   nitrane style bitrate display works more decently.
       implemented alternate volume setting method, etc.
       some other bugfixes.
       (binary distribution :
          used profile guided optimization flag and
          automatic MMX utilization flag to compile)
1.16   implemented nitrane style bitrate display.
       added crude locking mechanism of decoder.
1.15   implemented ID3 tag editor.
1.14   optional error tolerant setting
1.13   changed font of config pane. seeking problem fixed.
1.12   fixed small bug which is introduced in 1.11
1.11   added ID3v2 tag skipping. slightly improved sound quality.
1.10   added 'enable' checkbox.
       Now you can select decoder without exiting winamp.
1.10b2 should crash less frequently.
1.10b  implemented ID3 title formatting, seekbar support.
1.00   first release.

http://www.geocities.co.jp/Technopolis/9674/in_mpg123.html
shibatch@geocities.co.jp
