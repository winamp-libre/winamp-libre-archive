// ConfigDialog.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include "in_mpg123d.h"
#include "ConfigDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConfigDialog �_�C�A���O


CConfigDialog::CConfigDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CConfigDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConfigDialog)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_DATA_INIT
}


void CConfigDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConfigDialog)
	DDX_Control(pDX, IDC_ED_STRBUF, m_ed_strbuf);
	DDX_Control(pDX, IDC_ED_PROXY, m_ed_proxy);
	DDX_Control(pDX, IDC_CH_DISPAVG, m_ch_dispavg);
	DDX_Control(pDX, IDC_CH_FORCE, m_ch_force);
	DDX_Control(pDX, IDC_CH_ENABLE, m_ch_enable);
	DDX_Control(pDX, IDC_ED_TITLE, m_ed_title);
	DDX_Control(pDX, IDC_CH_VOLUME, m_ch_cvolume);
	DDX_Control(pDX, IDC_CH_SUPZERO, m_ch_csupzero);
	DDX_Control(pDX, IDC_CH_INVERT, m_ch_cinvert);
	DDX_Control(pDX, IDC_CH_24BIT, m_ch_c24bit);
	DDX_Control(pDX, ID_CH_REV, m_ch_crev);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConfigDialog, CDialog)
	//{{AFX_MSG_MAP(CConfigDialog)
	ON_EN_KILLFOCUS(IDC_ED_STRBUF, OnKillfocusEdStrbuf)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConfigDialog ���b�Z�[�W �n���h��


// Variables which keep state of config panel

char xed_title[256];
int xch_enable=0;
int xch_supzero=0;
int xch_force=0;
int xch_dispavg=0;
int xch_24bit=0;
int xch_volume=0;
int xch_reverse=0;
int xch_invert=0;
int xstrbuflen=256;
char xed_proxy[256];

BOOL CConfigDialog::OnInitDialog() 
{
	char mes[12];
	
	CDialog::OnInitDialog();
		
	m_ch_enable.SetCheck(xch_enable);
	m_ch_csupzero.SetCheck(xch_supzero);
	m_ch_force.SetCheck(xch_force);
	m_ch_dispavg.SetCheck(xch_dispavg);
	m_ch_c24bit.SetCheck(xch_24bit);
	m_ch_cvolume.SetCheck(xch_volume);
	m_ch_crev.SetCheck(xch_reverse);
	m_ch_cinvert.SetCheck(xch_invert);
	m_ed_title.SetWindowText(xed_title);
	m_ed_proxy.SetWindowText(xed_proxy);
	wsprintf(mes,"%d",xstrbuflen);
	m_ed_strbuf.SetWindowText(mes);
	m_ed_strbuf.LimitText(4);

	return TRUE;  // �R���g���[���Ƀt�H�[�J�X��ݒ肵�Ȃ��Ƃ��A�߂�l�� TRUE �ƂȂ�܂�
	              // ��O: OCX �v���p�e�B �y�[�W�̖߂�l�� FALSE �ƂȂ�܂�
}

void CConfigDialog::OnOK() 
{
	char mes[12];
	
	xch_enable = m_ch_enable.GetCheck();
	xch_supzero = m_ch_csupzero.GetCheck();
	xch_force = m_ch_force.GetCheck();
	xch_dispavg = m_ch_dispavg.GetCheck();
	xch_24bit = m_ch_c24bit.GetCheck();
	xch_volume = m_ch_cvolume.GetCheck();
	xch_reverse = m_ch_crev.GetCheck();
	xch_invert = m_ch_cinvert.GetCheck();
	m_ed_title.GetWindowText(xed_title,255);
	m_ed_proxy.GetWindowText(xed_proxy,255);
	m_ed_strbuf.GetWindowText(mes,10);
	xstrbuflen = atoi(mes);
	if (xstrbuflen <= 0) xstrbuflen = 256;

	CDialog::OnOK();
}

void CConfigDialog::OnKillfocusEdStrbuf() 
{
	char mes[12];
	int l;

	m_ed_strbuf.GetWindowText(mes,10);
	l = atoi(mes);
	if (l <= 0) l = xstrbuflen;
	wsprintf(mes,"%d",l);
	m_ed_strbuf.SetWindowText(mes);
}
