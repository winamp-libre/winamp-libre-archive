// InfoDialog.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include <stdio.h>
#include <io.h>

#include "stdafx.h"
#include "in_mpg123d.h"
#include "InfoDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInfoDialog �_�C�A���O

typedef struct id3tag {
	char tag[3];
	char title[30];
	char artist[30];
	char album[30];
	char year[4];
	char comment[30];
	unsigned char genre;
} id3tag;

id3tag xediting_id3;
char *xediting_id3fn;

#define GENRE_LAST 147

CInfoDialog::CInfoDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CInfoDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInfoDialog)
	//}}AFX_DATA_INIT
}


void CInfoDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInfoDialog)
	DDX_Control(pDX, IDC_CB_GENRE, m_cb_genre);
	DDX_Control(pDX, IDC_ED_YEAR, m_ed_year);
	DDX_Control(pDX, IDC_ED_TITLE, m_ed_title);
	DDX_Control(pDX, IDC_ED_FILENAME, m_ed_filename);
	DDX_Control(pDX, IDC_ED_COMMENT, m_ed_comment);
	DDX_Control(pDX, IDC_ED_ARTIST, m_ed_artist);
	DDX_Control(pDX, IDC_ED_ALBUM, m_ed_album);
	DDX_Control(pDX, IDOK, m_but_ok);
	DDX_Control(pDX, IDC_BUT_REMOVE, m_but_remove);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInfoDialog, CDialog)
	//{{AFX_MSG_MAP(CInfoDialog)
	ON_BN_CLICKED(IDOK, OnSave)
	ON_BN_CLICKED(IDC_BUT_REMOVE, OnButRemove)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInfoDialog ���b�Z�[�W �n���h��

BOOL CInfoDialog::OnInitDialog() 
{

	CDialog::OnInitDialog();

	m_ed_title.LimitText(30);
	m_ed_artist.LimitText(30);
	m_ed_album.LimitText(30);
	m_ed_year.LimitText(4);
	m_ed_comment.LimitText(30);
	
	m_ed_filename.SetWindowText(xediting_id3fn);

	if (strncmp(xediting_id3.tag,"TAG",3) == 0) {
		char buf[31];
		char *r;

		strncpy(buf,xediting_id3.title,30);
		buf[30] = '\0';
		for(r = buf;*r != '\0';r++) ;
		for(r--;r >= buf && *r == ' ';r--) ;
		*(r+1) = '\0';
		m_ed_title.SetWindowText(buf);

		strncpy(buf,xediting_id3.artist,30);
		buf[30] = '\0';
		for(r = buf;*r != '\0';r++) ;
		for(r--;r >= buf && *r == ' ';r--) ;
		*(r+1) = '\0';
		m_ed_artist.SetWindowText(buf);

		strncpy(buf,xediting_id3.album,30);
		buf[30] = '\0';
		for(r = buf;*r != '\0';r++) ;
		for(r--;r >= buf && *r == ' ';r--) ;
		*(r+1) = '\0';
		m_ed_album.SetWindowText(buf);

		strncpy(buf,xediting_id3.year,4);
		buf[4] = '\0';
		for(r = buf;*r != '\0';r++) ;
		for(r--;r >= buf && *r == ' ';r--) ;
		*(r+1) = '\0';
		m_ed_year.SetWindowText(buf);

		strncpy(buf,xediting_id3.comment,30);
		buf[30] = '\0';
		for(r = buf;*r != '\0';r++) ;
		for(r--;r >= buf && *r == ' ';r--) ;
		*(r+1) = '\0';
		m_ed_comment.SetWindowText(buf);

		if (xediting_id3.genre > GENRE_LAST) {
			m_cb_genre.SetCurSel(0);
		} else {
			m_cb_genre.SetCurSel(xediting_id3.genre+1);
		}
	} else {
		char buf[31];
		char *q,*r,*s;
		int remain = 30;

		r=s=xediting_id3fn+strlen(xediting_id3fn);
		while (*r != '\\' && r >= xediting_id3fn) r--;
		r++;
		while (*s != '.'  && s >= xediting_id3fn) s--;
		if (s < r) s = xediting_id3fn+strlen(xediting_id3fn);
		q = buf;
		while(r < s && remain > 0) {
			*q++ = *r++;
			remain--;
		}

		*q = '\0';
		m_ed_title.SetWindowText(buf);
	}

	return TRUE;  // �R���g���[���Ƀt�H�[�J�X��ݒ肵�Ȃ��Ƃ��A�߂�l�� TRUE �ƂȂ�܂�
	              // ��O: OCX �v���p�e�B �y�[�W�̖߂�l�� FALSE �ƂȂ�܂�
}

void stuffSpace(char *buf,int len)
{
	int i;

	for(i=0;i<len;i++) if (buf[i] == '\0') break;
	for(;i<len;i++) buf[i] = ' ';
}

void CInfoDialog::OnSave() 
{
	FILE *fp;
	char buf[31];

	memcpy(xediting_id3.tag,"TAG",3);

	m_ed_title.GetWindowText(buf,31);
	stuffSpace(buf,30);	
	memcpy(xediting_id3.title,buf,30);

	m_ed_artist.GetWindowText(buf,31);
	stuffSpace(buf,30);	
	memcpy(xediting_id3.artist,buf,30);

	m_ed_album.GetWindowText(buf,31);
	stuffSpace(buf,30);	
	memcpy(xediting_id3.album,buf,30);

	m_ed_year.GetWindowText(buf,5);
	stuffSpace(buf,4);	
	memcpy(xediting_id3.year,buf,4);

	m_ed_comment.GetWindowText(buf,31);
	stuffSpace(buf,30);	
	memcpy(xediting_id3.comment,buf,30);

	int cb = m_cb_genre.GetCurSel();
	if (cb == CB_ERR || cb == 0) {
		xediting_id3.genre = (unsigned char) 255;
	} else {
		xediting_id3.genre = (unsigned char) (cb-1);
	}

	fp = fopen(xediting_id3fn,"r+b");
	if (fp == NULL) {
		MessageBox("Cannot write to the file","Cannot save",MB_OK|MB_ICONEXCLAMATION);
		return;
	}

	fseek(fp,-128,SEEK_END);
	fread(buf,1,3,fp);

	if (strncmp(buf,"TAG",3) != 0) fseek(fp,0,SEEK_END); else fseek(fp,-128,SEEK_END);

	fwrite(&xediting_id3,sizeof(xediting_id3),1,fp);

	fclose(fp);	

	CDialog::OnOK();
}

void CInfoDialog::OnButRemove() 
{
	FILE *fp;
	long int tagpos;
	char buf[3];

	fp = fopen(xediting_id3fn,"r+b");
	if (fp == NULL) {
		MessageBox("Cannot write to the file","Cannot remove",MB_OK|MB_ICONEXCLAMATION);
		return;
	}

	fseek(fp,-128,SEEK_END);
	tagpos = ftell(fp);
	fread(buf,1,3,fp);

	if (strncmp(buf,"TAG",3) == 0) {
		int hn = _fileno(fp);
		if (_chsize(hn,tagpos)) {
			MessageBox("Error changing file size","Cannot remove",MB_OK|MB_ICONEXCLAMATION);
		}
	}

	fclose(fp);

	xediting_id3.tag[0] = '\0';
	
	CDialog::OnOK();
}

void CInfoDialog::OnCancel() 
{
	// TODO: ���̈ʒu�ɓ��ʂȌ㏈����ǉ����Ă��������B
	
	CDialog::OnCancel();
}
