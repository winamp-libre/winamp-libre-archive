/*
** in_mpg123  -  a MP3 decoder plugin based on mpg123
** Written by Naoki Shibata
** http://www.geocities.co.jp/Technopolis/9674/in_mpg123.html
*/

#include "stdafx.h"
#include "in_mpg123d.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define VERSIONSTRINGBASE "1.18"

#ifdef __ICL
#define VERSIONSTRING VERSIONSTRINGBASE"+"
#else
#define VERSIONSTRING VERSIONSTRINGBASE
#endif

BEGIN_MESSAGE_MAP(CIn_mpg123dApp, CWinApp)
	//{{AFX_MSG_MAP(CIn_mpg123dApp)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
		//        ���̈ʒu�ɐ��������R�[�h��ҏW���Ȃ��ł��������B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CIn_mpg123dApp::CIn_mpg123dApp()
{
	// TODO: ���̈ʒu�ɍ\�z�p�̃R�[�h��ǉ����Ă��������B
	// ������ InitInstance �̒��̏d�v�ȏ��������������ׂċL�q���Ă��������B
}

CIn_mpg123dApp theApp;

#if 1

#include <windows.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <afxinet.h>

#include "ConfigDialog.h"
#include "InfoDialog.h"
#include "SIFInfoDialog.h"

// avoid CRT. Evil. Big. Bloated.
BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}

#include <math.h>
#include <string.h>

extern "C" {
#include "mpg123.h"
#include "mpglib.h"
#include "in2.h"
#include "VbrTag.h"
}
#define WM_WA_MPEG_EOF WM_USER+2

void config(HWND);
void about(HWND);
void init();
void quit();
void getfileinfo(char *, char *, int *);
int infoDlg(char *, HWND);
int isourfile(char *);
int play(char *);
void pause();
void unpause();
int ispaused();
void stop();
int getlength();
int getoutputtime();
void setoutputtime(int);
void setvolume(int);
void setpan(int);
void eq_set(int, char data[10], int) ;

In_Module mod = 
{
	IN_VER,
	"Shibatch mpg123 plugin ver " VERSIONSTRING,
	0,	// hMainWindow
	0,  // hDllInstance
	"MP3\0MP3 Audio File (*.MP3)\0RMP\0RIFF MP3 Audio File (*.RMP)\0",
	1,	// is_seekable
	1,  // uses output
	config,
	about,
	init,
	quit,
	getfileinfo,
	infoDlg,
	isourfile,
	play,
	pause,
	unpause,
	ispaused,
	stop,
	
	getlength,
	getoutputtime,
	setoutputtime,

	setvolume,
	setpan,

	0,0,0,0,0,0,0,0,0,
	0,0,

	eq_set,

	NULL,

	0
};

extern "C" {
__declspec( dllexport ) In_Module * winampGetInModule2()
{
	return &mod;
}
}

char lastfn[MAX_PATH]; // currently playing file (used for getting info on the current file)
int file_length;       // file length, in bytes
double decode_pos_ms;     // current decoding position, in milliseconds
int paused;            // are we paused?
int seek_needed;       // if != -1, it is the point that the decode thread should seek to, in ms.
char sample_buffer[576*4*2]; // sample buffer
volatile int decoder_in_use = 0;
int xvolume,xpan;

CInternetSession *session=NULL;
CStdioFile *httpfile=NULL;
char *stream_buffer=NULL;
volatile int strbufp_s=0,strbufp_e=0,strbuf_eof=0;
int strbuflen;

HANDLE input_file=INVALID_HANDLE_VALUE; // input file handle

int killDecodeThread=0;					// the kill switch for the decode thread
HANDLE decode_thandle=INVALID_HANDLE_VALUE;	// the handle to the decode thread

int killReceiveThread=0;					// the kill switch for the decode thread
HANDLE receive_thandle=INVALID_HANDLE_VALUE;	// the handle to the decode thread

DWORD WINAPI __stdcall DecodeThread(void *b);  // the decode thread procedure
DWORD WINAPI __stdcall ReceiveThread(void *b); // the receive thread procedure

// Variable to estimate bitrate

extern "C" int totalFramesize,nframe,currentBitrate;

// Variables which keep state of config panel

extern char xed_title[256];
extern int xch_enable;
extern int xch_supzero;
extern int xch_force;
extern int xch_dispavg;
extern int xch_24bit;
extern int xch_volume;
extern int xch_reverse;
extern int xch_invert;
extern int xstrbuflen;
extern char xed_proxy[256];

// Code to extract info from MP3 file.

static int tabsel_123[2][3][16] = {
   { {0,32,64,96,128,160,192,224,256,288,320,352,384,416,448,},
     {0,32,48,56, 64, 80, 96,112,128,160,192,224,256,320,384,},
     {0,32,40,48, 56, 64, 80, 96,112,128,160,192,224,256,320,} },

   { {0,32,48,56,64,80,96,112,128,144,160,176,192,224,256,},
     {0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,},
     {0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,} }
};

typedef struct id3tag {
	char tag[3];
	char title[30];
	char artist[30];
	char album[30];
	char year[4];
	char comment[30];
	unsigned char genre;
} id3tag;


id3tag current_id3;

typedef struct mmioParam {
    HMMIO           hmmio;
	MMCKINFO*       mmckinfoParent;
	MMCKINFO*       mmckinfoSubchunk;
	MMCKINFO*       mmckinfoSubSubchunk;
	WAVEFORMATEX	*pFormat;
} mmioParam;

CSIFData sif;

extern id3tag xediting_id3;
extern char *xediting_id3fn;

static char	VBRTag[]={"Xing"};

VBRTAGDATA current_vbrtag;

typedef struct mp3info {
	int nbytes,freq,nch,hpos;
	int hasVbrtag,lsf,bitrate,isStream;
	double length;
} mp3info;

mp3info cur_mp3info;

static int ExtractI4(unsigned char *buf)
{
	int x;
	x = buf[0];
	x <<= 8;
	x |= buf[1];
	x <<= 8;
	x |= buf[2];
	x <<= 8;
	x |= buf[3];
	return x;
}

int GetVbrTag(VBRTAGDATA *pTagData,  unsigned char *buf)
{
	int			i, head_flags;
	int			h_id, h_mode, h_sr_index;
	static int	sr_table[4] = { 44100, 48000, 32000, 99999 };

	pTagData->flags = 0;     

	h_id       = (buf[1] >> 3) & 1;
	h_sr_index = (buf[2] >> 2) & 3;
	h_mode     = (buf[3] >> 6) & 3;

	if( h_id ) 
	{
		if( h_mode != 3 )	buf+=(32+4);
		else				buf+=(17+4);
	}
	else
	{
		if( h_mode != 3 ) buf+=(17+4);
		else              buf+=(9+4);
	}
	
	if( buf[0] != VBRTag[0] ) return 0;
	if( buf[1] != VBRTag[1] ) return 0;
	if( buf[2] != VBRTag[2] ) return 0;
	if( buf[3] != VBRTag[3] ) return 0;

	buf+=4;

	pTagData->h_id = h_id;

	pTagData->samprate = sr_table[h_sr_index];

	if( h_id == 0 )
		pTagData->samprate >>= 1;

	head_flags = pTagData->flags = ExtractI4(buf); buf+=4;

	if( head_flags & FRAMES_FLAG )
	{
		pTagData->frames   = ExtractI4(buf); buf+=4;
	}

	if( head_flags & BYTES_FLAG )
	{
		pTagData->bytes = ExtractI4(buf); buf+=4;
	}

	if( head_flags & TOC_FLAG )
	{
		if( pTagData->toc != NULL )
		{
			for(i=0;i<NUMTOCENTRIES;i++)
				pTagData->toc[i] = buf[i];
		}
		buf+=NUMTOCENTRIES;
	}

	pTagData->vbr_scale = -1;

	if( head_flags & VBR_SCALE_FLAG )
	{
		pTagData->vbr_scale = ExtractI4(buf); buf+=4;
	}

	return 1;
}

static int head_check(unsigned long head)
{
    if ((head & 0xffe00000) != 0xffe00000) return FALSE;
    if (!((head>>17)&3)) return FALSE;
    if (((head>>12)&0xf) == 0xf) return FALSE;
    if (((head>>10)&0x3) == 0x3 ) return FALSE;
    //if ((head & 0xffff0000) == 0xfffe0000) return FALSE;
	if ((4-((head>>17)&3)) != 3) return FALSE;
    return TRUE;
}

static int head_check2(unsigned long head,mp3info *info)
{
	int lsf,srate,nch,lay,mpeg25,freq,mode;

    if ((head & 0xffe00000) != 0xffe00000) return FALSE;
    if (!((head>>17)&3)) return FALSE;
    if (((head>>12)&0xf) == 0xf) return FALSE;
    if (((head>>10)&0x3) == 0x3 ) return FALSE;
    //if ((head & 0xffff0000) == 0xfffe0000) return FALSE;

    if( head & (1<<20) ) {
      lsf = (head & (1<<19)) ? 0x0 : 0x1;
      mpeg25 = 0;
    } else {
      lsf = 1;
      mpeg25 = 1;
    }

	if(mpeg25) srate = 6 + ((head>>10)&0x3);
    else srate = ((head>>10)&0x3) + (lsf*3);

    mode  = ((head>>6)&0x3);
	freq  = freqs[srate];
    nch   = (mode == MPG_MD_MONO) ? 1 : 2;
	lay   = 4-((head>>17)&3);

	if (lay != 3) return FALSE;
	if (nch != info->nch) return FALSE;
	if (freq != info->freq) return FALSE;

    return TRUE;
}

void getsifinfoNew(mmioParam* mmio)
{
	mmio->hmmio = NULL;
	mmio->mmckinfoParent       = new MMCKINFO;
	mmio->mmckinfoSubchunk     = new MMCKINFO;
	mmio->mmckinfoSubSubchunk  = new MMCKINFO;
	mmio->pFormat = NULL;
}

void getsifinfoDelete(mmioParam* mmio)
{
	if(mmio->hmmio) {
		mmioClose(mmio->hmmio, 0);
		mmio->hmmio = NULL;
	}
	delete mmio->mmckinfoParent;
	delete mmio->mmckinfoSubchunk;
	delete mmio->mmckinfoSubSubchunk;
	if(mmio->pFormat) {
		delete mmio->pFormat;
		mmio->pFormat = NULL;
	}

	delete mmio;
	mmio = NULL;
}

void getsifinfoString(mmioParam* mmio, CString* str)
{
	char *p;
	DWORD dwListSize;

	if (mmioDescend(mmio->hmmio, mmio->mmckinfoSubSubchunk,
		mmio->mmckinfoSubchunk, MMIO_FINDCHUNK) == NULL) {
		
		dwListSize = mmio->mmckinfoSubSubchunk->cksize;
		p = new char[dwListSize + 1];
		if(mmioRead(mmio->hmmio, (HPSTR)p, dwListSize) == (LONG) dwListSize) {
			*(p + dwListSize) = NULL;
			*str = p;
		}
		delete p;
		mmioAscend(mmio->hmmio, mmio->mmckinfoSubSubchunk, 0);
	}
}

void sifinit(void)
{
	// ������
	sif.m_file      = "";
	sif.m_title     = "";
	sif.m_artist    = "";
	sif.m_album     = "";
	sif.m_year      = "";
	sif.m_comment   = "";
	sif.m_genre     = "";
	sif.m_engineer  = "";
	sif.m_copyright = "";
	sif.m_source    = "";
	sif.m_software  = "";
	sif.m_datasize  = 0;
	sif.m_enable = FALSE;
}

int getsifinfo(char *fn)
{

	// �����o
	mmioParam* mmio;
	MMRESULT ret;
	DWORD dwDataSize;
	int hpos;
	CString str;

	// new
	mmio = new mmioParam;
	getsifinfoNew(mmio);

	// �o�b�t�@�t��I/O���g���ēǂݎ��p�Ƃ��ăt�@�C�����J��
	if(!(mmio->hmmio = mmioOpen(fn, NULL, MMIO_READ | MMIO_ALLOCBUF))) {
		getsifinfoDelete(mmio);
		return 0;
	}

	// 'RMP3'�t�H�[���^�C�v��'RIFF'�`�����N���������A���ꂪ
	// WAVE�t�@�C���ł��邩�ǂ������m�F
	mmio->mmckinfoParent->fccType = mmioFOURCC('R', 'M', 'P', '3');
	if (mmioDescend(mmio->hmmio, mmio->mmckinfoParent, NULL, MMIO_FINDRIFF)) {

		mmioSeek(mmio->hmmio, 0, SEEK_SET);
		// 'WAVE'�t�H�[���^�C�v��'RIFF'�`�����N���������A���ꂪ
		// WAVE�t�@�C���ł��邩�ǂ������m�F
		mmio->mmckinfoParent->fccType = mmioFOURCC('W', 'A', 'V', 'E');
		if (mmioDescend(mmio->hmmio, mmio->mmckinfoParent, NULL, MMIO_FINDRIFF)) {
			// RMP3����Ȃ���
			getsifinfoDelete(mmio);
			return 0;
		}
		// �`���`�����N(�t�H�[���^�C�v'fmt')����������B
		// ����́A�e�`�����N'RIFF'�̃T�u�`�����N�łȂ���΂Ȃ�Ȃ�
		mmio->mmckinfoSubchunk->ckid = mmioFOURCC('f', 'm', 't', ' ');
		if (mmioDescend(mmio->hmmio, mmio->mmckinfoSubchunk,
			mmio->mmckinfoParent, MMIO_FINDCHUNK)) {
			getsifinfoDelete(mmio);
			return 0;
		}

		// �`���`�����N�̃T�C�Y�̕����������������蓖�āA���b�N����
		dwDataSize = mmio->mmckinfoSubchunk->cksize;
		if((mmio->pFormat = (WAVEFORMATEX *)new char [dwDataSize]) == NULL) {
			getsifinfoDelete(mmio);
			return 0;
		}

		// �`���`�����N��ǂݎ��
		if (mmioRead(mmio->hmmio, (HPSTR)mmio->pFormat, dwDataSize) != (LONG) dwDataSize) {
			getsifinfoDelete(mmio);
			return 0;
		}
    
		// 85�Ԃł��邱�Ƃ��m�F
		if (mmio->pFormat->wFormatTag != 85) {
			// ����ȊO�Ȃ烁���������
			getsifinfoDelete(mmio);
			return 0;
		}

		// �`���T�u�`�����N����ړ�
		mmioAscend(mmio->hmmio, mmio->mmckinfoSubchunk, 0);
	
	}

	// �f�[�^�T�u�`�����N������
	mmio->mmckinfoSubchunk->ckid = mmioFOURCC('d', 'a', 't', 'a');
	if (mmioDescend(mmio->hmmio, mmio->mmckinfoSubchunk,
		mmio->mmckinfoParent, MMIO_FINDCHUNK)) {
		getsifinfoDelete(mmio);
		return 0;
	}

	// �f�[�^�T�u�`�����N�̃T�C�Y���擾
	dwDataSize = mmio->mmckinfoSubchunk->cksize;
	if (dwDataSize == 0L) {
		getsifinfoDelete(mmio);
		return 0;
	}
	// hpos���Z�b�g
	hpos = mmio->mmckinfoSubchunk->dwDataOffset;
	// data�T�C�Y
	sif.m_datasize = dwDataSize;

	// data�T�u�`�����N����ړ�
	mmioAscend(mmio->hmmio, mmio->mmckinfoSubchunk, 0);

	// LIST�T�u�`�����N������
	mmio->mmckinfoSubchunk->ckid = mmioFOURCC('L', 'I', 'S', 'T');

	if ((ret = mmioDescend(mmio->hmmio, mmio->mmckinfoSubchunk,
		mmio->mmckinfoParent, MMIO_FINDCHUNK)) == NULL) {
		//  LIST�`�����N������Ȃ�

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'N', 'A', 'M');
		getsifinfoString(mmio, &sif.m_title);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'A', 'R', 'T');
		getsifinfoString(mmio, &sif.m_artist);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'P', 'R', 'D');
		getsifinfoString(mmio, &sif.m_album);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'C', 'R', 'D');
		getsifinfoString(mmio, &sif.m_year);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'C', 'M', 'T');
		getsifinfoString(mmio, &sif.m_comment);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'C', 'O', 'P');
		getsifinfoString(mmio, &sif.m_copyright);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'S', 'R', 'C');
		getsifinfoString(mmio, &sif.m_source);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'G', 'N', 'R');
		getsifinfoString(mmio, &sif.m_genre);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'E', 'N', 'G');
		getsifinfoString(mmio, &sif.m_engineer);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		mmio->mmckinfoSubSubchunk->ckid = mmioFOURCC('I', 'S', 'F', 'T');
		getsifinfoString(mmio, &sif.m_software);
		mmioSeek(mmio->hmmio, mmio->mmckinfoSubchunk->dwDataOffset + 4, SEEK_SET);

		sif.m_file = fn;
		sif.m_enable = TRUE;
		mmioAscend(mmio->hmmio, mmio->mmckinfoSubchunk, 0);
	}
	// delete
	getsifinfoDelete(mmio);

	return hpos;
}

// for streaming
int getmp3info2(mp3info *info)
{
	int i;
	int head;
	int lsf,srate;
	int bitrate_index,mode,nch,lay,extension,mpeg25,padding;

	sifinit();

	for(i=0;i<strbuflen-4;i++)
	{
		while(!strbuf_eof && strbufp_e-4 < i) Sleep(100);

		*(3+(char *)&head) = stream_buffer[i  ];
		*(2+(char *)&head) = stream_buffer[i+1];
		*(1+(char *)&head) = stream_buffer[i+2];
		*(0+(char *)&head) = stream_buffer[i+3];

		if (strbuf_eof || head_check(head)) break;
	}

	{
		char mes[64];
		wsprintf(mes,"strbuf_eof=%d,i=%d",strbuf_eof,i);
		//MessageBox(mod.hMainWindow,mes,"getmp3info2",0);
	}

	if (strbuf_eof || i == strbuflen-4) return 0;

	strbufp_s = i;

    if( head & (1<<20) ) {
      lsf = (head & (1<<19)) ? 0x0 : 0x1;
      mpeg25 = 0;
    } else {
      lsf = 1;
      mpeg25 = 1;
    }

    bitrate_index = ((head>>12)&0xf);
	padding       = ((head>>9)&0x1);
    mode          = ((head>>6)&0x3);
    nch           = (mode == MPG_MD_MONO) ? 1 : 2;
	lay           = 4-((head>>17)&3);
	extension     = ((head>>8)&0x1);

	if(mpeg25) srate = 6 + ((head>>10)&0x3);
    else srate = ((head>>10)&0x3) + (lsf*3);

	if (lay != 3) return 0;

	info->isStream = 1;
	info->nbytes = 0;
	info->hpos = 0;
	info->length = 0;
	info->lsf  = lsf;
	info->freq = freqs[srate];
	info->nch  = nch;
	info->hasVbrtag = 0;
	info->bitrate = tabsel_123[lsf][lay-1][bitrate_index]*1000;
	
	return 1;
}

int getmp3info(char *fn,mp3info *info,id3tag *id3,VBRTAGDATA *vbr)
{
	unsigned long head,len;
	int lsf,srate;
	int bitrate_index,mode,nch,lay,extension,mpeg25,padding;
	int hpos,i;
	HANDLE input_file;

	input_file = CreateFile(fn,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
		OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if (input_file == INVALID_HANDLE_VALUE) // error opening file
	{
		return 0;
	}
	info->isStream = 0;
	info->nbytes=GetFileSize(input_file,NULL);

	hpos = 0;

	sifinit();

	// skip ID3v2 tag
	{
		unsigned char c1,c2,c3,c4;

		ReadFile(input_file,&c1,1,&len,NULL);
		ReadFile(input_file,&c2,1,&len,NULL);
		ReadFile(input_file,&c3,1,&len,NULL);
		ReadFile(input_file,&c4,1,&len,NULL);

		if (c1 == 'I' && c2 == 'D' && c3 == '3' && c4 == 2) {
			SetFilePointer(input_file,6,NULL,FILE_BEGIN);
			ReadFile(input_file,&c1,1,&len,NULL);
			ReadFile(input_file,&c2,1,&len,NULL);
			ReadFile(input_file,&c3,1,&len,NULL);
			ReadFile(input_file,&c4,1,&len,NULL);
			hpos = c1*2097152+c2*16384+c3*128+c4;
		}

		// skip RIFF chunk
		if (c1 == 'R' && c2 == 'I' && c3 == 'F' && c4 == 'F') {
			hpos = getsifinfo(fn);
		}
	}

	for(i=0;i<65536;i++)
	{
		SetFilePointer(input_file,hpos+i,NULL,FILE_BEGIN);
		ReadFile(input_file,3+(char *)&head,1,&len,NULL);
		ReadFile(input_file,2+(char *)&head,1,&len,NULL);
		ReadFile(input_file,1+(char *)&head,1,&len,NULL);
		ReadFile(input_file,0+(char *)&head,1,&len,NULL);
		if (len == 0 || head_check(head)) break;
	}

	if (len == 0 || i == 65536)
	{
		CloseHandle(input_file);
		input_file=INVALID_HANDLE_VALUE;
		return 0;
	}

	hpos += i;

	info->hpos = hpos;
	if(sif.m_datasize) {
		info->nbytes = sif.m_datasize;
	} else {
		info->nbytes -= hpos;

		// read ID3 tag

		SetFilePointer(input_file,-128,NULL,FILE_END);
		ReadFile(input_file,id3,128,&len,NULL);
		if (strncmp(id3->tag,"TAG",3) == 0) info->nbytes -= 128;
	}
	
	SetFilePointer(input_file,hpos,NULL,FILE_BEGIN);

    if( head & (1<<20) ) {
      lsf = (head & (1<<19)) ? 0x0 : 0x1;
      mpeg25 = 0;
    } else {
      lsf = 1;
      mpeg25 = 1;
    }

    bitrate_index = ((head>>12)&0xf);
	padding       = ((head>>9)&0x1);
    mode          = ((head>>6)&0x3);
    nch           = (mode == MPG_MD_MONO) ? 1 : 2;
	lay           = 4-((head>>17)&3);
	extension     = ((head>>8)&0x1);

	if(mpeg25) srate = 6 + ((head>>10)&0x3);
    else srate = ((head>>10)&0x3) + (lsf*3);

	if (lay != 3)
	{
		CloseHandle(input_file);
		input_file=INVALID_HANDLE_VALUE;
		return 0;
	}

	// read VBR tag

	SetFilePointer(input_file,hpos,NULL,FILE_BEGIN);

	info->lsf  = lsf;
	info->freq = freqs[srate];
	info->nch  = nch;
	
	{
		unsigned char buf[VBRHEADERSIZE+36];

		ReadFile(input_file,&buf,VBRHEADERSIZE+36,&len,NULL);
		if (GetVbrTag(&current_vbrtag,buf)) {
			int cur_bitrate = (int)(current_vbrtag.bytes*8/(current_vbrtag.frames*576.0*(lsf?1:2)/freqs[srate]));
			info->length = current_vbrtag.frames*576.0*(lsf?1:2)/freqs[srate];
			info->nbytes = current_vbrtag.bytes;
			info->hasVbrtag = 1;
			info->bitrate = cur_bitrate;
		} else {
			int framesize = tabsel_123[lsf][lay-1][bitrate_index]*144000/(freqs[srate]<<lsf)+padding;
			info->length = info->nbytes/framesize*576.0*(lsf?1:2)/freqs[srate];
			info->hasVbrtag = 0;
			info->bitrate = tabsel_123[lsf][lay-1][bitrate_index]*1000;
			//info->length = info->nbytes * 8 / info->bitrate;
		}
	}

	CloseHandle(input_file);

	return 1; 
}

int SeekPoint(unsigned char TOC[NUMTOCENTRIES], int file_bytes, float percent)
{
	/* interpolate in TOC to get file seek point in bytes */
	int a, seekpoint;
	float fa, fb, fx;

	if( percent < (float)0.0 )   percent = (float)0.0;
	if( percent > (float)100.0 ) percent = (float)100.0;

	a = (int)percent;
	if( a > 99 ) a = 99;
	fa = TOC[a];
	if( a < 99 ) {
		fb = TOC[a+1];
	} else {
		fb = (float)256.0;
	}

	fx = fa + (fb-fa)*(percent-a);

	seekpoint = (int)(((float)(1.0/256.0))*fx*file_bytes); 

	return seekpoint;
}

//

void reflect_setting(void)
{
	if (xch_enable) {
		mod.FileExtensions = "MP3\0MP3 Audio File (*.MP3)\0RMP\0RIFF MP3 Audio File (*.RMP)\0";
	} else {
		mod.FileExtensions = "\0\0";
	}

	if (xch_dispavg && decoder_in_use)
		mod.SetInfo(cur_mp3info.bitrate/1000,-1,-1,-1);

	forceDecoding = xch_force;
}

void config_getinifn(In_Module *this_mod, char *ini_file)
{	// makes a .ini file in the winamp directory named "plugin.ini"
	char *p;
	GetModuleFileName(this_mod->hDllInstance,ini_file,MAX_PATH);
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	strcat(ini_file,"plugin.ini");
}

void init() {
	char ini_file[MAX_PATH];
	config_getinifn(&mod,ini_file);
	xch_enable  = GetPrivateProfileInt("Shibatch mpg123 plugin","Enable" ,  1,ini_file);
	xch_supzero = GetPrivateProfileInt("Shibatch mpg123 plugin","SupZero",  0,ini_file);
	xch_force   = GetPrivateProfileInt("Shibatch mpg123 plugin","Force"  ,  0,ini_file);
	xch_dispavg = GetPrivateProfileInt("Shibatch mpg123 plugin","DispAvg",  1,ini_file);
	xch_24bit   = GetPrivateProfileInt("Shibatch mpg123 plugin","Hibit"  ,  0,ini_file);
	xch_volume  = GetPrivateProfileInt("Shibatch mpg123 plugin","Volume" ,  0,ini_file);
	xch_reverse = GetPrivateProfileInt("Shibatch mpg123 plugin","Reverse",  0,ini_file);
	xch_invert  = GetPrivateProfileInt("Shibatch mpg123 plugin","Invert" ,  0,ini_file);
	xvolume     = GetPrivateProfileInt("Shibatch mpg123 plugin","XVolume",255,ini_file);
	xpan        = GetPrivateProfileInt("Shibatch mpg123 plugin","XPan"   ,  0,ini_file);
	xstrbuflen  = GetPrivateProfileInt("Shibatch mpg123 plugin","StrBuf" ,256,ini_file);
	GetPrivateProfileString("Shibatch mpg123 plugin","Format","%1 - %2",xed_title,255,ini_file);
	GetPrivateProfileString("Shibatch mpg123 plugin","Proxy" ,"",xed_proxy,255,ini_file);
	if (xstrbuflen <= 0) xstrbuflen = 256;

	reflect_setting();

	//

	HINSTANCE hDllInstance;
	In_Module* (*_winampGetInModule2)(void);
}

void quit() {
	char string[32];
	char ini_file[MAX_PATH];

	config_getinifn(&mod,ini_file);

	wsprintf(string,"%d",xch_enable);
	WritePrivateProfileString("Shibatch mpg123 plugin","Enable",string,ini_file);

	wsprintf(string,"%d",xch_supzero);
	WritePrivateProfileString("Shibatch mpg123 plugin","SupZero",string,ini_file);

	wsprintf(string,"%d",xch_force);
	WritePrivateProfileString("Shibatch mpg123 plugin","Force",string,ini_file);

	wsprintf(string,"%d",xch_dispavg);
	WritePrivateProfileString("Shibatch mpg123 plugin","DispAvg",string,ini_file);

	wsprintf(string,"%d",xch_24bit);
	WritePrivateProfileString("Shibatch mpg123 plugin","Hibit",string,ini_file);

	wsprintf(string,"%d",xch_volume);
	WritePrivateProfileString("Shibatch mpg123 plugin","Volume",string,ini_file);

	wsprintf(string,"%d",xch_reverse);
	WritePrivateProfileString("Shibatch mpg123 plugin","Reverse",string,ini_file);

	wsprintf(string,"%d",xch_invert);
	WritePrivateProfileString("Shibatch mpg123 plugin","Invert",string,ini_file);

	wsprintf(string,"%d",xvolume);
	WritePrivateProfileString("Shibatch mpg123 plugin","XVolume",string,ini_file);

	wsprintf(string,"%d",xpan);
	WritePrivateProfileString("Shibatch mpg123 plugin","XPan",string,ini_file);

	wsprintf(string,"%d",xstrbuflen);
	WritePrivateProfileString("Shibatch mpg123 plugin","StrBuf",string,ini_file);

	WritePrivateProfileString("Shibatch mpg123 plugin","Format",xed_title,ini_file);
	WritePrivateProfileString("Shibatch mpg123 plugin","Proxy",xed_proxy,ini_file);
}

//

void config(HWND hwndParent)
{
	CConfigDialog *cd = new CConfigDialog();
	cd->DoModal();
	delete cd;

	reflect_setting();
}

void about(HWND hwndParent)
{
	MessageBox(hwndParent,"mpg123 plugin " VERSIONSTRING " for winamp by Shibatch and YunaSoft\n"
				"http://www.geocities.co.jp/Technopolis/9674/in_mpg123.html\n"
				"http://www.yunasoft.gr.jp/","About mpg123 plugin",MB_OK);
}

int isourfile(char *fn) {
	if (xch_enable && strncmp(fn,"http://",7) == 0) return 1;

	return 0;
} 

void pause() {
	paused=1;
	mod.outMod->Pause(1);
}

void unpause() {
	paused=0;
	mod.outMod->Pause(0);
}

int ispaused() {
	return paused;
}

int getoutputtime() { 
	return decode_pos_ms+(mod.outMod->GetOutputTime()-mod.outMod->GetWrittenTime()); 
}

void setoutputtime(int time_in_ms) { 
	seek_needed=time_in_ms;
}

void setvolume(int volume) {
	xvolume = volume;
	mod.outMod->SetVolume(volume);
}

void setpan(int pan) {
	xpan = pan;
	mod.outMod->SetPan(pan);
}

int infoDlg(char *fn, HWND hwnd)
{
	mp3info info;
	VBRTAGDATA vbr;
	int id;
		
	if (!getmp3info(fn,&info,&xediting_id3,&vbr)) return 0;
	
	xediting_id3fn = fn;

	if(sif.m_enable) {
		CSIFInfoDialog *cd = new CSIFInfoDialog(&sif);
		id = cd->DoModal();
		delete cd;
	} else {
		CInfoDialog *cd = new CInfoDialog();
		id = cd->DoModal();
		delete cd;
	}

	if (id == IDOK && strcmp(lastfn,fn) == 0) current_id3 = xediting_id3;

	return 0;
}

int getlength() { 
	return cur_mp3info.length * 1000;
}

void eq_set(int on, char data[10], int preamp) 
{ 
}

int play(char *fn) 
{ 
	int maxlatency;
	int thread_id;
	int use_proxy = 0;
	int bps = 16;
	static LPCTSTR proxy_bypass = "";
	static LPCTSTR Lversion = "Shibatch in_mpg123 " VERSIONSTRING;

	while(decoder_in_use) Sleep(30);
	
	if (strncmp(fn,"http://",7) == 0) {
		use_proxy = xed_proxy[0] != '\0';
		mod.is_seekable = 0;

		try {
			session = new CInternetSession(
				Lversion,1,
				use_proxy ? INTERNET_OPEN_TYPE_PROXY : INTERNET_OPEN_TYPE_DIRECT,
				xed_proxy,proxy_bypass,INTERNET_FLAG_DONT_CACHE);

			httpfile = session->OpenURL(fn,1,INTERNET_FLAG_RELOAD | INTERNET_FLAG_DONT_CACHE,
				"Accept: audio/mpeg, audio/x-mpegurl, */*\r");
		} catch (CInternetException* pEx) {
			httpfile = NULL;
		}

		if (httpfile == NULL) {
			MessageBox(mod.hMainWindow,"Connection failed","streaming error",0);
			delete session;
			session = NULL;
			return 1;
		}
		
		stream_buffer = (char *)realloc(stream_buffer,xstrbuflen*1024);
		strbuflen = xstrbuflen*1024;
		strbufp_e = strbufp_s = 0;

		killReceiveThread=0;
		receive_thandle = (HANDLE) CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) ReceiveThread,(void *) &killReceiveThread,0,(unsigned long *)&thread_id);
		SetThreadPriority(receive_thandle,THREAD_PRIORITY_HIGHEST);
		
		current_id3.tag[0] = '\0';
		
		if (!getmp3info2(&cur_mp3info) ||
			(maxlatency = mod.outMod->Open(cur_mp3info.freq,cur_mp3info.nch,bps, -1,-1)) < 0)
		{
			MessageBox(mod.hMainWindow,"Valid MP3 frame not found","streaming error",0);

			killReceiveThread=1;
			if (WaitForSingleObject(receive_thandle,INFINITE) == WAIT_TIMEOUT)
			{
				MessageBox(mod.hMainWindow,"error asking receive thread to die!\n","error killing receive thread",0);
				TerminateThread(receive_thandle,0);
			}
			CloseHandle(receive_thandle);
			receive_thandle = INVALID_HANDLE_VALUE;
			if (httpfile != NULL) {
				httpfile->Close();
				delete httpfile;
				httpfile = NULL;
			}

			if (session != NULL) {
				session->Close();
				delete session;
				session = NULL;
			}

			return 1;
		}
	} else {
		mod.is_seekable = 1;

		if (!getmp3info(fn,&cur_mp3info,&current_id3,&current_vbrtag)) return 1;

		input_file = CreateFile(fn,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
			OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
		if (input_file == INVALID_HANDLE_VALUE) return 1;

		file_length = cur_mp3info.nbytes;

		maxlatency = mod.outMod->Open(cur_mp3info.freq,cur_mp3info.nch,bps, -1,-1);
	
		if(maxlatency < 0) // error opening device
		{
			CloseHandle(input_file);
			input_file=INVALID_HANDLE_VALUE;
			return 1;
		}

		SetFilePointer(input_file,cur_mp3info.hpos,NULL,FILE_BEGIN);
	}

	strcpy(lastfn,fn);
	paused=0;
	decode_pos_ms=0;
	seek_needed=-1;

	mod.SetInfo(cur_mp3info.bitrate/1000,cur_mp3info.freq/1000,cur_mp3info.nch,1);

	// initialize vis stuff
	mod.SAVSAInit(maxlatency,cur_mp3info.freq);
	mod.VSASetInfo(cur_mp3info.freq,cur_mp3info.nch);

	// set the output plug-ins default volume
	mod.outMod->SetVolume(-666);
	
	killDecodeThread=0;
	decode_thandle = (HANDLE) CreateThread(NULL,0,(LPTHREAD_START_ROUTINE) DecodeThread,(void *) &killDecodeThread,0,(unsigned long *)&thread_id);
	SetThreadPriority(decode_thandle,THREAD_PRIORITY_HIGHEST);

	return 0; 
}

void stop() { 
	if (receive_thandle != INVALID_HANDLE_VALUE)
	{
#if 0
		killReceiveThread=1;
		if (WaitForSingleObject(receive_thandle,INFINITE) == WAIT_TIMEOUT)
		{
			MessageBox(mod.hMainWindow,"error asking receive thread to die!\n","error killing receive thread",0);
			TerminateThread(receive_thandle,0);
		}
#else
		killReceiveThread=1;
		while(!strbuf_eof) Sleep(100);
#endif
		CloseHandle(receive_thandle);
		receive_thandle = INVALID_HANDLE_VALUE;
	}
#if 0
	if (httpfile != NULL)
	{
		httpfile->Close();
		delete httpfile;
		httpfile = NULL;
	}
#endif
	if (session != NULL)
	{
		session->Close();
		delete session;
		session = NULL;
		httpfile = NULL;
	}

	if (decode_thandle != INVALID_HANDLE_VALUE)
	{
#if 1
		killDecodeThread=1;
		if (WaitForSingleObject(decode_thandle,INFINITE) == WAIT_TIMEOUT)
		{
			MessageBox(mod.hMainWindow,"error asking decode thread to die!\n","error killing decode thread",0);
			TerminateThread(decode_thandle,0);
		}
#else
		killDecodeThread=1;
		while(decoder_in_use) Sleep(200);
#endif
		CloseHandle(decode_thandle);
		decode_thandle = INVALID_HANDLE_VALUE;
	}
	if (input_file != INVALID_HANDLE_VALUE)
	{
		CloseHandle(input_file);
		input_file=INVALID_HANDLE_VALUE;
	}

	mod.outMod->Close();

	mod.SAVSADeInit();
}

int genre_last=147;
char *genre_list[]={
	"Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk",
	"Grunge", "Hip-Hop", "Jazz", "Metal", "New Age", "Oldies",
	"Other", "Pop", "R&B", "Rap", "Reggae", "Rock",
	"Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks",
	"Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk",
	"Fusion", "Trance", "Classical", "Instrumental", "Acid", "House",
	"Game", "Sound Clip", "Gospel", "Noise", "AlternRock", "Bass",
	"Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock",
	"Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk",
	"Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta",
	"Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret",
	"New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi",
	"Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical",
	"Rock & Roll", "Hard Rock", "Folk", "Folk/Rock", "National Folk", "Swing",
	"Fast-Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde",
	"Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band",
	"Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", "Chanson",
	"Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus",
	"Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba",
	"Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet",
	"Punk Rock", "Drum Solo", "A capella", "Euro-House", "Dance Hall",
	"Goa", "Drum & Bass", "Club House", "Hardcore", "Terror",
	"Indie", "BritPop", "NegerPunk", "Polsk Punk", "Beat",
	"Christian Gangsta", "Heavy Metal", "Black Metal", "Crossover", "Contemporary C",
	"Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "JPop",
	"SynthPop",
};

#define TITLEBUFLEN (MAX_PATH-10)

int gettitlefromsif(char *filename,char *title)
{
	char *p,*q,*r,*s;
	int remain = TITLEBUFLEN;

	q = title;

	for(p=xed_title;*p != '\0' && remain > 0;)
	{
		if (*p != '%') {
			*q++ = *p++;
			remain--;
			continue;
		}

		switch(*++p)
		{
		case '%':
			*q++ = '%';
			remain--;
			break;
		case '1':
			strncpy(q, (LPCTSTR)sif.m_artist, remain);
			remain -= sif.m_artist.GetLength();
			q += sif.m_artist.GetLength();
			break;
		case '2':
			strncpy(q, (LPCTSTR)sif.m_title, remain);
			remain -= sif.m_title.GetLength();
			q += sif.m_title.GetLength();
			break;
		case '3':
			strncpy(q, (LPCTSTR)sif.m_album, remain);
			remain -= sif.m_album.GetLength();
			q += sif.m_album.GetLength();
			break;
		case '4':
			strncpy(q, (LPCTSTR)sif.m_year, remain);
			remain -= sif.m_year.GetLength();
			q += sif.m_year.GetLength();
			break;
		case '5':
			strncpy(q, (LPCTSTR)sif.m_comment, remain);
			remain -= sif.m_comment.GetLength();
			q += sif.m_comment.GetLength();
			break;
		case '6':
			strncpy(q, (LPCTSTR)sif.m_genre, remain);
			remain -= sif.m_genre.GetLength();
			q += sif.m_genre.GetLength();
			break;
		case '7':
			r=s=filename+strlen(filename);
			while (*r != '\\' && r >= filename) r--;
			r++;
			while (*s != '.'  && s >= filename) s--;
			if (s < r) s = filename+strlen(filename);
			while(r < s && remain > 0) {
				*q++ = *r++;
				remain--;
			}
			break;
		case '8':
			s=filename+strlen(filename);
			while (*s != '\\' && s >= filename) s--;
			if (*s == '\\') s++;
			r = filename;
			while(r < s && remain > 0) {
				*q++ = *r++;
				remain--;
			}
			break;
		case '9':
			r=s=filename+strlen(filename);
			while (*r != '\\' && r >= filename) r--;
			while (*s != '.'  && s >= filename) s--;
			if (s < r) s = filename+strlen(filename);
			while(*s != '\0' && remain > 0) {
				*q++ = *s++;
				remain--;
			}
			break;
		default:
			if (remain >= 1) { *q++ = '%'; remain--; }
			if (remain >= 1) { *q++ = *p;  remain--; }
			break;
		}

		p++;
	}

	*q = '\0';
	
	return 1;
}

int gettitlefromid3(id3tag *tag,char *filename,char *title)
{
	char *p,*q,*r,*s,buf[31];
	int remain = TITLEBUFLEN;

	if((sif.m_file != "") && (sif.m_title != "")) {
		return gettitlefromsif(filename, title);
	}
	
	if (strncmp(tag->tag,"TAG",3) != 0) return 0;

	q = title;

	for(p=xed_title;*p != '\0' && remain > 0;)
	{
		if (*p != '%') {
			*q++ = *p++;
			remain--;
			continue;
		}

		switch(*++p)
		{
		case '%':
			*q++ = '%';
			remain--;
			break;
		case '1':
			strncpy(buf,tag->artist,30);
			buf[30] = '\0';
			for(r = buf;*r != '\0';r++) ;
			for(r--;r >= buf && *r == ' ';r--) ;
			*(r+1) = '\0';
			strncpy(q,buf,remain);
			remain -= strlen(buf);
			q += strlen(buf);
			break;
		case '2':
			strncpy(buf,tag->title,30);
			buf[30] = '\0';
			for(r = buf;*r != '\0';r++) ;
			for(r--;r >= buf && *r == ' ';r--) ;
			*(r+1) = '\0';
			strncpy(q,buf,remain);
			remain -= strlen(buf);
			q += strlen(buf);
			break;
		case '3':
			strncpy(buf,tag->album,30);
			buf[30] = '\0';
			for(r = buf;*r != '\0';r++) ;
			for(r--;r >= buf && *r == ' ';r--) ;
			*(r+1) = '\0';
			strncpy(q,buf,remain);
			remain -= strlen(buf);
			q += strlen(buf);
			break;
		case '4':
			strncpy(buf,tag->year,4);
			buf[4] = '\0';
			for(r = buf;*r != '\0';r++) ;
			for(r--;r >= buf && *r == ' ';r--) ;
			*(r+1) = '\0';
			strncpy(q,buf,remain);
			remain -= strlen(buf);
			q += strlen(buf);
			break;
		case '5':
			strncpy(buf,tag->comment,30);
			buf[30] = '\0';
			for(r = buf;*r != '\0';r++) ;
			for(r--;r >= buf && *r == ' ';r--) ;
			*(r+1) = '\0';
			strncpy(q,buf,remain);
			remain -= strlen(buf);
			q += strlen(buf);
			break;
		case '6':
			if (tag->genre > genre_last) {
				strncpy(q,"unknown",remain);
				remain -= 7;
				q += 7;
				break;
			}
			strncpy(q,genre_list[tag->genre],remain);
			remain -= strlen(genre_list[tag->genre]);
			q += strlen(genre_list[tag->genre]);
			break;
		case '7':
			r=s=filename+strlen(filename);
			while (*r != '\\' && r >= filename) r--;
			r++;
			while (*s != '.'  && s >= filename) s--;
			if (s < r) s = filename+strlen(filename);
			while(r < s && remain > 0) {
				*q++ = *r++;
				remain--;
			}
			break;
		case '8':
			s=filename+strlen(filename);
			while (*s != '\\' && s >= filename) s--;
			if (*s == '\\') s++;
			r = filename;
			while(r < s && remain > 0) {
				*q++ = *r++;
				remain--;
			}
			break;
		case '9':
			r=s=filename+strlen(filename);
			while (*r != '\\' && r >= filename) r--;
			while (*s != '.'  && s >= filename) s--;
			if (s < r) s = filename+strlen(filename);
			while(*s != '\0' && remain > 0) {
				*q++ = *s++;
				remain--;
			}
			break;
		default:
			if (remain >= 1) { *q++ = '%'; remain--; }
			if (remain >= 1) { *q++ = *p;  remain--; }
			break;
		}

		p++;
	}

	*q = '\0';
	
	return 1;
}

void getfileinfo(char *filename, char *title, int *length_in_ms)
{
	if (!filename || !*filename)
	{
		// currently playing file
		if (length_in_ms) *length_in_ms=cur_mp3info.length*1000;
		if (title) 
		{
			if (!gettitlefromid3(&current_id3,lastfn,title)) {
				char *p=lastfn+strlen(lastfn);
				while (*p != '\\' && p >= lastfn) p--;
				strncpy(title,++p,TITLEBUFLEN);
			}
		}
	}
	else
	{
		// some other file
		mp3info info;
		id3tag id3;
		VBRTAGDATA vbr;
		
		if (getmp3info(filename,&info,&id3,&vbr)) {
			if (length_in_ms) 
			{
				*length_in_ms = info.length*1000;
			}
			if (title) 
			{
				if (!gettitlefromid3(&id3,filename,title)) {
					char *p=filename+strlen(filename);
					while (*p != '\\' && p >= filename) p--;
					strncpy(title,++p,TITLEBUFLEN);
				}
			}
		} else {
			// not MP3 file
			if (length_in_ms) 
			{
				*length_in_ms = 0;
			}
			if (title) 
			{
				char *p=filename+strlen(filename);
				while (*p != '\\' && p >= filename) p--;
				strncpy(title,++p,TITLEBUFLEN);
			}
		}
	}
}

// Decoding thread

#define OBSIZE 16384
#define FBSIZE 512

static char obuf[OBSIZE];
static int bstart,bend;
static struct mpstr mp;
static int decoder_stat;

void postproc(char *buf,int size)
{
	int Bps = 2;

	if (!xch_reverse && !xch_invert && !xch_volume) return;
	
	if (cur_mp3info.nch == 2) {
		int i;
		int pl=127,pr=127;
		if (xpan > 0) pl = 127-xpan;
		if (xpan < 0) pr = 127+xpan;

		for(i=0;i<size/2/Bps;i++)
		{
			short *l = (short *)&buf[i*4],*r = (short *)&buf[i*4+2];

			if (xch_reverse) {
				short s;
				s = *l; *l = *r; *r = s;
			}
		
			if (xch_invert) {
				*l = *l == -32768 ? 32767 : -*l; *r = *r == -32768 ? 32767 : -*r;
			}

			if (xch_volume) {
				*l = xvolume*pl*(int)*l/(255*127);
				*r = xvolume*pr*(int)*r/(255*127);
			}
		}
	} else if (cur_mp3info.nch == 1) {
		int i;
		for(i=0;i<size/Bps;i++)
		{
			short *p = (short *)&buf[i*2];

			if (xch_invert) {
				*p = *p == -32768 ? 32767 : -*p;
			}

			if (xch_volume) {
				*p = xvolume*(int)*p/255;
			}
		}
	}
}

void preload_stream(void)
{
	for(;;)
	{
		Sleep(200);
		int l = strbufp_s > strbufp_e ? strbuflen+strbufp_e-strbufp_s : strbufp_e-strbufp_s;
		if (l > strbuflen*7/8 || strbuf_eof) break;
	}
}

int get_576_samples(char *out,int supZero,int flush)
{
	int at_eof = 0;
	int nch = cur_mp3info.nch;
	int Bps = 2;
	int ssize = 576*nch*Bps;

	if (flush) {
		ExitMP3(&mp);
		InitMP3(&mp);
		bstart = bend = 0;
		decoder_stat = MP3_ERR;
	}
	
	while (!at_eof && ssize > bend - bstart) {
		if (bstart != 0) {
			int i;
			for(i=0;i<bend-bstart;i++) obuf[i] = obuf[i+bstart];
			bend -= bstart;
			bstart = 0;
		}

		if (decoder_stat != MP3_OK) {
			char buf[FBSIZE];
			int len,size;

			if (cur_mp3info.isStream) {
				len = 0;

				if (strbufp_s > strbufp_e) {
					if (strbuflen-strbufp_s > FBSIZE) {
						memcpy(buf,stream_buffer+strbufp_s,FBSIZE);
						strbufp_s += FBSIZE;
						len = FBSIZE;
					} else {
						memcpy(buf,stream_buffer+strbufp_s,strbuflen-strbufp_s);
						len = strbuflen-strbufp_s;
						strbufp_s = 0;
					}
				}

				if (strbufp_s < strbufp_e) {
					if (strbufp_e-strbufp_s > FBSIZE-len) {
						memcpy(buf+len,stream_buffer+strbufp_s,FBSIZE-len);
						strbufp_s += FBSIZE-len;
						len = FBSIZE;
					} else {
						memcpy(buf+len,stream_buffer+strbufp_s,strbufp_e-strbufp_s);
						len += strbufp_e-strbufp_s;
						strbufp_s = strbufp_e;
					}
				}

				if (len == 0) preload_stream();

				at_eof = strbufp_e == strbufp_s && strbuf_eof;
				//if (at_eof) MessageBox(mod.hMainWindow,"EOF","get576samples",0);
			} else {
				ReadFile(input_file,buf,FBSIZE,(unsigned long *)&len,NULL);
				at_eof = len == 0;
			}

			size = 0;
			decoder_stat = decodeMP3(&mp,buf,len,obuf+bend,OBSIZE-bend,&size);
			postproc(obuf,size);
			bend += size;
		} else {
			int size=0;
			decoder_stat = decodeMP3(&mp,NULL,0,obuf+bend,OBSIZE-bend,&size);
			postproc(obuf,size);
			bend += size;
		}

		if (decoder_stat == MP3_ERR) {
			//MessageBox(NULL,errorstring,"Decoder error",MB_OK);
			return -1;
		}

		if (supZero) {
			int p,q,c;
			for(p=bstart;p<bend;p+=Bps*nch)
				for(c=0;c<nch;c++)
					for(q=0;q<Bps;q++)
						if (obuf[p+c*Bps+q] != 0) goto BreakSupLoop;
			BreakSupLoop:

			if (p < bend) {
				bstart = p;
				supZero = 0;
			} else {
				bend = bstart;
			}
		}
	}

	{
		int l,i;
		if (ssize < bend - bstart) l = ssize; else l = bend - bstart;
		for(i=0;i<l;i++) out[i] = obuf[bstart+i];

		bstart += l;
		return l;
	}
}

DWORD WINAPI __stdcall DecodeThread(void *b)
{
	int done=0;
	int supZero = xch_supzero;
	int isStream = cur_mp3info.isStream;

	decoder_in_use = 1;

	totalFramesize=0;
	nframe=0;
	
	InitMP3(&mp);
	decoder_stat = MP3_ERR;
	bstart = bend = 0;
	int Bps = 2;
	int flush = 0;

	if (isStream) preload_stream();
	
	while (! *((int *)b) ) 
	{
		if (seek_needed != -1)
		{
			int offs;

			if (cur_mp3info.hasVbrtag) {
				offs = SeekPoint(current_vbrtag.toc,cur_mp3info.nbytes,seek_needed/(cur_mp3info.length*10));
			} else {
				int framesize = totalFramesize/nframe;
				float frameDuration = 576.0*(cur_mp3info.lsf?1:2)/cur_mp3info.freq;
				//float length = cur_mp3info.nbytes * 8 / cur_mp3info.bitrate;
				float length = cur_mp3info.nbytes*frameDuration/framesize;

				offs = (float)cur_mp3info.nbytes * seek_needed / (length * 1000);
			}

			offs += cur_mp3info.hpos;
			decode_pos_ms = seek_needed;
			seek_needed=-1;
			done=0;
			mod.outMod->Flush(decode_pos_ms);
			flush = 1;

			unsigned long head,len,hpos;

			for(hpos=0;hpos<65536;hpos++)
			{
				SetFilePointer(input_file,offs+hpos,NULL,FILE_BEGIN);
				ReadFile(input_file,3+(char *)&head,1,&len,NULL);
				ReadFile(input_file,2+(char *)&head,1,&len,NULL);
				ReadFile(input_file,1+(char *)&head,1,&len,NULL);
				ReadFile(input_file,0+(char *)&head,1,&len,NULL);
				if (len == 0 || head_check2(head,&cur_mp3info)) break;
			}

			if (hpos == 65536 || len == 0) {
				done = 1;
			//break; // syncword not found
			}

			SetFilePointer(input_file,offs+hpos,NULL,FILE_BEGIN);
		}
		if (done)
		{
			// �f�R�[�h�I���C�o�b�t�@�̓��e�����ׂď������̂�҂��Ă���
			mod.outMod->CanWrite();
			if (!mod.outMod->IsPlaying())
			{
				ExitMP3(&mp);
				PostMessage(mod.hMainWindow,WM_WA_MPEG_EOF,0,0);
				decoder_in_use = 0;
				return 0;
			}
			Sleep(10);
		}
		else if (mod.outMod->CanWrite() >= ((576*cur_mp3info.nch*Bps)<<(mod.dsp_isactive()?1:0)))
		{	
			// �ʏ���
			int l;
			l=get_576_samples(sample_buffer,supZero,flush);
			supZero = 0;
			flush = 0;
			if (l == -1) {
				if (!isStream) {
					// errorneous frame found. try to resync.
					unsigned long head,len,hpos;
					unsigned long offs = SetFilePointer(input_file,0,NULL,FILE_CURRENT);

					for(hpos=0;hpos<65536;hpos++)
					{
						SetFilePointer(input_file,offs+hpos,NULL,FILE_BEGIN);
						ReadFile(input_file,3+(char *)&head,1,&len,NULL);
						ReadFile(input_file,2+(char *)&head,1,&len,NULL);
						ReadFile(input_file,1+(char *)&head,1,&len,NULL);
						ReadFile(input_file,0+(char *)&head,1,&len,NULL);
						if (len == 0 || head_check2(head,&cur_mp3info)) break;
					}

					if (hpos == 65536 || len == 0) {
						done = 1;
						//break; // syncword not found
					} else {
						SetFilePointer(input_file,offs+hpos,NULL,FILE_BEGIN);
						flush = 1;
					}
				} else {
					unsigned long head;
					int i;

					for(i=0;i<65536;i++)
					{
						while(!strbuf_eof && (strbufp_e+strbuflen-strbufp_s)%strbuflen < 4) Sleep(100);

						*(3+(char *)&head) = stream_buffer[(strbufp_s  )%strbuflen];
						*(2+(char *)&head) = stream_buffer[(strbufp_s+1)%strbuflen];
						*(1+(char *)&head) = stream_buffer[(strbufp_s+2)%strbuflen];
						*(0+(char *)&head) = stream_buffer[(strbufp_s+3)%strbuflen];

						if (strbuf_eof || head_check2(head,&cur_mp3info)) break;
						strbufp_s = (strbufp_s+1) % strbuflen;
					}

					if (i == 65536 || strbuf_eof) {
						done = 1;
					} else {
						flush = 1;
					}
				}
			} else if (!l)
			{
				done=1;
			}
			else
			{
				mod.SAAddPCMData((char *)sample_buffer,cur_mp3info.nch,Bps*8,decode_pos_ms);
				mod.VSAAddPCMData((char *)sample_buffer,cur_mp3info.nch,Bps*8,decode_pos_ms);
				decode_pos_ms+=(576*1000.0)/cur_mp3info.freq;
				if (mod.dsp_isactive()) l=mod.dsp_dosamples((short *)sample_buffer,l/cur_mp3info.nch/Bps,Bps*8,cur_mp3info.nch,cur_mp3info.freq)*(cur_mp3info.nch*Bps);
				mod.outMod->Write(sample_buffer,l);
			}
		}
		else
		{
			if (!cur_mp3info.hasVbrtag) {
				int framesize = totalFramesize/nframe;
				float frameDuration = 576.0*(cur_mp3info.lsf?1:2)/cur_mp3info.freq;
				//cur_mp3info.length = cur_mp3info.nbytes * 8 / cur_mp3info.bitrate;
				cur_mp3info.length = cur_mp3info.nbytes*frameDuration/framesize;
			}
			if (!xch_dispavg) {
				static int lastBitrate;
				if (lastBitrate != currentBitrate) {
					mod.SetInfo(currentBitrate,-1,-1,-1);
					lastBitrate = currentBitrate;
				}
			}
			Sleep(20);
		}
	}
	ExitMP3(&mp);
	decoder_in_use = 0;
	return 0;
}

#define READUNIT 1024

DWORD WINAPI __stdcall ReceiveThread(void *b)
{
	strbuf_eof = 0;
	CFileException fe;

	while (! *((int *)b) ) 
	{
		if (strbufp_e == strbuflen && strbufp_s != 0) strbufp_e = 0;

		if (strbufp_e != strbuflen && strbufp_e >= strbufp_s) {
			UINT len;
			int len2 = strbuflen-strbufp_e < READUNIT ? strbuflen-strbufp_e : READUNIT;
			
			len = httpfile->Read(stream_buffer+strbufp_e,len2);

			strbufp_e += len;

			if (len == 0) break;
		} else if (!(strbufp_e == strbuflen-1 && strbufp_s == strbuflen) && strbufp_e < strbufp_s-1) {
			UINT len;
			int len2 = strbufp_s-strbufp_e-1 < READUNIT ? strbufp_s-strbufp_e-1 : READUNIT;

			len = httpfile->Read(stream_buffer+strbufp_e,len2);

			strbufp_e += len;

			if (len == 0) break;
		} else {
			Sleep(200);
		}
	}

	strbuf_eof = 1;
	return 0;
}

#if 0
void main(void)
{
}
#endif
#endif
