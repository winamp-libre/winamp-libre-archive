//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by in_mpg123d.rc
//
#define IDD_DIALOG1                     129
#define IDD_DIALOG2                     130
#define IDD_SIF_DIALOG                  133
#define IDC_CH_SUPZERO                  1000
#define IDC_CH_24BIT                    1001
#define IDC_CH_VOLUME                   1002
#define ID_CH_REV                       1003
#define IDC_CH_INVERT                   1004
#define IDC_ED_TITLE                    1005
#define IDC_CH_ENABLE                   1006
#define IDC_BUT_REMOVE                  1007
#define IDC_ED_FILENAME                 1008
#define IDC_ED_ARTIST                   1010
#define IDC_ED_ALBUM                    1011
#define IDC_ED_YEAR                     1012
#define IDC_ED_COMMENT                  1013
#define IDC_CB_GENRE                    1014
#define IDC_CH_FORCE                    1015
#define IDC_CH_DISPAVG                  1016
#define IDC_SIF_FILENAME                1018
#define IDC_SIF_TITLE                   1019
#define IDC_SIF_ARTIST                  1020
#define IDC_SIF_ALBUM                   1021
#define IDC_SIF_YEAR                    1022
#define IDC_SIF_GENRE                   1023
#define IDC_SIF_COMMENT                 1024
#define IDC_SIF_COPYRIGHT               1025
#define IDC_ED_PROXY                    1025
#define IDC_SIF_ENGINEER                1026
#define IDC_ED_STRBUF                   1026
#define IDC_SIF_SOURCE                  1027
#define IDC_SIF_SOFTWARE                1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
