// ICYInfo.h: CICYInfo �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ICYINFO_H__06BA98E3_E1C7_478F_B716_BF0311AF2FFA__INCLUDED_)
#define AFX_ICYINFO_H__06BA98E3_E1C7_478F_B716_BF0311AF2FFA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class
CICYInfo : public CObject
{
public:
	int		m_udpport;
	CString	m_title;
	CString	m_name;
	CString	m_server;

	CICYInfo(void);
	~CICYInfo(void);

	void	Init(void);
	void	DeleteHeader(void);
	void	GetIcyInfoFromHttpHeader(CIn_mpg123dHttpFile* httpfile);
	UINT	GetICYInfo(char* lpBuff, char* Buff, UINT Size, bool* Error, CString* ErrorMsg);

private:
	char*	m_header;
	UINT	m_received;
	int		m_metaint;
	int		m_pub;
	int		m_br;
	CString	m_genre;
	CString	m_url;

	inline UINT	ParseIcyInfo(char* Src, UINT *Size);
	inline void	ParseIcyTag(char* Src, UINT Size);
};

#endif // !defined(AFX_ICYINFO_H__06BA98E3_E1C7_478F_B716_BF0311AF2FFA__INCLUDED_)
