
//
//  ID3v1�^�O���擾����
//
//  Written by Otachan
//  http://otachan.com/
//

#include "stdafx.h"

#include "wa_ipc.h"

#include "CommonFunc.h"

#include "in_mpg123.h"

#include "TagInfo.h"

extern const char*	GenreList[];

bool
Tag::GetTitleFromID3v1(_TagInfo* TagInfo)
{
	::SetLastError(NO_ERROR);

	HANDLE	hF = ::CreateFile(
							TagInfo->FileName,
							GENERIC_READ,
							FILE_SHARE_READ,
							NULL,
							OPEN_EXISTING,
							FILE_FLAG_RANDOM_ACCESS,
							NULL);

	if(::GetLastError() != NO_ERROR) return false;

	DWORD	FileSize = ::GetFileSize(hF, NULL);

	if(FileSize < sizeof(id3tag)) {
		::CloseHandle(hF);
		return false;
	}

	id3tag	ID3tag;
	DWORD	ReadByte;

	memset(ID3tag.tag, '\0', 3);
	::SetFilePointer(hF, FileSize - sizeof ID3tag, NULL, FILE_BEGIN);
	::ReadFile(hF, &ID3tag, sizeof ID3tag, &ReadByte, NULL);

	::CloseHandle(hF);

	if((*ID3tag.tag != 'T') || (*(ID3tag.tag + 1) != 'A') || (*(ID3tag.tag + 2) != 'G')) return false;

	memcpy(TagInfo->Title, ID3tag.title, 30);
	EraseSpace(TagInfo->Title, 30);

	if(ID3tag.genre < MAX_GENRE) {
		strcpy_s(TagInfo->Genre, sizeof TagInfo->Genre, GenreList[ID3tag.genre]);
	} else {
		*TagInfo->Genre = '\0';
	}

	memcpy(TagInfo->Year, ID3tag.year, 4);
	EraseSpace(TagInfo->Year, 4);

	memcpy(TagInfo->Artist, ID3tag.artist, 30);
	EraseSpace(TagInfo->Artist, 30);

	memcpy(TagInfo->Album, ID3tag.album, 30);
	EraseSpace(TagInfo->Album, 30);

	int		CommentLen;

	if(ID3tag.comment[28] == '\0') {
		const int	Track = static_cast<unsigned char>(ID3tag.comment[29]);

		if(Track) {
			_itoa_s(Track, TagInfo->Track, sizeof TagInfo->Track, 10);
		} else {
			*TagInfo->Track = '\0';
		}

		CommentLen = 28;
	} else {
		*TagInfo->Track = '\0';
		CommentLen = 30;
	}

	memcpy(TagInfo->Comment, ID3tag.comment, CommentLen);
	EraseSpace(TagInfo->Comment, CommentLen);

	*TagInfo->Composer = '\0';
	*TagInfo->OrgArtist = '\0';
	*TagInfo->Copyright = '\0';
	*TagInfo->Encoder = '\0';

	return true;
}

