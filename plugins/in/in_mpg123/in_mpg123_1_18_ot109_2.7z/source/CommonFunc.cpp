
//
//  �ėp�֐�
//
//  Written by Otachan
//  http://otachan.com/
//

#define	STRICT

#include <windows.h>
#include <mbctype.h>

#include "CommonFunc.h"

void
CutPathFileName(
			const char* FullFileName,
			char* FileNamePath,
			const size_t FileNamePathSize,
			char* FileName,
			const size_t FileNameSize)
{
	unsigned char	Str;
	size_t	cnt = 0;
	size_t	BackSlashCnt = -1;
	bool	Kanji = false;

	while((Str = *(FullFileName + cnt)) != '\0') {
		if(!Kanji) {
			if(_ismbblead(Str)) {
				Kanji = true;
			} else {
				if((Str == '\\') || (Str == '/')) {
					BackSlashCnt = cnt;
				}
			}
		} else {
			Kanji = false;
		}
		cnt++;
	}

	BackSlashCnt++;

	if(FileNamePath) {
		const size_t	CopySize = Min(BackSlashCnt, FileNamePathSize - 1);

		memcpy(FileNamePath, FullFileName, CopySize);
		*(FileNamePath + CopySize) = '\0';
	}

	if(FileName) {
		strcpy_s(FileName, FileNameSize, FullFileName + BackSlashCnt);
	}
}

void
CutFileNameExt(
			const char* FullFileName,
			char* FileName,
			const size_t FileNameSize,
			char* FileExt,
			const size_t FileExtSize)
{
	char	Str = '\0';
	size_t	ExtCnt;
	const size_t	FullFileNameLen = strlen(FullFileName);

	if(FullFileNameLen) {
		for(ExtCnt = FullFileNameLen - 1; ; ExtCnt--) {
			Str = *(FullFileName + ExtCnt);
			if((Str == '.') || (Str == '\\')  || (Str == '/') || (ExtCnt == 0)) break;
		}
	}

	if(Str != '.') ExtCnt = FullFileNameLen;

	if(FileName) {
		const size_t	CopySize = Min(ExtCnt, FileNameSize - 1);

		memcpy(FileName, FullFileName, CopySize);
		*(FileName + CopySize) = '\0';
	}

	if(FileExt) {
		if(Str == '.') {
			strcpy_s(FileExt, FileExtSize, FullFileName + ExtCnt + 1);
		} else {
			*FileExt = '\0';
		}
	}
}

char*
KanjiStrncpy(char* OutBuff, const char* InBuff, const int Len)
{
	char*	RetOutBuff = OutBuff;
	unsigned char	Str;
	bool	Kanji = false;

	for(int cnt = 0; (cnt < Len) && ((Str = *(InBuff + cnt)) != '\0'); cnt++) {
		if(!Kanji) {
			if(_ismbblead(Str)) {
				Kanji = true;
			}
		} else {
			Kanji = false;
		}

		*OutBuff++ = Str;
	}

	*(OutBuff - (Kanji ? 1 : 0)) = '\0';

	return RetOutBuff;
}

char*
WideToMultiStrcpy(
				char* OutBuff,
				const UINT OutBuffSize,
				WCHAR* InBuff,
				UINT InBuffSize,
				const bool UseBOM,
				bool BigEndian)
{
	if(UseBOM && (InBuffSize >= 1)) {
		if(*InBuff == L'\ufffe') {			// �r�b�O�G���f�B�A��
			InBuff++;
			InBuffSize--;
			BigEndian = true;
		} else if(*InBuff == L'\ufeff') {	// ���g���G���f�B�A��
			InBuff++;
			InBuffSize--;
			BigEndian = false;
		}
	}

	WCHAR*	WorkBuff;

	if(BigEndian) {
		WorkBuff = new WCHAR[InBuffSize];

		unsigned short*	InBuffPnt = reinterpret_cast<unsigned short*>(InBuff);
		unsigned short*	WorkBuffPnt = reinterpret_cast<unsigned short*>(WorkBuff);

		for(UINT Idx = 0; Idx < InBuffSize; Idx++) {
			*WorkBuffPnt++ = BSwap16(*InBuffPnt++);
		}
	} else {
		WorkBuff = InBuff;
	}

	Strcpy(OutBuff, OutBuffSize, WorkBuff, InBuffSize);

	if(BigEndian) delete[] WorkBuff;

	return OutBuff;
}

char*
UTF8ToMultiStrcpy(char* OutBuff, const UINT OutBuffSize, const char* InBuff, const int InBuffSize)
{
	const int	WorkBuffSize = UTF8Strcpy(NULL, 0, InBuff, InBuffSize) + 1;

	if(WorkBuffSize > 1) {
		WCHAR*	WorkBuff = new WCHAR[WorkBuffSize];

		UTF8Strcpy(WorkBuff, WorkBuffSize, InBuff, InBuffSize);
		Strcpy(OutBuff, OutBuffSize, WorkBuff);

		delete[] WorkBuff;
	} else {
		*OutBuff = '\0';
	}

	return OutBuff;
}

int
KanjiStrChr(const char* InBuff, char Chr1)
{
	unsigned char	Str;
	int		cnt = 0;
	bool	Kanji = false;

	while((Str = *(InBuff + cnt)) != '\0') {
		if(!Kanji) {
			if(_ismbblead(Str)) {
				Kanji = true;
			} else {
				if(Str == static_cast<unsigned char>(Chr1)) break;
			}
		} else {
			Kanji = false;
		}

		cnt++;
	}

	if((Str == '\0') && (Chr1 != '\0')) cnt = -1;

	return cnt;
}

// �����񒆁A���̗]���ȃX�y�[�X����菜��

void
EraseSpace(char* InBuff, int Len)
{
	if(Len == -1) Len = strlen(InBuff);

	int		Idx;

	for(Idx = Len - 1; Idx >= 0; Idx--) {
		char*	InBuffIdx = InBuff + Idx;

		if((*InBuffIdx != 0x20) && (*InBuffIdx != '\0')) break;
	}

	if(Idx < 0) {
		*InBuff = '\0';
		return;
	}

	bool	Kanji = false;

	for(int KanjiIdx = 0; KanjiIdx <= Idx; KanjiIdx++) {
		if(!Kanji) {
			if(_ismbblead(*(InBuff + KanjiIdx))) Kanji = true;
		} else {
			Kanji = false;
		}
	}

	if(Kanji) {
		if(Idx < (Len - 1)) Idx++;
	}

	// ������̍Ō��CR+LF����菜��

	bool	CrLf;

	if(Idx >= 1) {
		if((*(InBuff + Idx - 1) == 0x0d) && (*(InBuff + Idx) == 0x0a)) {
			CrLf = true;
		} else {
			CrLf = false;
		}
	} else {
		CrLf = false;
	}

	if(CrLf) {
		*(InBuff + Idx - 1) = '\0';
		if(Idx == 1) return;
	} else {
		*(InBuff + Idx + 1) = '\0';
	}
}

void
FormatItoa(const int Value, char* RetBuff, const size_t RetBuffSize, const int Len, const char c)
{
	char	Work[SIZE_ITOA10];

	_itoa_s(Value, Work, sizeof Work, 10);

	const int	WorkLen = strlen(Work);
	const int	CopyOffset = Len - WorkLen;

	if(CopyOffset >= 0) {
		if(CopyOffset) memset(RetBuff, c, CopyOffset);
		strcpy_s(RetBuff + CopyOffset, RetBuffSize - CopyOffset, Work);
	} else {
		Strncpy(RetBuff, Work + WorkLen - Len, Len);
	}
}

