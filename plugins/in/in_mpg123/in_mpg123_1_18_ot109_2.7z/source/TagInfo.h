
#define	MAX_FORMATTEXT	512
#define	MAX_MUSICTEXT	512

#define	MAX_GENRE		148

class
Tag
{
public:
	struct
	_TagInfo
	{
		int		Length;
		char	FileName[MAX_PATHLEN];
		char	Title[MAX_MUSICTEXT];
		char	Artist[MAX_MUSICTEXT];
		char	Album[MAX_MUSICTEXT];
		char	Year[MAX_MUSICTEXT];
		char	Comment[MAX_MUSICTEXT];
		char	Genre[MAX_MUSICTEXT];
		char	Track[MAX_MUSICTEXT];
		char	Composer[MAX_MUSICTEXT];
		char	OrgArtist[MAX_MUSICTEXT];
		char	Copyright[MAX_MUSICTEXT];
		char	Encoder[MAX_MUSICTEXT];
	};
	struct
	_ReplayGainInfo
	{
		bool	ValidTrackGain;
		bool	ValidTrackPeak;
		bool	ValidAlbumGain;
		bool	ValidAlbumPeak;
		double	TrackGain;
		double	TrackPeak;
		double	AlbumGain;
		double	AlbumPeak;
	};
	enum
	{
		REPLAYGAIN_NONE,
		REPLAYGAIN_TRACK_GAIN,
		REPLAYGAIN_TRACK_PEAK,
		REPLAYGAIN_ALBUM_GAIN,
		REPLAYGAIN_ALBUM_PEAK,
	};

	Tag(void);
	~Tag(void);

	void	FlushCache(void);
	bool	Get(const char* FileName, const int TagPriority, const char* Format, char* Title);
	bool	GetReplayGainInfo(
							const char* FileName,
							const int TagPriority,
							const UINT ReplayGainTag,
							_ReplayGainInfo* Info);
	int		GetExtendedFileInfo(extendedFileInfoStruct* ExtendedFileInfo, const int TagPriority);

private:
	CRITICAL_SECTION	CriticalSection;
	_TagInfo	Cache;
	DWORD	GetTagTime;

	bool	GetTitle(const int TagPriority, _TagInfo* TagInfo);
	bool	GetTitleFromID3v2(
							_TagInfo* TagInfo,
							_ReplayGainInfo* ReplayGainInfo = NULL,
							const char* FileName = NULL);
	bool	GetTitleFromAPE(
						_TagInfo* TagInfo,
						_ReplayGainInfo* ReplayGainInfo = NULL,
						const char* FileName = NULL);
	bool	GetTitleFromID3v1(_TagInfo* TagInfo);
	void	StoreReplayGainInfo(const int ReplayGainFieldName, char* Buff, _ReplayGainInfo* Info);
	void	DoFormat(const _TagInfo* Info, const char* Format, char* Title, const size_t TitleSize);
};

#include "APEInfo.h"
#include "ID3v1Info.h"

