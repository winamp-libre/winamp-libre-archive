
#include "stdafx.h"
#include <MMSystem.h>
//#include <mbctype.h>
//#include <mbstring.h>

#include "wa_ipc.h"

#include "CommonFunc.h"

#include "in_mpg123.h"

#include "TagInfo.h"
#include "VbrTag.h"

bool	getmp3info(bool Decode, char* fn, mp3info* info, VBRTAGDATA* vbr_tag);

const char*	GenreList[MAX_GENRE] =
{
	"Blues", "Classic Rock", "Country", "Dance", "Disco",
	"Funk", "Grunge", "Hip-Hop", "Jazz", "Metal",
	"New Age", "Oldies", "Other", "Pop", "R&B",
	"Rap", "Reggae", "Rock", "Techno", "Industrial",
	"Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack",
	"Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk",
	"Fusion", "Trance", "Classical", "Instrumental", "Acid",
	"House", "Game", "Sound Clip", "Gospel", "Noise",
	"AlternRock", "Bass", "Soul", "Punk", "Space",
	"Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic",
	"Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance",
	"Dream", "Southern Rock", "Comedy", "Cult", "Gangsta",
	"Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American",
	"Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes",
	"Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz",
	"Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock",
	"Folk", "Folk/Rock", "National Folk", "Swing", "Fast-Fusion",
	"Bebob", "Latin", "Revival", "Celtic", "Bluegrass",
	"Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock",
	"Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic",
	"Humour", "Speech", "Chanson", "Opera", "Chamber Music",
	"Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove",
	"Satire", "Slow Jam", "Club", "Tango", "Samba",
	"Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle",
	"Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House",
	"Dance Hall", "Goa", "Drum & Bass", "Club House", "Hardcore",
	"Terror", "Indie", "BritPop", "NegerPunk", "Polsk Punk",
	"Beat", "Christian Gangsta", "Heavy Metal", "Black Metal", "Crossover",
	"Contemporary C", "Christian Rock", "Merengue", "Salsa", "Thrash Metal",
	"Anime", "JPop", "SynthPop",
};

Tag::Tag(void)
{
	::InitializeCriticalSection(&CriticalSection);

	FlushCache();
}

Tag::~Tag(void)
{
	::DeleteCriticalSection(&CriticalSection);
}

void
Tag::FlushCache(void)
{
	::EnterCriticalSection(&CriticalSection);

	*Cache.FileName = '\0';
	GetTagTime = 0;

	::LeaveCriticalSection(&CriticalSection);
}

bool
Tag::Get(const char* FileName, const int TagPriority, const char* Format, char* Title)
{
	bool	RetCode;
	_TagInfo	Info;

	strcpy_s(Info.FileName, sizeof Info.FileName, FileName);

	if(RetCode = GetTitle(TagPriority, &Info)) DoFormat(&Info, Format, Title, MAX_PATH);

	return RetCode;
}

bool
Tag::GetReplayGainInfo(
					const char* FileName,
					const int TagPriority,
					const UINT ReplayGainTag,
					_ReplayGainInfo* Info)
{
	bool	RetCode;

	switch(TagPriority) {
	case 0:
	case 1:
	case 4:
		RetCode =	((ReplayGainTag & REPLAYGAIN_TAG_ID3V2) ?
						GetTitleFromID3v2(NULL, Info, FileName) : false) ||
					((ReplayGainTag & REPLAYGAIN_TAG_APE) ?
						GetTitleFromAPE(NULL, Info, FileName) : false);
		break;
	case 2:
	case 3:
	case 5:
		RetCode =	((ReplayGainTag & REPLAYGAIN_TAG_APE) ?
						GetTitleFromAPE(NULL, Info, FileName) : false) ||
					((ReplayGainTag & REPLAYGAIN_TAG_ID3V2) ?
						GetTitleFromID3v2(NULL, Info, FileName) : false);
		break;
	}

	return RetCode;
}

int
Tag::GetExtendedFileInfo(extendedFileInfoStruct* ExtendedFileInfo, const int TagPriority)
{
	::EnterCriticalSection(&CriticalSection);

	bool	FindTag = *ExtendedFileInfo->filename &&
						(strcmp(ExtendedFileInfo->filename, Cache.FileName) == 0) &&
						((::timeGetTime() - GetTagTime) <= 2000);

	if(FindTag) {
		GetTagTime = ::timeGetTime();
	} else {
		mp3info	info;
		VBRTAGDATA	vbr_tag;

		if(memcmp(ExtendedFileInfo->filename, "http://", 7) &&
				memcmp(ExtendedFileInfo->filename, "https://", 8) &&
				getmp3info(false, ExtendedFileInfo->filename, &info, &vbr_tag)) {
			char	BackFileName[MAX_PATHLEN];

			strcpy_s(BackFileName, sizeof BackFileName, Cache.FileName);
			strcpy_s(Cache.FileName, sizeof Cache.FileName, ExtendedFileInfo->filename);

			if(FindTag = GetTitle(TagPriority, &Cache)) {
				Cache.Length = info.length;
				GetTagTime = ::timeGetTime();
			} else {
				strcpy_s(Cache.FileName, sizeof Cache.FileName, BackFileName);
			}
		}
	}

	int		RetCode;

	if(FindTag) {
		char	Buff[16];
		char*	RetBuff;
		const char*	MetaData = ExtendedFileInfo->metadata;

		if(_stricmp(MetaData, "length") == 0) {
			_itoa_s(Cache.Length, Buff, sizeof Buff, 10);
			RetBuff = Buff;
			RetCode = 1;
		} else if(_stricmp(MetaData, "title") == 0) {
			RetBuff = Cache.Title;
			RetCode = 1;
		} else if(_stricmp(MetaData, "artist") == 0) {
			RetBuff = Cache.Artist;
			RetCode = 1;
		} else if(_stricmp(MetaData, "comment") == 0) {
			RetBuff = Cache.Comment;
			RetCode = 1;
		} else if(_stricmp(MetaData, "album") == 0) {
			RetBuff = Cache.Album;
			RetCode = 1;
		} else if(_stricmp(MetaData, "year") == 0) {
			RetBuff = Cache.Year;
			RetCode = 1;
		} else if(_stricmp(MetaData, "genre") == 0) {
			RetBuff = Cache.Genre;
			RetCode = 1;
		} else if(_stricmp(MetaData, "track") == 0) {
			RetBuff = Cache.Track;
			RetCode = 1;
		} else {
			RetCode = 0;
		}

		if(RetCode && ExtendedFileInfo->retlen) {
			KanjiStrncpy(ExtendedFileInfo->ret, RetBuff, ExtendedFileInfo->retlen - 1);
		}
	} else {
		RetCode = 0;
	}

	::LeaveCriticalSection(&CriticalSection);

	return RetCode;
}

bool
Tag::GetTitle(const int TagPriority, _TagInfo* Info)
{
	bool	RetCode;

	switch(TagPriority) {
	case 0:
		RetCode = GetTitleFromID3v2(Info) || GetTitleFromAPE(Info) || GetTitleFromID3v1(Info);
		break;
	case 1:
		RetCode = GetTitleFromID3v2(Info) || GetTitleFromID3v1(Info) || GetTitleFromAPE(Info);
		break;
	case 2:
		RetCode = GetTitleFromAPE(Info) || GetTitleFromID3v2(Info) || GetTitleFromID3v1(Info);
		break;
	case 3:
		RetCode = GetTitleFromAPE(Info) || GetTitleFromID3v1(Info) || GetTitleFromID3v2(Info);
		break;
	case 4:
		RetCode = GetTitleFromID3v1(Info) || GetTitleFromID3v2(Info) || GetTitleFromAPE(Info);
		break;
	case 5:
		RetCode = GetTitleFromID3v1(Info) || GetTitleFromAPE(Info) || GetTitleFromID3v2(Info);
		break;
	}

	return RetCode;
}

void
Tag::StoreReplayGainInfo(const int ReplayGainFieldName, char* Buff, _ReplayGainInfo* Info)
{
	if((ReplayGainFieldName == REPLAYGAIN_TRACK_GAIN) ||
			(ReplayGainFieldName == REPLAYGAIN_ALBUM_GAIN)) {
		char*	dB = strstr(Buff, " dB");

		if(dB) *dB = '\0';
	}

	const double	GainPeak = atof(Buff);

	switch(ReplayGainFieldName) {
	case REPLAYGAIN_TRACK_GAIN:
		Info->ValidTrackGain = true;
		Info->TrackGain = GainPeak;
		break;
	case REPLAYGAIN_TRACK_PEAK:
		Info->ValidTrackPeak = true;
		Info->TrackPeak = GainPeak;
		break;
	case REPLAYGAIN_ALBUM_GAIN:
		Info->ValidAlbumGain = true;
		Info->AlbumGain = GainPeak;
		break;
	case REPLAYGAIN_ALBUM_PEAK:
		Info->ValidAlbumPeak = true;
		Info->AlbumPeak = GainPeak;
		break;
	}
}

void
Tag::DoFormat(const _TagInfo* Info, const char* Format, char* Title, const size_t TitleSize)
{
	char*	MaxTitle = Title + TitleSize;
	char	Str;
	const int	MaxBlock = 8;
	int		BlockIdx = -1;
	char*	Block[MaxBlock];
	size_t	MaxReplaceSize[MaxBlock];

	for(; (Str = *Format) != '\0'; Format++) {
		if(Str == '[') {
			if(++BlockIdx == MaxBlock) break;
			Block[BlockIdx] = Title;
			MaxReplaceSize[BlockIdx] = 0;
			continue;
		} else if(Str == ']') {
			if(BlockIdx == -1) break;
			if(MaxReplaceSize[BlockIdx] == 0) Title = Block[BlockIdx];
			BlockIdx--;
			continue;
		} else if(Str == '%') {
			const char*	CommandPnt = Format + 1;

			if(*CommandPnt == '%') {
				Format++;
				if(Title < MaxTitle) *Title++ = '%';
			} else if(*CommandPnt == '[') {
				Format++;
				if(Title < MaxTitle) *Title++ = '[';
			} else if(*CommandPnt == ']') {
				Format++;
				if(Title < MaxTitle) *Title++ = ']';
			} else {
				const int	CommandLen = KanjiStrChr(CommandPnt, '%');

				if(CommandLen == -1) break;

				char	Command[MAX_FORMATTEXT];

				memcpy(Command, CommandPnt, CommandLen);
				*(Command + CommandLen) = '\0';

				Format += 1 + CommandLen;

				const size_t	TitleRemainSize = MaxTitle - Title;
				errno_t	Error;

				if(_stricmp(Command, "title") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Title);
				} else if(_stricmp(Command, "artist") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Artist);
				} else if(_stricmp(Command, "album") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Album);
				} else if(_stricmp(Command, "year") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Year);
				} else if(_stricmp(Command, "comment") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Comment);
				} else if(_stricmp(Command, "genre") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Genre);
				} else if(_stricmp(Command, "filename") == 0) {
					if(Title < MaxTitle) {
						char	Name[MAX_PATHLEN];

						CutPathFileName(Info->FileName, NULL, 0, Name, sizeof Name);
						*Title = '\0';
						CutFileNameExt(Name, Title, TitleRemainSize);
						Error = 0;
					} else {
						Error = 1;
					}
				} else if(_stricmp(Command, "filepath") == 0) {
					if(Title < MaxTitle) {
						*Title = '\0';
						CutPathFileName(Info->FileName, Title, TitleRemainSize);
						Error = 0;
					} else {
						Error = 1;
					}
				} else if(_stricmp(Command, "fileext") == 0) {
					if(Title < MaxTitle) {
						*Title = '\0';
						CutFileNameExt(Info->FileName, NULL, 0, Title, TitleRemainSize);
						Error = 0;
					} else {
						Error = 1;
					}
				} else if(_stricmp(Command, "track") == 0) {
					if(Title < MaxTitle) {
						*Title = '\0';
						if(*Info->Track) FormatItoa(atoi(Info->Track), Title, TitleRemainSize, 2, '0');
						Error = 0;
					} else {
						Error = 1;
					}
				} else if(_stricmp(Command, "composer") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Composer);
				} else if(_stricmp(Command, "origartist") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->OrgArtist);
				} else if(_stricmp(Command, "copyright") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Copyright);
				} else if(_stricmp(Command, "encoder") == 0) {
					Error = strcpy_s(Title, TitleRemainSize, Info->Encoder);
				} else {
					Error = 1;
				}

				if(Error == 0) {
					const size_t	ReplaceSize = strlen(Title);

					Title += ReplaceSize;

					for(int Idx = 0; Idx <= BlockIdx; Idx++) {
						MaxReplaceSize[Idx] = Max(ReplaceSize, MaxReplaceSize[Idx]);
					}
				}
			}

			continue;
		}

		if(Title < MaxTitle) *Title++ = Str;
	}

	if(Title < MaxTitle) {
		*Title = '\0';
	} else {
		*(MaxTitle - 1) = '\0';
	}
}

