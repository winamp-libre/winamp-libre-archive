// In_mpg123dParam.cpp: CIn_mpg123dParam �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "CommonFunc.h"

#include "in_mpg123.h"

#include "HttpFile.h"
#include "ICYInfo.h"

#include "Param.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CIn_mpg123dParam::CIn_mpg123dParam()
{
	// Initialize members

	m_nStartPage					= 0;

	m_bEnable						= true;
	m_nDecodeThreadPriority			= 2 /* THREAD_PRIORITY_HIGHEST */;
	m_nOutputBps					= 16;
	m_bSupZero						= false;
	m_bDispAvg						= false;
	m_bAltVolume					= false;
	m_bReverseLR					= false;
	m_bReversePhase					= false;
	m_bFullBuffering				= false;

	m_nVolume						= 255;
	m_nPan							= 0;

	m_bReplayGainEnable				= false;
	m_nReplayGainMode				= 0;
	m_nReplayGainTag				= REPLAYGAIN_TAG_INIT;
	m_nReplayGainPreAmpWithRG		= 0;
	m_nReplayGainPreAmpWithoutRG	= 0;
	m_bReplayGainHardLimit			= true;

	m_bEnableStreaming				= false;
	m_nReceiveThreadPriority		= 2;
	m_nBufferLength					= 256;
	m_bProxy						= false;
	m_strProxy						= "";
	m_bSaveStream					= false;
	m_strSaveStream					= "";
	m_bTitleStreaming				= true;
	m_bTitleStreamingDecode			= true;
	m_bTitleStreamingUDP			= false;
	m_strTitleStreamingFormat		= "%1 (%2)";

	m_nTagPriority					= 0;
	m_strID3Format					= "%1 - %2";
	m_strSIFFormat					= "%IART - %INAM";
}

CIn_mpg123dParam::~CIn_mpg123dParam()
{
	WriteProfile();
}

void CIn_mpg123dParam::GetIniFn(HMODULE hDllInstance)
{
	char	FileName[MAX_PATHLEN];

	::GetModuleFileName(hDllInstance, FileName, sizeof FileName);
	CutPathFileName(FileName, ini_file, NULL);
	strcat_s(ini_file, sizeof ini_file, "plugin.ini");
}

void CIn_mpg123dParam::GetProfile(void)
{

	char buf[1024];
	static const char szAppName[] = "Shibatch mpg123";

	m_bEnable               = ::GetPrivateProfileInt(szAppName, "Enable",          1, ini_file) != 0;
	m_nDecodeThreadPriority = ::GetPrivateProfileInt(szAppName, "DecodePriority",  2, ini_file);
	m_nOutputBps            = ::GetPrivateProfileInt(szAppName, "OutputFormat",   16, ini_file);
	m_bFullBuffering        = ::GetPrivateProfileInt(szAppName, "FullBuffering",   0, ini_file) != 0;
	m_bSupZero              = ::GetPrivateProfileInt(szAppName, "SupZero",         0, ini_file) != 0;
	m_bReverseLR            = ::GetPrivateProfileInt(szAppName, "ReverseLR",       0, ini_file) != 0;
	m_bReversePhase         = ::GetPrivateProfileInt(szAppName, "ReversePhase",    0, ini_file) != 0;
	m_bAltVolume            = ::GetPrivateProfileInt(szAppName, "Volume" ,         0, ini_file) != 0;
	m_bDispAvg              = ::GetPrivateProfileInt(szAppName, "DispAvg",         0, ini_file) != 0;

	if(m_nOutputBps == 64) m_nOutputBps = -64;

	m_bPostProc = m_bReverseLR || m_bReversePhase || m_bAltVolume;

	m_nVolume = ::GetPrivateProfileInt(szAppName, "XVolume", 255, ini_file);
	m_nPan    = ::GetPrivateProfileInt(szAppName, "XPan",      0, ini_file);

	m_bReplayGainEnable          =
						::GetPrivateProfileInt(szAppName, "ReplayGain_Enable",    0, ini_file) != 0;
	m_nReplayGainMode            =
						::GetPrivateProfileInt(szAppName, "ReplayGain_Mode",      0, ini_file);
	m_nReplayGainTag             =
						::GetPrivateProfileInt(szAppName, "ReplayGain_Tag",       REPLAYGAIN_TAG_INIT,
									ini_file);
	m_nReplayGainPreAmpWithRG    =
						::GetPrivateProfileInt(szAppName, "ReplayGain_PreAmp_WithRG",    0, ini_file);
	m_nReplayGainPreAmpWithoutRG =
						::GetPrivateProfileInt(szAppName, "ReplayGain_PreAmp_WithoutRG", 0, ini_file);
	m_bReplayGainHardLimit       =
						::GetPrivateProfileInt(szAppName, "ReplayGain_HardLimit", 1, ini_file) != 0;

	m_bEnableStreaming       = ::GetPrivateProfileInt(szAppName, "EnableStreaming", 0, ini_file) != 0;
	m_nReceiveThreadPriority = ::GetPrivateProfileInt(szAppName, "ReceivePriority", 2, ini_file);
	m_nBufferLength          = Max((int)GetPrivateProfileInt(szAppName, "StrBuf", 256, ini_file),
									MIN_STREAM_SIZE / 1024);
	m_bProxy                 = ::GetPrivateProfileInt(szAppName, "EnableProxy",     0, ini_file) != 0;
	m_bSaveStream            = ::GetPrivateProfileInt(szAppName, "SaveStream",      0, ini_file) != 0;
	m_bTitleStreaming        = ::GetPrivateProfileInt(szAppName, "TitleStreaming",  1, ini_file) != 0;
	m_bTitleStreamingDecode  = ::GetPrivateProfileInt(szAppName, "DecodeText",      1, ini_file) != 0;
	m_bTitleStreamingUDP     = ::GetPrivateProfileInt(szAppName, "UseUDP",          0, ini_file) != 0;

	::GetPrivateProfileString(szAppName, "Proxy", "", buf, 255, ini_file);
	m_strProxy = buf;
	::GetPrivateProfileString(szAppName, "SaveStreamFile", "", buf, 255, ini_file);
	m_strSaveStream = buf;
	::GetPrivateProfileString(szAppName, "TitleStreamingFormat", "%1 (%2)", buf, 255, ini_file);
	m_strTitleStreamingFormat = buf;

	::GetPrivateProfileString(szAppName, "FormatEx", "[%artist% - ]%title%", buf, 255, ini_file);
	m_strID3Format = buf;
	::GetPrivateProfileString(szAppName, "SIFFormat", "%IART - %INAM", buf, 255, ini_file);
	m_strSIFFormat = buf;

	m_nTagPriority = ::GetPrivateProfileInt(szAppName, "TagPriority", 0, ini_file);
}

void CIn_mpg123dParam::WriteProfile(void)
{
	char string[32];
	static const char szAppName[] = "Shibatch mpg123";

	_itoa_s(m_bEnable, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "Enable", string, ini_file);

	_itoa_s(m_nDecodeThreadPriority, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "DecodePriority", string, ini_file);

	_itoa_s(m_nOutputBps, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "OutputFormat", string, ini_file);

	_itoa_s(m_bFullBuffering, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "FullBuffering", string, ini_file);

	_itoa_s(m_bSupZero, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "SupZero", string, ini_file);

	_itoa_s(m_bReverseLR, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReverseLR", string, ini_file);

	_itoa_s(m_bReversePhase, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReversePhase", string, ini_file);

	_itoa_s(m_bAltVolume, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "Volume", string, ini_file);

	_itoa_s(m_bDispAvg, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "DispAvg", string, ini_file);

	_itoa_s(m_nVolume, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "XVolume", string, ini_file);

	_itoa_s(m_nPan, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "XPan", string, ini_file);

	_itoa_s(m_bReplayGainEnable, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReplayGain_Enable", string, ini_file);

	_itoa_s(m_nReplayGainMode, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReplayGain_Mode", string, ini_file);

	_itoa_s(m_nReplayGainTag, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReplayGain_Tag", string, ini_file);

	_itoa_s(m_nReplayGainPreAmpWithRG, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReplayGain_PreAmp_WithRG", string, ini_file);

	_itoa_s(m_nReplayGainPreAmpWithoutRG, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReplayGain_PreAmp_WithoutRG", string, ini_file);

	_itoa_s(m_bReplayGainHardLimit, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReplayGain_HardLimit", string, ini_file);

	_itoa_s(m_bEnableStreaming, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "EnableStreaming", string, ini_file);

	_itoa_s(m_nReceiveThreadPriority, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "ReceivePriority", string, ini_file);

	_itoa_s(m_nBufferLength, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "StrBuf", string, ini_file);

	_itoa_s(m_bProxy, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "EnableProxy", string, ini_file);

	_itoa_s(m_bSaveStream, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "SaveStream", string, ini_file);

	_itoa_s(m_bTitleStreaming, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "TitleStreaming", string, ini_file);

	_itoa_s(m_bTitleStreamingDecode, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "DecodeText", string, ini_file);

	_itoa_s(m_bTitleStreamingUDP, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "UseUDP", string, ini_file);

	::WritePrivateProfileString(szAppName, "Proxy", (LPCTSTR)m_strProxy, ini_file);
	::WritePrivateProfileString(szAppName, "SaveStreamFile", (LPCTSTR)m_strSaveStream, ini_file);
	::WritePrivateProfileString(szAppName, "TitleStreamingFormat", (LPCTSTR)m_strTitleStreamingFormat,
								ini_file);

	::WritePrivateProfileString(szAppName, "FormatEx", (LPCTSTR)m_strID3Format, ini_file);
	::WritePrivateProfileString(szAppName, "SIFFormat", (LPCTSTR)m_strSIFFormat, ini_file);

	_itoa_s(m_nTagPriority, string, sizeof string, 10);
	::WritePrivateProfileString(szAppName, "TagPriority", string, ini_file);

}

/////////////////////////////////////////////////////////////
// URL Decode ����
// �G�X�P�[�v���ꂽ���{������ɖ߂�
//
char CIn_mpg123dParam::x2c(char* what)
{
    char digit;

    digit = (what[0] >= 'A' ? ((what[0] & 0xdf) - 'A')+10 : (what[0] - '0'));
    digit *= 16;
    digit += (what[1] >= 'A' ? ((what[1] & 0xdf) - 'A')+10 : (what[1] - '0'));

    return digit;
}

void CIn_mpg123dParam::URLDecode(char* src, char* dst)
{
	unsigned char c;
	char *p;
	bool bFlag = false;
	bool bRadioSpy = false;

	p = src;

	while (c = (unsigned char)*p++) {
		switch (c) {
		case 0xff:
			if ((*p == 0x66) && (*(p+1) == 0x66) && (*(p+2) == 0x66) && (*(p+3) == 0x66) && (*(p+4)) && (*(p+5)) ) {
				bRadioSpy = true;
				p += 4; /* 66 66 66 66 '8' 'C' */
				c = x2c(p);

				if (((c >= 0x81) && (c <= 0x9F))
					|| ((c >= 0xE0) && (c <= 0xEF))) {
					if(bFlag) {
						bFlag = false;
					} else {
						// SJIS 1�o�C�g��
						bFlag = true;
					}
				} else {
					bFlag = false;
				}

				p += 2;
			} else {
				// SJIS�ꕶ���ڂ��폜����
				if(bFlag) {
					*(dst - 1) = NULL;
				}
				bFlag = false;
				// NULL���p�f�B���O
				c = NULL;
			}
			break;
		case '%':
			bFlag = false;
			if ((*p) && (*(p+1))) {
				c = x2c(p);
				p += 2;
			} else {
				c = NULL;
			}
			break;
		default:
			if ((c < 0x40) || (c > 0xfc)) {
				// SJIS�ꕶ���ڂ��폜
				if(bFlag) {
					dst--;
				}
			}

			if(bRadioSpy) {
				if ((c < 0x20) || (c >= 0x80)) {
					// �ςȕ������o�Ă�����p�[�X��ł�����
					*dst++ = NULL;
				}
			}

			bFlag = false;
		}
		*dst++ = c;
	}
    *dst = NULL;
}

int CIn_mpg123dParam::GetPriorityValue(int n)
{
	int		ret;

	switch(n) {
	case 0:
		ret = THREAD_PRIORITY_NORMAL;
		break;
	case 1:
		ret = THREAD_PRIORITY_ABOVE_NORMAL;
		break;
	default:
		ret = THREAD_PRIORITY_HIGHEST;
		break;
	}

	return ret;
}

