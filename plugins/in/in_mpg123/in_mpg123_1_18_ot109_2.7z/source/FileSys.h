
//
//  �t�@�C���ǂݍ��ݗp���b�p�[�N���X(�w�b�_)
//  �t���o�b�t�@�����O�ł���悤�ɂ���
//
//  Written by Otachan
//  http://otachan.com/
//

enum
{
	FILESYS_OPENMODE_NORMAL,
	FILESYS_OPENMODE_FULLBUFFERING,
};

class
FileSys
{
public:
	FileSys(int _MaxClient = 1);
	~FileSys(void);

	bool	Open(
				int _OpenMode,
				const char* FileName,
				DWORD Acces,
				DWORD ShareMode,
				LPSECURITY_ATTRIBUTES sa,
				DWORD Create,
				DWORD AttrsAndFlags = 0,
				HANDLE TemplateFile = NULL,
				bool NoClose = false);
	void	Close(void);
	void	CloseHandleOnly(void);
	bool	Read(
				int ClientIdx,
				LPVOID lpBuffer,
				DWORD nNumberOfBytesRead,
				LPDWORD lpNumberOfBytesRead = NULL,
				LPOVERLAPPED lpOverlapped = NULL);
	DWORD	SetPointer(
					int ClientIdx,
					LONG lDistanceToMove,
					PLONG lpDistanceToMoveHigh = NULL,
					DWORD dwMoveMethod = FILE_BEGIN);
	HANDLE	GetHandle(void);
	DWORD	GetSize(LPDWORD lpdwFileSizeHigh = NULL);
	DWORD	GetPointer(int ClientIdx);

private:
	int		MaxClient;
	int		OpenMode;
	int		MaxHandle;
	HANDLE*	hF;
	unsigned char*	FileBuff;
	DWORD	FileSize;
	DWORD*	FilePointer;

	void	Init(void);
};

