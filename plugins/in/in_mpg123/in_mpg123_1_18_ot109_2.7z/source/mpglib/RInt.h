
// �l�̌ܓ����Đ����ɕϊ�(32bit)

inline int __fastcall
RInt32(double Num)
{
	union
	{
		char	Work[8];
		double	Work64;
	};

	Work64 = Num;

	const int	Sign = (Work[7] >> 7) | 1;

	Work[7] &= 0x7f;

	int		IntNum = static_cast<int>(Work64);

	if((Work64 - IntNum) == .5) {
		if(IntNum & 1) IntNum++;
	} else {
		IntNum = static_cast<int>(Work64 + .5);
	}

	return Sign * IntNum;
}

// �l�̌ܓ����Đ����ɕϊ�(64bit)

inline __int64 __fastcall
RInt64(double Num)
{
	union
	{
		char	Work[8];
		double	Work64;
	};

	Work64 = Num;

	const __int64	Sign = (Work[7] >> 7) | 1;

	Work[7] &= 0x7f;

	__int64	IntNum = static_cast<__int64>(Work64);

	if((Work64 - IntNum) == .5) {
		if(IntNum & 1) IntNum++;
	} else {
		IntNum = static_cast<__int64>(Work64 + .5);
	}

	return Sign * IntNum;
}

