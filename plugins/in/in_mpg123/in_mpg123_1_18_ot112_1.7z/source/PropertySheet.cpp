// In_mpg123dPropertySheet.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"

#include "in_mpg123.h"

#include "HttpFile.h"
#include "ICYInfo.h"

#include "Param.h"
#include "PropertySheet.h"

/*
#include "AboutDlg.h"
#include "OptionDlg.h"
#include "ControlDlg.h"
#include "ExtendFontDlg.h"
#include "PreferenceDlg.h"
#include "ExtendDisplayDlg.h"
#include "MyPropertySheet.h"
#include "../WinampJ.h"
*/

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

void reflect_setting(void);
void reflect_thread_setting(void);

/////////////////////////////////////////////////////////////////////////////
// CIn_mpg123dPropertySheet

IMPLEMENT_DYNAMIC(CIn_mpg123dPropertySheet, CPropertySheet)

CIn_mpg123dPropertySheet::CIn_mpg123dPropertySheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CIn_mpg123dPropertySheet::CIn_mpg123dPropertySheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
}

CIn_mpg123dPropertySheet::~CIn_mpg123dPropertySheet()
{
}


BEGIN_MESSAGE_MAP(CIn_mpg123dPropertySheet, CPropertySheet)
	//{{AFX_MSG_MAP(CIn_mpg123dPropertySheet)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIn_mpg123dPropertySheet ���b�Z�[�W �n���h��

void CIn_mpg123dPropertySheet::ReflectSetting(BOOL bFlag)
{
	if(bFlag) {
		::reflect_thread_setting();
	}
	::reflect_setting();
}
