
#define	REALTIME_VBR_UPDATE_FRAME	32

class
Bitrate
{
public:
	Bitrate(int _MaxLatency, int _Sr, int _FrameSamples);
	~Bitrate(void);

	void	Flush(void);
	void	Set(int Bitrate);
	int		Get(int Latency);

private:
	int		MaxLatency;
	int		Sr;
	int		FrameSamples;
	int		MaxHistory;
	int*	History;
	bool	First;
	int		HistoryIdx;
	int		SetCnt;
	__int64	AddBitrate;
	int		AverageLatencyIdx;
};

