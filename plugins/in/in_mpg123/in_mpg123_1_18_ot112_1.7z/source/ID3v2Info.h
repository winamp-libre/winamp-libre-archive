
//
//  ID3v2�^�O���擾����(�w�b�_)
//
//  Written by Otachan
//  http://otachan.com/
//

inline void	ID3v2FrameTEXT(
						WCHAR* Buff,
						const UINT BuffSize,
						unsigned char* TagDataPnt,
						UINT FrameSize,
						const bool FrameUnsynchronization);
inline void	ID3v2FrameTXXX(
						WCHAR* FieldName,
						const UINT FieldNameSize,
						WCHAR* FieldData,
						const UINT FieldDataSize,
						unsigned char* TagDataPnt,
						UINT FrameSize,
						const bool FrameUnsynchronization);
inline void	ID3v2FrameCOMM(
						WCHAR* Buff,
						const UINT BuffSize,
						unsigned char* TagDataPnt,
						UINT FrameSize,
						const bool FrameUnsynchronization);
UINT	ID3v2DecodeUnsynchronization(unsigned char* Data, const UINT Size, const bool SetZero);
UINT	WideStrSize(WCHAR* InBuff, const UINT MaxSize);

