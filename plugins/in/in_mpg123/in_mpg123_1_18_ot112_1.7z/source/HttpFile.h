#if !defined(AFX_IN_MPG123DHTTPFILE_H__F67531D3_D0F6_445E_8BE3_9CA9BF9F86EC__INCLUDED_)
#define AFX_IN_MPG123DHTTPFILE_H__F67531D3_D0F6_445E_8BE3_9CA9BF9F86EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// In_mpg123dHttpFile.h : �w�b�_�[ �t�@�C��
//



/////////////////////////////////////////////////////////////////////////////
// CIn_mpg123dHttpFile �R�}���h �^�[�Q�b�g

class
CIn_mpg123dHttpFile : public CHttpFile
{
// �A�g���r���[�g
public:
	static	ThreadParamInetRead*	pParam;

// �I�y���[�V����
public:
	CIn_mpg123dHttpFile(HINTERNET hFile, HINTERNET hSession, LPCTSTR pstrObject,
		LPCTSTR pstrServer, LPCTSTR pstrVerb, DWORD dwContext);
	CIn_mpg123dHttpFile(HINTERNET hFile, LPCTSTR pstrVerb, LPCTSTR pstrObject,
		CHttpConnection* pConnection);
	virtual ~CIn_mpg123dHttpFile();

	// begin pl3 by YunaSoft
	void Init(int n);
	// end pl3
	void Quit(void);

	UINT ReadEx(LPVOID lpBuffer, UINT nCount);

private:
	bool CIn_mpg123dHttpFile::_InternetReadFile(
											HINTERNET hFile,
											LPVOID lpBuffer,
											DWORD dwNumberOfBytesToRead,
											LPDWORD lpdwNumberOfBytesRead);

// �C���v�������e�[�V����
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ �͑O�s�̒��O�ɒǉ��̐錾��}�����܂��B

#endif // !defined(AFX_IN_MPG123DHTTPFILE_H__F67531D3_D0F6_445E_8BE3_9CA9BF9F86EC__INCLUDED_)
