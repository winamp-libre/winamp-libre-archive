// In_mpg123dParam.h: CIn_mpg123dParam �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IN_MPG123DPARAM_H__D62BDF71_F32C_4E8A_96CD_BE403E63F4D0__INCLUDED_)
#define AFX_IN_MPG123DPARAM_H__D62BDF71_F32C_4E8A_96CD_BE403E63F4D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CIn_mpg123dParam : public CObject
{
public:
	CIn_mpg123dParam();
	virtual ~CIn_mpg123dParam();

	void GetProfile(void);
	void WriteProfile(void);
	void GetIniFn(HMODULE hDllInstance);
	int GetPriorityValue(int n);

	WCHAR ini_file[MAX_PATHLEN];

	CICYInfo m_icy;

	int m_nStartPage;

	// CConfigDialog
	bool	m_bEnable;
	int		m_nDecodeThreadPriority;
	int		m_nOutputBps;
	bool	m_bFullBuffering;
	bool	m_bSupZero;
	bool	m_bReverseLR;
	bool	m_bReversePhase;
	bool	m_bAltVolume;
	bool	m_bDispAvg;

	bool	m_bPostProc;

	// etc.
	int		m_nVolume;
	int		m_nPan;

	// CReplayGainDialog
	bool	m_bReplayGainEnable;
	int		m_nReplayGainMode;
	UINT	m_nReplayGainTag;
	int		m_nReplayGainPreAmpWithRG;
	int		m_nReplayGainPreAmpWithoutRG;
	bool	m_bReplayGainHardLimit;

	// CFormatDialog
	int		m_nTagPriority;
	CString	m_strID3Format;
	CString	m_strSIFFormat;

	// CStreamingDialog
	bool	m_bEnableStreaming;
	int		m_nReceiveThreadPriority;
	int		m_nBufferLength;
	bool	m_bProxy;
	CString	m_strProxy;
	bool	m_bSaveStream;
	CString	m_strSaveStream;
	bool	m_bTitleStreaming;
	bool	m_bTitleStreamingUDP;
	CString	m_strTitleStreamingFormat;
};

struct
THREADPARAM
{
	HANDLE	Thread;
	HANDLE	EventReadyThread;
	HANDLE	EventDestroyThread;
	CIn_mpg123dParam*	param;
	CWinThread*	mt;
};

#endif // !defined(AFX_IN_MPG123DPARAM_H__D62BDF71_F32C_4E8A_96CD_BE403E63F4D0__INCLUDED_)
