// in_mpg123d.h : IN_MPG123D �A�v���P�[�V�����̃��C�� �w�b�_�[ �t�@�C���ł��B
//

#if !defined(AFX_IN_MPG123D_H__98380E27_1EA3_11D4_9ECA_00A024503B95__INCLUDED_)
#define AFX_IN_MPG123D_H__98380E27_1EA3_11D4_9ECA_00A024503B95__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"

#define	VER						L"v1.18y ot112.1"

#define	_VER					"v1.18y ot112.1"

#define	MAX_PATHLEN				1024

#define	MPG123_FILESYS_NO		0

#define	OBSIZE					65536
#define	FBSIZE					8192

#define	MIN_STREAM_SIZE			(FBSIZE * 2)
#define	PRE_READ_STREAM_SIZE	512
#define	READ_STREAM_SIZE		FBSIZE

#define	POST_DELAY				1152
#define	DECODE_DELAY_LAYER1		0
#define	DECODE_DELAY_LAYER2		(480 + 1)
#define	DECODE_DELAY_LAYER3		(528 + 1)

#define	MAX_SEARCH_HEADER		65536

#define	FILE_EXT				"MP3;MP2;MP1;RMP\0MPEG Audio Files (*.MP3;*.MP2;*.MP1;*.RMP)\0"

#define	PLAY2ND_CLASS			L"in_!mpg123 Play2nd"

#define	USER_AGENT				L"WINAMP mpg123 " VER

#define	REPLAYGAIN_TAG_NONE		0x00000000U
#define	REPLAYGAIN_TAG_ID3V2	0x00000001U
#define	REPLAYGAIN_TAG_APE		0x00000002U
#define	REPLAYGAIN_TAG_LAME		0x00000004U
#define	REPLAYGAIN_TAG_INIT		(REPLAYGAIN_TAG_ID3V2 | REPLAYGAIN_TAG_APE)

typedef	void	(*OUT_DATA_FUNC)(char* OutBuff, unsigned char* InBuff, const int Size);
typedef	void	(*VIS_DATA_FUNC)(char* OutBuff, char* InBuff, const int Size);

struct
mp3info
{
	bool	stream;
	bool	vbr_tag;
	int		hpos;
	int		nbytes;
	int		hnbytes;
	bool	mpeg25;
	int		lsf;
	int		lay;
	int		freq;
	int		mode;
	int		nch;
	int		bitrate;
	int		frame_samples;
	int		frames;
	int		samples;
	int		length;
	int		out_bps;
	int		out_bps_b;
	int		out_bps_b_nch;
	int		vis_bps_b_nch;
	int		bps;
	int		bps_b;
	int		bps_b_nch;
	int		decode_delay;
	int		skip_start;
	double	skip_start_ms;
	bool	replaygain_valid_track_gain;
	bool	replaygain_valid_track_peak;
	bool	replaygain_valid_album_gain;
	bool	replaygain_valid_album_peak;
	double	replaygain_track_gain;
	double	replaygain_track_peak;
	double	replaygain_album_gain;
	double	replaygain_album_peak;
};

// begin pl3 by YunaSoft
struct
ThreadParamInetRead
{
	int		nPriority;
	HANDLE	hThread;
	HANDLE	EventReadyThread;
	HANDLE	EventDestroyThread;
	HANDLE	EventReadEx;
	HANDLE	EventRetReadEx;
	HANDLE	HandleEvent[2];
	volatile HINTERNET	hFile;
	volatile LPVOID	lpBuffer;
	volatile DWORD	dwNumberOfBytesToRead;
	volatile DWORD	dwNumberOfBytesRead;
	volatile bool	success;
};
// end pl3


// begin pl2 by YunaSoft
class CIn_mpg123dSession : public CInternetSession
{
public:
	CIn_mpg123dSession(
					LPCTSTR pstrAgent,
					DWORD dwContext,
					DWORD dwAccessType,
					LPCTSTR pstrProxyName,
					LPCTSTR pstrProxyBypass,
					DWORD dwFlags);
//	virtual void OnStatusCallback(DWORD dwContext, DWORD dwInternetStatus,
//		LPVOID lpvStatusInfomration, DWORD dwStatusInformationLen);
};

/*
class CIn_mpg123dException : public CException
{
	DECLARE_DYNCREATE(CIn_mpg123dException)

public:
	CIn_mpg123dException(int nCode = 0);
	~CIn_mpg123dException() { }

	int m_nErrorCode;
};
*/
// end pl2

/////////////////////////////////////////////////////////////////////////////
// CIn_mpg123App
// ���̃N���X�̓���̒�`�Ɋւ��Ă� in_mpg123.cpp �t�@�C�����Q�Ƃ��Ă��������B
//

class CIn_mpg123App : public CWinApp
{
public:
	CIn_mpg123App(void);

// �I�[�o�[���C�h
	// ClassWizard �͉��z�֐��̃I�[�o�[���C�h�𐶐����܂��B
	//{{AFX_VIRTUAL(CIn_mpg123dApp)
	public:
	virtual BOOL InitInstance(void);
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CIn_mpg123App)
		// ���� -  ClassWizard �͂��̈ʒu�Ƀ����o�֐���ǉ��܂��͍폜���܂��B
		//         ���̈ʒu�ɐ��������R�[�h��ҏW���Ȃ��ł��������B
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio �͑O�s�̒��O�ɒǉ��̐錾��}�����܂��B

#endif // !defined(AFX_IN_MPG123D_H__98380E27_1EA3_11D4_9ECA_00A024503B95__INCLUDED_)
