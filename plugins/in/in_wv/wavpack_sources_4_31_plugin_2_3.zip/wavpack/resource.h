//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wavpack.rc
//
#define IDC_MODE_GROUP                  1000
#define IDC_LOSSLESS                    1001
#define IDC_LOSSLESS_HIGH               1002
#define IDC_LOSSLESS_FAST               1003
#define IDC_HYBRID                      1004
#define IDC_HYBRID_HIGH                 1005
#define IDC_HYBRID_GROUP                1006
#define IDC_BITRATE                     1009
#define IDC_BITRATE_TEXT                1010
#define IDC_CORRECTION                  1011
#define IDC_FLOAT_GROUP                 1012
#define IDC_FLOAT20                     1013
#define IDC_FLOAT24                     1014
#define IDC_FLOAT32                     1015
#define IDC_NOISESHAPE                  1016
#define IDC_DITHER                      1017
#define IDC_USEWVC                      1018
#define IDC_REPLAYGAIN_TEXT             1019
#define IDC_REPLAYGAIN                  1020
#define IDC_CLIPPING_TEXT               1021
#define IDC_CLIPPING                    1022
#define IDC_HYBRID_FAST                 1023
#define IDC_NORMALIZE                   1024
#define IDC_EXTRA_GROUP                 1025
#define IDC_EXTRA                       1026
#define IDM_APP_DIALOG                  40001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
