*******************************************************************
 Seeking WavPack Player Plugin for Winamp  Version 2.3  2005-11-01
 Copyright (c) 2005 Conifer Software.  All Rights Reserved.
*******************************************************************

This plugin allows you to play WavPack files in the popular Windows
audio player Winamp (either versions 2 or 5). All versions of WavPack
file are supported (back to 1.00) and both lossless and lossy modes
are playable (and seekable). Files encoded in "raw" mode prior to
version 4.0 will not play.

Support for playing 24-bit files and floating point files is provided,
however the support for this in winamp is spotty and, of course, many
soundcards do not support this data. Make sure you have the latest
version of winamp and your soundcard's drivers.

This version of the plugin supports reading both ID3v1 and APEv2 tags.
If either of these tags are present on the .wv file, the artist and
title will appear in the winamp playlist and additional info will
show in the InfoBox.

The plugin can use the .wvc files (if present) to enable lossless
playback of hybrid files. However, because this requires more CPU
processing and disk seeking, a configuration setting exists to
disable this feature if desired.

ReplayGain is now supported through the APEv2 tags, although the
ReplayGain information must be calculated and stored in the tags
by another application (Foobar2000 is a good one). The configuration
allows the choice of ReplayGain mode (disabled, track or album mode)
and a choice of action in the case where a track (or album) will
clip after the ReplayGain is applied. The choices are to simply
hard clip the samples, to apply "soft clipping" that rounds the
clipped waveforms, and a third option to scale down the track
beforehand so that it will not clip. The current gain and whether
soft clipping is active is shown in the infobox.

To install the plugin simply copy (or extract) the file "in_wv.dll"
into the standard Winamp plugins directory (usually located at:
"\program files\winamp\plugins").

Because WavPack files from versions prior to 4.0 do not have seeking
information embedded in them, the seeking feature of this plugin works
a little differently than you may be used to when playing these older
files. When the plugin plays an older WavPack file it automatically
generates a temporary index for the file in memory. When a seek is
requested the plugin will instantly seek to the desired location if it
has been stored in the index, otherwise the seek operation could take
several seconds during which nothing is heard. Depending on the speed
of your computer and the mode that the file was packed with, this can
be from about 10x to 100x normal playback speed.

WavPack and this plugin are free programs; feel free to give them to
anyone who may find them useful. There is no warrantee provided and you
agree to use them completely at your own risk. If you have any questions
or problems please let me know at david@wavpack.com and be sure to visit
www.wavpack.com for the latest versions of WavPack and this plugin.
