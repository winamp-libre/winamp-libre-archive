#define IDD_CONFIG_BS2B             101
#ifndef IDC_STATIC
#define IDC_STATIC                  -1
#endif
#define IDC_SLIDER_LEVEL_FEED       1001
#define IDC_SLIDER_LEVEL_FCUT       1002
#define IDC_BUTTON_ABOUT            1003
#define IDC_BUTTON_DEFAULT          1004
#define IDC_BUTTON_CMOY             1005
#define IDC_BUTTON_JMEIER           1006
#define IDC_STATIC_LEVEL_FEED       1007
#define IDC_STATIC_LEVEL_FCUT       1008
