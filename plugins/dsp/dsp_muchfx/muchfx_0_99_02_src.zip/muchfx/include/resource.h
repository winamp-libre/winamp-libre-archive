
// *****************************************
//  muchfx Plug-in
//  Copyright (C) 1998-1999, Marc S. Ressl
//	Copyright (C) 2003, Nehal Mistry
//
//  See dsp_muchfx.txt for more information
// *****************************************

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by muchfx.rc
//
#define IDD_DIALOG1                     101
#define IDD_DIALOGMAIN4                 101
#define IDB_BITMAP1                     103
#define IDD_DIALOGABOUT                 105
#define IDD_DIALOGADD                   106
#define IDD_DIALOGMAIN1                 107
#define IDD_DIALOGMAIN                  107
#define IDB_BITMAP_UP2                  110
#define IDB_BITMAP_DOWN2                111
#define IDB_BITMAP_CB                   112
#define IDR_ACCELERATOR                 114
#define IDB_BITMAP_BAR                  126
#define IDB_BITMAP_UP                   127
#define IDB_BITMAP_DOWN                 128
#define IDB_BITMAP_RIGHT                129
#define IDB_BITMAP_LEFT                 130
#define IDI_ICON                        133
#define IDB_BITMAP                      138
#define IDC_LIST                        1004
#define IDC_SCROLL                      1006
#define IDC_BUTTONCANCEL                1007
#define IDC_BUTTONREM                   1008
#define IDC_BUTTONOK                    1009
#define IDC_BUTTONCONFIG                1009
#define IDC_BUTTONADD                   1010
#define IDC_BUTABOUT                    1011
#define IDC_BUTOK                       1012
#define IDC_STATIC_TOP                  1021
#define IDC_LIB                         1118
#define IDC_MODULE                      1119
#define IDC_CONFIG                      1120
#define IDC_BUTTONDOWN                  40004
#define IDC_BUTTONUP                    40005
#define IDC_BUTTONSEL                   40006
#define IDC_BUTTONLOAD                  40007
#define IDC_BUTTONSAVE                  40008
#define IDC_BUTTONABOUT                 40009
#define IDC_BUTTONRELOAD                40010
#define IDC_BUTTONHOME                  40011
#define IDC_BUTTONEND                   40012
#define IDC_BUTTONPGUP                  40013
#define IDC_BUTTONPGDN                  40014
#define IDC_BUTTONSCRLUP                40015
#define IDC_BUTTONSCRLDOWN              40016
#define IDC_BUTTONMOVEDOWN              40017
#define IDC_BUTTONMOVEUP                40018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
