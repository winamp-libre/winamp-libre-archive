
// *****************************************
//  muchfx Plug-in
//  Copyright (C) 1998-1999, Marc S. Ressl
//	Copyright (C) 2003, Nehal Mistry
//
//  See dsp_muchfx.txt for more information
// *****************************************

#define PROGRAMNAME "MuchFX 0.9902"

#include <windows.h>
#include "dsp.h"
#include "dspold.h"
#include "resource.h"   // includes the definitions for the resources
#include <direct.h>
#include <stdio.h>
#include <io.h>

// avoid stupid CRT silliness
BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}

// Variables
static char plugindir[MAX_PATH];
static char plugin_ini[MAX_PATH];
static char cache_pic[MAX_PATH];

static HWND mainDialog = NULL;
static HANDLE mainThreadHandle = NULL;
static DWORD mainThreadId = 0;
static HACCEL mainAccel;

static char dllPath[MAX_PATH];

static int dllModule;
static int dllType;
static BOOL dllModuleEn;
static HINSTANCE dllInst;

static winampDSPHeader1 *dspheaderP1;
static winampDSPHeader *dspheaderP;
static winampDSPModule1 *dspmoduleP1;
static winampDSPModule *dspmoduleP;

static POINT clickPoint;
static RECT clickWin;
static POINT clickDim;

static RECT clickWinamp;
static RECT clickMuch;

static RECT muchrect;

static HBITMAP hbmpSource;
static HBRUSH hBrush1;
static HBRUSH hBrush2;
static HFONT hFont;

static BOOL windowshademode = FALSE;
static BOOL windowfocus = TRUE;
static BOOL windowmove = FALSE;
static int windowdocked = 0;

static BOOL windowenable = FALSE;

static BOOL scrollenable = FALSE;
static BOOL scrollbarenable = FALSE;

static BOOL buttonpress;
static int buttonnum;

static BOOL windowEnable;

static int scrollstart = 0;
static int scrollindex = -1;
static int scrollcount = 0;

static HHOOK dragHook;

// Types
struct modlisttype {
	int dllType;

	char *dllPath;
	int dllModule;
	BOOL dllModuleEn;
	HINSTANCE dllInst;

	HANDLE configThreadHandle;
	DWORD configThreadId;

	union modtypeunion
	{
		winampDSPModule1 *v1;
		winampDSPModule  *v2;
	} module;

	struct modlisttype *next;
};

struct dspcachetype {
	char *dllPath;
	char *description;

	struct dspcachetype *next;
};

static struct modlisttype *modlist = NULL;
static struct dspcachetype *dspcache = NULL;

// DLL Functions
winampDSPModule *getModule(int which);

void config(struct winampDSPModule *this_mod);
int init(struct winampDSPModule *this_mod);
void quit(struct winampDSPModule *this_mod);

int modify_samples(struct winampDSPModule *this_mod, short *samples, int numsamples, int bps, int nch, int srate);

// Functions
BOOL APIENTRY GetMain(HWND hDlg, UINT message, UINT wParam, LONG lParam);
BOOL APIENTRY GetAdd(HWND hDlg, UINT message, UINT wParam, LONG lParam);
BOOL APIENTRY GetAbout(HWND hDlg, UINT message, UINT wParam, LONG lParam);

POINT startup(void);
void startup2(void);
void startup3(void);

void closeup(void);

void movenodeup(void);
void movenodedown(void);
int addnode(void);
void removenode(void);
void confignode(void);
void selectnode(void);
void reloadnode(void);
void loadlist(void);
void savelist(void);

LRESULT CALLBACK CallWndProc(int nCode, WPARAM wParam, LPARAM lParam);

// Module header, includes version, description, and address of the module retriever function
winampDSPHeader hdr = {DSP_HDRVER, PROGRAMNAME, getModule};

// the module
winampDSPModule mod =
{
	"MuchFX� Multi DSP Module",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	config,
	init,
	modify_samples,
	quit
};

// Tables
struct muchbutton {
	int sx;
	int sy;
	int x;
	int y;
	int xr;
	int yr;
	int xp;
	int yp;
};

struct muchbutton butTab[9] = {
	{23, 18, 11, 86, 11, 86, 19, 156},		// UP
	{23, 18, 34, 86, 34, 86, 42, 156},		// DOWN
	{23, 18, 57, 86, 57, 86, 65, 156},		// ADD
	{23, 18, 80, 86, 80, 86, 88, 156},		// DEL
	{23, 18, 103, 86, 103, 86, 111, 156},	// CFG
	{23, 18, 208, 86, 208, 86, 134, 156},	// LOAD
	{23, 18, 231, 86, 231, 86, 157, 156},	// SAVE
	{47, 15, 143, 86, 143, 86, 180, 156},	// ABOUT
	{ 9,  9, 264, 3, 264, 3, 1, 156},		// WINSHADE
};


// Anuther dec's
#ifdef __cplusplus
extern "C" {
#endif
// this is the only exported symbol. returns our main header.
__declspec( dllexport ) winampDSPHeader *winampDSPGetHeader2()
{
	return &hdr;
}
#ifdef __cplusplus
}
#endif

// getmodule routine from the main header. Returns NULL if an invalid module was requested,
// otherwise returns either mod1 or mod2 depending on 'which'.
winampDSPModule *getModule(int which)
{
	switch (which)
	{
		case 0: return &mod;
		default:return NULL;
	}
}

// Toggle windowshade mode
void windowshade(HWND hDlg)
{
	RECT r;

	HDC hdcSource;
	HDC hdcDest;

	hdcDest = GetWindowDC(hDlg);
	hdcSource = CreateCompatibleDC(hdcDest);
	SelectObject(hdcSource, hbmpSource);	

	if (windowshademode)
	{
		BitBlt(hdcDest,
			0,
			0,
			275, 116,
			hdcSource,
			0, 0, 
			SRCCOPY);
	}
	else
	{
		BitBlt(hdcDest,
			0,
			0,
			275, 14,
			hdcSource,
			0, 128, 
			SRCCOPY);
	}

	DeleteDC(hdcSource); 
	ReleaseDC(hDlg, hdcDest);
	
	if (windowshademode)
	{
		GetWindowRect(hDlg, &r);
		if (windowdocked == 1)		
			r.top -= 116 - 14;
		MoveWindow(hDlg, 
			r.left,
			r.top,
			275,
			116,
			TRUE);

		butTab[8].xr = 264;
		butTab[8].yr = 3;
		butTab[8].xp = 1;
		butTab[8].yp = 156;
	}	
	else
	{
		GetWindowRect(hDlg, &r);
		if (windowdocked == 1)
			r.top += 116 - 14;
		MoveWindow(hDlg, 
			r.left,
			r.top,
			275,
			14,
			TRUE);

		butTab[8].xr = 264;
		butTab[8].yr = 131;
		butTab[8].xp = 10;
		butTab[8].yp = 156;
	}
	windowshademode = !windowshademode;
	GetWindowRect(mod.hwndParent, &clickWinamp);
	GetWindowRect(hDlg, &muchrect);
	clickMuch = muchrect;
}

// Draw a button, in a state
void DrawButton(int butnum, BOOL pressed)
{
	HDC hdcSource;
	HDC hdcDest;
	
	hdcDest = GetWindowDC(mainDialog);
	hdcSource = CreateCompatibleDC(hdcDest);
	SelectObject(hdcSource, hbmpSource);	

	if (pressed)
	{
		BitBlt(hdcDest,
			butTab[butnum].x,
			butTab[butnum].y,
			butTab[butnum].sx, butTab[butnum].sy,
			hdcSource,
			butTab[butnum].xp, butTab[butnum].yp, 
			SRCCOPY);
	}
	else
	{
		BitBlt(hdcDest,
			butTab[butnum].x,
			butTab[butnum].y,
			butTab[butnum].sx, butTab[butnum].sy,
			hdcSource,
			butTab[butnum].xr, butTab[butnum].yr,
			SRCCOPY);
	}

	DeleteDC(hdcSource); 
	ReleaseDC(mainDialog, hdcDest);
}

// Class info
char szWindowClass[] = "MuchFX2Class";
#define WIND_BORDER 10

// Main thread proc
DWORD mainProc(LPDWORD lpdwParam)
{	
	WNDCLASS wc;	
	MSG msg;

	POINT p;


	wc.style = CS_DBLCLKS;
    wc.lpfnWndProc = (WNDPROC)GetMain;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = mod.hDllInstance;
    wc.hIcon = 0;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = 0;
    wc.lpszMenuName = NULL;
    wc.lpszClassName = szWindowClass;

    if(!RegisterClass(&wc)) 
		return 1;

// Setup position

	p = startup();

	mainDialog = CreateWindow(szWindowClass,"MuchFX�"
        , DS_MODALFRAME | WS_POPUP,
        , p.x, p.y, 275, 116, mod.hwndParent, NULL
        , mod.hDllInstance, (LPVOID)NULL);

	startup2();

	if (mainDialog)
	{
		ShowWindow(mainDialog,SW_SHOW);
	    UpdateWindow(mainDialog);

		startup3();

		dragHook = SetWindowsHookEx(WH_CALLWNDPROC, (HOOKPROC) CallWndProc, mod.hDllInstance, GetWindowThreadProcessId(mod.hwndParent, NULL));

		mainAccel = LoadAccelerators(mod.hDllInstance, MAKEINTRESOURCE(IDR_ACCELERATOR));

		// the almighty Windows message loop:
		
		while (GetMessage (&msg, NULL, 0, 0) == TRUE)
		{
			if (!TranslateAccelerator(mainDialog, mainAccel, &msg))
				if (!IsDialogMessage(mainDialog, &msg))
				{
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
		}

		// close up shop

		UnhookWindowsHookEx(dragHook);

		DestroyWindow(mainDialog);

		mainDialog = NULL;
	}

	UnregisterClass(szWindowClass, mod.hDllInstance);

	return 0;
}

// configuration. Passed this_mod, as a "this" parameter. Allows you to make one configuration
// function that shares code for all your modules (you don't HAVE to use it though, you can make
// config1(), config2(), etc...)
void config(struct winampDSPModule *this_mod)
{
	MessageBox(this_mod->hwndParent,"This plug-in is not configurable. To load, press OK or APPLY.",
		PROGRAMNAME,MB_OK | MB_ICONEXCLAMATION);
}

// Gets the directory out of a full path
void extractpathname(char *plugindir)
{
	char *filenamep = plugindir;

	do {
		if (*plugindir == '\\')
			filenamep = plugindir;
	} while (*plugindir++ != '\0');

	*filenamep = '\0';
}

// Initialization
POINT startup(void)
{
	char tempstring[512] = "";	
	POINT p;
	RECT r;

	GetPrivateProfileString("MuchFX", "Window", "", tempstring, 512, plugin_ini);
	
	if (sscanf(tempstring, "%d,%d", &p.x, &p.y) == 2)
	{
		GetWindowRect(GetDesktopWindow(), &r);

		if (p.x < 0)
		{
			p.x = 0;
			windowdocked = 0;
		}
		if (p.y < 0)
		{
			p.y = 0;
			windowdocked = 0;
		}
		if (p.x > (r.right - 275))
		{
			p.x = (r.right - 275);
			windowdocked = 0;
		}
		if (p.y > (r.bottom - 116))
		{
			p.y = (r.bottom - 116);
			windowdocked = 0;
		}
	}

	return p;
}

// Mo initialization
void startup2(void)
{	
	char tempstring[512] = "";	

	GetPrivateProfileString("MuchFX", "WindowDocked", "", tempstring, 512, plugin_ini);
	windowdocked = atoi(tempstring);

	GetPrivateProfileString("MuchFX", "WindowShade", "", tempstring, 512, plugin_ini);
	windowshademode = atoi(tempstring);
	if (windowshademode)
	{
		windowshademode = FALSE;
		windowshade(mainDialog);
	}
	else
		GetWindowRect(mainDialog, &muchrect);

	GetWindowRect(mod.hwndParent, &clickWinamp);
	clickMuch = muchrect;
}

// And mo initialization
void startup3(void)
{
	winampDSPGetHeaderType headerProc;
	winampDSPGetHeaderType1 headerProc1;

	char tempstring[1024] = "";	
	char tempfile[MAX_PATH];
	char *token;
	char *token2;

	char *tokenp;

	GetPrivateProfileString("MuchFX", "Plugins", "", tempstring, 1024, plugin_ini);
	token = strtok(tempstring, " ");
	while (token)
	{
		token2 = token;

		while (*token != ',' && *token != '\0')
			token++;

		if (*token != '\0')
		{
			*token = '\0';
			strcpy(dllPath, token2);
			tokenp = ++token;

			while (*token != ',' && *token != '\0')
				token++;
			
			if (*token != '\0')
			{
				*token = '\0';
				token++;
			}

			dllModule = atoi(tokenp);
			if (*token != '\0')
				dllModuleEn = atoi(token);
			else
				dllModuleEn = TRUE;

			sprintf(tempfile, "%s\\%s", plugindir, dllPath);
			dllInst = LoadLibrary((LPCSTR) tempfile);

			if (dllInst)
			{
				headerProc = (winampDSPGetHeaderType) GetProcAddress(dllInst, "winampDSPGetHeader2");
				headerProc1 = (winampDSPGetHeaderType1) GetProcAddress(dllInst, "winampDSPGetHeader");

				if (headerProc)
				{						
					dspheaderP = headerProc();
					if (dspheaderP->version == DSP_HDRVER)
					{
						dllType = 2;
						dspmoduleP = dspheaderP->getModule(dllModule);
						if (dspmoduleP)
						{
							dspmoduleP->hwndParent = mainDialog;
	    					dspmoduleP->hDllInstance = dllInst;

							if (addnode())
								FreeLibrary(dllInst);
						}
						else
							FreeLibrary(dllInst);
					}
				}
				else if (headerProc1)
				{						
					dspheaderP1 = headerProc1();
					if (dspheaderP1->version == DSP_HDRVER_1)
					{
						dllType = 1;
						dspmoduleP1 = dspheaderP1->getModule(dllModule);
						if (dspmoduleP1)
						{
							dspmoduleP1->hwndParent = mainDialog;
	    					dspmoduleP1->hDllInstance = dllInst;
	    					dspmoduleP1->sRate = 44100;	    					
							dspmoduleP1->nCh = 2;
	    					dspmoduleP1->blockSize = 576;

							if (addnode())
								FreeLibrary(dllInst);
						}
						else
							FreeLibrary(dllInst);
					}
				}
				 else
					FreeLibrary(dllInst);
			}
		}

		token = strtok(NULL, " ");
	}
}

// Adds node w/ data to cache
void addcache(char *dllPath, char *description, BOOL addToFile)
{
	struct dspcachetype *temp;

	temp = dspcache;

	temp = (struct dspcachetype *) calloc(1, sizeof(struct dspcachetype));
	if (!temp)
		return;
	
	temp->dllPath = (char *) calloc(1, strlen(dllPath) + 1);
	if (temp->dllPath)
		strcpy(temp->dllPath, dllPath);
	else
	{
		free(temp);
		return;
	}

	temp->description = (char *) calloc(1, strlen(description) + 1);
	if (temp->description)
		strcpy(temp->description, description);
	else
	{
		free(temp->dllPath);
		free(temp);
		return;
	}

	if (dspcache)
		temp->next = dspcache;
	else
		temp->next = NULL;

	dspcache = temp;

	if (addToFile)
	{
		FILE *fp;
		
		fp = fopen(cache_pic, "a");

		if (fp)
		{	
			char tempstring[256];

			sprintf(tempstring, "%s\t%s\n", dllPath, description);

			fputs(tempstring, fp);

			fclose(fp);
		}
	}
	return;
}

// Deletes the cache
void removecache(void)
{
	struct dspcachetype *temp;
	struct dspcachetype *next;

	temp = dspcache;

	while (temp)
	{
		next = temp->next;
		
		free(temp->dllPath);
		free(temp->description);
		free(temp);

		temp = next;
	}

	dspcache = NULL;
}

// Init's MuchFX
int init(struct winampDSPModule *this_mod)
{
	if (mainThreadHandle == NULL)
	{
		FILE *fp;
		char tempstring[256];
		
		modlist = NULL;
		dspcache = NULL;
		windowEnable = TRUE;

		GetModuleFileName(this_mod->hDllInstance, plugindir, 255);
		extractpathname(plugindir);
		sprintf(plugin_ini, "%s\\plugin.ini", plugindir);

		sprintf(cache_pic, "%s\\dsp_mfx2.pic", plugindir);
		fp = fopen(cache_pic, "rt");

		if (fp)
		{			
			while (fgets(tempstring, 256, fp))
			{
				char *token, *token2;

				token = strtok(tempstring, "\t");
				if (token)
				{
					token2 = strtok(NULL, "\n");
					if (token2)
						addcache(token, token2, FALSE);
				}
			}

			fclose(fp);
		}

		hbmpSource = LoadBitmap(mod.hDllInstance, MAKEINTRESOURCE(IDB_BITMAP));
		hFont = CreateFont(13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			VARIABLE_PITCH | FF_SWISS, "Arial");
		{
			HDC hdcSource;
			HDC hdcDest;

			hdcDest = GetWindowDC(mod.hwndParent);
			hdcSource = CreateCompatibleDC(hdcDest);
			SelectObject(hdcSource, hbmpSource);	

			hBrush1 = CreateSolidBrush(GetPixel(hdcSource, 13, 21));
			hBrush2 = CreateSolidBrush(GetPixel(hdcSource, 270, 156));

			DeleteDC(hdcSource); 
			ReleaseDC(mod.hwndParent, hdcDest);
		}

		mainThreadHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) &mainProc,
			0, 0, (LPDWORD) &mainThreadId);
	}

	return (mainThreadHandle == 0);
}

// We close da shop
void closeup(void)
{
	char tempstring[1024];
	char curridx[16];

	struct modlisttype *temp = modlist;
	struct modlisttype *temp2;
	
	sprintf(tempstring, "%d,%d", muchrect.left, muchrect.top);
	WritePrivateProfileString("MuchFX", "Window", tempstring, plugin_ini);

	sprintf(tempstring, "%d", windowshademode);
	WritePrivateProfileString("MuchFX", "WindowShade", tempstring, plugin_ini);
		
	sprintf(tempstring, "%d", windowdocked);
	WritePrivateProfileString("MuchFX", "WindowDocked", tempstring, plugin_ini);
	
	*tempstring = '\0';

	// Unload DLL's

	while (temp != NULL)
	{
		if (temp != modlist)
			strcat(tempstring, " ");
		
		strcat(tempstring, temp->dllPath);
		sprintf(curridx, ",%d", temp->dllModule);
		strcat(tempstring, curridx);
		sprintf(curridx, ",%d", temp->dllModuleEn);
		strcat(tempstring, curridx);

		if (temp->configThreadHandle)
		{
			PostThreadMessage(temp->configThreadId, WM_QUIT, 0, 0);

			WaitForSingleObject(temp->configThreadHandle, INFINITE);
		}
	
		if (temp->dllType == 1)
			temp->module.v1->Quit(temp->module.v1);
		else
			temp->module.v2->Quit(temp->module.v2);

		FreeLibrary(temp->dllInst);
		free(temp->dllPath);

		temp2 = temp;
		temp = temp->next;
		free(temp2);
	}

	modlist = NULL;

	WritePrivateProfileString("MuchFX", "Plugins", tempstring, plugin_ini);
}

// quit (opposite of init()). Destroys the window, unregisters the window class
void quit(struct winampDSPModule *this_mod)
{
	SendMessage(mainDialog, WM_CLOSE, 0, 0);
//	DestroyWindow(mainDialog);

	PostThreadMessage(mainThreadId, WM_QUIT, 0, 0);
	WaitForSingleObject(mainThreadHandle, INFINITE);

	removecache();

	DeleteObject(hFont);
	DeleteObject(hBrush1);
	DeleteObject(hBrush2);
	DeleteObject(hbmpSource);

	mainThreadHandle = NULL;
}

// YEAH. This is the only useful code (?)
int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate)
{
	struct modlisttype *temp;

	temp = NULL;
	temp = modlist;
	while (temp != NULL)
	{
		if (temp->dllModuleEn)
		{
			if (temp->dllType == 1)
			{
				temp->module.v1->sRate = srate;
				temp->module.v1->nCh = nch;
				temp->module.v1->blockSize = numsamples;
				temp->module.v1->ModifySamples(temp->module.v1, samples);
			}
			else
				numsamples = temp->module.v2->ModifySamples(temp->module.v2, samples, numsamples, bps, nch, srate);
		}
		temp = temp->next;
	}

	return numsamples;
}

// CAPTAIN CLAW WAS HERE.
LRESULT CALLBACK CallWndProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode < 0)  /* do not process message */
		return CallNextHookEx(dragHook, nCode, wParam, lParam);


	if (windowdocked)
	{
		if (nCode == HC_ACTION)
		{
			if (((CWPSTRUCT *)lParam)->hwnd == mod.hwndParent)
			{
				switch (((CWPSTRUCT *)lParam)->message) {
				case WM_MOVE:					
					{
						RECT r;

						GetWindowRect(mod.hwndParent, &r);
						r.left = clickMuch.left + r.left - clickWinamp.left;
						r.top = clickMuch.top + r.top - clickWinamp.top;

						if (windowshademode) 
							MoveWindow(mainDialog, r.left, r.top, 275, 14, TRUE);
						else 
							MoveWindow(mainDialog, r.left, r.top, 275, 116, TRUE);

						GetWindowRect(mainDialog, &muchrect);
					}
					break;

				case WM_SIZE:
					{
						RECT winamprect;

						GetWindowRect(mod.hwndParent, &winamprect);

						switch (windowdocked) {
						case 1:
							if (windowshademode) 
								MoveWindow(mainDialog, winamprect.left, winamprect.top-14, 275, 14, TRUE);
							else 
								MoveWindow(mainDialog, winamprect.left, winamprect.top-116, 275, 116, TRUE);
							break;
						case 2:
							if (windowshademode) 
								MoveWindow(mainDialog, winamprect.right, winamprect.top, 275, 14, TRUE);
							else 
								MoveWindow(mainDialog, winamprect.right, winamprect.top, 275, 116, TRUE);
							break;
						case 3:
							if (windowshademode) 
								MoveWindow(mainDialog, winamprect.left, winamprect.bottom, 275, 14, TRUE);
							else 
								MoveWindow(mainDialog, winamprect.left, winamprect.bottom, 275, 116, TRUE);
							break;
						case 4:
							if (windowshademode) 
								MoveWindow(mainDialog, winamprect.left-275, winamprect.top, 275, 14, TRUE);
							else 
								MoveWindow(mainDialog, winamprect.left-275, winamprect.top, 275, 116, TRUE);
							break;
						}

						GetWindowRect(mod.hwndParent, &clickWinamp);
						GetWindowRect(mainDialog, &muchrect);
						clickMuch = muchrect;
					}
					break;
				}
			}        
		}	
	}

    return CallNextHookEx(dragHook, nCode, wParam, lParam);
}

//
//  FUNCTION: GetMain(HWND, UINT, UINT, LONG)
//
//  MESSAGES:
//	
//	WM_INITDIALOG - intializes the page
//	WM_NOTIFY - processes the notifications sent to the page
//	WM_COMMAND - saves the id of the choice selected
//
BOOL APIENTRY GetMain(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{
	RECT rItem;
	RECT wItem;
	RECT r2Item;
	POINT cpnt, cpnt2;

	int i;
	int newX, newY;

	switch (message) {
    case WM_ENABLE:
        if (windowEnable)
        {
            EnableWindow(hDlg, TRUE);
            SetFocus(hDlg);
			SetActiveWindow(hDlg);
        }
        else
			windowEnable = TRUE;

        break;
	case WM_SETFOCUS:
		{
			HDC hdcSource;
			HDC hdcDest;

			windowfocus = TRUE;

			hdcDest = GetWindowDC(hDlg);
			hdcSource = CreateCompatibleDC(hdcDest);
			SelectObject(hdcSource, hbmpSource);	

			BitBlt(hdcDest,
				0,
				0,
				275, windowshademode ? 14 : 12,
				hdcSource,
				0, windowshademode ? 128 : 0, 
				SRCCOPY);

			DeleteDC(hdcSource); 
			ReleaseDC(hDlg, hdcDest);
		}
		break;
	case WM_KILLFOCUS:
		{
			HDC hdcSource;
			HDC hdcDest;

			windowfocus = FALSE;

			hdcDest = GetWindowDC(hDlg);
			hdcSource = CreateCompatibleDC(hdcDest);
			SelectObject(hdcSource, hbmpSource);	

			BitBlt(hdcDest,
				0,
				0,
				275, windowshademode ? 14 : 12,
				hdcSource,
				0, windowshademode ? 142 : 116,
				SRCCOPY);

			DeleteDC(hdcSource); 
			ReleaseDC(hDlg, hdcDest);
		}
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDC_BUTTONADD: 
			windowEnable = FALSE;
			DialogBox(mod.hDllInstance, MAKEINTRESOURCE(IDD_DIALOGADD), mainDialog, (DLGPROC)GetAdd); 
			break;
		case IDC_BUTTONRELOAD: 
			reloadnode(); 
			break;
		case IDC_BUTTONREM: 
			removenode(); 
			break;
		case IDC_BUTTONCONFIG: 
			confignode(); 
			break;
		case IDC_BUTTONUP: 
			if (scrollindex > 0)
			{
				scrollindex--;
				if (scrollindex < scrollstart)
					scrollstart--;
			}
			InvalidateRect(mainDialog, NULL, FALSE);
			break;
		case IDC_BUTTONDOWN: 
			if (scrollindex < (scrollcount - 1))
			{
				scrollindex++;
				if (scrollindex > (scrollstart + 3))
					scrollstart++;
			}
			InvalidateRect(mainDialog, NULL, FALSE);
			break;
		case IDC_BUTTONSCRLUP: 
			if (scrollstart)
			{
				scrollstart--;
				if (scrollindex > (scrollstart + 3))
					scrollindex = scrollstart + 3;
			}
			InvalidateRect(mainDialog, NULL, FALSE);
			break;
		case IDC_BUTTONSCRLDOWN:
			if (scrollstart < (scrollcount - 4))
			{
				scrollstart++;
				if (scrollindex < scrollstart)
					scrollindex = scrollstart;
			}
			InvalidateRect(mainDialog, NULL, FALSE);
			break;		
		case IDC_BUTTONHOME:
			scrollstart = 0;
			if (scrollcount)
				scrollindex = 0;
			InvalidateRect(mainDialog, NULL, FALSE);
			break;
		case IDC_BUTTONEND:
			if (scrollcount)
			{
				if (scrollcount > 4)
					scrollstart = scrollcount - 4;
				scrollindex = scrollcount - 1;
			}
			InvalidateRect(mainDialog, NULL, FALSE);
			break;
		case IDC_BUTTONPGUP:
			if (scrollindex != scrollstart)
				scrollindex = scrollstart;
			else
			{
				scrollstart -= 4;
				scrollindex -= 4;
				if (scrollstart < 0)
				{
					scrollstart = 0;
					scrollindex = 0;
				}
			}			
			InvalidateRect(mainDialog, NULL, FALSE);
			break;
		case IDC_BUTTONPGDN:
			if (scrollindex != (scrollstart + 3))
			{
				scrollindex = scrollstart + 3;
				if (scrollindex > (scrollcount - 1))
				{
					scrollindex = scrollcount - 1;
					scrollstart = scrollcount - 4;
					if (scrollstart < 0)
						scrollstart = 0;
				}
			}
			else
			{
				scrollstart += 4;
				scrollindex += 4;
				if (scrollstart >= (scrollcount - 4))
				{
					scrollstart = scrollcount - 4;
					scrollindex = scrollcount - 1;
				}
			}			
			InvalidateRect(mainDialog, NULL, FALSE);
			break;
		case IDC_BUTTONMOVEUP:
			movenodeup();
			break;
		case IDC_BUTTONMOVEDOWN:
			movenodedown();
			break;
		case IDC_BUTTONSEL:	
			selectnode();
			break;
		case IDC_BUTTONLOAD: 
			windowEnable = FALSE;
			loadlist(); 
			break;
		case IDC_BUTTONSAVE: 
			windowEnable = FALSE;
			savelist(); 
			break;
		case IDC_BUTTONABOUT: 	
			windowEnable = FALSE;
			DialogBox(mod.hDllInstance, MAKEINTRESOURCE(IDD_DIALOGABOUT), mainDialog, (DLGPROC)GetAbout);
			break;
		default:
			return SendMessage(mod.hwndParent,message,wParam,lParam);
		}
		return 0;

	case WM_USER:
	case WM_COPYDATA:
		return SendMessage(mod.hwndParent,message,wParam,lParam);

	case WM_LBUTTONDBLCLK:
		cpnt.x = LOWORD(lParam);
		cpnt.y = HIWORD(lParam);
// Check windowshade
		rItem.top = 0;
		rItem.bottom = 14;
		rItem.left = 0;
		rItem.right = 263;

		if (PtInRect(&rItem, cpnt))
		{
			windowshade(mainDialog);
			return 0;
		}
// Check for confignode		
		rItem.top = 22;
		rItem.bottom = 74;
		rItem.left = 11;
		rItem.right = 255;

		if (PtInRect(&rItem, cpnt))
		{
			i = (cpnt.y - 22) / 13;
			scrollindex = scrollstart + i;

			rItem.top = 23 + i * 13; 
			rItem.bottom = 34 + i * 13;
			rItem.left = 16;
			rItem.right = 27;

			if (scrollindex >= scrollcount)
				scrollindex = scrollcount - 1;
			else
			{
				if (PtInRect(&rItem, cpnt))
					selectnode();
				else				
					confignode();
			}

			return 0;
		}
	case WM_LBUTTONDOWN:
		cpnt.x = LOWORD(lParam);
		cpnt.y = HIWORD(lParam);
// Check buttons
		for (i = 0; i < 9; i++)
		{
			rItem.top = butTab[i].y;
			rItem.bottom = butTab[i].y + butTab[i].sy;
			rItem.left = butTab[i].x;
			rItem.right = butTab[i].x + butTab[i].sx;

			if (PtInRect(&rItem, cpnt))
			{
				buttonnum = i;
				buttonpress = TRUE;
				DrawButton(buttonnum, TRUE);

				SetCapture(mainDialog);
				return 0;
			}					
		}
// Check scroll
		rItem.top = 22;
		rItem.bottom = 74;
		rItem.left = 11;
		rItem.right = 255;
		if (PtInRect(&rItem, cpnt))
		{
			i = (cpnt.y - 22) / 13;
			scrollindex = scrollstart + i;

			if (scrollindex >= scrollcount)
				scrollindex = scrollcount - 1;

			rItem.top = 23 + i * 13; 
			rItem.bottom = 34 + i * 13;
			rItem.left = 16;
			rItem.right = 27;

			if (PtInRect(&rItem, cpnt))
				selectnode();
			else				
				InvalidateRect(mainDialog, NULL, FALSE);

			scrollenable = TRUE;
			SetCapture(mainDialog);

			return 0;
		}
// Check scroll bar
		rItem.top = 20;
		rItem.bottom = 77;
		rItem.left = 260;
		rItem.right = 268;
		if (PtInRect(&rItem, cpnt))
		{
			scrollbarenable = TRUE;
			
			if (scrollcount > 4)
			{
				scrollstart = (cpnt.y - 20) * (scrollcount - 3) / 57;
				if (scrollindex < scrollstart)
					scrollindex = scrollstart;
				else if (scrollindex > (scrollstart + 3))
					scrollindex = scrollstart + 3;
			}
			else
				scrollstart = 0;

			InvalidateRect(mainDialog, NULL, FALSE);		
			SetCapture(mainDialog);
			return 0;
		}
// Check SCROLL UP
		rItem.top = 79;
		rItem.bottom = 85;
		rItem.left = 258;
		rItem.right = 270;
		if (PtInRect(&rItem, cpnt))
		{
			SendMessage(mainDialog, WM_COMMAND, IDC_BUTTONSCRLUP, 0);
			return 0;
		}
// Check SCROLL DOWN
		rItem.top = 85;
		rItem.bottom = 91;
		rItem.left = 258;
		rItem.right = 270;
		if (PtInRect(&rItem, cpnt))
		{
			SendMessage(mainDialog, WM_COMMAND, IDC_BUTTONSCRLDOWN, 0);
			return 0;
		}
// Check caption
		rItem.top = 0;
		rItem.bottom = 14;
		rItem.left = 0;
		rItem.right = 275;

		if (PtInRect(&rItem, cpnt))
		{
			windowmove = TRUE;
	
			GetWindowRect(mainDialog, &clickWin);
			GetCursorPos(&clickPoint);
			
			clickDim.x = clickWin.right - clickWin.left;
			clickDim.y = clickWin.bottom - clickWin.top;

			SetCapture(mainDialog);
			return 0;
		}
		return 0;

	case WM_LBUTTONUP:		
		if (scrollenable)
		{
			scrollenable = FALSE;
			ReleaseCapture();
			return 0;
		}

		if (scrollbarenable)
		{
			scrollbarenable = FALSE;
			ReleaseCapture();
			InvalidateRect(mainDialog, NULL, FALSE);
			return 0;
		}

		if (buttonpress)
		{
			buttonpress = FALSE;
			ReleaseCapture();				 
			if (buttonnum != -1)
			{						
				DrawButton(buttonnum, FALSE);
			
				switch (buttonnum) {
				case 0:
					windowEnable = FALSE;
					DialogBox(mod.hDllInstance, MAKEINTRESOURCE(IDD_DIALOGADD), mainDialog, (DLGPROC)GetAdd);
					break;
				case 1:
					removenode();
					break;
				case 2:
					confignode();
					break;
				case 3:
					movenodedown();
					break;
				case 4:
					movenodeup();
					break;
				case 5:
					windowEnable = FALSE;
					loadlist();
					break;
				case 6:
					windowEnable = FALSE;
					savelist();
					break;
				case 7:
					windowEnable = FALSE;
					DialogBox(mod.hDllInstance, MAKEINTRESOURCE(IDD_DIALOGABOUT), mainDialog, (DLGPROC)GetAbout);
					break;
				case 8:
					windowshade(mainDialog);
					break;
				}
			}
			return 0;
		}
		
		if (windowmove)
		{
			windowmove = FALSE;
			ReleaseCapture();
			return 0;
		}
		return 0;

	case WM_MOUSEWHEEL:
		if ((short)HIWORD(wParam) > 0) {
			rItem.top = 79;
			rItem.bottom = 85;
			SendMessage(mainDialog, WM_COMMAND, IDC_BUTTONSCRLUP, 0);
		} else {
			rItem.top = 85;
			rItem.bottom = 91;
			SendMessage(mainDialog, WM_COMMAND, IDC_BUTTONSCRLDOWN, 0);
		}
		return 0;

	case WM_MOUSEMOVE: 
		cpnt.x = LOWORD(lParam);
		cpnt.y = HIWORD(lParam);

		if (scrollenable)
		{
			GetCursorPos(&cpnt2);

			cpnt2.y -= muchrect.top;

			rItem.top = 22;
			rItem.bottom = 74;
			rItem.left = 11;
			rItem.right = 255;

			cpnt2.x = 11;
			if (cpnt2.y < 22)
				cpnt2.y = 22;
			else if (cpnt2.y > 73)
				cpnt2.y = 73;

			if (PtInRect(&rItem, cpnt2))
			{
				i = (cpnt2.y - 22) / 13;
				scrollindex = scrollstart + i;

				if (scrollindex >= scrollcount)
					scrollindex = scrollcount - 1;

				InvalidateRect(mainDialog, NULL, FALSE);
			}
			return 0;
		}

		if (scrollbarenable)
		{						
			GetCursorPos(&cpnt2);

			cpnt2.y -= muchrect.top;

			rItem.top = 20;
			rItem.bottom = 77;
			rItem.left = 260;
			rItem.right = 268;

			cpnt2.x = 260;
			if (cpnt2.y < 20)
				cpnt2.y = 20;
			else if (cpnt2.y > 76)
				cpnt2.y = 76;

			if (PtInRect(&rItem, cpnt2))
			{
				if (scrollcount > 4)
				{
					scrollstart = (cpnt2.y - 20) * (scrollcount - 3) / 57;
					if (scrollindex < scrollstart)
						scrollindex = scrollstart;
					else if (scrollindex > (scrollstart + 3))
						scrollindex = scrollstart + 3;
				}
				else
					scrollstart = 0;

				InvalidateRect(mainDialog, NULL, FALSE);		
			}
			return 0;
		}

		if (buttonpress)
		{
			if (buttonnum == -1)
			{
				for (i = 0; i < 9; i++)
				{
					rItem.top = butTab[i].y;
					rItem.bottom = butTab[i].y + butTab[i].sy;
					rItem.left = butTab[i].x;
					rItem.right = butTab[i].x + butTab[i].sx;

					if (PtInRect(&rItem, cpnt))
					{
						buttonnum = i;
						DrawButton(buttonnum, TRUE);
						return 0;
					}					
				}
			}
			else
			{
				rItem.top = butTab[buttonnum].y;
				rItem.bottom = butTab[buttonnum].y + butTab[buttonnum].sy;
				rItem.left = butTab[buttonnum].x;
				rItem.right = butTab[buttonnum].x + butTab[buttonnum].sx;

				if (!PtInRect(&rItem, cpnt))
				{
					DrawButton(buttonnum, FALSE);
					buttonnum = -1;
					return 0;
				}					
			}
			return 0;
		}					

		if (windowmove)
		{
			GetCursorPos(&cpnt2);

			rItem.top		= clickWin.top + cpnt2.y - clickPoint.y;
			rItem.bottom	= clickWin.bottom + cpnt2.y - clickPoint.y;
			rItem.left		= clickWin.left + cpnt2.x - clickPoint.x;
			rItem.right		= clickWin.right + cpnt2.x - clickPoint.x;

			newX = rItem.left;
			newY = rItem.top;

			GetWindowRect(mod.hwndParent, &wItem);
// Check for below
			r2Item.top = wItem.bottom - WIND_BORDER;
			r2Item.bottom = wItem.bottom + WIND_BORDER;
			r2Item.left = wItem.left;
			r2Item.right = wItem.right;

			cpnt.x = rItem.left;
			cpnt.y = rItem.top;
			cpnt2.x = rItem.right;
			cpnt2.y = rItem.top;
				
			if (PtInRect(&r2Item, cpnt) || PtInRect(&r2Item, cpnt2))
			{
				GetWindowRect(mod.hwndParent, &clickWinamp);
				GetWindowRect(mainDialog, &clickMuch);

				windowdocked = 3;
				newY = wItem.bottom;
				if (rItem.right < wItem.left + WIND_BORDER)
					newX = wItem.left - clickDim.x;
				else if (rItem.left > wItem.left - WIND_BORDER && 
					rItem.left < wItem.left + WIND_BORDER)
					newX = wItem.left;
				else if (rItem.right > wItem.right - WIND_BORDER && 
					rItem.right < wItem.right + WIND_BORDER)
					newX = wItem.right - clickDim.x;
				else if (rItem.left > wItem.right - WIND_BORDER)
					newX = wItem.right;
			}
			else
// Check for above
			{
			r2Item.top = wItem.top - WIND_BORDER;
			r2Item.bottom = wItem.top + WIND_BORDER;
			r2Item.left = wItem.left;
			r2Item.right = wItem.right;

			cpnt.x = rItem.left;
			cpnt.y = rItem.bottom;
			cpnt2.x = rItem.right;
			cpnt2.y = rItem.bottom;
				
			if (PtInRect(&r2Item, cpnt) || PtInRect(&r2Item, cpnt2))
			{
				GetWindowRect(mod.hwndParent, &clickWinamp);
				GetWindowRect(mainDialog, &clickMuch);

				windowdocked = 1;
				newY = wItem.top - clickDim.y;
				if (rItem.right < wItem.left + WIND_BORDER)
					newX = wItem.left - clickDim.x;
				else if (rItem.left > wItem.left - WIND_BORDER && 
					rItem.left < wItem.left + WIND_BORDER)
					newX = wItem.left;
				else if (rItem.right > wItem.right - WIND_BORDER && 
					rItem.right < wItem.right + WIND_BORDER)
					newX = wItem.right - clickDim.x;
				else if (rItem.left > wItem.right - WIND_BORDER)
					newX = wItem.right;
			}
			else
// Check for left
			{
			r2Item.top = wItem.top;
			r2Item.bottom = wItem.bottom;
			r2Item.left = wItem.left - WIND_BORDER;
			r2Item.right = wItem.left + WIND_BORDER;

			cpnt.x = rItem.right;
			cpnt.y = rItem.top;
			cpnt2.x = rItem.right;
			cpnt2.y = rItem.bottom;
				
			if (PtInRect(&r2Item, cpnt) || PtInRect(&r2Item, cpnt2))
			{
				GetWindowRect(mod.hwndParent, &clickWinamp);
				GetWindowRect(mainDialog, &clickMuch);

				windowdocked = 4;
				newX = wItem.left - clickDim.x;
				if (rItem.bottom < wItem.top + WIND_BORDER)
					newY = wItem.top - clickDim.y;
				else if (rItem.top > wItem.top - WIND_BORDER && 
					rItem.top < wItem.top + WIND_BORDER)
					newY = wItem.top;
				else if (rItem.bottom > wItem.bottom - WIND_BORDER && 
					rItem.bottom < wItem.bottom + WIND_BORDER)
					newY = wItem.bottom - clickDim.y;
				else if (rItem.top > wItem.bottom - WIND_BORDER)
					newY = wItem.bottom;
			}
			else
// Check for right
			{
			r2Item.top = wItem.top;
			r2Item.bottom = wItem.bottom;
			r2Item.left = wItem.right - WIND_BORDER;
			r2Item.right = wItem.right + WIND_BORDER;

			cpnt.x = rItem.left;
			cpnt.y = rItem.top;
			cpnt2.x = rItem.left;
			cpnt2.y = rItem.bottom;
				
			if (PtInRect(&r2Item, cpnt) || PtInRect(&r2Item, cpnt2))
			{
				GetWindowRect(mod.hwndParent, &clickWinamp);
				GetWindowRect(mainDialog, &clickMuch);

				windowdocked = 2;
				newX = wItem.right;
				if (rItem.bottom < wItem.top + WIND_BORDER)
					newY = wItem.top - clickDim.y;
				else if (rItem.top > wItem.top - WIND_BORDER && 
					rItem.top < wItem.top + WIND_BORDER)
					newY = wItem.top;
				else if (rItem.bottom > wItem.bottom - WIND_BORDER && 
					rItem.bottom < wItem.bottom + WIND_BORDER)
					newY = wItem.bottom - clickDim.y;
				else if (rItem.top > wItem.bottom - WIND_BORDER)
					newY = wItem.bottom;
			}
			else
				windowdocked = 0;
			}
			}
			}
// Move
			MoveWindow(mainDialog, 
				newX,
				newY,
				clickDim.x,
				clickDim.y,
				TRUE);

			GetWindowRect(mainDialog, &muchrect);
			return 0;
		}
		return 0;

	case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdcDest;

			if (hdcDest = BeginPaint(hDlg,&ps))
			{
				HDC hdcSource;

				hdcSource = CreateCompatibleDC(hdcDest);
				SelectObject(hdcSource, hbmpSource);

				if (windowfocus)
				{
					BitBlt(hdcDest,
						0,
						0,
						275, windowshademode ? 14 : 12,
						hdcSource,
						0, windowshademode ? 128 : 0, 
						SRCCOPY);
				}
				else
				{
					BitBlt(hdcDest,
						0,
						0,
						275, windowshademode ? 14 : 12,
						hdcSource,
						0, windowshademode ? 142 : 116,
						SRCCOPY);
				}

				if (!windowshademode)
				{					
					struct modlisttype *temp = modlist;
					RECT r;
					int counter;
	
					counter = scrollstart;
					while (counter--)
						temp = temp->next;

					BitBlt(hdcSource,
						0,
						12,
						275, 104,
						hdcSource,
						0, 12,
						SRCCOPY);

					SelectObject(hdcSource, hFont);
					SetBkMode(hdcSource, TRANSPARENT);
					SetTextColor(hdcSource, GetPixel(hdcSource, 266, 156));
					SetTextAlign(hdcSource, TA_TOP | TA_LEFT);

					for (counter = 0; counter <= 3; counter++)
					{
						r.top = 22 + counter * 13;
						r.bottom = 35 + counter * 13;
						r.left = 11;
						r.right = 255;

						if (counter >= (scrollcount - scrollstart))
							FillRect(hdcSource, &r, hBrush1);
						else
						{
							FillRect(hdcSource, &r, (counter == (scrollindex - scrollstart)) ? hBrush2 : hBrush1);
		
							BitBlt(hdcSource,
								16,
								23 + counter * 13,
								11, 11,
								hdcSource,
								243 + 12 * temp->dllModuleEn, 156, 
								SRCCOPY);

							r.left = 32;

							if (temp->dllType == 1)
								ExtTextOut(hdcSource, 32, 22 + counter * 13, 
									ETO_CLIPPED, 
									&r, 
									temp->module.v1->description,
									strlen(temp->module.v1->description), NULL);
							else
								ExtTextOut(hdcSource, 32, 22 + counter * 13, 
									ETO_CLIPPED, 
									&r, 
									temp->module.v2->description,
									strlen(temp->module.v2->description), NULL);

							temp = temp->next;
						}
					}
		
					BitBlt(hdcSource,
						260,
						18,
						8, 61,
						hdcSource,
						275, 18, 
						SRCCOPY);

					BitBlt(hdcSource,
						260,
						20 + ( (scrollcount <= 4) ? 0 : 
							(scrollstart > (scrollcount - 4)) ? 40 :
							40 * (scrollstart) / (scrollcount - 4)
								),
						8, 18,
						hdcSource,
						scrollbarenable ? 235 : 227, 156,
						SRCCOPY);

					BitBlt(hdcDest,
						0,
						12,
						275, 104,
						hdcSource,
						0, 12,
						SRCCOPY);
				}
	
				DeleteDC(hdcSource); 				

				EndPaint(hDlg,&ps);
			}
		}
		return 0;
	
	case WM_CLOSE:
		closeup();
		break;	
	case WM_CREATE:
		SetWindowText(hDlg, PROGRAMNAME);
		return 0;
    case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}

	return(DefWindowProc(hDlg,message,wParam,lParam));
}

// Commands

void movenodeup(void)
{
	struct modlisttype *prev;
	struct modlisttype *temp;
	struct modlisttype *temp2;
	struct modlisttype *next;
	int counter;
	
	temp = modlist;
	prev = NULL;

	if (scrollindex > 0)
	{
		counter = scrollindex - 1;
		while (counter--)
		{
			prev = temp;
			temp = temp->next;
		}

		temp2 = temp->next;
		next = temp2->next;

		if (prev == NULL)
			modlist = temp2;
		else
			prev->next = temp2;

		temp2->next = temp;
		temp->next = next;

		scrollindex--;
		if (scrollindex < scrollstart)
			scrollstart--;

		InvalidateRect(mainDialog, NULL, FALSE);
	}
}

void movenodedown(void)
{
	struct modlisttype *prev;
	struct modlisttype *temp;
	struct modlisttype *temp2;
	struct modlisttype *next;
	int counter;
	
	temp = modlist;
	prev = NULL;

	if (scrollindex < (scrollcount - 1))
	{
		counter = scrollindex;
		while (counter--)
		{
			prev = temp;
			temp = temp->next;
		}

		temp2 = temp->next;
		next = temp2->next;

		if (prev == NULL)
			modlist = temp2;
		else
			prev->next = temp2;

		temp2->next = temp;
		temp->next = next;

		scrollindex++;
		if (scrollindex > (scrollstart + 3))
			scrollstart++;
		
		InvalidateRect(mainDialog, NULL, FALSE);
	}
}

// Adds node w/ data in dspmoduleP, dllInst, dllPath, dllModule, dllModuleEn
int addnode(void)
{
	struct modlisttype *temp;
	struct modlisttype *prev;
	BOOL otherInstFound = FALSE;

	temp = modlist;
	prev = NULL;

	if (dllType == 1)
	{
		while (temp != NULL)
		{
			prev = temp;

			if (!strcmp(temp->dllPath, dllPath))
			{
				if (temp->dllType == 1)
				{
					if (!strcmp(temp->module.v1->description, dspmoduleP1->description))
					otherInstFound = TRUE;
				}
				else if (!strcmp(temp->module.v2->description, dspmoduleP1->description))
					otherInstFound = TRUE;
			}

			temp = temp->next;
		}
	}
	else
	{
		while (temp != NULL)
		{
			prev = temp;

			if (!strcmp(temp->dllPath, dllPath))
			{
				if (temp->dllType == 1)
				{
					if (!strcmp(temp->module.v1->description, dspmoduleP->description))
						otherInstFound = TRUE;
				}
				else if (!strcmp(temp->module.v2->description, dspmoduleP->description))
					otherInstFound = TRUE;
			}

			temp = temp->next;
		}
	}

	if (otherInstFound)
		return 1;

	if (dllType == 1)
	{
		if (dspmoduleP1->Init(dspmoduleP1))
			return 2;
		if (dspmoduleP1->Restart(dspmoduleP1))
			return 2;
	}
	else
	{
		if (dspmoduleP->Init(dspmoduleP))
			return 2;
	}
		
	temp = (struct modlisttype *) calloc(1, sizeof(struct modlisttype));
	if (!temp)
		return 3;
	
	if (prev == NULL)
		modlist = temp;
	else
		prev->next = temp;

	temp->dllType = dllType;
	temp->dllPath = (char *) calloc(1, strlen(dllPath) + 1);
	if (temp->dllPath)
		strcpy(temp->dllPath, dllPath);
	else
	{
		free(temp);
		return 3;
	}

	temp->dllModule = dllModule;
	temp->dllModuleEn = dllModuleEn;
	temp->dllInst = dllInst;

	temp->configThreadHandle = NULL;	
	temp->configThreadId = 0;
	
	if (dllType == 1)
		temp->module.v1 = dspmoduleP1;
	else
		temp->module.v2 = dspmoduleP;

	temp->next = NULL;

	scrollcount++;
	scrollindex = scrollcount - 1;
	if (scrollcount > 4)
		scrollstart = scrollcount - 4;
	
	InvalidateRect(mainDialog, NULL, FALSE);

	return 0;
}

unsigned long configThread(struct modlisttype *temp)
{
	if (temp->dllType == 1)
		temp->module.v1->Config(temp->module.v1);
	else
		temp->module.v2->Config(temp->module.v2);

	temp->configThreadHandle = NULL;	
	temp->configThreadId = 0;

	return 0;
}

void confignode(void)
{
	struct modlisttype *temp;
	int counter;
	
	temp = modlist;

	if (scrollindex >= 0)
	{
		counter = scrollindex;
		while (counter--)
			temp = temp->next;

		if (!(temp->configThreadHandle))
		{
			temp->configThreadHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) &configThread,
				temp, 0, (LPDWORD) &(temp->configThreadId));
		}
	}
}

void removenode(void)
{
	struct modlisttype *prev;
	struct modlisttype *temp;
	int counter;

	prev = NULL;
	temp = modlist;

	if (scrollindex >= 0)
	{
		counter = scrollindex;
		while (counter--)
		{
			prev = temp;
			temp = temp->next;
		};

		if (prev)
			prev->next = temp->next;
		else	
			modlist = temp->next;

		if (temp->configThreadHandle)
		{
			PostThreadMessage(temp->configThreadId, WM_QUIT, 0, 0);

			WaitForSingleObject(temp->configThreadHandle, INFINITE);
		}
		
		if (temp->dllType == 1)
			temp->module.v1->Quit(temp->module.v1);
		else
			temp->module.v2->Quit(temp->module.v2);

		FreeLibrary(temp->dllInst);

		free(temp->dllPath);
		free(temp);

		scrollcount--;
		if (!scrollcount)
			scrollindex = -1;
		else 
		{
			if (scrollindex == scrollcount)
				scrollindex = scrollcount - 1;
		
			if (scrollindex < scrollstart)
				scrollstart--;
		}

		InvalidateRect(mainDialog, NULL, FALSE);
	}	
}

void selectnode(void)
{
	struct modlisttype *temp;
	int counter;
	
	temp = modlist;

	if (scrollindex >= 0 && scrollindex < scrollcount)
	{
		counter = scrollindex;
		while (counter--)
			temp = temp->next;

		temp->dllModuleEn = ! temp->dllModuleEn;
		if (temp->dllType == 1)
			temp->module.v1->Restart(temp->module.v1);
		
		InvalidateRect(mainDialog, NULL, FALSE);
	}
}

void reloadnode(void)
{
	struct modlisttype *temp;
	int counter;
	
	temp = modlist;

	if (scrollindex >= 0)
	{
		counter = scrollindex;
		while (counter--)
			temp = temp->next;

		if (temp->dllType == 1)
			temp->module.v1->Restart(temp->module.v1);
		else
		{
			char tempfile[MAX_PATH];
			static winampDSPHeader *pluginheaderP;
			
			if (temp->configThreadHandle)
			{
				PostThreadMessage(temp->configThreadId, WM_QUIT, 0, 0);

				WaitForSingleObject(temp->configThreadHandle, INFINITE);
			}
			
			temp->module.v2->Quit(temp->module.v2);

			FreeLibrary(temp->dllInst);

			sprintf(tempfile, "%s\\%s", plugindir, temp->dllPath);
			temp->dllInst = LoadLibrary((LPCSTR) tempfile);

			pluginheaderP = ((winampDSPGetHeaderType) GetProcAddress(temp->dllInst, "winampDSPGetHeader2"))();

			temp->module.v2 = pluginheaderP->getModule(temp->dllModule);
			temp->module.v2->hwndParent = mainDialog;
    		temp->module.v2->hDllInstance = temp->dllInst;

			temp->configThreadHandle = NULL;
			temp->configThreadId = 0;

			temp->module.v2->Init(temp->module.v2);
		}
	}
}

void loadlist(void)
{
	OPENFILENAME ofn;
	char szFile[MAX_PATH]; 

	strcpy(szFile, "*.mfx\0");

	ofn.lStructSize			= sizeof(OPENFILENAME);
	ofn.hwndOwner			= mainDialog;
	ofn.lpstrFilter			= "MuchFX� settings (*.mfx)\0*.mfx\0\0";
	ofn.lpstrCustomFilter	= NULL;
	ofn.nFilterIndex		= 1;
	ofn.lpstrFile			= szFile;
	ofn.nMaxFile			= sizeof(szFile);
	ofn.lpstrFileTitle		= NULL;
	ofn.nMaxFileTitle		= 0;
	ofn.lpstrInitialDir		= plugindir;
	ofn.lpstrTitle			= "";
	ofn.Flags				= OFN_EXPLORER |
							  OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST |
							  OFN_HIDEREADONLY;
	ofn.nFileOffset			= 0;
	ofn.nFileExtension		= 0;
	ofn.lpstrDefExt			= "MFX";
	
	if (GetOpenFileName(&ofn)) 
	{
		winampDSPGetHeaderType headerProc;
		winampDSPGetHeaderType1 headerProc1;
		struct modlisttype *temp;
		struct modlisttype *temp2;
		char tempstring[1024] = "";
		char *token;
		char *token2;
		char *tokenp;


		temp = modlist;
		*tempstring = '\0';

		// Clear list

		while (temp != NULL)
		{
			if (temp->configThreadHandle)
			{
				PostThreadMessage(temp->configThreadId, WM_QUIT, 0, 0);

				WaitForSingleObject(temp->configThreadHandle, INFINITE);
			}
		
			if (temp->dllType == 1)
				temp->module.v1->Quit(temp->module.v1);
			else
				temp->module.v2->Quit(temp->module.v2);

			FreeLibrary(temp->dllInst);
			free(temp->dllPath);

			temp2 = temp;
			temp = temp->next;
			free(temp2);
		}

		modlist = NULL;
		scrollcount = 0;
		scrollindex = -1;

		GetPrivateProfileString("MuchFX", "Plugins", "", tempstring, 1024, szFile);
		token = strtok(tempstring, " ");
		while (token)
		{
			token2 = token;
	
			while (*token != ',' && *token != '\0')
				token++;
	
			if (*token != '\0')
			{
				*token = '\0';
				strcpy(dllPath, token2);
				tokenp = ++token;
	
				while (*token != ',' && *token != '\0')
					token++;
				
				if (*token != '\0')
				{
					*token = '\0';
					token++;
				}

				dllModule = atoi(tokenp);
				if (*token != '\0')
					dllModuleEn = atoi(token);
				else	
					dllModuleEn = TRUE;

				sprintf(szFile, "%s\\%s", plugindir, dllPath);
				dllInst = LoadLibrary((LPCSTR) szFile);

				if (dllInst)
				{
					headerProc = (winampDSPGetHeaderType) GetProcAddress(dllInst, "winampDSPGetHeader2");
					headerProc1 = (winampDSPGetHeaderType1) GetProcAddress(dllInst, "winampDSPGetHeader");

					if (headerProc)
					{						
						dspheaderP = headerProc();
						if (dspheaderP->version == DSP_HDRVER)
						{
							dllType = 2;
							dspmoduleP = dspheaderP->getModule(dllModule);
							if (dspmoduleP)
							{
								dspmoduleP->hwndParent = mainDialog;
	    						dspmoduleP->hDllInstance = dllInst;

								if (addnode())
									FreeLibrary(dllInst);
							}
							else
								FreeLibrary(dllInst);
						}
					}
					else if (headerProc1)
					{						
						dspheaderP1 = headerProc1();
						if (dspheaderP1->version == DSP_HDRVER_1)
						{
							dllType = 1;
							dspmoduleP1 = dspheaderP1->getModule(dllModule);
							if (dspmoduleP1)
							{
								dspmoduleP1->hwndParent = mainDialog;
	    						dspmoduleP1->hDllInstance = dllInst;
	    						dspmoduleP1->sRate = 44100;
								dspmoduleP1->nCh = 2;
	    						dspmoduleP1->blockSize = 576;

								if (addnode())
									FreeLibrary(dllInst);
							}
							else
								FreeLibrary(dllInst);
						}
					}
					else
						FreeLibrary(dllInst);
				}
			}

			token = strtok(NULL, " ");
		}
	}
}

void savelist(void)
{
	OPENFILENAME ofn;
	char szFile[MAX_PATH];

	strcpy(szFile, "*.mfx\0");

	ofn.lStructSize			= sizeof(OPENFILENAME);
	ofn.hwndOwner			= mainDialog;
	ofn.lpstrFilter			= "MuchFX� settings (*.mfx)\0*.mfx\0\0";
	ofn.lpstrCustomFilter	= NULL;
	ofn.nFilterIndex		= 1;
	ofn.lpstrFile			= szFile;
	ofn.nMaxFile			= sizeof(szFile);
	ofn.lpstrFileTitle		= NULL;
	ofn.nMaxFileTitle		= 0;
	ofn.lpstrInitialDir		= plugindir;
	ofn.lpstrTitle			= "";
	ofn.Flags				= OFN_EXPLORER |
							  OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST |
							  OFN_HIDEREADONLY;
	ofn.nFileOffset			= 0;
	ofn.nFileExtension		= 0;
	ofn.lpstrDefExt			= "MFX";
	
	if (GetSaveFileName(&ofn)) 
	{
		struct modlisttype *temp = modlist;
		char tempstring[1024] = "";
		char curridx[16];

		*tempstring = '\0';

		// Save settings

		while (temp != NULL)
		{
			if (temp != modlist)
				strcat(tempstring, " ");
			
			strcat(tempstring, temp->dllPath);
			sprintf(curridx, ",%d", temp->dllModule);
			strcat(tempstring, curridx);
			sprintf(curridx, ",%d", temp->dllModuleEn);
			strcat(tempstring, curridx);

			temp = temp->next;
		}

		WritePrivateProfileString("MuchFX", "Plugins", tempstring, szFile);
	}
}

// Extracts the filename
// Format: Description (FILENAME)

void extrName(char *filename)
{
	int pos;

	pos = strlen(filename) - 1;
	filename[pos] = '\0';

	while (pos--)
	{
		if (filename[pos] == '(')
		{
			strcpy(filename, filename + pos + 1);
			break;
		}
	}
}

// Updates the DSP List, returnes winamp plugin version (1, 2)
int updateDspLib(HWND hDlg)
{
	winampDSPGetHeaderType headerProc;
	winampDSPGetHeaderType1 headerProc1;
	
	winampDSPModule *plugindspmoduleP;
	winampDSPModule1 *plugindspmoduleP1;

	char tempfile[MAX_PATH];
	int index = 0;

	if (dllInst)
		FreeLibrary(dllInst);
	
	SendDlgItemMessage(hDlg, IDC_MODULE, CB_RESETCONTENT, 0, 0);

	sprintf(tempfile, "%s\\%s", plugindir, dllPath);
	dllInst = LoadLibrary((LPCSTR) tempfile);

	if (dllInst)
	{
		headerProc = (winampDSPGetHeaderType) GetProcAddress(dllInst, "winampDSPGetHeader2");
		headerProc1 = (winampDSPGetHeaderType1) GetProcAddress(dllInst, "winampDSPGetHeader");

		if (headerProc)
		{						
			dspheaderP = headerProc();
			if (dspheaderP->version == DSP_HDRVER)
			{
				while ((plugindspmoduleP = dspheaderP->getModule(index)) != NULL)
				{
					SendDlgItemMessage(hDlg, IDC_MODULE, CB_ADDSTRING, 0, (LPARAM)(LPCSTR) plugindspmoduleP->description);
					index++;
				}
			}

			SendDlgItemMessage(hDlg, IDC_MODULE, CB_SETCURSEL, 0, 0);
			return 2;		
		}
		else if (headerProc1)
		{						
			dspheaderP1 = headerProc1();
			if (dspheaderP1->version == DSP_HDRVER_1)
			{
				while ((plugindspmoduleP1 = dspheaderP1->getModule(index)) != NULL)
				{
					SendDlgItemMessage(hDlg, IDC_MODULE, CB_ADDSTRING, 0, (LPARAM)(LPCSTR) plugindspmoduleP1->description);
					index++;
				}
			}

			SendDlgItemMessage(hDlg, IDC_MODULE, CB_SETCURSEL, 0, 0);
			return 1;
		}
	}
	return 0;
}

//
//  FUNCTION: GetAdd(HWND, UINT, UINT, LONG)
//
//  MESSAGES:
//	
//	WM_INITDIALOG - intializes the page
//	WM_NOTIFY - processes the notifications sent to the page
//	WM_COMMAND - saves the id of the choice selected
//
BOOL APIENTRY GetAdd(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{
	winampDSPGetHeaderType1 headerProc1;
	winampDSPGetHeaderType headerProc;

	winampDSPHeader1 *pluginDSPHeaderP1;
	winampDSPHeader *pluginDSPHeaderP;

	char tempstring[MAX_PATH];
	int index;

	struct _finddata_t fileinfo;
	int next;
	long hFile;

	switch (message) {
	case WM_INITDIALOG:
		dllInst = NULL;
		dspheaderP = NULL;
		dspheaderP1 = NULL;
		dspmoduleP = NULL;
		dspmoduleP1 = NULL;
	
		SendDlgItemMessage(hDlg, IDC_LIST, LB_RESETCONTENT, 0, 0);

		sprintf(tempstring, "%s\\dsp_*.dll", plugindir);
		hFile = _findfirst(tempstring, &fileinfo);

		if (hFile != -1)
		{				
			next = 0;
			while (next == 0)
			{
				struct dspcachetype *temp;

				temp = dspcache;

				while (temp)
				{
					if (!stricmp(fileinfo.name, temp->dllPath))
						break;
					
					temp = temp->next;
				};

				if (temp)
				{
					sprintf(tempstring, "%s (%s)", temp->description, temp->dllPath);
					SendDlgItemMessage(hDlg, IDC_LIST, LB_ADDSTRING, 0, (LPARAM)(LPCSTR) tempstring);
				}
				else
				{
					sprintf(tempstring, "%s\\%s", plugindir, fileinfo.name);
					dllInst = LoadLibrary((LPCSTR) tempstring);

					if (dllInst)
					{
						headerProc = (winampDSPGetHeaderType) GetProcAddress(dllInst, "winampDSPGetHeader2");
						headerProc1 = (winampDSPGetHeaderType1) GetProcAddress(dllInst, "winampDSPGetHeader");

						if (headerProc)
						{						
							pluginDSPHeaderP = headerProc();
							if (pluginDSPHeaderP->version == DSP_HDRVER)
							{
								if (strncmp(pluginDSPHeaderP->description, "MuchFX", 6) != 0)
								{
									addcache(fileinfo.name, pluginDSPHeaderP->description, TRUE);
									sprintf(tempstring, "%s (%s)", pluginDSPHeaderP->description, fileinfo.name);
									SendDlgItemMessage(hDlg, IDC_LIST, LB_ADDSTRING, 0, (LPARAM)(LPCSTR) tempstring);
								}
							}
						}
						else if (headerProc1)
						{						
							pluginDSPHeaderP1 = headerProc1();
							if (pluginDSPHeaderP1->version == DSP_HDRVER_1)
							{
								if (strncmp(pluginDSPHeaderP1->description, "MuchFX", 6) != 0)
								{
									addcache(fileinfo.name, pluginDSPHeaderP1->description, TRUE);
									sprintf(tempstring, "%s (%s)", pluginDSPHeaderP1->description, fileinfo.name);
									SendDlgItemMessage(hDlg, IDC_LIST, LB_ADDSTRING, 0, (LPARAM)(LPCSTR) tempstring);
								}
							}
						}

						FreeLibrary(dllInst);
					}
				}
				
				next = _findnext(hFile, &fileinfo);
			}
		}

		dllInst = NULL;

		SendDlgItemMessage(hDlg, IDC_LIST, LB_SETCURSEL, 0, 0);

		if (SendDlgItemMessage(hDlg, IDC_LIST, LB_GETCOUNT, 0, 0) != 0)
		{
			index = SendDlgItemMessage(hDlg, IDC_LIST, LB_GETCURSEL, 0, 0);
			if (index != CB_ERR)
			{					
				SendDlgItemMessage(hDlg, IDC_LIST, LB_GETTEXT, index, (LPARAM)(LPCSTR) dllPath);
				extrName(dllPath);
				dllType = updateDspLib(hDlg);
			}

			dllModule = SendDlgItemMessage(hDlg, IDC_MODULE, CB_GETCURSEL, 0, 0);
			if (dllModule != CB_ERR)
			{						
				if (dllType == 2)
				{
					dspmoduleP = dspheaderP->getModule(dllModule);
					if (dspmoduleP)
					{
						dspmoduleP->hwndParent = mainDialog;
	    				dspmoduleP->hDllInstance = dllInst;
					}
				}
				else
				{
					dspmoduleP1 = dspheaderP1->getModule(dllModule);
					if (dspmoduleP1)
					{
						dspmoduleP1->hwndParent = mainDialog;
    					dspmoduleP1->hDllInstance = dllInst;
	    				dspmoduleP1->sRate = 44100;
	    				dspmoduleP1->nCh = 2;
	    				dspmoduleP1->blockSize = 576;
					}
				}
			}
		}
		break;

	case WM_COMMAND:
		switch(HIWORD(wParam)) {
		case CBN_DBLCLK:
			PostMessage(hDlg, WM_COMMAND, MAKEWPARAM(IDOK, BN_CLICKED), 0);
			break;
		case CBN_SELCHANGE:
			if (LOWORD(wParam) == IDC_LIST)
			{
			    index = SendDlgItemMessage(hDlg, IDC_LIST, LB_GETCURSEL, 0, 0);
				if (index != CB_ERR)
				{					
					SendDlgItemMessage(hDlg, IDC_LIST, LB_GETTEXT, index, (LPARAM)(LPCSTR) dllPath);
					extrName(dllPath);
					dllType = updateDspLib(hDlg);
				}
			}

			dllModule = SendDlgItemMessage(hDlg, IDC_MODULE, CB_GETCURSEL, 0, 0);
			if (dllModule != CB_ERR)
			{						
				if (dllType == 2)
				{
					dspmoduleP = dspheaderP->getModule(dllModule);
					if (dspmoduleP)
					{
						dspmoduleP->hwndParent = mainDialog;
	    				dspmoduleP->hDllInstance = dllInst;
					}
				}
				else
				{
					dspmoduleP1 = dspheaderP1->getModule(dllModule);
					if (dspmoduleP1)
					{
						dspmoduleP1->hwndParent = mainDialog;
    					dspmoduleP1->hDllInstance = dllInst;
	    				dspmoduleP1->sRate = 44100;
	    				dspmoduleP1->nCh = 2;
	    				dspmoduleP1->blockSize = 576;
					}
				}
			}
			break;
		case BN_CLICKED:
			switch(LOWORD(wParam)) {
			case IDC_CONFIG:
				if (dllType == 2)
				{
					if (dspmoduleP)
					{
						dspmoduleP->hwndParent = hDlg;
    					dspmoduleP->hDllInstance = dllInst;
						dspmoduleP->Config(dspmoduleP);
						dspmoduleP->hwndParent = mainDialog;
					}
				}
				else
				{
					if (dspmoduleP1)
					{
						dspmoduleP1->hwndParent = hDlg;
    					dspmoduleP1->hDllInstance = dllInst;
	    				dspmoduleP1->sRate = 44100;
	    				dspmoduleP1->nCh = 2;
	    				dspmoduleP1->blockSize = 576;
						dspmoduleP1->Config(dspmoduleP1);
						dspmoduleP1->hwndParent = mainDialog;
					}
				}
				break;
			case IDOK:
				dllModuleEn = TRUE;
				if (dllInst)
				{
					switch (addnode()) {
					case 0:
						EndDialog(hDlg, TRUE);
						break;
					case 1:
						MessageBox(hDlg,"Can't load two instances of a plug-in.",
							PROGRAMNAME,MB_OK | MB_ICONEXCLAMATION);
						break;
					case 2:
						MessageBox(hDlg,"Error loading module.",
							PROGRAMNAME,MB_OK | MB_ICONSTOP);
						FreeLibrary(dllInst);
						EndDialog(hDlg, TRUE);
						break;
					case 3:
						MessageBox(mainDialog,"Not enough memory.",
							PROGRAMNAME,MB_OK | MB_ICONSTOP);
						FreeLibrary(dllInst);
						EndDialog(hDlg, TRUE);
						break;					
					}
				}
				else
					EndDialog(hDlg, TRUE);
				break;
			case IDCANCEL:
				if (dllInst)
					FreeLibrary(dllInst);	
				dllInst = NULL;
				EndDialog(hDlg, TRUE);
				break;
			}
			break;
		default:
			return FALSE;
		}

		break;
	case WM_CLOSE:
		if (dllInst)
			FreeLibrary(dllInst);	
		dllInst = NULL;

		EndDialog(hDlg, TRUE);
		break;
	default:
		return FALSE;
	}
	return TRUE;   
}
//
//  FUNCTION: GetAbout(HWND, UINT, UINT, LONG)
//
//  MESSAGES:
//	
//	WM_INITDIALOG - intializes the page
//	WM_NOTIFY - processes the notifications sent to the page
//	WM_COMMAND - saves the id of the choice selected
//
BOOL APIENTRY GetAbout(
	HWND hDlg,
	UINT message,
	UINT wParam,
	LONG lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			break;		

		case WM_COMMAND:
			if (HIWORD(wParam) == BN_CLICKED)
			{
				switch(LOWORD(wParam)) {
				case IDCANCEL:
					EndDialog(hDlg, TRUE);										
					break;				
				default:
					return FALSE;
				}
			}
			else
				return FALSE;

			break;
		case WM_CLOSE:
			EndDialog(hDlg, TRUE);
			break;
		default:
			return FALSE;
	}
	return TRUE;   
}
