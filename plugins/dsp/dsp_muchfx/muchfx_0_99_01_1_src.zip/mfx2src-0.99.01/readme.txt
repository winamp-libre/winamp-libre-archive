MuchFX� 0.99.01 Source codes
----------------------------

Hi! So you are the chosen! You decided to peek into the source code and fix MuchFX�! Bless you! :o)

Here's some help:

- Build

To build, simply create a new .dll project in Microsoft Visual C++ (or whatever you use)

Add the .cpp and .rc file, and read the .dll

- To-do list

Here's a to-do list to get started:

* Shoutcast bugfix (it should load, and correctly update the playlist info)
* Skinning support

- Publishing

If you want me to publish your work, write an email to:

muchfx-publish@ressl.com.ar

I'll try to do it asap.

- License

MuchFX� is released under the General Public GNU License, please read the gpl.txt for more information on what that means.