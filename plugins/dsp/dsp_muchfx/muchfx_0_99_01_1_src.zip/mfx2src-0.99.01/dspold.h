// DSP plugin interface

// notes:
// any window that remains in foreground should optimally pass unused
// keystrokes to the parent (winamp's) window, so that the user
// can still control it. As for storing configuration,
// Configuration data should be stored in <dll directory>\plugin.ini
// (look at the vis plugin for configuration code)

typedef struct winampDSPModule1 {
  char *description;            // description
  HWND hwndParent;                      // parent window (filled in by calling app)
  HINSTANCE hDllInstance;       // instance handle to this DLL (filled in by calling app)
  int sRate;                            // sample rate (filled in by calling app)
  int nCh;                                      // number of channels (filled in by calling app)
  int blockSize;                        // number of samples in block (filled in by calling app)

  void (*Config)(struct winampDSPModule1 *this_mod);  // configuration dialog (if needed)
  int (*Init)(struct winampDSPModule1 *this_mod);     // 0 on success, creates window, etc (if needed)
  int (*Restart)(struct winampDSPModule1 *this_mod);  // reinitializes plugin

  // modify waveform samples: number of short int's passed is nCh*blockSize (nCh*blockSize*2 bytes)
  void (*ModifySamples)(struct winampDSPModule1 *this_mod, short *samples);

  // modify layer 3 scalefactors. xr[channel][0][band], where band is { 0...575 }
  void (*ModifyLayer3XR)(struct winampDSPModule1 *this_mod, float xr[2][32][18]);

  // modify layer 2 scalefactors. this is a little more complex, because layer 2 frames
  // have two granules. The format is subbands[channel][band/18][band%18 + granule*18],
  // where band is { 0...575 } and granule is either 0 or 1
  void (*ModifyLayer2Subband)(struct winampDSPModule1 *this_mod, float subbands[2][32][36]);

  void (*Quit)(struct winampDSPModule1 *this_mod);    // called when unloading

  void *userData; // user data, optional
} winampDSPModule1;

typedef struct {
  int version;       // DSP_HDRVER
  char *description; // description of library
  winampDSPModule1* (*getModule)(int);	// module retrieval function
} winampDSPHeader1;

// exported symbols
typedef winampDSPHeader1* (*winampDSPGetHeaderType1)();

// header version: 0x10 == 0.10 == current
#define DSP_HDRVER_1 0x10