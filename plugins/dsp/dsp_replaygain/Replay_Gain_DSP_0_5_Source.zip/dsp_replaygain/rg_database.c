#include "rg_database.h"
#include "LinkedList.h"

#include <stdio.h>
#include <string.h>
#include <malloc.h>

int db_create_and_load(const char *db_filename, LinkedList **db) {
        FILE *f;
        char buffer[1023] = "";
        float gain = 0;
        float peak = 0;

	*db = new_LinkedList();

        if((f = fopen(db_filename, "r"))==NULL) {
                return 0;
        }

        fseek(f, 0, SEEK_END);
        if(ftell(f)==0) {
                goto exit;
        }
        fseek(f, 0, SEEK_SET);

        while(!feof(f)&&fscanf(f, "\"%[^\"]\" , %f , %f\n", &buffer, &gain, &peak)) {
                db_new(buffer, *db, gain, peak);
                peak = 0;
        }

exit:
        fclose(f);

        return 1;
}

char *filename_nopath(char *filename) {
	char *slash = strrchr(filename, '\\');

	if(!slash) {
		return filename;
	} else {
		return slash + 1;
	}
}

int db_find_str(int ignore_paths, char *findstr, const LinkedList *db, rg_data **record) {
	LinkedList_record *r = db->first;

	if(ignore_paths) {
		findstr = filename_nopath(findstr);
	}

	if(ignore_paths) {
		while(r!=NULL) {
			rg_data *data = r->data;
			if(stricmp(data->filename_nopath, findstr)==0) {
				*record = data;
				return 1;
			}
			r = r->next;
		}
	} else {
		while(r!=NULL) {
			rg_data *data = r->data;
			if(stricmp(data->filename, findstr)==0) {
				*record = data;
				return 1;
			}
			r = r->next;
		}
	}

        return 0;
}

void db_new(const char *filename, LinkedList *db, float replay_gain, float peak) {
	rg_data *r = malloc(sizeof(rg_data));

        r->filename = malloc(strlen(filename)+1);
	strcpy(r->filename, filename);

	r->filename_nopath = filename_nopath(r->filename);

        r->replay_gain = replay_gain;
        r->peak = peak;

	LinkedList_add_last(db, r);
}

int db_save(const char *db_filename, const LinkedList *db) {
        FILE *f;
	LinkedList_record *r;

        if((f = fopen(db_filename, "w"))==NULL) {
                return 0;
        }

        r = db->first;

        while(r!=NULL) {
		rg_data *data = r->data;
                fprintf(f, "\"%s\", %+2.2f, %.5f\n", data->filename, data->replay_gain, data->peak);
                r = r->next;
        }

        fclose(f);

        return 1;
}

static void db_free_func(rg_data *data) {
	free(data->filename);
	free(data);
}

void db_free(LinkedList *db) {
	destroy_LinkedList(db, db_free_func);
}


