#include <math.h>

/* hard limiter still very slow, i know */

#define HL_FLOATS

void apply_replay_gain_16bit(float gain, float peak, short int samples[], int numsamples, int channels, int reduce_gain_on_clipping, int hard_limit) {
	int i;
	float scale;

	scale = (float)pow(10.0, gain/20);

	if((scale * peak > 1.0) && hard_limit) {

		for(i=0;i<numsamples*channels;i++) {

//  sample *= pow(10., preamp_db/20);
//
//  /* hard 6dB limiting */
//  if (sample < -0.5)
//          sample = tanh((sample + 0.5) / (1-0.5)) * (1-0.5) - 0.5;
//  else if (sample > 0.5)
//          sample = tanh((sample - 0.5) / (1-0.5)) * (1-0.5) + 0.5;

#ifdef HL_FLOATS
			float sample = samples[i] / 32768.0f;

			sample *= scale;

			if(sample < -0.5) {
				sample = (float)( tanh((sample+0.5) / (1-0.5)) * (1-0.5) - 0.5 );
			} else {
				if(sample > 0.5) {
					sample = (float)( tanh((sample-0.5) / (1-0.5)) * (1-0.5) + 0.5 );
				}
			}

			samples[i] = (int)(sample * 32768.0f + 0.5f);

#endif

		}
	} else {
		int igain16;

		if(reduce_gain_on_clipping && (scale * peak > 1.0)) {
			scale = 1.0f / peak;
		}

		igain16 = (int)((scale * 65536)+0.5);

		for(i=0;i<numsamples*channels;i++) {
			samples[i] = (samples[i] * igain16) >> 16;
		}
	}
}