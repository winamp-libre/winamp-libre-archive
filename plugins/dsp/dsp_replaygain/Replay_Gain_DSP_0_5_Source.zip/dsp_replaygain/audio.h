#ifndef __AUDIO_H
#define __AUDIO_H

void uninterleave_to_floats_and_scan_peaks(float left[], float right[], const signed short readbuffer[], long samples, int channels, int *ppeak);

#endif __AUDIO_H