#ifndef __LINKEDLIST_H
#define __LINKEDLIST_H

typedef struct LinkedList_record_ {
	void *data;
	struct LinkedList_record_ *next;
} LinkedList_record;

typedef struct {
	LinkedList_record *first;
	LinkedList_record *last;
	int records;
} LinkedList;

LinkedList* new_LinkedList();
void        destroy_LinkedList(LinkedList *ll, void (data_free_func)(void *data));
void        LinkedList_add_last(LinkedList *ll, void *data);
void        LinkedList_add_first(LinkedList *ll, void *data);

#endif//__LINKEDLIST_H
