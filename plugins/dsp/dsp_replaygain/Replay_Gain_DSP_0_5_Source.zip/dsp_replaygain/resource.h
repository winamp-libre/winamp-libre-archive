//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resources.rc
//
#define IDD_STATUS                      101
#define IDD_CONFIG                      102
#define IDD_LOG                         103
#define IDD_GENERAL                     104
#define IDD_AUDIO                       105
#define IDD_ABOUT                       107
#define IDC_STATIC1                     1000
#define IDC_CURRENTFILE                 1001
#define IDC_STATIC2                     1002
#define IDC_STATIC3                     1003
#define IDC_STATIC4                     1004
#define IDC_RGCALCTIMES                 1005
#define IDC_RGAPPLIEDTIMES              1006
#define IDC_DISCARDED                   1006
#define IDC_STATIC5                     1007
#define IDC_DBCOUNT                     1008
#define IDC_STATUSTEXT                  1009
#define IDC_LOG                         1010
#define IDC_GAIN                        1010
#define IDC_STATUS                      1011
#define IDC_CLIP_ADJUST                 1011
#define IDC_LOGEDIT                     1012
#define IDC_HARD_LIMITER                1012
#define IDC_CLEAR                       1013
#define IDC_ANALYZING                   1013
#define IDC_CHECK_CALC                  1014
#define IDC_CHECK_APPLY                 1015
#define IDC_PREAMP                      1017
#define IDC_CHECK_REDUCE_GAIN_WHEN_CLIPPING 1019
#define IDC_ENABLED                     1024
#define IDC_CHECK_NEVERDISCARD          1025
#define IDC_CHECK_ALWAYS_CALC           1026
#define IDC_ABOUT                       1032
#define IDC_STATIC_PREAMP               1033
#define IDC_TAB1                        1034
#define IDC_EDIT1                       1035
#define IDC_CHECK_SKIPKNOWN             1036
#define IDC_RADIO_REDUCE_GAIN_WHEN_CLIPPING 1037
#define IDC_RADIO_HARD_LIMIT            1038
#define IDC_STATIC_REPLAY_LEVEL         1039
#define IDC_CHECK_IGNORE_PATHS          1040
#define IDC_FILE_RG                     1042
#define IDC_FILE_PEAK                   1043
#define IDC_ERRORSTATUS                 1044
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
