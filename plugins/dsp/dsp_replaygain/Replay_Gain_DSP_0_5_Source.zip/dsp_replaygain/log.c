#include <stdio.h>
#include <windows.h>

#include "dialogs.h"
#include "resource.h"
#include "log.h"

#define UNALIGNED_LOG_BUFSIZE 1024
#define LOG_BUFSIZE ((UNALIGNED_LOG_BUFSIZE+3) & ~3)

__declspec(naked) void __cdecl logf(const char *format, ...) {
        static char buf[LOG_BUFSIZE];
        static int temp_retaddr;

        __asm {
                pop     eax                     // the return addr
                mov     temp_retaddr, eax
                push    LOG_BUFSIZE
                push    offset buf
#ifdef _DEBUG                                   // weird, the assembler behaves
                                                // differently whether debugging or not
                call    _snprintf
#else
                call    dword ptr [_snprintf]
#endif
                push    offset buf 
                call    append_to_log
#ifdef _DEBUG
                call    dword ptr [OutputDebugString]
#endif
                pop     eax
                mov     eax, temp_retaddr
                mov     [esp], eax
                ret
        }
}

//------------------------------------------------------------------------------

HWND log_edit;
HWND log_dialog;

/* when debugging we also call OutputDebugString() after this function, so we
   leave esp alone here as OutputDebugString() will clean up the stack. When
   not debugging, we *do* clean up the stack by using the stdcall calling
   convention.

   see: logf()
*/

#ifdef _DEBUG
static void __cdecl append_to_log(const char *txt) {
#else
static void __stdcall append_to_log(const char *txt) {
#endif

        char *ptr = malloc(strlen(txt)+1);
        strcpy(ptr, txt);
        /* if successful, the log window's dialog proc will free
           the string */
        if(!PostMessage(log_dialog, WM_ADD_TO_LOG, (LONG)ptr, 0)) {
                free(ptr);
        }
}

//------------------------------------------------------------------------------

typedef struct log_wnd_userdata {
        int min_width;
        int min_height;

        /* variables to change controls' positions and sizes relative to dialog
           size */
        int log_edit_width_diff;
        int log_edit_height_diff;
        int button1_relative_pos_x;
        int button1_relative_pos_y;
        int button2_relative_pos_x;
        int button2_relative_pos_y;
        int check1_relative_pos_x;
        int check1_relative_pos_y;

	HFONT font;
};

BOOL CALLBACK log_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam) {
        WORD wmId = LOWORD(wParam);
        struct log_wnd_userdata *logdata = (void *)GetWindowLong(hwndDlg, GWL_USERDATA);

        switch(uMsg) {
                case WM_INITDIALOG: {
			HDC hdc;
			LOGFONT lf;

                        logdata = malloc(sizeof(struct log_wnd_userdata));
                        SetWindowLong(hwndDlg, GWL_USERDATA, (LONG)logdata);

                        log_edit = GetDlgItem(hwndDlg, IDC_LOGEDIT);
                        log_dialog = hwndDlg;

			// Get a 10 point Courier New font
			hdc = GetDC(log_edit);
			memset(&lf, 0, sizeof(LOGFONT));
			lf.lfHeight = -MulDiv(9, GetDeviceCaps(hdc, LOGPIXELSY), 72);
			strcpy(lf.lfFaceName, "Courier New");
			SendMessage(log_edit, WM_SETFONT, (WPARAM)(logdata->font = CreateFontIndirect(&lf)), TRUE);

                        SendMessage(log_edit, EM_SETLIMITTEXT, 0xffffffff, 0);

                        /* remove the windows icon from the caption bar */
                        SetWindowLong(hwndDlg, GWL_EXSTYLE, WS_EX_DLGMODALFRAME);

                        /* GUI controls' size and position stuff */
                        {
                                RECT r, r2;
                                POINT p;

                                /* save min size info */
                                GetWindowRect(hwndDlg, &r);

                                logdata->min_width = r.right - r.left;
                                logdata->min_height = r.bottom - r.top;

                                /* save info about size of edit control for resizing */
                                GetWindowRect(log_edit, &r2);

                                logdata->log_edit_width_diff = r.right - r2.right;
                                logdata->log_edit_height_diff = r.bottom - r2.bottom;

                                /* save info about button position relative to
                                   lower right of the dialog */
                                GetWindowRect(GetDlgItem(hwndDlg, IDCANCEL), &r2);

                                p.x = r2.left;
                                p.y = r2.top;
                                ScreenToClient(hwndDlg, &p);
                                logdata->button1_relative_pos_x = p.x - (r.right - r.left);
                                logdata->button1_relative_pos_y = p.y - (r.bottom - r.top);

                                GetWindowRect(GetDlgItem(hwndDlg, IDC_CLEAR), &r2);

                                p.x = r2.left;
                                p.y = r2.top;
                                ScreenToClient(hwndDlg, &p);
                                logdata->button2_relative_pos_x = p.x - (r.right - r.left);
                                logdata->button2_relative_pos_y = p.y - (r.bottom - r.top);

                                /* lower left */
                                GetWindowRect(GetDlgItem(hwndDlg, IDC_ENABLED), &r2);
                                p.x = r2.left;
                                p.y = r2.top;
                                ScreenToClient(hwndDlg, &p);
                                logdata->check1_relative_pos_x = p.x;
                                logdata->check1_relative_pos_y = p.y - (r.bottom - r.top);
                        }

                        return TRUE;
                }
                case WM_COMMAND: {
                        switch(wmId) {
                                case IDC_CLEAR: {
                                        SetDlgItemText(hwndDlg, IDC_LOGEDIT, "");
                                        return TRUE;
                                }
                                case WM_DESTROY: {
                                        ShowWindow(hwndDlg, SW_HIDE);
                                        return TRUE;
                                }
                        }
                        return FALSE;
                }
                case WM_ADD_TO_LOG: {
                        char *txt = (char *)wParam;

                        if(IsDlgButtonChecked(log_dialog, IDC_ENABLED)) {
                                int length = SendMessage(log_edit, WM_GETTEXTLENGTH, 0, 0);
                                int sl = strlen(txt);

                                SendMessage(log_edit, EM_SETSEL, length, length);
                                SendMessage(log_edit, EM_REPLACESEL, 0, (LPARAM)txt);
                                SendMessage(log_edit, EM_SETSEL, length+sl, length+sl);

                        }

                        /* not sure if this is threadsafe */
                        free(txt);

                        return TRUE;
                }
                case WM_REALLY_DESTROY: {
                        if(lParam == REALLY_MAGIC) {
				DeleteObject(logdata->font);
                                free(logdata);
                                DestroyWindow(hwndDlg);
                                return TRUE;
                        }
                }
                case WM_GETMINMAXINFO: {
                        ((MINMAXINFO *)lParam)->ptMinTrackSize.x = logdata->min_width;
                        ((MINMAXINFO *)lParam)->ptMinTrackSize.y = logdata->min_height;
                        return TRUE;
                }
                case WM_SIZE: {
                        /* GUI controls' size and position stuff */
                        RECT r, r2;

                        GetWindowRect(hwndDlg, &r);
                        GetWindowRect(log_edit, &r2);
                        SetWindowPos(log_edit, 0,
                                0,
                                0,
                                r.right - r2.left - logdata->log_edit_width_diff,
                                r.bottom - r2.top - logdata->log_edit_height_diff,
                                SWP_NOMOVE | SWP_NOOWNERZORDER);

                        SetWindowPos(GetDlgItem(hwndDlg, IDCANCEL), 0,
                                r.right - r.left + logdata->button1_relative_pos_x,
                                r.bottom - r.top + logdata->button1_relative_pos_y,
                                0,
                                0,
                                SWP_NOSIZE | SWP_NOOWNERZORDER);

                        SetWindowPos(GetDlgItem(hwndDlg, IDC_CLEAR), 0,
                                r.right - r.left + logdata->button2_relative_pos_x,
                                r.bottom - r.top + logdata->button2_relative_pos_y,
                                0,
                                0,
                                SWP_NOSIZE | SWP_NOOWNERZORDER);

                        SetWindowPos(GetDlgItem(hwndDlg, IDC_ENABLED), 0,
                                logdata->check1_relative_pos_x,
                                r.bottom - r.top + logdata->check1_relative_pos_y,
                                0,
                                0,
                                SWP_NOSIZE | SWP_NOOWNERZORDER);

                        InvalidateRect(hwndDlg, NULL, FALSE);

                        return TRUE;
                }
        }

        return FALSE;
}
