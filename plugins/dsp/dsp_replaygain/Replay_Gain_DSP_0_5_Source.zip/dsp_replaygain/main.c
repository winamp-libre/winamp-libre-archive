#include "windows.h"
#include "winbase.h"
#include "resource.h"
#include "commctrl.h"

#include "dsp.h"
#include "gain_analysis.h"

#include "rg_database.h"
#include "main.h"
#include "dialogs.h"
#include "audio.h"
#include "log.h"
#include "apply_gain.h"

#include "ticks.h"

#include <string.h>
#include <stdio.h>
#include <math.h>

//char status_error_fn[] = "error getting filename";
char status_error_wavefmt[] = "wave format not supported";
//char status_error_seeking[] = "Idle (discarded calculation due to seeking in file)";
//char status_error_streaming[] = "Idle (not processing streaming)";
char error_db[] = "There was an error loading the database. The plugin is disabled until Winamp is restarted again and the database could be loaded succesfully.";
char rg_title[] = "Replay Gain DSP Plugin";
char status_error_ga_rate[] = "Analysis: error calling InitGainAnalysis(), sampling rate may not be supported";
char status_error_ga_analysis[] = "Analysis: error calling AnalyzeSamples()";

char dll_name[] = "dsp_replaygain.dll";
char db_name[] =  "replaygains.csv";
char ini_name[] = "dsp_replaygain.ini";

static VOID CALLBACK timer_proc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime);
static void playback_stopped();

winampDSPHeader hdr = {DSP_HDRVER, "Replay Gain DSP v0.5", get_module};

winampDSPModule mod = {
        "Replay Gain",
        NULL,
        NULL,
        config,
        init,
        modify_samples,
        quit
};

static int song_changed = 1;

static int ok;

static HWND winamp_wnd;

static int quitting;

__declspec(dllexport) winampDSPHeader *winampDSPGetHeader2() {
        return &hdr;
}

static winampDSPModule *get_module(int which) {
        if(which==0) {
                return &mod;
        } else {
                return NULL;
        }
}

static void config(struct winampDSPModule *this_mod) {
	if(ok) {
		ShowWindow(dlg_config, SW_SHOW);
		BringWindowToTop(dlg_config);
	} else {
		MessageBox(winamp_wnd, error_db, rg_title, MB_OK | MB_ICONERROR);
	}
}

static int init(struct winampDSPModule *this_mod) {
	char name[MAX_PATH];
        char buf[33];
        size_t len;
	HWND desktop = GetDesktopWindow();

	winamp_wnd = this_mod->hwndParent;

	quitting = 0;
	ok = 1;

	db = 0;
	db_filename = 0;
	filename = 0;
	channel_buffers = 0;
	ini_filename = 0;

	hard_limiter_in_use = 0;
	record = 0;

	current_file_error = 0;

	instance = this_mod->hDllInstance;

	InitCommonControls();

        dlg_log = CreateDialog(instance, MAKEINTRESOURCE(IDD_LOG), desktop, log_proc);
        dlg_config = CreateDialog(instance, MAKEINTRESOURCE(IDD_CONFIG), desktop, config_proc);

	ticks_init();

        /* determine database and ini filenames */

        GetModuleFileName(this_mod->hDllInstance, name, MAX_PATH);

        len = strlen(name);

	/* test if the path to our module ends with dll_name */
        if(len<strlen(dll_name) || stricmp(&name[len-strlen(dll_name)], dll_name)!=0) {
                ok = 0;
        } else {
		/* replace dll_name with the database filename so we open the
		   database in the same directory as the DLL */
		strcpy(&name[len-strlen(dll_name)], db_name);
                db_filename = malloc(strlen(name)+1);
                strcpy(db_filename, name);

		/* replace db_name with the ini filename so we open the ini
		   file in the same directory as the DLL */
		strcpy(&name[strlen(name)-strlen(db_name)], ini_name);
                ini_filename = malloc(strlen(name)+1);
                strcpy(ini_filename, name);

		logf("Loading database: %s\r\n", db_filename);

                if(!db_create_and_load(db_filename, &db)) {
                        ok = 0;
                        logf("Error loading database!\r\n");
			MessageBox(winamp_wnd, error_db, rg_title, MB_OK | MB_ICONERROR);
			return 0;
                }
        }


//                SetDlgItemText(dlg_status, IDC_STATUSTEXT, status_idle);

        itoa(db->records, buf, 10);
        SetDlgItemText(dlg_status, IDC_DBCOUNT, buf);
        logf("Loaded ok, %d records\r\n", db->records);

	/* load config */
	CheckDlgButton(dlg_general, IDC_CHECK_APPLY,
		GetPrivateProfileInt("general", "rg_application", 1, ini_filename));

	CheckDlgButton(dlg_general, IDC_CHECK_CALC,
		GetPrivateProfileInt("general", "rg_calculation", 1, ini_filename));

	CheckDlgButton(dlg_general, IDC_CHECK_NEVERDISCARD,
		GetPrivateProfileInt("general", "rg_calculation_never_discard", 0, ini_filename));

	CheckDlgButton(dlg_general, IDC_CHECK_ALWAYS_CALC,
		GetPrivateProfileInt("general", "rg_calculation_always", 1, ini_filename));

	CheckDlgButton(dlg_general, IDC_CHECK_SKIPKNOWN,
		GetPrivateProfileInt("general", "skip_known", 0, ini_filename));

	CheckDlgButton(dlg_general, IDC_CHECK_IGNORE_PATHS,
		GetPrivateProfileInt("general", "ignore_paths", 0, ini_filename));

	CheckDlgButton(dlg_log, IDC_ENABLED,
		GetPrivateProfileInt("logging", "enabled", 1, ini_filename));

	SendDlgItemMessage(dlg_audio, IDC_PREAMP, TBM_SETPOS, 1, 1);
	SendDlgItemMessage(dlg_audio, IDC_PREAMP, TBM_SETPOS, 1, 0);
	SendDlgItemMessage(dlg_audio, IDC_PREAMP, TBM_SETPOS, 1,
		GetPrivateProfileInt("audio", "pre_amp", 0, ini_filename));

	CheckDlgButton(dlg_audio, IDC_RADIO_REDUCE_GAIN_WHEN_CLIPPING,
		GetPrivateProfileInt("audio", "reduce_gain_when_clipping", 0, ini_filename));

	CheckDlgButton(dlg_audio, IDC_RADIO_HARD_LIMIT,
		!GetPrivateProfileInt("audio", "reduce_gain_when_clipping", 0, ini_filename));

	/* undocumented feature: difference in seconds for discarding calculation
	   is saved in [audio], discarding_difference */
	cfg_difference = GetPrivateProfileInt("audio", "discarding_difference", 4, ini_filename);
	if(cfg_difference<2) {
		cfg_difference = 2;
	}

	/* make sure dialog controls are updated to reflect config */

	SendMessage(dlg_config, WM_UPDATE_GUI, 0, 0);

	timer = SetTimer(NULL, 0, 1000, timer_proc);

        return 0;
}

static void quit(struct winampDSPModule *this_mod) {
        char buf[33];

	quitting = 1;

	KillTimer(NULL, timer);

	if(db) {
		logf("Saving db to %s... ", db_filename);

		if(!db_save(db_filename, db)) {
			logf("\r\nError saving database\r\n");
			MessageBox(winamp_wnd, "Error saving database", "Replay Gain DSP Plugin", MB_OK | MB_ICONERROR);
		} else {
			logf("done\r\n");
		}
		db_free(db);
	}

	if(ok) {
		/* save config settings */
		WritePrivateProfileString("general", "rg_application",
			IsDlgButtonChecked(dlg_general, IDC_CHECK_APPLY)?"1":"0", ini_filename);

		WritePrivateProfileString("general", "rg_calculation",
			IsDlgButtonChecked(dlg_general, IDC_CHECK_CALC)?"1":"0", ini_filename);

		WritePrivateProfileString("general", "rg_calculation_never_discard",
			IsDlgButtonChecked(dlg_general, IDC_CHECK_NEVERDISCARD)?"1":"0", ini_filename);

		WritePrivateProfileString("general", "rg_calculation_always",
			IsDlgButtonChecked(dlg_general, IDC_CHECK_ALWAYS_CALC)?"1":"0", ini_filename);

		WritePrivateProfileString("general", "skip_known",
			IsDlgButtonChecked(dlg_general, IDC_CHECK_SKIPKNOWN)?"1":"0", ini_filename);

		WritePrivateProfileString("general", "ignore_paths",
			IsDlgButtonChecked(dlg_general, IDC_CHECK_IGNORE_PATHS)?"1":"0", ini_filename);

		WritePrivateProfileString("logging", "enabled",
			IsDlgButtonChecked(dlg_log, IDC_ENABLED)?"1":"0", ini_filename);

		itoa(SendDlgItemMessage(dlg_audio, IDC_PREAMP, TBM_GETPOS, 0, 0), buf, 10);
		WritePrivateProfileString("audio", "pre_amp", buf, ini_filename);

		WritePrivateProfileString("audio", "reduce_gain_when_clipping",
			IsDlgButtonChecked(dlg_audio, IDC_RADIO_REDUCE_GAIN_WHEN_CLIPPING)?"1":"0", ini_filename);
	}

        if(dlg_log) {
                SendMessage(dlg_log, WM_REALLY_DESTROY, 0, REALLY_MAGIC);
        }
        if(dlg_config) {
                SendMessage(dlg_config, WM_REALLY_DESTROY, 0, REALLY_MAGIC);
        }

        if(filename) {
                free(filename);
        }
        if(db_filename) {
                free(db_filename);
        }
	if(ini_filename) {
		free(ini_filename);
	}

        if(channel_buffers) {
                /* find the count of channels allocated */
                int i;
                int channels = 1; /* there's at least one */
                while(channel_buffers[channels]!=NULL) {
                        channels++;
                }
                logf("Deallocating buffers for %d channels\r\n", channels);

                for(i=0;i<channels;i++) {
                        free(channel_buffers[i]);
                }
                free(channel_buffers);
        }
}

static VOID CALLBACK timer_proc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime) {
	int status;

        if(SendMessageTimeout(winamp_wnd, WM_USER, 0, 104, SMTO_NORMAL, 50, &status)) {
		if(status!=3&&status!=1&&calculating) {
			playback_stopped();
		}
        }
}

static void playback_stopped() {
	if(calculating) {
		/* check if we need to save data from the old file */
		int diff = abs(samples_processed - samples_should_be);
		float s;

		int never_discard = cfg_dont_discard;

		s = ((float)diff)/sample_rate;
		logf("Analyzed %d samples; full file should be near %d samples, difference: %d (%.2f seconds)\r\n", samples_processed, samples_should_be, diff, s);

		if(!never_discard&&diff>(sample_rate*cfg_difference)) {
			rgs_discarded++;
			logf("Difference more than %d seconds, discarding calculation\r\n", cfg_difference);
		} else {
			/* yep, analyzation/analyzing is complete */

			float g = GetTitleGain();

			/* ? are these values for 83 dB and not for 89 dB ? */
			if(!never_discard&&g<-51.0||g>+51.0) {
				logf("Illegal value for Replay Gain: %+2.2f dB (not between -51.0 dB and +51.0 dB), weird file\r\n", g);
				rgs_discarded++;
			} else {
				rgs_calculated++;
				logf("Accepting calculation\r\n");
				if(can_apply) {
					// 2DO: if bits <> 16 no 32768
					logf("Updating record for \"%s\" from %+2.2f dB to %+2.2f dB, peak from %.5f to %.5f\r\n", filename, record->replay_gain, g, record->peak, peak / 32768.0f);
					record->replay_gain = g;
					record->peak = peak / 32768.0f;
				} else {
					logf("Creating new record (%d) for \"%s\"; %+2.2f dB, peak: %.5f\r\n", db->records+1, filename, g, peak / 32768.0f);
					db_new(filename, db, g, peak / 32768.0f);
				}

				db_save(db_filename, db);

				/* ? are these values for 83 dB and not for 89 dB ? */
				if(g<-23.0||g>+17.0) {
					logf("Warning: Unusual value for Replay Gain: %+2.2f dB (not between -23.0 dB and +17.0 dB), weird file\r\n", g);
				}
			}
		}

		/* free the old filename */
		free(filename);
		filename = 0;
	}

	/* print performance data */
	{
	    double s = (float)samples_processed;

	    __int64 ant = analyze_cycles;
	    __int64 apt = apply_cycles;
	    __int64 ift = i2f_cycles;
	    double  anps = s==0?0:ant / s;
	    double  apps = s==0?0:apt / s;
	    double  ifps = s==0?0:ift / s;
	    double  ans = ant / cpu_clock;
	    double aps = apt / cpu_clock;
	    double ifs = ift / cpu_clock;
	    double total = (float)ant+apt+ift;
	    double anpct = ant/total*100;
	    double appct = apt/total*100;
	    double ifpct = ift/total*100;
	    /* cycles per sample, total seconds, percentage of processing */
	    logf("Performance: i2fp %.1f  %.1f  %.1f%%; analyze %.1f  %.1f  %.1f%%; apply %.1f  %.1f  %.1f%%; all total %.3f\r\n",
		ifps, ifs, ifpct,
		anps, ans, anpct,
		apps, aps, appct,
		total / cpu_clock);
	}

	calculating = 0;
	can_apply = 0;
	record = 0;
	current_file_error = 0;

        PostMessage(dlg_status, WM_UPDATE_FILE_STATUS, 0, 0);
        PostMessage(dlg_status, WM_UPDATE_AUDIO_STATUS, 0, 0);
}

static int check_file_playing(int rate) {
        char *current_filename = 0;
        int pos;
        int length;

        if(!SendMessageTimeout(winamp_wnd, WM_USER, 0, 125, SMTO_NORMAL, 50, &pos)) {
                return 0;
        }

        if(!SendMessageTimeout(winamp_wnd, WM_USER, pos, 211, SMTO_NORMAL, 50, (LONG *)&current_filename)) {
                return 0;
        }

	if(!current_filename) {
		return 0;
	}

        if(!SendMessageTimeout(winamp_wnd, WM_USER, 1, 105, SMTO_NORMAL, 50, &length)) {
                return 0;
        }

        if(filename!=NULL) {

                if(strcmp(current_filename, filename)==0) {
                        /* same file still playing */
                        return 1;
                }

		/* we got a new file */

		playback_stopped();

	}


        /* setup data for new file */

        current_file_error = NULL;

        filename = malloc(strlen(current_filename)+1);
        strcpy(filename, current_filename);

        logf("New file: %s\r\n", current_filename);

        /* retrieve the Replay Gain from the database */

//	ticks_start_counting();

        if(db_find_str(cfg_ignore_paths, current_filename, db, &record)) {
                can_apply = 1;

		if(cfg_skip_known) {
		    PostMessage(winamp_wnd, WM_COMMAND, 40048, 0);
		}
	} else {
		can_apply = 0;
	}

//	ticks_stop_counting();

//	logf("Retrieval took %I64d ticks (%.4f seconds)\r\n", ticks_total, ticks_total / cpu_clock);

        if(cfg_calc&&(!can_apply||cfg_always_calc)) {
                calculating = 1;
                initialized = 0;
                samples_processed = 0;
                sample_rate = rate;
                peak = 0;

                samples_should_be = length * rate;

                logf("Current track info: %d Hz, %d seconds. Should be about %d samples\r\n", rate, length, samples_should_be);
        }

	analyze_cycles = 0;
	apply_cycles = 0;
	i2f_cycles = 0;

        PostMessage(dlg_status, WM_UPDATE_FILE_STATUS, 0, 0);

        return 1;
}

static int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate) {
	if(!(cfg_apply||cfg_calc)) {
		/* nothing to do */
                goto exit;
        }

	if(quitting) {
		return 0;
	}

        if(!check_file_playing(srate)) {
                /* we can't get info about the file the samples belong
                   to, so assume the file playing is unchanged */
        }

	/* check wave format */
        if(bps!=16||nch>2||nch<1) {
                can_apply = 0;
                calculating = 0;
                current_file_error = status_error_wavefmt;
                goto exit;
        }

        if(calculating) {
                if(!initialized) {
                        if(InitGainAnalysis(srate)==INIT_GAIN_ANALYSIS_ERROR) {
                                logf("InitGainAnalysis failed: INIT_GAIN_ANALYSIS_ERROR\r\n");
                                calculating = 0;
                                current_file_error = status_error_ga_rate;
                                /* could still apply Replay Gain though */
                                goto analyze_error;
                        } else {
                                initialized = 1;
                        }
                }

                /* check if the buffers are still big enough */

                if(channel_buffers==NULL) {
                        /* we haven't even allocated them yet... */
                        int i;

                        logf("Allocating buffers for %d channel%s of %d samples, total buffer size %.1f kB\r\n", nch, nch==1?"":"s", numsamples, (nch * numsamples * sizeof(float))/1024.0f);

                        channel_buffers = malloc((nch + 1) * sizeof(float *));

                        for(i=0;i<nch;i++) {
                                channel_buffers[i] = malloc(numsamples * sizeof(float));
                        }
                        channel_buffers[nch] = NULL;
                        buffers_size = numsamples;
                } else {
                        /* find the count of channels allocated */
                        int channels = 1;  /* there's at least one */
                        while(channel_buffers[channels]!=NULL) {
                                channels++;
                        }

                        if(buffers_size<numsamples||channels<nch) {
                                /* enlarge buffers */
                                int i;
                                logf("Enlarging buffers to %d channels of %d samples, total buffer size %.1f kB\r\n", nch, numsamples, (nch * numsamples * sizeof(float))/1024.0f);

                                /* free all buffers. the contents need not be preserved,
                                   so don't use realloc() here */
                                for(i=0;i<channels;i++) {
                                        free(channel_buffers[i]);
                                }

                                free(channel_buffers);
                                channel_buffers = malloc((nch + 1) * sizeof(float *));

                                /* allocate the new buffers for all channels */
                                for(i=0;i<nch;i++) {
                                        channel_buffers[i] = malloc(numsamples * sizeof(float));
                                }
                                channel_buffers[nch] = NULL;
                                buffers_size = numsamples;
                        }
                }

                /* - adjust peak scale when bitdepth changes?
                  (32768 for 16 bit to 128 for 8 bit)
                */

                /* uninterleave the samples and convert them to floats */
		ticks_start_counting();
                uninterleave_to_floats_and_scan_peaks(channel_buffers[0], channel_buffers[1], samples, numsamples, nch, &peak);
		ticks_stop_counting();
		i2f_cycles += ticks_total;

		ticks_start_counting();
                if(AnalyzeSamples(channel_buffers[0], nch==1?NULL:channel_buffers[1], numsamples, nch)==GAIN_ANALYSIS_ERROR) {
                        calculating = 0;
                        current_file_error = status_error_ga_analysis;
                        logf("AnalyzeSamples: GAIN_ANALYSIS_ERROR\r\n");
                        goto analyze_error;
                }
		ticks_stop_counting();
		analyze_cycles += ticks_total;
        }

analyze_error:

        if(can_apply&&cfg_apply) {
                float rg = record->replay_gain;
                float amp = cfg_preamp / 10.0f;
		float scale = (float)pow(10.0, (rg+amp)/20);

		reduce_gain = 0;

                if(cfg_reduce_gain_when_clipping) {
                        if(record->peak>0.01) {
                                reduce_gain = (float)log10(1/record->peak) * 20 - rg - amp;
                                if(reduce_gain>0) {
                                        reduce_gain = 0;
                                }
                        }
                }


		hard_limiter_in_use = (scale * record->peak > 1.0) && !cfg_reduce_gain_when_clipping;

		ticks_start_counting();
                apply_replay_gain_16bit(rg+amp, record->peak, samples, numsamples, nch, cfg_reduce_gain_when_clipping, !cfg_reduce_gain_when_clipping);
		ticks_stop_counting();
		apply_cycles += ticks_total;
        }

        samples_processed += numsamples;

exit:
        PostMessage(dlg_status, WM_UPDATE_AUDIO_STATUS, 0, 0);

        return numsamples;
}