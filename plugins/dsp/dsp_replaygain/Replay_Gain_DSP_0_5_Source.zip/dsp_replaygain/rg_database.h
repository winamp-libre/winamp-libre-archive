#ifndef __RG_DATABASE_H
#define __RG_DATABASE_H

#include <stddef.h>
#include "LinkedList.h"

typedef struct {
	/* keys */
	char *filename;		
	char *filename_nopath;	/* points into filename */

	/* data */
	float replay_gain;	
	float peak;
} rg_data;

int db_create_and_load(const char *db_filename, LinkedList **db);
int db_find_str(int ignore_paths, char *findstr, const LinkedList *db, rg_data **record);
void db_new(const char *filename, LinkedList *db, float replay_gain, float peak);
int db_save(const char *db_filename, const LinkedList *db);
void db_free(LinkedList *db);

char *filename_nopath(char *filename);

#endif __RG_DATABASE_H