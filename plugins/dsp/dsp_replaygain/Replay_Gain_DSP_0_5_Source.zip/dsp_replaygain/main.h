#ifndef __MAIN_H
#define __MAIN_H

#include "dsp.h"
#include "rg_database.h"

winampDSPModule *get_module(int which);

void config(struct winampDSPModule *this_mod);
int init(struct winampDSPModule *this_mod);
void quit(struct winampDSPModule *this_mod);
int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate);

/** DLL global variables
 * Note that each process has its own copy of these, so multiple Winamp
 * instances work fine. The winampDSPModule.userData construct I used 
 * in earlier versions isn't really needed.
 */

HINSTANCE instance;

/* are the current samples being analyzed? */
int calculating;

/* is there a gain calculated for the current file? */
int can_apply;
/* data for the current file if can_apply */
rg_data *record;

/* filename of database */
char *db_filename;
/* filename of .ini */
char *ini_filename;

/* database of RG values */
LinkedList *db;

/* whether InitGainAnalysis has been called */
int initialized;
/* amount of samples analyzed, for checking if file was only played
   partially or if there was seeking. Not bulletproof, but should
   work most of the time */
int samples_processed;
/* amount of samples the file should be according to the length of
   the file from the playlist
   note: not entirely accurate because Winamp will only give length
   in seconds, but good enough for the comparison */
int samples_should_be;
/* samplerate of current file being analyzed */
int sample_rate;
/* current peak */
int peak;

/* performance stats */
__int64 analyze_cycles;
__int64 i2f_cycles;
__int64 apply_cycles;

/* filename of file currently playing */
char *filename;

HWND dlg_status;
HWND dlg_log;
HWND dlg_config;
HWND dlg_general;
HWND dlg_audio;

/* buffers to store samples for each channel
   if NULL, no buffers allocated. if not NULL,
   there are n channel buffers allocated where
   channel_buffers[n] == NULL. then channel_buffers
   is allocated for n+1 pointers */
float **channel_buffers;
/* size of each channel buffer in samples */
int buffers_size;

/* GUI selections */

/* data reflecting user settings from config dialog.
   not synchronized, but that's ok here as the DSP
   processing thread will only read 'em */
int cfg_apply;
int cfg_calc;
int cfg_dont_discard;
int cfg_always_calc;
int cfg_preamp;
int cfg_reduce_gain_when_clipping;	/* 1 = reduce gain; 0 = hard limit */
int cfg_difference;
int cfg_skip_known;
int cfg_ignore_paths;

/* data for status dialog */

/* stats */
int rgs_calculated;
int rgs_discarded;

float reduce_gain;

int hard_limiter_in_use;

/* error string if an error occurred for the current file,
   NULL if everything ok */
char *current_file_error;

/* timer */
UINT timer;

/** Error Messages */

/*extern char status_applying[];
extern char status_calculating[];
extern char status_both[];
extern char status_error_fn[];
extern char status_error_wavefmt[];
//extern char status_error_seeking[];
//extern char status_error_streaming[];
extern char status_error_db[];
extern char status_error_ga_rate[];
extern char status_error_ga_analysis[];
extern char status_applying_but_analysis_error[];
*/
#endif __MAIN_H