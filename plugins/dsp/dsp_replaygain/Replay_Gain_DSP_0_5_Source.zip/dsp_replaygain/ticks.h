#ifndef __TICKS_H
#define __TICKS_H

float cpu_clock;

void ticks_init();
void ticks_start_counting();
void ticks_stop_counting();

__int64 ticks_start;
__int64 ticks_total;
int ticks_overhead;

#endif __TICKS_H