#ifndef __STATUS_WINDOW_H
#define __STATUS_WINDOW_H

#include "windows.h"
#include "main.h"

#define WM_REALLY_DESTROY WM_USER+342
#define REALLY_MAGIC 12335
#define WM_UPDATE_GUI WM_USER+343
#define WM_UPDATE_FILE_STATUS WM_USER+345
#define WM_UPDATE_AUDIO_STATUS WM_USER+346

#define TAB_PAGES 4
 
HWND tab;   
HWND dialog;
HWND tab_dialogs[TAB_PAGES]; 
RECT rect_tab;

int min_width;
int min_height;

/* variables to change controls' positions and sizes relative to dialog
   size */
int tab_width_diff;
int tab_height_diff;
int button1_relative_pos_x;
int button1_relative_pos_y;
int button2_relative_pos_x;
int button2_relative_pos_y;

BOOL CALLBACK status_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK config_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif __STATUS_WINDOW_H
