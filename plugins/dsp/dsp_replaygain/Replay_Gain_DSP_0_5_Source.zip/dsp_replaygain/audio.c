#include <math.h>

#include "audio.h"

#include "log.h"

/* quick hack for multiple channels, but only supports mono/stereo */

/* little endian assumed */

void uninterleave_to_floats_and_scan_peaks(float left[], float right[], const signed short readbuffer[], long samples, int channels, int *ppeak) {
        int i;
        int peak = *ppeak;
        short a, b;

        if(channels==1) {

                for(i=0;i<samples;i++) {
                        a = readbuffer[i];
                        if(abs(a)>peak) {
                                peak = abs(a);
                        }
                        left[i] = (float)a;
                }

        } else {
                /* stereo assumed */

                // 2DO: multiple channels support!

                for(i=0;i<samples;i++) {
                        a = readbuffer[i*2];
                        if(abs(a)>peak) {
                                peak = abs(a);
                        }
                        left[i] = (float)a;

                        b = readbuffer[i*2+1];
                        if(abs(b)>peak) {
                                peak = abs(b);
                        }
                        right[i] = (float)b;
                }
        }

        *ppeak = peak;
}