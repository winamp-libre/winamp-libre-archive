#include "windows.h"
#include "commctrl.h"

#include "main.h"
#include "resource.h"

#include "dialogs.h"

#include "log.h"
#include "rg_database.h"  // for filename_nopath

#include <stdio.h>

void UpdateDlgItemText(HWND dlg, int item, char *str) {
	char buf[256];

	GetDlgItemText(dlg, item, buf, 255);
	if(strcmp(buf, str)) {
		SetDlgItemText(dlg, item, str);
	}
}
//------------------------------------------------------------------------------

/* status tab dialog box */
BOOL CALLBACK status_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam) {
        WORD wmId = LOWORD(wParam);

        switch(uMsg) {
                case WM_INITDIALOG: {
                        return TRUE;
                }
                case WM_UPDATE_FILE_STATUS: {
                        char buf[33];

                        SetDlgItemInt(dlg_status, IDC_RGCALCTIMES, rgs_calculated, FALSE);
                        SetDlgItemInt(dlg_status, IDC_DISCARDED, rgs_discarded, FALSE);
                        SetDlgItemInt(dlg_status, IDC_DBCOUNT, db->records, FALSE);

			if(filename) {
				SetDlgItemText(dlg_status, IDC_CURRENTFILE, filename_nopath(filename));
			} else {
				SetDlgItemText(dlg_status, IDC_CURRENTFILE, "N/A");
			}

			if(record) {
				_snprintf(buf, 199, "%+.2f dB", record->replay_gain);
				SetDlgItemText(dlg_status, IDC_FILE_RG, buf);
				_snprintf(buf, 199, "%.5f", record->peak);
				SetDlgItemText(dlg_status, IDC_FILE_PEAK, buf);
			} else {
				if(filename) {
					SetDlgItemText(dlg_status, IDC_FILE_RG, "not calculated yet");
					SetDlgItemText(dlg_status, IDC_FILE_PEAK, "not calculated yet");
				} else {
					SetDlgItemText(dlg_status, IDC_FILE_RG, "N/A");
					SetDlgItemText(dlg_status, IDC_FILE_PEAK, "N/A");
				}
			}

			return TRUE;
		}
		case WM_UPDATE_AUDIO_STATUS: {
			char buf[200];
			int applying = can_apply&&cfg_apply;

			if(current_file_error) {
				UpdateDlgItemText(dlg_status, IDC_ERRORSTATUS, current_file_error);
			} else {
				UpdateDlgItemText(dlg_status, IDC_ERRORSTATUS, "no error");
			}

			if(applying) {
				_snprintf(buf, 199, "%+.2f dB",  record->replay_gain + cfg_preamp / 10.0f + reduce_gain);
				UpdateDlgItemText(dlg_status, IDC_GAIN, buf);
			} else {
				UpdateDlgItemText(dlg_status, IDC_GAIN, "N/A");
				UpdateDlgItemText(dlg_status, IDC_CLIP_ADJUST, "N/A");
			}

			if(!cfg_reduce_gain_when_clipping && applying) {
				if(hard_limiter_in_use) {
					UpdateDlgItemText(dlg_status, IDC_HARD_LIMITER, "in use");
				} else {
					UpdateDlgItemText(dlg_status, IDC_HARD_LIMITER, "not used");
				}
			} else {
				UpdateDlgItemText(dlg_status, IDC_HARD_LIMITER, "N/A");
			}

			if(cfg_reduce_gain_when_clipping && applying) {
				_snprintf(buf, 199, "%+.2f dB", reduce_gain);
				UpdateDlgItemText(dlg_status, IDC_CLIP_ADJUST, buf);
			} else {
				UpdateDlgItemText(dlg_status, IDC_CLIP_ADJUST, "N/A");
			}
			

			UpdateDlgItemText(dlg_status, IDC_ANALYZING, calculating ? "yes" : (can_apply ? "no" : "N/A"));
			return TRUE;
		}

/*
                        char buf[200];
                        char *newtext;
                        char oldtext[200];
                        int applying = can_apply&&cfg_apply;
                        if(current_file_error!=NULL) {
                                if(applying) {
                                        _snprintf(buf, 199, status_applying_but_analysis_error, gain, rg, amp, reduce_gain);
                                        newtext = buf;
                                } else {
                                        newtext = current_file_error;
                                }
                                goto settext;
                        }

                        if(applying&&!calculating) {
                                _snprintf(buf, 199, status_applying, gain, rg, amp, reduce_gain);
                                newtext = buf;
                                goto settext;
                        }

                        if (applying&&calculating) {
                                _snprintf(buf, 199, status_both, gain, rg, amp, reduce_gain);
                                newtext = buf;
                                goto settext;
                        }

                        if(calculating) {
                                newtext = status_calculating;
                                goto settext;
                        }

                        newtext = status_idle;

settext:
                        if(strcmp(oldtext, newtext)) {
                                SetDlgItemText(hwndDlg, IDC_STATUSTEXT, newtext);
                        }
*/
        }

        return FALSE;
}

//------------------------------------------------------------------------------

/* about tab dialog box */
BOOL CALLBACK about_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam) {
        if(uMsg==WM_INITDIALOG) {

                SetDlgItemText(hwndDlg, IDC_EDIT1,  "Replay Gain Winamp DSP Plugin Copyright (C) 2002 Matthijs Laan <matthijsln@xs4all.nl>\r\n"
                                                    "http://www.xs4all.nl/~walterln/replaygain/\r\n"
                                                    "\r\n" 
                                                    "Replay Gain by David Robinson\r\n"
                                                    "http://www.replaygain.org/\r\n"
                                                    "\r\n"
                                                    "Replay Gain analysis code Copyright (C) 2001 David Robinson, Glen Sawyer and Frank Klemm"
						    "\r\n"
						    "\r\n"
						    "Compiled " __DATE__ " " __TIME__ " CET");
                return TRUE;
        }
        return FALSE;
}

//------------------------------------------------------------------------------

/* audio tab dialog box */
BOOL CALLBACK audio_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam) {
        switch(uMsg) {
                case WM_INITDIALOG: {
                        SendDlgItemMessage(hwndDlg,IDC_PREAMP,TBM_SETRANGE,0,MAKELONG(-150,150));
                        SendDlgItemMessage(hwndDlg,IDC_PREAMP,TBM_SETPOS,TRUE,0);
                        SendDlgItemMessage(hwndDlg,IDC_PREAMP,TBM_SETTICFREQ,10,0);
                        SendDlgItemMessage(hwndDlg,IDC_PREAMP,TBM_SETPOS,1,1);
                        SendDlgItemMessage(hwndDlg,IDC_PREAMP,TBM_SETPOS,1,0);

                        return TRUE;
                }
                case WM_HSCROLL: {
                        HWND wnd = (HWND)lParam;
                        if (wnd == GetDlgItem(hwndDlg,IDC_PREAMP)) {
                                char str[100];
                                int preamp;
                                preamp = SendDlgItemMessage(hwndDlg,IDC_PREAMP,TBM_GETPOS,0,0);
                                _snprintf(str, 99, "%+2.1f dB", preamp / 10.);
                                SetDlgItemText(hwndDlg,IDC_STATIC_PREAMP, str);
				_snprintf(str, 99, "Replay level: %2.1f dB", 89 + preamp/10.);
				SetDlgItemText(hwndDlg,IDC_STATIC_REPLAY_LEVEL, str);

                                cfg_preamp = preamp;

                                return TRUE;
                        }
                        return FALSE;
                }
                case WM_COMMAND: {
                        WORD wNotifyCode = HIWORD(wParam);
                        WORD wID = LOWORD(wParam);
                        HWND hwndCtl = (HWND)lParam;

                        switch(wID) {
				case IDC_RADIO_HARD_LIMIT:
                                case IDC_RADIO_REDUCE_GAIN_WHEN_CLIPPING: {
                                        if(wNotifyCode==BN_CLICKED) {
                                                cfg_reduce_gain_when_clipping = IsDlgButtonChecked(hwndDlg, IDC_RADIO_REDUCE_GAIN_WHEN_CLIPPING);
                                        }
                                        return TRUE;
                                }
                        }
                }
                case WM_UPDATE_GUI: {
                        EnableWindow(GetDlgItem(hwndDlg, IDC_PREAMP), IsDlgButtonChecked(dlg_general, IDC_CHECK_APPLY));

			SendMessage(hwndDlg, WM_HSCROLL, 0, (WPARAM)GetDlgItem(hwndDlg,IDC_PREAMP));

                        cfg_reduce_gain_when_clipping = IsDlgButtonChecked(hwndDlg, IDC_RADIO_REDUCE_GAIN_WHEN_CLIPPING);

                        return TRUE;
                }
        }

        return FALSE;
}

//------------------------------------------------------------------------------

/* preferences (or general options) tab dialog box */
BOOL CALLBACK general_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam) {
        switch(uMsg) {
                case WM_INITDIALOG: {
			return TRUE;
                }
                case WM_COMMAND: {
                        WORD wNotifyCode = HIWORD(wParam);
                        WORD wID = LOWORD(wParam);
                        HWND hwndCtl = (HWND)lParam;

                        if(wNotifyCode==BN_CLICKED) {
                                switch(wID) {
                                        case IDC_CHECK_CALC: {
                                                int a = IsDlgButtonChecked(hwndDlg, IDC_CHECK_CALC);

                                                cfg_calc = a;

                                                EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_ALWAYS_CALC), a);
                                                EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_NEVERDISCARD), a);
                                                return TRUE;
                                        }
                                        case IDC_CHECK_APPLY: {
                                                int a = IsDlgButtonChecked(hwndDlg, IDC_CHECK_APPLY);

                                                cfg_apply = a;

                                                EnableWindow(GetDlgItem(dlg_audio, IDC_PREAMP), a);
                                                return TRUE;
                                        }
                                        case IDC_CHECK_NEVERDISCARD: {
                                                cfg_dont_discard = IsDlgButtonChecked(hwndDlg, IDC_CHECK_NEVERDISCARD);
                                                return TRUE;
                                        }
                                        case IDC_CHECK_ALWAYS_CALC: {
                                                cfg_always_calc = IsDlgButtonChecked(hwndDlg, IDC_CHECK_ALWAYS_CALC);
                                                return TRUE;
                                        }
					case IDC_CHECK_SKIPKNOWN: {
						cfg_skip_known = IsDlgButtonChecked(hwndDlg, IDC_CHECK_SKIPKNOWN);
						return TRUE;
					}
					case IDC_CHECK_IGNORE_PATHS: {
						cfg_ignore_paths = IsDlgButtonChecked(hwndDlg, IDC_CHECK_IGNORE_PATHS);
						return TRUE;
					}
                                }
                        }
                        return FALSE;
                }
                case WM_UPDATE_GUI: {
                        int a = IsDlgButtonChecked(hwndDlg, IDC_CHECK_CALC);

                        cfg_calc = a;
                        EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_ALWAYS_CALC), a);
                        EnableWindow(GetDlgItem(hwndDlg, IDC_CHECK_NEVERDISCARD), a);

                        cfg_always_calc = IsDlgButtonChecked(hwndDlg, IDC_CHECK_ALWAYS_CALC);
                        cfg_dont_discard = IsDlgButtonChecked(hwndDlg, IDC_CHECK_NEVERDISCARD);
                        cfg_apply = IsDlgButtonChecked(hwndDlg, IDC_CHECK_APPLY);
			cfg_skip_known = IsDlgButtonChecked(hwndDlg, IDC_CHECK_SKIPKNOWN);
			cfg_ignore_paths = IsDlgButtonChecked(hwndDlg, IDC_CHECK_IGNORE_PATHS);

                        return TRUE;
                }
        }

        return FALSE;
}

//------------------------------------------------------------------------------

void tab_selection_changed(HWND hwndDlg) {
        RECT dlg_rect;
        RECT tab_rect;

        int sel = TabCtrl_GetCurSel(tab);

        if(dialog) {
                ShowWindow(dialog, SW_HIDE);
        }

        ShowWindow((dialog = tab_dialogs[sel]), SW_SHOW);

        /* tab controls are kind of shy about giving up the position where the
           dialog box for the page should be */

        GetWindowRect(tab, &tab_rect);
        GetWindowRect(hwndDlg, &dlg_rect);

        dlg_rect.left = tab_rect.left - dlg_rect.left;
        dlg_rect.top  = tab_rect.top  - dlg_rect.top - GetSystemMetrics(SM_CYCAPTION);

        TabCtrl_AdjustRect(tab, FALSE, &dlg_rect);

        SetWindowPos(dialog, HWND_TOP, dlg_rect.left, dlg_rect.top, 0, 0, SWP_NOSIZE);
}

//------------------------------------------------------------------------------

/* configuration dialog box */
BOOL CALLBACK config_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam) {
        switch(uMsg) {
                case WM_INITDIALOG: {
                        TCITEM ti;
                        tab = GetDlgItem(hwndDlg, IDC_TAB1);

                        /* remove the windows icon from the caption bar */
                        SetWindowLong(hwndDlg, GWL_EXSTYLE, WS_EX_DLGMODALFRAME);

                        /* Create the dialogs. We don't destroy them, just hide
                           them sometimes. */
                        dlg_general = tab_dialogs[0] = CreateDialog(instance, MAKEINTRESOURCE(IDD_GENERAL), hwndDlg, general_proc);
                        dlg_audio = tab_dialogs[1] = CreateDialog(instance, MAKEINTRESOURCE(IDD_AUDIO), hwndDlg, audio_proc);
                        dlg_status = tab_dialogs[2] = CreateDialog(instance, MAKEINTRESOURCE(IDD_STATUS), hwndDlg, status_proc);
                        tab_dialogs[3] = CreateDialog(instance, MAKEINTRESOURCE(IDD_ABOUT), hwndDlg, about_proc);

                        ti.mask = TCIF_TEXT;

                        ti.pszText = "Preferences";
                        TabCtrl_InsertItem(tab, 0, &ti);

                        ti.pszText = "Audio";
                        TabCtrl_InsertItem(tab, 1, &ti);

                        ti.pszText = "Status";
                        TabCtrl_InsertItem(tab, 2, &ti);

                        ti.pszText = "About";
                        TabCtrl_InsertItem(tab, 3, &ti);

                        tab_selection_changed(hwndDlg);

                        /* GUI controls' size and position stuff */
                        {
                                RECT r, r2;
                                POINT p;

                                /* save min size info */
                                GetWindowRect(hwndDlg, &r);

                                min_width = r.right - r.left;
                                min_height = r.bottom - r.top;

                                /* save info about size of tab control for resizing */
                                GetWindowRect(tab, &r2);

                                tab_width_diff = r.right - r2.right;
                                tab_height_diff = r.bottom - r2.bottom;

                                /* save info about button position relative to
                                   lower right of the dialog */
                                GetWindowRect(GetDlgItem(hwndDlg, IDCANCEL), &r2);

                                p.x = r2.left;
                                p.y = r2.top;
                                ScreenToClient(hwndDlg, &p);
                                button1_relative_pos_x = p.x - (r.right - r.left);
                                button1_relative_pos_y = p.y - (r.bottom - r.top);

                                /* lower left */
                                GetWindowRect(GetDlgItem(hwndDlg, IDC_LOG), &r2);
                                p.x = r2.left;
                                p.y = r2.top;
                                ScreenToClient(hwndDlg, &p);
                                button2_relative_pos_x = p.x;
                                button2_relative_pos_y = p.y - (r.bottom - r.top);
                        }

                        return TRUE;
                }
                case WM_COMMAND: {
                        WORD wNotifyCode = HIWORD(wParam);
                        WORD wID = LOWORD(wParam);
                        HWND hwndCtl = (HWND)lParam;

                        switch(wID) {
                                case IDC_LOG: {
                                        if(wNotifyCode==BN_CLICKED) {
                                                ShowWindow(dlg_log, SW_SHOW);
                                                BringWindowToTop(dlg_log);
                                                return TRUE;
                                        }
                                        break;
                                }
                                case WM_DESTROY: {
                                        ShowWindow(hwndDlg, SW_HIDE);
                                        break;
                                }
                        }
                        return 0;
                }
                case WM_NOTIFY: {
                        NMHDR *hdr = (NMHDR *)lParam;
                        if(hdr->idFrom==IDC_TAB1) {
                                if(hdr->code==TCN_SELCHANGE) {
                                        tab_selection_changed(hwndDlg);
                                }
                        }
                        return TRUE;
                }
                case WM_REALLY_DESTROY: {
                        if(lParam == REALLY_MAGIC) {
                                DestroyWindow(hwndDlg);
                                return TRUE;
                        }
                }
                case WM_GETMINMAXINFO: {
                        ((MINMAXINFO *)lParam)->ptMinTrackSize.x = min_width;
                        ((MINMAXINFO *)lParam)->ptMinTrackSize.y = min_height;
                        return TRUE;
                }
                case WM_SIZE: {
                        /* GUI controls' size and position stuff */
                        RECT r, r2;

                        GetWindowRect(hwndDlg, &r);
                        GetWindowRect(tab, &r2);
                        SetWindowPos(tab, 0,
                                0,
                                0,
                                r.right - r2.left - tab_width_diff,
                                r.bottom - r2.top - tab_height_diff,
                                SWP_NOMOVE | SWP_NOOWNERZORDER);

                        SetWindowPos(GetDlgItem(hwndDlg, IDCANCEL), 0,
                                r.right - r.left + button1_relative_pos_x,
                                r.bottom - r.top + button1_relative_pos_y,
                                0,
                                0,
                                SWP_NOSIZE | SWP_NOOWNERZORDER);

                        SetWindowPos(GetDlgItem(hwndDlg, IDC_LOG), 0,
                                button2_relative_pos_x,
                                r.bottom - r.top + button2_relative_pos_y,
                                0,
                                0,
                                SWP_NOSIZE | SWP_NOOWNERZORDER);

                        InvalidateRect(hwndDlg, NULL, FALSE);

                        SetWindowPos(dialog, HWND_TOP, 0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);

                        return TRUE;
                }
                case WM_UPDATE_GUI: {

                        SendMessage(tab_dialogs[0], WM_UPDATE_GUI, 0, 0);
                        SendMessage(tab_dialogs[1], WM_UPDATE_GUI, 0, 0);
                        SendMessage(tab_dialogs[2], WM_UPDATE_GUI, 0, 0);
                        SendMessage(tab_dialogs[3], WM_UPDATE_GUI, 0, 0);

                        return TRUE;
                }
        }

        return FALSE;
}

