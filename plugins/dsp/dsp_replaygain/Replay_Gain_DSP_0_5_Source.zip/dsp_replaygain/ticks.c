#include "windows.h"

#include "ticks.h"
#include "log.h"

void ticks_init() {
	int i;

	/* determine timing overhead */

	ticks_overhead = 0;

	for(i=0;i<10;i++) {
		ticks_start_counting();
		ticks_stop_counting();
	}
	ticks_overhead = (int)ticks_total;

	/* determine CPU clock frequency */
	{
	
	LARGE_INTEGER t1, t2, f;
	__int64 t, c;

	ticks_start_counting();
	QueryPerformanceCounter(&t1);

	for(i=0;i<20000000;i++) {
		__asm nop
	}

	QueryPerformanceCounter(&t2);
	ticks_stop_counting();

	QueryPerformanceFrequency(&f);

	t = ticks_total;

	c = t2.QuadPart - t1.QuadPart;
	
	cpu_clock = t / (c / (float)f.QuadPart);

	}

	//logf("Timing overhead: %d ticks\r\n", ticks_overhead);
	//logf("%I64d cycles, %I64d counts, %I64d counts per second, %.5f seconds, %.0f MHz\r\n", t, c, f, c / (float)f.QuadPart,  cpu_clock / 1000000);
	logf("Timing overhead: %d ticks; CPU clock frequency: ~%.0f MHz\r\n", ticks_overhead, cpu_clock / 1000000);
}

__declspec(naked) void __cdecl ticks_start_counting() {
	__asm {
		rdtsc		
		mov     dword ptr [ticks_start], eax	
		mov     dword ptr [ticks_start+4], edx	
		ret
	}
}

__declspec(naked) void __cdecl ticks_stop_counting() {
	__asm {
		rdtsc				
		sub	eax, dword ptr [ticks_start]
		sbb     edx, dword ptr [ticks_start+4]
		sub     eax, [ticks_overhead]	
		mov     dword ptr [ticks_total+4], edx
		mov     dword ptr [ticks_total], eax
		ret
	}
}