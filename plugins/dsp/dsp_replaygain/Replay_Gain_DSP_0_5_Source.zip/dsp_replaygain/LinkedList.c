#include "LinkedList.h"
#include <stdlib.h>

LinkedList* new_LinkedList() {
        LinkedList *ll = malloc(sizeof(LinkedList));
        ll->first = NULL;
        ll->last = NULL;
        ll->records = 0;
        return ll;
}

void destroy_LinkedList(LinkedList *ll, void (data_free_func)(void *data)) {
        LinkedList_record *r = ll->first;
        LinkedList_record *t;

        while(r!=NULL) {
                t = r->next;
                if(data_free_func) {
                        data_free_func(r->data);
                }
                free(r);
                r = t;
        }
	free(ll);
}

void LinkedList_add_last(LinkedList *ll, void *data) {
        LinkedList_record *r = malloc(sizeof(LinkedList_record));

        r->data = data;
        r->next = NULL;

        if(!ll->first) {
                ll->last = ll->first = r;
        } else {
                ll->last->next = r;
                ll->last = r;
        }

       ll->records++;
}

void LinkedList_add_first(LinkedList *ll, void *data) {
        LinkedList_record *r = malloc(sizeof(LinkedList_record));

        r->data = data;

        if(!ll->first) {
                r->next = NULL;
                ll->last = ll->first = r;
        } else {
                r->next = ll->first;
                ll->first = r;
        }

       ll->records++;
}
