#ifndef __LOG_H
#define __LOG_H

#include "windows.h"

void logf(const char *format, ...);

#define WM_ADD_TO_LOG WM_USER+344

BOOL CALLBACK log_proc(HWND hwndDlg,UINT uMsg, WPARAM wParam, LPARAM lParam);

#ifdef _DEBUG
void __cdecl append_to_log(const char *txt);
#else
void __stdcall append_to_log(const char *txt);
#endif

#endif __LOG_H