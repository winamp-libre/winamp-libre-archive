#define PLUGVER "v1.1 \"void\""
#include <windows.h>
#include "out.h"

int getwrittentime();
void config_read();
void config_write();

int srate, numchan, bps;

volatile int writtentime, w_offset;
Out_Module out;
static int last_pause=0;

void config(HWND hwnd) {
	MessageBox(hwnd, "No configuration", "Null output plugin", MB_OK);
}

void about(HWND hwnd) {
	MessageBox(hwnd,"Null output plugin " PLUGVER "\n"
			"Stuff deleted from raw output plugin source by Matthijs Laan\n"
			"Raw output plugin source Copyright (c) 1998-1999 Nullsoft, Inc.\n\n"
			"Compiled on " __DATE__ "\n","About",MB_OK);
}

void init() {
}

void quit() {
}

int open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms) {
 	w_offset = writtentime = 0;
	numchan = numchannels;
	srate = samplerate;
	bps = bitspersamp;
	return 0;
}

void close() {
}

int opened = 0;

int write(char *buf, int len) {
	writtentime += len;
	return 0;
}

int canwrite() {
	return last_pause?0:16*1024*1024;
}

int isplaying() {
	return 0;
}

int pause(int pause) {
	int t=last_pause;
	last_pause=pause;
	return t;
}

void setvolume(int volume) {
}

void setpan(int pan) {
}

void flush(int t) {
  int a;
  w_offset=0;
  a = t - getwrittentime();
  w_offset=a;
}
	
int getwrittentime() {
	int t=srate*numchan,l;
	int ms=writtentime;

	l=ms%t;
	ms /= t;
	ms *= 1000;
	ms += (l*1000)/t;

	if (bps == 16) ms/=2;

	return ms + w_offset;
}

Out_Module out = {
	OUT_VER,
	"Null output plugin " PLUGVER,
	76647,
	0, 
	0, 
	config,
	about,
	init,
	quit,
	open,
	close,
	write,
	canwrite,
	isplaying,
	pause,
	setvolume,
	setpan,
	flush,
	getwrittentime,
	getwrittentime
};

__declspec( dllexport ) Out_Module * winampGetOutModule() {
	return &out;
}