De-Stereo Module for Winamp v1.0
By C-JiPH (jab00@doc.ic.ac.uk)
Copyright (C) 2001

Description:
Turns all outgoing sound data mono. Useful if:
* You only have one speaker
* Your cables/jacks are shot
* You want mono output for any other reason

Install:
Stick dsp_nostereo.dll in your winamp/plugin directory

Known bugs:
If you 'configure' the plugin and then remove it winamp GPFs. Dunno why.

Disclaimer:
This module is provided AS IS, I waive ANY responsibility based on the use of this program
and/or its accompianiying material. The code is there, if you don't like it dont run it.
This module and its source may be distributed in any form provided that this readme.txt and 
all other associated files with the program accompany it and remain in tack. If you do
anything neat with my code please let me know.
