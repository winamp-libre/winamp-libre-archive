/*
  De-Stereo module for Winamp
  By Jacob Bower (jacob.bower@ic.ac.uk)
  07/03/01

  Based on DSP framework by Justin Frankel/Nullsoft
*/

#include <windows.h>
#include "resource.h"
#include "dsp.h"

// avoid stupid CRT silliness
BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}

// module getter.
winampDSPModule *getModule(int which);

void config(struct winampDSPModule *this_mod);
int init(struct winampDSPModule *this_mod);
void quit(struct winampDSPModule *this_mod);
int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate);
static BOOL CALLBACK ConfigProc(HWND hdlg, UINT message, WPARAM wParam,LPARAM lParam);

// Module header, includes version, description, and address of the module retriever function
winampDSPHeader hdr = { DSP_HDRVER, "De-Stereo module", getModule };

// first module
winampDSPModule mod =
{
	"De-Stereo module",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	config,
	init,
	modify_samples,
	quit
};


#ifdef __cplusplus
extern "C" {
#endif
// this is the only exported symbol. returns our main header.
__declspec( dllexport ) winampDSPHeader *winampDSPGetHeader2()
{
	return &hdr;
}
#ifdef __cplusplus
}
#endif

winampDSPModule *getModule(int which)
{
	if(!which)
		return &mod;
	
	return NULL;
}

void config(struct winampDSPModule *this_mod)
{
	CreateDialog(this_mod->hDllInstance,MAKEINTRESOURCE(IDD_CONFIG),this_mod->hwndParent,ConfigProc);
}

int init(struct winampDSPModule *this_mod)
{
	return 0;
}

void quit(struct winampDSPModule *this_mod)
{
}

int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate)
{
	int mixed,i;

	if(nch==2) {
	
		if(bps==16) {
			for(i=0; i<numsamples; i++) {
				mixed = (samples[0] + samples[1]) >> 1;
				samples[1] = samples[0] = (short int)mixed;
				samples += 2 * sizeof(short int);
			}
		} else {
			char *smp = (char *)samples;
			for(i=0; i<numsamples; i++) {
				mixed = (smp[0] + smp[1]) >> 1;
				smp[1] = smp[0] = (char)mixed;
				smp += 2 * sizeof(char);
			}
		}
	}
	return numsamples;
}

int width,height,x[2],y[2],xvel[2],yvel[2];
UINT timer;

#define Circle(h,cx,cy,r) Ellipse((h),(cx)-(r),(cy)-(r),(cx)+(r),(cy)+(r));

static BOOL CALLBACK ConfigProc(HWND hdlg, UINT message, WPARAM wParam,LPARAM lParam)
{
	int i,r;
	HWND hw;
	RECT re;
	HDC hdc;

	switch(message)
	{
		case WM_INITDIALOG:
			hw = GetDlgItem(hdlg, IDC_FX);
			GetClientRect(hw, &re);
			width = re.right;
			height = re.bottom;

			
			xvel[0]=1;
			yvel[0]=2;
			xvel[1]=-3;
			yvel[1]=1;

			x[0]=10;
			y[0]=20;
			x[1]=30;
			y[1]=40;

			timer = SetTimer(hdlg, NULL, 100, NULL);			
			return TRUE;

		case WM_TIMER:
			hw = GetDlgItem(hdlg,IDC_FX);
			hdc = GetDC(hw);			

			SelectObject(hdc,GetStockObject(WHITE_PEN));
			SelectObject(hdc,GetStockObject(NULL_BRUSH));
			SelectClipRgn(hdc,CreateRectRgn(0,0,width,height));

			PatBlt(hdc,0,0,width,height,BLACKNESS);

			for(i=0;i<2;i++) {
				for(r=1; r<height+(height>>1); r+=4)
					Circle(hdc,x[i],y[i],r);
				x[i] += xvel[i];
				y[i] += yvel[i];
				if(x[i]<0 || x[i]>width)
					xvel[i]*=-1;
				if(y[i]<0 || y[i]>height)
					yvel[i]*=-1;
			}

			ReleaseDC(hw, hdc);
			return TRUE;
		
		case WM_COMMAND:
			KillTimer(hdlg, timer);
			EndDialog(hdlg, 0);
			return TRUE;
	}

	return FALSE;
}
