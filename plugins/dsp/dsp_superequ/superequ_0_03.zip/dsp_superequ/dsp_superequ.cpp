// dsp_superequ.cpp : DLL �p�̏����������̒�`���s���܂��B
//

//#include <afxwin.h>
#include <string.h>

#include "stdafx.h"
#include "dsp_superequ.h"
#include "config_dialog.h"

#include "paramlist.hpp"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	����!
//
//		���� DLL �� MFC DLL �ɑ΂��ē��I�Ƀ����N�����ꍇ�A
//		MFC ���ŌĂяo����邱�� DLL ����G�N�X�|�[�g���ꂽ
//		�ǂ̊֐����֐��̍ŏ��ɒǉ������ AFX_MANAGE_STATE 
//		�}�N�����܂�ł��Ȃ���΂Ȃ�܂���B
//
//		��:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// �ʏ�֐��̖{�̂͂��̈ʒu�ɂ���܂�
//		}
//
//		���̃}�N�����e�֐��Ɋ܂܂�Ă��邱�ƁAMFC ����
//		�ǂ̌Ăяo�����D�悷�邱�Ƃ͔��ɏd�v�ł��B
//		����͊֐����̍ŏ��̃X�e�[�g�����g�łȂ���΂�
//		��Ȃ����Ƃ��Ӗ����܂��A�R���X�g���N�^�� MFC 
//		DLL ���ւ̌Ăяo�����s���\��������̂ŁA�I�u
//		�W�F�N�g�ϐ��̐錾�����O�łȂ���΂Ȃ�܂���B
//
//		�ڍׂɂ��Ă� MFC �e�N�j�J�� �m�[�g 33 �����
//		58 ���Q�Ƃ��Ă��������B
//

/////////////////////////////////////////////////////////////////////////////
// CDsp_superequApp

BEGIN_MESSAGE_MAP(CDsp_superequApp, CWinApp)
	//{{AFX_MSG_MAP(CDsp_superequApp)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
		//        ���̈ʒu�ɐ��������R�[�h��ҏW���Ȃ��ł��������B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDsp_superequApp �̍\�z

CDsp_superequApp::CDsp_superequApp()
{
	// TODO: ���̈ʒu�ɍ\�z�p�̃R�[�h��ǉ����Ă��������B
	// ������ InitInstance �̒��̏d�v�ȏ��������������ׂċL�q���Ă��������B
}

/////////////////////////////////////////////////////////////////////////////
// �B��� CDsp_superequApp �I�u�W�F�N�g

CDsp_superequApp theApp;

// avoid stupid CRT silliness
BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	return TRUE;
}

#include "Dsp.h"

// module getter.
winampDSPModule *getModule(int which);

void config(struct winampDSPModule *this_mod);
int init(struct winampDSPModule *this_mod);
void quit(struct winampDSPModule *this_mod);
int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate);

// Module header, includes version, description, and address of the module retriever function
winampDSPHeader hdr = { DSP_HDRVER, "Shibatch Super Equalizer 0.03", getModule };

// first module
winampDSPModule mod =
{
	"Equalizer",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	config,
	init,
	modify_samples,
	quit
};

extern "C" {
// this is the only exported symbol. returns our main header.
__declspec( dllexport ) winampDSPHeader *winampDSPGetHeader2()
{
	return &hdr;
}
}

// getmodule routine from the main header. Returns NULL if an invalid module was requested,
// otherwise returns either mod1 or mod2 depending on 'which'.
winampDSPModule *getModule(int which)
{
	if (which == 0) return &mod; else return NULL;
}

#if 0
int mixratio=24;
int delay=20;
int config_opened = 0;
#endif

extern void equ_init(int wb);
extern void equ_makeTable(float *lbc,float *rbc,paramlist *,float fs);
extern void equ_quit(void);
extern int equ_modifySamples(char *buf,int nsamples,int nch,int bps);
extern void equ_clearbuf(int,int);
extern void setBandsFromSlpos(void);
extern void load_from(char *filename,int);

extern int lslpos[19],rslpos[19];

config_dialog *cdialog;
//int config_opened = 0;
float last_srate = 0;
int last_nch = 0, last_bps = 0;
float lbands[18] = {1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0};
float rbands[18] = {1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0};
paramlist paramroot;
char autoloadfile[257];

// configuration. Passed this_mod, as a "this" parameter. Allows you to make one configuration
// function that shares code for all your modules (you don't HAVE to use it though, you can make
// config1(), config2(), etc...)
void config(struct winampDSPModule *this_mod)
{
	//if (config_opened) return;
	if (cdialog) return;

	//config_opened = 1;
	cdialog = new config_dialog;
	
	//cdialog->BringWindowToTop();
	cdialog->DoModal();
	//cdialog->Create();

	delete cdialog;
	cdialog = NULL;
}

#if 0
void setAsDefault(void)
{
	extern dither,enable,locklr;
	//CWinApp* pApp = CWinApp::FromHandle(mod.hDllInstance);
	CWinApp* pApp = AfxGetApp();
	//pApp->SetRegistryKey("HKEY_CURRENT_USER\\Software\\Shibatch");

	theApp.WriteProfileInt("equalizer","lsl0",lslpos[ 0]);
	theApp.WriteProfileInt("equalizer","lsl1",lslpos[ 1]);
	theApp.WriteProfileInt("equalizer","lsl2",lslpos[ 2]);
	theApp.WriteProfileInt("equalizer","lsl3",lslpos[ 3]);
	theApp.WriteProfileInt("equalizer","lsl4",lslpos[ 4]);
	theApp.WriteProfileInt("equalizer","lsl5",lslpos[ 5]);
	theApp.WriteProfileInt("equalizer","lsl6",lslpos[ 6]);
	theApp.WriteProfileInt("equalizer","lsl7",lslpos[ 7]);
	theApp.WriteProfileInt("equalizer","lsl8",lslpos[ 8]);
	theApp.WriteProfileInt("equalizer","lsl9",lslpos[ 9]);
	theApp.WriteProfileInt("equalizer","lsl10",lslpos[10]);
	theApp.WriteProfileInt("equalizer","lsl11",lslpos[11]);
	theApp.WriteProfileInt("equalizer","lsl12",lslpos[12]);
	theApp.WriteProfileInt("equalizer","lsl13",lslpos[13]);
	theApp.WriteProfileInt("equalizer","lsl14",lslpos[14]);
	theApp.WriteProfileInt("equalizer","lsl15",lslpos[15]);
	theApp.WriteProfileInt("equalizer","lsl16",lslpos[16]);
	theApp.WriteProfileInt("equalizer","lsl17",lslpos[17]);
	theApp.WriteProfileInt("equalizer","lsl18",lslpos[18]);

	theApp.WriteProfileInt("equalizer","rsl0",rslpos[ 0]);
	theApp.WriteProfileInt("equalizer","rsl1",rslpos[ 1]);
	theApp.WriteProfileInt("equalizer","rsl2",rslpos[ 2]);
	theApp.WriteProfileInt("equalizer","rsl3",rslpos[ 3]);
	theApp.WriteProfileInt("equalizer","rsl4",rslpos[ 4]);
	theApp.WriteProfileInt("equalizer","rsl5",rslpos[ 5]);
	theApp.WriteProfileInt("equalizer","rsl6",rslpos[ 6]);
	theApp.WriteProfileInt("equalizer","rsl7",rslpos[ 7]);
	theApp.WriteProfileInt("equalizer","rsl8",rslpos[ 8]);
	theApp.WriteProfileInt("equalizer","rsl9",rslpos[ 9]);
	theApp.WriteProfileInt("equalizer","rsl10",rslpos[10]);
	theApp.WriteProfileInt("equalizer","rsl11",rslpos[11]);
	theApp.WriteProfileInt("equalizer","rsl12",rslpos[12]);
	theApp.WriteProfileInt("equalizer","rsl13",rslpos[13]);
	theApp.WriteProfileInt("equalizer","rsl14",rslpos[14]);
	theApp.WriteProfileInt("equalizer","rsl15",rslpos[15]);
	theApp.WriteProfileInt("equalizer","rsl16",rslpos[16]);
	theApp.WriteProfileInt("equalizer","rsl17",rslpos[17]);
	theApp.WriteProfileInt("equalizer","rsl18",rslpos[18]);

	theApp.WriteProfileInt("equalizer","dither",dither);
	theApp.WriteProfileInt("equalizer","enable",enable);
	theApp.WriteProfileInt("equalizer","locklr",locklr);
}
#endif

int init(struct winampDSPModule *this_mod)
{
	equ_init(14);

#if 1
	extern int dither,enable,locklr;
	//CWinApp* pApp = CWinApp::FromHandle(mod.hDllInstance);
	//free((void*)pApp->m_pszProfileName);
	//pApp->m_pszProfileName=_tcsdup(_T("d:\equ.ini"));

	//pApp->SetRegistryKey("HKEY_CURRENT_USER\\Software\\Shibatch");

	theApp.setReg();
	//CWinApp* pApp = AfxGetApp();

	//char *inifn = (char *)malloc(strlen(pApp->m_pszExeName)+20);
	//strcpy(inifn,pApp->m_pszExeName);

	//char *p;
	//for(p=inifn;*p != '\0';p++) ;
	//for(;p != inifn && *p != '\\';p--) ;
	//if (*p == '\\') p++;
	//strcpy(p,"plugin.ini");
	//free((void*)pApp->m_pszProfileName);
	//pApp->m_pszProfileName = inifn;

#if 0
	lslpos[ 0] = theApp.GetProfileInt("equalizer","lsl0", 0);
	lslpos[ 1] = theApp.GetProfileInt("equalizer","lsl1", 0);
	lslpos[ 2] = theApp.GetProfileInt("equalizer","lsl2", 0);
	lslpos[ 3] = theApp.GetProfileInt("equalizer","lsl3", 0);
	lslpos[ 4] = theApp.GetProfileInt("equalizer","lsl4", 0);
	lslpos[ 5] = theApp.GetProfileInt("equalizer","lsl5", 0);
	lslpos[ 6] = theApp.GetProfileInt("equalizer","lsl6", 0);
	lslpos[ 7] = theApp.GetProfileInt("equalizer","lsl7", 0);
	lslpos[ 8] = theApp.GetProfileInt("equalizer","lsl8", 0);
	lslpos[ 9] = theApp.GetProfileInt("equalizer","lsl9", 0);
	lslpos[10] = theApp.GetProfileInt("equalizer","lsl10", 0);
	lslpos[11] = theApp.GetProfileInt("equalizer","lsl11", 0);
	lslpos[12] = theApp.GetProfileInt("equalizer","lsl12", 0);
	lslpos[13] = theApp.GetProfileInt("equalizer","lsl13", 0);
	lslpos[14] = theApp.GetProfileInt("equalizer","lsl14", 0);
	lslpos[15] = theApp.GetProfileInt("equalizer","lsl15", 0);
	lslpos[16] = theApp.GetProfileInt("equalizer","lsl16", 0);
	lslpos[17] = theApp.GetProfileInt("equalizer","lsl17", 0);
	lslpos[18] = theApp.GetProfileInt("equalizer","lsl18", 0);

	rslpos[ 0] = theApp.GetProfileInt("equalizer","rsl0", 0);
	rslpos[ 1] = theApp.GetProfileInt("equalizer","rsl1", 0);
	rslpos[ 2] = theApp.GetProfileInt("equalizer","rsl2", 0);
	rslpos[ 3] = theApp.GetProfileInt("equalizer","rsl3", 0);
	rslpos[ 4] = theApp.GetProfileInt("equalizer","rsl4", 0);
	rslpos[ 5] = theApp.GetProfileInt("equalizer","rsl5", 0);
	rslpos[ 6] = theApp.GetProfileInt("equalizer","rsl6", 0);
	rslpos[ 7] = theApp.GetProfileInt("equalizer","rsl7", 0);
	rslpos[ 8] = theApp.GetProfileInt("equalizer","rsl8", 0);
	rslpos[ 9] = theApp.GetProfileInt("equalizer","rsl9", 0);
	rslpos[10] = theApp.GetProfileInt("equalizer","rsl10", 0);
	rslpos[11] = theApp.GetProfileInt("equalizer","rsl11", 0);
	rslpos[12] = theApp.GetProfileInt("equalizer","rsl12", 0);
	rslpos[13] = theApp.GetProfileInt("equalizer","rsl13", 0);
	rslpos[14] = theApp.GetProfileInt("equalizer","rsl14", 0);
	rslpos[15] = theApp.GetProfileInt("equalizer","rsl15", 0);
	rslpos[16] = theApp.GetProfileInt("equalizer","rsl16", 0);
	rslpos[17] = theApp.GetProfileInt("equalizer","rsl17", 0);
	rslpos[18] = theApp.GetProfileInt("equalizer","rsl18", 0);
#endif

	CString str;
	str = theApp.GetProfileString("equalizer","autoload","");
	strncpy(autoloadfile,str,256);
	dither = theApp.GetProfileInt("equalizer","dither", 0);
	enable = theApp.GetProfileInt("equalizer","enable", 1);
	locklr = theApp.GetProfileInt("equalizer","locklr", 1);

	for(int i=0;i<=18;i++)
	{
		if (lslpos[i] < 0 ) lslpos[i] = 0;
		if (lslpos[i] > 96) lslpos[i] = 96;
		if (rslpos[i] < 0 ) rslpos[i] = 0;
		if (rslpos[i] > 96) rslpos[i] = 96;
	}

	load_from(autoloadfile,1);
	setBandsFromSlpos();
#endif

	//free((void*)pApp->m_pszProfileName);
	//pApp->m_pszProfileName=_tcsdup(_T("test.ini"));
	//pApp->WriteProfileString("This","is a","test.");

	//mixratio = pApp->GetProfileInt("dsp_crossfeed","mixratio",24);
	//delay    = pApp->GetProfileInt("dsp_crossfeed","delay",   20);

	//if (mixratio < 0 || mixratio > 50) mixratio = 24;
	//if (delay < 0    || delay > 50)    delay = 20;

	return 0;
}

// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quit(struct winampDSPModule *this_mod)
{
 	extern int dither,enable,locklr;

	equ_quit();

	theApp.WriteProfileString("equalizer","autoload",autoloadfile);
	theApp.WriteProfileInt("equalizer","dither",dither);
	theApp.WriteProfileInt("equalizer","enable",enable);
	theApp.WriteProfileInt("equalizer","locklr",locklr);

#if 0
	if (config_opened) {
		cdialog->EndDialog(0);
		delete cdialog;
		cdialog = NULL;
	}

	CWinApp* pApp = AfxGetApp();

	mixratio = pApp->WriteProfileInt("dsp_crossfeed","mixratio",mixratio);
	delay    = pApp->WriteProfileInt("dsp_crossfeed","delay",   delay   );
#endif
	//CWinApp* pApp = AfxGetApp();

	//pApp->WriteProfileInt("Shibatch Super Equalizer","test",1);
}

//#define DBUFLEN 1024
//static int delaybufL[DBUFLEN],delaybufR[DBUFLEN],dbufpos=0;

int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate)
{
	int i;

	if ((nch != 1 && nch != 2) || (bps != 8 && bps != 16 && bps != 24)) return numsamples;

	if (last_srate != srate) {
		equ_makeTable(lbands,rbands,&paramroot,srate);
		last_srate = srate;
		last_nch = nch;
		last_bps = bps;
		equ_clearbuf(bps,srate);
#if 0
		if (cdialog) {
			char str[64];
			wsprintf(str,"%s %d Hz %s bits",nch == 1 ? "Mono" : "Stereo",srate,bps);
			cdialog->display(str);
		}
#endif
	} else if (last_nch != nch || last_bps != bps) {
		last_nch = nch;
		last_bps = bps;
		equ_clearbuf(bps,srate);
#if 0
		if (cdialog) {
			char str[64];
			wsprintf(str,"%s %d Hz %s bits",nch == 1 ? "Mono" : "Stereo",srate,bps);
			cdialog->display(str);
		}
#endif
	}

#if 0
	if (bps == 8) {
		buf = (short *)malloc(sizeof(short)*numsamples*nch);
		for(i=0;i<numsamples*nch;i++)
			buf[i] = ((unsigned char *)samples)[i] - 0x80;
	} else {
		buf = samples;
	}
#endif

	equ_modifySamples((char *)samples,numsamples,nch,bps);

#if 0
	if (bps == 8) {
		for(i=0;i<numsamples*nch;i++)
			((unsigned char *)samples)[i] = buf[i] + 0x80;
		free(buf);
	}
#endif

	return numsamples;
}
