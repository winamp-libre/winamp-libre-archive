//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dsp_superequ.rc
//
#define IDC_BUT_CANCEL                  3
#define IDD_DIALOG1                     129
#define IDC_BUT_OK                      1000
#define IDC_BUT_UP                      1002
#define IDC_BUT_DOWN                    1003
#define IDC_BUT_SDEF                    1006
#define IDC_BUT_APPLY                   1008
#define IDC_LIST_PARAM                  1010
#define IDC_SL_L1                       1012
#define IDC_BUT_PDEL                    1013
#define IDC_SL_L2                       1014
#define IDC_SL_L3                       1015
#define IDC_SL_L4                       1016
#define IDC_SL_L5                       1017
#define IDC_SL_L6                       1018
#define IDC_SL_L7                       1019
#define IDC_SL_L8                       1020
#define IDC_SL_L9                       1021
#define IDC_SL_L10                      1022
#define IDC_SL_L11                      1023
#define IDC_SL_L12                      1024
#define IDC_SL_L13                      1025
#define IDC_SL_L14                      1026
#define IDC_SL_L15                      1027
#define IDC_SL_L16                      1028
#define IDC_SL_L17                      1029
#define IDC_SL_L18                      1030
#define IDC_SL_LPRE                     1031
#define IDC_SL_R1                       1032
#define IDC_SL_R2                       1033
#define IDC_SL_R3                       1034
#define IDC_SL_R4                       1035
#define IDC_SL_R5                       1036
#define IDC_SL_R6                       1037
#define IDC_SL_R7                       1038
#define IDC_SL_R8                       1039
#define IDC_SL_R9                       1040
#define IDC_SL_R10                      1041
#define IDC_SL_R11                      1042
#define IDC_SL_R12                      1043
#define IDC_SL_R13                      1044
#define IDC_SL_R14                      1045
#define IDC_SL_R15                      1046
#define IDC_SL_R16                      1047
#define IDC_SL_R17                      1048
#define IDC_SL_R18                      1049
#define IDC_SL_RPRE                     1050
#define IDC_ED_PLOW                     1051
#define IDC_CH_LOCK                     1052
#define IDC_ED_TARGET                   1053
#define IDC_BUT_PNEW                    1054
#define IDC_BUT_LOAD                    1055
#define IDC_BUT_SAVE                    1056
#define IDC_CH_ENABLE                   1057
#define IDC_ED_PUP                      1058
#define IDC_ED_GAIN                     1059
#define IDC_CH_PLEFT                    1063
#define IDC_CH_PRIGHT                   1064
#define IDC_CH_DITHER                   1065
#define IDC_ED_AUTOLOAD                 1067

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1068
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
