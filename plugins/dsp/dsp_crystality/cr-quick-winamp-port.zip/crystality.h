/*  Crystality Plugin - A plugin for remastering mp3 sound in realtime
 *
 *  Copyright (C) 2001 Rafal Bosak <gyver@fanthom.irc.pl>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef WIN32
#include <linux/soundcard.h>
#endif /* WIN32 */

#define int16 short
#define int32 long
#define uint16 unsigned short
#define uint32 unsigned long

void gui_init(void);
void gui_cleanup(void);
void gui_about(void);
void gui_configure(void);

extern int bext_level;
extern int filter_level;
extern int echo_level;
extern int stereo_level;
extern int feedback_level;
extern int harmonics_level;
extern int enable_plugin;

void set_defaults(void);
void bext_level_cb(void);
void echo_level_cb(void);
void stereo_level_cb(void);
void feedback_level_cb(void);
void harmonics_level_cb(void);
void enable_plugin_cb(void);

void init(void);
int read_config(void);
void cleanup(void);
int write_config(void);
void about(void);
void configure(void);
int process_sound(void *data, int length, uint32 afmt, int srate, int nch);

