#include <windows.h>
#include "crystality.h"
#include "dsp.h"

void dspconfig(struct winampDSPModule *this_mod);
int dspinit(struct winampDSPModule *this_mod);
void dspquit(struct winampDSPModule *this_mod);
int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate);

winampDSPModule *getModule(int which);

winampDSPHeader hdr = { DSP_HDRVER, "Crystality Plugin v0.92", getModule };

winampDSPModule mod =
{
	"Crystality 0.92",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	dspconfig,
	dspinit,
	modify_samples,
	dspquit
};

#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) winampDSPHeader *winampDSPGetHeader2()
{
	return &hdr;
}
#ifdef __cplusplus
}
#endif

winampDSPModule *getModule(int which)
{
	switch (which)
	{
		case 0: return &mod;
		default:return NULL;
	}
}

void dspconfig(struct winampDSPModule *this_mod)
{
	MessageBox(this_mod->hwndParent, "Crystality Plugin v0.92\n"
"\n"
"Bandwidth Extender, Harmonic Booster and 3D Echo\n"
"You will need a good stereo and a good ear to notice quality\n"
"improvement, otherwise this is not for you.  This plugin tries\n"
"to patch mp3 format flaws, not poor audio hardware!\n"
"For more info see README file!\n"
"Copyright (C) 2001 Rafal Bosak <gyver@fanthom.irc.pl>\n"
"\n"
"This program is free software; you can redistribute it and/or modify\n"
"it under the terms of the GNU General Public License as published by\n"
"the Free Software Foundation; either version 2 of the License, or\n"
"(at your option) any later version.\n"
"\n"
"This program is distributed in the hope that it will be useful,\n"
"but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
"GNU General Public License for more details.\n"
"\n"
"You should have received a copy of the GNU General Public License\n"
"along with this program; if not, write to the Free Software\n"
"Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n"
		, "About Crystality", MB_OK);
}

int dspinit(struct winampDSPModule *this_mod)
{
	init();

	return 0;
}

void dspquit(struct winampDSPModule *this_mod)
{
}

int modify_samples(struct winampDSPModule *this_mod, short int *samples, int numsamples, int bps, int nch, int srate)
{
	if (bps==16)
	{
		process_sound(samples, numsamples*nch, 0, srate, nch);
	}
	return numsamples;
}
