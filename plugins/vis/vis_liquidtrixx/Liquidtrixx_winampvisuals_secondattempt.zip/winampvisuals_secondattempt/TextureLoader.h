#ifndef __TEXTURELOADER_H_
#define __TEXTURELOADER_H_

#pragma comment(lib,"jpeg.lib")

#include "headers.h"
#include "jpeglib.h"

// I-PICTURE CODE
int JPEG_Texture(GLuint textureArray[], LPSTR strFileName, int ID);

#endif	__TEXTURELOADER_H_