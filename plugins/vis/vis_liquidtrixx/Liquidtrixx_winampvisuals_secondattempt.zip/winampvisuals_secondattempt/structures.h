const int num=50;																						// Number Of Stars To Draw

typedef struct																							// Create A Structure For Star
{
  int r, g, b;																							// Stars Color
  GLfloat dist;																							// Stars Distance From Center
  GLfloat angle;																						// Stars Current Angle
}
stars;					

typedef struct																							// Structure For 3D Points
{
	float	x, y, z;																					// X, Y & Z Points
} 
VERTEX;

typedef	struct																							// Structure For An Object
{
	int		verts;																						// Number Of Vertices For The Object
	VERTEX	*points;																					// One Vertice (Vertex x,y & z)
} OBJECT;

typedef struct
{
	OBJECT	helper,*sour;
	int		morph;
	int		step;
} GLRETURN;

GLRETURN *reflect=new GLRETURN;

typedef struct
{
	float	roll;
	int	direction;
} GLRETURN2;

GLRETURN2 *reflect2=new GLRETURN2;

typedef struct 
{
	float old_beat;
	float beat;
} beat_return;

VERTEX calculate(int i,OBJECT *sour,OBJECT *dest,int steps)												// Calculates Movement Of Points During Morphing
{
	VERTEX a;																							// Temporary Vertex Called a
	a.x=(sour->points[i].x-dest->points[i].x)/steps;													// a.x Value Equals Source x - Destination x Divided By Steps
	a.y=(sour->points[i].y-dest->points[i].y)/steps;													// a.y Value Equals Source y - Destination y Divided By Steps
	a.z=(sour->points[i].z-dest->points[i].z)/steps;													// a.z Value Equals Source z - Destination z Divided By Steps
	return a;																
}

typedef struct
{
	int color_holder;
	float	beat2;
} GLRETURN7;

GLRETURN7 *reflect7=new GLRETURN7;

typedef struct
{
	float Punkte[21][12001][3];
	float Kamera[6];
	int	  Kamera_pos;
	int   Geschwindigkeit;
} GLTUNNEL;

GLTUNNEL *reflect_tunnel=new GLTUNNEL;

typedef struct			
{
	GLubyte	*imageData;																					// Image Data (Up To 32 Bits)
	GLuint	bpp;																						// Image Color Depth In Bits Per Pixel.
	GLuint	width;																						// Image Width
	GLuint	height;																						// Image Height
	GLuint	texID;																						// Texture ID Used To Select A Texture
} TextureImage;																							// Structure Name

typedef struct																							// Create A Structure For Particle
{
	bool	active;																						// Active (Yes/No)
	float	life;																						// Particle Life
	float	fade;																						// Fade Speed
	float	r;																							// Red Value
	float	g;																							// Green Value
	float	b;																							// Blue Value
	float	x;																							// X Position
	float	y;																							// Y Position
	float	z;																							// Z Position
	float	xi;																							// X Direction
	float	yi;																							// Y Direction
	float	zi;																							// Z Direction
	float	xg;																							// X Gravity
	float	yg;																							// Y Gravity
	float	zg;																							// Z Gravity
}
particles;

typedef struct
{
	float	r;																							// Red Value
	float	g;																							// Green Value
	float	b;																							// Blue Value
	float	x;																							// X Position
	float	y;																							// Y Position
	float	z;																							// Z Position
	float	scalez;
}
particles2;

struct GLvector
{
	GLfloat fX;
	GLfloat fY;
	GLfloat fZ;     
};

struct GLVector
{
	GLfloat x;
	GLfloat y;
	GLfloat z;     
};

