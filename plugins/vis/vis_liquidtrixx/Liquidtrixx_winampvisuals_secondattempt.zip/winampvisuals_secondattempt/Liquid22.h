#ifndef __LIQUID22_H_
#define __LIQUID22_H_

#include "TextureLoader.h"
#include "Scenemanager.h"										
#include "Background.h"

class scene22:public Manager
{

	public:
		scene22(double time,float wid,float hei);												
		~scene22();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:

		GLuint		m_Texture[5];										
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		float		lastTime,sceneTime;
		float		slowdown;
		GLfloat		xspeed,yspeed;
		GLuint		col;
		int			delay;
		float		help2;
		float		width,height;
};

#endif __LIQUID22_H_
