#ifndef __LIQUID12_H_
#define __LIQUID12_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"

class scene12:public Manager
{

	public:
		scene12(double time,float wid,float hei);												
		~scene12();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
		virtual void rectangle2 (float scale);
	
	private:
		float		GetTime(void);

		GLuint		m_Texture[5];										
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder,beat_min,beat_max;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		int			col,ret;
		float		lastTime,sceneTime;
		int			scene_switcher;
		float		width,height;
};

#endif __LIQUID12_H_
