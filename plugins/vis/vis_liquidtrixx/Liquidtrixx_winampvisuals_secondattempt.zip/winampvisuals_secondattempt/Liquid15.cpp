#include "headers.h"
#include "Misc.h"
#include "liquid15.h"

scene15::scene15(double time,float wid,float hei):Manager(time)					
{
	liquid2			= new scene2(20.0,1,wid,hei,1);
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	camera = new CCamera();
	camera->PositionCamera(0.5f, 0.5f, 40.0f,   0.5f, 0.5f, 0.5f,   1, 1, 1);
	center = new CVector3(0,0,0);

	width						= wid;
	height						= hei;
}

scene15::~scene15()					
{
	if (liquid2)
		delete(liquid2);
	if (camera)
		delete(camera);
	if (center)
		delete(center);
}


void scene15::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	
	camera->RotateAroundPoint(camera->m_vView,(float)pow(beat_responder/300.0f,2), 0, 1, 0);
	camera->MoveCamera(200+beat_responder);
	Metaballs_list  = glGenLists(1);
	gluLookAt ( camera->m_vPosition.x, camera->m_vPosition.y, camera->m_vPosition.z,   
				camera->m_vView.x, camera->m_vView.y, camera->m_vView.z,
				camera->m_vUpVector.x, camera->m_vUpVector.y, camera->m_vUpVector.z ); 
	glNewList(Metaballs_list,GL_COMPILE);
		liquid2->Draw(blend_colour,this_mod);
	glEndList();

	//camera->RotateAroundPoint(camera->m_vView,beat_responder/300,0,1,0);
	//glTranslatef(camera->m_vView.x, camera->m_vView.y, camera->m_vView.z);
	glTranslatef(camera->m_vView.x, 0, camera->m_vView.z);
	//glCallList(Metaballs_list);
	//glTranslatef(0.0,0.0,+5.5f-(float)pow(beat_responder/30.0f,2));
	//glRotatef(xrot,0.0f,0.0f,1.0f);
	glPushMatrix();
	//glTranslatef(0.0f,0.0f,-20.0f);
	for (int k=-2;k<3;k++)
	{
		for (int j=-2;j<3;j++)
		{
			for (i=-2;i<3;i++)
			{
				glPushMatrix();
				if ((abs(i)<=1) && (abs(j)<=1) && (abs(k)<=1))
					glScalef(2.0f,2.0f,2.0f);
					glScalef(1.0f+beat_responder/20,1.0f+beat_responder/20,1.0f+beat_responder/20);
					glTranslatef(i*4.0f*(1.2f+beat_responder/60),j*4.0f*(1.2f+beat_responder/60),k*4.0f*(1.2f+beat_responder/60));
					glPushMatrix();
						glTranslatef(1.0f-2.0f*(float)pow(beat_responder/60.0f,2),1.0f-2.0f*(float)pow(beat_responder/60.0f,2),+5.5f-2.0f*(float)pow(beat_responder/60.0f,2));
						glCallList(Metaballs_list);
					glPopMatrix();
				glPopMatrix();
			}
		}
	}
	glPopMatrix();
	glDeleteLists(Metaballs_list,1);
}

void scene15::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	liquid2->Update(beat_help,this_mod,beat_scaler,Tex_on);
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene15::Init(loadall		*textures)
{
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glEnable(GL_LIGHT0);                             
	glEnable(GL_LIGHTING);

	liquid2->Init(textures);
	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%10;
	
	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(6);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(6);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==10)
		multi_texture=0;*/
	return true;
}

