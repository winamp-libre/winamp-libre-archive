#ifndef __WELCOME_H_
#define __WELCOME_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "cube.h"
#include "Background.h"
#include "vis.h"

class welcome
{

	public:
		welcome(float wid,float hei);												
		~welcome();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(struct winampVisModule *this_mod);
		virtual void getfilename(LPSTR strFileName,struct winampVisModule *this_mod,int id);
	
	private:
		float		GetTime(void);
		background	*bg;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		float		width,height;
		GLuint		w_Texture[2];
};

#endif __WELCOME_H_
