#ifndef __LIQUID16_H_
#define __LIQUID16_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"

class scene16:public Manager
{

	public:
		scene16(double time,int choice_in,float wid,float hei);												
		~scene16();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		GLuint		m_Texture[5];
		GLfloat		colours[16];
		int			i,direction,choice;
		float		scalefactor;
		float		xrot,t,roll;
		float		beat_responder,beat_min,beat_max;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		float		width,height;
		int			scene_switcher;
};

#endif __LIQUID16_H_
