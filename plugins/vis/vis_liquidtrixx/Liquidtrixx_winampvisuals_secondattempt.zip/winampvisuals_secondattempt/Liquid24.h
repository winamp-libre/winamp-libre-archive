#ifndef __LIQUID24_H_
#define __LIQUID24_H_

#include "TextureLoader.h"
#include "Scenemanager.h"										
#include "Background.h"
#include "Font.h"

#ifndef io_curve
#define io_curve(x) ((x)*(1-(x))*4)
#endif	io_curve

#ifndef fade_io
#define fade_io(a, x) (io_curve((sceneTime-(a))/(x)))
#endif	fade_io

class scene24:public Manager
{

	public:
		scene24(double time,float wid,float hei);												
		~scene24();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		float		GetTime(void);

		GLuint		m_Texture[5];										
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		float		lastTime,sceneTime;
		float		slowdown;
		GLfloat		xspeed,yspeed;
		GLuint		col;
		int			delay;
		float		help2;
		Font		*fnt;
		int			mode;
		float		width,height;
};

#endif __LIQUID24_H_
