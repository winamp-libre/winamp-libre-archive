beat_return Beat_it(struct winampVisModule *this_mod,float beat_help,float old_beat,int xmin,int xmax) 
{
	float beat=float(winampDetectBass(this_mod,xmin,xmax));
	float add;
	if (fabs(beat_help-beat)>6)
	{
		add=5;		
	}
	else
	{
		add=1;
	} 	
	if (int(beat_help)<=int(beat))
	{
		beat_help+=add;
	}
	if (int(beat_help)>int(beat))
	{
		beat_help-=1;
	}
	beat_return beat2;
	beat2.old_beat=old_beat;
	beat2.beat=beat_help;
	return beat2;
}
