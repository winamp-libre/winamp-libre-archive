#include "headers.h"
#include "Misc.h"
#include "liquid11.h"

scene11::scene11(double time,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	t1				= 0.0f;
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=2;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	for (int loop=0;loop<100;loop++)														
	{
		particle[loop].x=(float)0.01*loop;												
		particle[loop].y=0.0f;															
		particle[loop].z=0.0f;															
		particle[loop].scalez=0.0f;
	}
	scene_switcher=-1;

	width						= wid;
	height						= hei;
}

scene11::~scene11()					
{
}


void scene11::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glDisable(GL_DEPTH_TEST);																				// Disable Depth Testing
	glDepthFunc(GL_LEQUAL);
	glEnable(GL_BLEND);																						// Enable Blending
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);																		// Type Of Blending To Perform
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);														// Really Nice Perspective Calculations
	glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);																	// Really Nice Point Smoothing
	if (beat_responder>10)
		col=1;
	if (beat_responder>20)
		col=2;
	if (beat_responder>30)
		col=3;
	if (beat_responder>40)
		col=4;
	if (beat_responder>50)
		col=5;
	if (beat_responder>60)
		col=6;
	if (beat_responder>70)
		col=7;
	if (beat_responder>80)
		col=8;
	if (beat_responder>90)
		col=9;
	if (beat_responder>100)
		col=0;
	col=rand()%10;

	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};	

	GLfloat vertices[]=
	{	
		-1.0f,	-1.0f,  -1.0f,
		1.0f,	-1.0f,  -1.0f,
		1.0f,	1.0f,	-1.0f,
		-1.0f,  1.0f,	-1.0f
	};

	GLfloat tex_coords[]=
	{
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f
	};

	GLfloat		colours[]=
	{
		1.0f,1.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,1.0f,
	};

	GLuint		indices[]={0,1,2,3};

	if (scene_switcher>10)
	{
		glActiveTextureARB		( GL_TEXTURE0_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
			
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB		( GL_TEXTURE1_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);	
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	if (scene_switcher>20)
	{
		glActiveTextureARB		( GL_TEXTURE0_ARB );
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glDisable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB		( GL_TEXTURE1_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		
		glEnable(GL_BLEND);
		glEnable(GL_TEXTURE_GEN_S);																
		glEnable(GL_TEXTURE_GEN_T);	
		glDisable(GL_DEPTH_TEST);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
	}
	if (scene_switcher<=10)
	{
		glActiveTextureARB		( GL_TEXTURE0_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
			
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB		( GL_TEXTURE1_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);	
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}

	glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );

	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );

	glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
	
	glPushMatrix();
		glTranslatef((float)((beat_responder/60+1.0f)*cos(t)),(float)((beat_responder/50+1.0f)*sin(t)),-30.0f+(float)(5+beat_responder/5));
		glRotatef(xrot,0.0f,0.0f,1.0f);
		glPushMatrix();
			glRotatef(xrot,1.0f,1.0f,1.0f);
			for (int i=0;i<3;i++)
			{
				glRotatef(i*-beat_responder/1.3f,0.0f,1.0f,0.0f);
				
				for (int k=-4;k<5;k++)
				{
					glPushMatrix();	
						glRotatef(k*beat_responder/1.3f,0.0f,0.0f,1.0f);
						glTranslatef(xrot/60*(float)cos(t)+xrot/80*(float)cos(0.5*t)+xrot/140*(float)cos(1.5*t),
									xrot/60*(float)cos(t)+xrot/80*(float)cos(2*t)+xrot/70*(float)cos(1.5*t),
									0.0f);
						glPushMatrix();
						
						glDisable(GL_DEPTH_TEST);
							for (int loop=0;loop<100;loop++)
							{
								particle[loop].x=(float)((-((beat_responder/60000)+0.001f)*loop+0.1*cos(t/10)));
								particle[loop].y=(float)((((100-beat_responder)/130)*sin(particle[loop].x+t))*cos(t/10));
								particle[loop].z=(float)((-((beat_responder/3000)+0.001f)*loop+0.1*cos(t))*cos(t/10));
								glTranslatef(particle[loop].x,particle[loop].y,particle[loop].z);
								glScalef((float)0.95-(loop/100),(float)0.95-(loop/100),(float)0.95-(loop/100));
								glPushMatrix();
									glRotatef(-k*beat_responder/1.3f,0.0f,0.0f,1.0f);
									glRotatef(-i*-beat_responder/1.3f,0.0f,1.0f,0.0f);
									glRotatef(-xrot,1.0f,1.0f,1.0f);																											
									glColorPointer  ( 4, GL_FLOAT, 0, &colours );
									glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
								glPopMatrix();
							}
						glPopMatrix();
						
					glPopMatrix();
				}
			}
		glPopMatrix();
	glPopMatrix();
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_TEXTURE_GEN_R);																
	glDisable(GL_TEXTURE_GEN_Q);
}

void scene11::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/30)*(beat_responder/30));
	t1+=0.01f*direction;
	if (t1>1.5*beat_responder/60)	
		direction=-1;
	if (t1<-1.5*beat_responder/60)
		direction=1;

	t+=3.14f/1000*xrot/60;

	if (t>4*3.14)	
		t=0.0f;

	ret+=(int)beat_responder/60;
		
	if (ret>=80)
		ret=0;
}

bool scene11::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%10;
	scene_switcher=rand()%30;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(1);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 2:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(3);
		break;
		case 3:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(3);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(4);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(4);
		break;
		case 6:
			m_Texture[0]=textures->Bind(10);
			m_Texture[1]=textures->Bind(5);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(6);
		break;
		case 8:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(7);
		break;
		case 9:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(8);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==10)
		multi_texture=0;
	scene_switcher=scene_switcher++;
	if (scene_switcher==30)
		scene_switcher=0;*/
	return true;
}

