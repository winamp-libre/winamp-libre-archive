#include "headers.h"
#include "Misc.h"
#include "liquid7.h"

scene7::scene7(double time,float wid,float hei):Manager(time)					// Constructor
{
	xrot			= 0.0f;
	t				= 0.0f;
	liquid_cube		= new cube();	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	scenechanger	= -1;

	width						= wid;
	height						= hei;
}

scene7::~scene7()					// Destructor
{
	if (liquid_cube)
		delete liquid_cube;
}


void scene7::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glDisable ( GL_DEPTH_TEST );
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);															
	glEnable(GL_BLEND);

	
	for (int i=0;i<7;i++)
	{
		glPushMatrix();
			glTranslatef(0.0f,0.0f,-11.0f+(10-i)*(float)pow(beat_responder/50,2));
			scalefactor=(float)pow((beat_responder/600*i/7),2);
			glScalef(1-scalefactor,1-scalefactor,1-scalefactor);
			glRotatef(xrot/3+(i/3+1),0.0f,0.0f,1.0f);
			glRotatef(xrot/4+(i/3+1),0.0f,1.0f,0.0f);	
			glRotatef(xrot/5+(i/3+1),1.0f,0.0f,0.0f);
			glPushMatrix();
			if((timeeffect > 1) && (timeeffect<18)) 
				liquid_cube->Update(10*i+blend_colour,beat_responder,timeeffect);
			if (timeeffect <1 )
				liquid_cube->Update(int(fadeffect*i)+blend_colour,beat_responder,timeeffect);
			glPopMatrix();
		glPopMatrix();
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);

		glColor4ub(255,255,255,60+5*(int)pow(beat_responder/40.0f,2));
		if (scenechanger<=18 && multi_texture!=4)
		{
			glActiveTextureARB ( GL_TEXTURE0_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glDisable(GL_TEXTURE_GEN_S);																
			glDisable(GL_TEXTURE_GEN_T);
			glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

			glActiveTextureARB ( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			glEnable(GL_TEXTURE_GEN_S);																
			glEnable(GL_TEXTURE_GEN_T);
			glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
			glTranslatef(0.0f,0.0f,-(float)i);
			bg->DrawWaving(xrot/80+i*xrot/400+i);
			bg->DrawPlasma(xrot/200+i*(1+xrot/1000));
		}
		else
		{
			glActiveTextureARB ( GL_TEXTURE0_ARB );
			glEnable(GL_TEXTURE_2D);
			glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glDisable(GL_TEXTURE_GEN_S);																
			glDisable(GL_TEXTURE_GEN_T);
			glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB ( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
			glEnable(GL_TEXTURE_GEN_S);																
			glEnable(GL_TEXTURE_GEN_T);
			glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
			glTranslatef(0.0f,0.0f,-(float)i);
			bg->DrawWaving(xrot/80+i*xrot/400+i);
			bg->DrawPlasma(xrot/200+i*(1+xrot/1000));
		}
	}


}

void scene7::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene7::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glDisableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glDisableClientState		( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%18;
	scenechanger=rand()%34;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(2);
		break;
		case 2:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(7);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(5);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(6);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(6);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
		case 10:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(6);
		break;
		case 11:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(6);
		break;
		case 12:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(6);
		break;
		case 13:
			m_Texture[0]=textures->Bind(17);
			m_Texture[1]=textures->Bind(6);
		break;
		case 14:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(6);
		break;
		case 15:
			m_Texture[0]=textures->Bind(19);
			m_Texture[1]=textures->Bind(6);
		break;
		case 16:
			m_Texture[0]=textures->Bind(20);
			m_Texture[1]=textures->Bind(17);
		break;
		case 17:
			m_Texture[0]=textures->Bind(21);
			m_Texture[1]=textures->Bind(15);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==18)
		multi_texture=0;
	scenechanger=scenechanger++;
	if (scenechanger==34)
		scenechanger=0;*/
	return true;
}

