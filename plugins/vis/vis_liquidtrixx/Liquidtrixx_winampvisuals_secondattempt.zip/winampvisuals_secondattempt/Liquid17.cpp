#include "headers.h"
#include "Misc.h"
#include "liquid17.h"

scene17::scene17(double time,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	width						= wid;
	height						= hei;
}

scene17::~scene17()	
{
}


void scene17::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);
	gluLookAt(0, 0, 30,     0, 0, 0,     0, 1, 0);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
	
	glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );
	
	glActiveTextureARB		( GL_TEXTURE0_ARB ); 
	glBindTexture			( GL_TEXTURE_2D, m_Texture[1] ); 
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);		
	glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);					
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_S, GL_EYE_PLANE, GL_SPHERE_MAP);	 
	glTexGeni(GL_T, GL_EYE_PLANE, GL_SPHERE_MAP);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
	
	glActiveTextureARB		( GL_TEXTURE1_ARB ); 
	glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);		
	glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);					
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_S, GL_EYE_PLANE, GL_SPHERE_MAP);	 
	glTexGeni(GL_T, GL_EYE_PLANE, GL_SPHERE_MAP);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	
	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );

	float originX=beat_responder/30;
	float originY=beat_responder/30;
	for (int l=0;l<2;l++)
	{
		glRotatef(90.0f*l,1.0f,1.0f,1.0f);
		glScalef(1.0f+beat_responder/200,1.0f+beat_responder/200,1.0f);
		glPushMatrix();
			for (int z=0;z<2;z++)
			{
				glRotatef(180.0f*z,1.0f,1.0f,1.0f);
				glPushMatrix();
					glRotatef(xrot,1.0f,1.0f,1.0f);
					glPushMatrix();
						float radius=1.5f;
						float vectorY1=originY+radius;
						float vectorX1=originX;
						float vectorX,vectorY;
						
						int col=0;

						if (beat_min==0 && beat_max==0)
						{
							beat_min=beat_responder;
							beat_max=beat_responder;
						}
						else
						{
							if (beat_min>beat_responder)
								beat_min=beat_responder;
							if (beat_max<beat_responder)
								beat_max=beat_responder;
						}

						float beat_middle=(beat_max-beat_min)/10.0f;
						
						if (beat_responder>=0)
							col=1;
						if (beat_responder>1*beat_middle+beat_min)
							col=2;
						if (beat_responder>2*beat_middle+beat_min)
							col=3;
						if (beat_responder>3*beat_middle+beat_min)
							col=4;
						if (beat_responder>4*beat_middle+beat_min)
							col=5;
						if (beat_responder>5*beat_middle+beat_min)
							col=6;
						if (beat_responder>6*beat_middle+beat_min)
							col=7;
						if (beat_responder>7*beat_middle+beat_min)
							col=8;
						if (beat_responder>8*beat_middle+beat_min)
							col=9;
						if (beat_responder>9*beat_middle+beat_min)
							col=0;
						for (int j=0;j<10;j++)
						{
							//glColor4f(colors[col][0],colors[col][1],colors[col][2],0.3f);
							
							vertices_count=0;
							indices_count=0;
							colours_count=0;
							texture_count=0;
							
							glPushMatrix();
							glRotatef(xrot/4,1.0f,1.0f,1.0f);
							glTranslatef(0.0f,0.0f,(beat_responder/200));
							
							for(int i=0;i<=120;i++)
							{
								float angle=(float)(((double)i)/57.29577957795135);
								float angle_old;
								if (i!=0)
									angle_old=(float)(((double)(i-1))/57.29577957795135);
								else
									angle_old=0.0f;
								vectorX=originX*beat_responder/60*i/200+(radius*(float)sin((double)xrot/100));
								vectorY=originY*beat_responder/60*i/200+(radius*(float)cos((double)angle-xrot/100));	
								
								tex_coords[texture_count]=0.5f+beat_responder/10+i/100;
								tex_coords[texture_count+1]=0.5f+beat_responder/10+i/100;
								
								vertices[vertices_count	 ]=originX*i/100-j*beat_responder/100;
								vertices[vertices_count+1]=originY*beat_responder/100;
								vertices[vertices_count+2]=-5+(-0.5f*float(j))+j+i*(beat_responder/300)-(float)pow(beat_responder/20,2);
								
								colours[colours_count  ]=colors[col][0];
								colours[colours_count+1]=colors[col][1];
								colours[colours_count+2]=colors[col][2];
								colours[colours_count+3]=0.6f;
								
								tex_coords[texture_count+2]=(float)cos(angle_old*i/100);
								tex_coords[texture_count+3]=(float)sin(angle_old*i/100);
								
								vertices[vertices_count+3]=vectorX1*i/100-j*beat_responder/100;
								vertices[vertices_count+4]=vectorY1*j*(beat_responder/100+1);
								vertices[vertices_count+5]=-5+(-0.5f*float(j))-i*(beat_responder/100);
								
								colours[colours_count+4]=colors[col][0];
								colours[colours_count+5]=colors[col][1];
								colours[colours_count+6]=colors[col][2];
								colours[colours_count+7]=0.6f;
								
								tex_coords[texture_count+4]=(float)cos(angle_old*i/100);
								tex_coords[texture_count+5]=(float)sin(angle_old*i/100);
								
								vertices[vertices_count+6]=vectorX*i/100-j*beat_responder/100;
								vertices[vertices_count+7]=vectorY*j*(beat_responder/100+1);
								vertices[vertices_count+8]=-5+(-0.5f*float(j))-i*(beat_responder/100);
								
								colours[colours_count+8]=colors[col][0];
								colours[colours_count+9]=colors[col][1];
								colours[colours_count+10]=colors[col][2];
								colours[colours_count+11]=0.6f;
								
								indices[indices_count  ]=indices_count;
								indices[indices_count+1]=indices_count+1;
								indices[indices_count+2]=indices_count+2;
								
								vertices_count=vertices_count+9;
								colours_count=colours_count+12;
								texture_count=texture_count+6;
								indices_count=indices_count+3;
								
								vectorY1=vectorY;
								vectorX1=vectorX;
							}
						glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_TRIANGLES, indices_count-1, GL_UNSIGNED_INT, &indices );	
						glPopMatrix();
					}
				glPopMatrix();	
			glPopMatrix();
		}
	}
	glDisable(GL_BLEND);
}

void scene17::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/40)*(beat_responder/40)+0.3f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene17::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;
	multi_texture=rand()%10;


	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(10);
		break;
		case 7:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(11);
		break;
		case 8:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==10)
		multi_texture=0;*/
	return true;
}

