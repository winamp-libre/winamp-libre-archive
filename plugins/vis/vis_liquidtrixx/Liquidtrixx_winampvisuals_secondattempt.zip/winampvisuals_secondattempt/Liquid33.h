#ifndef __LIQUID33_H_
#define __LIQUID33_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"
#include "GLFont.h"
#include "CoolPrint.h"
#include "lines.h"

#ifndef PI
#define PI	3.1415926535897932384626433832795f
#endif PI

#ifndef PI2
#define PI2 6.283185307179586476925286766559f
#endif PI2

#ifndef	N
#define N	7500
#endif N

class scene33:public Manager
{
	class Vector3
	{
	public:
		float x, y, z, r;
		Vector3(float a, float b, float c)
		{
			x = a;
			y = b;
			z = c;
		}
		Vector3()
		{
		}	
	};

	public:
		scene33(double time,float wid,float hei);												
		~scene33();												
		virtual void Draw	(GLuint blend_colour,short* pcm);
		virtual void Update	(float beat_help,short* pcm,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		float		GetTime(void);
		void		ViewOrtho();
		void		ViewPerspective();

		GLuint		m_Texture[5];										
		int			direction;
		int			scene_switcher;
		float		scalefactor;
		float		xrot,t,t2;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		loadall		*textures_in;
		bool		speedTexure;
		float		lastTime,sceneTime;
		Manager		*liquid_next;

		Vector3		petal[27][161];
		GLFont		*fontarial;
		HDC			hDC;	
		int			len, i, j;
		Vector3		p;
		double		r;
		float		R, G, B;
		Lines		lights;

		float		angle,curTime,lastTickCount,realt;
		float		width,height;
};

#endif __LIQUID33_H_
