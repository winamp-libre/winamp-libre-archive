#include "headers.h"
#include "Misc.h"
#include "liquid33.h"

scene33::scene33(double time,float wid,float hei):Manager(time)					
{
	xrot						= 0.0f;
	t							= 0.0f;	
	direction					= -1;
	beat_responder				= 0.0f;
	bg							= new background();
	timeeffect					= 0;
	multi_texture				=0;
	scene_switcher				=-1;
	speedTexure					= FALSE;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB			= ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB	= ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	t2							= 0.0f;
	sceneTime					= 0.0f;
	lastTime					= 0.0f;
	double r, p4, p8, phi;

	lastTickCount = (float)GetTickCount();     
	curTime = 0.0f;					
	hDC=NULL;
	fontarial = new GLFont(hDC, "Arial");
	lights.Init();

	for (int j = 0; j <= 26; j++)
	{
		for (int i = 0; i <= 160; i++)
		{
			phi = i * 21.0f * PI / N;
			p4 = sin(17 * phi / 3);
			p8 = sin(2 * cos(3 * phi) - 28 * phi);
			r = (1 - j * 0.038)* 5 * (1 + sin(11 * phi / 5)) - 4*(p4,4) * pow(p8,8);

			petal[j][i].r = (float) r;
			petal[j][i].x = (float) (r * cos(phi));
			petal[j][i].y = (float) (r * sin(phi));
			petal[j][i].z = (float) (r * r * j * 0.02);
		}
	}
	angle=0.0f;
	width	= wid;
	height	= hei;
	bg								= new background();
}

scene33::~scene33()					
{
}


void scene33::Draw(GLuint blend_colour,short* pcm)
{	
	glClearColor(0.0f, 0.0f, 0.0f, 0.5);
	/*glDisable(GL_FOG);
	glDisable(GL_LIGHTING);
	glDisable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);									
	glDisable(GL_COLOR_MATERIAL);	
	glShadeModel(GL_SMOOTH);	
	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT);
	glColor4f(0.3f, 0.3f, 0.3f, 0.5f);
	glColorMaterial(GL_FRONT_AND_BACK, GL_SPECULAR);
	glColor4f(1.0f, 1.0f, 1.0f, 0.5f);

	glBlendFunc(GL_SRC_ALPHA_SATURATE, GL_ONE);
	glDisable(GL_TEXTURE_2D);

	glMateriali(GL_FRONT, GL_SHININESS, 255);
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);									
		
	glShadeModel(GL_SMOOTH);									

	glBlendFunc(GL_SRC_ALPHA_SATURATE, GL_ONE);

	glMateriali(GL_FRONT, GL_SHININESS, 128);*/
	
	glActiveTextureARB		( GL_TEXTURE0_ARB ); 
	glEnable(GL_TEXTURE_2D);
	glBindTexture			( GL_TEXTURE_2D, m_Texture[0] ); 
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);	 
	glTexGeni(GL_T, GL_EYE_PLANE, GL_EYE_LINEAR);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND );
	
	glActiveTextureARB		( GL_TEXTURE1_ARB ); 
	glEnable(GL_TEXTURE_2D);
	glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);	 
	glTexGeni(GL_T, GL_EYE_PLANE, GL_EYE_LINEAR);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_COLOR);

	glEnable(GL_BLEND);
	//glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);		
	glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);					
	glDisable(GL_DEPTH_TEST);

	glLoadIdentity();
	glPushMatrix();
	
	glTranslatef(2, 2, -.2f);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	lights.RenderFrame(realt);
	glPopMatrix();											
	
	glLoadIdentity();

	glPushMatrix();
	
	glTranslatef(0, 2, -30);

	glRotatef(376.0f, 0, 1, 0);
	glRotatef(335.0f, 1, 0, 0);

	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);

	bg->DrawShaky();
	
	glRotatef(angle+xrot, 0.0f, 0.0f , 1.0f );
	for (j = 0; j <= 26; j++)
	{
		glRotatef(16.4f * j, 0, 0, 1);
		glBegin(GL_POLYGON);
		for (i = 0; i <= 160; i++)
		{
			R = 0.1f + (0.3f * (float)sin(curTime/2800.0f - petal[j][i].r/5.5f));
			G = 0.1f + (0.3f * (float)sin(curTime/1900.0f - petal[j][i].r/4.0f));
			B = 0.1f + (0.3f * (float)cos(curTime/2400.0f - petal[j][i].r/6.0f));
			glColor4f(R, G, B, 0.05f);
			glVertex3f(petal[j][i].x*(1+(beat_responder/((j+1.3f)*(j+1.02f)))), petal[j][i].y, petal[j][i].z);
		}
		glEnd();
	}

	glPopMatrix();
	
	/*glActiveTextureARB		( GL_TEXTURE0_ARB ); 
	glDisable(GL_TEXTURE_2D);
	glActiveTextureARB		( GL_TEXTURE1_ARB ); 
	glDisable(GL_TEXTURE_2D);

	ViewOrtho();

	CoolPrint1(*fontarial, 4, t, 1.5f, 3.0f, 8.0f, 10.0f,width/1.905f,height * 0.73f, 0.12f * width, 2.f, 0.5f, "Peace");
	CoolPrint1(*fontarial, 6, 10-t, -1.0f, 1.0f, 5.0f, 7.0f, width/2.0f, height * 0.9f, 0.097f * width, 0.6f, 0.2f, "all over the world");
	
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	
	ViewPerspective();*/											
	
	glFlush ();
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_LIGHTING);
}

void scene33::Update(float beat_help,short* pcm,float beat_scaler,bool Tex_on)
{
	speedTexure = Tex_on;
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;


	angle += ((float)(GetTickCount() - lastTickCount) / 150.0f);		
	if (angle > 360)
		angle -= 360;
	curTime += (float) (GetTickCount() - lastTickCount);
	lastTickCount = (float)GetTickCount();
	realt = currTime;
	t = fmodf(realt, 12.f);
}

bool scene33::Init(loadall		*textures)
{
	glViewport(0 , 0, (int)width, (int)height);								
	glMatrixMode(GL_PROJECTION);								
	glLoadIdentity();												
	gluPerspective(50, (float)width/(float)height, 0,  2000);	
	glMatrixMode(GL_MODELVIEW); 							
	glLoadIdentity();																				

	textures_in=textures;
	glDisableClientState		( GL_VERTEX_ARRAY );
	glDisableClientState		( GL_COLOR_ARRAY); 
	glDisableClientState		( GL_NORMAL_ARRAY ); 
	glDisableClientState		( GL_TEXTURE_COORD_ARRAY );

	/*glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glDisableClientState		( GL_TEXTURE_COORD_ARRAY );
	glDisable					( GL_TEXTURE_2D   );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glDisableClientState		( GL_TEXTURE_COORD_ARRAY );
	glDisable					( GL_TEXTURE_2D   );

	glActiveTextureARB			( GL_TEXTURE0_ARB );   
	glEnable					( GL_TEXTURE_2D   );     

	glActiveTextureARB			( GL_TEXTURE1_ARB );   
	glEnable					( GL_TEXTURE_2D   );*/

	SceneStart		= GetTickCount();
	fadeffect		= 0;
	
	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(3);
		break;
		case 1:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(1);
		break;
		case 2:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(5);
		break;
		case 3:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(13);
		break;
		case 4:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(3);
		break;
		case 6:
			m_Texture[0]=textures->Bind(23);
			m_Texture[1]=textures->Bind(23);
		break;
		case 7:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(1);
		break;
		case 8:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(23);
		break;
		case 9:
			m_Texture[0]=textures->Bind(24);
			m_Texture[1]=textures->Bind(24);
		break;
	}
	multi_texture=multi_texture++;
	if (multi_texture==10)
		multi_texture=0;
	scene_switcher=scene_switcher++;
	if (scene_switcher==19)
		scene_switcher=0;
	return true;
}

float scene33::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);
}

void scene33::ViewOrtho()										// Set Up An Ortho View
{
	glMatrixMode(GL_PROJECTION);								// Select Projection
	glPushMatrix(); 											// Push The Matrix
	glLoadIdentity();											// Reset The Matrix
	glOrtho( 0, width, height, 0, -1, 1);						// Select Ortho Mode (WIDTHxHEIGHT)
	glMatrixMode(GL_MODELVIEW); 								// Select Modelview Matrix
	glPushMatrix(); 											// Push The Matrix
	glLoadIdentity();											// Reset The Matrix
}

void scene33::ViewPerspective()									// Set Up A Perspective View
{
	glMatrixMode( GL_PROJECTION );								// Select Projection
	glPopMatrix();												// Pop The Matrix
	glMatrixMode( GL_MODELVIEW );								// Select Modelview
	glPopMatrix();												// Pop The Matrix
}





















/////////////////////////////////////////////



		


//	panInitTimer();
//	lights.Init();
//	return TRUE;												// Return TRUE (Initialization Successful)

