#include "math.h"
#include "Vector3.h"

class CCamera {

public:

	CVector3 m_vPosition;								// The camera's position
	CVector3 m_vView;									// The camera's View
	CVector3 m_vUpVector;								// The camera's UpVector

	// Our camera constructor
	CCamera();	
	
	// This changes the position, view, and up vector of the camera.
	// This is primarily used for initialization
	void PositionCamera(float positionX, float positionY, float positionZ,
			 		    float viewX,     float viewY,     float viewZ,
						float upVectorX, float upVectorY, float upVectorZ);

	// This rotates the camera's view around the position using axis-angle rotation
	void RotateView(float angle, float X, float Y, float Z);


//////////// *** NEW *** ////////// *** NEW *** ///////////// *** NEW *** ////////////////////

	// This rotates the camera around a point (I.E. your character).
	// vCenter is the point that we want to rotate the position around.
	// Like the other rotate function, the x, y and z is the axis to rotate around.
	void RotateAroundPoint(CVector3 vCenter, float angle, float x, float y, float z);

//////////// *** NEW *** ////////// *** NEW *** ///////////// *** NEW *** ////////////////////


	// This will move the camera forward or backward depending on the speed
	void MoveCamera(float speed);
};