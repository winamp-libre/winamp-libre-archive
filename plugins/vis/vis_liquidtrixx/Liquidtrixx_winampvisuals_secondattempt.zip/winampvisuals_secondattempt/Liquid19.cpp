#include "headers.h"
#include "Misc.h"
#include "liquid19.h"

scene19::scene19(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glDisable(GL_FOG);

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	for (int i=0;i<20;i++)
		offset[i]=0.0f;

	width						= wid;
	height						= hei;
}

scene19::~scene19()	
{
}


void scene19::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	gluLookAt(0, 0, 10,     0, 0, 0,     0, 1, 0);

	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};

	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glActiveTextureARB ( GL_TEXTURE1_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	
	glRotatef(xrot,1.0f,1.0f,1.0f);
	glPushMatrix();
	for (int i=0;i<10;i++)
	{
		glColor4f(colors[i][0],colors[i][1]+beat_responder/255,colors[i][2]+beat_responder/120,0.2f+i*beat_responder/10000.0f);

		bg->DrawPlasma((float)pow(xrot/6000,2)*i);
		bg->DrawRotateTile((float)pow(xrot/5000,2)*i);
	}
	glPopMatrix();
}

void scene19::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((float)pow(beat_responder/30,2)+0.1f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene19::Init(loadall		*textures)
{
	
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%10;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(2);
		break;
		case 1:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(1);
		break;
		case 2:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(1);
		break;
		case 3:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(6);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(6);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==10)
		multi_texture=0;*/
	return true;
}

