#ifndef __LIQUID20_H_
#define __LIQUID20_H_

#include "TextureLoader.h"
#include "Scenemanager.h"										
#include "Background.h"
#include "particle.h"

class scene20:public Manager
{

	public:
		scene20(double time,float wid,float hei);												
		~scene20();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:

		GLuint		m_Texture[5];										
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		float		lastTime,sceneTime;
		float		offset[20];
		particle	*particle1;
		particle	*particle2;
		particle	*particle3;
		particle	*particle4;
		particle	*particle5;
		float		slowdown;
		GLfloat		xspeed,yspeed;
		GLuint		col;
		int			delay;
		float		help2;
		float		width,height;
};

#endif __LIQUID20_H_
