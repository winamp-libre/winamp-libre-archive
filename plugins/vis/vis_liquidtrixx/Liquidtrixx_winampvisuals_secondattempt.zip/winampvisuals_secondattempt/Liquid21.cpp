#include "headers.h"
#include "Misc.h"
#include "liquid21.h"

scene21::scene21(double time,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	slowdown=0.0f;
	xspeed	=2.0f;
	yspeed	=4.0f;
	col		=0;
	delay	=0;
	help2	=0.0f;

	width						= wid;
	height						= hei;
}

scene21::~scene21()	
{
}


void scene21::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glEnable(GL_FOG);
	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glActiveTextureARB ( GL_TEXTURE1_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	float originX=(0.3f+beat_responder/10)*(float)cos(timeeffect/10000.0f);
	float originY=(0.3f+beat_responder/10)*(float)sin(timeeffect/10000.0f);
	for (int z=0;z<2;z++)
	{
		
	glPushMatrix();
	glRotatef(180.0f*z,0.0f,0.0f,1.0f);
		float radius=1.0f+(float)pow((beat_responder/60),2);

		float vectorY1=originY+radius+beat_responder/50;
		float vectorX1=originX+beat_responder/50;
		float vectorX,vectorY;
		vectorY1=originY;
		vectorX1=originX;
		for (int j=0;j<30;j++)
		{
			glColor4ub(0,rand()%256,250,120-(j*3));
			glPushMatrix();
				glRotatef(xrot/10,0.0f,0.0f,1.0f);
				glTranslatef((beat_responder/100),0.0f,-10.0f+(float)pow(beat_responder/20,2));
				glBegin(GL_TRIANGLES);	
					for(int i=0;i<=360;i++)
					{
						float angle=(float)(((double)i)/57.29577957795135);
						float angle_old;
						if (i!=0)
							angle_old=(float)(((double)(i-1))/57.29577957795135);
						else
							angle_old=0.0f;
						vectorX=originX+(radius*(float)sin((double)angle));
						vectorY=originY+(radius*(float)cos((double)angle));	
						glTexCoord2f(0.5f+beat_responder/50,0.5f+beat_responder/100);
						glVertex3f(originX,originY,-2*float(j)+(beat_responder/20));
						glTexCoord2f((float)cos(angle_old),(float)sin(angle_old));
						glVertex3f(vectorX1,vectorY1,-2*float(j)+(beat_responder/20));
						glTexCoord2f((float)cos(angle_old),(float)sin(angle_old));
						glVertex3f(vectorX,vectorY,-2*float(j)+(beat_responder/20));
						vectorY1=vectorY;
						vectorX1=vectorX;
					}
				glEnd();
			glPopMatrix();
		}
	glPopMatrix();
	}
}

void scene21::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((float)pow(beat_responder/30,2)+0.1f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
	help2+=direction*beat_responder/20;
}

bool scene21::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState       ( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;
	multi_texture=rand()%5;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(2);
		break;
		case 1:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(1);
		break;
		case 2:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(1);
		break;
		case 3:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(1);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==6)
		multi_texture=0;*/
	return true;
}

