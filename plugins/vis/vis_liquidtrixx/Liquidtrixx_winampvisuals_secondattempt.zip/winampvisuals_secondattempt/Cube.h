#ifndef __CUBE_H_
#define __CUBE_H_

class cube
{
	public:
		cube();													// Constructor
		~cube();												// Destructor
		void Draw(GLfloat tex_cord,GLfloat roll,GLuint m_Texture[],float number,float xrot);
		void Update(GLuint blend_colour,float beat,DWORD timeeffect);
		void Init(void);
	private:
		PFNGLCLIENTACTIVETEXTUREARBPROC		glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC			glActiveTextureARB;
		GLfloat vertices[72];
		GLuint	indices[24];
		GLfloat normals[72];
		GLfloat colours[96];
		DWORD	time;
		int i;
		int	scene_timer;
		float beat_responder,beat_min,beat_max;
		int texturechanger;
};	

#endif __CUBE_H_
