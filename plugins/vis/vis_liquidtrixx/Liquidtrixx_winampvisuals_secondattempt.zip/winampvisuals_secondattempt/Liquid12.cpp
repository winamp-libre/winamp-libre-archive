#include "headers.h"
#include "Misc.h"
#include "liquid12.h"

scene12::scene12(double time,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;

	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	col = 0;
	ret	= 0;
	scene_switcher	= -1;
	sceneTime		= 0;
	lastTime		= 0;

	width						= wid;
	height						= hei;
	beat_min		= 0.0f;
	beat_max		= 0.0f;
}

scene12::~scene12()					
{
}


void scene12::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	gluLookAt(0, 0, 1,     0, 0, 0,     0, 1, 0);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);																	
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glShadeModel(GL_SMOOTH);																			
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);																
	glClearDepth(1.0f);																					
	glDepthFunc(GL_LEQUAL);																				
	glDisable(GL_DEPTH_TEST);																			
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	float scale=1.0f;
	int rand_texture=0;
	glTranslatef(0.0f,0.0f,-20.0f+beat_responder/20);
	
	if (scene_switcher<=10)
	{
		glActiveTextureARB ( GL_TEXTURE0_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB ( GL_TEXTURE1_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	else
	{
		glActiveTextureARB ( GL_TEXTURE0_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glEnable(GL_TEXTURE_GEN_S);																
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

		glActiveTextureARB ( GL_TEXTURE1_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glEnable(GL_TEXTURE_GEN_S);																
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
	}

	glPushMatrix();
	glTranslatef((float)sin(sceneTime),(float)cos(sceneTime),0.0f);
	glPushMatrix();	
		glScalef(1.0f+beat_responder/10,1.0f+beat_responder/10,1.0f);
		
		glRotatef(xrot,1.0f,1.0f,1.0f);
		glPushMatrix();
			int max_rec=10;
			for (int loop=0;loop<max_rec;loop++)
			{
				
				glPushMatrix();
					glRotatef(xrot*loop/(max_rec),0.0f,1.0f,0.0f);
					rectangle2((float)(loop/max_rec)*(float)pow(beat_responder/10,2));
				glPopMatrix();
			}
		glPopMatrix();
	glPopMatrix();
	glPopMatrix();
}

void scene12::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	if (beat_min==0 && beat_max==0)
	{
		beat_min=beat_responder;
		beat_max=beat_responder;
	}
	else
	{
		if (beat_min>beat_responder)
			beat_min=beat_responder;
		if (beat_max<beat_responder)
			beat_max=beat_responder;
	}
	xrot+=direction*((beat_responder/40)*(beat_responder/40))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;

	ret+=(int)beat_responder/60;
		
	if (ret>=80)
		ret=0;


	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;
}

bool scene12::Init(loadall		*textures)
{
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;
	lastTime		= GetTime();
	sceneTime		= 0;

	multi_texture=rand()%10;
	scene_switcher=rand()%20;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(5);
			m_Texture[1]=textures->Bind(6);
		break;
		case 1:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(1);
		break;
		case 2:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(5);
			m_Texture[1]=textures->Bind(3);
		break;
		case 4:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(4);
		break;
		case 5:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(0);
		break;
		case 6:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(10);
		break;
		case 7:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(11);
		break;
		case 8:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(12);
		break;
		case 9:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(13);
		break;
	}
	//multi_texture=multi_texture++;
	//if (multi_texture==10)
	//	multi_texture=0;
	//scene_switcher=scene_switcher++;
	//if (scene_switcher==20)
	//	scene_switcher=0;
	return true;
}
void scene12::rectangle2(float scale) 

{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};
	int col=0;
	float beat_middle=(beat_max-beat_min)/10.0f;
	if (beat_responder>=0)
		col=1;
	if (beat_responder>1*beat_middle+beat_min)
		col=2;
	if (beat_responder>2*beat_middle+beat_min)
		col=3;
	if (beat_responder>3*beat_middle+beat_min)
		col=4;
	if (beat_responder>4*beat_middle+beat_min)
		col=5;
	if (beat_responder>5*beat_middle+beat_min)
		col=6;
	if (beat_responder>6*beat_middle+beat_min)
		col=7;
	if (beat_responder>7*beat_middle+beat_min)
		col=8;
	if (beat_responder>8*beat_middle+beat_min)
		col=9;
	if (beat_responder>9*beat_middle+beat_min)
		col=0;

	glPushMatrix();
	glScalef(scale+1.0f,scale+1.0f,scale+1.0f);
	float scale_vert=beat_responder/60.0f;
	float scale_vert2=0.0f;
	
	GLfloat vertices[]=
	{	
		-1.0f-scale_vert, -1.0f-scale_vert,  1.0f+scale_vert2,
		 1.0f+scale_vert, -1.0f-scale_vert,  1.0f+scale_vert2,
		 1.0f+scale_vert,  1.0f+scale_vert,  1.0f+scale_vert2,
		-1.0f-scale_vert,  1.0f+scale_vert,  1.0f+scale_vert2,

		-1.0f-scale_vert, -1.0f-scale_vert, -1.0f-scale_vert2,
		-1.0f-scale_vert,  1.0f+scale_vert, -1.0f-scale_vert2,
		 1.0f+scale_vert,  1.0f+scale_vert, -1.0f-scale_vert2,
		 1.0f+scale_vert, -1.0f-scale_vert, -1.0f-scale_vert2,

		-1.0f-scale_vert,  1.0f+scale_vert, -1.0f-scale_vert2,
		-1.0f-scale_vert,  1.0f+scale_vert,  1.0f+scale_vert2,
		 1.0f+scale_vert,  1.0f+scale_vert,  1.0f+scale_vert2,
		 1.0f+scale_vert,  1.0f+scale_vert, -1.0f-scale_vert2,

		-1.0f-scale_vert, -1.0f-scale_vert, -1.0f-scale_vert2,
		 1.0f+scale_vert, -1.0f-scale_vert, -1.0f-scale_vert2,
		 1.0f+scale_vert, -1.0f-scale_vert,  1.0f+scale_vert2,
		-1.0f-scale_vert, -1.0f-scale_vert,  1.0f+scale_vert2,

		 1.0f+scale_vert, -1.0f-scale_vert, -1.0f-scale_vert2,
		 1.0f+scale_vert,  1.0f+scale_vert, -1.0f-scale_vert2,
		 1.0f+scale_vert,  1.0f+scale_vert,  1.0f+scale_vert2,
		 1.0f+scale_vert, -1.0f-scale_vert,  1.0f+scale_vert2,

		-1.0f-scale_vert, -1.0f-scale_vert, -1.0f-scale_vert2,
		-1.0f-scale_vert, -1.0f-scale_vert,  1.0f+scale_vert2,
		-1.0f-scale_vert,  1.0f+scale_vert,  1.0f+scale_vert2,
		-1.0f-scale_vert,  1.0f+scale_vert, -1.0f-scale_vert2
	};

	GLfloat tex_coords[]=
	{
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f,

		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f,
		0.0f, 0.0f,

		0.0f, 1.0f,
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,

		1.0f, 1.0f,
		0.0f, 1.0f,
		0.0f, 0.0f,
		1.0f, 0.0f,

		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f,
		0.0f, 0.0f,

		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f
	};

	float blend_colour=0.2f;

	GLfloat		colours[]=
	{
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,

		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,

		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,

		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,

		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,

		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
		colors[col][0],colors[col][1],colors[col][2],0.2f+blend_colour,
	};

	GLuint		indices[]={	0,1,2,3,
							4,5,6,7,
							8,9,10,11,
							12,13,14,15,
							16,17,18,19,
							20,21,22,23};

	glClientActiveTextureARB	( GL_TEXTURE0_ARB             ); 
	glTexCoordPointer			( 2, GL_FLOAT, 0, &tex_coords ); 
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB             );  
	glTexCoordPointer			( 2, GL_FLOAT, 0, &tex_coords );

	glEnableClientState			( GL_VERTEX_ARRAY );
	glEnableClientState			( GL_COLOR_ARRAY );
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	glVertexPointer				( 3, GL_FLOAT, 0, &vertices );
	glColorPointer  ( 4, GL_FLOAT, 0, &colours );
	glDrawElements  ( GL_QUADS, 24, GL_UNSIGNED_INT, &indices );

	glPopMatrix();
}

float scene12::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);

}
