#include "headers.h"
#include "Misc.h"
#include "welcome.h"

welcome::welcome(float wid,float hei)					
{
	bg							= new background();

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB			= ( PFNGLCLIENTACTIVETEXTUREARBPROC )	wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB	= ( PFNGLACTIVETEXTUREARBPROC )			wglGetProcAddress  ( "glClientActiveTextureARB" );

	width						= wid;
	height						= hei;

}

welcome::~welcome()					
{
}


void welcome::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{	
	getfilename("Data\\Maetor.jpg",this_mod,0);
	glDisable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,w_Texture[0]);
	glColor3f(1.0f,0.0f,1.0f);
	glBegin(GL_QUADS);
		glVertex3f(-1.0f, 1.0f, 0.0f);
		glVertex3f( 1.0f, 1.0f, 0.0f);
		glVertex3f( 1.0f,-1.0f, 0.0f);
		glVertex3f(-1.0f,-1.0f, 0.0f);
	glEnd();
	
}

void welcome::Update(struct winampVisModule *this_mod)
{
	glViewport (0, 0, (GLsizei)width, (GLsizei)height);				
	glMatrixMode (GL_PROJECTION);										
	glLoadIdentity ();													
	gluPerspective(30.0f,(GLfloat)width/(GLfloat)height,0.5f,120.0f);		
	glMatrixMode (GL_MODELVIEW);										
	glLoadIdentity ();	
}

void welcome::getfilename(LPSTR strFileName,struct winampVisModule *this_mod,int id)
{
	char *ini_file=new char[70];
	char *help=new char[70];
	char *p;
	GetModuleFileName(this_mod->hDllInstance,ini_file,MAX_PATH);
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) 
		*p = 0;
	strcpy(help,ini_file);
	strcat(help,strFileName);
	JPEG_Texture(w_Texture,help,id);
}

