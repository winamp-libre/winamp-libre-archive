#include "headers.h"
#include "Misc.h"
#include "liquid27.h"

scene27::scene27(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,float wid,float hei):Manager(time)					
{
	TextGen			= generatedtextures;
	Meshes			= generatedmeshes;
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	for (int i=0;i<20;i++)
		offset[i]=0.0f;

	width						= wid;
	height						= hei;
}

scene27::~scene27()	
{
}


void scene27::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	GLuint linelist;
	linelist = glGenLists(1);

	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glActiveTextureARB ( GL_TEXTURE1_ARB ); 
	glDisable(GL_TEXTURE_2D);

	glActiveTextureARB ( GL_TEXTURE0_ARB );

	float lightPos[] = {0, 0, 0, 1};
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glEnable(GL_LIGHT0);

	vec campos;

	campos.x = beat_responder/10;
	campos.y = 1;
	campos.z = -10;

	gluLookAt(campos.x, campos.y, campos.z, 0, 0, 0, 0, 1, 0);

	glDisable(GL_LIGHTING);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	
	glDepthMask(GL_FALSE);

	//TextGen->t_metal2->Bind();
	glColor4f(1, 0, 0.7f,1.0f);
	
	sceneTime *= 2;
	vec line[100];
	glNewList(linelist,GL_COMPILE);
		
		
		for(int b = 1; b < 3; b++)
		{
			int c=0;
			for(int a = 0; a < 50; a++)
			{
				//float waveform2=(32767.0f-pcm[int(a*4)])*SPECHEIGHT/265536.0f;
				int waveform2=this_mod->waveformData[1][int(a*8)]/127;
				line[c].x = a*0.1f*((-1+(float)cos(a*0.2f+sceneTime*4*semirand(b)))/2)-b*2;
				line[c].y = sinf(a*0.2f+sceneTime*4*semirand(b))+beat_responder/5 + sinf(a*0.5f)*0.05f;
				line[c].z = sinf(a*0.1f+sceneTime*3*semirand(b))*beat_responder/5;
				line[c].y=line[c].y/(c-50)+(float)pow(beat_responder/60,2)+waveform2/800;
				line[c].z=line[c].z/(c-50)+(float)pow(beat_responder/60,2)+waveform2/800;
				c++;
			}

			drawline(line, 50, 0.2f, campos,beat_responder);
		}
	
	glEndList();

	glTranslatef(1*(float)cos(sceneTime*2*semirand(3)),0.0f,-6*(float)cos(sceneTime*semirand(3)));
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );
	glPushMatrix();
		glRotatef(xrot,0.0f,0.0f,1.0f);
		for (int j=0;j<6;j++)
		{
			glRotatef(45,0.0f,1.0f,0.0f);
			for (int i=1;i<9;i++)
			{
				glRotatef(45,0.0f,0.0f,1.0f);
				glCallList(linelist);
			}
		}
	glPopMatrix();
	glDeleteLists(linelist,1);

	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);

	glColor4f(0.9f, 0.3f, 0.9f,0.4f);

	glDisable(GL_LIGHTING);
	glPushMatrix();
	glRotatef(xrot, 0, 1, 0);

	for (int i=-3;i<3;i++)
	{
		glPushMatrix();
			glScalef(1.0f*i+beat_responder/120,1.0f*i+beat_responder/120,1.0f*i+beat_responder/120);
			Meshes->m_distsphere2->Draw();
		glPopMatrix();
	}
	glPopMatrix();
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	
	glDepthMask(GL_TRUE);
	glDisable(GL_BLEND);

	sceneTime /= 2.0f;
}

void scene27::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((float)pow(beat_responder/30,2)+0.1f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene27::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glDisableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glDisableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;
	sceneTime		= 0;
	lastTime		= 0;
	
	multi_texture=rand()%6;
	
	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==6)
		multi_texture=0;*/
	return true;
}

void scene27::drawline(const vec *points, int numPoints, float width, const vec &campos,float beat_help)
{
	vec lookat = campos - points[0];
	vec dir = points[1] - points[0];	
	
	vec x, tmp;
	
	glBegin(GL_QUADS);
		for(int a = 0; a < numPoints-1; a++)
		{
			x = lookat*dir;
			x.Normalize();
			
			tmp = points[a] + x * width;
			glTexCoord2f(0, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);				
			
			tmp = points[a] - x * width;
			glTexCoord2f(1, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			lookat = campos - points[a+1];
			dir = points[a+1] - points[a];
			x = lookat * dir;
			x.Normalize();
			
			tmp = points[a+1] - x*width;
			glTexCoord2f(1, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			tmp = points[a+1] + x*width;
			glTexCoord2f(0, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);			
		}
	glEnd();
}

float scene27::semirand(int x)
{
	x = (x<<13) ^ x;
	return ( 1.0f - ( (x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f); 
}

float scene27::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);

}

