#ifndef __MESHGENERATION_H_
#define __MESHGENERATION_H_

#include "Texture.h"
#include "Mesh.h"

class MeshGeneration
{

	public:
		MeshGeneration();												
		~MeshGeneration();	

	public:
		Mesh *m_distsphere;
		Mesh *m_distsphere2;
		Mesh *m_weirdsphere;
		Mesh *m_insidesphere;
};

#endif __MESHGENERATION_H_
