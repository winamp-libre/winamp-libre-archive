#ifndef __LIQUID9_H_
#define __LIQUID9_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"

class scene9:public Manager
{

	public:
		typedef struct																							// Create A Structure For Particle
		{
			bool	active;																						// Active (Yes/No)
			float	life;																						// Particle Life
			float	fade;																						// Fade Speed
			float	r;																							// Red Value
			float	g;																							// Green Value
			float	b;																							// Blue Value
			float	x;																							// X Position
			float	y;																							// Y Position
			float	z;																							// Z Position
			float	xi;																							// X Direction
			float	yi;																							// Y Direction
			float	zi;																							// Z Direction
			float	xg;																							// X Gravity
			float	yg;																							// Y Gravity
			float	zg;																							// Z Gravity
		}
		particles;

		scene9(double time,float wid,float hei);												
		~scene9();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		GLuint		m_Texture[5];										
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		int			col,ret;
		particles	particle[500];
		int			scenechanger;

		float		width,height;
};

#endif __LIQUID9_H_
