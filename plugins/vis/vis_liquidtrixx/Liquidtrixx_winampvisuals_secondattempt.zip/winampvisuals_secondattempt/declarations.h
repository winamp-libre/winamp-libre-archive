#include "headers.h"
#include "vis.h"
#include "winampdetectbeat.h"
#include "structures.h"
#include "beat_return.h"

const FPS_TIMER = 1;
const FPS_INTERVAL = 2000;

														
HGLRC	hRC=NULL;																					// Der OpenGL Rendering Context
HDC		hDC=NULL;																					// Gesch�tzter GDI Device Context
HWND	hWnd=NULL;																					// Verweist sp�ter auf den Windows Handle
HINSTANCE hInstance;
HWND	hMainWnd;																					// main window handle
HDC		memDC;																						// memory device context
HBITMAP	memBM,																						// memory bitmap (for memDC)
		oldBM;																						// old bitmap (from memDC)																									// Die Instanz der Anwendung
				
char	szAppName[] = "LiquidtriXX level2b";																		// Our window class, etc
char	*tmp=new char[70]; 
char	*title=new char[70];
char	*old_title=new char[70];
char	** title_winamp;
								
int		width=1024 ,config_x = 1600 ,height=768 ,config_y	=1200 ;
int		key=1;		
int		current_window_size=4;											
int		now_playing,pos;
float	old_beat,beat_help						=0.0f;
bool	keys[256];																				// Vektor (Array) der den Status einzelner Tasten enth�lt (gedr�ckt/nicht gedr�ckt)
bool	done=FALSE;
bool	new_title=TRUE;
bool	fullscreen=TRUE;																			// L�uft das Programm im Vollbildmodus oder nicht?
bool	change_scene=TRUE;
bool	active=TRUE;

/* --------------------------------------------------------------------------------------------------------------------*/
/* -----------------------------------------------------winamp functions-----------------------------------------------*/
/* --------------------------------------------------------------------------------------------------------------------*/
																									// configuration declarations
void	config_read(struct winampVisModule *this_mod);												// reads the configuration
void	config_write(struct winampVisModule *this_mod);												// writes the configuration
void	config_getinifn(struct winampVisModule *this_mod, char *ini_file);							// makes the .ini file filename																			
		winampVisModule *getModule(int which);														// returns a winampVisModule when requested. Used in hdr, below
void	config(struct winampVisModule *this_mod);													// configuration dialog
int		init(struct winampVisModule *this_mod);														// initialization for module
int		render(struct winampVisModule *this_mod);													// rendering for winamp module
void	quit(struct winampVisModule *this_mod);														// deinitialization for module
void	quit3(struct winampVisModule *this_mod);													// deinitialization for module and restart


LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

/* --------------------------------------------------------------------------------------------------------------------*/
/* -------------Module header, includes version, description, and address of the module retriever function-------------*/
/* --------------------------------------------------------------------------------------------------------------------*/

winampVisHeader hdr = { VIS_HDRVER, "LiquidtriX Visualisation plugin for winamp", getModule };

/* --------------------------------------------------------------------------------------------------------------------*/
/* ----------------------------------------------------module OpenGL---------------------------------------------------*/
/* --------------------------------------------------------------------------------------------------------------------*/

winampVisModule mod =
{
	"LiquidtriXX LeveL 2.0b",
	NULL,																							// hwndParent
	NULL,																							// hDllInstance
	0,																								// sRate
	0,																								// nCh
	1,																								// latencyMS
	1,																								// delayMS
	2,																								// spectrumNch
	2,																								// waveformNch
	{ 0, },																							// spectrumData
	{ 0, },																							// waveformData
	config,
	init,
	render, 
	quit
};



