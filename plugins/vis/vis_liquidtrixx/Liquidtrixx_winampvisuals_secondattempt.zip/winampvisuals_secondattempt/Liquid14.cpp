#include "headers.h"
#include "Misc.h"
#include "liquid14.h"

scene14::scene14(double time,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;

	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	width						= wid;
	height						= hei;
}

scene14::~scene14()					
{
}


void scene14::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);
	GLfloat vertices[]=
	{	
		-1.0f, -1.0f, 0.0f,
		 1.0f, -1.0f, 0.0f,
		 1.0f,  1.0f, 0.0f,
		-1.0f,  1.0f, 0.0f
	};

	GLfloat tex_coords[]=
	{
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f
	};

	GLuint		indices[]={0,1,2,3};

	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );


	glVertexPointer ( 3, GL_FLOAT, 0, &vertices );


	int Layers=50;
	ElapsedTime=xrot/10;
	glTranslatef(0.0f,0.0f,-3.0f);
	
	/*-------------------------------------------------- Background----------------------------------------*/

	glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );

	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
	glEnable(GL_BLEND);
	glDisable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

	glActiveTextureARB ( GL_TEXTURE1_ARB );
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glPushMatrix();
		glTranslatef(0.0f,0.0f,1.5f);
		glRotatef(ElapsedTime, 0.0f, 0.0f, 1.0f);
		glRotatef(5*(float)sin(ElapsedTime/800), 1.0f, 0.0f, 0.0f);
		glRotatef(7*(float)sin(ElapsedTime/600), 0.0f, 1.0f, 0.0f);
		glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
		glColorPointer  ( 4, GL_FLOAT, 0, &colours );
		glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
		glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
	glPopMatrix();
	glEnable(GL_BLEND);
	
	/*-------------------------------------------------- plasma effect---------------------------------------*/

	glDisable(GL_DEPTH_TEST);	
	glTranslatef(0.0,0.0,-1);

	glBindTexture(GL_TEXTURE_2D, m_Texture[1]);
	glPushMatrix();
		glScalef(1.0f+(float)pow(beat_responder/60,2),1.0f+(float)pow(beat_responder/60,2),1.0f);
		for (int i=0;i<Layers;i++)
		{
			float Temp	=(ElapsedTime + i*2.0f) / 4.0f;
			float XSize	=1.0f + 0.5f*(float)cos(Temp);
			float YSize	=1.0f + 0.5f*(float)cos(0.8*Temp);
			float Angle	=180.0f + 180.0f*(float)sin((Temp-i)/30.0f);
			float XPos	=0.7f*(float)sin(Temp/8);
			float YPos	=0.6f*(float)cos(Temp/4);
			
			div_t div_result=div( i, 16 );
			
			glPushMatrix();
				glTranslatef(XPos,YPos,0);
				glRotatef (Angle, 0.0, 0.0, 1.0);
				glScalef(XSize, YSize, 1);
				glColor3f(R[div_result.rem], G[div_result.rem], B[div_result.rem]);
				
				glColorPointer  ( 4, GL_FLOAT, 0, &colours );
				glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
				glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
			glPopMatrix ();
		}
	glPopMatrix ();
}

void scene14::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};

	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/15)*(beat_responder/15));
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
	if (beat_min==0 && beat_max==0)
	{
		beat_min=beat_responder;
		beat_max=beat_responder;
	}
	else
	{
		if (beat_min>beat_responder)
			beat_min=beat_responder;
		if (beat_max<beat_responder)
			beat_max=beat_responder;
	}

	float beat_middle=(beat_max-beat_min)/10.0f;
	int col=0;
	if (beat_responder>=0)
		col=1;
	if (beat_responder>1*beat_middle+beat_min)
		col=2;
	if (beat_responder>2*beat_middle+beat_min)
		col=3;
	if (beat_responder>3*beat_middle+beat_min)
		col=4;
	if (beat_responder>4*beat_middle+beat_min)
		col=5;
	if (beat_responder>5*beat_middle+beat_min)
		col=6;
	if (beat_responder>6*beat_middle+beat_min)
		col=7;
	if (beat_responder>7*beat_middle+beat_min)
		col=8;
	if (beat_responder>8*beat_middle+beat_min)
		col=9;
	if (beat_responder>9*beat_middle+beat_min)
		col=0;
	for (i=0;i<16;i=i+4)
	{
		colours[i  ] =colors[col][0];
		colours[i+1] =colors[col][1];
		colours[i+2] =colors[col][2];
		colours[i+3] =0.3f;
	}
}

bool scene14::Init(loadall		*textures)
{
	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%9;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(7);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(2);
		break;
		case 2:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(3);
		break;
		case 3:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(5);
		break;
		case 5:
			m_Texture[0]=textures->Bind(5);
			m_Texture[1]=textures->Bind(6);
		break;
		case 6:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(10);
		break;
		case 7:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(11);
		break;
		case 8:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	//multi_texture=multi_texture++;
	//if (multi_texture==10)
	//	multi_texture=0;
	return true;
}

