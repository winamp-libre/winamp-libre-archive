#ifndef __LIQUID13_H_
#define __LIQUID13_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"
#include "TextGeneration.h"
#include "MeshGeneration.h"

class scene13:public Manager
{

	public:
		scene13(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,float wid,float hei);												
		~scene13();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		float		GetTime(void);
		void		drawline(const vec *points, int numPoints, float width, const vec &campos,float beat_help);
		float		semirand(int x);

		GLuint		m_Texture[5];										
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		int			col,ret;
		TextGeneration*	TextGen;
		MeshGeneration* Meshes;
		float		lastTime,sceneTime;
		float		width,height;
};

#endif __LIQUID13_H_
