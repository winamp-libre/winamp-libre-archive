#include "headers.h"
#include "Misc.h"
#include "liquid3.h"

scene3::scene3(double time,TextGeneration* generatedtextures,float wid,float hei):Manager(time)					
{
	TextGen							= generatedtextures;
	TUNNEL_SPEED=1/240;
	PI_8= 0.3926990816987f;
	//loadTextures();
	glClientActiveTextureARB		= NULL;
	glActiveTextureARB				= NULL;
	glActiveTextureARB				= ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB		= ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
   
	TunnelStart						=0;

	xrot			=0.0f;
	t				=0.0f;	
	direction		=-1;
	beat_responder	=0.0f;
	multi_texture	=0;
	
	timeeffect					= 0;
	scene_switcher = -1;

	width						= wid;
	height						= hei;
}

scene3::~scene3()					
{
}

void scene3::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};

	int col=0;

	if (beat_responder>5)
		col=1;
	if (beat_responder>10)
		col=2;
	if (beat_responder>15)
		col=3;
	if (beat_responder>20)
		col=4;
	if (beat_responder>25)
		col=5;
	if (beat_responder>30)
		col=6;
	if (beat_responder>35)
		col=7;
	if (beat_responder>40)
		col=8;
	if (beat_responder>45)
		col=9;
	if (beat_responder>50)
		col=0;

	glClearColor(0.0, 0.0, 0.0, 0.5); 	   
	glShadeModel(GL_SMOOTH);                 
	glClearDepth(1.0);                       
	glDisable(GL_DEPTH_TEST);                 
	glDepthFunc(GL_LESS);		           
	glBlendFunc(GL_ONE, GL_ONE);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);   
	glEnable(GL_TEXTURE_2D);                     
	glEnable(GL_TEXTURE_GEN_S);															
	glEnable(GL_TEXTURE_GEN_T);
	glDisable(GL_NORMALIZE);
	vertices_count=0;
	indices_count=0;
	colours_count=0;
	texture_count=0;
	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );

	GLfloat ambientLight[] = { 1.0f, 0.7f, 0.8f, 0.5f };    
	GLfloat diffuseLight[] = { 1.0f, 1.0f, 1.0f, 0.5f };			
	GLfloat specular[]     = { 1.0f, 0.0f, 0.8f, 1.0f };			
	GLfloat specref[]      = { 0.0f, 0.0f, 1.0f, 1.0f };			
	GLfloat lightPos[]     = { 0.0f, 0.0f, 50.0f, 1.0f };
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);					
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);					
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);					
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);					

	GLfloat LightAmbient [4];
	GLfloat LightDiffuse [4];
	GLfloat LightPosition[4];

	LightAmbient[0] = 1.5f;
	LightAmbient[1] = 2.5f;
	LightAmbient[2] = 3.5f;
	LightAmbient[3] = 4.0f;


	LightDiffuse[0] = 2.0f;
	LightDiffuse[1] = 3.0f;
	LightDiffuse[2] = 4.0f;
	LightDiffuse[3] = 4.0f;


	LightPosition[0]= 3.0f;
	LightPosition[1]= 3.0f;
	LightPosition[2]= 5.0f;
	LightPosition[3]= 6.0f;


	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuseLight);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);

	glEnable(GL_COLOR_MATERIAL);									

	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);		

	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specref);					
	glMateriali( GL_FRONT_AND_BACK, GL_SHININESS, 255);						

	GLuint	fogMode[]	= { GL_EXP, GL_EXP2, GL_LINEAR };
	GLfloat fogColor[4]	= {colors[col][0],colors[col][1],colors[col][2],0.1f}; 
	glFogi(GL_FOG_MODE, GL_LINEAR);								
	glFogi(GL_FOG_MODE, fogMode[2]);						
	glFogfv(GL_FOG_COLOR, fogColor);						
	glFogf(GL_FOG_DENSITY, 0.03f);							
	DWORD ticker_help=GetTickCount();
	internal_timer=ticker_help - TunnelStart;
	if (internal_timer>80000)
		TunnelStart=ticker_help;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	t+=(beat_responder/20.0f)*0.01f*(float)cos(timeeffect/300.0f*(beat_responder))*direction;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/5)	
		direction=-1;
	if (t<-1.5*beat_responder/5)
		direction=1;
	glFogf(GL_FOG_START, 40.0f-beat_responder/2);
	glFogf(GL_FOG_END, 50.0f+beat_responder/2);

	glEnable(GL_DEPTH_TEST);
}

void scene3::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	int I, J;
    GLfloat C, J1, J2;
    GLfloat X, Y;
    GLfloat Angle;
    GLfloat A1, A2, A3, A4;
    int DemoTime;	
	
	DemoTime =internal_timer;
	
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);

	glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glEnable(GL_FOG);

	glPushMatrix();
		glTranslatef(0.0,0.0,-2.0f);
		Angle = DemoTime*(beat_responder/30000.0f);
		
		A1 = (float)sin(Angle/27.0f);
		A2 = (float)cos(Angle/33.0f);
		A3 = (float)cos(Angle/13.0f);
		A4 = (float)sin(Angle/17.0f);
		for (I =0;I<=16;I++)
		{
			X =(float)cos(PI_8*I);
			Y =(float)sin(PI_8*I);
			for (J=0 ;J<=32;J++) 
			{
				
				Tunnels[I][J].x =(float)((3.0f - J/12.0f)*X + 2.0f*sin((Angle+2.0f*J)/27.0f) + cos((Angle+2.0f*J)/13.0f) - 2.0f*A1 - A3)*(1+((float)sin(xrot/200+3*this_mod->waveformData[0][I*J]/500)/300));
				Tunnels[I][J].y =(float)((3.0f - J/12.0f)*Y + 2.5f*cos((Angle+2.0f*J)/33.0f) + sin((Angle+2.0f*J)/17.0f) - 2.0f*A2 - A4)*(1+((float)sin(xrot/200+3*this_mod->waveformData[0][I*J]/500)/300));
				Tunnels[I][J].z =(float)-J*(1.5f+0.2f*(float)sin(xrot/1800));
			}
		}

		for (J =0;J<=31;J++)
		{
			J1 =J/64.0f + Angle*(TUNNEL_SPEED)+xrot/300;        
			J2 =(J+1.0f)/64.0f + Angle*(TUNNEL_SPEED)+xrot/300;

		
			if (J > 24)
				C =(float)(1.0f-(J-24.0f)/10.0f);
			else
				C =1.0f;

      
			if (DemoTime < 500) 
				C =C*DemoTime/500.0f;

			glColor3ub(255, 255, 255);

			for (I =0 ;I<=15;I++)
			{
				float   text_denum=(float)pow((Tunnels[I][J].x+Tunnels[I][J].y+Tunnels[I][J].z),2);

				normals[vertices_count]=Tunnels[I][J].x/text_denum;
				normals[vertices_count+1]=Tunnels[I][J].y/text_denum;
				normals[vertices_count+2]=Tunnels[I][J].z/text_denum;

				vertices[vertices_count	]=Tunnels[I][J].x;
				vertices[vertices_count+1]=Tunnels[I][J].y;
				vertices[vertices_count+2]=Tunnels[I][J].z;

				tex_coords[texture_count]=(float)((I-1.0f)/16.0f)+internal_timer/1000000;
				tex_coords[texture_count+1]=(float)J1+internal_timer/1000000;

				text_denum=(float)pow((Tunnels[I+1][J].x+Tunnels[I+1][J].y+Tunnels[I+1][J].z),2);

				normals[vertices_count+3]=Tunnels[I+1][J].x/text_denum;
				normals[vertices_count+4]=Tunnels[I+1][J].y/text_denum;
				normals[vertices_count+5]=Tunnels[I+1][J].z/text_denum;

				vertices[vertices_count+3]=Tunnels[I+1][J].x;
				vertices[vertices_count+4]=Tunnels[I+1][J].y;
				vertices[vertices_count+5]=Tunnels[I+1][J].z;

				normals[vertices_count+3]=0;
				normals[vertices_count+4]=1;
				normals[vertices_count+5]=1;

				tex_coords[texture_count+2]=(float)(( I )/16.0f)+internal_timer/100000;
				tex_coords[texture_count+3]=(float)J1+internal_timer/100000;

				text_denum=(float)pow((Tunnels[I+1][J+1].x+Tunnels[I+1][J+1].y+Tunnels[I+1][J+1].z),2);

				normals[vertices_count+6]=Tunnels[I+1][J+1].x/text_denum;
				normals[vertices_count+7]=Tunnels[I+1][J+1].y/text_denum;
				normals[vertices_count+8]=Tunnels[I+1][J+1].z/text_denum;

				vertices[vertices_count+6]=Tunnels[I+1][J+1].x;
				vertices[vertices_count+7]=Tunnels[I+1][J+1].y;
				vertices[vertices_count+8]=Tunnels[I+1][J+1].z;

				normals[vertices_count+6]=1;
				normals[vertices_count+7]=0;
				normals[vertices_count+8]=1;

				tex_coords[texture_count+4]=(float)(( I )/16.0f)+internal_timer/100000;
				tex_coords[texture_count+5]=(float)J2+internal_timer/100000;

				text_denum=(float)pow((Tunnels[I][J+1].x+Tunnels[I][J+1].y+Tunnels[I][J+1].z),2);

				normals[vertices_count+9]=Tunnels[I][J+1].x/text_denum;
				normals[vertices_count+10]=Tunnels[I][J+1].y/text_denum;
				normals[vertices_count+11]=Tunnels[I][J+1].z/text_denum;


				vertices[vertices_count+9 ]=Tunnels[I][J+1].x;
				vertices[vertices_count+10]=Tunnels[I][J+1].y;
				vertices[vertices_count+11]=Tunnels[I][J+1].z;

				normals[vertices_count+9]=1;
				normals[vertices_count+10]=0;
				normals[vertices_count+11]=1;

				tex_coords[texture_count+6]=(float)((I-1.0f)/16.0f)+internal_timer/100000;
				tex_coords[texture_count+7]=(float)J2+internal_timer/100000;

				colours[colours_count  ]=10*(GLubyte)pow(beat_responder/20,2);
				colours[colours_count+1]=20*(GLubyte)pow(beat_responder/20,2);
				colours[colours_count+2]=255;
				colours[colours_count+3]=255;

				colours[colours_count+4]=10*(GLubyte)pow(beat_responder/20,2);
				colours[colours_count+5]=20*(GLubyte)pow(beat_responder/20,2);
				colours[colours_count+6]=255;
				colours[colours_count+7]=255;

				colours[colours_count+8	]=10*(GLubyte)pow(beat_responder/20,2);
				colours[colours_count+9	]=20*(GLubyte)pow(beat_responder/20,2);
				colours[colours_count+10]=255;
				colours[colours_count+11]=255;

				colours[colours_count+12]=10*(GLubyte)pow(beat_responder/20,2);
				colours[colours_count+13]=20*(GLubyte)pow(beat_responder/20,2);
				colours[colours_count+14]=255;
				colours[colours_count+15]=255;

				indices[indices_count  ]=indices_count;
				indices[indices_count+1]=indices_count+1;
				indices[indices_count+2]=indices_count+2;
				indices[indices_count+3]=indices_count+3;
				
				vertices_count=vertices_count+12;
				colours_count=colours_count+16;
				texture_count=texture_count+8;
				indices_count=indices_count+4;
			}
		}

		glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
		glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
		glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
		glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );
		
		if ( timeeffect>10 )
		{
			glActiveTextureARB			( GL_TEXTURE0_ARB );   
			glEnable					( GL_TEXTURE_2D   );     

			glActiveTextureARB			( GL_TEXTURE1_ARB );   
			glEnable					( GL_TEXTURE_2D   );
			if (scene_switcher<=19)
			{
				glActiveTextureARB		( GL_TEXTURE0_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[1] ); 
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND );
				glDisable(GL_TEXTURE_GEN_S);															
				glDisable(GL_TEXTURE_GEN_T);

				glActiveTextureARB		( GL_TEXTURE1_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glDisable(GL_TEXTURE_GEN_S);															
				glDisable(GL_TEXTURE_GEN_T);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			}
			if (scene_switcher>19)
			{
				glActiveTextureARB		( GL_TEXTURE0_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[0] ); 
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glDisable(GL_TEXTURE_GEN_S);															
				glDisable(GL_TEXTURE_GEN_T);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

				glActiveTextureARB		( GL_TEXTURE1_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glDisable(GL_TEXTURE_GEN_S);															
				glDisable(GL_TEXTURE_GEN_T);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	
			}
			if (scene_switcher>38)
			{
				glActiveTextureARB		( GL_TEXTURE0_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[1] ); 
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glDisable(GL_TEXTURE_GEN_S);															
				glDisable(GL_TEXTURE_GEN_T);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

				glActiveTextureARB		( GL_TEXTURE1_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glEnable(GL_TEXTURE_GEN_S);															
				glEnable(GL_TEXTURE_GEN_T);
				glEnable(GL_DEPTH_TEST);
				glDisable(GL_BLEND);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			}
		}
		else
		{
			glDisable(GL_TEXTURE_GEN_S);															
			glDisable(GL_TEXTURE_GEN_T);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		}
		glDisable(GL_BLEND);
		glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
		glColorPointer  ( 4, GL_UNSIGNED_BYTE, 0, &colours );
		glNormalPointer	(GL_FLOAT, 0, &normals);
		glDrawElements  ( GL_QUADS, indices_count-1, GL_UNSIGNED_INT, &indices );

		//--- Outside tunnel ---//
		
		for (I =0;I<=16;I++)
		{
			X =(float)cos(PI_8*I);
			Y =(float)sin(PI_8*I);
			for (J =0;J<=28;J++)
			{
				Tunnels[I][J].x =((float)((2.0f - J/12.0f)*X + 2.0f*sin((Angle+2.0f*J)/27.0f) + cos((Angle+2.0f*J)/13.0f) - 2.0f*A1 - A3))*(1+((float)sin(xrot/2000+3*this_mod->waveformData[0][I*J]/500)/200));
				Tunnels[I][J].y =((float)((2.0f - J/12.0f)*Y + 2.5f*cos((Angle+2.0f*J)/33.0f) + sin((Angle+2.0f*J)/17.0f) - 2.0f*A2 - A4))*(1+((float)cos(xrot/2000+3*this_mod->waveformData[0][I*J]/500)/200));
				Tunnels[I][J].z =(float)-J*(1.5f+0.2f*(float)sin(xrot/1800));
			}
		}

		X =(float)(DemoTime/240.0f);

		glEnable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glEnable(GL_FOG);
		

		vertices_count=0;
		indices_count=0;
		colours_count=0;
		texture_count=0;

		for( J =0;J<=27;J++)
		{
			J1 =J/64.0f - Angle/200.0f+(float)pow(xrot/6000,2);       
			J2 =(J+1.0f)/64.0f - Angle/200.0f+(float)pow(xrot/6000,2);

			if (J > 24)
				C =(float)(1.0f-(J-24.0f)/10.0f);
			else
				C =1.0f;

			if (DemoTime < 500)
				C =C*DemoTime/500.0f;

			glColor4f(C,beat_responder/240,C+beat_responder/100,C);
			glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

			for ( I =0 ;I<=15;I++) 
			{
				float waveform2=0.0f;

				float   text_denum=(float)pow((Tunnels[I][J].x+Tunnels[I][J].y+Tunnels[I][J].z),2);

				normals[vertices_count]=Tunnels[I][J].x/text_denum;
				normals[vertices_count+1]=Tunnels[I][J].y/text_denum;
				normals[vertices_count+2]=Tunnels[I][J].z/text_denum;

				vertices[vertices_count	]=Tunnels[I][J].x+waveform2*normals[vertices_count];
				vertices[vertices_count+1]=Tunnels[I][J].y+waveform2*normals[vertices_count+1];
				vertices[vertices_count+2]=Tunnels[I][J].z;

				tex_coords[texture_count]=(float)((I-1.0f + X)/16.0f);
				tex_coords[texture_count+1]=(float)J1;

				text_denum=(float)pow((Tunnels[I+1][J].x+Tunnels[I+1][J].y+Tunnels[I+1][J].z),2);

				normals[vertices_count+3]=Tunnels[I+1][J].x/text_denum;
				normals[vertices_count+4]=Tunnels[I+1][J].y/text_denum;
				normals[vertices_count+5]=Tunnels[I+1][J].z/text_denum;

				vertices[vertices_count+3]=Tunnels[I+1][J].x+waveform2*normals[vertices_count+3];
				vertices[vertices_count+4]=Tunnels[I+1][J].y+waveform2*normals[vertices_count+4];
				vertices[vertices_count+5]=Tunnels[I+1][J].z;

				tex_coords[texture_count+2]=(float)(( I  + X)/16.0f);
				tex_coords[texture_count+3]=(float)J1;

				text_denum=(float)pow((Tunnels[I+1][J+1].x+Tunnels[I+1][J+1].y+Tunnels[I+1][J+1].z),2);

				normals[vertices_count+6]=Tunnels[I+1][J+1].x/text_denum;
				normals[vertices_count+7]=Tunnels[I+1][J+1].y/text_denum;
				normals[vertices_count+8]=Tunnels[I+1][J+1].z/text_denum;

				vertices[vertices_count+6]=Tunnels[I+1][J+1].x+waveform2*normals[vertices_count+6];
				vertices[vertices_count+7]=Tunnels[I+1][J+1].y+waveform2*normals[vertices_count+7];
				vertices[vertices_count+8]=Tunnels[I+1][J+1].z;

				tex_coords[texture_count+4]=(float)(( I  + X)/16.0f);
				tex_coords[texture_count+5]=(float)J2;

				text_denum=(float)pow((Tunnels[I][J+1].x+Tunnels[I][J+1].y+Tunnels[I][J+1].z),2);

				normals[vertices_count+9]=Tunnels[I][J+1].x/text_denum;
				normals[vertices_count+10]=Tunnels[I][J+1].y/text_denum;
				normals[vertices_count+11]=Tunnels[I][J+1].z/text_denum;

				vertices[vertices_count+9 ]=Tunnels[I][J+1].x+waveform2*normals[vertices_count+9];
				vertices[vertices_count+10]=Tunnels[I][J+1].y+waveform2*normals[vertices_count+10];
				vertices[vertices_count+11]=Tunnels[I][J+1].z;

				tex_coords[texture_count+6]=(float)((I-1.0f + X)/16.0f);
				tex_coords[texture_count+7]=(float)J2;

				colours[colours_count  ]=I*20;
				colours[colours_count+1]=I*20;
				colours[colours_count+2]=I*20;
				colours[colours_count+3]=255-I*10;

				colours[colours_count+4]=I*20;
				colours[colours_count+5]=I*20;
				colours[colours_count+6]=I*20;
				colours[colours_count+7]=255-I*10;

				colours[colours_count+8	]=I*20;
				colours[colours_count+9	]=I*20;
				colours[colours_count+10]=I*20;
				colours[colours_count+11]=255-I*10;

				colours[colours_count+12]=I*20;
				colours[colours_count+13]=I*20;
				colours[colours_count+14]=I*20;
				colours[colours_count+15]=255-I*10;

				indices[indices_count  ]=indices_count;
				indices[indices_count+1]=indices_count+1;
				indices[indices_count+2]=indices_count+2;
				indices[indices_count+3]=indices_count+3;
				
				vertices_count=vertices_count+12;
				colours_count=colours_count+16;
				texture_count=texture_count+8;
				indices_count=indices_count+4;
			}


		}
	
		glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
		glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
		glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
		glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );
		
		if (timeeffect>10)
		{
			if (scene_switcher<=19)
			{
			glActiveTextureARB		( GL_TEXTURE0_ARB ); 
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] ); 
			glDisable(GL_TEXTURE_GEN_S);																
			glDisable(GL_TEXTURE_GEN_T);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB		( GL_TEXTURE1_ARB ); 
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
			glDisable(GL_TEXTURE_GEN_S);																
			glDisable(GL_TEXTURE_GEN_T);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
			}
			if (scene_switcher>19)
			{
				glActiveTextureARB		( GL_TEXTURE0_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[0] ); 
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

				glActiveTextureARB		( GL_TEXTURE1_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
			}
			if (scene_switcher>36)
			{
				glActiveTextureARB		( GL_TEXTURE0_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[0] ); 
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND );

				glActiveTextureARB		( GL_TEXTURE1_ARB ); 
				glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glDisable(GL_TEXTURE_GEN_S);																
				glDisable(GL_TEXTURE_GEN_T);
				glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			}
		}
		else
		{
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		}

		glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
		glColorPointer  ( 4, GL_UNSIGNED_BYTE, 0, &colours );
		glNormalPointer	(GL_FLOAT, 0, &normals);
		glColor4ub(255,255,255,255);
		glDrawElements  ( GL_QUADS, indices_count-1, GL_UNSIGNED_INT, &indices );
  glPopMatrix();
  glDisable(GL_FOG);
}

bool scene3::Init(loadall		*textures)
{
	glActiveTextureARB			( GL_TEXTURE0_ARB );   
	glEnable					( GL_TEXTURE_2D   );     

	glActiveTextureARB			( GL_TEXTURE1_ARB );   
	glEnable					( GL_TEXTURE_2D   );

	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);

	glEnable(GL_COLOR_MATERIAL);									

	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);		
											
	glDisable(GL_LIGHT0); 
	glDisable(GL_LIGHT1);
	glDisable(GL_LIGHTING);

	SceneStart		= GetTickCount();
	multi_texture=rand()%19;
	scene_switcher=rand()%56;


	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(22);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(5);
		break;
		case 2:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(5);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(2);
		break;
		case 4:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(3);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(3);
		break;
		case 6:
			m_Texture[0]=textures->Bind(10);
			m_Texture[1]=textures->Bind(11);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(13);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(12);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(4);
		break;
		case 10:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(7);
		break;
		case 11:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(3);
		break;
		case 12:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(2);
		break;
		case 13:
			m_Texture[0]=textures->Bind(17);
			m_Texture[1]=textures->Bind(4);
		break;
		case 14:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(2);
		break;
		case 15:
			m_Texture[0]=textures->Bind(19);
			m_Texture[1]=textures->Bind(4);
		break;
		case 16:
			m_Texture[0]=textures->Bind(20);
			m_Texture[1]=textures->Bind(17);
		break;
		case 17:
			m_Texture[0]=textures->Bind(21);
			m_Texture[1]=textures->Bind(15);
		break;
		case 18:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(5);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==19)
		multi_texture=0;
	//scene_switcher=scene_switcher++;
	if (scene_switcher>56)
		scene_switcher=0;*/
	return true;
}


