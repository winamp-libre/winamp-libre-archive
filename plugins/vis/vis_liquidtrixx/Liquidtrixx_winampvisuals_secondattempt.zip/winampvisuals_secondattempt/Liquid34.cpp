#include "headers.h"
#include "Misc.h"
#include "liquid34.h"

#define GRID_RES    10        // Grid resolution
#define drand48()   (rand()/((double)RAND_MAX))
#define G_DEFORM    10
#define M_PI        3.14159

scene34::scene34(double time,float wid,float hei):Manager(time)					
{
	xrot						= 0.0f;
	t							= 0.0f;	
	direction					= -1;
	beat_responder				= 0.0f;

	timeeffect					= 0;
	multi_texture				=0;
	speedTexure					= FALSE;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB			= ( PFNGLCLIENTACTIVETEXTUREARBPROC )	wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB	= ( PFNGLACTIVETEXTUREARBPROC )			wglGetProcAddress  ( "glClientActiveTextureARB" );
	t2							= 0.0f;
	sceneTime					= 0.0f;
	lastTime					= 0.0f;
	width						= wid;
	height						= hei;
	fade_def					= 0;


	CameraX=0.0f;
	CameraY=-5.0f;
	CameraZ=5.0f;
	CameraTheta=-25.0f;

	sizex=int (wid);
	sizey=int (hei);

	QuadSphere=gluNewQuadric();

	LightAmbient[0]=0.5f;
	LightAmbient[1]=0.5f;
	LightAmbient[2]=0.5f;
	LightAmbient[3]=0.5f;

	LightDiffuse[0]=1.0f;
	LightDiffuse[1]=1.0f;
	LightDiffuse[2]=1.0f;
	LightDiffuse[3]=1.0f;

	LightPosition[0]=-25.0f;
	LightPosition[1]=0.0f;
	LightPosition[2]=0.0f;
	LightPosition[3]=1.0f;

	matSpecular[0]=1.0f;
	matSpecular[1]=1.0f;
	matSpecular[2]=1.0f;
	matSpecular[3]=1.0f;

	shininess=32.0f;
	
	gridon=false;
	ballson=false;
	barson=false;
 
	g_iDeform=8;         // Current deformation number
	g_iDrawLines=0;      // Should we draw random lines ?
    g_iDrawCube=0;       // Should we draw a nice wireframe 3d cube ?
    g_iFrame=0;          // Frame counter
    g_iClear=1;          // Should we clear the texture
    g_iShowField=0;      // Should we draw the vector field ?
    g_iPaintBrush=0;     // Should we draw a square under mouse cursor ?
	g_iCurrentColor=1;   // setting = 1 => compute color at startup

	g_uiGridList=glGenLists(1);

}

scene34::~scene34()					
{
	gluDeleteQuadric(QuadSphere);
}


void scene34::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	static int deform=-1;
	static double ***texCoords=NULL;
	static int first=1;
	int    i,j;
	GLint  v[4];
	if (texCoords == NULL)
    {
		texCoords=new double **[GRID_RES+1];
		for (i=0;i<GRID_RES+1;i++)
			texCoords[i]=new double *[GRID_RES+1];
		for (i=0;i<GRID_RES+1;i++)
			for (j=0;j<GRID_RES+1;j++)
				texCoords[i][j]=new double [2];
    }
	
	if(first) 
	{
		time1 = time(NULL);
	}

	time2 = time(NULL);
	g_iDiffTime = difftime(time2, time1);
	if(g_iDiffTime>8.376f) 
	{
		g_iCurrentColor = (g_iCurrentColor+1)%2;
		g_iDeform=rand()% G_DEFORM;		  
		time1 = time(NULL);
	}	

	if (first || deform != g_iDeform)
    {
      genTexCoords(0,GRID_RES+1,(double ***)texCoords);   
      computeGrid(GRID_RES,(double ***)texCoords);
      deform=g_iDeform;
    }

	if (first)
    {
		glGetIntegerv(GL_VIEWPORT,v);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D,g_uiTexId);
		glCopyTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,0,128,1024,1024,0);  
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,GL_CLAMP);
		glTexEnvi(GL_TEXTURE_2D, GL_TEXTURE_ENV_MODE ,GL_MODULATE); 
		first=0;
    }

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,1.0,0.0,1.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,g_uiTexId);
	glColor3d(0.98,0.98,0.98);
	glCallList(g_uiGridList);

	diffuseDraw(this_mod);
  
	g_iFrame++;

	glFlush();
	if (g_iClear==1)
    {
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		g_iClear=0;
    }
  
	glGetIntegerv(GL_VIEWPORT,v);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,g_uiTexId);
	glCopyTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,0,128,1024,512,0);

	noDiffuseDraw(this_mod);
	
	if (g_iShowField)
		drawVectorField(GRID_RES+1,(double ***)texCoords);
}

void scene34::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{							
	glLoadIdentity ();	

	speedTexure = Tex_on;
	if (fade_def==0)
		fadeffect+=0.1f;
	if (fade_def==1)
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/30.0f)*(beat_responder/30.0f))+1.0f;
	t+=(beat_responder/20.0f)*0.01f*(float)cos(timeeffect/300.0f*(beat_responder))*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;
}

bool scene34::Init(loadall		*textures)
{
	textures_in=textures;
	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glDisableClientState       ( GL_TEXTURE_COORD_ARRAY );
	glDisable				 ( GL_TEXTURE_2D);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );  
	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%19;
	
	
	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(22);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(10);
			m_Texture[1]=textures->Bind(7);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(3);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(2);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(4);
		break;
		case 10:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(7);
		break;
		case 11:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(3);
		break;
		case 12:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(2);
		break;
		case 13:
			m_Texture[0]=textures->Bind(17);
			m_Texture[1]=textures->Bind(4);
		break;
		case 14:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(2);
		break;
		case 15:
			m_Texture[0]=textures->Bind(19);
			m_Texture[1]=textures->Bind(4);
		break;
		case 16:
			m_Texture[0]=textures->Bind(20);
			m_Texture[1]=textures->Bind(17);
		break;
		case 17:
			m_Texture[0]=textures->Bind(21);
			m_Texture[1]=textures->Bind(15);
		break;
		case 18:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(22);
		break;
	}

	srand(static_cast<unsigned>(time(0))); // seed random number generator

	/*multi_texture=multi_texture++;
	if (multi_texture==19)
		multi_texture=0;*/
	return true;
}

float scene34::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);

}

void scene34::computeGrid(int res,double ***texCoords)
{
  int i,j;

  glNewList(g_uiGridList,GL_COMPILE);
  glBegin(GL_QUADS);
  for (i=0;i<GRID_RES;i++)
    {
      for (j=0;j<GRID_RES;j++)
	{
	  glTexCoord2d(texCoords[i][j][0],texCoords[i][j][1]);
	  glVertex2d(((double)i)/((double)GRID_RES),((double)j)/((double)GRID_RES));
	  glTexCoord2d(texCoords[i+1][j][0],texCoords[i+1][j][1]);
	  glVertex2d(((double)i+1)/((double)GRID_RES),((double)j)/((double)GRID_RES));
	  glTexCoord2d(texCoords[i+1][j+1][0],texCoords[i+1][j+1][1]);
	  glVertex2d(((double)i+1)/((double)GRID_RES),((double)j+1)/((double)GRID_RES));
	  glTexCoord2d(texCoords[i][j+1][0],texCoords[i][j+1][1]);
	  glVertex2d(((double)i)/((double)GRID_RES),((double)j+1)/((double)GRID_RES));
	}
    }
  glEnd();  
  glEndList();
}

void scene34::genTexCoords(int time,int res,double ***tbl)
{
	double x,c,s,d;
	int    i,j;
  
	for (i=0;i<res;i++)
    {
		for (j=0;j<res;j++)
		{
			tbl[i][j][0]=((double)i)/((double)res-1.0);
			tbl[i][j][1]=((double)j)/((double)res-1.0);
			switch (g_iDeform)
			{
				case 0:
					tbl[i][j][0]+=0.01;
					tbl[i][j][1]+=0.01;
				break;
				
				case 1:
					tbl[i][j][0]+=(i-res/2.0)*0.001;
					tbl[i][j][1]+=(j-res/2.0)*0.001;
				break;
				
				case 2:
					tbl[i][j][0]*=cos((i+j-res)/50.0*M_PI);
					tbl[i][j][1]*=cos((i-j)/100.0*M_PI);
				break;
				
				case 3:
					tbl[i][j][0]+=(i-res/2.0)*0.003;
					tbl[i][j][1]+=(j-res/2.0)*0.003;

					tbl[i][j][0]-=0.5;
					tbl[i][j][1]-=0.5;
					x=tbl[i][j][0];
					c=cos(M_PI/32.0+(i-res/2)*M_PI/32.0);
					s=sin(M_PI/32.0+(j-res/2)*M_PI/32.0);
					tbl[i][j][0]=c*x-s*tbl[i][j][1];
					tbl[i][j][1]=s*x+c*tbl[i][j][1];
					tbl[i][j][0]+=0.5;
					tbl[i][j][1]+=0.5;
				break;
				
				case 4:
					tbl[i][j][0]-=0.5;
					tbl[i][j][1]-=0.5;
					x=tbl[i][j][0];
					d=sqrt((i-res/2.0)*(i-res/2.0)+(j-res/2.0)*(j-res/2.0));
					c=cos((d)*M_PI/64.0);
					s=sin((d)*M_PI/64.0);
					tbl[i][j][0]=c*x-s*tbl[i][j][1];
					tbl[i][j][1]=s*x+c*tbl[i][j][1];
					tbl[i][j][0]+=0.5;
					tbl[i][j][1]+=0.5;
				break;

				case 5:
					if(i<=4)
						tbl[i][j][1]-=0.02;
					if(i>=6)
						tbl[i][j][1]+=0.02;
					tbl[i][j][0]+=0.01;
				break;

				case 6:
					if(j<=4)
						tbl[i][j][1]+=0.02;
					if(j>=4)
						tbl[i][j][1]-=0.02;
					if(i<=4)
						tbl[i][j][0]-=0.008;
					if(i>=6)
						tbl[i][j][0]+=0.008;
				break;
				
				case 7:
					if(j<=4)
						tbl[i][j][1]+=0.02;
					if(j>=4)
						tbl[i][j][1]-=0.02;
					if(i<=4)
						tbl[i][j][0]+=0.008;
					if(i>=6)
						tbl[i][j][0]-=0.008;
				break;
				
				case 8:
					if(j<=4)
						tbl[i][j][1]+=0.01+0.004*(5-j);
					if(j>=6)
						tbl[i][j][1]-=0.01+0.004*(j-5);
					if(i<=4)
			 			tbl[i][j][0]+=0.004+0.01*(5-i);
					if(i>=6)
						tbl[i][j][0]-=0.004+0.01*(i-5); 
				break;
				
				case 9:
					if(j<=4)
						tbl[i][j][1]+=0.02;
					if(j>=4)
						tbl[i][j][1]-=0.02; 
					if(i<=4)
						tbl[i][j][0]+=0.008;
					if(i>=6)
						tbl[i][j][0]-=0.008;
				break;
				
				default:
				break;
			}
		}
    }
}

void scene34::noDiffuseDraw(struct winampVisModule *this_mod)
{
 	glDisable(GL_TEXTURE_2D);
    glLineWidth(1.0f+(rand()%3));
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE,GL_ONE);
 	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
	GLfloat xf;
	GLfloat x_old=0.;
	GLfloat y_old=0.;
	glBegin(GL_LINES);
	glColor3f(1.0f, 1.0f, 1.0f);
		for (int x = 0;  x < 512; x++)
		{
			GLfloat y = (GLfloat)((this_mod->waveformData[0][x]^128));
			y=  (y/255)-0.5f; // -0.5f;	//-0.9		
			xf = (float)x;			
			xf = (xf/256)-1.0f;

			if(x==0){
				glVertex2f(xf,y);
				glVertex2f(xf,y);
			} else {
			glVertex2f(x_old,y_old);
			glVertex2f(xf, y);
			}
			x_old = xf;
			y_old = y;
		}
	
	glEnd();
	glDisable(GL_BLEND);
}


void scene34::diffuseDraw(struct winampVisModule *this_mod)
{
	glDisable(GL_TEXTURE_2D);
    glLineWidth(1.0f+(rand()%3));
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE,GL_ONE);	
	glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();	
	GLfloat xf;
	GLfloat x_old=0.;
	GLfloat y_old=0.;
	glBegin(GL_LINES);
	
	if(g_iCurrentColor) 
	{
		currentColor[0] = (((float)((rand()%8)+1)))/10.0f;
		currentColor[1] = ((((float)((((rand()%8)+4)%8)+1))))/10.0f;
		currentColor[2] = ((((float)((((rand()%8)+7)%8)+1))))/10.0f;
		glColor3fv(currentColor);
		g_iCurrentColor = 0;
	}
	glColor3fv(currentColor);
	
	for (int x = 0;  x < 512; x++)
	{
		GLfloat y = (GLfloat)((this_mod->waveformData[0][x]^128));
		y=  (y/255)-0.5f; 		
		xf = (float)x;			
		xf = (xf/256)-1.0f;

		if(x==0){
			glVertex2f(xf,y);
			glVertex2f(xf,y);
		} else {
		glVertex2f(x_old,y_old);
		glVertex2f(xf, y);
		}
		x_old = xf;
		y_old = y;
	}
	
	glEnd(); 
	glDisable(GL_BLEND);
}

void scene34::drawVectorField(int res,double ***texCoords)
{
  int    i,j;
  double u,v;

  glPushAttrib(GL_ENABLE_BIT);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(0.0,1.0,0.0,1.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  glDisable(GL_TEXTURE_2D);
  glLineWidth(1.0);
  glBegin(GL_LINES);
  glColor3d(0.0,1.0,0.0);
  for (i=0;i<GRID_RES;i++)
    {
      for (j=0;j<GRID_RES;j++)
	{
	  u=texCoords[i][j][0]-((double)i)/((double)res-1.0);
	  v=texCoords[i][j][1]-((double)j)/((double)res-1.0);
	  glVertex2d(((double)i)/((double)res-1.0),((double)j)/((double)res-1.0));
	  glVertex2d(((double)i)/((double)res-1.0)+u,((double)j)/((double)res-1.0)+v);
	}
    }
  glEnd();  
  glColor3d(1.0,1.0,1.0);
  glPolygonMode(GL_FRONT,GL_LINE);
  glCallList(g_uiGridList);
  glPolygonMode(GL_FRONT,GL_FILL);
  glPopAttrib();
}

