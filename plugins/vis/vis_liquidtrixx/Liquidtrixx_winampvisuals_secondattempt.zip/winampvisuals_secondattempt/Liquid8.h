#ifndef __LIQUID8_H_
#define __LIQUID8_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "cube.h"
#include "Background.h"

class scene8:public Manager
{

	public:
		scene8(double time,float wid,float hei);												
		~scene8();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
		virtual void initcubes(void);
	
	private:
		GLuint		m_Texture[5];										
		cube		*liquid_cube;
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture,Direction;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect,t1,Time,Step;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		int			dX,dY,dZ;
		GLfloat		vertices[72];
		GLuint		indices[24];
		GLfloat		normals[72];
		GLubyte		colours[96];
		GLfloat		tex_coords[48];
		int			Src[3];
		int			Dst[3];
		float		xPos, yPos, zPos;
		float		OldTime;
		int			scenechanger;

		float		width,height;
};

#endif __LIQUID8_H_
