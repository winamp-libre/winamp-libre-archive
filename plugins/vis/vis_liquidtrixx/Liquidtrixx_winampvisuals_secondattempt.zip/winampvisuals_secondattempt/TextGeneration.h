#ifndef __TEXTGENERATION_H_
#define __TEXTGENERATION_H_

#include "Texture.h"

class TextGeneration
{

	public:
		TextGeneration();												
		~TextGeneration();	
		void Bind(int number);

	public:
		Texture *t_metal2;
		Texture *t_re2xt;
		Texture *t_blab;
		Texture *t_refl;
		Texture *t_silver;
};

#endif __TEXTGENERATION_H_
