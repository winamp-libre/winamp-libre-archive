#ifndef __FONT_H_
#define __FONT_H_

#include "Texture.h"

class Font
{
public:
	Font(const char *fontname, int fontsize, bool bold, bool italic);
	~Font();
	void Print(const char *fmt, ...);
	void Print(float x1, float y1, const char *fmt, ...);
private:
	float x, y;
	float coords[256][4][2];
	int widths[256];

	int height;

	Texture *tex;
};

#endif __FONT_H_
