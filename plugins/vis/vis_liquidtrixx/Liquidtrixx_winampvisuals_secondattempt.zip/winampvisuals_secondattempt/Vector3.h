#include "math.h"

#ifndef __Vector3_H_
#define __Vector3_H_

class CVector3
{
	public:
		CVector3() {};
		CVector3(float X, float Y, float Z);  
		CVector3 operator+(CVector3);
		CVector3 operator-(CVector3);
		CVector3 operator*(float num);
		CVector3 operator/(float num);

		float x, y, z;						
};

#endif __Vector3_H_
