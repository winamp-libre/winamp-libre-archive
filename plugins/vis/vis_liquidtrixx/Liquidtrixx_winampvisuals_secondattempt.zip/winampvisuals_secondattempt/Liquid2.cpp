#include "headers.h"
#include "Misc.h"
#include "liquid2.h"
#include "metaballtables.h"
#include "Background.h"

scene2::scene2(double time,float max_meta,float wid,float hei,int choice_entrance):Manager(time)					
{
	glLockArraysEXT				= NULL;
	glUnlockArraysEXT			= NULL;

	glLockArraysEXT   = ( PFNGLLOCKARRAYSEXTPROC )		wglGetProcAddress ( "glLockArraysEXT" );
	glUnlockArraysEXT = ( PFNGLUNLOCKARRAYSEXTPROC )	wglGetProcAddress ( "glUnlockArraysEXT" );

	vertices_count=0;

	MetaBall[0].Radius =0.12f;
	MetaBall[0].x =0.3f;
	MetaBall[0].y =0.0f;
	MetaBall[0].z =0.2f;

	MetaBall[1].Radius =0.13f;
	MetaBall[1].x =0.0f;
	MetaBall[1].y =0.1f;
	MetaBall[1].z =0.0f;

	MetaBall[2].Radius =0.19f;
	MetaBall[2].x =0.3f;
	MetaBall[2].y =0.0f;
	MetaBall[2].z =0.1f;

	MetaBall[3].Radius =0.16f;
	MetaBall[3].x =0.1f;
	MetaBall[3].y =0.0f;
	MetaBall[3].z =0.5f;

	MetaBall[4].Radius =0.15f;
	MetaBall[4].x =-0.2f;
	MetaBall[4].y =0.3f;
	MetaBall[4].z =-0.5f;

	MetaBall[5].Radius =0.18f;
	MetaBall[5].x =0.4f;
	MetaBall[5].y =0.3f;
	MetaBall[5].z =-0.3f;

	GridSize  =25;

	int cx, cy, cz;

	for (cx = 0;cx<51;cx++)
		for (cy = 0;cy<51;cy++)
			for (cz = 0;cz<51;cz++)
			{
				Grid[cx][cy][cz].Pos.x=0;
				Grid[cx][cy][cz].Pos.y=0;
				Grid[cx][cy][cz].Pos.z=0;
				Grid[cx][cy][cz].Normal.x=0;
				Grid[cx][cy][cz].Normal.y=0;
				Grid[cx][cy][cz].Normal.z=0;
				Grid[cx][cy][cz].Value=0;
			}


	for (cx = 0;cx<GridSize;cx++)
		for (cy = 0;cy<GridSize;cy++)
			for (cz = 0;cz<GridSize;cz++)
			{
				Grid[cx][cy][cz].Pos.x = 2.0f*cx/GridSize -1.0f;   
				Grid[cx][cy][cz].Pos.y = 2.0f*cy/GridSize -1.0f;   
				Grid[cx][cy][cz].Pos.z = 1.0f-2.0f*cz/GridSize;    
			}
  
	for (cx = 0;cx< GridSize-1;cx++)
		for (cy = 0;cy< GridSize-1;cy++)
			for (cz = 0;cz< GridSize-1;cz++)
			{
				Cubes[cx][cy][cz].GridPoint[0] = &Grid[cx][cy][cz];
				Cubes[cx][cy][cz].GridPoint[1] = &Grid[cx+1][cy][cz];
				Cubes[cx][cy][cz].GridPoint[2] = &Grid[cx+1][cy][cz+1];
				Cubes[cx][cy][cz].GridPoint[3] = &Grid[cx][cy][cz+1];
				Cubes[cx][cy][cz].GridPoint[4] = &Grid[cx][cy+1][cz];
				Cubes[cx][cy][cz].GridPoint[5] = &Grid[cx+1][cy+1][cz];
				Cubes[cx][cy][cz].GridPoint[6] = &Grid[cx+1][cy+1][cz+1];
				Cubes[cx][cy][cz].GridPoint[7] = &Grid[cx][cy+1][cz+1];
			}

	xrot							=0.0f;
	t								=0.0f;
	direction						=-1;
	beat_responder					=0.0f;
	multi_texture					=0;
	meta_number						=max_meta;
	scene_switcher=-1;
	width							= wid;
	height							= hei;
	timeeffect						= 0;
	fadeffect						= 0;
	SceneStart						= GetTickCount();
	beat_min		= 0.0f;
	beat_max		= 0.0f;
	choice			= choice_entrance;
	liquid1			= new scene1(20.0,wid,hei);
	bg							= new background();
}

scene2::~scene2()					
{
}

void scene2::ViewOrtho()												// Set Up An Ortho View
{
	glMatrixMode(GL_PROJECTION);								// Select Projection
	glPushMatrix();												// Push The Matrix
	glLoadIdentity();											// Reset The Matrix
	glOrtho( 0, 640 , 480 , 0, -1, 1 );							// Select Ortho Mode (640x480)
	glMatrixMode(GL_MODELVIEW);									// Select Modelview Matrix
	glPushMatrix();												// Push The Matrix
	glLoadIdentity();											// Reset The Matrix
}

void scene2::ViewPerspective()											// Set Up A Perspective View
{
	glMatrixMode( GL_PROJECTION );								// Select Projection
	glPopMatrix();												// Pop The Matrix
	glMatrixMode( GL_MODELVIEW );								// Select Modelview
	glPopMatrix();												// Pop The Matrix
}

void scene2::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	timeeffect=(GetTickCount()-SceneStart)/1000;
	if (fade_def==0)
		fadeffect+=0.1f;
	if (fade_def==1)
		fadeffect-=0.1f;

	if (choice==1)
		beat_responder=2.0f*beat_responder;

	ElapsedTime		= GetTickCount() - SceneStart;
	beat_responder=beat_help*beat_scaler*0.5f;
	xrot+=direction*((beat_responder/30)*(beat_responder/30))+0.3f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;	

	if (beat_min==0 && beat_max==0)
	{
		beat_min=beat_responder;
		beat_max=beat_responder;
	}
	else
	{
		if (beat_min>beat_responder)
			beat_min=beat_responder;
		if (beat_max<beat_responder)
			beat_max=beat_responder;
	}

	if (timeeffect<3 && choice==0)
	{
		//glViewport(0,0,128,128);
		liquid1->getPrev();
		liquid1->Update(beat_responder/2.0f,this_mod,beat_scaler,Tex_on);
		
	}


	GLfloat ambientLight[] = { .3f, .9f, .0f, 1.0f };    
	GLfloat diffuseLight[] = { 1.0f, 1.0f, 1.0f, 1.0f };			
	GLfloat specular[]     = { 1.0f, 0.0f, 0.8f, 1.0f };						
	GLfloat lightPos[]     = { 3.0f, 3.0f, 3.0f, 1.0f };
	GLfloat specref[]      = { 1.0f, 1.0f, 1.0f, 0.0f };

	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);					
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);					
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);					
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);					

	GLfloat LightAmbient [4];
	GLfloat LightDiffuse [4];
	GLfloat LightPosition[4];

	LightAmbient[0] = 0.5f;
	LightAmbient[1] = 0.5f;
	LightAmbient[2] = 0.5f;
	LightAmbient[3] = 1.0f;

	LightDiffuse[0] = 1.0f;
	LightDiffuse[1] = 1.0f;
	LightDiffuse[2] = 1.0f;
	LightDiffuse[3] = 1.0f;

	LightPosition[0]= 0.0f;
	LightPosition[1]= 0.0f;
	LightPosition[2]= 0.0f;
	LightPosition[3]= 1.0f;

	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);
	glLightfv(GL_LIGHT1, GL_SPECULAR, specular);
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);
	
	glEnable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);		
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specref);					
	glMateriali( GL_FRONT_AND_BACK, GL_SHININESS, 120);						

	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_TEXTURE_2D);

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );
		
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );

	vertices_count=0;
	indices_count=0;
	colours_count=0;
	texture_count=0;

	float scalefactor=(float)pow(beat_responder/20,2);
	c = 0.15f*(float)cos(ElapsedTime/600.0f)*(float)pow(beat_responder/30,2);

	MetaBall[0].x =0.3f+(-0.3f*(float)cos(ElapsedTime/700.0f) + c)*(float)pow(beat_responder/30,2);
	MetaBall[0].y =(0.3f*(float)sin(ElapsedTime/600.0f) - c)*(float)pow(beat_responder/40,2);
	MetaBall[0].z = 0.4f;

	MetaBall[1].x =(0.4f*(float)sin(ElapsedTime/400.0f) + c)*(float)pow(beat_responder/40,2);
	MetaBall[1].y =(0.4f*(float)cos(ElapsedTime/400.0f) - c)*(float)pow(beat_responder/40,2);
	MetaBall[1].y = (float)pow(beat_responder/80,2)+0.3f;

	MetaBall[2].x =(-0.4f*(float)cos(ElapsedTime/400.0f) - 0.2f*(float)sin(ElapsedTime/600.0f)*beat_responder/120)*(float)pow(beat_responder/30,2);
	MetaBall[2].y =(0.4f*(float)sin(ElapsedTime/500.0f) - 0.2f*(float)sin(ElapsedTime/400.0f)*beat_responder/120)*(float)pow(beat_responder/30,2);
	MetaBall[2].z = -0.3f;

	MetaBall[3].x =(-0.5f*(float)cos(ElapsedTime/700.0f)*beat_responder/120 - c)*(float)pow(beat_responder/30,2);
	MetaBall[3].y =(0.3f*(float)sin(ElapsedTime/600.0f) - c)*(float)pow(beat_responder/20,2);
	MetaBall[2].z =(0.3f*(float)sin(ElapsedTime/600.0f) - c)*(float)pow(beat_responder/30,2);

	MetaBall[4].x =(0.5f*(float)cos(ElapsedTime/400.0f) - c)*(float)pow(beat_responder/40,2);
	MetaBall[4].y =(0.3f*(float)sin(ElapsedTime/800.0f) - c*beat_responder/120)*(float)pow(beat_responder/30,2);
	MetaBall[4].z =(0.3f*(float)sin(ElapsedTime/600.0f) - c*beat_responder/120)*(float)pow(beat_responder/30,2);

	MetaBall[5].x =(-0.1f*(float)cos(ElapsedTime/400.0f) - 0.2f*(float)sin(ElapsedTime/600.0f)*beat_responder/30)*(float)pow(beat_responder/30,2);
	MetaBall[5].y =(0.4f*(float)sin(ElapsedTime/300.0f) - c)*(float)pow(beat_responder/40,2);
	MetaBall[5].z =(0.1f*(float)sin(ElapsedTime/500.0f) - 0.3f*(float)sin(ElapsedTime/400.0f)*beat_responder/30)*(float)pow(beat_responder/40,2);


	TessTriangles = 0;
	for (cx = 0;cx<GridSize;cx++)
	{
		for (cy = 0;cy<GridSize;cy++)
		{
			for (cz = 0;cz<GridSize;cz++)
			{
				Grid[cx][cy][cz].Value =0;
				vec_help.x=0;
				vec_help.y=0;
				vec_help.z=0;
				for (i=0;i<6;i++)
				{
					Value=Grid[cx][cy][cz].Value;
					Radius=MetaBall[i].Radius;
					Pos.x=Grid[cx][cy][cz].Pos.x+vec_help.x;
					Pos.y=Grid[cx][cy][cz].Pos.y+vec_help.y;
					Pos.z=Grid[cx][cy][cz].Pos.z+vec_help.z;
					x=MetaBall[i].x;
					y=MetaBall[i].y;
					z=MetaBall[i].z;
					Grid[cx][cy][cz].Value = Value + Radius*Radius /((Pos.x-x)*(Pos.x-x) + (Pos.y-y)*(Pos.y-y) + (Pos.z-z)*(Pos.z-z));
				}
			}
		}
	}
	for (cx = 1;cx<GridSize-1;cx++)
	{
		for (cy = 1;cy<GridSize-1;cy++)
		{
			for (cz = 1;cz<GridSize-1;cz++)
			{
				Grid[cx][cy][cz].Normal.x = Grid[cx-1][cy][cz].Value - Grid[cx+1][cy][cz].Value;
				Grid[cx][cy][cz].Normal.y = Grid[cx][cy-1][cz].Value - Grid[cx][cy+1][cz].Value;
				Grid[cx][cy][cz].Normal.z = Grid[cx][cy][cz-1].Value - Grid[cx][cy][cz+1].Value;
			}
		}
	}
}

int	 scene2::CreateCubeTriangles(TGridCube GridCube,int index_helper,float xrot,GLuint blend_colour)
{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};

	int col=0;
	float beat_middle=(beat_max-beat_min)/10.0f;
	if (beat_responder>=0)
		col=1;
	if (beat_responder>1*beat_middle+beat_min)
		col=2;
	if (beat_responder>2*beat_middle+beat_min)
		col=3;
	if (beat_responder>3*beat_middle+beat_min)
		col=4;
	if (beat_responder>4*beat_middle+beat_min)
		col=5;
	if (beat_responder>5*beat_middle+beat_min)
		col=6;
	if (beat_responder>6*beat_middle+beat_min)
		col=7;
	if (beat_responder>7*beat_middle+beat_min)
		col=8;
	if (beat_responder>8*beat_middle+beat_min)
		col=9;
	if (beat_responder>9*beat_middle+beat_min)
		col=0;

	CubeIndex = 0;

	if (GridCube.GridPoint[0]->Value < 1) CubeIndex = CubeIndex |= 1;
	if (GridCube.GridPoint[1]->Value < 1) CubeIndex = CubeIndex |= 2;
	if (GridCube.GridPoint[2]->Value < 1) CubeIndex = CubeIndex |= 4;
	if (GridCube.GridPoint[3]->Value < 1) CubeIndex = CubeIndex |= 8;
	if (GridCube.GridPoint[4]->Value < 1) CubeIndex = CubeIndex |= 16;
	if (GridCube.GridPoint[5]->Value < 1) CubeIndex = CubeIndex |= 32;
	if (GridCube.GridPoint[6]->Value < 1) CubeIndex = CubeIndex |= 64;
	if (GridCube.GridPoint[7]->Value < 1) CubeIndex = CubeIndex |= 128;

	if (edgeTable[CubeIndex] == 0)
		return 0;

	if (edgeTable[CubeIndex] & 1)
		Interpolate(*GridCube.GridPoint[0],*GridCube.GridPoint[1],0);
    if (edgeTable[CubeIndex] & 2)
		Interpolate(*GridCube.GridPoint[1],*GridCube.GridPoint[2],1);
    if (edgeTable[CubeIndex] & 4)
		Interpolate(*GridCube.GridPoint[2],*GridCube.GridPoint[3],2);
	if (edgeTable[CubeIndex] & 8)
		Interpolate(*GridCube.GridPoint[3],*GridCube.GridPoint[0],3);
	if (edgeTable[CubeIndex] & 16)
		Interpolate(*GridCube.GridPoint[4],*GridCube.GridPoint[5],4);
	if (edgeTable[CubeIndex] & 32)
		Interpolate(*GridCube.GridPoint[5],*GridCube.GridPoint[6],5);
	if (edgeTable[CubeIndex] & 64)
		Interpolate(*GridCube.GridPoint[6],*GridCube.GridPoint[7],6);
	if (edgeTable[CubeIndex] & 128)
		Interpolate(*GridCube.GridPoint[7],*GridCube.GridPoint[4],7);
	if (edgeTable[CubeIndex] & 256)
		Interpolate(*GridCube.GridPoint[0],*GridCube.GridPoint[4],8);
	if (edgeTable[CubeIndex] & 512)
		Interpolate(*GridCube.GridPoint[1],*GridCube.GridPoint[5],9);
	if (edgeTable[CubeIndex] & 1024)
		Interpolate(*GridCube.GridPoint[2],*GridCube.GridPoint[6],10);
	if (edgeTable[CubeIndex] & 2048)
		Interpolate(*GridCube.GridPoint[3],*GridCube.GridPoint[7],11);	

	glDepthFunc(GL_LESS);
	
		for (i=0;TriangleTable[CubeIndex][i]!=-1;i+=3) 
		{
			for (int j=0;j<meta_number;j++)
			{
				glEnable(GL_BLEND);
				glDisable(GL_DEPTH_TEST);

				normals[vertices_count]=Norm[TriangleTable[CubeIndex][i]].x;
				normals[vertices_count+1]=Norm[TriangleTable[CubeIndex][i]].y;
				normals[vertices_count+2]=Norm[TriangleTable[CubeIndex][i]].z;
				
				float Abs_norm=(float)pow(pow(	(Norm[TriangleTable[CubeIndex][i]].x)+
												(Norm[TriangleTable[CubeIndex][i]].y)+
												(Norm[TriangleTable[CubeIndex][i]].z),2),1/3);
				
				vertices[vertices_count	 ]=VertList[TriangleTable[CubeIndex][i]].x+((VertList[TriangleTable[CubeIndex][i]].x)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));
				vertices[vertices_count+1]=VertList[TriangleTable[CubeIndex][i]].y+((VertList[TriangleTable[CubeIndex][i]].y)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));
				vertices[vertices_count+2]=VertList[TriangleTable[CubeIndex][i]].z+((VertList[TriangleTable[CubeIndex][i]].z)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));
				
				
				normals[vertices_count+3]=Norm[TriangleTable[CubeIndex][i+1]].x;
				normals[vertices_count+4]=Norm[TriangleTable[CubeIndex][i+1]].y;
				normals[vertices_count+5]=Norm[TriangleTable[CubeIndex][i+1]].z;

				Abs_norm=(float)pow(pow(	(Norm[TriangleTable[CubeIndex][i+1]].x)+
											(Norm[TriangleTable[CubeIndex][i+1]].y)+
											(Norm[TriangleTable[CubeIndex][i+1]].z),2),1/3);
				
				vertices[vertices_count+3]=VertList[TriangleTable[CubeIndex][i+1]].x+((VertList[TriangleTable[CubeIndex][i+1]].x)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));
				vertices[vertices_count+4]=VertList[TriangleTable[CubeIndex][i+1]].y+((VertList[TriangleTable[CubeIndex][i+1]].y)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));
				vertices[vertices_count+5]=VertList[TriangleTable[CubeIndex][i+1]].z+((VertList[TriangleTable[CubeIndex][i+1]].z)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));
				
				normals[vertices_count+6]=Norm[TriangleTable[CubeIndex][i+2]].x;
				normals[vertices_count+7]=Norm[TriangleTable[CubeIndex][i+2]].y;
				normals[vertices_count+8]=Norm[TriangleTable[CubeIndex][i+2]].z;
				
				Abs_norm=(float)pow(pow(	(Norm[TriangleTable[CubeIndex][i+2]].x)+
											(Norm[TriangleTable[CubeIndex][i+2]].y)+
											(Norm[TriangleTable[CubeIndex][i+2]].z),2),1/3);

				vertices[vertices_count+6]=VertList[TriangleTable[CubeIndex][i+2]].x+((VertList[TriangleTable[CubeIndex][i+2]].x)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));
				vertices[vertices_count+7]=VertList[TriangleTable[CubeIndex][i+2]].y+((VertList[TriangleTable[CubeIndex][i+2]].y)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));
				vertices[vertices_count+8]=VertList[TriangleTable[CubeIndex][i+2]].z+((VertList[TriangleTable[CubeIndex][i+2]].z)/Abs_norm*j*((beat_responder/20.0f+3.0f)/70+0.3f));

				

				indices[indices_count]=indices_count;
				indices[indices_count+1]=indices_count+1;
				indices[indices_count+2]=indices_count+2;

				colours[colours_count  ]=colors[col][0];
				colours[colours_count+1]=colors[col][1];
				colours[colours_count+2]=colors[col][2];
				colours[colours_count+3]=0.8f;
				
				colours[colours_count+4]=colors[col][0];
				colours[colours_count+5]=colors[col][1];
				colours[colours_count+6]=colors[col][2];
				colours[colours_count+7]=0.8f;
				
				colours[colours_count+8] =colors[col][0];
				colours[colours_count+9] =colors[col][1];
				colours[colours_count+10]=colors[col][2];
				colours[colours_count+11]=0.8f;

				vertices_count=vertices_count+9;
				indices_count=indices_count+3;
				colours_count=colours_count+12;
				texture_count=texture_count+6;

			}			
			TessTriangles++;
			index_helper=index_helper+1;		
		}
	return index_helper;
}


void scene2::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	int index_helper=0;

	
	/*if (timeeffect<3 && choice==0 )
	{
		glViewport(0,0,128,128);
			glBindTexture(GL_TEXTURE_2D,BlurTexture);
			glLoadIdentity();
			liquid1->Draw(255,this_mod);
			glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, 0, 0, 128, 128, 0);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);			
		glViewport(0 , 0,(GLsizei)width ,(GLsizei)height);
	}*/
	glEnable(GL_BLEND);
	glPushMatrix();
	glTranslatef(0.0,0.0,-5.5f+(float)pow(beat_responder/20.0f,2));
	glPushMatrix();
		glScalef(1.0f+2.0f*(float)pow(beat_responder/30.0f,2),1.0f+2.0f*(float)pow(beat_responder/30.0f,2),1.0f+0.5f*(float)pow(beat_responder/30.0f,2));
		glPushMatrix();
			glRotatef(xrot*4, 0, 0, 1);
			glRotatef(xrot*2, 0, 1, 0);
			glRotatef(xrot*3, 1, 0, 0);
			glEnable(GL_TEXTURE_2D);

			for (cx = 0 ;cx< GridSize-1;cx++)
			{
				for (int cy = 0 ;cy< GridSize-1;cy++)
				{
					for (int cz = 0 ;cz< GridSize-1;cz++)
					{
						index_helper=CreateCubeTriangles(Cubes[cx][cy][cz],index_helper,xrot,blend_colour);
					}
				}
			}
			
			for (int te_count=0;te_count<texture_count;te_count+=6)
			{
				tex_coords[te_count  ]=0.0f+beat_responder/10;
				tex_coords[te_count+1]=0.0f+beat_responder/10;
				tex_coords[te_count+2]=1.0f+beat_responder/10;
				tex_coords[te_count+3]=1.0f+beat_responder/10;
				tex_coords[te_count+4]=0.0f+beat_responder/10;
				tex_coords[te_count+5]=1.0f+beat_responder/10;	
			}
			
			glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
			glEnable(GL_TEXTURE_2D);
			glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
			glClientActiveTextureARB ( GL_TEXTURE1_ARB             );
			glEnable(GL_TEXTURE_2D);
			glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );
			
			glActiveTextureARB ( GL_TEXTURE0_ARB );  
			if (scene_switcher<=19)
			{
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glEnable(GL_TEXTURE_GEN_S);
				glEnable(GL_TEXTURE_GEN_T);
			}
			if (scene_switcher>19)
			{
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glEnable(GL_TEXTURE_GEN_S);
				glEnable(GL_TEXTURE_GEN_T);
			}
			if (scene_switcher>38)
			{
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glEnable(GL_TEXTURE_GEN_S);
				glEnable(GL_TEXTURE_GEN_T);
			}

			glEnable(GL_LIGHTING);
			glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );
			
			glActiveTextureARB ( GL_TEXTURE1_ARB ); 
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			
			if (timeeffect>10)
			{
			if (scene_switcher<8 && choice!=1)
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
			else
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

			glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );

			}
			else
			{
				glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
				glEnable(GL_TEXTURE_2D);
				glBindTexture(GL_TEXTURE_2D,BlurTexture);
				glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glEnable(GL_TEXTURE_GEN_S);
				glEnable(GL_TEXTURE_GEN_T);
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

				glClientActiveTextureARB ( GL_TEXTURE1_ARB             ); 
				glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
				glEnable(GL_TEXTURE_2D);
				glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glEnable(GL_TEXTURE_GEN_S);
				glEnable(GL_TEXTURE_GEN_T);
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
			}


			glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
			glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
			glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
			glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
			glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
			glColorPointer  ( 4, GL_FLOAT, 0, &colours );
			glNormalPointer	(GL_FLOAT, 0, &normals);
			glDrawElements  ( GL_TRIANGLES, indices_count-1, GL_UNSIGNED_INT, &indices );
			
		glPopMatrix();
	glPopMatrix();
	glPopMatrix();
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);		
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glDisable(GL_TEXTURE_GEN_S);															
	glDisable(GL_TEXTURE_GEN_T);
	if (timeeffect<3 && choice==0)
	{
		//DrawBlur(10, 0.3f);	
		//bg->DrawPlasma((float)timeeffect*20);
		//bg->DrawRotateTile((float)timeeffect*xrot);;
	}
	
}



GLvoid	scene2::Interpolate(TGridPoint C1,TGridPoint C2,int in)
{
	GLVector Norm_h,CResult;
	if (fabs(C1.Value) == 1)
	{
		CResult = C1.Pos;
		Norm_h = C1.Normal;
	}
	else
	{
		if (fabs(C2.Value) == 1)
		{
			CResult = C2.Pos;
			Norm_h = C2.Normal;
		}
		else
		{
			if (C1.Value == C2.Value)
			{
				CResult = C1.Pos;
				Norm_h = C1.Normal;
			}
			else
			{
				mu = (1 - C1.Value) / (C2.Value - C1.Value);
				CResult.x = C1.Pos.x + mu * (C2.Pos.x - C1.Pos.x);
				CResult.y = C1.Pos.y + mu * (C2.Pos.y - C1.Pos.y);
				CResult.z = C1.Pos.z + mu * (C2.Pos.z - C1.Pos.z);

				Norm_h.x = C1.Normal.x + (C2.Normal.x - C1.Normal.x) * mu;
				Norm_h.y = C1.Normal.y + (C2.Normal.y - C1.Normal.y) * mu;
				Norm_h.z = C1.Normal.z + (C2.Normal.z - C1.Normal.z) * mu;
			}
		}
	}
	VertList[in]=CResult;
	Norm[in]=Norm_h;
}

void scene2::DrawBlur(int times, float inc)								// Draw The Blurred Image
{
	float spost = 0.0f;											// Starting Texture Coordinate Offset
	float alphainc = 0.9f / times;								// Fade Speed For Alpha Blending
	float alpha = 0.2f;											// Starting Alpha Value

	// Disable AutoTexture Coordinates
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	glEnable(GL_TEXTURE_2D);									// Enable 2D Texture Mapping
	glDisable(GL_DEPTH_TEST);									// Disable Depth Testing
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);							// Set Blending Mode
	glEnable(GL_BLEND);											// Enable Blending
	glBindTexture(GL_TEXTURE_2D,BlurTexture);					// Bind To The Blur Texture
	ViewOrtho();												// Switch To An Ortho View

	alphainc = alpha / times;									// alphainc=0.2f / Times To Render Blur

	glBegin(GL_QUADS);											// Begin Drawing Quads
		for (int num = 0;num < times;num++)						// Number Of Times To Render Blur
		{
			glColor4f(1.0f, 1.0f, 1.0f, alpha);					// Set The Alpha Value (Starts At 0.2)
			glTexCoord2f(0+spost,1-spost);						// Texture Coordinate	( 0, 1 )
			glVertex2f(0,0);									// First Vertex		(   0,   0 )

			glTexCoord2f(0+spost,0+spost);						// Texture Coordinate	( 0, 0 )
			glVertex2f(0,480);									// Second Vertex	(   0, 480 )

			glTexCoord2f(1-spost,0+spost);						// Texture Coordinate	( 1, 0 )
			glVertex2f(640,480);								// Third Vertex		( 640, 480 )

			glTexCoord2f(1-spost,1-spost);						// Texture Coordinate	( 1, 1 )
			glVertex2f(640,0);									// Fourth Vertex	( 640,   0 )

			spost += inc;										// Gradually Increase spost (Zooming Closer To Texture Center)
			alpha = alpha - alphainc;							// Gradually Decrease alpha (Gradually Fading Image Out)
		}
	glEnd();													// Done Drawing Quads

	ViewPerspective();											// Switch To A Perspective View

	glEnable(GL_DEPTH_TEST);									// Enable Depth Testing
	glDisable(GL_TEXTURE_2D);									// Disable 2D Texture Mapping
	glDisable(GL_BLEND);										// Disable Blending
	glBindTexture(GL_TEXTURE_2D,0);								// Unbind The Blur Texture
}

bool scene2::Init(loadall		*textures)
{
	fadeffect		= 0;
	glViewport (0, 0, (GLsizei)width, (GLsizei)height);				
	glMatrixMode (GL_PROJECTION);										
	glLoadIdentity ();	
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);
	glMatrixMode (GL_MODELVIEW);										
	glLoadIdentity ();	

	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );
	glEnableClientState ( GL_NORMAL_ARRAY);
	glDisable(GL_FOG);

	BlurTexture		= textures->EmptyTexture();

	multi_texture=rand()%19;
	scene_switcher=rand()%55;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(10);
			m_Texture[1]=textures->Bind(11);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(13);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(12);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(4);
		break;
		case 10:
			m_Texture[0]=textures->Bind(7);
			m_Texture[1]=textures->Bind(14);
		break;
		case 11:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(15);
		break;
		case 12:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(16);
		break;
		case 13:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(17);
		break;
		case 14:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(18);
		break;
		case 15:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(19);
		break;
		case 16:
			m_Texture[0]=textures->Bind(20);
			m_Texture[1]=textures->Bind(17);
		break;
		case 17:
			m_Texture[0]=textures->Bind(21);
			m_Texture[1]=textures->Bind(15);
		break;
		case 18:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(22);
		break;
	}
	/*multi_texture=rand()%19;
	if (multi_texture>19)
		multi_texture=0;
	scene_switcher=rand()%55;
	if (scene_switcher>=55)
		scene_switcher=0;*/

	SceneStart		= GetTickCount();

	return true;
}


