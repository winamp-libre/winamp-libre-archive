#include "headers.h"
#include "Misc.h"
#include "liquid8.h"

scene8::scene8(double time,float wid,float hei):Manager(time)					// Constructor
{
	OldTime			= 0.0f;
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	timeeffect		= 0;
	t1				= 0;
	Time			= 0;
	Step			=0;

	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	Src[0]=0;Src[1]=0;Src[2]=0;
	Dst[0]=0;Dst[1]=0;Dst[2]=0;
	dX,dY,dZ							=1;

	float shift=40/512;
	float pos=0.30f;
	GLubyte blend_colour				= 30;

	GLfloat vertices_help[] =	
	{	
		pos+shift,	0.0,		0.0,        
		pos+shift,	pos+shift,	0.0,
		pos+shift,	pos+shift,	pos+shift,
		pos+shift,	0.0,		pos+shift,
		
		0.0,		0.0,		pos+shift,
		0.0,		0.0,		0.0,
		0.0,		pos+shift,	0.0,
		0.0,		pos+shift,	pos+shift,
		
		0.0,		pos+shift,	0.0,
		pos+shift,	pos+shift,	0.0,
		pos+shift,	0.0,		0.0,
		0.0,		0.0,		0.0,
		
		0.0,		0.0,		pos+shift,
		0.0,		pos+shift,	pos+shift,
		pos+shift,	pos+shift,	pos+shift,
		pos+shift,	0.0,		pos+shift,
		
		pos+shift,	pos+shift,	0.0,
		pos+shift,	pos+shift,	pos+shift,
		0.0,		pos+shift,	pos+shift,
		0.0,		pos+shift,	0.0,
		
		pos+shift,	0.0,		pos+shift,
		0.0,		0.0,		pos+shift,
		0.0,		0.0,		0.0,
		pos+shift,	0.0,		0.0
	};

	GLfloat tex_coords_help[] = 
	{    
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f, 
		
		0.0f, 1.0f,
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
		
		0.0f, 1.0f,
		1.0f, 1.0f,
		1.0f, 0.0f,
		0.0f, 0.0f,
		
		0.0f, 0.0f,
		0.0f, 1.0f,
		1.0f, 1.0f,
		1.0f, 0.0f,
		
		0.0f, 1.0f,
		1.0f, 1.0f,
		1.0f, 0.0f,
		0.0f, 0.0f,
		
		1.0f, 1.0f,
		1.0f, 0.0f,
		0.0f, 0.0f,
		0.0f, 1.0f
	};

	GLuint indices_help[] = 
	{	
		0	,1	,2	,3	, 
		4	,5	,6	,7	, 
		8	,9	,10	,11	, 
		12	,13	,14	,15	,
		16	,17	,18	,19	,
		20	,21	,22	,23 
	};

	GLfloat normals_help[]=	
	{		
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		-1.0f, 0.0f, 0.0f,
		
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		0.0f, 0.0f, -1.0f,
		
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		0.0f, 0.0f, 1.0f,
		
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f, 0.0f,
		
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		0.0f, -1.0f, 0.0f
	};

	GLubyte colours_help[]  =	
	{	
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour,
		255, 255, 255,	blend_colour
	};

	for (i=0;i<72;i++)
	{
		vertices[i]=vertices_help[i];
		normals[i]=normals_help[i];
	}
	for (i=0;i<24;i++)
		indices[i]=indices_help[i];
	for (i=0;i<96;i++)
		colours[i]=colours_help[i];

	for (i=0;i<48;i++)
		tex_coords[i]=tex_coords_help[i];

	multi_texture	= 1;
	scenechanger	=-1;

	width						= wid;
	height						= hei;
	bg								= new background();
}

scene8::~scene8()					
{
	if (liquid_cube)
		delete liquid_cube;
}


void scene8::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};

	int col=0;

	if (beat_responder>10)
		col=1;
	if (beat_responder>20)
		col=2;
	if (beat_responder>30)
		col=3;
	if (beat_responder>40)
		col=4;
	if (beat_responder>50)
		col=5;
	if (beat_responder>60)
		col=6;
	if (beat_responder>70)
		col=7;
	if (beat_responder>80)
		col=8;
	if (beat_responder>90)
		col=9;
	if (beat_responder>100)
		col=0;
	t1+=0.01f*direction;
		
	if (t1>1.5*beat_responder/10)	
		direction=-1;
	if (t1<-1.5*beat_responder/10)
		direction=1;

	xrot+=direction*beat_responder/40;
	OldTime = Time;                                  
	Time = GetTickCount()/20000.0f+beat_responder/2000;
	Step = Step + Time - OldTime;
	int MaxCube=3;

	if (Step >= 1.0f)
	{
		Step = 0.0f;
		
		for (int i=0;i<3;i++)
			Src[i] = Dst[i];  
		
		if ((Src[0] >= MaxCube) || (Src[0] <= 0)) 
			dX = -dX;                 
		if ((Src[1] >= MaxCube) || (Src[1] <= 0)) 
			dY = -dY;
		if ((Src[2] >= MaxCube) || (Src[2] <= 0)) 
			dZ = -dZ;
		
		switch (Direction)
		{                               
		case 0: 
			{
				Dst[1] = (Dst[1] + dY);
				Dst[2] = (Dst[2] + dZ);
			}
		case 1:
			{
				Dst[0] = (Dst[0] + dX);
				Dst[2] = (Dst[2] + dZ);
			}
		case 2:
			{
				Dst[1] = (Dst[1] + dY);
				Dst[0] = (Dst[0] + dX);
			}
		}
		Direction=Direction++; 
		
		if (Direction > 2) 
			Direction = 0;
	}
	GLuint	fogMode[]	= { GL_EXP, GL_EXP2, GL_LINEAR };
	GLfloat fogColor[4]	= {colors[col][0],colors[col][1],colors[col][2],0.1f}; 								
	glFogi(GL_FOG_MODE, fogMode[1]);						
	glFogfv(GL_FOG_COLOR, fogColor);						
	glFogf(GL_FOG_DENSITY, 0.01f);
	
	xPos = Src[0] + (Dst[0] - Src[0]) * Step ;        
	yPos = Src[1] + (Dst[1] - Src[1]) * Step ;
	zPos = Src[2] + (Dst[2] - Src[2]) * Step ;
	
	glRotatef(Time * 20.0f, 1.0f, 0.0f, 0.0f);                 
	glRotatef(Time * 30.0f, 0.0f, 1.0f, 0.0f);
	glRotatef(Time * 50.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-2.0f, -2.0f, -2.0f);                   
	//glTranslatef(xPos, yPos, zPos);
	glEnable(GL_BLEND);
	glFogi(GL_FOG_MODE, GL_EXP2);
	glFogf(GL_FOG_START, -50.0f);
	glFogf(GL_FOG_END, -20.0f);
	glEnable(GL_FOG);
	glEnable(GL_LIGHT0);                             
	glEnable(GL_LIGHTING);                          
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glShadeModel(GL_SMOOTH);
	glDisable(GL_DEPTH_TEST);                          
	
	initcubes();
	glDisable(GL_FOG);
}

void scene8::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/100000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/30)*(beat_responder/30))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;

	float shift=beat_responder/800;
	float pos=0.30f;

	GLfloat vertices_help[] =	
	{	
		pos+shift,	0.0,		0.0,        
		pos+shift,	pos+shift,	0.0,
		pos+shift,	pos+shift,	pos+shift,
		pos+shift,	0.0,		pos+shift,
		
		0.0,		0.0,		pos+shift,
		0.0,		0.0,		0.0,
		0.0,		pos+shift,	0.0,
		0.0,		pos+shift,	pos+shift,
		
		0.0,		pos+shift,	0.0,
		pos+shift,	pos+shift,	0.0,
		pos+shift,	0.0,		0.0,
		0.0,		0.0,		0.0,
		
		0.0,		0.0,		pos+shift,
		0.0,		pos+shift,	pos+shift,
		pos+shift,	pos+shift,	pos+shift,
		pos+shift,	0.0,		pos+shift,
		
		pos+shift,	pos+shift,	0.0,
		pos+shift,	pos+shift,	pos+shift,
		0.0,		pos+shift,	pos+shift,
		0.0,		pos+shift,	0.0,
		
		pos+shift,	0.0,		pos+shift,
		0.0,		0.0,		pos+shift,
		0.0,		0.0,		0.0,
		pos+shift,	0.0,		0.0
	};

	for (i=0;i<72;i++)
	{
		vertices[i]=vertices_help[i];
	}
}

bool scene8::Init(loadall		*textures)
{
	Time			= 0;
	timeeffect		= 0;
	OldTime			= 0.0f;
	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	t				= 0.0f;
	t1				= 0.0f;
	fadeffect		= 0;

	multi_texture=rand()%16;
	scenechanger=rand()%30;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(5);
		break;
		case 5:
			m_Texture[0]=textures->Bind(10);
			m_Texture[1]=textures->Bind(0);
		break;
		case 6:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(4);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(4);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(4);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(4);
		break;
		case 10:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(6);
		break;
		case 11:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(6);
		break;
		case 12:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(6);
		break;
		case 13:
			m_Texture[0]=textures->Bind(17);
			m_Texture[1]=textures->Bind(6);
		break;
		case 14:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(6);
		break;
		case 15:
			m_Texture[0]=textures->Bind(19);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==16)
		multi_texture=0;
	scenechanger=scenechanger++;
	if (scenechanger==30)
		scenechanger=0;*/
	return true;
}

void scene8::initcubes(void) 
{
	int MaxCube=3;
	if (scenechanger<=15)
	{
			glActiveTextureARB		( GL_TEXTURE0_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glEnable(GL_BLEND);
			glDisable(GL_DEPTH_TEST);
			 
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB		( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			
			glEnable(GL_BLEND);
			glDisable(GL_TEXTURE_GEN_S);																
			glDisable(GL_TEXTURE_GEN_T);	
			glDisable(GL_DEPTH_TEST);
			glEnable(GL_BLEND);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	else
	{
			glActiveTextureARB		( GL_TEXTURE0_ARB );
			glEnable(GL_TEXTURE_2D);
			glDisable(GL_TEXTURE_GEN_S);
			glDisable(GL_TEXTURE_GEN_T);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glDisable(GL_BLEND);
			glEnable(GL_DEPTH_TEST);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB		( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			
			glEnable(GL_BLEND);
			glEnable(GL_TEXTURE_GEN_S);																
			glEnable(GL_TEXTURE_GEN_T);	
			glDisable(GL_DEPTH_TEST);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

	}
	glEnableClientState ( GL_VERTEX_ARRAY );
	glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
	glEnable(GL_TEXTURE_2D);
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );
	glEnable(GL_TEXTURE_2D);
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );

	

	glRotatef(xrot/3,1.0f,1.0f,0.0f);
	glPushMatrix();
		for (int I = -3;I<=MaxCube + 3;I++)
			for (int J = -3 ;J<=MaxCube + 3;J++)
				for (int K = -3 ;K<=MaxCube + 3;K++)
				{
					
					for (int l=1;l<4;l++)
					{
						glPushMatrix();
							glScalef(1+(beat_responder/6000)*(l/10),1+(beat_responder/6000)*l/10,1+(beat_responder/6000)*l/10);
							glTranslatef((float)I,(float)J,(float)K);              
							glTranslatef(-0.75f, -0.75f, -0.75f);  
							glPushMatrix();
								glColor4f(1.0f,1.0f,1.0f,0.2f+l*0.1f);
								glRotatef(xrot/5*I,0.0f,1.0f,0.0f); 
								glRotatef(xrot/7*J,0.0f,0.0f,1.0f);
								glRotatef(xrot/10*K,1.0f,0.0f,0.0f);
								glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
								glColorPointer  ( 4, GL_UNSIGNED_BYTE, 0, &colours );
								glNormalPointer	(GL_FLOAT, 0, &normals);
								glDrawElements  ( GL_QUADS, 24, GL_UNSIGNED_INT, &indices );
							glPopMatrix();
						glPopMatrix();
					}
				}
	glPopMatrix();
	
}
