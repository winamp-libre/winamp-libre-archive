#ifndef __LIQUID34_H_
#define __LIQUID34_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "vis.h"
#include <ctime>

class scene34:public Manager
{

	public:
		scene34(double time,float wid,float hei);												
		~scene34();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		GLUquadricObj *QuadSphere;

		GLfloat LightAmbient[4];
		GLfloat LightDiffuse[4];
		GLfloat LightPosition[4];
		GLfloat matSpecular[4];
		GLfloat shininess;

		bool gridon;
		bool ballson;
		bool barson;

		int sizex;
		int sizey;
		int bitdepth;

		
		int     g_iDeform;						// Current deformation number
		int     g_iDrawLines;					// Should we draw random lines ?
		int     g_iDrawCube;					// Should we draw a nice wireframe 3d cube ?
		int     g_iFrame;						// Frame counter
		int     g_iClear;						// Should we clear the texture
		int     g_iShowField;					// Should we draw the vector field ?
		int		g_iPaintBrush;					// Should we draw a square under mouse cursor ?
		int		g_iCurrentColor;
		double	g_dBrushX,g_dBrushY;			// Position of mouse cursor
		int switch_color_or_vector;

		float		GetTime(void);

		GLuint		m_Texture[5];										
		int			i,direction;
		int			scene_switcher;
		float		scalefactor;
		float		xrot,t,t2;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		loadall		*textures_in;
		bool		speedTexure;
		float		lastTime,sceneTime;
		Manager		*liquid_next;
		float		width,height;
		int			fade_def;

		float c_red;
		float c_green;
		float c_blue;
		float currentColor[3];

		double g_iDiffTime;
		time_t time1;
		time_t time2;

		GLfloat CameraX;
		GLfloat CameraY;
		GLfloat CameraZ;
		GLfloat CameraTheta;

		GLuint       g_uiGridList;
		GLuint       g_uiTexId;

		void genTexCoords(int time,int res,double ***tbl);
		void noDiffuseDraw(struct winampVisModule *this_mod);
		void diffuseDraw(struct winampVisModule *this_mod);
		void drawVectorField(int res,double ***texCoords);
		void computeGrid(int res,double ***texCoords);
};

#endif __LIQUID34_H_
