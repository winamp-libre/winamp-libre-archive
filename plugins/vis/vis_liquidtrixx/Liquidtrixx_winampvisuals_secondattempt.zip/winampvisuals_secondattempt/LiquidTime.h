#ifndef LIQUIDTIME_H
#define LIQUIDTIME_H

#include "HEADERS.H"

class liqTime
{
public:
	liqTime();

	void			update();
	double			getFrameTime();	

private:
	int				m_iCount;
	double			m_dFPS;
	double			m_dFrameTime;

	long			m_lCurrentTime;
	long			m_lLastTime;
};

extern liqTime		*g_pFrameTime;
extern liqTime		*timeeffect;			

#endif
