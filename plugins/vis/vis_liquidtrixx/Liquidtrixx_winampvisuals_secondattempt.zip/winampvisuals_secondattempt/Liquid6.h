#ifndef __LIQUID6_H_
#define __LIQUID6_H_

#include "Scenemanager.h"
#include "TextureLoader.h"	
#include "LoadAlltextures.h"									

class scene6:public Manager
{

	public:
		scene6(double time,float wid,float hei);												
		~scene6();												
		virtual void Draw(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init(loadall		*textures);
	
	private:
		GLuint	m_Texture[5];
		float	xrot,t,t2,beat_responder;
		PFNGLCLIENTACTIVETEXTUREARBPROC		glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC			glActiveTextureARB;
		int		color_holder,multi_texture,direction;
		DWORD	internal_timer;
		DWORD	SceneStart;
		GLfloat vertices[48];
		GLuint	indices[16];
		GLfloat normals[48];
		GLubyte colours[64];
		GLfloat tex_coords[32];
		int		scenechanger;

		float	width,height;
};

#endif __LIQUID6_H_
