#include "headers.h"
#include "Misc.h"
#include "liquid6.h"

scene6::scene6(double time,float wid,float hei):Manager(time)				
{
	scenechanger					=-1;
	color_holder					=0;
	SceneStart						=0;	
	multi_texture					= 0;
	glClientActiveTextureARB		= NULL;
	glActiveTextureARB				= NULL;
	glActiveTextureARB				= ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB		= ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	direction		= -1;
   
	xrot							= 0;

	GLuint blend_colour=255;

	GLfloat vertices_help[] =	{-1.0,  1.0, -1.0,
								-1.0,  1.0,  1.0,
								1.0,  1.0,  1.0,
								1.0,  1.0, -1.0,

								-1.0, -1.0, -1.0,
								1.0, -1.0, -1.0,
								1.0, -1.0,  1.0,
								-1.0, -1.0,  1.0,

								1.0, -1.0, -1.0,
								1.0,  1.0, -1.0,
								1.0,  1.0,  1.0,
								1.0, -1.0,  1.0,	
								
								-1.0, -1.0, -1.0,
								-1.0, -1.0,  1.0,
								-1.0,  1.0,  1.0,
								-1.0,  1.0, -1.0};

	GLuint indices_help[]   = {	0	,1	,2	,3	, 
								4	,5	,6	,7	, 
								8	,9	,10	,11	, 
								12	,13	,14	,15};

	GLfloat normals_help[]=	{	0.0, 1.0, 0.0,
								0.0, 1.0, 0.0,
								0.0, 1.0, 0.0,
								0.0, 1.0, 0.0,

								0.0, -1.0, 0.0,
								0.0, -1.0, 0.0,
								0.0, -1.0, 0.0,
								0.0, -1.0, 0.0,

								1.0, 0.0, 0.0,
								1.0, 0.0, 0.0,
								1.0, 0.0, 0.0,
								1.0, 0.0, 0.0,

								-1.0, 0.0, 0.0,
								-1.0, 0.0, 0.0,
								-1.0, 0.0, 0.0,
								-1.0, 0.0, 0.0};

	GLubyte colours_help[]  =	{	255, 255, 255,	blend_colour,
                                255, 255, 255,	blend_colour,
                                255, 255, 255,	blend_colour,
								255, 255, 255,	blend_colour,
							
								255, 255, 255,	blend_colour,
                                255, 255, 255,	blend_colour,
                                255, 255, 255,	blend_colour,
								255, 255, 255,	blend_colour,
	
								255, 255, 255,	blend_colour,
                                255, 255, 255,	blend_colour,
                                255, 255, 255,	blend_colour,
								255, 255, 255,	blend_colour,
	
								255, 255, 255,	blend_colour,
                                255, 255, 255,	blend_colour,
                                255, 255, 255,	blend_colour,
								255, 255, 255,	blend_colour};

	float	tex_cord=1.0f;
	float	roll=0.0f;

	GLfloat tex_coords_help[] = {    0.0f+roll, 0.0f+roll,
                                tex_cord+roll, 0.0f+roll,
                                tex_cord+roll, tex_cord+roll,
                                0.0f+roll, tex_cord+roll, 
	
								tex_cord+roll, 0.0f+roll,
								tex_cord+roll, tex_cord+roll,
								0.0f+roll, tex_cord+roll,
								0.0f+roll, 0.0f+roll,

								tex_cord+roll, 0.0f+roll,
								tex_cord+roll, tex_cord+roll,
								0.0f+roll, tex_cord+roll,
								0.0f+roll, 0.0f+roll,

								tex_cord+roll, 0.0f+roll,
								tex_cord+roll, tex_cord+roll,
								0.0f+roll, tex_cord+roll,
								0.0f+roll, 0.0f+roll};


	for (int i=0;i<48;i++)
	{
		vertices[i]=vertices_help[i];
		normals[i]=normals_help[i];
	}
	for (i=0;i<16;i++)
		indices[i]=indices_help[i];
	for (i=0;i<64;i++)
		colours[i]=colours_help[i];
	for (i=0;i<32;i++)
		tex_coords[i]=tex_coords_help[i];

	width						= wid;
	height						= hei;
	t2							= 0.0f;
}

scene6::~scene6()					
{
}


void scene6::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glPushMatrix();
		//glTranslatef(xrot/500*sin(0.1*t2),xrot/3000*cos(0.1*t2),0.0f);
		glRotatef(-xrot/10,0.0f,0.0f,1.0f);
		//glRotatef(xrot,0.0f,1.0f,0.0f);
		
	glPushMatrix();
		double z=0.0;
		double x=0.0;
		double y=0.0;

		GLfloat	zrot		=0.2f;
		GLfloat	xspeed		=2.0f;
		GLfloat	yspeed		=4.0f;


		if (scenechanger<18)
		{
			glActiveTextureARB		( GL_TEXTURE0_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glEnable(GL_BLEND);
			glDisable(GL_DEPTH_TEST);
			 
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB		( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			
			glEnable(GL_BLEND);
			glDisable(GL_TEXTURE_GEN_S);																
			glDisable(GL_TEXTURE_GEN_T);	
			glDisable(GL_DEPTH_TEST);
			glEnable(GL_BLEND);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		}
		if (scenechanger>18)
		{
			glActiveTextureARB		( GL_TEXTURE0_ARB );
			glEnable(GL_TEXTURE_2D);
			glDisable(GL_TEXTURE_GEN_S);
			glDisable(GL_TEXTURE_GEN_T);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glDisable(GL_BLEND);
			glEnable(GL_DEPTH_TEST);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB		( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			
			glEnable(GL_BLEND);
			glEnable(GL_TEXTURE_GEN_S);																
			glEnable(GL_TEXTURE_GEN_T);	
			glDisable(GL_DEPTH_TEST);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		}
		if (scenechanger>35)
		{
			glActiveTextureARB		( GL_TEXTURE0_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
			glEnable(GL_BLEND);
			glDisable(GL_DEPTH_TEST);
			 
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB		( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			
			glEnable(GL_BLEND);
			glDisable(GL_TEXTURE_GEN_S);																
			glDisable(GL_TEXTURE_GEN_T);	
			glDisable(GL_DEPTH_TEST);
			glEnable(GL_BLEND);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		}

		glEnable(GL_NORMALIZE);
		glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
		glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
		glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
		glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
		
		glDisable(GL_LIGHT0);                             
		glDisable(GL_LIGHTING);
		glEnableClientState ( GL_VERTEX_ARRAY );
		glEnableClientState ( GL_COLOR_ARRAY );

		glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
		glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
		glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
		glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );
		
		glTranslatef(0.0f,0.0f,-15+(10.0f*(0.01f*(float)sin(12*internal_timer/10000.0f)-0.0f*(float)sin(9*internal_timer/10000.0f)+0.4f)+(float)pow(beat_responder/200,2)));
		glRotatef(xrot,0.0f,0.0f,1.0f);
		glPushMatrix();
			glRotatef(xrot/1000,0.0f,0.0f,1.0f);
			glTranslatef(0.0f,0.0f,-1.0f);
			int direction=1;
			float scale=1.0f;
			float scale2=1.0f;
			int direction_h=1;
			for (int loop=0; loop<50; loop++)
			{
				glPushMatrix();
				scale=scale*0.95f;
				
				scale2=scale2*0.9f;
				if (beat_responder>60)
				{
					color_holder=color_holder+2;
					direction_h=rand()%2;
					if (direction_h==0 || direction_h==2)
					{
						direction_h=1;
					}
					else
						direction_h=-1;
				}
				else
					color_holder=color_holder-2;
				if (color_holder<0)
					color_holder=50;
				if (color_holder>50)
					color_holder=0;
				
				float xtrans=beat_responder/20*(loop+1)/50*(float)cos(t/10+loop/100)+beat_responder/30*(float)cos(3*t+loop/100)+beat_responder/80*(float)sin(5*t+loop/100);
				float ytrans=beat_responder/10*(loop+1)/50*(float)sin(t/10+loop/100)+beat_responder/30*(float)cos(3*t+loop/100)+beat_responder/80*(float)sin(5*t+loop/100);
				
				glRotatef(xrot*(loop+1)*direction_h/200,0.0f,0.0f,1.0f);
				glTranslatef(xtrans/4.0f,ytrans/6.0f,4.0f+(scale2*(float)pow(beat_responder/20.0f,2))+(float)pow(beat_responder/30.0f,2)*(float)cos(t/10.0f)*(float)sin(t/100.0f));
				glPushMatrix();
					glScalef(scale*2,scale*2,scale*2);
					glEnable(GL_TEXTURE_2D);
					glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
					glColorPointer  ( 4, GL_UNSIGNED_BYTE, 0, &colours );
					glDrawElements  ( GL_QUADS, 16, GL_UNSIGNED_INT, &indices );

					glPopMatrix();
					z=z-3.0f;
				glPopMatrix();
				if (direction_h==1)
					direction_h=-1;
				else
					direction_h=1;
			}
		glPopMatrix();
	glPopMatrix();
}

void scene6::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	gluLookAt(0, 0, 0.5,     0, 0, 0,     0, 1, 0);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);						
	glDisable(GL_TEXTURE_2D);	
	glBindTexture(GL_TEXTURE_2D, m_Texture[1]);								
	glDisable(GL_DEPTH_TEST);	
	beat_responder=beat_help*beat_scaler;
	if (t2>1.5*beat_responder/16)	
		direction=-1;
	if (t2<-1.5*beat_responder/16)
		direction=1;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+0.3f;
	DWORD ticker_help=GetTickCount();
	internal_timer=ticker_help - SceneStart;
	t=(float)(internal_timer/10000.0f);	
	t2+=0.01f*direction;
}

bool scene6::Init(loadall		*textures)
{
	glActiveTextureARB			( GL_TEXTURE0_ARB );   
	glEnable					( GL_TEXTURE_2D   );     

	glActiveTextureARB			( GL_TEXTURE1_ARB );   
	glEnable					( GL_TEXTURE_2D   );

	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);

	glDisable(GL_COLOR_MATERIAL);									

	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);		
											
	glEnable(GL_LIGHT0);                             
	glEnable(GL_LIGHTING);

	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	multi_texture=rand()%20;
	scenechanger=rand()%60;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(22);
			m_Texture[1]=textures->Bind(6);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(6);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(6);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(6);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(6);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(6);
		break;
		case 6:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(6);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(6);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
		case 10:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(6);
		break;
		case 11:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(6);
		break;
		case 12:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(6);
		break;
		case 13:
			m_Texture[0]=textures->Bind(17);
			m_Texture[1]=textures->Bind(6);
		break;
		case 14:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(6);
		break;
		case 15:
			m_Texture[0]=textures->Bind(19);
			m_Texture[1]=textures->Bind(6);
		break;
		case 16:
			m_Texture[0]=textures->Bind(20);
			m_Texture[1]=textures->Bind(6);
		break;
		case 17:
			m_Texture[0]=textures->Bind(21);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	//multi_texture=multi_texture++;
	/*if (multi_texture==20)
		multi_texture=0;*/
	//scenechanger=scenechanger++;
	/*if (scenechanger==60)
		scenechanger=0;*/
	return true;
}

