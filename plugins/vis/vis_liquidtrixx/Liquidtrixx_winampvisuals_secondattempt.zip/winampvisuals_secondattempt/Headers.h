#include <windows.h>											// Header File For Windows
#include <olectl.h>												// Header File For The OLE Controls Library	(BuildTexture)
#include <gl\gl.h>												// Header File For The OpenGL32 Library
#include <gl\glu.h>												// Header File For The GLu32 Library
#include <gl\glaux.h>											// Header File For The GLaux Library
#include <math.h>												// Header File For Math
//#include <stdarg.h>												// Header File For Variable Argument Routines
//#include <string.h>
#include "Glext.h"
//#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")
#pragma comment(lib, "jpeg.lib")
