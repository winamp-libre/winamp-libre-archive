#ifndef __BACKGROUND_H_
#define __BACKGROUND_H_

#include <math.h>

class background
{
	public:
		background();													
		~background();	
		void DrawStatic(void);
		void DrawShaky(void);
		void DrawPlasma(float time);
		void DrawRotateTile(float rot);
		void DrawDistort(float time);
		void DrawWaving(float time);
		void DrawZooming(float time);
};	

#endif __BACKGROUND_H_
