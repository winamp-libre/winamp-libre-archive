#include "headers.h"
#include "Misc.h"
#include "liquid9.h"

scene9::scene9(double time,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	col = 0;
	ret	= 0;

	for(int loop=0;loop<486;loop++)														
	{
		particle[loop].r=(float)(rand()%255);											
		particle[loop].g=(float)(rand()%255);											
		particle[loop].b=(float)(rand()%255);											
		particle[loop].x=((float)(rand()%14000)/1000)-7;								
		particle[loop].y=((float)(rand()%14000)/1000)-7;								
		particle[loop].z=((float)(rand()%14000)/1000)-7;								
	}
	scenechanger=-1;

	width						= wid;
	height						= hei;
}

scene9::~scene9()					
{
}


void scene9::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};	

	GLfloat vertices[]=
	{	
		-1.0f, -1.0f,  5.0f,
		1.0f, -1.0f,  5.0f,
		1.0f,  1.0f,  5.0f,
		-1.0f,  1.0f,  5.0f
	};

	GLfloat tex_coords[]=
	{
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f
	};

	GLfloat		colours[]=
	{
		1.0f,0.0f,1.0f,beat_responder/40,
		1.0f,0.0f,1.0f,beat_responder/40,
		1.0f,0.0f,1.0f,beat_responder/40,
		1.0f,0.0f,1.0f,beat_responder/40,
	};

	GLuint		indices[]={0,1,2,3};		

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);																		
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);		
	glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);																	
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_COLOR);							

	if (scenechanger>15)
	{
		glActiveTextureARB		( GL_TEXTURE0_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
			
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB		( GL_TEXTURE1_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);	
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	else
	{
		glActiveTextureARB		( GL_TEXTURE0_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
			
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB		( GL_TEXTURE1_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);	
		glDisable(GL_DEPTH_TEST);
		glEnable(GL_BLEND);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	
	}

	glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );

	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );


	glVertexPointer ( 3, GL_FLOAT, 0, &vertices );

	float max_k=10;
	float Radius;
	glRotatef(xrot,0.0f,0.0f,1.0f);
	float sense=1.0f;
	if (beat_responder>5)
		col=1;
	if (beat_responder>10)
		col=2;
	if (beat_responder>15)
		col=3;
	if (beat_responder>20)
		col=4;
	if (beat_responder>25)
		col=5;
	if (beat_responder>30)
		col=6;
	if (beat_responder>35)
		col=7;
	if (beat_responder>40)
		col=8;
	if (beat_responder>45)
		col=9;
	if (beat_responder>50)
		col=0;
	float shift;

	glPushMatrix();
		for (int k=0;k<max_k;k++)
		{
			if (k>max_k/2)
				sense=-1.0f;
			for (int i=0;i<=30;i++)
			{
				for (int j=0;j<beat_responder/7;j++)
				{
					glPushMatrix();
					glRotatef((float)i*j,0.0f,0.0f,1.0f);
						glTranslatef(0.0f,0.0f,-150.0f+(float)(beat_responder/10));
						Radius=(float)(pow(beat_responder/300,2)*i*((float)fabs(0.5f+0.3f)));
						glTranslatef(	0.5f+(float)(beat_responder/500*sense*cos(0.5*t+(3.14/(50+j)*(i*t)))*i),
										0.5f+(float)(beat_responder/200*sense*sin(t+(3.14/(50+j)*(i))+xrot/1000)*i),
									(float)(40+beat_responder/1500*sense*((3.14/(50+j)*(i))-xrot/1000)*i));	
						
						div_t div_result=div( ret, 12 );
						if (ret==i)
						{
							shift=beat_responder/20;
							
							
							for (int k=0;k<15;k+=4)
							{
								colours[k	]=colors[div_result.rem][0];
								colours[k+1	]=colors[div_result.rem][1];
								colours[k+2	]=colors[div_result.rem][2];
							}
						}

						else
						{
							for (int k=0;k<15;k+=4)
							{
								colours[k	]=colors[col][0];
								colours[k+1]=colors[col][1];
								colours[k+2]=colors[col][2];
							}
							shift=0;															
						}
						
						if (i<ret)
						{
							for (int k=0;k<15;k+=4)
							{
								colours[k]=colors[col][0];
								colours[k+1]=colors[col][1];
								colours[k+2]=colors[col][2];
							}	
						}
						
						glPushMatrix();
								
							glRotatef(beat_responder,0.0f,0.0f,1.0f);
							glTranslatef((float)(Radius*cos(k*2*3.14/max_k)),(float)(Radius*sin(k*2*3.14/max_k)),i+(i+j)*(2.0f+beat_responder/60)+beat_responder/40);
							glScalef((float)0.5-(i/100)+shift,(float)0.5-(i/100)+shift,(float)0.7-(i/100));
							glRotatef(-xrot/40*i,0.0f,0.0f,1.0f);
							if (i<ret)
								glRotatef(xrot,1.0f,1.0f,1.0f);
							glColorPointer  ( 4, GL_FLOAT, 0, &colours );
							glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
						glPopMatrix();
					glPopMatrix();
				}
			}
		}
	glPopMatrix();
}

void scene9::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;

	ret+=(int)beat_responder/30;
		
	if (ret>=80)
		ret=0;
}

bool scene9::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%15;
	scenechanger=rand()%30;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(6);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(6);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
		case 10:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(6);
		break;
		case 11:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(6);
		break;
		case 12:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(6);
		break;
		case 13:
			m_Texture[0]=textures->Bind(17);
			m_Texture[1]=textures->Bind(6);
		break;
		case 14:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(6);
		break;
		case 15:
			m_Texture[0]=textures->Bind(19);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==16)
		multi_texture=0;
	scenechanger=scenechanger++;
	if (scenechanger==30)
		scenechanger=0;*/
	return true;
}

