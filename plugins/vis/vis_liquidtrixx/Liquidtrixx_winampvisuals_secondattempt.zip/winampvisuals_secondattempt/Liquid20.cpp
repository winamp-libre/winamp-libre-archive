#include "headers.h"
#include "Misc.h"
#include "liquid20.h"

scene20::scene20(double time,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	for (int i=0;i<20;i++)
		offset[i]=0.0f;
	slowdown=0.0f;
	xspeed	=2.0f;
	yspeed	=4.0f;
	col		=0;
	delay	=0;
	help2	=0.0f;

	particle1 =new 	particle(0.0f,1.5f,1.5f);
	particle2 =new 	particle(0.0f,1.5f,0.0f);
	particle3 =new 	particle(0.0f,1.5f,0.0f);
	particle4 =new 	particle(0.0f,1.5f,0.0f);
	particle5 =new 	particle(0.0f,0.0f,0.0f);

	width						= wid;
	height						= hei;
}

scene20::~scene20()	
{
	if (particle1)
		delete particle1;
	if (particle2)
		delete particle2;
	if (particle3)
		delete particle3;
	if (particle4)
		delete particle5;
	if (particle5)
		delete particle5;

}


void scene20::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glActiveTextureARB ( GL_TEXTURE1_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);

	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );

	float delay2=0.5f+0.5f*(float)pow(beat_responder/20.0f,2);
	if (delay>25)
	{
		delay=0;																				
		col++;																					
	}

	if (beat_responder<60)
		slowdown+=slowdown+(float)pow((beat_responder/32),2);
	else
		slowdown-=slowdown+(float)pow((beat_responder/64),2);
	
	if (slowdown<1.0f)
		slowdown=1.0f;
	
	if (slowdown>6.0f)
		slowdown=0.0f;
	
	glRotatef(xrot,0.0f,0.0f,1.0f);
	glTranslatef(0.0f,0.0f,beat_responder/10-10.0f);
	
	glPushMatrix();
		//glTranslatef(4.0f+/*(float)(beat_responder/30*cos(t)-sin(2*t))*/,/*-4.0f-(float)(beat_responder/40*sin(t))*/,-5.0f+beat_responder/40-delay2);
		xspeed=beat_responder/32;
		yspeed=4.0f;
		particle5->Draw(blend_colour,beat_responder,this_mod,xrot,xspeed,yspeed,col);
		xspeed=100.0f;
		yspeed=-200.0f;
		particle1->Draw(blend_colour,beat_responder,this_mod,xrot,xspeed,yspeed,col);
	glPopMatrix();
	
	glPushMatrix();
		//glTranslatef(-1.0f-/*(float)(beat_responder/30*cos(t)-sin(2*t)) */,/*-1.0f-(float)(beat_responder/40*sin(t))*/,-5.0f+beat_responder/40-delay2);
		xspeed=beat_responder/32;
		yspeed=4.0f;
		particle5->Draw(blend_colour,beat_responder,this_mod,xrot,xspeed,yspeed,col);
		xspeed=-100.0f;
		yspeed=-200.0f;
		particle2->Draw(blend_colour,beat_responder,this_mod,xrot,xspeed,yspeed,col);
	glPopMatrix();
	
	glPushMatrix();
		//glTranslatef(-4.0f-/*(float)(beat_responder/40*cos(t)-sin(2*t))*/,4.0f+/*(float)(beat_responder/40*sin(t))*/,-10.0f+beat_responder/40-delay2);
		xspeed=beat_responder/32;
		yspeed=4.0f;
		particle5->Draw(blend_colour,beat_responder,this_mod,xrot,xspeed,yspeed,col);
		xspeed=-100.0f;
		yspeed=200.0f;
		particle3->Draw(blend_colour,beat_responder,this_mod,xrot,xspeed,yspeed,col);
	glPopMatrix();
	
	glPushMatrix();
		//glTranslatef(1.0f+(float)(beat_responder/30*cos(t)-sin(2*t)),1.0f+(float)(beat_responder/40*sin(t)),-10.0f+beat_responder/40-delay2);
		xspeed=beat_responder/32;
		yspeed=4.0f;
		particle5->Draw(blend_colour,beat_responder,this_mod,xrot,xspeed,yspeed,col);
		xspeed=100.0f;
		yspeed=200.0f;
		particle4->Draw(blend_colour,beat_responder,this_mod,xrot,xspeed,yspeed,col);
	glPopMatrix();		
	
	if (col>11)	col=0;				
	delay++;	
}

void scene20::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((float)pow(beat_responder/30,2)+0.1f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
	help2+=direction*beat_responder/20;
}

bool scene20::Init(loadall		*textures)
{
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	particle1->Restore(0.0f,1.5f,1.5f);
	particle2->Restore(0.0f,1.5f,0.0f);
	particle3->Restore(0.0f,1.5f,0.0f);
	particle4->Restore(0.0f,1.5f,0.0f);
	particle5->Restore(0.0f,0.0f,0.0f);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState       ( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;
	multi_texture=rand()%18;
	
	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(5);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(5);
		break;
		case 2:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(5);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(2);
		break;
		case 4:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(3);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(3);
		break;
		case 6:
			m_Texture[0]=textures->Bind(10);
			m_Texture[1]=textures->Bind(11);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(13);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(12);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(4);
		break;
		case 10:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(7);
		break;
		case 11:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(3);
		break;
		case 12:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(2);
		break;
		case 13:
			m_Texture[0]=textures->Bind(17);
			m_Texture[1]=textures->Bind(4);
		break;
		case 14:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(2);
		break;
		case 15:
			m_Texture[0]=textures->Bind(19);
			m_Texture[1]=textures->Bind(4);
		break;
		case 16:
			m_Texture[0]=textures->Bind(20);
			m_Texture[1]=textures->Bind(17);
		break;
		case 17:
			m_Texture[0]=textures->Bind(21);
			m_Texture[1]=textures->Bind(15);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==18)
		multi_texture=0;*/
	return true;
}

