#ifndef __LIQUID32_H_
#define __LIQUID32_H_
#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"
#include "TextGeneration.h"
#include "MeshGeneration.h"
//#include "scene.h"

#define SCENE_FADEOUT	0x0A
#define CUBE_BEAT		0x0B
#define CUBE_SHIFT		0x0C
#define CUBE_ROTATE		0x0D
#define CUBE_MOVE		0x0E
#define CUBE_FAST		0x0F
#define CUBE_RECOMBINE	0x10

class scene32 : public Manager 
{
	public:
		scene32(double time,float wid,float hei);
		~scene32();
		
		virtual void Draw	(GLuint blend_colour,short* pcm);
		virtual void Update	(float beat_help,short* pcm,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
		/*void initGL();
		void render(GLfloat dTick);*/

	private:
		void	makeDLs();
		void	animate();
		float	GetTime(void);
		void	switcher(unsigned char command);

		GLuint *textures;
		GLUquadricObj *sphere;
		GLuint dlSmallSphere;
		GLuint dlBigCube;
		GLuint dlFader;
		GLuint dlBack;

		GLfloat matAmb[4];
		GLfloat matDif[4];
		GLfloat matSpe[4];
		GLfloat matShi[1];
		GLfloat matEmi[4];
		GLfloat lightPos[4];
		GLfloat lightAmb[4];
		GLfloat lightDif[4];

		GLfloat theta, phi, omega, gamma;
		GLfloat whiteout;
		GLfloat xCam, yCam, zCam;
		GLfloat xLook, yLook, zLook;
		GLfloat trans;
		DWORD	tick1,tick2;
		GLfloat dTick;
		bool beat, shift, rotate, move, recombine;
		enum spinStates {fast, slow};	
		enum fadeStates {in, out, none};
		fadeStates fade;
		spinStates spin;
		
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		DWORD		timeeffect,SceneStart;
		float		beat_responder,lastTime,sceneTime;
		float		xrot,t,fadeffect;
		int			direction,multi_texture,scene_switcher;
		GLuint		m_Texture[5];
		float		width,height;
};

#endif __LIQUID32_H_