#ifndef __LIQUID2_H_
#define __LIQUID2_H_

#include "Scenemanager.h"
#include "TextureLoader.h"
#include "LoadAlltextures.h"
#include "Liquid1.h"
#include "vis.h"	

#ifndef io_curve
#define io_curve(x) ((x)*(1-(x))*4)
#endif	io_curve

#ifndef fade_io
#define fade_io(a, x) (io_curve((sceneTime-(a))/(x)))
#endif	fade_io									

class scene2:public Manager
{
	struct GLVector
	{
		GLfloat x;
		GLfloat y;
		GLfloat z;     
	};
	struct TMetaBall
	{
		GLfloat Radius;
		GLfloat x;
		GLfloat y;
		GLfloat z;     
	};

	struct		TGridPoint
	{
		GLVector	Pos;
		GLVector	Normal;
		GLfloat		Value;  
	};

	struct TGridCube
	{
		TGridPoint	*GridPoint[8];
	}; 

	public:
		scene2(double time,float max_meta,float wid,float hei,int choice_entrance);												
		~scene2();												
		virtual void Draw(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init(loadall		*textures);
		virtual void DrawBlur(int times, float inc);
		virtual void ViewOrtho();
		virtual void ViewPerspective();
	
	private:
		scene1		*liquid1;
		GLuint		m_Texture[5];
		TMetaBall	MetaBall[6];
		TGridPoint	Grid[51][51][51];
		TGridCube	Cubes[50][50][50];
		int			GridSize,cx,cy,cz,TessTriangles,i,CubeIndex;
		GLfloat		c,Value,Radius,mu;
		GLVector	vec_help,Pos;
		GLVector	VertList[12];
		GLVector	Norm[12];
		float		waveform2,x,y,z;

		int			CreateCubeTriangles(TGridCube GridCube,int index_helper,float xrot,GLuint blend_colour);
		GLvoid		Interpolate(TGridPoint C1,TGridPoint C2,int i);
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		PFNGLLOCKARRAYSEXTPROC				glLockArraysEXT; 
		PFNGLUNLOCKARRAYSEXTPROC			glUnlockArraysEXT;

		GLfloat vertices[80000];
		GLuint	indices[80000];
		GLfloat normals[80000];
		GLfloat colours[80000];
		GLfloat tex_coords[80000];

		int		indices_count,vertices_count,colours_count,texture_count,direction,multi_texture,choice;

		float	xrot,t,beat_responder,beat_min,beat_max;
		DWORD	ElapsedTime,SceneStart;
		float	meta_number;
		int		scene_switcher;
		Manager		*liquid_prev;
		float		width,height;

		DWORD		timeeffect;
		float		fadeffect;
		int			fade_def;
		int			col;
		GLuint		BlurTexture;
		background	*bg;


};

#endif __LIQUID2_H_
