#include "headers.h"
#include "Misc.h"
#include "liquid16.h"

scene16::scene16(double time,int choice_in,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	choice			= choice_in;
	roll			= 0;

	width						= wid;
	height						= hei;
	scene_switcher				= -1;
}

scene16::~scene16()					
{											
}


void scene16::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	GLfloat vertices[]=
	{	
		-3.5f, -2.5f,  0.0f,
		 3.5f, -2.5f,  0.0f,
		 3.5f,  2.5f,  0.0f,
		-3.5f,  2.5f,  0.0f
	};

	GLfloat tex_coords[]=
	{
		-roll+0.0f, -roll+0.0f,
		-roll+1.0f, -roll+0.0f,
		-roll+1.0f, -roll+1.0f,
		-roll+0.0f, -roll+1.0f
	};

	GLuint		indices[]={0,1,2,3};

	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );

	glVertexPointer ( 3, GL_FLOAT, 0, &vertices );

	gluLookAt(0, 0, 1,     0, 0, 0,     0, 1, 0);
	glBindTexture(GL_TEXTURE_2D,m_Texture[0]);
	glTranslatef(0.0f,0.0f,-60.0f);																		
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);
	if (choice>8)
	{
		glEnable(GL_TEXTURE_GEN_S);															
		glEnable(GL_TEXTURE_GEN_T);
	}
	else
	{
		glDisable(GL_TEXTURE_GEN_S);															
		glDisable(GL_TEXTURE_GEN_T);
	}
	glDisable(GL_TEXTURE_GEN_R);															
	glDisable(GL_TEXTURE_GEN_Q);

	glTexGeni(GL_S, GL_OBJECT_LINEAR, GL_SPHERE_MAP);												
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_SPHERE_MAP);												
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE,  GL_EYE_LINEAR);												
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE,  GL_EYE_LINEAR);

		glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );

	if (scene_switcher>10)
	{
		glActiveTextureARB ( GL_TEXTURE0_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glDisable(GL_DEPTH_TEST);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB ( GL_TEXTURE1_ARB );
		glEnable(GL_BLEND);
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}
	else
	{
		glActiveTextureARB ( GL_TEXTURE0_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_BLEND);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);
		glDisable(GL_DEPTH_TEST);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB ( GL_TEXTURE1_ARB );
		glEnable(GL_BLEND);
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_TEXTURE_GEN_S);																
		glEnable(GL_TEXTURE_GEN_T);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	}

	for (int i=0;i<30;i++)
	{
	glPushMatrix();
		glRotatef(xrot/10+i*2.0f,0.0f,0.0f,1.0f);
		glTranslatef((float)cos(timeeffect/10)*(i/30),(float)sin(timeeffect/10)*(i/30),-15+(i)*(0.6f+(float)pow(beat_responder/40,2))+i);
		glColorPointer  ( 4, GL_FLOAT, 0, &colours );
		glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
		glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
	glPopMatrix();
	}
}

void scene16::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;

	roll+=1+beat_responder/(128*30);																			
	if (roll>1.0f)																						
	{
		roll-=1.0f;																						
	}
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};
	if (beat_min==0 && beat_max==0)
	{
		beat_min=beat_responder;
		beat_max=beat_responder;
	}
	else
	{
		if (beat_min>beat_responder)
			beat_min=beat_responder;
		if (beat_max<beat_responder)
			beat_max=beat_responder;
	}

	float beat_middle=(beat_max-beat_min)/10.0f;
	int col=0;
	if (beat_responder>=0)
		col=1;
	if (beat_responder>1*beat_middle+beat_min)
		col=2;
	if (beat_responder>2*beat_middle+beat_min)
		col=3;
	if (beat_responder>3*beat_middle+beat_min)
		col=4;
	if (beat_responder>4*beat_middle+beat_min)
		col=5;
	if (beat_responder>5*beat_middle+beat_min)
		col=6;
	if (beat_responder>6*beat_middle+beat_min)
		col=7;
	if (beat_responder>7*beat_middle+beat_min)
		col=8;
	if (beat_responder>8*beat_middle+beat_min)
		col=9;
	if (beat_responder>9*beat_middle+beat_min)
		col=0;

	for (i=0;i<16;i=i+4)
		{
			colours[i  ] =colors[col][0];
			colours[i+1] =colors[col][1];
			colours[i+2] =colors[col][2];
			colours[i+3] =i*10.0f/255.0f;
		}
}

bool scene16::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%10;
	scene_switcher=rand()%20;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(5);
		break;
		case 4:
			m_Texture[0]=textures->Bind(7);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(10);
		break;
		case 7:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(11);
		break;
		case 8:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==10)
		multi_texture=0;
		scene_switcher=scene_switcher++;
	if (scene_switcher==20)
		scene_switcher=0;*/
	return true;
}

