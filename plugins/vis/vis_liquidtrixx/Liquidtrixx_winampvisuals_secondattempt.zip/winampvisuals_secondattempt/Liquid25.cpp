#include "headers.h"
#include "Misc.h"
#include "liquid25.h"

scene25::scene25(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,float wid,float hei):Manager(time)					
{
	TextGen			= generatedtextures;
	Meshes			= generatedmeshes;
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	for (int i=0;i<20;i++)
		offset[i]=0.0f;

	width						= wid;
	height						= hei;
}

scene25::~scene25()	
{
}


void scene25::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
		// Setup lighting
	float lightPos[] = {0, 0, 0, 1};
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glEnable(GL_LIGHT0);

	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glActiveTextureARB ( GL_TEXTURE1_ARB );
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );
	glEnable(GL_TEXTURE_2D);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_SPHERE_MAP);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_SPHERE_MAP);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

	glActiveTextureARB ( GL_TEXTURE0_ARB );

	// Setup texture coordinate generation
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);


	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);

	// Some matrix manipulation
	
	glTranslatef(0, 0, -0.5f);
	glPushMatrix();
		glRotatef(xrot, 0, 1, 0);
		glRotatef(xrot, 1, 0, 1);

		glDepthMask(GL_FALSE);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);

		Texture::Enable(false);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

		glColor3f(beat_responder/600, 0.1f+beat_responder/800, 0.2f+beat_responder/900);
		Meshes->m_distsphere->Draw();
	glPopMatrix();

	// Draw the outer distorted sphere
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	Texture::Enable(true);
	glPushMatrix();
		glRotatef(xrot/2, 0, 0, 1);
		glTranslatef(0.0f,0.0f,-0.3f+(float)pow(beat_responder/100,2));
		glRotatef(sceneTime*16.0f, 0, 1, 0);
		glRotatef(sceneTime*13.9f, 1, 0, 1);

		//TextGen->t_re2xt->Bind();
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
		glColor3f(1, 0.7f, 0.2f);
		Meshes->m_weirdsphere->Draw();
	glPopMatrix();

	// Draw the inner distored sphere
	glPushMatrix();
		//glScalef(1.0f+beat_responder/160,1.0f+beat_responder/160,1.0f+beat_responder/160);
		glRotatef(xrot, 0, 1, 0);
		glRotatef(xrot/2, 0, 0, 1);
		glRotatef(xrot*1.2f, 1, 0, 0);
		glRotatef(sceneTime*33.9f, 1, 0, 1);
		//TextGen->t_metal2->Bind();
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
		glColor4f(1, 1, 1,0.5f+beat_responder/255.0f);
		Meshes->m_insidesphere->Draw();
	glPopMatrix();
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);

	glDisable(GL_BLEND);
	glDepthMask(GL_TRUE);

	glDisable(GL_LIGHTING);
}

void scene25::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((float)pow(beat_responder/30,2)+0.1f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene25::Init(loadall		*textures)
{
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glDisableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glDisableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%6;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
	}

	/*multi_texture=multi_texture++;
	if (multi_texture==6)
		multi_texture=0;*/
	return true;
}

