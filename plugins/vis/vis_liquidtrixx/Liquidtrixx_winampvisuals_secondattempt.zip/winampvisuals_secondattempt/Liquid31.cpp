#include "headers.h"
#include "Misc.h"
#include "liquid31.h"

scene31::scene31(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,t3DModel *model,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	= 0;
	scene_switcher	=-1;
	sceneTime		= 0;
	lastTime		= 0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	
	TextGen					= generatedtextures;
	Meshes					= generatedmeshes;
	spin					= 0;
	g_3DModel				= model;

	width						= wid;
	height						= hei;
}

scene31::~scene31()					// Destructor
{
	for(int i = 0; i < g_3DModel->numOfObjects; i++)
	{
		// Free the faces, normals, vertices, and texture coordinates.
		delete [] g_3DModel->pObject[i].pFaces;
		delete [] g_3DModel->pObject[i].pNormals;
		delete [] g_3DModel->pObject[i].pVerts;
		delete [] g_3DModel->pObject[i].pTexVerts;
	}
}


void scene31::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glDisable(GL_LIGHTING);
	glDisable(GL_LIGHT0);
	gluLookAt(		0, 1.5f, -100.0f,		0, 0.5f, 0,			0, 1, 0);
	int   g_ViewMode	  = GL_TRIANGLES;

	for(int i = 0; i < g_3DModel->numOfObjects; i++)
	{
		// Make sure we have valid objects just in case. (size() is in the vector class)
		if(g_3DModel->pObject.size() <= 0) break;

		// Get the current object that we are displaying
		t3DObject *pObject = &g_3DModel->pObject[i];
			
		// Check to see if this object has a texture map, if so bind the texture to it.
		if(pObject->bHasTexture) {

			// Turn on texture mapping and turn off color
			glEnable(GL_TEXTURE_2D);

			// Reset the color to normal again
			glColor3ub(255, 255, 255);

			// Bind the texture map to the object by it's materialID
				glActiveTextureARB ( GL_TEXTURE0_ARB ); 
				glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
				glEnable(GL_TEXTURE_2D);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glEnable(GL_BLEND);
				glDisable(GL_DEPTH_TEST);
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

				glActiveTextureARB ( GL_TEXTURE1_ARB ); 
				glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
				glEnable(GL_TEXTURE_2D);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glEnable(GL_BLEND);
				glDisable(GL_DEPTH_TEST);
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
			//glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
		} else {

			// Turn off texture mapping and turn on color
			if (scene_switcher >8)
			{
				glActiveTextureARB ( GL_TEXTURE0_ARB ); 
				glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
				glEnable(GL_TEXTURE_2D);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glEnable(GL_BLEND);
				glDisable(GL_DEPTH_TEST);
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

				glActiveTextureARB ( GL_TEXTURE1_ARB ); 
				glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
				glEnable(GL_TEXTURE_2D);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glEnable(GL_BLEND);
				glDisable(GL_DEPTH_TEST);
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
				glEnable(GL_TEXTURE_2D);
			}
			else
			{
				glActiveTextureARB ( GL_TEXTURE0_ARB ); 
				glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
				glEnable(GL_TEXTURE_2D);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glEnable(GL_BLEND);
				glDisable(GL_DEPTH_TEST);
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

				glActiveTextureARB ( GL_TEXTURE1_ARB ); 
				glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
				glEnable(GL_TEXTURE_2D);
				glEnable(GL_TEXTURE_GEN_S);																
				glEnable(GL_TEXTURE_GEN_T);
				glEnable(GL_BLEND);
				glDisable(GL_DEPTH_TEST);
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
				glEnable(GL_TEXTURE_2D);
			}

			// Reset the color to normal again
			glColor4ub(255, 255, 255,120);
		}

		// This determines if we are in wireframe or normal mode
		glRotatef(xrot/3,0.0f,0.0f,1.0f);
		glRotatef(xrot/2+1.0f,0.0f,1.0f,0.0f);
		glRotatef(xrot+3.0f,1.0f,0.0f,0.0f);
		glPushMatrix();
		for (int i=0;i<10;i++)
		{
			
			//glTranslatef(0.0f,0.0f,beat_responder/20);
			glScalef(1.0f+beat_responder/200*i,1.0f+beat_responder/200*i,1.0f+beat_responder/200*i);
			glBegin(GL_TRIANGLES);					// Begin drawing with our selected mode (triangles or lines)

			// Go through all of the faces (polygons) of the object and draw them
			for(int j = 0; j < pObject->numOfFaces; j++)
			{
				// Go through each corner of the triangle and draw it.
				for(int whichVertex = 0; whichVertex < 3; whichVertex++)
				{
					// Get the index for each point of the face
					int index = pObject->pFaces[j].vertIndex[whichVertex];
			
					// Give OpenGL the normal for this vertex.
					glNormal3f(pObject->pNormals[ index ].x, pObject->pNormals[ index ].y, pObject->pNormals[ index ].z);
				
					// If the object has a texture associated with it, give it a texture coordinate.
					if(pObject->bHasTexture) {

						// Make sure there was a UVW map applied to the object or else it won't have tex coords.
						if(pObject->pTexVerts) {
							glTexCoord2f(pObject->pTexVerts[ index ].x, pObject->pTexVerts[ index ].y);
						}
					} else {

						// Make sure there is a valid material/color assigned to this object.
						// You should always at least assign a material color to an object, 
						// but just in case we want to check the size of the material list.
						// if the size is at least one, and the material ID != -1,
						// then we have a valid material.
						if(g_3DModel->pMaterials.size() && pObject->materialID >= 0) 
						{
							// Get and set the color that the object is, since it must not have a texture
							BYTE *pColor = g_3DModel->pMaterials[pObject->materialID].color;

							// Assign the current color to this model
							//glColor3ub(pColor[0], pColor[1], pColor[2]);
							glColor3ub(255,255,0);
						}
					}

					// Pass in the current vertex of the object (Corner of current face)
					glVertex3f(pObject->pVerts[ index ].x, pObject->pVerts[ index ].y, pObject->pVerts[ index ].z);
				}
			}

		glEnd();								// End the drawing
		
		}
		glPopMatrix();
	}		
}

void scene31::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;
}

bool scene31::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;

	glEnable(GL_LIGHT0);								// Turn on a light with defaults set
	glEnable(GL_LIGHTING);								// Turn on lighting
	glEnable(GL_COLOR_MATERIAL);						// Allow color

	multi_texture=rand()%8;
	scene_switcher=rand()%17;
	
	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(9);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(3);
		break;
		case 2:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(4);
		break;
		case 3:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(1);
		break;
		case 4:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(3);
		break;
		case 6:
			m_Texture[0]=textures->Bind(9);
			m_Texture[1]=textures->Bind(8);
		break;
		case 7:
			m_Texture[0]=textures->Bind(8);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==8)
		multi_texture=0;
	scene_switcher=scene_switcher++;
	if (scene_switcher==17)
		scene_switcher=0;*/
	return true;
}

float scene31::semirand(int x)
{
	x = (x<<13) ^ x;
	return ( 1.0f - ( (x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f); 
}
void scene31::drawline(const vec *points, int numPoints, float width, const vec &campos,float beat_help)
{
	vec lookat = campos - points[0];
	vec dir = points[1] - points[0];	
	
	vec x, tmp;
	
	glBegin(GL_QUADS);
		for(int a = 0; a < numPoints-1; a++)
		{
			x = lookat*dir;
			x.Normalize();
			
			tmp = points[a] + x * width;
			glTexCoord2f(0, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);				
			
			tmp = points[a] - x * width;
			glTexCoord2f(1, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			lookat = campos - points[a+1];
			dir = points[a+1] - points[a];
			x = lookat * dir;
			x.Normalize();
			
			tmp = points[a+1] - x*width;
			glTexCoord2f(1, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			tmp = points[a+1] + x*width;
			glTexCoord2f(0, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);			
		}
	glEnd();
}

float scene31::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);

}

