#ifndef __SCENE_MANAGER_H
#define __SCENE_MANAGER_H

#define MAX_CALLS			20

#include "LoadAlltextures.h"
#include "vis.h"

class Manager
{
	public:
		Manager(double time);
		
		virtual void		addNext(Manager *next);
		virtual void		add_Next_Prev(Manager *next,Manager *prev);

		virtual void		start();
		virtual bool		isComplete();
		virtual Manager		*getNext();
		virtual Manager		*getPrev();

		virtual void		Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual void		Draw(GLuint blend_colour,struct winampVisModule *this_mod)=0;
		virtual bool		Init(loadall *textures)=0;
		Manager				*m_pNext;
		Manager				*m_pPrev;

	private:
		

	protected:

		double				m_dSceneLength;
		double				m_dSceneTime;

		void				setTime(int index, double time);
			
		double				m_dTime[MAX_CALLS];
		bool				m_bExecuting[MAX_CALLS];
		bool				m_bSwitched[MAX_CALLS];
		bool				m_bStaySwitched[MAX_CALLS];
		GLuint				SceneStart;
};

#endif
