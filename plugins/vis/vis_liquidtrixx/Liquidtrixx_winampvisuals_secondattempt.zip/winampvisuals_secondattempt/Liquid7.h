#ifndef __LIQUID7_H_
#define __LIQUID7_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "cube.h"
#include "Background.h"

class scene7:public Manager
{

	public:
		scene7(double time,float wid,float hei);												
		~scene7();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		GLuint		m_Texture[5];										
		cube		*liquid_cube;
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		int			scenechanger;

		float		width,height;
};

#endif __LIQUID7_H_
