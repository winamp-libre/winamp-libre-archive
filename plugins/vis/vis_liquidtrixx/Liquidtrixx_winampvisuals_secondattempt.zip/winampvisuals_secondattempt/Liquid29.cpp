#include "headers.h"
#include "Misc.h"
#include "liquid29.h"

scene29::scene29(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,float wid,float hei):Manager(time)					
{
	TextGen			= generatedtextures;
	Meshes			= generatedmeshes;
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	for (int i=0;i<20;i++)
		offset[i]=0.0f;
	scene_switcher=-1;
	roll=0;
	roll2=0;

	width						= wid;
	height						= hei;
	GLfloat vertices_help[] =	{	
									-1.0, -1.0, 1.0,        
									1.0, -1.0, 1.0,
									1.0, 1.0, 1.0,
									-1.0, 1.0, 1.0,
							
									-1.0, -1.0, -1.0,
									-1.0,  1.0, -1.0,
									1.0,  1.0, -1.0,
									1.0, -1.0, -1.0,
	
									-1.0,  1.0, -1.0,
									-1.0,  1.0,  1.0,
									1.0,  1.0,  1.0,
									1.0,  1.0, -1.0,
	
									-1.0, -1.0, -1.0,
									1.0, -1.0, -1.0,
									1.0, -1.0,  1.0,
									-1.0, -1.0,  1.0,
													
									1.0, -1.0, -1.0,
									1.0,  1.0, -1.0,
									1.0,  1.0,  1.0,
									1.0, -1.0,  1.0,
	
									-1.0, -1.0, -1.0,
									-1.0, -1.0,  1.0,
									-1.0,  1.0,  1.0,
									-1.0,  1.0, -1.0
								};

	GLfloat normals_help[]=		{		
									0.0, 0.0, 0.5,
									0.0, 0.0, 0.5,
									0.0, 0.0, 0.5,
									0.0, 0.0, 0.5,

									0.0, 0.0, -0.5,
									0.0, 0.0, -0.5,
									0.0, 0.0, -0.5,
									0.0, 0.0, -0.5,

									0.0, 0.5, 0.0,
									0.0, 0.5, 0.0,
									0.0, 0.5, 0.0,
									0.0, 0.5, 0.0,

									0.0,-0.5, 0.0,
									0.0,-0.5, 0.0,
									0.0,-0.5, 0.0,
									0.0,-0.5, 0.0,

									0.5, 0.0, 0.0,
									0.5, 0.0, 0.0,
									0.5, 0.0, 0.0,
									0.5, 0.0, 0.0,

									-0.5, 0.0, 0.0,
									-0.5, 0.0, 0.0,
									-0.5, 0.0, 0.0,
									-0.5, 0.0, 0.0
								};

	float blend_colour			= 0.6f ;


	GLfloat colours_help[]		=	{	
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,

										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,

										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,

										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,

										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,

										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour,
										1.0f, 1.0f, 1.0f,	blend_colour
									};

	for (int i=0;i<72;i++)
	{
		vertices[i]=vertices_help[i];
		normals[i]=normals_help[i];
	}

	for (int k=0;k<96;k++)
	{
		colours[k]=colours_help[k];
	}
	for (int i=0;i<24;i++)
		indices[i]=i;
	
}

scene29::~scene29()	
{
}


void scene29::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{

	GLuint	fogMode[]	= { GL_EXP, GL_EXP2, GL_LINEAR };
	GLfloat fogColor[4]	= {0,0,1.0f,0.1f}; 
	/*
		glFogf(GL_FOG_START, -120.0f-beat_responder/20);
		glFogf(GL_FOG_END, -110.0f+beat_responder/20);
		glFogi(GL_FOG_MODE, GL_LINEAR);								
		glFogi(GL_FOG_MODE, fogMode[0]);						
		glFogfv(GL_FOG_COLOR, fogColor);						
		glFogf(GL_FOG_DENSITY, 0.03f);
		glEnable(GL_FOG);
	*/
	glAlphaFunc(GL_GREATER,0.3f);
    glDisable(GL_ALPHA_TEST);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glEnable(GL_LIGHT0);                             
	glEnable(GL_LIGHTING);

	gluLookAt(0, 0, 1,     0, 0, 0,     0, 1, 0);
	glTranslatef(0.0f,0.0f,-80.0f);																	
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_BLEND);

	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

	glActiveTextureARB ( GL_TEXTURE1_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);

	glActiveTextureARB ( GL_TEXTURE0_ARB );

	glDisable(GL_DEPTH_TEST);
	glDisable(GL_TEXTURE_GEN_R);															
	glDisable(GL_TEXTURE_GEN_Q);

	glColor4ub(255,255,255,60);

	GLfloat tex_coords[] = {    
								-roll2+0.0f, -roll2+0.0f
                                -roll2+1.0f, -roll2+0.0f,
								-roll2+1.0f, -roll2+1.0f,
								-roll2+0.0f, -roll2+1.0f

								-roll2+0.0f, -roll2+0.0f
                                -roll2+1.0f, -roll2+0.0f,
								-roll2+1.0f, -roll2+1.0f,
								-roll2+0.0f, -roll2+1.0f

								-roll2+0.0f, -roll2+0.0f
                                -roll2+1.0f, -roll2+0.0f,
								-roll2+1.0f, -roll2+1.0f,
								-roll2+0.0f, -roll2+1.0f

								-roll2+0.0f, -roll2+0.0f
                                -roll2+1.0f, -roll2+0.0f,
								-roll2+1.0f, -roll2+1.0f,
								-roll2+0.0f, -roll2+1.0f

								-roll2+0.0f, -roll2+0.0f
                                -roll2+1.0f, -roll2+0.0f,
								-roll2+1.0f, -roll2+1.0f,
								-roll2+0.0f, -roll2+1.0f

								-roll2+0.0f, -roll2+0.0f
                                -roll2+1.0f, -roll2+0.0f,
								-roll2+1.0f, -roll2+1.0f,
								-roll2+0.0f, -roll2+1.0f
							};


	float roll2=0.0f;
	for (int i=1;i<20;i++)
	{
		glPushMatrix();
			float Temp	=(i*0.2f) / 4.0f;
			float XSize	=1.0f + 0.5f*(float)cos(Temp);
			float YSize	=1.0f + 0.5f*(float)cos(0.8*Temp);
			float Angle	=180.0f + 180.0f*(float)sin((Temp-i)/15.0f);
			float XPos	=0.3f*(float)sin(Temp/8);
			float YPos	=0.6f*(float)cos(Temp/4);

			
			glRotatef(xrot+i*3,0.0f,0.0f,1.0f);
			glTranslatef(XPos*i*(1+beat_responder/150),YPos*(1+i*beat_responder/150),2.0f+i*beat_responder/15);
			glColor4ub((int)(120+beat_responder),(int)(beat_responder*2.0),(int)(beat_responder*i/15),180);
			glTranslatef(i*beat_responder/100,i*beat_responder/100,(2*i/10)+beat_responder/30);
		glPushMatrix();
			glScalef(1.0f+beat_responder/10+i*roll/40,1.0f+beat_responder/30+i*roll/20,1.0f);
			glEnableClientState				(	GL_VERTEX_ARRAY							);
			glEnableClientState				(	GL_NORMAL_ARRAY							);
			glClientActiveTextureARB		(	GL_TEXTURE0_ARB							); 
			glTexCoordPointer				(	2, GL_FLOAT, 0, &tex_coords				); 
			glClientActiveTextureARB		(	GL_TEXTURE1_ARB							);  
			glTexCoordPointer				(	2, GL_FLOAT, 0, &tex_coords				);
			glDisableClientState				(	GL_COLOR_ARRAY							);
			glVertexPointer					(	3, GL_FLOAT, 0,			&vertices		);
			glColorPointer					(	4, GL_FLOAT, 0,		&colours	);
			glNormalPointer					(	GL_FLOAT, 0, &normals					);
			glDrawElements					(	GL_QUADS, 24, GL_UNSIGNED_INT, &indices );
		glPopMatrix();
	}
	roll+=beat_responder/(128/5);
	roll2+=beat_responder/(128*10);	
	// Increase Our Texture Roll Variable
	if (roll>1.0f)																					// Is Roll Greater Than One
	{
		roll-=1.0f;																					// Subtract 1 From Roll
	}
	glDisable(GL_ALPHA_TEST);
	//glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	//glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );
	//glEnable(GL_TEXTURE_2D);
	//glEnable(GL_TEXTURE_GEN_S);																
	//glEnable(GL_TEXTURE_GEN_T);
	//glEnable(GL_BLEND);
	//glDisable(GL_DEPTH_TEST);
	//glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	//glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	//glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND );

	//glActiveTextureARB ( GL_TEXTURE1_ARB ); 
	//glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
	//glEnable(GL_TEXTURE_2D);
	//glEnable(GL_TEXTURE_GEN_S);																
	//glEnable(GL_TEXTURE_GEN_T);
	//glEnable(GL_BLEND);
	//glDisable(GL_DEPTH_TEST);
	//glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);	
	//glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
	//glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	//bg->DrawWaving(beat_responder/10*(float)cos(timeeffect/1000.0f));
}

void scene29::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((float)pow(beat_responder/30,2)+0.1f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene29::Init(loadall		*textures)
{
	roll=0;
	timeeffect		= 0;
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glDisableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glDisableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;
	sceneTime		= 0;
	lastTime		= 0;

	multi_texture=rand()%18;
	scene_switcher=rand()%36;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
		case 6:
			m_Texture[0]=textures->Bind(10);
			m_Texture[1]=textures->Bind(11);
		break;
		case 7:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(13);
		break;
		case 8:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(12);
		break;
		case 9:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(4);
		break;
		case 10:
			m_Texture[0]=textures->Bind(7);
			m_Texture[1]=textures->Bind(14);
		break;
		case 11:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(15);
		break;
		case 12:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(16);
		break;
		case 13:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(17);
		break;
		case 14:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(18);
		break;
		case 15:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(19);
		break;
		case 16:
			m_Texture[0]=textures->Bind(20);
			m_Texture[1]=textures->Bind(17);
		break;
		case 17:
			m_Texture[0]=textures->Bind(21);
			m_Texture[1]=textures->Bind(15);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==18)
		multi_texture=0;
	scene_switcher=scene_switcher++;
	if (scene_switcher==36)
		scene_switcher=0;*/
	return true;
}

void scene29::drawline(const vec *points, int numPoints, float width, const vec &campos,float beat_help)
{
	vec lookat = campos - points[0];
	vec dir = points[1] - points[0];	
	
	vec x, tmp;
	
	glBegin(GL_QUADS);
		for(int a = 0; a < numPoints-1; a++)
		{
			x = lookat*dir;
			x.Normalize();
			
			tmp = points[a] + x * width;
			glTexCoord2f(0, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);				
			
			tmp = points[a] - x * width;
			glTexCoord2f(1, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			lookat = campos - points[a+1];
			dir = points[a+1] - points[a];
			x = lookat * dir;
			x.Normalize();
			
			tmp = points[a+1] - x*width;
			glTexCoord2f(1, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			tmp = points[a+1] + x*width;
			glTexCoord2f(0, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);			
		}
	glEnd();
}

float scene29::semirand(int x)
{
	x = (x<<13) ^ x;
	return ( 1.0f - ( (x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f); 
}

float scene29::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);

}

