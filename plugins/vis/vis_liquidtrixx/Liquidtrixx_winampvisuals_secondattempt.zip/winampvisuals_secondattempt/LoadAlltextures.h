#ifndef __LOADALL_H_
#define __LOADALL_H_

#include "TextureLoader.h"
#include "vis.h"

class loadall
{
	public:
		loadall(struct winampVisModule *this_mod);													
		~loadall();	
		GLuint EmptyTexture();
		GLuint Bind(int number);
	private:
		GLuint	m_Texture[25];
		void	getfilename(LPSTR strFileName,struct winampVisModule *this_mod,int id);
};	

#endif __LOADALL_H_
