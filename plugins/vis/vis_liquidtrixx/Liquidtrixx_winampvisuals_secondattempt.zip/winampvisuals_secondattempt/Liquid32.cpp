#include "headers.h"
#include "Misc.h"
#include <cmath>
#include "liquid32.h"
//#include "cues.h"

#define PI 3.14159265358979323846

scene32::scene32(double time,float wid,float hei):Manager(time) 
{
	sphere = gluNewQuadric();
	gluQuadricOrientation(sphere, GLU_OUTSIDE);
	gluQuadricNormals(sphere, GLU_SMOOTH);
	gluQuadricTexture(sphere,GL_TRUE);

	makeDLs();

	theta = 0.0;
	phi = 0.0;
	omega = 0.0;
	gamma = 0.0;
	xCam = 0.0;
	yCam = 0.0;
	zCam = 7.0;
	xLook = 0.0;
	yLook = 0.0;
	zLook = 0.0;
	//trans = 0.0;
	trans = 1.5;
	whiteout = 1.0;
	fade = in;
	spin = fast;
	//beat = false;
	beat= true;
	shift = false;
	move = false;
	rotate = false;
	recombine = false;

	matAmb[0] = 0.35f; 
	matAmb[1] = 0.3f;
	matAmb[2] = 0.2f; 
	matAmb[3] = 0.4f;

	matDif[0] = 0.75f; 
	matDif[1] = 0.7f; 
	matDif[2] = 0.4f; 
	matDif[3] = 0.5f;

	matSpe[0] = 0.55f; 
	matSpe[1] = 0.5f; 
	matSpe[2] = 0.4f; 
	matSpe[3] = 0.3f;

	matEmi[0] = 0.0f; 
	matEmi[1] = 0.0f; 
	matEmi[2] = 0.0f; 
	matEmi[3] = 0.0f;

	matShi[0] = 50.0f;

	lightPos[0] = 0.0f; lightPos[1] = 0.0f; lightPos[2] = 0.0f; lightPos[3] = 1.0f;
	lightAmb[0] = 0.3f; lightAmb[1] = 0.3f; lightAmb[2] = 0.3f; lightAmb[3] = 1.0f;
	lightDif[0] = 0.8f; lightDif[1] = 0.8f; lightDif[2] = 0.8f; lightDif[3] = 1.0f;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	timeeffect		= 0;
	multi_texture	= 0;
	scene_switcher	=-1;
	sceneTime		= 0;
	lastTime		= 0;

	tick1 = GetTickCount();
	tick2 = GetTickCount();
	dTick = (float)((tick2 - tick1) / 30.0);

	width						= wid;
	height						= hei;
}

scene32::~scene32() {
	gluDeleteQuadric(sphere);
	glDeleteLists(1, dlSmallSphere);
	glDeleteLists(1, dlBigCube);
	glDeleteLists(1, dlFader);
	glDeleteLists(1, dlBack);
}

void scene32::Update(float beat_help,short* pcm,float beat_scaler,bool Tex_on)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHT0);
	glDisable(GL_LIGHTING);
	glDisable(GL_NORMALIZE);
	glDisable(GL_CULL_FACE);
	
	glShadeModel(GL_SMOOTH);

	glMaterialfv	(GL_FRONT, GL_AMBIENT,		matAmb);
	glMaterialfv	(GL_FRONT, GL_DIFFUSE,		matDif);
	glMaterialfv	(GL_FRONT, GL_SPECULAR,		matSpe);
	glMaterialfv	(GL_FRONT, GL_SHININESS,	matShi);
	glMaterialfv	(GL_FRONT, GL_EMISSION,		matEmi);

	glLightfv		(GL_LIGHT0, GL_AMBIENT,		lightAmb);
	glLightfv		(GL_LIGHT0, GL_SPECULAR,	lightDif);



	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;

	tick1 = tick2;
	tick2 = GetTickCount();
	dTick = (float)((tick2 - tick1) / 30.0);
}

void scene32::animate() 
{
	if(fade == in) {
		if(whiteout - dTick*0.1 > 0.0)
			whiteout -= dTick*0.1f;
		else {
			whiteout = 0.0;
			fade = none;
		}
	}
	else if(fade == out) {
		if(whiteout + dTick*0.008 < 1.0)
			whiteout += dTick*0.008f;
		else {
			whiteout = 1.0f;
		}
	}

	if(beat_responder>40) {
		if(trans - dTick*0.5 > 0.0)
			trans -= dTick * 0.3f;
		else {
			trans = 0.0;
			beat = false;
		}
	}

	if(spin == fast) 
		theta += 3.0f * dTick;
	else if(spin == slow) 
		theta += 0.5f * dTick;
	if(theta > 360.0)
			theta -= 360.0;

	if(shift) {
		phi += 0.01f * dTick;
		if(phi > 360.0)
			phi -= 360.0;
	}

	if(rotate) {
		if(omega + 0.75 * dTick > 360.0) {
			if(recombine) {
				omega = 0.0;
				rotate = false;
			}
			else {
				omega += 0.75f * dTick;
				omega -= 360.0;
			}
		}
		else
			omega += 0.75f * dTick;

	}

	if(move) {
		if(gamma + 5.0 * dTick > 360.0) {	
			if(recombine) {
				gamma = 0.0;
				move = false;
			}
			else {
				gamma += 5.0f * dTick;	
				gamma -= 360.0f;
			}
		}
		else
			gamma += 5.0f * dTick;
	}

}

void scene32::switcher(unsigned char command) 
{
	switch(command) {
	case CUBE_BEAT:
		beat = true;
		trans = 1.5;
		break;

	case CUBE_SHIFT:
		spin = slow;
		shift = true;
		glEnable(GL_COLOR_MATERIAL);
		glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT);
		glColor4f(0.3f, 0.3f, 0.3f, 0.5f);
		glColorMaterial(GL_FRONT_AND_BACK, GL_SPECULAR);
		glColor4f(1.0f, 1.0f, 1.0f, 0.5f);
		break;

	case CUBE_ROTATE:
		rotate = true;
		break;

	case CUBE_MOVE:
		move = true;
		break;

	case CUBE_FAST:
		spin = fast;
		break;

	case CUBE_RECOMBINE:
		recombine = true;
		break;

	case SCENE_FADEOUT:
		fade = out;
		whiteout = 0.0;
		break;
	}
}
void scene32::Draw(GLuint blend_colour,short* pcm)
{
	switch (scene_switcher)
	{
		case 1:
			switcher(CUBE_BEAT);
		break;
		case 2:
			switcher(CUBE_SHIFT);
		break;
		case 3:
			switcher(CUBE_ROTATE);
		break;
		case 4:
			switcher(CUBE_MOVE);
		break;
		case 5:
			switcher(CUBE_FAST);
		break;
		case 6:
			switcher(CUBE_RECOMBINE);
		break;
	}
	animate();
	glPushMatrix();
		gluLookAt(xCam, yCam, 2*zCam-pow(beat_responder/30,2), xLook, yLook, zLook, 0.0, 1.0, 0.0);
		glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
		
		/*glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_Texture[1]);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);*/

	glActiveTextureARB		( GL_TEXTURE0_ARB ); 
	glEnable(GL_TEXTURE_2D);
	glBindTexture			( GL_TEXTURE_2D, m_Texture[1] ); 
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);		
	glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);					
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);	 
	glTexGeni(GL_T, GL_EYE_PLANE, GL_EYE_LINEAR);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND );
	
	glActiveTextureARB		( GL_TEXTURE1_ARB ); 
	glEnable(GL_TEXTURE_2D);
	glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
	glHint(GL_PERSPECTIVE_CORRECTION_HINT,GL_NICEST);		
	glHint(GL_POINT_SMOOTH_HINT,GL_NICEST);					
	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);	 
	glTexGeni(GL_T, GL_EYE_PLANE, GL_EYE_LINEAR);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		
		glPushMatrix();
			glTranslatef(0.0, 0.0, -20.0);
			glCallList(dlBack);
		glPopMatrix();

		if(shift) {
			glColorMaterial(GL_FRONT_AND_BACK, GL_DIFFUSE);
			glColor4f((float)cos(phi), 0.5f*(float)sin(phi), -(float)sin(phi), 0.5f);
		}

		glPushMatrix();
			glTranslatef(0.0f, 0.0f, trans);
			glRotatef(theta, 2.0f, 1.0f, 0.5f);
			
			glPushMatrix();
				glTranslatef(1.3f, 1.3f, 1.3f);
				glRotatef(omega, 0.0f, 1.0f, 1.0f);
				glTranslatef((float)sin(gamma*PI/180.0), (float)sin(gamma*PI/180.0), 2*(float)sin(gamma*PI/180.0));
				glCallList(dlBigCube);
			glPopMatrix();

			glPushMatrix();
				glTranslatef(-1.3f, 1.3f, 1.3f);
				glRotatef(omega, 0.0f, 1.0f, 1.0f);
				glTranslatef((float)sin(gamma*PI/180.0), -(float)sin(gamma*PI/180.0), 2*(float)sin(gamma*PI/180.0));
				glCallList(dlBigCube);
			glPopMatrix();

			glPushMatrix();
				glTranslatef(-1.3f, 1.3f, -1.3f);
				glRotatef(omega, 0.0f, 1.0f, 1.0f);
				glTranslatef(-(float)sin(gamma*PI/180.0), (float)sin(gamma*PI/180.0), 2*(float)sin(gamma*PI/180.0));
				glCallList(dlBigCube);
			glPopMatrix();

			glPushMatrix();
				glTranslatef(1.3f, 1.3f, -1.3f);
				glRotatef(omega, 0.0f, 1.0f, 1.0f);
				glTranslatef(-(float)sin(gamma*PI/180.0), -(float)sin(gamma*PI/180.0), 2*(float)sin(gamma*PI/180.0));
				glCallList(dlBigCube);
			glPopMatrix();

			glPushMatrix();
				glTranslatef(1.3f, -1.3f, 1.3f);
				glRotatef(omega, 0.0f, 1.0f, 1.0f);
				glTranslatef((float)sin(gamma*PI/180.0), (float)sin(gamma*PI/180.0), -2*(float)sin(gamma*PI/180.0));
				glCallList(dlBigCube);
			glPopMatrix();

			glPushMatrix();
				glTranslatef(-1.3f, -1.3f, 1.3f);
				glRotatef(omega, 0.0f, 1.0f, 1.0f);
				glTranslatef((float)sin(gamma*PI/180.0), -(float)sin(gamma*PI/180.0), -2*(float)sin(gamma*PI/180.0));
				glCallList(dlBigCube);
			glPopMatrix();

			glPushMatrix();
				glTranslatef(-1.3f, -1.3f, -1.3f);
				glRotatef(omega, 0.0f, 1.0f, 1.0f);
				glTranslatef(-(float)sin(gamma*PI/180.0), (float)sin(gamma*PI/180.0), -2*(float)sin(gamma*PI/180.0));
				glCallList(dlBigCube);
			glPopMatrix();

			glPushMatrix();
				glTranslatef(1.3f, -1.3f, -1.3f);
				glRotatef(omega, 0.0f, 1.0f, 1.0f);
				glTranslatef(-(float)sin(gamma*PI/180.0), -(float)sin(gamma*PI/180.0), -2*(float)sin(gamma*PI/180.0));
				glCallList(dlBigCube);
			glPopMatrix();
		glPopMatrix();

		if(fade == in || fade == out) {
			glPushMatrix();
				glTranslatef(xCam, yCam, zCam-0.2f);

				if(fade == in)
					glColor4f(1.0f, 1.0f, 1.0f, whiteout);
				else
					glColor4f(0.0f, 0.0f, 0.0f, whiteout);
				glCallList(dlFader);	
			glPopMatrix();
		}
	glPopMatrix();
}

bool scene32::Init(loadall		*textures)
{
	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glDisableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glDisableClientState       ( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;
	
	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(3);
		break;
		case 1:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(1);
		break;
		case 2:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(5);
		break;
		case 3:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(1);
		break;
		case 4:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(3);
		break;
		case 6:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(22);
		break;
		case 7:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(1);
		break;
	}
	multi_texture=multi_texture++;
	if (multi_texture==8)
		multi_texture=0;
	scene_switcher=scene_switcher++;
	if (scene_switcher==7)
		scene_switcher=0;
	return true;
}

float scene32::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);
}

void scene32::makeDLs() {
	GLfloat x, y, z;

	dlSmallSphere = glGenLists(1);
	glNewList(dlSmallSphere, GL_COMPILE);
	glPushMatrix();
		glEnable(GL_LIGHTING);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
		glDepthMask(GL_FALSE);
		gluSphere(sphere, 0.2, 6, 6);
		glDepthMask(GL_TRUE);
		glDisable(GL_BLEND);
		glDisable(GL_LIGHTING);
	glPopMatrix();
	glEndList();

	dlBigCube = glGenLists(1);
	glNewList(dlBigCube, GL_COMPILE);
	for(z = -1.0; z <= 1.0; z += 0.5) {
		for(y = -1.0; y <= 1.0; y += 0.5) {
			for(x = -1.0; x <= 1.0; x += 0.5) {
				glPushMatrix();
					glTranslatef(x, y, z);
					glCallList(dlSmallSphere);
				glPopMatrix();
			}
		}
	}
	glEndList();

	dlFader = glGenLists(1);
	glNewList(dlFader, GL_COMPILE);
	glPushMatrix();
		glEnable(GL_BLEND);	
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture(GL_TEXTURE_2D, 0);
		glBegin(GL_QUADS);
			glVertex3f(500.0, 500.0, 0.0);
			glVertex3f(-500.0, 500.0, 0.0);
			glVertex3f(-500.0, -500.0, 0.0);
			glVertex3f(500.0, -500.0, 0.0);
		glEnd();
		glDisable(GL_BLEND);
	glPopMatrix();
	glEndList();

	dlBack = glGenLists(1);
	glNewList(dlBack, GL_COMPILE);
	glPushMatrix();
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, m_Texture[1]);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
		glScalef(30.0, 20.0, 0.0);
		glBegin(GL_QUADS);
			glTexCoord2d(1.0, 1.0); glVertex3f(1.0, 1.0, 0.0);
			glTexCoord2d(0.0, 1.0); glVertex3f(-1.0, 1.0, 0.0);
			glTexCoord2d(0.0, 0.0); glVertex3f(-1.0, -1.0, 0.0);
			glTexCoord2d(1.0, 0.0); glVertex3f(1.0, -1.0, 0.0);
		glEnd();
		glEnable(GL_TEXTURE_2D);
	glPopMatrix();
	glEndList();
}