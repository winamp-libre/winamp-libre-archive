#ifndef HELPERFUNCS_H
#define HELPERFUNCS_H

#include "HEADERS.H"

#define PI 3.14159

void				initHelperFuncs();

void				setExit();

#endif

