#include "headers.h"
#include "Misc.h"
#include "liquid13.h"

scene13::scene13(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,float wid,float hei):Manager(time)					
{
	TextGen			= generatedtextures;
	Meshes			= generatedmeshes;
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	col = 0;
	ret	= 0;

	width						= wid;
	height						= hei;
}

scene13::~scene13()					
{
}


void scene13::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{	
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);

	float lightPos[] = {0, 0, 0, 1};
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glDisable(GL_LIGHT0);

	vec campos;
	campos.x = sinf(sceneTime*0.21f)*5;
	campos.y = cosf(sceneTime*0.31f)*5;
	campos.z = -20 + sinf(sceneTime*1.01f+2)*4+beat_responder/30;

	gluLookAt(campos.x, campos.y, campos.z, 0, 0, 0, 0, 1, 0);
	
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);

	glDisable(GL_LIGHTING);

	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	
	glDepthMask(GL_FALSE);
	
 
	
	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );
	glEnable(GL_TEXTURE_2D);
	//TextGen->t_refl->Bind();
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	glActiveTextureARB ( GL_TEXTURE1_ARB );
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND );
	glDisable(GL_TEXTURE_2D);
	glActiveTextureARB ( GL_TEXTURE0_ARB );

	// Setup texture coordinate generation

	

	glColor4f(0.3f+beat_responder/150, beat_responder/200, 0.7f*beat_responder/200,0.3f);
	
	sceneTime *= 2;
	vec line[100];
	
	GLuint linelist;
	linelist = glGenLists(1);
	glNewList(linelist,GL_COMPILE);
			
	for(int b = 1; b < 3; b++)
	{
		int c=0;
		for(int a = 0; a < 50; a++)
		{
			float time_sound=(float)cos(a*0.2f+sceneTime*4*semirand(b));
			line[c].x = a*0.1f*((-1+time_sound)/2)-b*2;
			line[c].y = sinf(a*0.2f+sceneTime*4*semirand(b))+beat_responder/5*time_sound + sinf(a*0.5f)*0.05f;
			line[c].z = sinf(a*0.1f+sceneTime*3*semirand(b))*beat_responder/5*time_sound;
			c++;
		}

		drawline(line, 50, 0.2f, campos,beat_responder);
	}
	
	glEndList();

	glTranslatef(6*(float)cos(sceneTime*(beat_responder/400+1.0f)*semirand(b)),0.0f,-6*(float)cos(sceneTime*semirand(b)+beat_responder/400));
	glPushMatrix();
		glRotatef(xrot,0.0f,0.0f,1.0f);
		float r=3.0f+beat_responder/5.0f*(float)pow(cos(sceneTime/20),2);
		for (int j=0;j<15;j++)
		{
			glRotatef(45,1.0f,1.0f,0.0f);
			for (int i=1;i<9;i++)
			{
				glRotatef(45,0.0f,0.0f,1.0f);
				glPushMatrix();
					glTranslatef(r*(float)pow(cos(sceneTime/20),2),r*(float)pow(sin(sceneTime),2),(float)i);
					glCallList(linelist);
				glPopMatrix();
			}
		}
	glPopMatrix();
	glDeleteLists(linelist,1);

	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);

	glColor4f(1, 1, 1.0f ,0.6f);

	glTranslatef(0, 0, 0);
	glDisable(GL_LIGHTING);

	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	//glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
	TextGen->t_metal2->Bind();
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glActiveTextureARB ( GL_TEXTURE1_ARB ); 
	//glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
	TextGen->t_refl->Bind();
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	for (int i=0;i<6;i++)
	{
		glPushMatrix();
		switch (i)
		{
		case 0:
			glColor4f(0, 1, 0,3*i*0.2f);
			break;
		case 1:
			glColor4f(1, 0, 0,3*i*0.2f);
			break;
		case 2:
			glColor4f(0.5, 0, 0,2*i*0.2f);
			break;
		case 3:
			glColor4f(0, 0.2f, 0,2*i*0.2f);
			break;
		case 4:
			glColor4f(0, 1, 0.2f,i*0.2f);
			break;
		case 5:
			glColor4f(1, 0.0f, 0,i*0.2f);
			break;
		}
		glScalef(1.0f+i/3,1.0f+i/3,1.0f);
		glPushMatrix();
			if (i==5)
			{	glPushMatrix();
				glRotatef(xrot*1.25f,1.0f,1.0f,1.0f);
				glTranslatef(beat_responder/60,beat_responder/60,0.0f);
				glPushMatrix();
				glScalef(2.0f+beat_responder/60,2.0f+beat_responder/60,2.0f+beat_responder/60);
				Meshes->m_distsphere2->Draw();
				glPopMatrix();
				glPopMatrix();
			}
			else
			{
				
				glPushMatrix();
					glRotatef(xrot*0.5f*i,1.0f,1.0f,1.0f);
					glTranslatef(beat_responder/60,beat_responder/60,0.0f);
					Meshes->m_distsphere2->Draw();
				glPopMatrix();
			}
		glPopMatrix();
	}

	glDisable(GL_LIGHTING);

	glDisable(GL_TEXTURE_GEN_S);
	glDisable(GL_TEXTURE_GEN_T);
	
	glDepthMask(GL_TRUE);
	glDisable(GL_BLEND);

	sceneTime /= 2.0f;
}

void scene13::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;

	ret+=(int)beat_responder/60;
		
	if (ret>=80)
		ret=0;

	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;

}

bool scene13::Init(loadall		*textures)
{
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glDisableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glDisableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;
	lastTime		= GetTime();
	sceneTime		= 0;

	multi_texture=rand()%9;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(6);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(6);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(6);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(6);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(6);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(6);
		break;
		case 6:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(10);
		break;
		case 7:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(11);
		break;
		case 8:
			m_Texture[0]=textures->Bind(12);
			m_Texture[1]=textures->Bind(6);
		break;
		case 9:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==10)
		multi_texture=0;*/
	return true;
}

float scene13::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);

}

void scene13::drawline(const vec *points, int numPoints, float width, const vec &campos,float beat_help)
{
	vec lookat = campos - points[0];
	vec dir = points[1] - points[0];	
	
	vec x, tmp;
	
	glBegin(GL_QUADS);
		for(int a = 0; a < numPoints-1; a++)
		{
			x = lookat*dir;
			x.Normalize();
			
			tmp = points[a] + x * width;
			glTexCoord2f(0, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);				
			
			tmp = points[a] - x * width;
			glTexCoord2f(1, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			lookat = campos - points[a+1];
			dir = points[a+1] - points[a];
			x = lookat * dir;
			x.Normalize();
			
			tmp = points[a+1] - x*width;
			glTexCoord2f(1, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			tmp = points[a+1] + x*width;
			glTexCoord2f(0, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);			
		}
	glEnd();
}

float scene13::semirand(int x)
{
	x = (x<<13) ^ x;
	return ( 1.0f - ( (x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f); 
}

