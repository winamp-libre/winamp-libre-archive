#include "headers.h"
#include "cube.h"

cube::cube()					
{
	scene_timer					= 0;
	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	int blend_colour=120;

	GLfloat vertices_help[] =	{	
									-1.0, -1.0, 1.0,        
									1.0, -1.0, 1.0,
									1.0, 1.0, 1.0,
									-1.0, 1.0, 1.0,
							
									-1.0, -1.0, -1.0,
									-1.0,  1.0, -1.0,
									1.0,  1.0, -1.0,
									1.0, -1.0, -1.0,
	
									-1.0,  1.0, -1.0,
									-1.0,  1.0,  1.0,
									1.0,  1.0,  1.0,
									1.0,  1.0, -1.0,
	
									-1.0, -1.0, -1.0,
									1.0, -1.0, -1.0,
									1.0, -1.0,  1.0,
									-1.0, -1.0,  1.0,
													
									1.0, -1.0, -1.0,
									1.0,  1.0, -1.0,
									1.0,  1.0,  1.0,
									1.0, -1.0,  1.0,
	
									-1.0, -1.0, -1.0,
									-1.0, -1.0,  1.0,
									-1.0,  1.0,  1.0,
									-1.0,  1.0, -1.0
								};

	GLuint indices_help[]=		{		
									0	,1	,2	,3	, 
									4	,5	,6	,7	, 
									8	,9	,10	,11	, 
									12	,13	,14	,15	,
									16	,17	,18	,19	,
									20	,21	,22	,23 
								};

	GLfloat normals_help[]=		{		
									0.0, 0.0, 0.5,
									0.0, 0.0, 0.5,
									0.0, 0.0, 0.5,
									0.0, 0.0, 0.5,

									0.0, 0.0, -0.5,
									0.0, 0.0, -0.5,
									0.0, 0.0, -0.5,
									0.0, 0.0, -0.5,

									0.0, 0.5, 0.0,
									0.0, 0.5, 0.0,
									0.0, 0.5, 0.0,
									0.0, 0.5, 0.0,

									0.0,-0.5, 0.0,
									0.0,-0.5, 0.0,
									0.0,-0.5, 0.0,
									0.0,-0.5, 0.0,

									0.5, 0.0, 0.0,
									0.5, 0.0, 0.0,
									0.5, 0.0, 0.0,
									0.5, 0.0, 0.0,

									-0.5, 0.0, 0.0,
									-0.5, 0.0, 0.0,
									-0.5, 0.0, 0.0,
									-0.5, 0.0, 0.0
								};

	GLubyte colours_help[]  =	{	
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
								
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
		
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
		
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
		
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour
							};

	for (i=0;i<72;i++)
	{
		vertices[i]=vertices_help[i];
		normals[i]=normals_help[i];
	}
	for (i=0;i<24;i++)
		indices[i]=indices_help[i];
	for (i=0;i<96;i++)
		colours[i]=colours_help[i];
	beat_min		= 0.0f;
	beat_max		= 0.0f;

	texturechanger = 0;
}

cube::~cube()
{					
}


void cube::Draw(GLfloat tex_cord,GLfloat roll,GLuint m_Texture[],float number,float xrot)
{
	GLfloat vertices_help[] =	
	{
		(-1.0f-beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,        
		( 1.0f+beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
		(-1.0f-beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
							
		(-1.0f-beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		(-1.0f-beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,	( 1.0f+beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
	
		(-1.0f-beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		(-1.0f-beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
	
		(-1.0f-beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
		(-1.0f-beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
													
		( 1.0f+beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
		( 1.0f+beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
	
		(-1.0f-beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, (-1.0f-beat_responder/30)*number,
		(-1.0f-beat_responder/30)*number,   (-1.0f-beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
		(-1.0f-beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, ( 1.0f+beat_responder/30)*number,
		(-1.0f-beat_responder/30)*number,   ( 1.0f+beat_responder/30)*number, (-1.0f-beat_responder/30)*number
	};

	for (i=0;i<72;i++)
	{
		vertices[i]=vertices_help[i];
	}

	GLfloat tex_coords[] = {    0.0f+roll, 0.0f+roll,
                                tex_cord+roll, 0.0f+roll,
                                tex_cord+roll, tex_cord+roll,
                                0.0f+roll, tex_cord+roll, 
	
								tex_cord+roll, 0.0f+roll,
								tex_cord+roll, tex_cord+roll,
								0.0f+roll, tex_cord+roll,
								0.0f+roll, 0.0f+roll,
	
								0.0f+roll, tex_cord+roll,
								0.0f+roll, 0.0f+roll,
								tex_cord+roll, 0.0f+roll,
								tex_cord+roll, tex_cord+roll,
	
								tex_cord+roll, tex_cord+roll,
								0.0f+roll, tex_cord+roll,
								0.0f+roll, 0.0f+roll,
								tex_cord+roll, 0.0f+roll,
		
								tex_cord+roll, 0.0f+roll,
								tex_cord+roll, tex_cord+roll,
								0.0f+roll, tex_cord+roll,
								0.0f+roll, 0.0f+roll,
	
								0.0f+roll, 0.0f+roll,
								tex_cord+roll, 0.0f+roll,
								tex_cord+roll, tex_cord+roll,
								0.0f+roll, tex_cord+roll};

	GLfloat lightPos[] = {0, 0, 0,0.0f};
	GLfloat ambientLight[] = { .3f, .9f, .0f, 1.0f };    
	GLfloat diffuseLight[] = {0.0f, 1.0f, 1.0f, 1.0f };			
	GLfloat specular[]     = { 0.0f, 0.0f, 0.8f, 1.0f };			
	GLfloat specref[]      = { 0.0f, 0.0f, 1.0f, 1.0f };			
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);		
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, specref);					
	glMateriali( GL_FRONT_AND_BACK, GL_SHININESS, 120 );
	glDisable(GL_COLOR_MATERIAL);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);					
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);					
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);					
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);

	//int texturechanger=0;
	if ( texturechanger <= 19)
	{
		
		glActiveTextureARB ( GL_TEXTURE0_ARB );
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );	
		glEnable           ( GL_TEXTURE_2D   );
		glEnable(GL_BLEND);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);
		

		glActiveTextureARB ( GL_TEXTURE1_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	}
	else
	{
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
		glActiveTextureARB ( GL_TEXTURE0_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );	
		glEnable           ( GL_TEXTURE_2D   );
		glEnable(GL_BLEND);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
		glEnable(GL_TEXTURE_GEN_S);																
		glEnable(GL_TEXTURE_GEN_T);
		glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB ( GL_TEXTURE1_ARB ); 
		glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] ); 
		glEnable(GL_TEXTURE_2D);
		glDisable(GL_TEXTURE_GEN_S);																
		glDisable(GL_TEXTURE_GEN_T);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	}
	
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);
	glRotatef(xrot/3+(i),0.0f,0.0f,1.0f);
	glRotatef(xrot/7,0.0f,1.0f,0.0f);	
	glRotatef(xrot/5,1.0f,0.0f,0.0f);

	glEnableClientState				(	GL_VERTEX_ARRAY							);
	glEnableClientState				(	GL_NORMAL_ARRAY							);
	glClientActiveTextureARB		(	GL_TEXTURE0_ARB							); 
	glTexCoordPointer				(	2, GL_FLOAT, 0, &tex_coords				); 
	glClientActiveTextureARB		(	GL_TEXTURE1_ARB							);  
	glTexCoordPointer				(	2, GL_FLOAT, 0, &tex_coords				);
	glEnableClientState				(	GL_COLOR_ARRAY							);
	glVertexPointer					(	3, GL_FLOAT, 0,			&vertices		);
	glColorPointer					(	4, GL_FLOAT, 0,		&colours	);
	glNormalPointer					(	GL_FLOAT, 0, &normals					);
	glDrawElements					(	GL_QUADS, 24, GL_UNSIGNED_INT, &indices );
}

void cube::Update(GLuint blend_colour,float beat,DWORD timeeffect)
{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};

	time=timeeffect;
	
	beat_responder=beat;

	if (beat_min==0 && beat_max==0)
	{
		beat_min=beat_responder;
		beat_max=beat_responder;
	}
	else
	{
		if (beat_min>beat_responder)
			beat_min=beat_responder;
		if (beat_max<beat_responder)
			beat_max=beat_responder;
	}

	float beat_middle=(beat_max-beat_min)/10.0f;
	int col=0;
	if (beat_responder>=0)
		col=1;
	if (beat_responder>1*beat_middle+beat_min)
		col=2;
	if (beat_responder>2*beat_middle+beat_min)
		col=3;
	if (beat_responder>3*beat_middle+beat_min)
		col=4;
	if (beat_responder>4*beat_middle+beat_min)
		col=5;
	if (beat_responder>5*beat_middle+beat_min)
		col=6;
	if (beat_responder>6*beat_middle+beat_min)
		col=7;
	if (beat_responder>7*beat_middle+beat_min)
		col=8;
	if (beat_responder>8*beat_middle+beat_min)
		col=9;
	if (beat_responder>9*beat_middle+beat_min)
		col=0;

	for (i=0;i<96;i=i+4)
	{
		colours[i  ] =colors[col][0];
		colours[i+1] =colors[col][1];
		colours[i+2] =colors[col][2];
		colours[i+3] =0.6f;
	}
}

void cube::Init(void)
{
	glClientActiveTextureARB ( GL_TEXTURE0_ARB        ); 
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glEnableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glActiveTextureARB ( GL_TEXTURE0_ARB );   
	glEnable           ( GL_TEXTURE_2D   );     

	glActiveTextureARB ( GL_TEXTURE1_ARB );   
	glEnable           ( GL_TEXTURE_2D   );
	texturechanger++;
	if (texturechanger == 38)
		texturechanger=0;
}

