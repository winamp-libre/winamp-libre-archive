#include "Liquidtime.h"

liqTime::liqTime()
{
	m_iCount		= 0;
	m_dFPS			= 60.0;
	m_dFrameTime	= 0;

	m_lCurrentTime	= GetTickCount();
	m_lLastTime		= 0;
}

/*
 * update()
 * This calculates the time difference between frames, and also the frames per
 * second (FPS).
 */
void liqTime::update()
{
	m_lCurrentTime = GetTickCount();

	m_iCount ++;

	if(m_iCount % 10 == 0)
	{
		m_dFPS = 100.0f / ((m_lCurrentTime - m_lLastTime) / 100.0f);
		m_lLastTime = m_lCurrentTime;

		if(m_dFPS >= 1.0f)
			m_dFrameTime = 1.0f / m_dFPS;
		else
		{
			m_dFPS = 60.0f;
			m_dFrameTime = 0;
		}
	}
}

/*
 * getFrameTime()
 * This returns the current frame time calculated.
 */
double liqTime::getFrameTime()
{
	if(m_dFrameTime <= 0)
		return 0.016;
	else
		return m_dFrameTime;
}
