#ifndef __LIQUID15_H_
#define __LIQUID15_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"
#include "Liquid2.h"
#include "camera.h"

class scene15:public Manager
{

	public:
		scene15(double time,float wid,float hei);												
		~scene15();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		GLuint		m_Texture[5];										
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		scene2		*liquid2;
		GLuint		Metaballs_list;
		CCamera		*camera;
		CVector3	*center;
		float		width,height;
};

#endif __LIQUID15_H_
