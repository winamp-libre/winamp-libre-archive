#include "headers.h"
#include "Misc.h"
#include "liquid28.h"

scene28::scene28(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,float wid,float hei):Manager(time)					
{
	TextGen			= generatedtextures;
	Meshes			= generatedmeshes;
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	for (int i=0;i<20;i++)
		offset[i]=0.0f;
	scene_switcher=-1;

	width						= wid;
	height						= hei;
}

scene28::~scene28()	
{
}


void scene28::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] );
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

	glActiveTextureARB ( GL_TEXTURE1_ARB );
	glEnable(GL_TEXTURE_2D);
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			glTexGeni(GL_S, GL_EYE_PLANE, GL_SPHERE_MAP);
		glTexGeni(GL_T, GL_EYE_PLANE, GL_SPHERE_MAP);
	glEnable(GL_TEXTURE_GEN_S);																
	glEnable(GL_TEXTURE_GEN_T);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	

	glActiveTextureARB ( GL_TEXTURE0_ARB );


	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};
	gluLookAt(0, 0, 1,     0, 0, 0,     0, 1, 0);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);																	// Set The Blending Function For Translucency
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);
	glShadeModel(GL_SMOOTH);																			// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);																// Black Background
	glClearDepth(1.0f);																					// Depth Buffer Setup
	glDepthFunc(GL_LEQUAL);																				// The Type Of Depth Testing To Do
	glDisable(GL_DEPTH_TEST);																			// Enables Depth Testing
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	float scale=1.0f;
	glTranslatef(0.0f,0.0f,-10.0f+beat_responder/10);
	int rand_texture=0;
	if (scene_switcher<=5)
	{
		glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
		glTexGeni(GL_S, GL_EYE_PLANE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_EYE_PLANE, GL_OBJECT_LINEAR);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);												// Set The Texture Generation Mode For S To Sphere Mapping 
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);	
		glTexGeni(GL_S, GL_SPHERE_MAP, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_SPHERE_MAP, GL_OBJECT_LINEAR);
		glEnable(GL_TEXTURE_GEN_S);                                                             
		glEnable(GL_TEXTURE_GEN_T); 
	}
	if (scene_switcher>5)
	{
		glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
		glDisable(GL_TEXTURE_GEN_S);                                                                
		glDisable(GL_TEXTURE_GEN_T);    
	}  
	if (scene_switcher>10)
	{
		glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
		glTexGeni(GL_S, GL_EYE_PLANE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_EYE_PLANE, GL_OBJECT_LINEAR);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);												// Set The Texture Generation Mode For S To Sphere Mapping 
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni(GL_S, GL_SPHERE_MAP, GL_EYE_LINEAR);
		glTexGeni(GL_T, GL_SPHERE_MAP, GL_EYE_LINEAR);
		glEnable(GL_TEXTURE_GEN_S);                                                             
		glEnable(GL_TEXTURE_GEN_T); 
	}
	if (scene_switcher>15)
	{
		glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
		glDisable(GL_TEXTURE_GEN_S);                                                                
		glDisable(GL_TEXTURE_GEN_T);    
	} 
	if (scene_switcher>20)
	{
		glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
		glTexGeni(GL_S, GL_EYE_PLANE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_EYE_PLANE, GL_OBJECT_LINEAR);
		glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);												// Set The Texture Generation Mode For S To Sphere Mapping 
		glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);			
		glTexGeni(GL_S, GL_SPHERE_MAP, GL_EYE_LINEAR);
		glTexGeni(GL_T, GL_SPHERE_MAP, GL_EYE_LINEAR);
		glEnable(GL_TEXTURE_GEN_S);                                                             
		glEnable(GL_TEXTURE_GEN_T); 
	}
	if (scene_switcher>25)
	{
		glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
		glTexGeni(GL_S, GL_EYE_PLANE, GL_OBJECT_LINEAR);
		glTexGeni(GL_T, GL_EYE_PLANE, GL_OBJECT_LINEAR);
		glTexGeni(GL_S, GL_SPHERE_MAP, GL_EYE_LINEAR);
		glTexGeni(GL_T, GL_SPHERE_MAP, GL_EYE_LINEAR);
		glEnable(GL_TEXTURE_GEN_S);                                                             
		glEnable(GL_TEXTURE_GEN_T); 
	}
	if (rand_texture>=6)
		glBindTexture(GL_TEXTURE_2D, m_Texture[0]);
	
	//if (rand_texture!=4)
	glTranslatef((float)sin(sceneTime),(float)cos(sceneTime),0.0f);
	glPushMatrix();	
	glScalef(1.0f+beat_responder/10,1.0f+beat_responder/10,1.0f+beat_responder/10);
	
	glRotatef(xrot,0.0f,1.0f,1.0f);
	glPushMatrix();
	int col=0;
	if (beat_responder>10)
		col=1;
	if (beat_responder>20)
		col=2;
	if (beat_responder>30)
		col=3;
	if (beat_responder>40)
		col=4;
	if (beat_responder>50)
		col=5;
	if (beat_responder>60)
		col=6;
	if (beat_responder>70)
		col=7;
	if (beat_responder>80)
		col=8;
	if (beat_responder>90)
		col=9;
	if (beat_responder>100)
		col=0;
	int max_rec=10;
	glColor4f(colors[col][0],colors[col][1],colors[col][2],0.2f);
	int choice=0;
	for (int loop=0;loop<max_rec;loop++)
	{
		
		glPushMatrix();
			glRotatef(xrot*loop/(max_rec),0.0f,1.0f,0.0f);
			glPushMatrix();
				glScalef(scale/(max_rec-loop),scale/(max_rec-loop),scale/(max_rec-loop));

				glEnable(GL_TEXTURE_2D);
				glBegin(GL_QUADS);
					if (choice!=2)
					{
					glNormal3f( 0.0f, 0.0f, 1.0f);								
					glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
					glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
					}

					/*-------------------------------------------------------------------------------------------------*/
					/*-------------------------------------------Back Face---------------------------------------------*/
					/*-------------------------------------------------------------------------------------------------*/

					if (choice!=2)
					{
					glNormal3f( 0.0f, 0.0f,-1.0f);								
					glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f); 
					glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
					}
					/*-------------------------------------------------------------------------------------------------*/
					/*--------------------------------------------Top Face---------------------------------------------*/
					/*-------------------------------------------------------------------------------------------------*/

					glNormal3f( 0.0f, 1.0f, 0.0f);								
					glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
        
					/*-------------------------------------------------------------------------------------------------*/
					/*-------------------------------------------Bottom Face-------------------------------------------*/
					/*-------------------------------------------------------------------------------------------------*/

					glNormal3f( 0.0f,-1.0f, 0.0f);								
					glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
					glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
					
					/*-------------------------------------------------------------------------------------------------*/
					/*-------------------------------------------Right face--------------------------------------------*/
					/*-------------------------------------------------------------------------------------------------*/

					glNormal3f( 1.0f, 0.0f, 0.0f);								
					glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
					glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
					glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
					
					/*-------------------------------------------------------------------------------------------------*/
					/*-------------------------------------------Left Face---------------------------------------------*/
					/*-------------------------------------------------------------------------------------------------*/

					glNormal3f(-1.0f, 0.0f, 0.0f);								
					glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
					glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
					glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
					glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
				glEnd();															
			glPopMatrix();
		glPopMatrix();
	}
	glPopMatrix();
	//bg->DrawRotateTile(timeeffect*xrot/100);
}

void scene28::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((float)pow(beat_responder/30,2)+0.1f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene28::Init(loadall		*textures)
{
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glDisableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glDisableClientState       ( GL_TEXTURE_COORD_ARRAY );
	SceneStart		= GetTickCount();
	fadeffect		= 0;
	sceneTime		= 0;
	lastTime		= 0;
	multi_texture=rand()%6;
	scene_switcher=rand()%30;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(4);
		break;
		case 1:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(0);
		break;
		case 2:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(4);
		break;
		case 4:
			m_Texture[0]=textures->Bind(2);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(1);
		break;
	}
	/*multi_texture=multi_texture++;
	if (multi_texture==6)
		multi_texture=0;
	scene_switcher=scene_switcher++;
	if (scene_switcher==30)
		scene_switcher=0;*/
	return true;
}

void scene28::drawline(const vec *points, int numPoints, float width, const vec &campos,float beat_help)
{
	vec lookat = campos - points[0];
	vec dir = points[1] - points[0];	
	
	vec x, tmp;
	
	glBegin(GL_QUADS);
		for(int a = 0; a < numPoints-1; a++)
		{
			x = lookat*dir;
			x.Normalize();
			
			tmp = points[a] + x * width;
			glTexCoord2f(0, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);				
			
			tmp = points[a] - x * width;
			glTexCoord2f(1, a/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			lookat = campos - points[a+1];
			dir = points[a+1] - points[a];
			x = lookat * dir;
			x.Normalize();
			
			tmp = points[a+1] - x*width;
			glTexCoord2f(1, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);
			
			tmp = points[a+1] + x*width;
			glTexCoord2f(0, (a+1)/(float)(numPoints-1));
			glVertex3fv(tmp.v);			
		}
	glEnd();
}

float scene28::semirand(int x)
{
	x = (x<<13) ^ x;
	return ( 1.0f - ( (x * (x * x * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0f); 
}

float scene28::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);

}

