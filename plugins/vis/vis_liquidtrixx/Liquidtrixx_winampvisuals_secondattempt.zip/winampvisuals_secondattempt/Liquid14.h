#ifndef __LIQUID14_H_
#define __LIQUID14_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"

class scene14:public Manager
{

	public:
		scene14(double time,float wid,float hei);												
		~scene14();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		GLuint		m_Texture[5];
		GLfloat		R[6],G[6],B[6];
		GLfloat		colours[16];
		int			i,direction;
		float		scalefactor,ElapsedTime;
		float		xrot,t;
		float		beat_responder,beat_min,beat_max;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		float		width,height;
};

#endif __LIQUID14_H_
