#include "headers.h"
#include "Misc.h"
#include "WindowFunctions.h"
#include "liquid4.h"

scene4::scene4(double time,float wid,float hei):Manager(time)					
{
	glClientActiveTextureARB		= NULL;
	glActiveTextureARB				= NULL;
	glActiveTextureARB				= ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB		= ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
   
	TunnelStart						= 0;
	DICHTE_U						= 15;
	DICHTE_V						= 8000;
	step_u							= 1.0f/DICHTE_U;
	step_v							= 1.0f/DICHTE_V;
	T								= 2.4f;
	Geschwindigkeit					= 1;
	Kamera_pos						= 0;
	frame							= 0;
	SICHTBAR_V						= 700;
	multi_texture					= 0;
	scenechanger					= 0;
	gain_a							= 2;
	gain_b							= 3;

	xrot			=0.0f;
	xrot_help		=0.0f;
	t				=0.0f;	
	direction		=-1;

	glDisable(GL_FOG);
	float PI=3.14f;
	float temp_x, temp_y, temp_z, temp_u, temp_v;										// Zwischenspeicher
	for(int u = 0; u < DICHTE_U; u++)													// Schleife durch die Querpunkte
	{
		float c = 0.0f;
		for(int v = 0; v < DICHTE_V; v++)												// Schleife durch die L�ngspunkte
		{	
			temp_u = float(u-DICHTE_U)*(step_u*2);										// Zwischenpunkte berechnen
			temp_v = float(v)*step_v;
																								
			temp_x = float(((T*sin(temp_u*PI)  + 2.3*cos(temp_v*PI*-cos(-temp_v*PI*51+ cos(temp_v*PI*37))) +
							2*sin(temp_v*PI*-80) + 10*sin(temp_v*PI*6))));
			temp_y = float(((T*cos(temp_u*PI) + 7*cos(temp_v*PI*76) + 17*sin(temp_v*PI*-6)) +
							1.5*sin(temp_v*PI*cos(-temp_v*PI*43+ sin(temp_v*PI*35)))));
			temp_z = float(((temp_v*2500 + 2*cos(temp_v*PI*102))*0.8)-2.3*sin(temp_v*PI*120));
			Punkte[u][v][0] = 0.5f*temp_x;															
			Punkte[u][v][1] = 0.7f*temp_y;
			Punkte[u][v][2] = 2*temp_z;

			if(u == DICHTE_U-1)							
			{
				Punkte[u+1][v][0] = Punkte[0][v][0];
				Punkte[u+1][v][1] = Punkte[0][v][1];
				Punkte[u+1][v][2] = Punkte[0][v][2];
			}
		}
	}

	GLuint blend_colour=255;

	GLfloat vertices_help[] =	{-1.0,  1.0, -1.0,
								-1.0,  1.0,  1.0,
								1.0,  1.0,  1.0,
								1.0,  1.0, -1.0};

	GLuint indices_help[]   = {	0	,1	,2	,3};

	GLfloat normals_help[]=	{	0.0, 1.0, 0.0};

	GLubyte colours_help[]  =	{	255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour,
									255, 255, 255,	blend_colour
								};

	float	tex_cord=1.0f;
	roll=0.0f;

	GLfloat tex_coords_help[] = {    0.0f+roll,		0.0f+roll,
									tex_cord+roll,	0.0f+roll,
									tex_cord+roll,	tex_cord+roll,
									0.0f+roll,		tex_cord+roll
								};


	for (int i=0;i<12;i++)
	{
		vertices[i]=vertices_help[i];
		normals[i]=normals_help[i];
	}
	for (i=0;i<4;i++)
		indices[i]=indices_help[i];
	for (i=0;i<16;i++)
		colours[i]=colours_help[i];
	for (i=0;i<8;i++)
		tex_coords[i]=tex_coords_help[i];

	width						= wid;
	height						= hei;
}

scene4::~scene4()					
{
}

void scene4::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	vertices_count=0;
	indices_count=0;
	colours_count=0;
	texture_count=0;
	
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	xrot_help+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

void scene4::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};
	int HALBE_U = int(DICHTE_U / 2.0f);
	glColor4f(1.0f,1.0f,1.0f,1.0f);
	glDisable(GL_BLEND);
	Kamera[0] = (Punkte[0][Kamera_pos][0] + Punkte[HALBE_U][Kamera_pos][0]) / 2.0f;
	Kamera[1] = (Punkte[0][Kamera_pos][1] + Punkte[HALBE_U][Kamera_pos][1]) / 2.0f;
	Kamera[2] = (Punkte[0][Kamera_pos][2] + Punkte[HALBE_U][Kamera_pos][2]) / 2.0f;
	Kamera[3] = (Punkte[0][Kamera_pos+1][0] + Punkte[HALBE_U][Kamera_pos+1][0]) / 2.0f;
	Kamera[4] = (Punkte[0][Kamera_pos+1][1] + Punkte[HALBE_U][Kamera_pos+1][1]) / 2.0f;
	Kamera[5] = (Punkte[0][Kamera_pos+1][2] + Punkte[HALBE_U][Kamera_pos+1][2]) / 2.0f;
	frame++;

	if(Geschwindigkeit > 1)
		Geschwindigkeit--;
	if (frame % Geschwindigkeit == 0)
		Kamera_pos-=beat_responder/80;																	
	if(Kamera_pos<= 0)															
		Kamera_pos = DICHTE_V-1;
	gluLookAt(Kamera[3], Kamera[4], Kamera[5],											
		      Kamera[0], Kamera[1], Kamera[2], 
			  0.0f, 1.0f, 0.0f);
	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
	glEnable(GL_TEXTURE_2D);
	
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
	glEnable(GL_TEXTURE_2D);
	
	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_NORMAL_ARRAY);
	
	if (scenechanger<8)
	{
		glActiveTextureARB		( GL_TEXTURE0_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[0] ); 
		glTexGeni				(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glTexGeni				(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glEnable(GL_TEXTURE_GEN_S);															
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND );

		glActiveTextureARB		( GL_TEXTURE1_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
		glEnable(GL_TEXTURE_GEN_S);															
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glDisable(GL_DEPTH_TEST);
		glTexGeni				(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glTexGeni				(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );
	}
	if (scenechanger>=8)
	{
		glActiveTextureARB		( GL_TEXTURE0_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[0] ); 
		glTexGeni				(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
		glTexGeni				(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glEnable(GL_TEXTURE_GEN_S);															
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB		( GL_TEXTURE1_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
		glEnable(GL_TEXTURE_GEN_S);															
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		glTexGeni				(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glTexGeni				(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);

	}

	if (scenechanger>16)
	{
		glActiveTextureARB		( GL_TEXTURE0_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[0] ); 
		glTexGeni				(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glTexGeni				(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glEnable(GL_TEXTURE_GEN_S);															
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

		glActiveTextureARB		( GL_TEXTURE1_ARB ); 
		glEnable(GL_TEXTURE_2D);
		glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
		glEnable(GL_TEXTURE_GEN_S);															
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_BLEND);
		glEnable(GL_DEPTH_TEST);
		glTexGeni				(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		glTexGeni				(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
		glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);

	}

	/*if (scenechanger<7)
		glDisable(GL_BLEND);*/
	int col=0;

	if (beat_responder>5)
		col=1;
	if (beat_responder>10)
		col=2;
	if (beat_responder>15)
		col=3;
	if (beat_responder>20)
		col=4;
	if (beat_responder>25)
		col=5;
	if (beat_responder>30)
		col=6;
	if (beat_responder>35)
		col=7;
	if (beat_responder>40)
		col=8;
	if (beat_responder>45)
		col=9;
	if (beat_responder>50)
		col=0;
	glColor4f(colors[col][0],colors[col][1],colors[col][2],1.0f);

	float texture_shift=0.0f;
	vec *nor_1	= new vec();
	vec *nor_2	= new vec();
	vec *normal = new vec();
	vec *vertex_shift = new vec();

	for(int v = 0 ; v < DICHTE_V-1; v++)							
	{
		for(int u = 0; u < DICHTE_U; u++)
		{
			if((v < Kamera_pos) && (v > Kamera_pos- SICHTBAR_V))								
			{
				float temp_u = float(u)*step_u;										
				float temp_v = float(v)*step_v; 
				
				texture_shift=xrot;
				
				*nor_1 = vec(Punkte[u][v+1][0]-Punkte[u][v][0],
							 Punkte[u][v+1][1]-Punkte[u][v][1],
							 Punkte[u][v+1][2]-Punkte[u][v][2]);
				*nor_2 = vec(Punkte[u+1][v][0]-Punkte[u][v][0],
							 Punkte[u+1][v][1]-Punkte[u][v][1],
							 Punkte[u+1][v][2]-Punkte[u][v][2]);

				*normal = (*nor_1)*(*nor_2);
				*vertex_shift=vec(0,0,0);

				for (int i=0;i<12;i+=3)
				{
					normals[i  ]=normal->x;
					normals[i+1]=normal->y;
					normals[i+2]=normal->z;
				}

				for (int j=0;j<2;j++)
				{
					if (j==0)
					{
						for (int i=0;i<2;i++)
						{
							vertices[0+3*i]=Punkte[u][v+i][0]+Punkte[u][v+i][0]*vertex_shift->x;
							vertices[1+3*i]=Punkte[u][v+i][1]+Punkte[u][v+i][1]*vertex_shift->y;
							vertices[2+3*i]=Punkte[u][v+i][2]+Punkte[u][v+i][2]*vertex_shift->z;
						}
					}
					else
					{
						for (int i=0;i<2;i++)
						{
							vertices[6+3*i]=Punkte[u+1][v+1-i][0]+Punkte[u+1][v+1-i][0]*vertex_shift->x;
							vertices[7+3*i]=Punkte[u+1][v+1-i][1]+Punkte[u+1][v+1-i][1]*vertex_shift->y;
							vertices[8+3*i]=Punkte[u+1][v+1-i][2]+Punkte[u+1][v+1-i][2]*vertex_shift->z;
						}
					}
				}
				roll+=beat_responder/30;
				tex_coords[0] = temp_u*gain_a+texture_shift+roll;
				tex_coords[1] = temp_v*gain_b+texture_shift+roll;
				tex_coords[2] = temp_u*gain_a+texture_shift+roll;
				tex_coords[3] = temp_v*gain_b+step_v+texture_shift+roll;

				tex_coords[4] = temp_u*gain_a+step_u+texture_shift+roll;
				tex_coords[5] = temp_v*gain_b+step_v+texture_shift+roll;
				tex_coords[6] = temp_u*gain_a+step_u+texture_shift+roll;
				tex_coords[7] = temp_v*gain_b+texture_shift+roll;
				glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
				glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
				glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
				glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );

				glNormalPointer		(GL_FLOAT, 0, &normals);
				glVertexPointer ( 3, GL_FLOAT, 0, &vertices );
				glColorPointer  ( 4, GL_UNSIGNED_BYTE, 0, &colours );
				glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );	
			}
		}
	}
	if (nor_1)
		delete nor_1;
	
	if (nor_2)
		delete nor_2;
	if (normal)
		delete normal;
	if (vertex_shift)
		delete vertex_shift;

	glDisableClientState ( GL_VERTEX_ARRAY );
	glDisableClientState ( GL_COLOR_ARRAY );
	glDisableClientState ( GL_NORMAL_ARRAY);

	//glEnd();
}

bool scene4::Init(loadall		*textures)
{
		
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
	glDisable(GL_LIGHT1);
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(2);
		break;
		case 1:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(1);
		break;
		case 2:
			m_Texture[0]=textures->Bind(7);
			m_Texture[1]=textures->Bind(0);
		break;
		case 3:
			m_Texture[0]=textures->Bind(1);
			m_Texture[1]=textures->Bind(20);
		break;
		case 4:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(0);
		break;
		case 5:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(3);
		break;
		case 6:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(22);
		break;
		case 7:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(1);
		break;
	}
	scenechanger=scenechanger++;
	if (scenechanger==25)
		scenechanger=0;
	multi_texture=multi_texture++;
	if (multi_texture==8)
		multi_texture=0;
	return true;
}


