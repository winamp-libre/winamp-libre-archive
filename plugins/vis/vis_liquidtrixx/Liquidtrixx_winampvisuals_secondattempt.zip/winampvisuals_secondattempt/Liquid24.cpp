#include "headers.h"
#include "Misc.h"
#include "liquid24.h"

scene24::scene24(double time,float wid,float hei):Manager(time)					
{
	xrot			= 0.0f;
	t				= 0.0f;	
	direction		= -1;
	beat_responder	= 0.0f;
	bg				= new background();
	timeeffect		= 0;
	multi_texture	=0;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );
	slowdown=0.0f;
	xspeed	=2.0f;
	yspeed	=4.0f;
	col		=0;
	delay	=0;
	help2	=0.0f;
	mode	=-1;
	fnt = new Font("Arial", 42, true, false);

	width						= wid;
	height						= hei;
}

scene24::~scene24()	
{
}


void scene24::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);

	glActiveTextureARB ( GL_TEXTURE0_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[1] );
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

	glActiveTextureARB ( GL_TEXTURE1_ARB ); 
	glBindTexture      ( GL_TEXTURE_2D, m_Texture[0] ); 
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_TEXTURE_GEN_S);																
	glDisable(GL_TEXTURE_GEN_T);
	glEnable(GL_BLEND);
	glDisable(GL_DEPTH_TEST);
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);	
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexEnvi          ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL );

	glActiveTextureARB ( GL_TEXTURE0_ARB );								//first texture unit activated no multitexturing
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_T, GL_OBJECT_LINEAR, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);
	glTexGeni(GL_S, GL_EYE_PLANE, GL_EYE_LINEAR);

	glDepthMask(GL_FALSE);

	glTranslatef(0, 0, -3);

	glColor4f(0.5f, 0.7f, 1, 0.1f * fade_io(0, 20));
	glPushMatrix();
	if (mode==0 || mode==1 || mode==2)
	{
		glPushMatrix();
		glTranslatef(0, 0, -3.0f);
		glPushMatrix();
		for(int a = 0; a < 40; a++)
		{
				glTranslatef(2-sceneTime*0.7f, 0, 0-beat_responder/10);
				
				glScalef(0.01f, 0.01f, 0.01f);
				glTranslatef(-65, -35, 0);
				if (multi_texture==0)
					fnt->Print(0, 0, "The Rythm is taking you to another Dimension");
				if (multi_texture==1)
					fnt->Print(0, 0, "Liquify your Mind with the light Power");
				if (multi_texture==2)
					fnt->Print(0, 0, "::The Blue ::/:: the Red ::");
				if (multi_texture==3)
					fnt->Print(0, 0, "Liquifying rythems");
				if (multi_texture==4)
					fnt->Print(0, 0, "Musicflow <.........>  Mindflow");
				if (multi_texture==5)
					fnt->Print(0, 0, "http://www.liquidtrixx.com");
				if (multi_texture==6)
					fnt->Print(0, 0, "Thx to all the Artist with their pictures");
				if (multi_texture==7)
					fnt->Print(0, 0, "Deviantart http://www.deviantart.com");
				if (multi_texture==8)
					fnt->Print(0, 0, "Liquifying rythems :: shock your mind");
				if (multi_texture==9)
					fnt->Print(0, 0, "Musicflow <.........>  Mindflow");
			glPopMatrix();
		}
		glPopMatrix();
		glPopMatrix();
	}

	if (mode==2)
	{
		glPushMatrix();
		glTranslatef(0, 0, -3);
		glPushMatrix();
			glColor4f(0.5f, 0.7f, 1, 0.1f * fade_io(0, 20));	
			for(int a = 0; a < 30; a++)
			{
				glTranslatef(0, 0, 0.1f);
				glPushMatrix();
					glTranslatef(2.5f-sceneTime*0.6f, 0, 0);
					
					glScalef(0.01f, 0.01f, 0.01f);
					glTranslatef(-65, -35, 0);
					fnt->Print(0, 0, "Music and Mind in Harmoney and Therapy");
				glPopMatrix();
			}
		glPopMatrix();
		glPopMatrix();
	}

	glDepthMask(GL_TRUE);

	glDisable(GL_BLEND);
}

void scene24::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((float)pow(beat_responder/30,2)+0.1f);
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
	help2+=direction*beat_responder/20;

	float currTime = GetTime();
	float deltaTime = currTime - lastTime;
	lastTime = currTime;	
	float speed = 1;	
	sceneTime += deltaTime * speed;
}

bool scene24::Init(loadall		*textures)
{
	
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB ( GL_TEXTURE0_ARB        );    
	glDisableClientState      ( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB        );    
	glDisableClientState       ( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;
	lastTime		= GetTime();
	sceneTime		= 0;
	/*switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(13);
			m_Texture[1]=textures->Bind(3);
		break;
		case 1:
			m_Texture[0]=textures->Bind(0);
			m_Texture[1]=textures->Bind(1);
		break;
		case 2:
			m_Texture[0]=textures->Bind(4);
			m_Texture[1]=textures->Bind(5);
		break;
		case 3:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(1);
		break;
		case 4:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(2);
		break;
		case 5:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(0);
		break;
		case 6:
			m_Texture[0]=textures->Bind(11);
			m_Texture[1]=textures->Bind(3);
		break;
		case 7:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(22);
		break;
	}*/
	multi_texture=multi_texture++;
	if (multi_texture==9)
		multi_texture=0;
	mode=mode++;
	if (mode==2)
		mode=0;
	return true;
}

float scene24::GetTime(void)
{
	static bool init = false;
	static bool hires = false;
	static __int64 freq = 1;
	if(!init)
	{
		hires = !QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
		if(!hires)
			freq = 1000;
		init = true;
	}

	__int64 now;

	if(hires)
		QueryPerformanceCounter((LARGE_INTEGER *)&now);
	else
		now = GetTickCount();

	return (float)((double)now / (double)freq);

}

