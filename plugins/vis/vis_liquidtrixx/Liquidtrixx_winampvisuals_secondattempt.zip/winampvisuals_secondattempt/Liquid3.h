#ifndef __LIQUID3_H_
#define __LIQUID3_H_

#include "Scenemanager.h"
#include "TextGeneration.h"									

class scene3:public Manager
{
	public:
		struct GLVector
		{
			GLfloat x;
			GLfloat y;
			GLfloat z;     
		};
		scene3(double time,TextGeneration* generatedtextures,float wid,float hei);												
		~scene3();												
		virtual void Draw(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init(loadall		*textures);
	
	private:
		GLuint		m_Texture[5];
		int			TUNNEL_SPEED;
		float		PI_8;
		GLVector	Tunnels[65][33];
		GLfloat		vertices[10000];
		GLuint		indices[10000];
		GLfloat		normals[10000];
		GLubyte		colours[10000];
		GLfloat		tex_coords[10000];
		int			indices_count;
		int			vertices_count;
		int			colours_count;
		int			texture_count;
		PFNGLCLIENTACTIVETEXTUREARBPROC		glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC			glActiveTextureARB;
		DWORD		internal_timer;
		DWORD		TunnelStart;
		float		xrot,beat_responder,t;
		int			direction,multi_texture;
		TextGeneration*	TextGen;
		int			scene_switcher;
		float		width,height;
		DWORD		timeeffect,SceneStart;
};

#endif __LIQUID3_H_
