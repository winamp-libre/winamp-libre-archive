#ifndef __LIQUID18_H_
#define __LIQUID18_H_

#include "TextureLoader.h"
#include "Scenemanager.h"										
#include "Background.h"
#include "TextGeneration.h"
#include "MeshGeneration.h"

class scene18:public Manager
{

	public:
		scene18(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,float wid,float hei);												
		~scene18();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		GLuint		m_Texture[5];										
		int			i,direction;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		TextGeneration*	TextGen;
		MeshGeneration* Meshes;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		float		lastTime,sceneTime;
		float		offset[20];
		float		width,height;
};

#endif __LIQUID18_H_
