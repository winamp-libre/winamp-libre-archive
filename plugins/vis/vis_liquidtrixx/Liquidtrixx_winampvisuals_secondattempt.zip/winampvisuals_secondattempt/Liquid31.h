#ifndef __LIQUID31_H_
#define __LIQUID31_H_

#include "TextureLoader.h"
#include "Scenemanager.h"
#include "LoadAlltextures.h"										
#include "Background.h"
#include "TextGeneration.h"
#include "MeshGeneration.h"
#include "3ds.h"

class scene31:public Manager
{
	public:
		scene31(double time,TextGeneration* generatedtextures,MeshGeneration* generatedmeshes,t3DModel *model,float wid,float hei);												
		~scene31();												
		virtual void Draw	(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update	(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init	(loadall		*textures);
	
	private:
		//const int num=50;																						// Number Of Stars To Draw

			typedef struct																							// Create A Structure For Star
				{
					int r, g, b;																							// Stars Color
					GLfloat dist;																							// Stars Distance From Center
					GLfloat angle;																						// Stars Current Angle
				}
			stars;

		float		GetTime(void);
		float		semirand(int x);
		void		drawline(const vec *points, int numPoints, float width, const vec &campos,float beat_help);

		GLuint		m_Texture[5];										
		int			i,direction;
		int			scene_switcher;
		float		scalefactor;
		float		xrot,t;
		float		beat_responder;
		int			multi_texture;
		DWORD		timeeffect,SceneStart;
		background	*bg;
		float		fadeffect;
		PFNGLCLIENTACTIVETEXTUREARBPROC  glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC        glActiveTextureARB;
		TextGeneration*	TextGen;
		MeshGeneration* Meshes;
		float		lastTime,sceneTime,spin;
		stars		star[50];
		t3DModel	*g_3DModel;
		float		width,height;
};

#endif __LIQUID31_H_
