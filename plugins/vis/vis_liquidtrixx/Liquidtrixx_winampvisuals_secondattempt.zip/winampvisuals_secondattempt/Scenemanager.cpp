#include "headers.h"
#include "Misc.h"
#include "Scenemanager.h"
#include "LiquidTime.h"
#include "vis.h"

Manager::Manager(double time)
{
	m_dSceneLength				= time;
	SceneStart					= GetTickCount(); 

	for(int iCount = 0; iCount < MAX_CALLS; iCount ++)
	{
		m_dTime[iCount]			= 10000;
		m_bExecuting[iCount]	= false;
		m_bSwitched[iCount]		= false;
		m_bStaySwitched[iCount] = false;
	}

	m_pNext = NULL;
	m_pPrev = NULL;
}

void Manager::addNext(Manager *next)
{
	m_pNext = next;
}

void Manager::add_Next_Prev(Manager *next,Manager *prev)
{
	m_pPrev = prev;
	m_pNext = next;
}

void Manager::start()
{
	m_dSceneTime = 0;

	for(int iCount = 0; iCount < MAX_CALLS; iCount ++)
	{
		m_bExecuting[iCount]	= false;
		m_bSwitched[iCount]		= false;
		m_bStaySwitched[iCount] = false;
	}
}

void Manager::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	for(int iCount = 0; iCount < MAX_CALLS - 1; iCount ++)	// Loop thru all but the last scene
	{
		if(m_dSceneTime >= m_dTime[iCount] && m_dSceneTime < m_dTime[iCount + 1])	// If this is our time (ie mutex resource)
		{
			if(!m_bStaySwitched[iCount]) // Have we just switched over 
			{
				m_bStaySwitched[iCount]			= true;
				m_bSwitched[iCount]				= true;

				if(iCount > 0)
					m_bExecuting[iCount - 1]	= false;	// We are not executing the event before this one

				m_bExecuting[iCount]			= true;
			}
			else
				m_bSwitched[iCount]				= false;
		}
		else if(m_dSceneTime >= m_dTime[MAX_CALLS - 1])	// The last event
		{
			if(!m_bStaySwitched[MAX_CALLS - 1])
			{
				m_bStaySwitched[MAX_CALLS - 1]	= true;
				m_bSwitched[MAX_CALLS - 1]		= true;
				m_bExecuting[MAX_CALLS - 1]		= true;

				if(iCount > 0)
					m_bExecuting[MAX_CALLS - 2] = false;
			}
			else
				m_bSwitched[MAX_CALLS - 1]		= false;
		}
	}
}

bool Manager::isComplete()
{
	m_dSceneTime += g_pFrameTime->getFrameTime();

	if(m_dSceneTime >= m_dSceneLength)
		return true;

	return false;
}

Manager *Manager::getNext()
{
	return m_pNext;
}

Manager *Manager::getPrev()
{
	return m_pPrev;
}

void Manager::setTime(int index, double time)
{
	m_dTime[index] = time;
}
