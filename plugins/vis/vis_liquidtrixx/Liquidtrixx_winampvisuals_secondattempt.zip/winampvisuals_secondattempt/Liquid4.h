#ifndef __LIQUID4_H_
#define __LIQUID4_H_

#include "Scenemanager.h"
#include "TextureLoader.h"	
#include "LoadAlltextures.h"									

class scene4:public Manager
{
	public:
		struct GLVector
		{
			GLfloat x;
			GLfloat y;
			GLfloat z;     
		};
		scene4(double time,float wid,float hei);												
		~scene4();												
		virtual void Draw(GLuint blend_colour,struct winampVisModule *this_mod);
		virtual void Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on);
		virtual bool Init(loadall		*textures);
	
	private:
		GLuint		m_Texture[5];
		int			indices_count;
		int			vertices_count;
		int			colours_count;
		int			texture_count;
		PFNGLCLIENTACTIVETEXTUREARBPROC		glClientActiveTextureARB;
		PFNGLACTIVETEXTUREARBPROC			glActiveTextureARB;
		DWORD		internal_timer;
		DWORD		TunnelStart;
		float Punkte[21][12001][3];
		int			DICHTE_U,DICHTE_V;
		float		step_u,step_v,T,xrot;
		float		Kamera[6];
		int			Kamera_pos,frame;
		int			Geschwindigkeit;
		int			SICHTBAR_V;
		float		beat_responder,t;
		int			direction,multi_texture;
		int			scenechanger;
		float		xrot_help,gain_a,gain_b;
		float		roll;
		GLfloat vertices[48];
		GLuint	indices[16];
		GLfloat normals[48];
		GLubyte colours[64];
		GLfloat tex_coords[32];

		float		width,height;
};

#endif __LIQUID4_H_
