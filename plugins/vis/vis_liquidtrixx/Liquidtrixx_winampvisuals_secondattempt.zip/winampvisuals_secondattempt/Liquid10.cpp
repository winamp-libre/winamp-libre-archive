#include "headers.h"
#include "Misc.h"
#include "liquid10.h"

scene10::scene10(double time,float wid,float hei):Manager(time)					
{
	xrot						= 0.0f;
	t							= 0.0f;	
	direction					= -1;
	beat_responder				= 0.0f;
	bg							= new background();
	timeeffect					= 0;
	multi_texture				=0;
	camera						=	-100;
	scene_switcher				=	-1;

	glClientActiveTextureARB	= NULL;
	glActiveTextureARB			= NULL;

	glActiveTextureARB = ( PFNGLCLIENTACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glActiveTextureARB" );	
	glClientActiveTextureARB = ( PFNGLACTIVETEXTUREARBPROC )wglGetProcAddress  ( "glClientActiveTextureARB" );

	width						= wid;
	height						= hei;
}

scene10::~scene10()					
{
}


void scene10::Draw(GLuint blend_colour,struct winampVisModule *this_mod)
{
	gluLookAt(0, 0, 2+camera,     0, 0, 0,     0, 1, 0);
	
	GLfloat colors[12][3]=																		
	{
		{1.0f,0.5f,0.5f},{1.0f,0.75f,0.5f},{1.0f,1.0f,0.5f},{0.75f,1.0f,0.5f},
		{0.5f,1.0f,0.5f},{0.5f,1.0f,0.75f},{0.5f,1.0f,1.0f},{0.5f,0.75f,1.0f},
		{0.5f,0.5f,1.0f},{0.75f,0.5f,1.0f},{1.0f,0.5f,1.0f},{1.0f,0.5f,0.75f}
	};	

	GLfloat vertices[]=
	{	
		-1.0f,	-1.0f,  0.0f,
		1.0f,	-1.0f,  0.0f,
		1.0f,	1.0f,	0.0f,
		-1.0f,  1.0f,	0.0f
	};

	GLfloat tex_coords[]=
	{
		0.0f, 0.0f,
		1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 1.0f
	};

	GLfloat		colours[]=
	{
		1.0f,1.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,1.0f,
		1.0f,1.0f,1.0f,1.0f,
	};

	GLuint		indices[]={0,1,2,3};

	if (scene_switcher<=15)
	{
			glActiveTextureARB		( GL_TEXTURE0_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
			glEnable(GL_TEXTURE_GEN_S);
			glEnable(GL_TEXTURE_GEN_T);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
			glEnable(GL_BLEND);
			glDisable(GL_DEPTH_TEST);
			 
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB		( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_EYE_LINEAR);
			
			glEnable(GL_BLEND);
			glDisable(GL_TEXTURE_GEN_S);																
			glDisable(GL_TEXTURE_GEN_T);	
			glDisable(GL_DEPTH_TEST);
			glEnable(GL_BLEND);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	}
	else
	{
			glActiveTextureARB		( GL_TEXTURE0_ARB );
			glEnable(GL_TEXTURE_2D);
			glDisable(GL_TEXTURE_GEN_S);
			glDisable(GL_TEXTURE_GEN_T);
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			glDisable(GL_BLEND);
			glEnable(GL_DEPTH_TEST);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[0] );
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE );

			glActiveTextureARB		( GL_TEXTURE1_ARB ); 
			glEnable(GL_TEXTURE_2D);
			glBindTexture			( GL_TEXTURE_2D, m_Texture[1] );
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
			
			glEnable(GL_BLEND);
			glEnable(GL_TEXTURE_GEN_S);																
			glEnable(GL_TEXTURE_GEN_T);	
			glDisable(GL_DEPTH_TEST);
			glTexEnvi				( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_BLEND);

	}
	glClientActiveTextureARB ( GL_TEXTURE0_ARB             ); 
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords ); 
   
	glClientActiveTextureARB ( GL_TEXTURE1_ARB             );  
	glTexCoordPointer        ( 2, GL_FLOAT, 0, &tex_coords );

	glEnableClientState ( GL_VERTEX_ARRAY );
	glEnableClientState ( GL_COLOR_ARRAY );
	glEnableClientState ( GL_TEXTURE_COORD_ARRAY );


	glVertexPointer ( 3, GL_FLOAT, 0, &vertices );

	glPushMatrix();
		for (int k=0;k<beat_responder;k++)
		{
			glPushMatrix();		
				glTranslatef((float)(beat_responder/40*sin(k*t)),(float)(beat_responder/40*cos(k*t)),-2*(float)(k*t));
				glRotatef(float(k*beat_responder/2),0.0f,0.0f,1.0f);
				glPushMatrix();
					glRotatef(beat_responder+1.0f,0.0f,0.0f,1.0f);
					glTranslatef(3.0f+(beat_responder/20), 2.0f, -5.0f+(beat_responder/10));										
					int t=rand()%11;
					for (int c=0;c<15;c+=4)
					{
						colours[c	]=colors[t][0];
						colours[c+1	]=colors[t][1];
						colours[c+2	]=colors[t][2];
					}
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();
				glPopMatrix();
				glPushMatrix();
					glTranslatef(-3.0f-(beat_responder/20), 2.0f, -10.0f+(beat_responder/10));								
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();
				glPopMatrix();
				glPushMatrix();
					glTranslatef(-3.0f-(beat_responder/20), -2.0f, -10.0f+(beat_responder/10));				
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();						
				glPopMatrix();

				glPushMatrix();
					glTranslatef(3.0f+(beat_responder/20), -2.0f, -20.0f+(beat_responder/10));				
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();
				glPopMatrix();
				t=rand()%11;
					for (c=0;c<15;c+=4)
					{
						colours[c	]=colors[t][0];
						colours[c+1	]=colors[t][1];
						colours[c+2	]=colors[t][2];
					}
				glPushMatrix();
					glRotatef(2*beat_responder,0.0f,0.0f,1.0f);
					glTranslatef(0.0f, 0.0f, -15.0f+(beat_responder/10)-k);				
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();
				glPopMatrix();
				float radius=2.0f;
				for (int j=1;j<9;j++)
				{
					glPushMatrix();
						glRotatef(2*beat_responder,0.0f,0.0f,1.0f);
						int t=rand()%11;
					for (int c=0;c<15;c+=4)
					{
						colours[c	]=colors[t][0];
						colours[c+1	]=colors[t][1];
						colours[c+2	]=colors[t][2];
					}
						float pos_x=radius*float(cos((2*3.14/8)*j))*(beat_responder/40)+3*(float)sin(t);
						float pos_y=radius*float(sin((2*3.14/8)*j))*(beat_responder/60)+2*(float)sin(t);
						glTranslatef(pos_x,pos_y, -3.0f-(beat_responder/40));				
						glPushMatrix();
							glScalef(0.5f,0.5f,0.5f);
							glColorPointer  ( 4, GL_FLOAT, 0, &colours );
							glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
						glPopMatrix();
					glPopMatrix();
				}


			glPopMatrix();

			glPushMatrix();		
				glTranslatef(0.0f,0.0f,-30.0f);
				glRotatef(float(k*beat_responder/2),0.0f,0.0f,1.0f);
				glPushMatrix();
					glTranslatef(3.0f+(beat_responder/20), 2.0f, -20.0f+(beat_responder/5));								
					t=rand()%11;
					for (c=0;c<15;c+=4)
					{
						colours[c	]=colors[t][0];
						colours[c+1	]=colors[t][1];
						colours[c+2	]=colors[t][2];
					}
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();
				glPopMatrix();
				glPushMatrix();
					glTranslatef(-3.0f-(beat_responder/20), 2.0f, -20.0f+(beat_responder/5));								
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();
				glPopMatrix();
				glPushMatrix();
					glTranslatef(-3.0f-(beat_responder/20), -2.0f, -20.0f+(beat_responder/5));				
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();						
				glPopMatrix();

				glPushMatrix();
					glTranslatef(3.0f+(beat_responder/20), -2.0f, -20.0f+(beat_responder/5));				
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();
				glPopMatrix();
				t=rand()%11;
					for (c=0;c<15;c+=4)
					{
						colours[c	]=colors[t][0];
						colours[c+1	]=colors[t][1];
						colours[c+2	]=colors[t][2];
					}
				glPushMatrix();
					glTranslatef(0.0f, 0.0f, -20.0f+(beat_responder/10)-k);				
					glPushMatrix();
						glScalef(0.5f,0.5f,0.5f);
						glColorPointer  ( 4, GL_FLOAT, 0, &colours );
						glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
					glPopMatrix();
				glPopMatrix();
				for (j=1;j<9;j++)
				{
					glPushMatrix();
						float pos_x=radius*float(cos((2*3.14/8)*j))*(float)(beat_responder/20)+3*(float)sin(2*t);
						float pos_y=radius*float(sin((2*3.14/8)*j))*(float)(beat_responder/30)+2*(float)sin(2*t);
						glRotatef(2*beat_responder,0.0f,0.0f,1.0f);
						glTranslatef(pos_x,pos_y, -3.0f-(beat_responder/40));				
						int t=rand()%11;
						for (int c=0;c<15;c+=4)
						{
							colours[c	]=colors[t][0];
							colours[c+1	]=colors[t][1];
							colours[c+2	]=colors[t][2];
						}
						glPushMatrix();
							glScalef(0.5f,0.5f,0.5f);
							glColorPointer  ( 4, GL_FLOAT, 0, &colours );
							glDrawElements  ( GL_QUADS, 4, GL_UNSIGNED_INT, &indices );
						glPopMatrix();
					glPopMatrix();
				}


			glPopMatrix();
			
		}
	glPopMatrix();	
}

void scene10::Update(float beat_help,struct winampVisModule *this_mod,float beat_scaler,bool Tex_on)
{
	if (timeeffect<16)
		fadeffect+=0.1f;
	else
		fadeffect-=0.1f;

	timeeffect=(GetTickCount()-SceneStart)/1000;
	beat_responder=beat_help*beat_scaler;
	xrot+=direction*((beat_responder/20)*(beat_responder/20))+1.0f;
	t+=0.01f*direction;
	if (t>1.5*beat_responder/16)	
		direction=-1;
	if (t<-1.5*beat_responder/16)
		direction=1;
}

bool scene10::Init(loadall		*textures)
{
	glDisable(GL_FOG);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_COLOR_MATERIAL);									
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);												
	glDisable(GL_LIGHT0);                             
	glDisable(GL_LIGHTING);

	glClientActiveTextureARB	( GL_TEXTURE0_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );
   
	glClientActiveTextureARB	( GL_TEXTURE1_ARB        );    
	glEnableClientState			( GL_TEXTURE_COORD_ARRAY );

	SceneStart		= GetTickCount();
	fadeffect		= 0;

	multi_texture=rand()%16;
	scene_switcher=rand()%30;

	switch (multi_texture)
	{
		case 0:
			m_Texture[0]=textures->Bind(5);
			m_Texture[1]=textures->Bind(6);
		break;
		case 1:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(1);
		break;
		case 2:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(2);
		break;
		case 3:
			m_Texture[0]=textures->Bind(5);
			m_Texture[1]=textures->Bind(3);
		break;
		case 4:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(4);
		break;
		case 5:
			m_Texture[0]=textures->Bind(3);
			m_Texture[1]=textures->Bind(0);
		break;
		case 6:
			m_Texture[0]=textures->Bind(5);
			m_Texture[1]=textures->Bind(10);
		break;
		case 7:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(11);
		break;
		case 8:
			m_Texture[0]=textures->Bind(5);
			m_Texture[1]=textures->Bind(12);
		break;
		case 9:
			m_Texture[0]=textures->Bind(6);
			m_Texture[1]=textures->Bind(13);
		break;
		case 10:
			m_Texture[0]=textures->Bind(14);
			m_Texture[1]=textures->Bind(6);
		break;
		case 11:
			m_Texture[0]=textures->Bind(15);
			m_Texture[1]=textures->Bind(6);
		break;
		case 12:
			m_Texture[0]=textures->Bind(16);
			m_Texture[1]=textures->Bind(6);
		break;
		case 13:
			m_Texture[0]=textures->Bind(17);
			m_Texture[1]=textures->Bind(6);
		break;
		case 14:
			m_Texture[0]=textures->Bind(18);
			m_Texture[1]=textures->Bind(6);
		break;
		case 15:
			m_Texture[0]=textures->Bind(19);
			m_Texture[1]=textures->Bind(6);
		break;
	}
	/*multi_texture=rand()%16;
	if (multi_texture==16)
		multi_texture=0;
	scene_switcher=rand()%30;
	if (scene_switcher==30)
		scene_switcher=0;*/
	return true;
}

