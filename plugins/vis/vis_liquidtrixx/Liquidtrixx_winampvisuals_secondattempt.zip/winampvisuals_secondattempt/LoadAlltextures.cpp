#include "headers.h"
#include "LoadAlltextures.h"

loadall::loadall(struct winampVisModule *this_mod)					
{
	getfilename("Liquid\\Liquid1.jpg",this_mod,0);
	getfilename("Liquid\\Liquid2.jpg",this_mod,1);
	getfilename("Liquid\\Liquid3.jpg",this_mod,2);
	getfilename("Liquid\\Liquid4.jpg",this_mod,3);
	getfilename("Liquid\\Liquid5.jpg",this_mod,4);
	getfilename("Liquid\\Liquid6.jpg",this_mod,5);
	getfilename("Liquid\\Liquid7.jpg",this_mod,6);
	getfilename("Liquid\\Liquid8.jpg",this_mod,7);
	getfilename("Liquid\\Liquid9.jpg",this_mod,8);
	getfilename("Liquid\\Liquid10.jpg",this_mod,9);
	getfilename("Liquid\\Liquid11.jpg",this_mod,10);
	getfilename("Liquid\\Liquid12.jpg",this_mod,11);
	getfilename("Liquid\\Liquid13.jpg",this_mod,12);
	getfilename("Liquid\\Liquid14.jpg",this_mod,13);
	getfilename("Liquid\\Liquid15.jpg",this_mod,14);
	getfilename("Liquid\\Liquid16.jpg",this_mod,15);
	getfilename("Liquid\\Liquid17.jpg",this_mod,16);
	getfilename("Liquid\\Liquid18.jpg",this_mod,17);
	getfilename("Liquid\\Liquid19.jpg",this_mod,18);
	getfilename("Liquid\\Liquid20.jpg",this_mod,19);
	getfilename("Liquid\\Liquid21.jpg",this_mod,20);
	getfilename("Liquid\\Liquid22.jpg",this_mod,21);
	getfilename("Liquid\\Liquid23.jpg",this_mod,22);
}

loadall::~loadall()
{					
}

GLuint loadall::Bind(int number)
{	
	return m_Texture[number];
}

GLuint loadall::EmptyTexture()									// Create An Empty Texture
{
	GLuint txtnumber;											// Texture ID
	unsigned int* data;											// Stored Data

	// Create Storage Space For Texture Data (128x128x4)
	data = (unsigned int*)new GLuint[((128 * 128)* 4 * sizeof(unsigned int))];
	ZeroMemory(data,((128 * 128)* 4 * sizeof(unsigned int)));	// Clear Storage Memory

	glGenTextures(1, &txtnumber);								// Create 1 Texture
		glBindTexture(GL_TEXTURE_2D, txtnumber);					// Bind The Texture
		glTexImage2D(GL_TEXTURE_2D, 0, 4, 128, 128, 0,
		GL_RGBA, GL_UNSIGNED_BYTE, data);						// Build Texture Using Information In data
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

	delete [] data;												// Release data

	return txtnumber;											// Return The Texture ID
}

void loadall::getfilename(LPSTR strFileName,struct winampVisModule *this_mod,int id)
{
	char *ini_file=new char[70];
	char *help=new char[70];
	char *p;
	GetModuleFileName(this_mod->hDllInstance,ini_file,MAX_PATH);
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) 
		*p = 0;
	strcpy(help,ini_file);
	strcat(help,strFileName);

	JPEG_Texture(m_Texture,help,id);
}

