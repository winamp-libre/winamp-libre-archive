/*  SoundScape -- winamp visual plugin in C++, with OpenGL

    Copyright (C) 2002-2003 Dan Medeiros

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/************************************
 *   Includes                       *
 ************************************/
#include <windows.h> 
#include <gl\gl.h> 
#include <gl\glu.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <math.h> 
#include <string.h>
#include <time.h>

#include "vis.h" 

/************************************
 *   Constants                      *
 ************************************/
#define PI 3.1415926535897932384626433

// Background Scope Texture
#define SCOPE_TEX_ID        1
#define SCOPE_TEX_SCALE     2
#define SCOPE_TEX_WIDTH  (256 * SCOPE_TEX_SCALE)
#define SCOPE_TEX_HEIGHT (256 * SCOPE_TEX_SCALE)
#define SCOPE_FADE_AMNT     0.995 // multiplier for fade
#define SCOPE_FADE_RATE     1     // distance for fade, in pixels, per frame
#define SCOPE_SMOOTH_DIST   2     // x-length of each line in pixels

// Line Drawing
#define LINE_THICK     6
#define N_ROWS         SCOPE_TEX_HEIGHT
#define N_COLS         SCOPE_TEX_WIDTH
#define VIEWX0         0
#define VIEWY0         0
#define VIEWX1         SCOPE_TEX_HEIGHT
#define VIEWY1         SCOPE_TEX_WIDTH
#define TRUE           1
#define FALSE          0

// Colors/Color Fading
#define COLOR_CHANGE_RATE 1

// Fractal Terrain
#define TERRAIN_TEX_ID        2
#define TERRAIN_TEX_WIDTH     1
#define TERRAIN_TEX_HEIGHT    1
#define TERRAIN_NUM_SUBDIVS   4   // number of fractal iterations
#define TERRAIN_BASE_DEPTH    0.01
#define TERRAIN_BASE_WIDTH    1.6
#define TERRAIN_NUM_BASES     40
#define TERRAIN_MAX_HEIGHT    0.2
#define TERRAIN_WIDTH_NOISE   0.25
#define TERRAIN_DEPTH_NOISE   0.25
#define TERRAIN_HEIGHT_NOISE  0.05
                                   // pseudo-constants, calculated once
float TERRAIN_X_DIST = TERRAIN_BASE_WIDTH/(pow(2, TERRAIN_NUM_SUBDIVS));
float TERRAIN_Y_DIST = TERRAIN_BASE_DEPTH/(pow(2, TERRAIN_NUM_SUBDIVS));
int TERRAIN_PTS_ACROSS = pow(2,TERRAIN_NUM_SUBDIVS)+1;

// Spectrum Sphere
#define SPHERE_ROTATE_SPEED   3
#define SPHERE_SMOOTH_DIST    50
#define SPHERE_BASE_RADIUS    0.35
#define SPHERE_SPIKE_RADIUS   0.2
                                   // pseudo-constants, calculated once
float SPHERE_CYL_HEIGHT = SPHERE_BASE_RADIUS / 144;

/************************************
 *   Function Dec's                 *
 ************************************/
// our window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// window setup functions

// Plugin Function Dec's
// "member" functions
winampVisModule *getModule(int which);
void config(struct winampVisModule *this_mod); // configuration dialog
int init(struct winampVisModule *this_mod);	   // initialization for module
int redraw(struct winampVisModule *this_mod);  // rendering for module
void quit(struct winampVisModule *this_mod);   // deinitialization for module
void config_read(struct winampVisModule *this_mod);		// reads the configuration
void config_write(struct winampVisModule *this_mod);	// writes the configuration
void config_getinifn(struct winampVisModule *this_mod, char *ini_file); // makes the .ini file filename

// vis functions
static void drawTerrain(struct winampVisModule *this_mod);
static void drawSphere(struct winampVisModule *this_mod);
static void genBackgroundTexture(struct winampVisModule *this_mod);

// linedrawing functions
void drawLine(int x1, int y1, int x2, int y2, unsigned char * pixeldata);
void setPixel(int x, int y, unsigned char * pixeldata);
void lineClip(float x1, float y1, float x2, float y2, unsigned char * pixeldata);
void findT(double denom, double num, double *tE, double *tL);

// general utility functions
void getNorm(float x1, float y1, float z1, float x2, float y2, float z2, float* nx, float* ny, float* nz);
float dotProd(float x1, float y1, float z1, float x2, float y2, float z2);

/************************************
 *   Global Var's and Class Dec's   *
 ************************************/
// Standard Windows vars
HDC hDC;
HGLRC hGLRC;
HPALETTE hPalette;
HWND hMainWnd; // main window handle
int winHeight = 350;
int winWidth = 350;
int config_x = 50;
int config_y = 50;

// Plugin vars
char szAppName[] = "SoundScape";

// Module header, includes version, description, and address of the module retriever function
winampVisHeader hdr = { VIS_HDRVER, "SoundScape beta", getModule };

// module (soundscape)
winampVisModule mod1 = {
	"Soundscape",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	0,		// sRate
	0,		// nCh
	25,		// latencyMS
	25,		// delayMS
	2,		// spectrumNch
	2,		// waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config,
	init,
	redraw, 
	quit
};

// background texture vars
unsigned char * backgroundScopeTexture;
unsigned char blankScopeTexture[SCOPE_TEX_HEIGHT*SCOPE_TEX_WIDTH*3] = {0,};
unsigned char scopeTexBuff[2][SCOPE_TEX_HEIGHT*SCOPE_TEX_WIDTH*3];
int currTexBuff = 0;

// terrain texture
unsigned char terrainTexture[3] = {40, 40, 40};
GLUquadric * quadric;

// fractal terrain
typedef struct Point_3d_f {
	float x;
	float y;
	float z;   
} Point_3d_f;

// due to the nature of the fractal:
//
//  ----------        ----------
//  |         |       |____|____|
//  |         |  ->   |    |    |
//   ----------        ----------
//
//   we will have 4^n quads, for each division, and the
//   base area will have (2^n + 1) by (2^n + 1)
//  
//   this structure stores x/y/z offsets for each point
Point_3d_f** terrain[TERRAIN_NUM_BASES];

// sphere
double baseCylRadius[290];
double spikeCylRadius[290];
double sinScale[SPHERE_SMOOTH_DIST];
int currRotate = 0;

// colors
typedef struct Color_RGB_UC {
	unsigned char red;
	unsigned char green;
	unsigned char blue;
} Color_RGB_UC;

Color_RGB_UC col1 = {255, 0, 0};
Color_RGB_UC col2 = {255, 128, 0};
Color_RGB_UC col3 = {0, 255, 0};
Color_RGB_UC col4 = {0, 255, 128};
Color_RGB_UC col5 = {0, 0, 255};
Color_RGB_UC col6 = {128, 0, 255};
Color_RGB_UC col7 = {255, 128, 0};
Color_RGB_UC col8 = {255, 0, 255};
Color_RGB_UC col9 = {255, 255, 0};
Color_RGB_UC col10 = {0, 255, 255};
Color_RGB_UC col11 = {200, 80, 160};
#define NUM_COLORS 11

Color_RGB_UC * colors[NUM_COLORS] = {&col1, &col2, &col3, &col4, &col5, &col6, 
                                 &col7, &col8, &col9, &col10, &col11};

Color_RGB_UC currColor = {200, 200, 200};
Color_RGB_UC drawColor;
int currColorIndex = 0;
int nextColorIndex = 1;


/************************************
 *   Function Def's                 *
 ************************************/
// this is the only exported symbol. returns our main header.
// if you are compiling C++, the extern "C" { is necessary, so we just #ifdef it
#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) winampVisHeader *winampVisGetHeader() {return &hdr;}
#ifdef __cplusplus
}
#endif

// getmodule routine from the main header. Returns NULL if an invalid module was requested,
// otherwise returns either mod1, mod2 or mod3 depending on 'which'.
winampVisModule *getModule(int which) {
	if(which == 0) {
		return &mod1;
	}
	else {
		return NULL;
	}
}

// configuration. Passed this_mod, as a "this" parameter. Allows you to make one configuration
// function that shares code for all your modules (you don't HAVE to use it though, you can make
// config1(), config2(), etc...)
void config(struct winampVisModule *this_mod) {
	MessageBox(this_mod->hwndParent,"SoundScape is Copyright (c) 2002-2003, Dan Medeiros\n",
		       "About SoundScape",MB_OK);
}

// initialization. Registers our window class, creates our window, etc. Again, this one works for
// both modules, but you could make init1() and init2()...
// returns 0 on success, 1 on failure.
int init(struct winampVisModule *this_mod) {
	int i, j;
	int height = winHeight;
	int width = winWidth;

	srand(time(NULL));

	// initialize terrain
	for(i = 0; i < TERRAIN_NUM_BASES; i++) {
		terrain[i] = new Point_3d_f*[TERRAIN_PTS_ACROSS];
		for(int j = 0; j < TERRAIN_PTS_ACROSS; j++) {
			terrain[i][j] = new Point_3d_f[TERRAIN_PTS_ACROSS];
		}
	}

	for(i = 0; i < TERRAIN_NUM_BASES; i++) {
		for(j = 0; j < TERRAIN_PTS_ACROSS; j++) {
			for(int k = 0; k < TERRAIN_PTS_ACROSS; k++) {
				terrain[i][j][k].x = 0;
				terrain[i][j][k].y = 0;
				terrain[i][j][k].z = 0;
			}
		}
	}

	// initialize sphere
	for(i = 0; i < 145; i++) {
		double y = SPHERE_BASE_RADIUS - (SPHERE_CYL_HEIGHT * i);
		double radiusSquared = pow(y, 2.0) - pow(SPHERE_BASE_RADIUS, 2.0);
		if(radiusSquared < 0) {
			radiusSquared = -radiusSquared;
		}
		double radius = sqrt(radiusSquared);

		baseCylRadius[i] = radius;
		baseCylRadius[289 - i] = radius;
	}
	spikeCylRadius[0] = 0;
	spikeCylRadius[289] = 0;
	quadric = gluNewQuadric();
	gluQuadricTexture(quadric, GL_TRUE);

	for(i = 0; i < SPHERE_SMOOTH_DIST; i++) {
		sinScale[i] = (sin(((double(i)/double(SPHERE_SMOOTH_DIST)) * PI) - (PI/2)) / 2.0) + 0.5;
	}

	// initialize terrain texture
	float texcolor[] = {0.2, 0.2, 0.1, 1.0};

	glBindTexture(GL_TEXTURE_2D, TERRAIN_TEX_ID);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, texcolor);
	glTexImage2D (GL_TEXTURE_2D, 
				  0, 
				  GL_RGB, 
				  TERRAIN_TEX_WIDTH, 
				  TERRAIN_TEX_HEIGHT, 
				  0, 
				  GL_RGB, 
				  GL_UNSIGNED_BYTE, 
				  terrainTexture);

	// Register our window class
	WNDCLASS wc;
	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = WndProc;				// our window procedure
	wc.hInstance = this_mod->hDllInstance;	// hInstance of DLL
	wc.lpszClassName = szAppName;			// our window class name
	wc.style = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszMenuName = NULL;
	
	if (!RegisterClass(&wc)) {
		MessageBox(this_mod->hwndParent,"Error registering window class!","ERROR!",MB_OK);
		return 1;
	}

	hMainWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW|WS_EX_APPWINDOW,											// these exstyles put a nice small frame, 
																					// but also a button in the taskbar
		szAppName,																	// our window class name
		this_mod->description,														// use description for a window title
		WS_VISIBLE|WS_SYSMENU|WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN|WS_CLIPSIBLINGS,  // make the window visible with a close button
		config_x,config_y,															// screen position (read from config)
		width,height,																// width & height of window (need to adjust client area later)
		this_mod->hwndParent,														// parent window (winamp main window)
		NULL,																		// no menu
		this_mod->hDllInstance,														// hInstance of DLL
		0);																			// no window creation data

	if (!hMainWnd) {
		MessageBox(this_mod->hwndParent,"Error creating window!","ERROR!",MB_OK);
		return 1;
	}

	SetWindowLong(hMainWnd,GWL_USERDATA,(LONG)this_mod); // set our user data to a "this" pointer
	{	// adjust size of window to make the client area exactly width x height
		RECT r;
		GetClientRect(hMainWnd,&r);
		SetWindowPos(hMainWnd,0,0,0,width*2-r.right,height*2-r.bottom,SWP_NOMOVE|SWP_NOZORDER);
	}

	// show the window
	ShowWindow(hMainWnd,SW_SHOWNORMAL);
	return 0;
}

static void setupOpenGL(void) {
	float position[] = {0.0, 100.0, 200.0, 0.0};
	float ambient[] = {0.2, 0.2, 0.2, 1.0};
	float diffuse[] = {0.5, 0.5, 0.5, 1.0};
	float specular[] = {0.2, 0.2, 0.2, 1.0};
	int shiny = {5};
	float lmamb[] = {0.2,0.2,0.2, 1.0};

	/* set viewing projection */
    glMatrixMode(GL_PROJECTION);
    glFrustum(-0.5F, 0.5F, -0.5F, 0.5F, 1.0F, 3.0F);

    /* position viewer */
    glMatrixMode(GL_MODELVIEW);
    glTranslatef(0.0F, 0.0F, -2.0F);

	glClearColor (0.0, 0.0, 0.0, 0.0);
    glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
    glMateriali (GL_FRONT,GL_SHININESS, shiny);

	glLightfv(GL_LIGHT0, GL_POSITION, position);	
	glLightModelfv (GL_LIGHT_MODEL_AMBIENT, lmamb);

	//glEnable(GL_NORMALIZE);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_COLOR_MATERIAL);
	glShadeModel (GL_SMOOTH);
    
	//glLightfv(GL_LIGHT1, GL_POSITION, position1);
}



int redraw(struct winampVisModule *this_mod) {
	clock_t ts1, ts2;
	ts1 = clock();

    /* clear color and depth buffers */
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// setup texture... unfortunately, need to reload texture each time
	genBackgroundTexture(this_mod);

	glBindTexture(GL_TEXTURE_2D, SCOPE_TEX_ID);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	glTexImage2D (GL_TEXTURE_2D, 
				  0, 
				  GL_RGB, 
				  SCOPE_TEX_WIDTH, 
				  SCOPE_TEX_HEIGHT, 
				  0, 
				  GL_RGB, 
				  GL_UNSIGNED_BYTE, 
				  backgroundScopeTexture);



    /* draw textured background quad */
    glBegin(GL_QUADS);

    glNormal3f( 0.0F, 0.0F, 1.0F);
	glTexCoord2f(1.0F, 1.0F);
    glVertex3f( 0.75F, 0.75F, 0.5F); 
	glTexCoord2f(0.0F, 1.0F);
	glVertex3f(-0.75F, 0.75F, 0.5F);
	glTexCoord2f(0.0F, 0.0F);
    glVertex3f(-0.75F,-0.95F, 0.5F); 
	glTexCoord2f(1.0F, 0.0F);
	glVertex3f( 0.75F,-0.95F, 0.5F);

    glEnd();

	/* draw fractal terrain */ 
	drawTerrain(this_mod); 

	/* draw sphere */
	drawSphere(this_mod);

    SwapBuffers(hDC);

	ts2 = clock();
	this_mod->latencyMs = (ts2 - ts1)/(CLOCKS_PER_SEC / 1000);

	return 0;
}

void resize(void)
{
    /* set viewport to cover the window */
    glViewport(0, 0, winWidth, winHeight);
}

void setupPixelFormat(HDC hDC)
{
    PIXELFORMATDESCRIPTOR pfd = {
        sizeof(PIXELFORMATDESCRIPTOR),  /* size */
        1,                              /* version */
        PFD_SUPPORT_OPENGL |
        PFD_DRAW_TO_WINDOW |
        PFD_DOUBLEBUFFER,               /* support double-buffering */
        PFD_TYPE_RGBA,                  /* color type */
        16,                             /* prefered color depth */
        0, 0, 0, 0, 0, 0,               /* color bits (ignored) */
        0,                              /* no alpha buffer */
        0,                              /* alpha bits (ignored) */
        0,                              /* no accumulation buffer */
        0, 0, 0, 0,                     /* accum bits (ignored) */
        16,                             /* depth buffer */
        0,                              /* no stencil buffer */
        0,                              /* no auxiliary buffers */
        PFD_MAIN_PLANE,                 /* main layer */
        0,                              /* reserved */
        0, 0, 0,                        /* no layer, visible, damage masks */
    };
    int pixelFormat;

    pixelFormat = ChoosePixelFormat(hDC, &pfd);
    if (pixelFormat == 0) {
        MessageBox(WindowFromDC(hDC), "ChoosePixelFormat failed.", "Error",
                MB_ICONERROR | MB_OK);
        exit(1);
    }

    if (SetPixelFormat(hDC, pixelFormat, &pfd) != TRUE) {
        MessageBox(WindowFromDC(hDC), "SetPixelFormat failed.", "Error",
                MB_ICONERROR | MB_OK);
        exit(1);
    }
}

void setupPalette(HDC hDC)
{
    int pixelFormat = GetPixelFormat(hDC);
    PIXELFORMATDESCRIPTOR pfd;
    LOGPALETTE* pPal;
    int paletteSize;

    DescribePixelFormat(hDC, pixelFormat, sizeof(PIXELFORMATDESCRIPTOR), &pfd);

    if (pfd.dwFlags & PFD_NEED_PALETTE) {
        paletteSize = 1 << pfd.cColorBits;
    } else {
        return;
    }

    pPal = (LOGPALETTE*)
        malloc(sizeof(LOGPALETTE) + paletteSize * sizeof(PALETTEENTRY));
    pPal->palVersion = 0x300;
    pPal->palNumEntries = paletteSize;

    /* build a simple RGB color palette */
    {
        int redMask = (1 << pfd.cRedBits) - 1;
        int greenMask = (1 << pfd.cGreenBits) - 1;
        int blueMask = (1 << pfd.cBlueBits) - 1;
        int i;

        for (i=0; i<paletteSize; ++i) {
            pPal->palPalEntry[i].peRed =
                    (((i >> pfd.cRedShift) & redMask) * 255) / redMask;
            pPal->palPalEntry[i].peGreen =
                    (((i >> pfd.cGreenShift) & greenMask) * 255) / greenMask;
            pPal->palPalEntry[i].peBlue =
                    (((i >> pfd.cBlueShift) & blueMask) * 255) / blueMask;
            pPal->palPalEntry[i].peFlags = 0;
        }
    }

    hPalette = CreatePalette(pPal);
    free(pPal);

    if (hPalette) {
        SelectPalette(hDC, hPalette, FALSE);
        RealizePalette(hDC);
    }
}

// render function for oscilliscope. Returns 0 if successful, 1 if visualization should end.
int render(struct winampVisModule *this_mod) {
	return 0;
}

// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quit(struct winampVisModule *this_mod)
{
	config_write(this_mod);		// write configuration
//	SelectObject(memDC,oldBM);	// delete our doublebuffer
//	DeleteObject(memDC);
//	DeleteObject(memBM);	
	DestroyWindow(hMainWnd); // delete our window
	UnregisterClass(szAppName,this_mod->hDllInstance); // unregister window class
}


// window procedure for our window
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_CREATE:
			{
				/* initialize OpenGL rendering */
				hDC = GetDC(hWnd);
				setupPixelFormat(hDC);
				setupPalette(hDC);
				hGLRC = wglCreateContext(hDC);
				wglMakeCurrent(hDC, hGLRC);
				setupOpenGL();
				return 0;
			}
		case WM_ERASEBKGND: return 0;
		case WM_DESTROY:
			{
		        /* finish OpenGL rendering */
		        if (hGLRC) {
	            wglMakeCurrent(NULL, NULL);
		        wglDeleteContext(hGLRC);
				}
				if (hPalette) {
			        DeleteObject(hPalette);
				}
			    ReleaseDC(hWnd, hDC);

				// delete terrain
				for(int i = 0; i < TERRAIN_NUM_BASES; i++) {
					for(int j = 0; j < TERRAIN_PTS_ACROSS; j++) {
						delete [] terrain[i][j];
					}
					delete [] terrain[i];
				}

				// delete sphere
				gluDeleteQuadric(quadric);

				PostQuitMessage(0);
				return 0;
			}	
		case WM_KEYDOWN: // pass keyboard messages to main winamp window (for processing)
		case WM_KEYUP:
			{	// get this_mod from our window's user data
				winampVisModule *this_mod = (winampVisModule *) GetWindowLong(hWnd,GWL_USERDATA);
				PostMessage(this_mod->hwndParent,message,wParam,lParam);
				return 0;
			}
		case WM_MOVE:
			{	// get config_x and config_y for configuration
				RECT r;
				GetWindowRect(hMainWnd,&r);
				config_x = r.left;
				config_y = r.top;
				return 0;
			}
		case WM_SIZE:
			{
				/* track window size changes */
				if (hGLRC) {
	            winWidth = (int) LOWORD(lParam);
		        winHeight = (int) HIWORD(lParam);
			    resize();
				return 0;
				}
			}
		case WM_PALETTECHANGED:
			{
				/* realize palette if this is *not* the current window */
			    if (hGLRC && hPalette && (HWND) wParam != hWnd) {
				    UnrealizeObject(hPalette);
			        SelectPalette(hDC, hPalette, FALSE);
				    RealizePalette(hDC);
					redraw(getModule(0));
					break;
		        }
			    break;
			}
		case WM_QUERYNEWPALETTE:
			{
				/* realize palette if this is the current window */
		        if (hGLRC && hPalette) {
			        UnrealizeObject(hPalette);
				    SelectPalette(hDC, hPalette, FALSE);
					RealizePalette(hDC);
		            redraw(getModule(0));
			        return TRUE;
				}
				break;
			}
	    case WM_PAINT:
		    {
			    PAINTSTRUCT ps;
				BeginPaint(hWnd, &ps);
	            if (hGLRC) {
		            redraw(getModule(0));
			    }
				EndPaint(hWnd, &ps);
	            return 0;
		    }
	}
	return DefWindowProc(hWnd,message,wParam,lParam);
}


void config_getinifn(struct winampVisModule *this_mod, char *ini_file)
{	// makes a .ini file in the winamp directory named "plugin.ini"
	char *p;
	GetModuleFileName(this_mod->hDllInstance,ini_file,MAX_PATH);
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	strcat(ini_file,"plugin.ini");
}


void config_read(struct winampVisModule *this_mod)
{
	char ini_file[MAX_PATH];
	config_getinifn(this_mod,ini_file);
	config_x = GetPrivateProfileInt(this_mod->description,"Screen_x",config_x,ini_file);
	config_y = GetPrivateProfileInt(this_mod->description,"Screen_y",config_y,ini_file);
}

void config_write(struct winampVisModule *this_mod)
{
	char string[32];
	char ini_file[MAX_PATH];

	config_getinifn(this_mod,ini_file);

	wsprintf(string,"%d",config_x);
	WritePrivateProfileString(this_mod->description,"Screen_x",string,ini_file);
	wsprintf(string,"%d",config_y);
	WritePrivateProfileString(this_mod->description,"Screen_y",string,ini_file);
}

void drawLine(int x1, int y1, int x2, int y2, unsigned char * pixeldata) {
  int dx, dy;
  int curX, curY, lastX, lastY;
  int p;
  int twoDy, twoDyDx, twoDx, twoDxDy;

  //slope m is -1<m<1
  if(abs(x1 - x2) > abs(y1 - y2)) {
    if(x1 > x2) {
      curX = x2;
      curY = y2;
      lastX = x1;
      dx = x1 - x2;
      dy = y1 - y2;
    }
    else {
      curX = x1;
      curY = y1;
      lastX = x2;
      dx = x2 - x1;
      dy = y2 - y1;
    }
    
    p = 2 * dy - dx;
    twoDy = 2 * dy;
    twoDyDx = 2 * (abs(dy) - abs(dx));
    

    setPixel(curX, curY, pixeldata);
    
    while(curX < lastX) {
      curX++;
      if (p < 0) {
	if (dy < 0) {
	  curY--;
	  p -= twoDyDx;
	}
	else {
	  p += twoDy;
	}
      }
      else {
	if (dy > 0) {
	  curY++; 
	  p += twoDyDx;
	}
	else {
	  p += twoDy;
	}
      }
      
      setPixel(curX, curY, pixeldata);
    }
  }
  //if slope m is >1 or <-1
  else {
    if(y1 > y2) {
      curY = y2;
      curX = x2;
      lastY = y1;
      dy = y1 - y2;
      dx = x1 - x2;
    }
    else {
      curY = y1;
      curX = x1;
      lastY = y2;
      dy = y2 - y1;
      dx = x2 - x1;
    }
    
    p = 2 * dx - dy;
    twoDx = 2 * dx;
    twoDxDy = 2 * (abs(dx) - abs(dy));
    
    setPixel(curX, curY, pixeldata);
    
    while(curY < lastY) {
      curY++;
      if (p < 0) {
	if (dx < 0) {
	  curX--;
	  p -= twoDxDy;
	}
	else {
	  p += twoDx;
	}
      }
      else {
	if (dx > 0) {
	  curX++; 
	  p += twoDxDy;
	}
	else {
	  p += twoDx;
	}
      }
      
      setPixel(curX, curY, pixeldata);
    }
  }
}
 
void setPixel(int x, int y, unsigned char * pixeldata) {
  int index;

  for(int i = 0; i < LINE_THICK; i++) {
	  for(int j = 0; j < LINE_THICK; j++) {
		  //multiply by 3 for 3 color bytes
		  index = ((N_COLS * (y+i)) + (x+j)) * 3;
		  pixeldata[index] = drawColor.red;
		  pixeldata[index+1] = drawColor.green;
		  pixeldata[index+2] = drawColor.blue;
	  }
  }
}
  
void lineClip(double x1, double  y1, double x2, double  y2, unsigned char * pixeldata) {
  double dx = x2 - x1;
  double dy = y2 - y1;
  double tE = 0.0;
  double tL = 1.0;
  double denom;
  double num;
  int i;

  //normals for the sides
  //start at left vertical, go clockwise 
  double nx[4] = {-1, 0, 1, 0};
  double ny[4] = {0, 1, 0, -1};

  //points for the sides
  //start at left vertical, go clockwise
  int px[4] = {VIEWX0, VIEWX1, VIEWX1, VIEWX0};
  int py[4] = {VIEWY0, VIEWY1, VIEWY1, VIEWY0};

  // draw if obviously inside area
  if((x1 >= VIEWX0) &&
     (x1 <= VIEWX1) &&
     (x2 >= VIEWX0) &&
     (x2 <= VIEWX1) &&
     (y1 >= VIEWY0) &&
     (y1 <= VIEWY1) &&
     (y2 >= VIEWY0) &&
     (y2 <= VIEWY1)) {
    drawLine((int) x1, (int) y1, (int) x2, (int) y2, pixeldata);
    return;
  }

  // clip the segment against each edge of the view window
  //start at left vertical, go clockwise 
  for (i = 0; i < 4; i++) {
    // denom is -N . D; num is N . (Po-Pei)
    denom = - nx[i] * dx - ny[i] * dy;
    num = nx[i] * (x1 - px[i]) + ny[i] * (y1 - py[i]);
    findT(denom, num, &tE, &tL);
  }
  
  // compute clipped end points
  if((tE < tL) && ((tL < 1) || (tE > 0)) ) {
    if (tL < 1) {
      x2 = x1 + tL*dx;
      y2 = y1 + tL*dy;
    }
    if (tE > 0) {
      x1 =  x1 + tE*dx;
      y1 =  y1 + tE*dy;
    }
    //draw clipped line
    drawLine((int) x1, (int) y1, (int) x2, (int) y2, pixeldata);
  }
}

void findT(double denom, double num, double *tE, double *tL) {
  double t;

  if (denom < 0) {
    t = num / denom;
    if(!((t > 1)||(t < 0)) && (t < *tL)) {
      *tL = t;
    }
  } 
  else if (denom > 0) {
    t = num / denom;
    if(!((t > 1)||(t < 0)) && (t > *tE)) {
      *tE = t;
    }
  } 
}

static void genBackgroundTexture(struct winampVisModule *this_mod) {
	int i;

	// check for first run
	if(!backgroundScopeTexture) {
		// init our background to blank data if none there, set up texture buffers
		memcpy(scopeTexBuff, blankScopeTexture, sizeof(unsigned char) * SCOPE_TEX_WIDTH * SCOPE_TEX_HEIGHT * 3);
		memcpy(&(scopeTexBuff[1][0]), blankScopeTexture, sizeof(unsigned char) * SCOPE_TEX_WIDTH * SCOPE_TEX_HEIGHT * 3);

		currTexBuff = 0;
		backgroundScopeTexture = &(scopeTexBuff[currTexBuff][0]);
	}

	// get waveform!
	unsigned char waveformData[576];
	memcpy(waveformData, this_mod->waveformData[0], sizeof(unsigned char) * 576);

	/*************** shift old texture up ***************/
	// fade old texture
	for(i = 0; i < (SCOPE_TEX_WIDTH*SCOPE_TEX_HEIGHT*3); i++) {
		backgroundScopeTexture[i] *= SCOPE_FADE_AMNT;
	}

	//first, figure out new buffer
	unsigned char * tex;
	if(currTexBuff == 0) {
		tex = &(scopeTexBuff[1][0]);
		currTexBuff = 1;
	}
	else {
		tex = &(scopeTexBuff[0][0]);
		currTexBuff = 0;
	}

	// do the shift
	memcpy(tex, blankScopeTexture, sizeof(unsigned char) * SCOPE_TEX_WIDTH * SCOPE_TEX_HEIGHT * 3);
	memcpy(tex + (sizeof(unsigned char) * SCOPE_FADE_RATE * SCOPE_TEX_WIDTH * 3), 
		   backgroundScopeTexture, 
		   sizeof(unsigned char) * (SCOPE_TEX_WIDTH * (SCOPE_TEX_HEIGHT - SCOPE_FADE_RATE) * 3));
	backgroundScopeTexture = tex;

	/**************** draw new waveform ******************/
	// get volume multiplier
	float volume = 1.0;

/* volume modding doesn't look very pretty -> disabled
	float total = 0;

	int last=waveformData[0];
	for (int x = 1; x < 576; x ++) {
		total += abs(last - waveformData[x]);
		last = waveformData[x];
	}
	total /= 288;
	if (total > 127) total = 127;
	volume = total / 127;
*/

	// check for color change
	if(currColor.red == colors[nextColorIndex]->red &&
	   currColor.green == colors[nextColorIndex]->green &&
	   currColor.blue == colors[nextColorIndex]->blue) {
		currColorIndex = nextColorIndex;
		nextColorIndex = (currColorIndex + 1) % NUM_COLORS;
	}
	// do color fade, if need to
	//red
	if(currColor.red != colors[nextColorIndex]->red) {
		if(currColor.red > colors[nextColorIndex]->red) {
			if((currColor.red - colors[nextColorIndex]->red) < COLOR_CHANGE_RATE) {
				currColor.red = colors[nextColorIndex]->red;
			}
			else {
				currColor.red -= COLOR_CHANGE_RATE;
			}
		}
		else {
			if((colors[nextColorIndex]->red - currColor.red) < COLOR_CHANGE_RATE) {
				currColor.red = colors[nextColorIndex]->red;
			}
			else {
				currColor.red += COLOR_CHANGE_RATE;
			}
		}
	}
	//green
	if(currColor.green != colors[nextColorIndex]->green) {
		if(currColor.green > colors[nextColorIndex]->green) {
			if((currColor.green - colors[nextColorIndex]->green) < COLOR_CHANGE_RATE) {
				currColor.green = colors[nextColorIndex]->green;
			}
			else {
				currColor.green -= COLOR_CHANGE_RATE;
			}
		}
		else {
			if((colors[nextColorIndex]->green - currColor.green) < COLOR_CHANGE_RATE) {
				currColor.green = colors[nextColorIndex]->green;
			}
			else {
				currColor.green += COLOR_CHANGE_RATE;
			}
		}
	}
	//blue
	if(currColor.blue != colors[nextColorIndex]->blue) {
		if(currColor.blue > colors[nextColorIndex]->blue) {
			if((currColor.blue - colors[nextColorIndex]->blue) < COLOR_CHANGE_RATE) {
				currColor.blue = colors[nextColorIndex]->blue;
			}
			else {
				currColor.blue -= COLOR_CHANGE_RATE;
			}
		}
		else {
			if((colors[nextColorIndex]->blue - currColor.blue) < COLOR_CHANGE_RATE) {
				currColor.blue = colors[nextColorIndex]->blue;
			}
			else {
				currColor.blue += COLOR_CHANGE_RATE;
			}
		}
	}

	// set color
	drawColor.red = currColor.red * volume;
	drawColor.green = currColor.green * volume;
	drawColor.blue = currColor.blue * volume;


	// draw waveform
	for(i = 0; (((i+SCOPE_SMOOTH_DIST)*SCOPE_TEX_SCALE)+LINE_THICK+1) < SCOPE_TEX_WIDTH; i+=SCOPE_SMOOTH_DIST) {
		drawLine(i*SCOPE_TEX_SCALE, waveformData[i]^128, 
				 (i+SCOPE_SMOOTH_DIST)*SCOPE_TEX_SCALE, waveformData[i+SCOPE_SMOOTH_DIST]^128, 
				 backgroundScopeTexture);
	}

	// set lighting (for terrain & objects)
	float lmamb[] = {float(drawColor.red) / 1275, float(drawColor.green) / 1275, float(drawColor.blue) / 1275, 1.0};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmamb);
}

static void drawTerrain(struct winampVisModule *this_mod) {
	int i, j, k;

	//unsigned char spectrum[576];
	//memcpy(spectrum, this_mod->waveformData[0], sizeof(unsigned char) * 576);

	/************ update the terrain **************/
	//shift old terrain up

	/* slow... just shift up the pointers
	for(i = TERRAIN_NUM_BASES-1; i > 0; i--) {
		for(j = 0; j < TERRAIN_PTS_ACROSS; j++) {
			for(k = 0; k < TERRAIN_PTS_ACROSS; k++) {
				terrain[i][j][k].x = terrain[i-1][j][k].x;
				terrain[i][j][k].y = terrain[i-1][j][k].y;
				terrain[i][j][k].z = terrain[i-1][j][k].z;
			}
		}
	}
	*/
	Point_3d_f **firstBase = terrain[TERRAIN_NUM_BASES-1];
	for(i = TERRAIN_NUM_BASES-1; i > 0; i--) {
		terrain[i] = terrain[i-1];
	}
	terrain[0] = firstBase;

	//set new terrain specs
	//first, match the previous block's points
	for(i = 0; i < TERRAIN_PTS_ACROSS; i++) {
		terrain[0][i][TERRAIN_PTS_ACROSS - 1].x = terrain[1][i][0].x;
		terrain[0][i][TERRAIN_PTS_ACROSS - 1].y = terrain[1][i][0].y;
		terrain[0][i][TERRAIN_PTS_ACROSS - 1].z = terrain[1][i][0].z;
	}

	//now set new terrain specs
	for(i = 0; i < TERRAIN_PTS_ACROSS; i++) {
		float heightAtX;

		/*
		// find average of spectrum data for this region
		int specLeft, specRight;

		specLeft = (288 / TERRAIN_PTS_ACROSS) * (i - 0.5);
		specRight = (288 / TERRAIN_PTS_ACROSS) * (i + 0.5);
		if(specLeft < 0) {
			specLeft = 0;
		}
		if(specRight > 287) {
			specRight = 287;
		}

		int lowest = 256;
		for(j = specLeft; j <= specRight; j++) {
			if(spectrum[j] < lowest) {
				lowest = spectrum[j];
			}
		}
		heightAtX = (lowest / 256);
		*/
		heightAtX = (float(rand()%5001))/5000;

		for(j = 0; j < TERRAIN_PTS_ACROSS - 1; j++) {
			terrain[0][i][j].x = TERRAIN_X_DIST * ((rand()%2 ? 1 : -1) * ((float(rand()%100001))/100000) * TERRAIN_WIDTH_NOISE);
			terrain[0][i][j].y = TERRAIN_Y_DIST * ((rand()%2 ? 1 : -1) * ((float(rand()%100001))/100000) * TERRAIN_DEPTH_NOISE);
			terrain[0][i][j].z = (TERRAIN_MAX_HEIGHT * heightAtX) + (TERRAIN_MAX_HEIGHT * ((rand()%2 ? 1 : -1) * (float((rand()%100001))/100000) * TERRAIN_HEIGHT_NOISE));
		}
	}

	/************ draw the terrain **************/
	glBindTexture(GL_TEXTURE_2D, TERRAIN_TEX_ID);

	glPushMatrix();
	glTranslatef(-(TERRAIN_BASE_WIDTH/2), -0.55, 0.5);
	glRotatef(-70.0, 1.0, 0.0, 0.0);
	glBegin(GL_QUADS);

	// start at upper left, and draw each base in succession
	// for each base, start at upper-left, and draw each poly
	for(i = 0; i < TERRAIN_NUM_BASES; i++) {
		for(j = 0; j < (TERRAIN_PTS_ACROSS - 1); j++) {
			for(k = 0; k < (TERRAIN_PTS_ACROSS - 1); k++) {
				float leftx = TERRAIN_X_DIST * j;
				float rightx = TERRAIN_X_DIST * (j + 1);
				float highy = -((TERRAIN_BASE_DEPTH * i) + (TERRAIN_Y_DIST * k));
				float lowy = -((TERRAIN_BASE_DEPTH * i) + (TERRAIN_Y_DIST * (k + 1)));

				int highPoint;
				float highz = -1.0;
				float znormal[4] = {1.0, 1.0, 1.0, 1.0};

				if(terrain[i][j][k+1].z > highz) {
					highPoint = 0;
					highz = terrain[i][j][k+1].z;
				}
				if(terrain[i][j+1][k+1].z > highz) {
					highPoint = 1;
					highz = terrain[i][j][k+1].z;
				}
				if(terrain[i][j+1][k].z > highz) {
					highPoint = 2;
					highz = terrain[i][j][k+1].z;
				}
				if(terrain[i][j][k].z > highz) {
					highPoint = 3;
					highz = terrain[i][j][k+1].z;
				}
				znormal[highPoint] = -znormal[highPoint];

				//float normx;
				//float normy;
				//float normz;
				//float lightx = 0.425;
				//float lighty = 0.425;
				//float lightz = -0.8;

				//getNorm((leftx + terrain[i][j][k].x) - (leftx + terrain[i][j][k+1].x), 
				//	    (highy + terrain[i][j][k].y) - (lowy + terrain[i][j][k+1].y), 
				//		(terrain[i][j][k].z) - (terrain[i][j][k+1].z),
				//		(rightx + terrain[i][j+1][k+1].x) - (leftx + terrain[i][j][k+1].x), 
				//	    (lowy + terrain[i][j+1][k+1].y) - (lowy + terrain[i][j][k+1].y), 
				//		(terrain[i][j+1][k+1].z) - (terrain[i][j][k+1].z),
				//		&normx,
				//		&normy,
				//		&normz);
				//if(normz > 0) {
				//	normz = -normz;
				//}

				/* try to use opengl lighting instead...
				// get the scale for coloring... need the if, 'cause abs() returns int,
				// and causes loss of data
				float colorScale = dotProd(normx, normy, normz, lightx, lighty, lightz);
				if(colorScale < 0) { 
					colorScale = -colorScale;
				}

				glColor3f((drawColor.red * colorScale) / 255, (drawColor.green * colorScale) / 255, (drawColor.blue * colorScale) / 255);
				*/
				glNormal3f(0.1, 0.1, znormal[0]);
				glTexCoord2f(1.0F, 1.0F);
				glVertex3f(leftx + terrain[i][j][k+1].x, lowy + terrain[i][j][k+1].y, terrain[i][j][k+1].z);

				glNormal3f(0.1, 0.1, znormal[1]);
				glTexCoord2f(0.0F, 1.0F);
				glVertex3f(rightx + terrain[i][j+1][k+1].x, lowy + terrain[i][j+1][k+1].y, terrain[i][j+1][k+1].z);

				glNormal3f(0.1, 0.1, znormal[2]);
				glTexCoord2f(0.0F, 0.0F);
				glVertex3f(rightx + terrain[i][j+1][k].x, highy + terrain[i][j+1][k].y, terrain[i][j+1][k].z);

				glNormal3f(0.1, 0.1, znormal[3]);
				glTexCoord2f(1.0F, 0.0F);
				glVertex3f(leftx + terrain[i][j][k].x, highy + terrain[i][j][k].y, terrain[i][j][k].z);
			}
		}
	}
    glEnd();
	glPopMatrix();
}

static void drawSphere(struct winampVisModule *this_mod) {
	int i, j;
	int lastSpike = 0;

	// generate radii from spectrum info
	unsigned char spectrum[576];
	memcpy(spectrum, this_mod->waveformData[0], sizeof(unsigned char) * 576);

	/*
	for(i = 1; i < 289; i++) {
		spikeCylRadius[i] = SPHERE_SPIKE_RADIUS * ((spectrum[i-1]^128) / 256.0);
	}
	*/

	for(i = SPHERE_SMOOTH_DIST; ; i+= SPHERE_SMOOTH_DIST) {
		if(!(i > (288 - SPHERE_SMOOTH_DIST))) {
			// find spectrum info for this smaple point
			spikeCylRadius[i] = (((spectrum[i-1]^128) / 256.0) - 0.5) * SPHERE_SPIKE_RADIUS;
		}

		/*
		// linearly interpolate between spikes
		for(j = 1; j < (i - lastSpike); j++) {
			if(spikeCylRadius[lastSpike] < spikeCylRadius[i]) {
				spikeCylRadius[i - j] = spikeCylRadius[lastSpike] + ((i - lastSpike - j) * ((spikeCylRadius[i] - spikeCylRadius[lastSpike]) / (i - lastSpike)));
			}
			else {
				spikeCylRadius[i - j] = spikeCylRadius[i] + (j * ((spikeCylRadius[lastSpike] - spikeCylRadius[i]) / (i - lastSpike)));
			}
		}
		*/
		
		// interpolate between spikes with sin function
		for(j = 1; j < (i - lastSpike); j++) {
			if(spikeCylRadius[lastSpike] < spikeCylRadius[i]) {
				spikeCylRadius[i - j] = spikeCylRadius[lastSpike] + ((spikeCylRadius[i] - spikeCylRadius[lastSpike]) * sinScale[(i - lastSpike) - j]);
			}
			else {
				spikeCylRadius[i - j] = spikeCylRadius[i] + ((spikeCylRadius[lastSpike] - spikeCylRadius[i]) * sinScale[j]);
			}
		}
		
		lastSpike = i;

		if(i > (288 - SPHERE_SMOOTH_DIST)) {
			break;
		}
	}

	// figure out rotation
	currRotate = (currRotate + SPHERE_ROTATE_SPEED) % 360;

	// draw sphere
	glBindTexture(GL_TEXTURE_2D, TERRAIN_TEX_ID);

	glPushMatrix();
	glTranslatef(0.0, 0.0, 0.5);
	glRotatef(90.0, 1.0, 0.0, 0.0);
	glRotatef(currRotate, 0.0, 1.0, 0.0);
	glRotatef(currRotate, 1.0, 0.0, 0.0);
	//glScalef(1.0, 1.0, 1.2);

	for(i = 0; i < 289; i++) {
		glPushMatrix();
		glTranslatef(0.0, 0.0, (SPHERE_CYL_HEIGHT * i) - SPHERE_BASE_RADIUS);
		gluCylinder(gluNewQuadric(), baseCylRadius[i] + spikeCylRadius[i], baseCylRadius[i+1] + spikeCylRadius[i+1], SPHERE_CYL_HEIGHT, 128, 1);
		glPopMatrix();
	}

	glPopMatrix();
}

void getNorm(float x1, float y1, float z1, 
			 float x2, float y2, float z2, 
			 float* nx, float* ny, float* nz) {
	float total = sqrt(  pow((y1*z2 - z1*y2), 2) 
					   + pow((z1*x2 - x1*z2), 2) 
					   + pow((x1*y2 - y1*x2), 2));

	*nx = (y1*z2 - z1*y2) / total;
	*ny = (z1*x2 - x1*z2) / total;
	*nz = (x1*y2 - y1*x2) / total;
}

float dotProd(float x1, float y1, float z1, float x2, float y2, float z2) {
	return (x1*x2)+(y1*y2)+(z1*z2);
}