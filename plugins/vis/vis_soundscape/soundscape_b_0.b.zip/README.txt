    SoundScape -- winamp visual plugin in C++, with OpenGL
    ------------------------------------------------------

License info:
    Copyright (C) 2002-2003 Dan Medeiros

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program, see LICENSE.txt; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Overview:
    This was written in about 3 weeks for a graphics class. I'm posting it so
    that others can have an example of a simple winamp vis plugin that uses
    OpenGL. When I was writing this, I couldn't find any such examples myself,
    so I thought that making this available would be useful.

    The plugin itself isn't too bad, either -- if you decided to just download the
    plugin to try out, thanks, and I hope you like it.

Installation:
    Find the directory winamp is in. Off of this directory is a directory called
    "Plugins". Simply move soundscape.dll into the plugins directory. You can then
    start it up as a visualization plugin. 

    Note: older versions of winamp require that visualization plugins have filenames 
    that start with "vis_". If you have an older version of winamp, and don't see this
    plugin as an option after moving it to the plugins directory, simply rename
    "soundscape.dll" as "vis_soundscape.dll" and you should be fine.

-Dan
<random-nomad@psychotic.co.uk>





   