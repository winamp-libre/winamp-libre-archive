#ifndef __WASABI_BROWSERCB_H
#define __WASABI_BROWSERCB_H

#include <api/syscb/callbacks/syscb.h>

namespace BrowserCallback {
  enum {
    ONOPENURL=10,
  };
};
#endif
