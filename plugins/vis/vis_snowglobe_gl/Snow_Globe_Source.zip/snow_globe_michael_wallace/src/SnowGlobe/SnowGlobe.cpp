#include "SnowGlobe.h"
#include "IPictureImageFile.h"
#include "TgaImageFile.h"
#include <stdio.h>
#include "GlobeGeometry.h"
#include <time.h>
#include <math.h>
#include <stdarg.h>
#include "../gl_wrap.h"
#include "glext.h"
#include "wglext.h"
#include "../winamp/wa_ipc.h"

// texture indexes into the array of texture ids
enum Textures
{
  FLOOR_TEXTURE,
  WRAPPING_PAPER_TEXTURE,
  CARD_TEXTURE,
  PENCIL_TEXTURE,
  GLOBE_BASE_TEXTURE,
  GLOBE_GLASS_TEXTURE,
  GLOBE_SNOW_FLOOR_TEXTURE,
  GLOBE_TREE_TEXTURE,
  SNOWMAN_HAT_TEXTURE,
  PRESENTS_TEXTURE,
  SNOWMAN_SNOW_TEXTURE,
  SPLASH_SCREEN_TEXTURE,
  GLOBE_LIGHT_TEXTURE,
};

const int   c_maxSpectrumVals     = 30;
const float c_defaultSensitivity  = 1.3f;
const float c_oneEightyByPi       = 57.29577951f;
const float c_timeToShowTitleFor  = 5.0f;

#define DegToRad(d) d*3.14159f/180.0f

// wgl extension string
PFNWGLGETEXTENSIONSSTRINGARBPROC wglGetExtensionsStringARB = NULL;

// wgl swap interval extension
PFNWGLSWAPINTERVALEXTPROC wglSwapIntervalEXT = NULL;

SnowGlobe::SnowGlobe() 
: m_intensity(0.0f),
  m_cameraHeight(25.0f),
  m_elapsedTime(0.0),
  m_cameraRot(0.0),
  m_snowmanBottomBop(0.0f),
  m_snowmanMiddleBop(0.0f),
  m_snowmanTopBop(0.0f),
  m_avgEnergy(0.0f),
  m_instantEnergy(0.0f),
  m_isBeat(false),
  m_beatSensitivity(c_defaultSensitivity),
  m_timeSincelastBeat(0.0f),
  m_danceDir(1.0f),
  m_timeTitleShownFor(0.0f),
  m_displayTitle(true)
{
  // seed the random number generator
  srand((unsigned)time(NULL));

  // create the snow particles
  CreateSnowParticles();

  // set the fov
  SetCurrFOV(90.0f);

  // create the array of colours for the tree lights
  m_treeLightColours.push_back(Vector3D(1.0f, 0.0f, 0.0));
  m_treeLightColours.push_back(Vector3D(0.0f, 1.0f, 0.0));
  m_treeLightColours.push_back(Vector3D(0.0f, 0.0f, 1.0));
  m_treeLightColours.push_back(Vector3D(1.0f, 1.0f, 1.0));
  m_treeLightColours.push_back(Vector3D(1.0f, 1.0f, 0.0));
  m_treeLightColours.push_back(Vector3D(0.0f, 1.0f, 1.0));
  m_treeLightColours.push_back(Vector3D(1.0f, 0.0f, 1.0));
  m_treeLightColours.push_back(Vector3D(1.0f, 0.8f, 0.0));
  m_treeLightColours.push_back(Vector3D(0.0f, 0.8f, 1.0));
}

SnowGlobe::~SnowGlobe()
{

}

bool SnowGlobe::Init(HDC hDC, 
                     HWND hWnd, 
                     const char* pluginPath,
                     bool displayTitle)
{
  m_hDC           = hDC;
  m_hWnd          = hWnd;
  m_pluginPath    = pluginPath;
  m_displayTitle  = displayTitle;

  // create the font
  BuildFont();

  // create the textures
  glGenTextures(TEXTURE_COUNT, m_loadedTextures);

  // load the textures
  if (LoadTexture("snow_globe\\floor.jpg", FLOOR_TEXTURE) != GL_TRUE)
  {
    return false;
  }
  
  if (LoadTexture("snow_globe\\wrapping_paper.jpg", WRAPPING_PAPER_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\card.jpg", CARD_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\pencil.jpg", PENCIL_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\globe_base.jpg", GLOBE_BASE_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\globe_glass.jpg", GLOBE_GLASS_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\tree.jpg", GLOBE_TREE_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\snow_floor.jpg", GLOBE_SNOW_FLOOR_TEXTURE) != GL_TRUE)
  {
    return false;
  }
  
  if (LoadTexture("snow_globe\\hat.jpg", SNOWMAN_HAT_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\presents.jpg", PRESENTS_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\snowman_snow.jpg", SNOWMAN_SNOW_TEXTURE) != GL_TRUE)
  {
    return false;
  }

  if (LoadTexture("snow_globe\\splash_screen.jpg", SPLASH_SCREEN_TEXTURE) != GL_TRUE)
  {
    return false;
  }
  
  if (LoadTexture("snow_globe\\light.tga", GLOBE_LIGHT_TEXTURE) != GL_TRUE)
  {
    return false;
  }
  
  // set texgen mode to sphere mapping
  glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);

  // enable coloured materials
  glEnable(GL_COLOR_MATERIAL);
  
  // set up transparency
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glAlphaFunc(GL_GEQUAL, 0.1f);
  
  // culling
  glCullFace(GL_BACK);
  glEnable(GL_CULL_FACE);

  // the light
  GLfloat lightDiffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
  GLfloat lightSpecular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
  GLfloat lightAmbient[] = { 0.8f, 0.8f, 0.8f, 1.0f };

  glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);
  glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpecular);
  glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);
  glLightf(GL_LIGHT0, GL_SPOT_CUTOFF, 90.0f);
  glLightf(GL_LIGHT0, GL_SPOT_EXPONENT, 100.0f);
  glEnable(GL_LIGHT0);
  glEnable(GL_LIGHTING);

  // load the wgl extension string function
  wglGetExtensionsStringARB = (PFNWGLGETEXTENSIONSSTRINGARBPROC)wglGetProcAddress("wglGetExtensionsStringARB");

  // use vsync if available
  if (WGLExtensionAvailable("WGL_EXT_swap_control"))
  {
    wglSwapIntervalEXT = (PFNWGLSWAPINTERVALEXTPROC)wglGetProcAddress("wglSwapIntervalEXT");
    if (wglSwapIntervalEXT != NULL)
    {
       wglSwapIntervalEXT(1);
    }
    else if (wglSwapIntervalEXT != NULL)
    {
       wglSwapIntervalEXT(0);
    }
  }
  
  
  return true;
}

void SnowGlobe::Render(struct wamp_module_t* module,
                       float deltaTime)
{
  /*if (GetAsyncKeyState(VK_UP) < 0)
  {
    SetCurrFOV(m_currFOV -= 5.0f * deltaTime);
  }
  if (GetAsyncKeyState(VK_DOWN) < 0)
  {
    SetCurrFOV(m_currFOV += 5.0f * deltaTime);
  }

  if (GetAsyncKeyState(VK_NEXT) < 0)
  {
    m_cameraHeight += 5.0f * deltaTime;
  }
  if (GetAsyncKeyState(VK_PRIOR) < 0)
  {
    m_cameraHeight -= 5.0f * deltaTime;
  }
*/

  m_elapsedTime += deltaTime;

  //-- update the camera height
  m_cameraHeight = (float)sin(m_elapsedTime/15.0f) * 12.5f + 17.5f;

  // prevent the height from going out of range
  m_cameraHeight = min(max(m_cameraHeight, 4.0f), 30.0f);

  //--update the camera fov
  SetCurrFOV(m_currFOV -= 5.0f * deltaTime * (float)sin(m_elapsedTime/6.0f));
  
  /*
  static bool plop = false;
  if (GetAsyncKeyState(VK_SPACE) < 0)
  {
    plop = !plop;

    if (plop)
    {
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    }
    else
    {
      glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    }
  }*/

  UpdateFromMusic(module, deltaTime);

  m_cameraRot += 5.0f * deltaTime;
  Wrap(m_cameraRot, 0.0f, 360);

  m_cameraPos.Set(-sinf(DegToRad(m_cameraRot))*30.0f, m_cameraHeight, cosf(DegToRad(m_cameraRot))*30.0f);
  gluLookAt(m_cameraPos.X(), m_cameraPos.Y(), m_cameraPos.Z(),
            0.0, 10.0, 0.0,
            0.0, 1.0, 0.0);

  // place the light
  GLfloat lightPos[] = { 0.0f, 180.0f, 0.0f, 1.0f };
  GLfloat lightDir[] = { 0.0f, -1.0f, 0.0f, 1.0f };

  glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
  glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, lightDir);

  //glRotatef(m_cameraRot, 0.0f, 1.0f, 0.0f);
  
  // render a nice reflective floor
  glDisable(GL_CULL_FACE);
  // use the following code to activate the stencil buffer to prevent the reflection
  // "overrunning" the floor, but as my geometry in this demo is too small to overrun
  // I don't enable the stencil buffer to improve performance on older cards
  /*glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
  glEnable(GL_STENCIL_TEST);
  glStencilFunc(GL_ALWAYS, 1, 1);
  glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
  glDisable(GL_DEPTH_TEST);
  RenderFloor(deltaTime, GL_FALSE);

  // draw the reflection where the stencil buffer is a 1
  glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
  glEnable(GL_DEPTH_TEST);
  glStencilFunc(GL_EQUAL, 1, 1);
  glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);*/

  RenderSnow(deltaTime, GL_TRUE);
  RenderGlobe(deltaTime, GL_TRUE);
  
  // draw the proper floor
  //glDisable(GL_STENCIL_TEST);

  glEnable(GL_CULL_FACE);
  RenderFloor(deltaTime, GL_FALSE);

  // draw the proper globe
  RenderSnow(deltaTime, GL_FALSE);
  RenderGlobe(deltaTime, GL_FALSE);

  DisplayTitle(deltaTime, module);
  
  //RenderDebugText();
}

void SnowGlobe::RenderIdle()
{
  SetCurrFOV(90.0f);
  glColor3f(1.0f, 1.0f, 1.0f);
  glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_LIGHTING);

    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[SPLASH_SCREEN_TEXTURE]);
    EnterOrthographicMode();
    /*glTranslatef(-0.0f, -0.0f, -1.7f);
    glBegin(GL_TRIANGLE_STRIP);
		  glTexCoord2f(0.005f, 0.95f); glVertex3f(-1.5f,  1.5f, 0.0f);
		  glTexCoord2f(0.005f, 0.005f); glVertex3f(-1.5f, -1.5f, 0.0f);
		  glTexCoord2f(0.95f, 0.95f); glVertex3f( 1.5f,  1.5f, 0.0f);
		  glTexCoord2f(0.95f, 0.005f); glVertex3f( 1.5f, -1.5f, 0.0f);
	  glEnd();*/
    
    glBegin(GL_TRIANGLE_STRIP);
		  glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f,  1.0f, 0.0f);
		  glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, 0.0f, 0.0f);
		  glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, 0.0f);
		  glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, 0.0f, 0.0f);
	  glEnd();

    // go back to perspective mode
    SetCurrFOV(m_currFOV);
    
  glPopAttrib();
}

void SnowGlobe::Uninit()
{
  // delete the font display lists
  glDeleteLists(m_fontBase, 96);

  // delete the textures
  glDeleteTextures(TEXTURE_COUNT, m_loadedTextures);
}

GLboolean SnowGlobe::LoadTexture(const char* texFile, GLuint texID, GLboolean UseGLNearest)
{

  // find out what type file it is
  GLuint strLen = (GLuint)strlen(texFile);
  
  ImageFile* image = NULL;

  if (tolower(texFile[strLen-4]) == '.' && tolower(texFile[strLen-3] == 'j')
      && tolower(texFile[strLen-2] == 'p') && tolower(texFile[strLen-1] == 'g'))
  {
    // jpeg file
    image = new IPictureImageFile(m_hDC);
  }
  else
  {
    // assume tga
    image = new TgaImageFile;
  }

  if (image == NULL)
  {
    return GL_FALSE;
  }

  std::string actualPath = m_pluginPath;
  actualPath += texFile;

  if (!image->LoadFromFile(actualPath.c_str()))
  {
    char err[128];
    sprintf(err, "Error loading \"%s\"", actualPath.c_str()); 
    MessageBox(m_hWnd, err, "Error", MB_OK | MB_ICONSTOP);
    return GL_FALSE;
  }

  glBindTexture(GL_TEXTURE_2D, m_loadedTextures[texID]);
  
  glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, UseGLNearest ? GL_NEAREST : GL_LINEAR_MIPMAP_LINEAR);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, UseGLNearest ? GL_NEAREST : GL_LINEAR_MIPMAP_LINEAR);

  if (image->GetColourDepth() == 24)
  {
    gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->GetWidth(), image->GetHeight(), 
                GL_RGB, GL_UNSIGNED_BYTE, image->GetData());
  }
  else
  {
    gluBuild2DMipmaps(GL_TEXTURE_2D, 4, image->GetWidth(), image->GetHeight(), 
                GL_RGBA, GL_UNSIGNED_BYTE, image->GetData());
  }

  if (image != 0)
  {
    delete image;
    image = 0;
  }

  return GL_TRUE;
}

void SnowGlobe::RenderFloor(float deltaTime,
                            GLboolean reflection)
{
  //-- draw the floor
  glPushAttrib(GL_ENABLE_BIT);

    if (!reflection)
    {
      glEnable(GL_BLEND);
      glColor4f(1.0f, 1.0f, 1.0f, 0.8f);
    }
    else
    {
      glDisable(GL_BLEND);
      glColor3f(1.0f, 1.0f, 1.0f);
    }

    glEnable(GL_TEXTURE_2D);
    
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    //-- draw the base floor
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[FLOOR_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, TableTop_Verts);
    glNormalPointer(GL_FLOAT, 0, TableTop_Norms);
    glTexCoordPointer(2, GL_FLOAT, 0, TableTop_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 1350);

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

  glPopAttrib();
}

void SnowGlobe::RenderGlobe(float deltaTime,
                            GLboolean reflection)
{
  //-- draw the snow globe and the other bits on the floor
  glColor3f(1.0f, 1.0f, 1.0f);
  glPushAttrib(GL_ENABLE_BIT);
    if (reflection)
    {
      glPushMatrix();
      // create a clip plane for so the reflection doesn't appear above y = 0.0
      GLdouble plane[] = {0.0, -1.0, 0.0, 0.0};
      glEnable(GL_CLIP_PLANE0);
      glClipPlane(GL_CLIP_PLANE0, plane);

      glScalef(1.0f, -1.0f, 1.0f);
    }
    
    glEnable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    
    //-- base
    //-- top
    glDisable(GL_CULL_FACE);
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[GLOBE_BASE_TEXTURE]);
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, BaseTop_Verts);
    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT, 0, BaseTop_Norms);   
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, 0, BaseTop_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 216);

    //-- bottom
    glVertexPointer(3, GL_FLOAT, 0, BaseBottom_Verts);
    glNormalPointer(GL_FLOAT, 0, BaseBottom_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, BaseBottom_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 312);

    //-- wrapping paper
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[WRAPPING_PAPER_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, WrapPaper_Verts);
    glNormalPointer(GL_FLOAT, 0, WrapPaper_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, WrapPaper_TexCoords);
    
    glDrawArrays(GL_TRIANGLES, 0, 168);

    //glEnable(GL_CULL_FACE);

    //-- card
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[CARD_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, Card_Verts);
    glNormalPointer(GL_FLOAT, 0, Card_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, Card_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 6);
    
    //-- pencil
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[PENCIL_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, Pencil_Verts);
    glNormalPointer(GL_FLOAT, 0, Pencil_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, Pencil_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 162);

    //-- snow floor
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[GLOBE_SNOW_FLOOR_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, SnowFloor_Verts);
    glNormalPointer(GL_FLOAT, 0, SnowFloor_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, SnowFloor_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 270);

    //-- tree
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[GLOBE_TREE_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, Tree_Verts);
    glNormalPointer(GL_FLOAT, 0, Tree_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, Tree_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 360);

    //-- presents
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[PRESENTS_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, Presents_Verts);
    glNormalPointer(GL_FLOAT, 0, Presents_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, Presents_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 108);

    //-- ribbons
    glVertexPointer(3, GL_FLOAT, 0, Ribbon01_Verts);
    glNormalPointer(GL_FLOAT, 0, Ribbon01_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, Ribbon01_TexCoords);
    
    glDrawArrays(GL_TRIANGLES, 0, 462);

    glVertexPointer(3, GL_FLOAT, 0, Ribbon02_Verts);
    glNormalPointer(GL_FLOAT, 0, Ribbon02_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, Ribbon02_TexCoords);
    
    glDrawArrays(GL_TRIANGLES, 0, 462);

    glVertexPointer(3, GL_FLOAT, 0, Ribbon03_Verts);
    glNormalPointer(GL_FLOAT, 0, Ribbon03_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, Ribbon03_TexCoords);
    
    glDrawArrays(GL_TRIANGLES, 0, 462);
    // render the snowman
    RenderSnowman(deltaTime, reflection);
    
    // have to render tree lights AFTER the snowman to avoid transparency issues
    RenderTreeLights(deltaTime);

    //-- glass globe
    glEnable(GL_CULL_FACE);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    glColor4f(0.8f, 0.8f, 1.0f, 0.3f);
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[GLOBE_GLASS_TEXTURE]);
    
    // environment mapped so disable the texture coord array
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);

    glVertexPointer(3, GL_FLOAT, 0, GlassGlobe_Verts);
    glNormalPointer(GL_FLOAT, 0, GlassGlobe_Norms);   

    glDrawArrays(GL_TRIANGLES, 0, 1728);

    glDisable(GL_TEXTURE_GEN_S);
    glDisable(GL_TEXTURE_GEN_T);

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

    if (reflection)
    {
      glDisable(GL_CLIP_PLANE0);
      // undo the negative scale
      glPopMatrix();
    }
  glPopAttrib();
}

void SnowGlobe::RenderSnow(float deltaTime,
                           GLboolean reflection)
{
  glPushMatrix();
  //-- draw the snow particles
  glPushAttrib(GL_ENABLE_BIT);
    if (reflection)
    {
      // create a clip plane for so the reflection doesn't appear above y = 0.0
      GLdouble plane[] = {0.0, -1.0, 0.0, 0.0};
      glEnable(GL_CLIP_PLANE0);
      glClipPlane(GL_CLIP_PLANE0, plane);

      glScalef(1.0f, -1.0f, 1.0f);
    }
    
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_BLEND);
    glDisable(GL_CULL_FACE);

    // draw each snowflake around a sphere fitting inside the globe
    glTranslatef(0.0f, 11.5f, 0.0);
    
    static float sysRot = 0.0f;
    sysRot += 2.0f * deltaTime;

    glColor3f(0.8f, 0.8f, 0.8f);

    // vary the number of particles by the intensity of the music
    /*int particlesToDraw = 0;
    
    const float lowerBound = 0.15f;
    if (m_intensity > lowerBound)
    {
      particlesToDraw = (int)(MAX_SNOW_PARTICLE_COUNT * Lerp(0.0f, 1.0, (m_intensity - lowerBound)/(1.0f - lowerBound)));
      // just in case an out of range amount comes in (should never happen)
      particlesToDraw = min(particlesToDraw, MAX_SNOW_PARTICLE_COUNT);
    }*/

    int particlesToDraw = (int)(MAX_SNOW_PARTICLE_COUNT * m_intensity * m_intensity);
    // just in case an out of range amount comes in (should never happen)
    particlesToDraw = min(particlesToDraw, MAX_SNOW_PARTICLE_COUNT);

    for (int i = 0; i < particlesToDraw; i++)
    {
      //glColor3f(Random(0.0f, 1.0f), Random(0.0f, 1.0f), Random(0.0f, 1.0f));

      // update the rotations (varying the speed according to the intensity of the music)
      m_snowParticles[i].currSystemRotation += m_snowParticles[i].systemRotationSpeed * deltaTime * m_intensity;
      m_snowParticles[i].currSystemRotation = Wrap(m_snowParticles[i].currSystemRotation, 0.0f, 360.0f);
      m_snowParticles[i].currLocalRotation += m_snowParticles[i].localRotationSpeed * deltaTime * m_intensity;
      m_snowParticles[i].currLocalRotation = Wrap(m_snowParticles[i].currLocalRotation, 0.0f, 720.0f);

      glRotatef(m_snowParticles[i].currSystemRotation, 
                m_snowParticles[i].systemAxisOfRotation.X(), 
                m_snowParticles[i].systemAxisOfRotation.Y(), 
                m_snowParticles[i].systemAxisOfRotation.Z());

      glPushMatrix();
        glTranslatef(m_snowParticles[i].distFromCenter, 0.0f, 0.0f);

        // rotate around the local axis of rotation
        glRotatef(m_snowParticles[i].currLocalRotation, 
                  m_snowParticles[i].localAxisOfRotation.X(), 
                  m_snowParticles[i].localAxisOfRotation.Y(), 
                  m_snowParticles[i].localAxisOfRotation.Z());
        glBegin(GL_TRIANGLE_STRIP);
          glNormal3f(0.0f, 0.0f, 1.0f);
          glVertex3f(-0.085f, -0.085f, 0.0f);
          glVertex3f(0.085f, -0.085f, 0.0f);
          glVertex3f(-0.085f, 0.085f, 0.0f);
          glVertex3f(0.085f, 0.085f, 0.0f);
        glEnd();
      glPopMatrix();
    }
    
    
    if (reflection)
    {
      glDisable(GL_CLIP_PLANE0);
    }
  glPopAttrib();
  glPopMatrix();
}

void SnowGlobe::RenderSnowman(float deltaTime,
                              GLboolean reflection)
{
  glPushMatrix();

    // make the snowman "dance"
    static float zAngle = 0.0f;
    static float xAngle = 0.0f;
    static float xDir = 1.0f;

    // don't update the dancing on the reflection
    if (m_isBeat && !reflection)
    {
      m_danceDir = -1.0f * m_danceDir;
      if (Random(-1.0f, 1.0f) > 0)
      {
        xDir = -xDir;
      }
    }
    zAngle += 30.0f * m_intensity * m_intensity * deltaTime * m_danceDir;
    xAngle += 7.5f * m_intensity * m_intensity * deltaTime * xDir;
    zAngle = min(max(zAngle, -7.0f), 7.0f);
    xAngle = min(max(xAngle, -1.0f), 1.0f);

    glRotatef(zAngle, 0.0f, 0.0f, 1.0f);
    glRotatef(xAngle, 1.0f, 0.0f, 0.0f);
    RenderSnowmanBottom(deltaTime, reflection);
    glRotatef(zAngle, 0.0f, 0.0f, 1.0f);
    glRotatef(xAngle, 1.0f, 0.0f, 0.0f);
    RenderSnowmanMiddle(deltaTime, reflection);
    glRotatef(zAngle/2.0f, 0.0f, 0.0f, 1.0f);
    glRotatef(xAngle/2.0f, 1.0f, 0.0f, 0.0f);
    RenderSnowmanTop(deltaTime, reflection);
  glPopMatrix();
}

void SnowGlobe::RenderSnowmanBottom(float deltaTime, 
                                    GLboolean reflection)
{
  //-- draw bottom of the snowman in the globe
  glColor3f(1.0f, 1.0f, 1.0f);
  glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
    
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glDisable(GL_CULL_FACE);
    
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[SNOWMAN_SNOW_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, SnowmanBottom_Verts);
    glNormalPointer(GL_FLOAT, 0, SnowmanBottom_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, SnowmanBottom_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 672);

    // no textures from now on
    glDisable(GL_TEXTURE_2D);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glColor3f(0.0f, 0.0f, 0.0f);

    //-- all the coal bits
    glVertexPointer(3, GL_FLOAT, 0, Snowman_Coal_Bottom_Verts);
    glNormalPointer(GL_FLOAT, 0, Snowman_Coal_Bottom_Norms);   
    
    glDrawArrays(GL_TRIANGLES, 0, 60);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

  glPopAttrib();
}

void SnowGlobe::RenderSnowmanMiddle(float deltaTime, 
                                    GLboolean reflection)
{
  //-- draw the snowman in the globe
  glColor3f(1.0f, 1.0f, 1.0f);
  glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
    
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glDisable(GL_CULL_FACE);
    
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    //-- snowman middle
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[SNOWMAN_SNOW_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, SnowmanMiddle_Verts);
    glNormalPointer(GL_FLOAT, 0, SnowmanMiddle_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, SnowmanMiddle_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 360);
    
    // no textures from now on
    glDisable(GL_TEXTURE_2D);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glColor3f(0.0f, 0.0f, 0.0f);

    //-- all the coal bits
    glVertexPointer(3, GL_FLOAT, 0, Snowman_Coal_Middle_Verts);
    glNormalPointer(GL_FLOAT, 0, Snowman_Coal_Middle_Norms);   
    
    glDrawArrays(GL_TRIANGLES, 0, 60);

    glColor3f(0.415f, 0.223f, 0.223f);

    //-- arms
    // make the arms move to the music
    static float armRot = 0.0f;
    armRot += 180.0f * m_intensity * deltaTime * m_danceDir;
    armRot = min(max(armRot, 0.0f), 250.0f);

    //-- left arm
    glPushMatrix();
      glTranslatef(1.226f, 10.7482f, 0.0f);  
      glRotatef(armRot, 1.0f, 0.0f, 0.0f);
      glVertexPointer(3, GL_FLOAT, 0, Snowman_LeftArm_Verts);
      glNormalPointer(GL_FLOAT, 0, Snowman_LeftArm_Norms);   
      
      glDrawArrays(GL_TRIANGLES, 0, 528);
    glPopMatrix();
    //-- right arm
    glPushMatrix();
      glTranslatef(-1.226f, 10.7482f, -0.6391f);  
      glRotatef(-armRot, 1.0f, 0.0f, 0.0f);
      
      glVertexPointer(3, GL_FLOAT, 0, Snowman_RightArm_Verts);
      glNormalPointer(GL_FLOAT, 0, Snowman_RightArm_Norms);   
      
      glDrawArrays(GL_TRIANGLES, 0, 528);
    glPopMatrix();

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

  glPopAttrib();
}

void SnowGlobe::RenderSnowmanTop(float deltaTime, 
                                 GLboolean reflection)
{
  //-- draw the snowman in the globe
  glColor3f(1.0f, 1.0f, 1.0f);
  glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
    
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glDisable(GL_CULL_FACE);
    
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    //-- snowman head
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[SNOWMAN_SNOW_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, SnowmanHead_Verts);
    glNormalPointer(GL_FLOAT, 0, SnowmanHead_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, SnowmanHead_TexCoords);

    glDrawArrays(GL_TRIANGLES, 0, 360);

    //-- hat
    glBindTexture(GL_TEXTURE_2D, m_loadedTextures[SNOWMAN_HAT_TEXTURE]);
    glVertexPointer(3, GL_FLOAT, 0, Snowman_Hat_Verts);
    glNormalPointer(GL_FLOAT, 0, Snowman_Hat_Norms);   
    glTexCoordPointer(2, GL_FLOAT, 0, Snowman_Hat_TexCoords);
    
    glDrawArrays(GL_TRIANGLES, 0, 126);

    // no textures from now on
    glDisable(GL_TEXTURE_2D);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glColor3f(0.0f, 0.0f, 0.0f);

    //-- all the coal bits
    glVertexPointer(3, GL_FLOAT, 0, Snowman_Coal_Top_Verts);
    glNormalPointer(GL_FLOAT, 0, Snowman_Coal_Top_Norms);   
    
    glDrawArrays(GL_TRIANGLES, 0, 180);

    //-- nose
    glColor3f(1.0f, 0.5f, 0.0f);
    glVertexPointer(3, GL_FLOAT, 0, Snowman_Nose_Verts);
    glNormalPointer(GL_FLOAT, 0, Snowman_Nose_Norms);   
    
    glDrawArrays(GL_TRIANGLES, 0, 72);

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);

  glPopAttrib();
}

void SnowGlobe::CreateSnowParticles()
{
  // create the entire particle system of snow flakes
  for (int i = 0; i < MAX_SNOW_PARTICLE_COUNT; i++)
  {
    // create a particle at a random distance from the center  (without having any particles too close to the center)
    float randNum = Random(2.0f, 9.0f);
    // choose the side of the origin to be placed at
    float side = Random(-1.0f, 1.0f);
    if (side < 0)
    {
      randNum *= -1.0f;
    }
    m_snowParticles[i].distFromCenter = randNum;
    m_snowParticles[i].systemAxisOfRotation.Set(Random(-1.0f, 1.0f), Random(-1.0f, 1.0f), Random(-1.0f, 1.0f));
    m_snowParticles[i].localAxisOfRotation.Set(Random(-1.0f, 1.0f), Random(-1.0f, 1.0f), Random(-1.0f, 1.0f));
    m_snowParticles[i].systemRotationSpeed = Random(0.1f, 2.5f);
    m_snowParticles[i].localRotationSpeed = Random(1.0f, 720.0f);
    m_snowParticles[i].currSystemRotation = Random(0.0f, 360.0f);
    m_snowParticles[i].currLocalRotation = Random(0.0f, 360.0f);
  }
}

float SnowGlobe::Random(float min,
                        float max)
{
  // create a random number between the min and max values
  return ((float)rand())/RAND_MAX * (max-min) + min;
}

float SnowGlobe::Wrap(float val,
                      float min,
                      float max)
{
  if (val > max)
  {
    return min + val - max;
  }

  return val;
}

void SnowGlobe::UpdateFromMusic(struct wamp_module_t* module, 
                                float deltaTime)
{
  // get the average value of the spectrum over all channels
  int spectrum = 0;
  int max = 0;
  for (int y = 0; y < module->num_channels; y++)
  {
    for (int x = 0; x < 288; x++)
    {
      max = max(max, module->spectrum_data[y][x]);
      spectrum += module->spectrum_data[y][x];
    }
  }
  
  // keep the last c_maxSpectrumVals spectrum maximums
  if (m_intensityLastSpectrumVals.size() < c_maxSpectrumVals)
  {
    m_intensityLastSpectrumVals.push_back(max);
  }
  else
  {
    m_intensityLastSpectrumVals.pop_front();
    m_intensityLastSpectrumVals.push_back(max);
  }

  float avgSpectrum = 0.0;
  for (std::deque<unsigned char>::const_iterator it = m_intensityLastSpectrumVals.begin();
       it != m_intensityLastSpectrumVals.end(); it++)
  {
    avgSpectrum += *it;
  }

  avgSpectrum /= m_intensityLastSpectrumVals.size();
  
  // calculate the "intensity" of the music
  float intensityThisFrame = avgSpectrum/255.0f;
  if (intensityThisFrame >= m_intensity)
  {
    // greater intensity
    m_intensity = min(m_intensity += 0.025f * deltaTime, intensityThisFrame);
  }
  else
  {
    // lesser intensity
    m_intensity = max(m_intensity -= 0.025f * deltaTime, intensityThisFrame);
  }

  DoBeatDetection(module, deltaTime);
}

void SnowGlobe::SetCurrFOV(float fov)
{
  m_currFOV = fov;

  // prevent the fov from going out of range
  m_currFOV = min(max(m_currFOV, 28.0f), 90.0f);

  glSetFOV(fov);
  /*gl_resize_wnd((GLsizei)wamp_get_scr_width(),
								(GLsizei)wamp_get_scr_height());*/
  gl_render_update_viewport();
}

void SnowGlobe::EnterOrthographicMode()
{
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  gluOrtho2D(0.0, 1.0, 0.0, 1.0);

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void SnowGlobe::BuildFont()
{
  HFONT	font;
	HFONT	oldfont;

	m_fontBase = glGenLists(96);
  font = CreateFont(-24,
                    0,
                    0,
                    0,
                    FW_BOLD,
                    FALSE, 
                    FALSE, 
                    FALSE,
                    ANSI_CHARSET,
                    OUT_TT_PRECIS,
                    CLIP_DEFAULT_PRECIS,
                    ANTIALIASED_QUALITY,
                    FF_DONTCARE|DEFAULT_PITCH,
                    "Ariel");

  oldfont = (HFONT)SelectObject(m_hDC, font);
	wglUseFontBitmaps(m_hDC, 32, 96, m_fontBase);
	SelectObject(m_hDC, oldfont);
	DeleteObject(font);
}

void SnowGlobe::glPrint(const char* fmt,
                        ...)
{
  char		text[256];
	va_list		ap;

  if (fmt == NULL)
		return;

  va_start(ap, fmt);
	    vsprintf(text, fmt, ap);
	va_end(ap);

  glPushAttrib(GL_LIST_BIT);
	glListBase(m_fontBase - 32);

  glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);
	glPopAttrib();
}

void SnowGlobe::RenderDebugText()
{
  glColor3f(1.0f, 1.0f, 1.0f);
  glPushAttrib(GL_ENABLE_BIT);
    // debug text
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);

    EnterOrthographicMode();
    glRasterPos2f(0.01f, 0.93f);
    glPrint("Elapsed Time: %.2f", m_elapsedTime);
    glRasterPos2f(0.01f, 0.9f);
    glPrint("Camera Height: %.2f", m_cameraHeight);
    glRasterPos2f(0.01f, 0.87f);
    glPrint("FOV: %.2f", m_currFOV);
    glRasterPos2f(0.01f, 0.84f);
    glPrint("Intensity: %.2f", m_intensity);
    glRasterPos2f(0.01f, 0.81f);
    glPrint("Particles: %d", (int)(MAX_SNOW_PARTICLE_COUNT * m_intensity * m_intensity));
    glRasterPos2f(0.01f, 0.78f);
    glPrint("# Samples: %d", (int)m_spectrumSamples.size());
    glRasterPos2f(0.01f, 0.75f);
    glPrint("Avg energy: %.2f", m_avgEnergy);
    glRasterPos2f(0.01f, 0.72f);
    glPrint("Inst energy: %.2f", m_instantEnergy);
    if (m_avgEnergy > 0.0)
    {
      glRasterPos2f(0.01f, 0.69f);
      glPrint("Energy fraction: %.2f", m_instantEnergy / m_avgEnergy);
    }
    glRasterPos2f(0.01f, 0.66f);
    glPrint("Avg Variance: %.2f", m_avgVariance);
    glRasterPos2f(0.01f, 0.63f);
    glPrint("Beat Sensitivity: %.2f", m_beatSensitivity);
    glRasterPos2f(0.01f, 0.60f);
    glPrint("Dance Dir: %.2f", m_danceDir);
    
    
    if (m_isBeat)
    {
      glColor3f(1.0f, 0.0f, 0.0f);
      glRasterPos2f(0.5f, 0.93f);
      glPrint("BEAT");
    }

    // go back to perspective mode
    SetCurrFOV(m_currFOV);
  glPopAttrib();
}

float SnowGlobe::Lerp(float start,
                      float end,
                      float fraction)
{
  return start * (1.0f - fraction) + end * fraction;
}

void SnowGlobe::DoBeatDetection(struct wamp_module_t* module, 
                                float deltaTime)
{
  // how many samples must be stored to get �1 second of sound
  int numSamples = module->sample_rate;

  if ((int)m_spectrumSamples.size() >= numSamples)
  {
    //-- get rid of the oldest samples
    for (int i = 0; i < 576; i++)
    {
      m_spectrumSamples.pop_front();
    }

  }
  
  //-- add the average value of the samples from the module
  m_instantEnergy = 0.0f;
  for (int j = 0; j < 576; j++)
  {
    int val = 0;
    for (int i = 0; i < module->num_channels; i++)
    {
      val += module->spectrum_data[i][j];
    }
    val /= module->num_channels;
    m_spectrumSamples.push_back((unsigned char)val);
    m_instantEnergy += val;
  }
  m_instantEnergy /= 576.0f;
  
  // don't do anything further till the required amount of samples are stored
  if ((int)m_spectrumSamples.size() < numSamples ||
      m_spectrumSamples.size() <= 0)
  {
    return;
  }

  // work out the average energy of the samples
  m_avgEnergy = 0.0f;
  for (std::deque<unsigned char>::const_iterator it = m_spectrumSamples.begin(); 
       it != m_spectrumSamples.end(); it++)
  {
    m_avgEnergy += *it;
  }
  m_avgEnergy /= m_spectrumSamples.size();

  // work out the variance of the energies in the spectrum samples in order to create the best sensitivity
  m_beatSensitivity = c_defaultSensitivity;
  m_avgVariance = 0.0f;
  for (std::deque<unsigned char>::const_iterator it = m_spectrumSamples.begin(); 
       it != m_spectrumSamples.end(); it++)
  {
    float var = *it - m_avgEnergy;
    m_avgVariance += (var * var);
  }
  m_avgVariance /= m_spectrumSamples.size();

  if (m_avgVariance > 200.0f)
  {
    m_beatSensitivity = 1.0f;
  }
  else if (m_avgVariance < 25.0f)
  {
    m_beatSensitivity = 1.45f;
  }
  else
  {
    m_beatSensitivity = Lerp(1.45f, 1.0f, (m_avgVariance - 25.0f)/(200.0f - 25.0f));
  }

  m_isBeat = false;
  m_timeSincelastBeat += deltaTime;
  if (m_avgEnergy > 0.0f)
  {
    bool isABeat = (m_instantEnergy / m_avgEnergy) > m_beatSensitivity;
    if (isABeat && m_timeSincelastBeat > 0.125f)
    {
      m_isBeat = true;
      m_timeSincelastBeat = 0.0f;
    }
  }
}

void SnowGlobe::SelectRandomColour(float& red,
                                   float& green,
                                   float& blue)
{
  int index = (int)(Random(0.0f, 1.0f)*10)%9;

  red = m_treeLightColours.at(index).X();
  green = m_treeLightColours.at(index).Y();
  blue = m_treeLightColours.at(index).Z();
}

void SnowGlobe::BeginBillboard(GLfloat camX, 
                               GLfloat camY, 
                               GLfloat camZ, 
                               GLfloat xPos, 
                               GLfloat yPos, 
                               GLfloat zPos, 
                               GLboolean cylindrical)
{
   // only affect what needs to be billboarded
   glPushMatrix();

   // get the vector from the camera to the object in the XZ plane (ie. y = 0)
   Vector3D objectToCamera = Vector3D(camX, camY, camZ) - Vector3D(xPos, yPos, zPos);
   Vector3D objectToCameraXZ(objectToCamera.X(), 0.0f, objectToCamera.Z());
   objectToCamera.Normalise();
   objectToCameraXZ.Normalise();

   // get the angle to rotate by getting the dot product of the lookat and objecttocamera vectors
   Vector3D lookAt(0.0f, 0.0f, 1.0f);
   GLfloat cosAngle = lookAt.Dot(objectToCameraXZ);

   // check if the angle is positive or negative
   Vector3D upVec = lookAt.Cross(objectToCameraXZ);

   // rotate
   if (cosAngle < 0.9999f && cosAngle > -0.9999f)
   {
      glRotatef((GLfloat)acos(cosAngle)*c_oneEightyByPi, upVec.X(), upVec.Y(), upVec.Z());
   }

   if (!cylindrical)
   {
      // do an extra rotation round the x axis to do spherical billboarding
      // get the angle to rotate by
      cosAngle = objectToCameraXZ.Dot(objectToCamera);

      if (cosAngle < 0.9999f && cosAngle > -0.9999f)
      {
         if (objectToCamera.Y() < 0.0f)
         {
            glRotatef((GLfloat)acos(cosAngle)*c_oneEightyByPi, 1.0f, 0.0f, 0.0f);
         }
         else
         {
            glRotatef((GLfloat)acos(cosAngle)*c_oneEightyByPi, -1.0f, 0.0f, 0.0f);
         }
      }  
   }
}

void SnowGlobe::EndBillboard(void)
{
   // stop billboarding
   glPopMatrix();
}

void SnowGlobe::RenderTreeLight(float deltaTime,
                                float xPos,
                                float yPos,
                                float zPos,
                                float& scale,
                                float scaleRate)
{
  glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
      glTranslatef(xPos, yPos, zPos);
      glScalef(scale, scale, scale);
      scale -= scale*deltaTime/scaleRate;
      scale = max(0.0f, scale);
      BeginBillboard(m_cameraPos.X(), m_cameraPos.Y(), m_cameraPos.Z(), 
                     xPos, yPos, zPos, GL_FALSE);
      glBindTexture(GL_TEXTURE_2D, m_loadedTextures[GLOBE_LIGHT_TEXTURE]);
      glBegin(GL_TRIANGLE_STRIP);
        glTexCoord2f(0.0f, 0.0f); glVertex3f(-0.75f, -0.75f, 0.0f); 
        glTexCoord2f(1.0f, 0.0f); glVertex3f(0.75f, -0.75f, 0.0f);  
        glTexCoord2f(0.0f, 1.0f); glVertex3f(-0.75f, 0.75f, 0.0f);  
        glTexCoord2f(1.0f, 1.0f); glVertex3f(0.75f, 0.75f, 0.0f);   
      glEnd();
      EndBillboard();
    glPopMatrix();
  glPopAttrib();
}

void SnowGlobe::RenderTreeLights(float deltaTime)
{
  //-- tree lights
  glPushAttrib(GL_ENABLE_BIT | GL_CURRENT_BIT);
    glEnable(GL_ALPHA_TEST);
    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight1.red, m_treeLight1.green, m_treeLight1.blue);
      m_treeLight1.scale = 1.0f;
    }
    glColor3f(m_treeLight1.red, m_treeLight1.green, m_treeLight1.blue);
    RenderTreeLight(deltaTime, 4.6239f, 13.6541f, -5.1325f, m_treeLight1.scale, m_treeLight1.scaleRate);
    
    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight2.red, m_treeLight2.green, m_treeLight2.blue);
      m_treeLight2.scale = 1.0f;
    }
    glColor3f(m_treeLight2.red, m_treeLight2.green, m_treeLight2.blue);
    RenderTreeLight(deltaTime, 3.2149f, 8.8155f, -3.9717f, m_treeLight2.scale, m_treeLight2.scaleRate);

    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight3.red, m_treeLight3.green, m_treeLight3.blue);
      m_treeLight3.scale = 1.0f;
    }
    glColor3f(m_treeLight3.red, m_treeLight3.green, m_treeLight3.blue);
    RenderTreeLight(deltaTime, 6.1685f, 8.1867f, -3.8427f, m_treeLight3.scale, m_treeLight3.scaleRate);

    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight4.red, m_treeLight4.green, m_treeLight4.blue);
      m_treeLight4.scale = 1.0f;
    }
    glColor3f(m_treeLight4.red, m_treeLight4.green, m_treeLight4.blue);
    RenderTreeLight(deltaTime, 5.8491f, 7.2247f, -6.6942f, m_treeLight4.scale, m_treeLight4.scaleRate);

    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight5.red, m_treeLight5.green, m_treeLight5.blue);
      m_treeLight5.scale = 1.0f;
    }
    glColor3f(m_treeLight5.red, m_treeLight5.green, m_treeLight5.blue);
    RenderTreeLight(deltaTime, 4.9451f, 5.4063f, -2.745f, m_treeLight5.scale, m_treeLight5.scaleRate);

    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight6.red, m_treeLight6.green, m_treeLight6.blue);
      m_treeLight6.scale = 1.0f;
    }
    glColor3f(m_treeLight6.red, m_treeLight6.green, m_treeLight6.blue);
    RenderTreeLight(deltaTime, 3.7055f, 12.2314f, -4.929f, m_treeLight6.scale, m_treeLight6.scaleRate);

    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight7.red, m_treeLight7.green, m_treeLight7.blue);
      m_treeLight7.scale = 1.0f;
    }
    glColor3f(m_treeLight7.red, m_treeLight7.green, m_treeLight7.blue);
    RenderTreeLight(deltaTime, 3.1351f, 7.2042f, -6.3682f, m_treeLight7.scale, m_treeLight7.scaleRate);

    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight8.red, m_treeLight8.green, m_treeLight8.blue);
      m_treeLight8.scale = 1.0f;
    }
    glColor3f(m_treeLight8.red, m_treeLight8.green, m_treeLight8.blue);
    RenderTreeLight(deltaTime, 2.4865f, 6.378f, -4.4671f, m_treeLight8.scale, m_treeLight8.scaleRate);

    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight9.red, m_treeLight9.green, m_treeLight9.blue);
      m_treeLight9.scale = 1.0f;
    }
    glColor3f(m_treeLight9.red, m_treeLight9.green, m_treeLight9.blue);
    RenderTreeLight(deltaTime, 4.212f, 10.9269f, -6.5903f, m_treeLight9.scale, m_treeLight9.scaleRate);

    if (m_isBeat && RandomBool())
    {
      SelectRandomColour(m_treeLight10.red, m_treeLight10.green, m_treeLight10.blue);
      m_treeLight10.scale = 1.0f;
    }
    glColor3f(m_treeLight10.red, m_treeLight10.green, m_treeLight10.blue);
    RenderTreeLight(deltaTime, 3.2392f, 10.088f, -6.4252f, m_treeLight10.scale, m_treeLight10.scaleRate);

  glPopAttrib();
}

bool SnowGlobe::RandomBool()
{
  return Random(-1.0f, 1.0f) > 0.0f;
}

GLboolean SnowGlobe::WGLExtensionAvailable(const char* ext)
{
   if (wglGetExtensionsStringARB != NULL && m_hDC != NULL)
   {
      char* extString = NULL;

      std::string tmpExtString = (char*)wglGetExtensionsStringARB(m_hDC);
      extString = new char[tmpExtString.size()+1];
      memset(extString, 0, tmpExtString.size()+1);

      strcpy(extString, tmpExtString.c_str());

      // go to the pos of the extension
      char* extPos = strstr(extString, ext);
      if (!extPos)
      {
         if (extString != 0)
         {
            delete[] extString;
            extString = 0;
         }

         return GL_FALSE;
      }

      // change the \n to a 0
      char* tempStr = strchr(extPos, 0x20);
      if (!tempStr)
      {
         if (extString != 0)
         {
            delete[] extString;
            extString = 0;
         }

         return GL_FALSE;
      }

      tempStr[0] = 0;

      if (strcmpi(ext, extPos) == 0)
      {
         if (extString != 0)
         {
            delete[] extString;
            extString = 0;
         }
         return GL_TRUE;
      }
      else
      {
         if (extString != 0)
         {
            delete[] extString;
            extString = 0;
         }
         return GL_FALSE;
      }

      if (extString != 0)
      {
        delete[] extString;
        extString = 0;
      }
	   return GL_FALSE;		
   }

   return GL_FALSE;
}

void SnowGlobe::DisplayTitle(float deltaTime,
                             struct wamp_module_t* module)
{
  if (m_displayTitle)
  {
    // get the song title of the currently playing title
	  if (SendMessage(module->hwndParent, WM_WA_IPC, 0, IPC_ISPLAYING))
	  {
		  int index = SendMessage(module->hwndParent, WM_WA_IPC, 0, IPC_GETLISTPOS);

		  if(index >= 0)
		  {	
			  char* title = 0;

			  title = reinterpret_cast<char*>(SendMessage(module->hwndParent, WM_WA_IPC, index, IPC_GETPLAYLISTTITLE));
			  if (title != 0)
			  {
          if (m_currTitle != title)
          {
            // song has changed
            m_currTitle = title;
            m_timeTitleShownFor = 0.0f;
          }
          else
          {
            m_timeTitleShownFor += deltaTime;
          }
          static float alpha = 1.0f;

          if (m_timeTitleShownFor <= c_timeToShowTitleFor)
          {
            glColor3f(1.0f, 1.0f, 1.0f);
            
            glPushAttrib(GL_ENABLE_BIT);
              glDisable(GL_TEXTURE_2D);
              glDisable(GL_LIGHTING);

              EnterOrthographicMode();
              glRasterPos2f(0.01f, 0.93f);
              glPrint("%s", title);

              // go back to perspective mode
              SetCurrFOV(m_currFOV);
            glPopAttrib();
          }
			  }
		  }
	  }
  }
}
