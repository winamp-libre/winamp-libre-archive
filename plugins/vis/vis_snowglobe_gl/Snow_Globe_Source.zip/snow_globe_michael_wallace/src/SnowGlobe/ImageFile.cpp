#include "imagefile.h"

ImageFile::ImageFile(void) : m_imageData(NULL), m_imageWidth(0), m_imageHeight(0), m_colourDepth(0)
{
}

ImageFile::~ImageFile(void)
{
   if (m_imageData != 0)
   {
      delete m_imageData;
      m_imageData = 0;
   }
}

const GLuint* ImageFile::GetData(void) const
{
   return m_imageData;
}

const GLuint ImageFile::GetWidth(void) const
{
   return m_imageWidth;
}

const GLuint ImageFile::GetHeight(void) const
{
   return m_imageHeight;
}

const GLuint ImageFile::GetColourDepth(void) const
{
   return m_colourDepth;
}

GLvoid ImageFile::SetImageData(const GLuint* data)
{
   m_imageData = data;
}

GLvoid ImageFile::SetImageWidth(const GLuint width)
{
   m_imageWidth = width;
}

GLvoid ImageFile::SetImageHeight(const GLuint height)
{
   m_imageHeight = height;
}

GLvoid ImageFile::SetImageColourDepth(const GLuint depth)
{
   m_colourDepth = depth;
}
