#pragma once

#include <windows.h>
#include <GL/gl.h>
#include "ImageFile.h"

class IPictureImageFile : public ImageFile
{
public:
	IPictureImageFile(HDC hDC);
	virtual ~IPictureImageFile();

   virtual GLboolean LoadFromFile(const char* imagePath);
private:
   HDC      m_hDC;
};
