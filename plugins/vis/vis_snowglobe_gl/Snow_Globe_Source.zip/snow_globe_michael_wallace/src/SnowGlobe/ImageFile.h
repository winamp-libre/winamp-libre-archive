#pragma once

#include <windows.h>
#include <GL/gl.h>

class ImageFile
{
public:
   ImageFile(void);
   virtual ~ImageFile(void);

   virtual GLboolean LoadFromFile(const char* imagePath) = 0;
   const GLuint*  GetData(void) const;
   const GLuint   GetWidth(void) const;
   const GLuint   GetHeight(void) const;
   const GLuint   GetColourDepth(void) const;

protected:
   GLvoid SetImageData(const GLuint* data);
   GLvoid SetImageWidth(const GLuint width);
   GLvoid SetImageHeight(const GLuint height);
   GLvoid SetImageColourDepth(const GLuint depth);

private:
   const GLuint*  m_imageData;
   GLuint   m_imageWidth;
   GLuint   m_imageHeight;
   GLuint   m_colourDepth;
};
