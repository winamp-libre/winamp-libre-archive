#pragma once
#include "ImageFile.h"

class TgaImageFile : public ImageFile
{
public:
   TgaImageFile(void);
   virtual ~TgaImageFile(void);

public:
   virtual GLboolean LoadFromFile(const char* fileName);
};
