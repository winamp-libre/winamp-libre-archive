#include "tgaImageFile.h"
#include <stdio.h>

TgaImageFile::TgaImageFile(void)
{
}

TgaImageFile::~TgaImageFile(void)
{
}

// pretty much taken from NeHe's tuts on targas
GLboolean TgaImageFile::LoadFromFile(const char* fileName)
{
   unsigned char  FileHeader[12];
   unsigned char  ImageHeader[6];
   unsigned char  UnCompressedTGA[12] = {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0};
   unsigned char  CompressedTGA[12] = {0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0};

   // open the file in binary mode
   FILE* pFile = fopen(fileName, "rb");
   
   if (pFile)
   {
      // read the file header
      if (fread(&FileHeader, sizeof(FileHeader), 1, pFile) == 0)
         return GL_FALSE;

      if(memcmp(UnCompressedTGA, &FileHeader, sizeof(FileHeader)) == 0)
	   {
         // read the image header
         if (fread(ImageHeader, sizeof(ImageHeader), 1, pFile) == 0)
            return GL_FALSE;

         ImageFile::SetImageWidth(ImageHeader[1] * 256 + ImageHeader[0]);
         ImageFile::SetImageHeight(ImageHeader[3] * 256 + ImageHeader[2]);
         ImageFile::SetImageColourDepth(ImageHeader[4]);

         unsigned int iSize = (ImageFile::GetColourDepth()/8) * ImageFile::GetWidth() * ImageFile::GetHeight();

         GLuint* texImageData = NULL;
         if (iSize > 0)
         {
            texImageData = new GLuint[iSize];
         }

         if (!texImageData)
         {
            return GL_FALSE;
         }

         // read in the data
         if (fread(texImageData, 1, iSize, pFile) != iSize)
         {
            return GL_FALSE;
         }

         int iDimensions = ImageFile::GetWidth() * ImageFile::GetHeight();         
         void* pData = texImageData;

         int iBytes = 0;
         if (ImageFile::GetColourDepth() == 24)
         {
            iBytes = 3;
         }
         else if (ImageFile::GetColourDepth() == 32)
         {
            iBytes = 4;
         }
         else
         {
            return GL_FALSE;
         }

         // this is from a nehe tutorial
         // it swaps the R and B components 
         __asm
	      {
		      mov ecx, iDimensions // Set Up A Counter (Dimensions Of Memory Block)
		      mov ebx, pData       // Points ebx To Our Data (pData)
		      label:               // Label Used For Looping
			      mov al,[ebx+0]    // Loads Value At ebx Into al
			      mov ah,[ebx+2]    // Loads Value At ebx+2 Into ah
			      mov [ebx+2],al    // Stores Value In al At ebx+2
			      mov [ebx+0],ah    // Stores Value In ah At ebx
			      
			      add ebx,iBytes    // Moves Through The Data By 3 or 4 Bytes
			      dec ecx           // Decreases Our Loop Counter
			      jnz label         // If Not Zero Jump Back To Label
	      }

         ImageFile::SetImageData(texImageData);
      }
      else
      {
         return GL_FALSE;
      }

      // close the file
      fclose(pFile);
   }
   else
      return GL_FALSE;

   return GL_TRUE;
}
