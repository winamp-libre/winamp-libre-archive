#ifndef SNOWGLOBE_H_
#define SNOWGLOBE_H_

#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include <string>
#include <deque>
#include <vector>
#include "../wamp_module.h"
#include "../wamp_module_functions.h"
#include "vector3D.h"


// how many textures that are being created
#define TEXTURE_COUNT           12
// the maximum nuber of snow particles
#define MAX_SNOW_PARTICLE_COUNT 1500

struct SnowParticle
{
  SnowParticle() 
  : distFromCenter(0.0f),
    systemRotationSpeed(0.0f),
    localRotationSpeed(0.0f),
    currSystemRotation(0.0f),
    currLocalRotation(0.0f)
  {
    
  }

  float     distFromCenter;       // the distance from the center of the system
  Vector3D  systemAxisOfRotation; // the axis of rotation that the particle will rotate around
  Vector3D  localAxisOfRotation;  // the local axis of rotation that the particle will rotate around
  float     systemRotationSpeed;  // the speed (in degrees per second) of the rotation around the system axis
  float     localRotationSpeed;   // the speed (in degrees per second) of the rotation around the local axis
  float     currSystemRotation;   // the current angle (in degrees) around the system rotation
  float     currLocalRotation;    // the current angle (in degrees) around the local rotation
};

struct TreeLight
{
  TreeLight() 
  : red(1.0f),
    green(0.0f),
    blue(0.0f),
    scale(0.0f),
    scaleRate(0.5f)
  {
  }

  float red;
  float green;
  float blue;
  float scale;
  float scaleRate;  // the rate at which the light gets reduced in scale when not on a beat
};

// class that does all of the rendering & dynmaics work of the snowglobe vis
class SnowGlobe
{
public:
  SnowGlobe();
  ~SnowGlobe();

public:
  bool Init(HDC hDC, 
            HWND hWnd, 
            const char* pluginPath,
            bool displayTitle); 
  void Render(struct wamp_module_t *module, 
              float deltaTime);
  void RenderIdle();
  void Uninit();
  
private:
  void RenderFloor(float deltaTime,
                   GLboolean reflection);
  void RenderGlobe(float deltaTime,
                   GLboolean reflection);
  void RenderSnow(float deltaTime,
                  GLboolean reflection);
  void RenderSnowman(float deltaTime,
                   GLboolean reflection);
  void RenderSnowmanBottom(float deltaTime, 
                           GLboolean reflection);
  void RenderSnowmanMiddle(float deltaTime, 
                           GLboolean reflection);
  void RenderSnowmanTop(float deltaTime, 
                        GLboolean reflection);
  void CreateSnowParticles();
  float Random(float min, 
               float max);
  float Wrap(float val, 
             float min, 
             float max);
  void UpdateFromMusic(struct wamp_module_t *module,
                       float deltaTime);
  void SetCurrFOV(float fov);
  void EnterOrthographicMode(void);
  void BuildFont();
  void glPrint(const char *fmt, 
               ...);
  void RenderDebugText();
  float Lerp(float start, 
             float end, 
             float fraction);
  void DoBeatDetection(struct wamp_module_t* module,
                       float deltaTime);
  void SelectRandomColour(float& red, 
                          float& green, 
                          float& blue);
  void BeginBillboard(GLfloat camX, 
                      GLfloat camY, 
                      GLfloat camZ, 
                      GLfloat xPos, 
                      GLfloat yPos, 
                      GLfloat zPos, 
                      GLboolean cylindrical);
  void EndBillboard(void);
  GLboolean LoadTexture(const char* texFile, 
                        GLuint texID, 
                        GLboolean UseGLNearest=GL_FALSE);
  void RenderTreeLight(float deltaTime,
                       float xPos, 
                       float yPos, 
                       float zPos, 
                       float& scale,
                       float scaleRate);
  void RenderTreeLights(float deltaTime);
  bool RandomBool();
  GLboolean WGLExtensionAvailable(const char* ext);
  void DisplayTitle(float deltaTime,
                    struct wamp_module_t* module);

private:
  // NOTE: some of these could be local to their appropriate functions but I made them private members
  //       so that my RenderDebugText() function could display them to the screen without having to go to a lot
  //       of effort
  GLuint                    m_loadedTextures[TEXTURE_COUNT];
  HDC                       m_hDC;
  HWND                      m_hWnd;
  std::string               m_pluginPath;
  SnowParticle              m_snowParticles[MAX_SNOW_PARTICLE_COUNT];
  std::deque<unsigned char> m_intensityLastSpectrumVals;
  float                     m_intensity;
  float                     m_currFOV;
  float                     m_cameraHeight;
  double                    m_elapsedTime;
  float                     m_cameraRot;
  GLuint	                  m_fontBase;
  float                     m_snowmanBottomBop;
  float                     m_snowmanMiddleBop;
  float                     m_snowmanTopBop;
  std::deque<unsigned char> m_spectrumSamples;
  float                     m_avgEnergy;
  float                     m_instantEnergy;
  bool                      m_isBeat;
  float                     m_beatSensitivity;
  float                     m_avgVariance;
  float                     m_timeSincelastBeat;
  float                     m_danceDir;
  std::vector<Vector3D>     m_treeLightColours;
  Vector3D                  m_cameraPos;
  TreeLight                 m_treeLight1;
  TreeLight                 m_treeLight2;
  TreeLight                 m_treeLight3;
  TreeLight                 m_treeLight4;
  TreeLight                 m_treeLight5;
  TreeLight                 m_treeLight6;
  TreeLight                 m_treeLight7;
  TreeLight                 m_treeLight8;
  TreeLight                 m_treeLight9;
  TreeLight                 m_treeLight10;
  float                     m_timeTitleShownFor;
  std::string               m_currTitle;
  bool                      m_displayTitle;
};

#endif