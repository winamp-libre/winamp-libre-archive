//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by dialog.rc
//
#define IDD_INIT                        101
#define IDB_DIALOG_SCREEN               116
#define IDC_RES_800_600                 1000
#define IDC_RES_1024_768                1001
#define IDC_RES_CUSTOM                  1002
#define IDC_CUS_WIDTH                   1003
#define IDC_CUS_HEIGHT                  1004
#define IDC_BPP_16                      1005
#define IDC_BPP_32                      1006
#define IDC_FULLSCREEN                  1007
#define IDC_STAT_CUSTOM                 1008
#define IDC_RESOLUTIONS                 1013
#define IDC_CHECK1                      1014
#define IDC_DISPLAY_TITLE               1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
