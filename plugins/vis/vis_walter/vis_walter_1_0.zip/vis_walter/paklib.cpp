//
// Singing Walter - Winamp visual plugin
//
// (http://planethalflife.com/botman/)
//
// paklib.cpp
//
// Copyright (C) 2001 - Jeffrey "botman" Broome
//
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
// See the GNU General Public License for more details at:
// http://www.gnu.org/copyleft/gpl.html
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

//#include "cmdlib.h"
//#include "scriplib.h"

#include <windows.h>
#include <stdio.h>

#include "paklib.h"


FILE *pakhandle;
int num_entries;
pakinfo_t *pakinfo = NULL;


FILE *SafeOpenRead (char *filename)
{
   FILE *f;

   f = fopen(filename, "rb");

   if (!f)
   {
		MessageBox(NULL,"SafeOpenRead: fopen failed!","ERROR",MB_OK);
      return NULL;
   }

   return f;
}


void SafeClose(FILE *f)
{
   fclose(f);
}


void SafeRead (FILE *f, void *buffer, int count)
{
   if ( fread (buffer, 1, count, f) != (size_t)count)
		MessageBox(NULL,"SafeRead: fread failed!","ERROR",MB_OK);
}


/*
====================
P_OpenPak
====================
*/
FILE *P_OpenPak (char *filename)
{
   pakhandle = SafeOpenRead(filename);

   if (pakhandle == NULL)
   {
		MessageBox(NULL,"P_OpenPak: Can't open .pak file!","ERROR",MB_OK);
      return NULL;
   }

   return pakhandle;
}


void P_ClosePak(void)
{
   SafeClose(pakhandle);
}


/*
====================
P_ReadPakHeader
====================
*/
int P_ReadPakHeader(pakheader_t *pakheader)
{
   SafeRead(pakhandle, pakheader, sizeof(pakheader_t));

   if (strncmp(pakheader->identification, "PACK", 4))
      return 0;

   pakheader->dir_offset = pakheader->dir_offset;
   pakheader->dir_length = pakheader->dir_length;

   return 1;
}


/*
====================
P_ReadPakInfo
====================
*/
void P_ReadPakInfo(long offset, int num_entries, pakinfo_t *pakinfo)
{
   int index;

   fseek(pakhandle, offset, SEEK_SET);

   for (index=0; index < num_entries; index++)
   {
      SafeRead(pakhandle, &pakinfo[index], sizeof(pakinfo_t));

      pakinfo[index].file_pos = pakinfo[index].file_pos;
      pakinfo[index].file_length = pakinfo[index].file_length;
   }
}


/*
====================
P_ReadPakItem
====================
*/
void P_ReadPakItem(pakinfo_t *pakinfo, void *buffer)
{
   fseek(pakhandle, pakinfo->file_pos, SEEK_SET);

   SafeRead(pakhandle, buffer, pakinfo->file_length);
}


/*
====================
SearchPakFilename - Search PAK config info for filename
====================
*/
bool SearchPakFilename(char *filename, pakinfo_t **pakinfo_ptr)
{
   for (int index=0; index < num_entries; index++)
   {
      if (stricmp(pakinfo[index].filename, filename) == 0)
      {
         *pakinfo_ptr = &pakinfo[index];

         return TRUE;
      }
   }

   return FALSE;
}
