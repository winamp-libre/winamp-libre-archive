
#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include <string.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library

#include "vis.h"
#include "studio_model.h"
#include "paklib.h"

#include "resource.h"

char szAppName[] = "WalterVis"; // Our window class, etc


#define NUM_MODELS 3

StudioModel Walter;
StudioModel Barney;
StudioModel GMan;

float  g_lambert = 1.5;
vec3_t g_vright = {1, 0, 0};

int size_x[3] = {160, 200, 240};
int size_y[3] = {160, 200, 240};

// returns a winampVisModule when requested. Used in hdr, below
winampVisModule *getModule(int which);

// "member" functions
void config(struct winampVisModule *this_mod);  // configuration dialog
int init(struct winampVisModule *this_mod);     // initialization for module
int render(struct winampVisModule *this_mod);   // rendering for module
void quit(struct winampVisModule *this_mod);    // deinitialization for module

// configuration declarations
int config_size = 0;  // small
int config_red = 0;
int config_green = 0;
int config_blue = 0;
int config_model = 0;  // which model to use (0=scientist, 1=guard)
int config_head = 0;  // which head to use on the model (for scientist)
int config_mouth = 0;  // on scale of 0 to 9
int config_x = 0;	// screen X position and Y position, repsectively
int config_y = 0;
char config_halflife[MAX_PATH];

void config_read(struct winampVisModule *this_mod);		// reads the configuration
void config_write(struct winampVisModule *this_mod);	// writes the configuration
void config_getinifn(struct winampVisModule *this_mod, char *ini_file); // makes the .ini file filename

// our window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND hMainWnd = NULL; // main window handle

// Double buffering data
HDC    hDC = NULL;
HGLRC  hRC = NULL;    // Permanent Rendering Context

bool do_resize = FALSE;

typedef struct
{
   float transx, transy, transz;
   float rotx, roty;
} model_matrix_t;

model_matrix_t model_matrix[NUM_MODELS];

float mouth_scale[NUM_MODELS] = {6, 5, 7};


// Module header, includes version, description, and address of the module retriever function
winampVisHeader hdr = { VIS_HDRVER, "botman's Singing Walter v1.0", getModule };

// module
winampVisModule walter_module =
{
   "Singing Walter",
   NULL,	// hwndParent
   NULL,	// hDllInstance
   0,		// sRate
   0,		// nCh
   2,	   // latencyMS
   2,	   // delayMS
   0,		// spectrumNch
   2,		// waveformNch
   { 0, },	// spectrumData
   { 0, },	// waveformData
   config,
   init,
   render,
   quit
};

// this is the only exported symbol. returns our main header.
// if you are compiling C++, the extern "C" { is necessary, so we just #ifdef it
#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) winampVisHeader *winampVisGetHeader()
{
	return &hdr;
}
#ifdef __cplusplus
}
#endif


// getmodule routine from the main header. Returns NULL if an invalid module was requested.
winampVisModule *getModule(int which)
{
	switch (which)
	{
		case 0: return &walter_module;
		default:return NULL;
	}
}


int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations

   glEnable(GL_TEXTURE_2D);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(50.,1.,.1,10.);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

	return TRUE;										// Initialization Went OK
}


int ResizeGL(GLvoid)
{
	glViewport(0,0,size_x[config_size],size_y[config_size]);	// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)size_x[config_size]/(GLfloat)size_y[config_size],0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix

   return SetWindowPos (hMainWnd, NULL, config_x, config_y,
                        size_x[config_size], size_y[config_size], SWP_NOZORDER);
}


int DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
   glClearColor( config_red/255.0f, config_green/255.0f, config_blue/255.0f, 0 );

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer

   glPushMatrix();
    
   glTranslatef(model_matrix[config_model].transx,
                model_matrix[config_model].transy,
                model_matrix[config_model].transz);

	glRotatef(model_matrix[config_model].rotx, 0., 1., 0.);
   glRotatef(model_matrix[config_model].roty, 1., 0., 0.);

   glScalef( 0.01f, 0.01f, 0.01f );
	glCullFace( GL_FRONT );
	glEnable( GL_DEPTH_TEST );

   StudioModel *pModel;

   if (config_model == 1)
      pModel = &Barney;
   else if (config_model == 2)
      pModel = &GMan;
   else
      pModel = &Walter;

   pModel->SetBlending(0, 0.0f);
   pModel->SetBlending(1, 0.0f);

   if (config_model == 0)  // scientist?
      pModel->SetBodygroup(1, config_head);
//   pModel->SetBodygroup(0, config_head);

   pModel->DrawModel();

   glPopMatrix();

	return TRUE;										// Keep Going
}


VOID EnableOpenGL( HWND hWnd, HDC * hDC, HGLRC * hRC )
{
	PIXELFORMATDESCRIPTOR pfd;
	int iFormat;

	// Get the device context (DC)
	*hDC = GetDC( hWnd );

	// Set the pixel format for the DC
	ZeroMemory( & pfd, sizeof( pfd ) );
	pfd.nSize		= sizeof( pfd );
	pfd.nVersion	= 1;
	pfd.dwFlags		= PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
 	pfd.cColorBits	= 24;
	pfd.cDepthBits	= 16;
	pfd.iLayerType	= PFD_MAIN_PLANE;
	iFormat			= ChoosePixelFormat( *hDC, &pfd );
	SetPixelFormat( *hDC, iFormat, &pfd );

	// Create and enable the render context (RC)
	*hRC			= wglCreateContext( * hDC);
	wglMakeCurrent( *hDC, *hRC);
}


VOID DisableOpenGL( HWND hWnd, HDC hDC, HGLRC hRC )
{
	wglMakeCurrent( NULL, NULL );
	wglDeleteContext( hRC );
	ReleaseDC( hWnd, hDC );
}


BOOL CenterWindow (HWND hWnd)
{
    RECT    rRect, rParentRect;
    HWND    hParentWnd;
    int     wParent, hParent, xNew, yNew;
    int     w, h;

    GetWindowRect (hWnd, &rRect);
    w = rRect.right - rRect.left;
    h = rRect.bottom - rRect.top;

    hParentWnd = GetDesktopWindow();

    GetWindowRect( hParentWnd, &rParentRect );

    wParent = rParentRect.right - rParentRect.left;
    hParent = rParentRect.bottom - rParentRect.top;

    xNew = wParent/2 - w/2 + rParentRect.left;
    yNew = hParent/2 - h/2 + rParentRect.top;

    return SetWindowPos (hWnd, NULL, xNew, yNew, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
}


BOOL CALLBACK DialogProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
   static struct winampVisModule *this_mod;
   LPNMHDR nmhdr;
   LPNMCUSTOMDRAW nmdraw;
   int temp;

   switch (uMsg)
   {
      case WM_INITDIALOG:
         this_mod = (struct winampVisModule *)lParam;

         config_read(this_mod);

         CenterWindow(hDlg);

         if (config_size == 0)
         {
            SendDlgItemMessage(hDlg, IDC_RADIO1, BM_SETCHECK, TRUE, 0L);
            SendDlgItemMessage(hDlg, IDC_RADIO2, BM_SETCHECK, FALSE, 0L);
            SendDlgItemMessage(hDlg, IDC_RADIO3, BM_SETCHECK, FALSE, 0L);
         }
         else if (config_size == 1)
         {
            SendDlgItemMessage(hDlg, IDC_RADIO1, BM_SETCHECK, FALSE, 0L);
            SendDlgItemMessage(hDlg, IDC_RADIO2, BM_SETCHECK, TRUE, 0L);
            SendDlgItemMessage(hDlg, IDC_RADIO3, BM_SETCHECK, FALSE, 0L);
         }
         else
         {
            SendDlgItemMessage(hDlg, IDC_RADIO1, BM_SETCHECK, FALSE, 0L);
            SendDlgItemMessage(hDlg, IDC_RADIO2, BM_SETCHECK, FALSE, 0L);
            SendDlgItemMessage(hDlg, IDC_RADIO3, BM_SETCHECK, TRUE, 0L);
         }

         SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, 0, (LPARAM)("scientist 1"));
         SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, 0, (LPARAM)("scientist 2"));
         SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, 0, (LPARAM)("scientist 3"));
         SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, 0, (LPARAM)("scientist 4"));
         SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, 0, (LPARAM)("guard"));
         SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, 0, (LPARAM)("g-man"));

         if (config_model == 1)  // barney?
            SendDlgItemMessage(hDlg, IDC_COMBO1, CB_SETCURSEL, 4, 0L);
         else if (config_model == 2)  // g-man?
            SendDlgItemMessage(hDlg, IDC_COMBO1, CB_SETCURSEL, 5, 0L);
         else
            SendDlgItemMessage(hDlg, IDC_COMBO1, CB_SETCURSEL, config_head, 0L);

         SendDlgItemMessage(hDlg, IDC_SLIDER1, TBM_SETRANGE, FALSE, MAKELONG(0, 255)); 
         SendDlgItemMessage(hDlg, IDC_SLIDER2, TBM_SETRANGE, FALSE, MAKELONG(0, 255)); 
         SendDlgItemMessage(hDlg, IDC_SLIDER3, TBM_SETRANGE, FALSE, MAKELONG(0, 255)); 

         SendDlgItemMessage(hDlg, IDC_SLIDER1, TBM_SETTHUMBLENGTH, 10, 0L); 
         SendDlgItemMessage(hDlg, IDC_SLIDER2, TBM_SETTHUMBLENGTH, 10, 0L); 
         SendDlgItemMessage(hDlg, IDC_SLIDER3, TBM_SETTHUMBLENGTH, 10, 0L); 

         SendDlgItemMessage(hDlg, IDC_SLIDER1, TBM_SETPOS, TRUE, config_red); 
         SendDlgItemMessage(hDlg, IDC_SLIDER2, TBM_SETPOS, TRUE, config_green); 
         SendDlgItemMessage(hDlg, IDC_SLIDER3, TBM_SETPOS, TRUE, config_blue); 

         SendDlgItemMessage(hDlg, IDC_SLIDER4, TBM_SETRANGE, FALSE, MAKELONG(0, 9)); 
         SendDlgItemMessage(hDlg, IDC_SLIDER4, TBM_SETTHUMBLENGTH, 10, 0L); 
         SendDlgItemMessage(hDlg, IDC_SLIDER4, TBM_SETPOS, TRUE, config_mouth); 

         break;

      case WM_CLOSE:
            config_write(this_mod);
            EndDialog(hDlg, TRUE);
            return ( TRUE );

      case WM_COMMAND:
         switch (LOWORD(wParam))
         {
            case IDOK:
               config_write(this_mod);
               EndDialog(hDlg, TRUE);
               return ( TRUE );

            case IDC_RADIO1:
               if (SendDlgItemMessage(hDlg, IDC_RADIO1, BM_GETCHECK, 0, 0L) == 1)
               {
                  config_size = 0;  // small
                  do_resize = TRUE;
                  if (hMainWnd)
                     SendMessage(hMainWnd, WM_PAINT, 0, 0L);
               }
               break;

            case IDC_RADIO2:
               if (SendDlgItemMessage(hDlg, IDC_RADIO2, BM_GETCHECK, 0, 0L) == 1)
               {
                  config_size = 1;  // medium
                  do_resize = TRUE;
                  if (hMainWnd)
                     SendMessage(hMainWnd, WM_PAINT, 0, 0L);
               }
               break;

            case IDC_RADIO3:
               if (SendDlgItemMessage(hDlg, IDC_RADIO3, BM_GETCHECK, 0, 0L) == 1)
               {
                  config_size = 2;  // large
                  do_resize = TRUE;
                  if (hMainWnd)
                     SendMessage(hMainWnd, WM_PAINT, 0, 0L);
               }
               break;

            case IDC_COMBO1:
               if (HIWORD(wParam) == CBN_SELCHANGE)
               {
                  temp = SendDlgItemMessage(hDlg, IDC_COMBO1, CB_GETCURSEL, 0, 0L);
                  if (temp == 4)  // barney?
                  {
                     config_model = 1;
                     config_head = 0;
                  }
                  else if (temp == 5)  // g-man?
                  {
                     config_model = 2;
                     config_head = 0;
                  }
                  else
                  {
                     config_model = 0;
                     config_head = temp;
                  }
                  if (hMainWnd)
                     SendMessage(hMainWnd, WM_PAINT, 0, 0L);
               }
               break;
         }
         break;

      case WM_NOTIFY:
         nmhdr = (LPNMHDR)lParam;
         nmdraw = (LPNMCUSTOMDRAW) lParam;

         if ((nmhdr->code == NM_RELEASEDCAPTURE) ||  // slider released?
             (nmdraw->dwItemSpec = TBCD_THUMB))
         {
            switch (wParam)
            {
               case IDC_SLIDER1:
                  config_red = SendDlgItemMessage(hDlg, IDC_SLIDER1, TBM_GETPOS, 0, 0L);
                  if (hMainWnd)
                     SendMessage(hMainWnd, WM_PAINT, 0, 0L);
                  break;
               case IDC_SLIDER2:
                  config_green = SendDlgItemMessage(hDlg, IDC_SLIDER2, TBM_GETPOS, 0, 0L);
                  if (hMainWnd)
                     SendMessage(hMainWnd, WM_PAINT, 0, 0L);
                  break;
               case IDC_SLIDER3:
                  config_blue = SendDlgItemMessage(hDlg, IDC_SLIDER3, TBM_GETPOS, 0, 0L);
                  if (hMainWnd)
                     SendMessage(hMainWnd, WM_PAINT, 0, 0L);
                  break;
               case IDC_SLIDER4:
                  config_mouth = SendDlgItemMessage(hDlg, IDC_SLIDER4, TBM_GETPOS, 0, 0L);
                  break;
            }
         }
         break;
   }
   return FALSE;
}


// configuration. Passed this_mod, as a "this" parameter.
void config(struct winampVisModule *this_mod)
{
   DLGPROC  lpProcInstance;

   lpProcInstance = (DLGPROC) MakeProcInstance( (FARPROC) DialogProc,
                                                this_mod->hDllInstance ) ;
   DialogBoxParam(this_mod->hDllInstance, MAKEINTRESOURCE(IDD_DIALOG1),
                  hMainWnd, lpProcInstance, (LPARAM)this_mod);
   FreeProcInstance( (FARPROC) lpProcInstance ) ;
}


// initialization. Registers our window class, creates our window, etc.
int init(struct winampVisModule *this_mod)
{
   DWORD dwR;
   HKEY  hKey;
   DWORD Type;
   DWORD DataSize;
   int size;
   pakheader_t  pakheader;

   config_halflife[0] = 0;

   config_read(this_mod);

   if (config_halflife[0] == 0)
   {
      dwR = RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("Software\\Valve\\Half-Life"), 0, KEY_READ, &hKey);

      if (dwR != ERROR_SUCCESS)
      {
         MessageBox(this_mod->hwndParent,"Error opening registry key for Half-Life InstallPath","Error",MB_OK);
         return 1;
      }

      DataSize = MAX_PATH;

      dwR = RegQueryValueEx(hKey, TEXT("InstallPath"), 0, &Type, (LPBYTE)config_halflife, &DataSize);

      if (dwR != ERROR_SUCCESS)
      {
         MessageBox(this_mod->hwndParent,"Error reading registry key for Half-Life InstallPath","Error",MB_OK);
         return 1;
      }
   }

   strcat(config_halflife, "\\valve\\pak0.pak");

   if (P_OpenPak (config_halflife) == NULL)
   {
      char msg[MAX_PATH];
      wsprintf(msg, "Error reading %s\n( Is another application using it? )", config_halflife);
      MessageBox(this_mod->hwndParent, msg, "Error", MB_OK);
      return 1;
   }

   if (!P_ReadPakHeader(&pakheader))
   {
      MessageBox(this_mod->hwndParent, "Error reading pak0.pak file!", "Error", MB_OK);
      P_ClosePak();
      return 1;
   }

   num_entries = pakheader.dir_length / sizeof(pakinfo_t);

   size = num_entries * sizeof(pakinfo_t);

   if (pakheader.dir_length != size)
   {
      MessageBox(this_mod->hwndParent, "Error pak0.pak is not a valid pak file!", "Error", MB_OK);
      return 1;  // dir_length NOT even multiple of pakinfo size
   }

   pakinfo = (pakinfo_t *)malloc(pakheader.dir_length);

   P_ReadPakInfo(pakheader.dir_offset, num_entries, pakinfo);


	{	// Register our window class
		WNDCLASS wc;
		memset(&wc,0,sizeof(wc));

      wc.style = CS_OWNDC; // And Own DC For Window.
      wc.lpfnWndProc = WndProc;				// our window procedure
      wc.cbClsExtra	= 0;
      wc.cbWndExtra	= 0;
		wc.hInstance = this_mod->hDllInstance;	// hInstance of DLL
      wc.hIcon		= LoadIcon( NULL, IDI_APPLICATION );
      wc.hCursor		= LoadCursor( NULL, IDC_ARROW );
      wc.hbrBackground= (HBRUSH)GetStockObject( BLACK_BRUSH );
      wc.lpszMenuName	= NULL;
		wc.lpszClassName = szAppName;			// our window class name
	
		if (!RegisterClass(&wc)) 
		{
			MessageBox(this_mod->hwndParent,"Error registering window class","Error",MB_OK);
			return 1;
		}
	}

	// Create main window

	hMainWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW|WS_EX_APPWINDOW,	// these exstyles put a nice small frame, 
		szAppName,							// our window class name
		this_mod->description,				// use description for a window title
		WS_VISIBLE|WS_SYSMENU,				// make the window visible with a close button
		config_x, config_y,					// screen position (read from config)
		size_x[config_size], size_y[config_size],	// width & height of window
		this_mod->hwndParent,				// parent window (winamp main window)
		NULL,								// no menu
		this_mod->hDllInstance,				// hInstance of DLL
		0); // no window creation data

	if (!hMainWnd) 
	{
      char msg[80];
      wsprintf(msg, "Error creating Window: %d", GetLastError());
		MessageBox(this_mod->hwndParent, msg, "Error", MB_OK);
		return 1;
	}

	// Enable OpenGL for the window
	EnableOpenGL(hMainWnd, &hDC, &hRC);

	SetWindowLong(hMainWnd,GWL_USERDATA,(LONG)this_mod); // set our user data to a "this" pointer

	// show the window
	ShowWindow(hMainWnd,SW_SHOWNORMAL);

	glViewport(0,0,size_x[config_size],size_y[config_size]);	// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)size_x[config_size]/(GLfloat)size_y[config_size],0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK);
		return FALSE;								// Return FALSE
	}

   Walter.Init("models/scientist.mdl");

   Walter.SetController(0, 0.0f);
   Walter.SetController(1, 0.0f);
   Walter.SetController(2, 0.0f);
   Walter.SetController(3, 0.0f);

   Walter.SetSequence(13);  // scientist idle sequence

   Barney.Init("models/barney.mdl");

   Barney.SetController(0, 0.0f);
   Barney.SetController(1, 0.0f);
   Barney.SetController(2, 0.0f);
   Barney.SetController(3, 0.0f);

   Barney.SetSequence(0);  // barney idle sequence

   GMan.Init("models/gman.mdl");

   GMan.SetController(0, 0.0f);
   GMan.SetController(1, 0.0f);
   GMan.SetController(2, 0.0f);
   GMan.SetController(3, 0.0f);

   GMan.SetSequence(5);  // g-man idle sequence (tilting head)

   P_ClosePak();  // close the pak0.pak file

   model_matrix[0].transx = -0.0f;  // scientist
   model_matrix[0].transy = -0.65f;
   model_matrix[0].transz = -0.23f;
   model_matrix[0].rotx = 270.0f;
   model_matrix[0].roty = -90.0f;

   model_matrix[1].transx = -0.010f;  // barney
   model_matrix[1].transy = -0.68f;
   model_matrix[1].transz = -0.21f;
   model_matrix[1].rotx = 275.0f;
   model_matrix[1].roty = -90.0f;

   model_matrix[2].transx = -0.0f;  // g-man
   model_matrix[2].transy = -0.68f;
   model_matrix[2].transz = -0.19f;
   model_matrix[2].rotx = 270.0f;
   model_matrix[2].roty = -90.0f;

   StudioModel *pModel;

   if (config_model == 1)
      pModel = &Barney;
   else if (config_model == 2)
      pModel = &GMan;
   else
      pModel = &Walter;

   if (config_model == 0)  // scientist?
      pModel->SetBodygroup(1, config_head);
//   pModel->SetBodygroup(0, config_head);

   pModel->SetMouth(0);

   DrawGLScene();

	SwapBuffers(hDC);					// Swap Buffers (Double Buffering)

	return 0;
}


// render function. Returns 0 if successful, 1 if visualization should end.
int render(struct winampVisModule *this_mod)
{
	int x, y;
	float total=0.0;
   static float running_total[4] = {0,0,0,0};
   float scale, magnify;

   for (y=0; y < this_mod->nCh; y++)  // channels
   {
	   for (x = 0; x < 576; x ++)
         total += abs((this_mod->waveformData[y][x]^128) - 128);
   }

   scale = mouth_scale[config_model] * 576;
   total = total / scale;

   magnify = ((float)config_mouth + 5.0f) / 5.0f;
   total = total * magnify;

   if (total > 24.0f)
      total = 24.0f;

   for (x=0; x < 3; x++)
      running_total[x] = running_total[x+1];
   running_total[3] = total;

   total = 0;
   for (x=0; x < 4; x++)
      total += running_total[x];

   total = total / 4;

   static float curr = 0.0f, prev = 0.0f, direction = 1.0f;
   curr = GetTickCount( ) / 1000.0f;

   StudioModel *pModel;

   if (config_model == 1)
      pModel = &Barney;
   else if (config_model == 2)
      pModel = &GMan;
   else
      pModel = &Walter;

   pModel->SetMouth(total);

   pModel->AdvanceFrame( direction * (curr - prev));

   prev = curr;

   DrawGLScene();

	SwapBuffers(hDC);					// Swap Buffers (Double Buffering)

	return 0;
}

// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quit(struct winampVisModule *this_mod)
{
	config_write(this_mod);		// write configuration

   if (pakinfo)
      free(pakinfo);

	// shutdown OpenGL
	DisableOpenGL(hMainWnd, hDC, hRC);

	DestroyWindow(hMainWnd); // delete our window

	UnregisterClass(szAppName,this_mod->hDllInstance); // unregister window class
}

// window procedure for our window
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_CREATE:
         {
            InitCommonControls();  // for WinNT and Win2K
         }
         return 0;
		case WM_ERASEBKGND:  return 0;
		case WM_DESTROY: PostQuitMessage(0); return 0;
		case WM_KEYDOWN: // pass keyboard messages to main winamp window (for processing)
		case WM_KEYUP:
			{	// get this_mod from our window's user data
				winampVisModule *this_mod = (winampVisModule *) GetWindowLong(hwnd,GWL_USERDATA);
				PostMessage(this_mod->hwndParent,message,wParam,lParam);
			}
		return 0;

		case WM_PAINT:
			{ // update from doublebuffer
            if (do_resize)
            {
               do_resize = FALSE;
               ResizeGL();
            }

            DrawGLScene();

				PAINTSTRUCT ps;
				RECT r;
				HDC hdc = BeginPaint(hwnd,&ps);
				GetClientRect(hwnd,&r);
				BitBlt(hdc,0,0,r.right,r.bottom,hDC,0,0,SRCCOPY);
				EndPaint(hwnd,&ps);

            SwapBuffers(hDC);
			}
      return 0;

      case WM_SETFOCUS:
         {
            if (hDC)
            {
               DrawGLScene();
               SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
            }
         }
      return 0;
		case WM_MOVE:
			{	// get config_x and config_y for configuration
				RECT r, rDesktop;
            GetWindowRect(GetDesktopWindow(), &rDesktop );
				GetWindowRect(hMainWnd,&r);
            if ((r.left >= rDesktop.left) && (r.left <= rDesktop.right) &&
                (r.top >= rDesktop.top) && (r.top <= rDesktop.bottom))
            {
               config_x = (INT)r.left;
               config_y = (INT)r.top;

               winampVisModule *this_mod = (winampVisModule *) GetWindowLong(hwnd,GWL_USERDATA);
               if (this_mod != NULL)
                  config_write(this_mod);
            }
			}
		return 0;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}


void config_getinifn(struct winampVisModule *this_mod, char *ini_file)
{	// makes a .ini file in the winamp directory named "plugin.ini"
	char *p;
	GetModuleFileName(this_mod->hDllInstance,ini_file,MAX_PATH);
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	strcat(ini_file,"walter.ini");
}


void config_read(struct winampVisModule *this_mod)
{
	char ini_file[MAX_PATH];

	config_getinifn(this_mod,ini_file);

	config_x = (INT)GetPrivateProfileInt(this_mod->description,TEXT("xPos"),10,ini_file);
	config_y = (INT)GetPrivateProfileInt(this_mod->description,TEXT("yPos"),10,ini_file);
	config_size = (INT)GetPrivateProfileInt(this_mod->description,TEXT("size"),1,ini_file);
	config_red = (INT)GetPrivateProfileInt(this_mod->description,TEXT("red"),0,ini_file);
	config_green = (INT)GetPrivateProfileInt(this_mod->description,TEXT("green"),128,ini_file);
	config_blue = (INT)GetPrivateProfileInt(this_mod->description,TEXT("blue"),128,ini_file);
	config_model = (INT)GetPrivateProfileInt(this_mod->description,TEXT("model"),0,ini_file);
	config_head = (INT)GetPrivateProfileInt(this_mod->description,TEXT("head"),0,ini_file);
	config_mouth = (INT)GetPrivateProfileInt(this_mod->description,TEXT("mouth"),3,ini_file);
   int len = (INT)GetPrivateProfileString(this_mod->description,TEXT("halflife_dir"),"",config_halflife,MAX_PATH,ini_file);
   if (len < 1)
      config_halflife[0] = 0;
}

void config_write(struct winampVisModule *this_mod)
{
	char string[32];
	char ini_file[MAX_PATH];

	config_getinifn(this_mod,ini_file);

	wsprintf(string,TEXT("%i"),config_x);
	WritePrivateProfileString(this_mod->description,TEXT("xPos"),string,ini_file);
	wsprintf(string,TEXT("%i"),config_y);
	WritePrivateProfileString(this_mod->description,TEXT("yPos"),string,ini_file);
	wsprintf(string,TEXT("%i"),config_size);
	WritePrivateProfileString(this_mod->description,TEXT("size"),string,ini_file);
	wsprintf(string,TEXT("%i"),config_red);
	WritePrivateProfileString(this_mod->description,TEXT("red"),string,ini_file);
	wsprintf(string,TEXT("%i"),config_green);
	WritePrivateProfileString(this_mod->description,TEXT("green"),string,ini_file);
	wsprintf(string,TEXT("%i"),config_blue);
	WritePrivateProfileString(this_mod->description,TEXT("blue"),string,ini_file);
	wsprintf(string,TEXT("%i"),config_model);
	WritePrivateProfileString(this_mod->description,TEXT("model"),string,ini_file);
	wsprintf(string,TEXT("%i"),config_head);
	WritePrivateProfileString(this_mod->description,TEXT("head"),string,ini_file);
	wsprintf(string,TEXT("%i"),config_mouth);
	WritePrivateProfileString(this_mod->description,TEXT("mouth"),string,ini_file);
}
