Singing Walter - Version 1.0 (November 25th, 2001)

Singing Walter is a visual plugin for Winamp (www.winamp.com).  You will
need to have Half-Life installed on your machine to use this plugin.  You
will also need a video card that supports OpenGL.  I highly recommend using
a 3D graphics card with hardware acceleration for OpenGL.

You should have extracted the .zip file to your Winamp Plugins folder (the
plugin folder on my machine is C:\Program Files\Winamp\Plugins).  Winamp
will automatically find the Singing Walter plugin the next time it is
started running.

To start the plugin, select "Visualization->Select plug-in" from the Winamp
menu.  Then look for "botman's Singing Walter" plugin, click on it, then
click on the "Start" button to start it.  Click on the "Close" button to
close the Winamp Preferences window.

The Singing Walter plugin can be configured by selecting "Visualization->
Configure plug-in" from the Winamp menu.  You can select the window size,
one of four scientist models, the guard model (Barney) or the G-man model.
You can adjust the background color using the Red, Green and Blue slider
controls.  You can adjust the mouth sensitivity using the Mouth Scale
slider control.

If you move the Singing Walter plugin window, it will remember that position
and will be placed at that location the next time you start the Singing
Walter plugin.

Now all you need to do is start playing some music (or any audio file)
with the Winamp player, and Walter, or Barney or the G-man will sing along
with your favorite song!  I hope you like it.

Jeffrey "botman" Broome