#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	VALUE	258
#define	IDENTIFIER	259
#define	FUNCTION1	260
#define	FUNCTION2	261
#define	FUNCTION3	262
#define	UMINUS	263
#define	UPLUS	264


extern YYSTYPE yylval;
