#ifndef __EVAL_H
#define __EVAL_H

#ifdef __cplusplus
extern "C" {
#endif

  // stuff that apps will want to use
#define EVAL_MAX_VARS 103//90
        // note: in order for presets not to break, this 
        // value must be equal to the number of built-in
        // per-frame variables (see CState::var_pf_*), 
        // PLUS 30.  otherwise, the presets might try to
        // create too many of their own new custom per-
        // frame variables, and there wouldn't be room.
        // 
        // A good preset to test with is Krash & Telek - Real Noughts and Crosses (random ending),
        // as it uses exactly 30 custom per-frame vars.
        // 
        // History:         # pf vars  EVAL_MAX_VARS  # left for user (should never decrease!)
        // ---------------  ---------  -------------  ----------------------------------------
        //  Milkdrop 1.03   60         90             30
        //  Milkdrop 1.04   73         103            30

typedef struct 
{
  char name[8];
  double value;
} varType;

void resetVars(varType *vars);
double *getVarPtr(char *varName);
double *registerVar(char *varName);


// other shat

extern varType *varTable;
extern int *errPtr;
extern int colCount;
extern int result;

int setVar(int varNum, double value);
int getVar(int varNum);
void *compileExpression(char *txt);



#ifdef __cplusplus
}
#endif

#endif