/*
  LICENSE
  -------
  Copyright (C) 1999-2002 Nullsoft, Inc.

  This source code is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this source code or the software it produces.

  Permission is granted to anyone to use this source code for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this source code must not be misrepresented; you must not
     claim that you wrote the original source code.  If you use this source code
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original source code.
  3. This notice may not be removed or altered from any source distribution.
*/

#include <afxwin.h>
#include <stdio.h>

#include "vis.h"
#include "plugin.h"
#include "defines.h"
#include "resource.h"

CPlugin  g_plugin;

bool g_bFullyExited = true;



void config(struct winampVisModule *this_mod); // configuration dialog
int init(struct winampVisModule *this_mod);       // initialization for module
int render1(struct winampVisModule *this_mod);  // rendering for module 1
void quit(struct winampVisModule *this_mod);   // deinitialization for module

// our only plugin module in this plugin:
winampVisModule mod1 =
{
    MODULEDESC,
    NULL,    // hwndParent
    NULL,    // hDllInstance
    0,        // sRate
    0,        // nCh
    0,        // latencyMS - tells winamp how much in advance you want the audio data, 
            //             in ms.
    0,        // delayMS - if winamp tells the plugin to render a frame and it takes
            //           less than this # of milliseconds, winamp will sleep (go idle)
            //           for the remainder.  In effect, this limits the framerate of
            //           the plugin.  A value of 10 would cause a fps limit of ~100.
            //           Derivation: (1000 ms/sec) / (10 ms/frame) = 100 fps.
    0,        // spectrumNch
    2,        // waveformNch
    { 0, },    // spectrumData
    { 0, },    // waveformData
    config,
    init,
    render1, 
    quit
};

// getmodule routine from the main header. Returns NULL if an invalid module was requested,
// otherwise returns either mod1, mod2 or mod3 depending on 'which'.
winampVisModule *getModule(int which)
{
    switch (which)
    {
        case 0: return &mod1;
        //case 1: return &mod2;
        //case 2: return &mod3;
        default: return NULL;
    }
}

// Module header, includes version, description, and address of the module retriever function
winampVisHeader hdr = { VIS_HDRVER, DLLDESC, getModule };

// this is the only exported symbol. returns our main header.
// if you are compiling C++, the extern "C" { is necessary, so we just #ifdef it
#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) winampVisHeader *winampVisGetHeader()
{
    return &hdr;
}
#ifdef __cplusplus
}
#endif

bool WaitUntilPluginFinished(HWND hWndWinamp)
{
    int slept = 0;
    while (!g_bFullyExited && slept < 1000)
    {
        Sleep(50);
        slept += 50;
    }
    if (!g_bFullyExited)
    {
        MessageBox(hWndWinamp, "Error: the plugin is already running.", "ERROR", MB_OK|MB_SETFOREGROUND|MB_TOPMOST);
        return false;        
    }

    return true;
}

// configuration. Passed this_mod, as a "this" parameter. Allows you to make one configuration
// function that shares code for all your modules (you don't HAVE to use it though, you can make
// config1(), config2(), etc...)
void config(struct winampVisModule *this_mod)
{
    if (!WaitUntilPluginFinished(this_mod->hwndParent))
        return;

    InitCommonControls(); // loads common controls DLL 

    g_bFullyExited = false;
    
    g_plugin.PluginPreInitialize(this_mod->hwndParent, this_mod->hDllInstance);
    
    DialogBoxParam(this_mod->hDllInstance, MAKEINTRESOURCE(IDD_CONFIG), this_mod->hwndParent, (DLGPROC)g_plugin.ConfigDialogProc, (LPARAM)&g_plugin);
    
    //g_plugin.PluginQuit();

    g_bFullyExited = true;
}

// initialization. Registers our window class, creates our window, etc. Again, this one works for
// both modules, but you could make init1() and init2()...
// returns 0 on success, 1 on failure.
int init(struct winampVisModule *this_mod)
{
    if (!WaitUntilPluginFinished(this_mod->hwndParent))
    {
        return 1;        
    }

    if (SendMessage(mod1.hwndParent,WM_WA_IPC,0,0) < 0x4000)
    {
        // query winamp for its playback state
        int ret = SendMessage(this_mod->hwndParent, WM_USER, 0, 104); 
        // ret=1: playing, ret=3: paused, other: stopped

        if (ret != 1)
        {
            MessageBox(this_mod->hwndParent, "This plugin can't run without music.\r\nPlease play some music, through Winamp, and then try running the plugin again.", "No music playing", MB_OK|MB_SETFOREGROUND|MB_TOPMOST|MB_TASKMODAL );
            return 1;  // failure
        }
    }

    g_bFullyExited = false;

    if (!g_plugin.PluginPreInitialize(this_mod->hwndParent, this_mod->hDllInstance))
    {
        g_plugin.PluginQuit();
        g_bFullyExited = true;
        return 1;
    }

    if (!g_plugin.PluginInitialize())
    {
        g_plugin.PluginQuit();
        g_bFullyExited = true;
        return 1;
    }

    return 0;    // success
}

// render function for oscilliscope. Returns 0 if successful, 1 if visualization should end.
int render1(struct winampVisModule *this_mod)
{
    if (g_plugin.PluginRender(this_mod->waveformData[0], this_mod->waveformData[1]))
        return 0;    // ok
    else
        return 1;    // failed
}


// cleanup (opposite of init()). Should destroy the window, unregister the window class, etc.
void quit(struct winampVisModule *this_mod)
{
    g_plugin.PluginQuit();
    g_bFullyExited = true;
}


