/*
  LICENSE
  -------
  Copyright (C) 1999-2002 Nullsoft, Inc.

  This source code is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this source code or the software it produces.

  Permission is granted to anyone to use this source code for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this source code must not be misrepresented; you must not
     claim that you wrote the original source code.  If you use this source code
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original source code.
  3. This notice may not be removed or altered from any source distribution.
*/

#ifndef __NULLSOFT_DX8_PLUGIN_SHELL_UTILITY_H__
#define __NULLSOFT_DX8_PLUGIN_SHELL_UTILITY_H__ 1

#include <windows.h>

#define SafeRelease(x) { if (x) {x->Release(); x=NULL;} } 
#define SafeDelete(x) { if (x) {delete x; x=NULL;} }
#define IsNullGuid(lpGUID) ( ((int*)lpGUID)[0]==0 && ((int*)lpGUID)[1]==0 && ((int*)lpGUID)[2]==0 && ((int*)lpGUID)[3]==0 )
#define DlgItemIsChecked(hDlg, nIDDlgItem) ((SendDlgItemMessage(hDlg, nIDDlgItem, BM_GETCHECK, (WPARAM) 0, (LPARAM) 0) == BST_CHECKED) ? true : false)
#define CosineInterp(x) (0.5f - 0.5f*cosf((x) * 3.1415926535898f))
#define InvCosineInterp(x) (acosf(1.0f - 2.0f*(x))/3.1415926535898f)
float   PowCosineInterp(float x, float pow);
float   AdjustRateToFPS(float per_frame_decay_rate_at_fps1, float fps1, float actual_fps);

//int   GetPrivateProfileInt - part of Win32 API
#define GetPrivateProfileBool(w,x,y,z) ((bool)(GetPrivateProfileInt(w,x,y,z) != 0))
#define GetPrivateProfileBOOL(w,x,y,z) ((BOOL)(GetPrivateProfileInt(w,x,y,z) != 0))
float   GetPrivateProfileFloat(char *szSectionName, char *szKeyName, float fDefault, char *szIniFile);
bool    WritePrivateProfileInt(int d, char *szKeyName, char *szIniFile, char *szSectionName);
bool    WritePrivateProfileFloat(float f, char *szKeyName, char *szIniFile, char *szSectionName);

void    SetScrollLock(int bNewState);
void    RemoveExtension(char *str);
void    RemoveSingleAmpersands(char *str);
void    TextToGuid(char *str, GUID *pGUID);
void    GuidToText(GUID *pGUID, char *str, int nStrLen);
//int    GetPentiumTimeRaw(unsigned __int64 *cpu_timestamp);
//double GetPentiumTimeAsDouble(unsigned __int64 frequency);
#ifdef _DEBUG
    void    OutputDebugMessage(char *szStartText, HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam); // only available in RELEASE builds!
#endif
void    MissingDirectX(HWND hwnd);
bool    CheckForMMX();
bool    CheckForSSE();
void    memcpy_MMX(void *pDest, void *pSrc, int nBytes); // CALL CheckForMMX() FIRST!!!
void    memset_MMX(void *pDest, unsigned char value, int nBytes); // CALL CheckForMMX() FIRST!!!
void    GetDesktopFolder(char *szDesktopFolder); // should be MAX_PATH len.



#include "icon_t.h"
#include <shlobj.h>
#include <list> 

BOOL    DoExplorerMenu (HWND hwnd, LPCTSTR pszPath,   POINT point);
BOOL    DoExplorerMenu (HWND hwnd, LPITEMIDLIST pidl, POINT point);
UINT    GetItemCount (LPITEMIDLIST pidl);
LPITEMIDLIST GetNextItem (LPITEMIDLIST pidl);
LPITEMIDLIST DuplicateItem (LPMALLOC pMalloc, LPITEMIDLIST pidl);
void    FindDesktopWindows(HWND *desktop_progman, HWND *desktopview_wnd, HWND *listview_wnd);
void    ExecutePidl(LPITEMIDLIST pidl, char *szPathAndFile, char *szWorkingDirectory, HWND hWnd);
//int   DetectWin2kOrLater();
int     GetDesktopIconSize();








#endif