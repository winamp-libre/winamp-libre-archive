
#ifndef __ICON_T_H__
#define __ICON_T_H__ 1


#include <windows.h>
#include <shlobj.h> // for ITEMIDLIST

typedef struct
{
    int x, y, selected, icon_bitmap_idx, checksum[3], bUpdate;
    DWORD dwReserved1;
    DWORD dwReserved2;
    DWORD dwReserved3;
    DWORD dwReserved4;
    RECT icon_rect;
    RECT label_rect;
    BYTE pidl[1024];    // when using this, cast it to an ITEMIDLIST
    TCHAR name[MAX_PATH];
} icon_t;







#endif