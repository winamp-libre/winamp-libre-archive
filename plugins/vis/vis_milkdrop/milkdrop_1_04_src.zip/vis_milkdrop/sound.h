/*
  LICENSE
  -------
Copyright 2005 Nullsoft, Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer. 

  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution. 

  * Neither the name of Nullsoft nor the names of its contributors may be used to 
    endorse or promote products derived from this software without specific prior written permission. 
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _MILKDROP_SOUND_
#define _MILKDROP_SOUND_ 1

// note: there is only one instance of this class, and it is GLOBAL;
//        see milkdrop.h


#include "fft.h"


#define FFT_SAMPLES 512		// NOTE: this must match the # of samples in the FFT class!



typedef struct
{
	float imm[3];
	unsigned int dwTime;
} td_frame_hist;


#define HIST_MAX_FPS	60.0
#define HIST_MIN_FPS	10.0
#define HIST_MAX_BPM	240.0
#define HIST_MIN_BPM	15.0
#define HIST_MAX_MATCHING_WINDOW (60.0f/HIST_MIN_BPM * 2.0f)					// in seconds
#define HIST_MAX_FRAMES          ((int)(HIST_MAX_MATCHING_WINDOW * HIST_MAX_FPS + 1))	// in frames

class CSoundData
{
public:
	CSoundData();
	~CSoundData();

	void Init();
	void Finish();
	void AnalyzeNewSound(unsigned char *pL, unsigned char *pR);	// assumes 576 samples in each array!
	int  GoGoAlignatron(int nSamplesBeingDisplayed);

	// note: clients should treat these as read-only
	float   imm[3];			// bass, mids, treble (absolute)
	float	imm_rel[3];		// bass, mids, treble (relative to song; 1=avg, 0.9~below, 1.1~above)
	float	avg[3];			// bass, mids, treble (absolute)
	float	avg_rel[3];		// bass, mids, treble (relative to song; 1=avg, 0.9~below, 1.1~above)
	float	long_avg[3];	// bass, mids, treble (absolute)

	// note: these are temporarily here for debug purposes; should be 'protected'
	float			fSpecLeft[FFT_SAMPLES];
	//float			fSpecRight[FFT_SAMPLES];	// not computed
	float			fSoundLeft[576];		
	float			fSoundRight[576];		
	float			fOldSoundLeft[576];		
	float			fOldSoundRight[576];	
	td_frame_hist	hist[HIST_MAX_FRAMES];
	int				histpos;

protected:
	FFT     m_fft;

	int		m_nFrames;
	int		m_nLastFrameAlignPos;
	
};











#endif



















