
>>> DrO (http://forums.winamp.com/member.php?s=&action=getinfo&userid=122037)
    has updated v2.81b to v2.81d by changing a few files, as he posted here:
    http://forums.winamp.com/showthread.php?postid=2054764#post2054764

>>> This file you have here is the sourcecode from http://www.nullsoft.com/free/avs/ (v2.81b),
    with the few files from http://www.nunzioweb.com/daz/temp/avs/vis_avs_changed.zip (2.81d) overwritten over v2.81b

>>> Since DrO's download location sais that it's temporary, I've put this file up as a backup for his server and to have a complete file.

>>> If you have questions or comments, the AVS forums are over here:
    http://forums.winamp.com/forumdisplay.php?s=&forumid=85

>>> Keep in mind though, that there is currently only little, if any, development going on over there.
    If you have suggestions, your best chances are to make a start and post your results there with your questions, rather than to ask 'us' to do it, as none of us are Nullsoft employees.

>>> You'll also need the Winamp SDK. Search the forums for the lastest version.


Greetings, 

'Warrior of the Light'

 http://Warrior-of-the-Light.net
 info.wotl@gmail.com