// DirDlg.cpp : implementation file
//

#include "stdafx.h"

#include "DirDlg.h"
#include "Logger.h"
#include "MyVector.h"
#include "MyString.h"
#include "RegistryKey.h"
#include "Settings.h"
#include "shlobj.h"
#include "synconfig.h"
#include "Utility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDirDlg dialog


void CDirDlg::refreshDirList() {
	FunctionLogger flog("CDirDlg::refreshDirList()", Logger::guifunc);
	CListBox *dirs = (CListBox *) GetDlgItem(IDC_DIRLIST);

	// Clear the list
	dirs->ResetContent();

	// Add directories to the list box
	for (vector<string>::const_iterator it = m_settings.getDirectories().begin();
		it != m_settings.getDirectories().end();
		++it)
		dirs->AddString(it->c_str());
}


void CDirDlg::refreshInstallDir() {
	FunctionLogger flog("void CDirDlg::refreshInstallDir()", Logger::guifunc);

	try {
		RegistryKey r(HKEY_CURRENT_USER, "Software\\MediaScience\\Sonique\\General Preferences 0.80\\");
		string soniquedir = nicifyDirPath(r.getString("SoniquePath"));
		SetDlgItemText(IDC_REG, soniquedir.c_str());
	}
	catch (...) { 
		SetDlgItemText(IDC_REG, "");
	}
}


CDirDlg::CDirDlg(Settings& settings, CWnd* pParent /*=NULL*/)
:	m_settings(settings),
	CDialog(CDirDlg::IDD, pParent)
{
	FunctionLogger flog("CDirDlg::CDirDlg(Settings&, CWnd*)", Logger::guifunc);
	//{{AFX_DATA_INIT(CDirDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDirDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDirDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDirDlg, CDialog)
	//{{AFX_MSG_MAP(dirconfig)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	ON_BN_CLICKED(IDC_FIND, OnFind)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_FINDREG, OnFindreg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDirDlg message handlers

void CDirDlg::OnReset() 
{
	FunctionLogger flog("CDirDlg::OnReset()", Logger::guifunc);
	m_settings.resetDirectories();
	refreshDirList();
	CWnd *visini = (CWnd *) GetDlgItem(IDC_VISINI);
	visini->SetWindowText(m_settings.getVisIni().c_str());
}

void CDirDlg::OnRemove() 
{
	FunctionLogger flog("CDirDlg::OnRemove()", Logger::guifunc);
	// Get the selected directory
	CListBox *dirs = (CListBox *) GetDlgItem(IDC_DIRLIST);

	int sel = dirs->GetCurSel();
	dirs->DeleteString(sel);
}

BOOL CDirDlg::OnInitDialog() 
{
	FunctionLogger flog("CDirDlg::OnInitDialog()", Logger::guifunc);
	CDialog::OnInitDialog();
	
	refreshDirList();

	CWnd *visini = (CWnd *) GetDlgItem(IDC_VISINI);
	visini->SetWindowText(m_settings.getVisIni().c_str());

	refreshInstallDir();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDirDlg::OnOK() 
{
	FunctionLogger flog("CDirDlg::OnOK()", Logger::guifunc);

	// Copy the vis ini to the settings
	CWnd *visini = (CWnd *) GetDlgItem(IDC_VISINI);
	int len = visini->GetWindowTextLength();
	char *buf = new char[len + 1];
	visini->GetWindowText(buf, len + 1);

	if (exists(buf)) m_settings.setVisIni(buf);
	else {
		if (string(buf) != "") {
			int response = MessageBox("The vis.ini file does not exist\nContinue anyway?", 
				"Synesthesia Error", MB_YESNO | MB_ICONQUESTION);

			if (response == IDYES) m_settings.setVisIni("");
			else {
				delete[] buf;
				return;
			}
		}
	}

	delete[] buf;

	// Copy the list box's contents into the settings
	CListBox *dirs = (CListBox *) GetDlgItem(IDC_DIRLIST);

	int num = dirs->GetCount();
	vector<string> dirlist(num);

	for (int i = 0; i < num; ++i) {
		int size = dirs->GetTextLen(i);
		char *buf = new char[size + 1];
		dirs->GetText(i, buf);
		dirlist[i] = string(buf);
		delete[] buf;
	}

	m_settings.setDirectories(dirlist);
	m_settings.updatePlugins();

	// Copy the install dir to the registry
	try {
		RegistryKey r(HKEY_CURRENT_USER, "Software\\MediaScience\\Sonique\\General Preferences 0.80\\", true);
		char buf[FILENAME_MAX];
		GetDlgItemText(IDC_REG, buf, FILENAME_MAX);
		r.setString("SoniquePath", buf);
	}
	catch (...) { }

	// Finish up
	CDialog::OnOK();
}

void CDirDlg::OnFind() 
{
	FunctionLogger flog("CDirDlg::OnFind()", Logger::guifunc);

	CFileDialog dialog(TRUE, ".ini", 0, OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR | OFN_NOREADONLYRETURN,
		"Ini files (*.ini)|*.ini|All files|*||", this);

	if (dialog.DoModal() == IDOK) {
		CString path = dialog.GetPathName();
		CWnd *visini = (CWnd *) GetDlgItem(IDC_VISINI);
		visini->SetWindowText(path.GetBuffer(0));
	}
}

void CDirDlg::OnAdd() 
{
	FunctionLogger flog("CDirDlg::OnAdd()", Logger::guifunc);

	// Thanks to Bulent Ozkir for this code which was at
	//	http://www.mindcracker.com/mindcracker/c_cafe/mfc/SHBrowseForFolder.asp

	LPMALLOC pMalloc;

	if (NOERROR == ::SHGetMalloc(&pMalloc) )
	{
		BROWSEINFO bi;
		
		char pszBuffer[MAX_PATH];
		LPITEMIDLIST pidl;
		bi.hwndOwner = GetSafeHwnd();
		bi.pidlRoot = NULL;
		bi.pszDisplayName = pszBuffer;
		bi.lpszTitle = _T("Select a directory");
		bi.ulFlags = BIF_RETURNFSANCESTORS | BIF_RETURNONLYFSDIRS;
		bi.lpfn = NULL;
		bi.lParam = 0;
		// This next call issues the dialog box.
		if ((pidl = ::SHBrowseForFolder(&bi)) != NULL) {
			if (::SHGetPathFromIDList(pidl, pszBuffer)) { 
				CListBox *dirlist = (CListBox *) GetDlgItem(IDC_DIRLIST);
				dirlist->AddString(pszBuffer);
			}
			// Free the PIDL allocated by SHBrowseForFolder.
			pMalloc->Free(pidl);
		}
		// Release the shell's allocator.
		pMalloc->Release();
	} 
	
}

void CDirDlg::OnFindreg() 
{
	FunctionLogger flog("CDirDlg::OnFindreg()", Logger::guifunc);

	LPMALLOC pMalloc;

	if (NOERROR == ::SHGetMalloc(&pMalloc) )
	{
		BROWSEINFO bi;
		
		char pszBuffer[MAX_PATH];
		LPITEMIDLIST pidl;
		bi.hwndOwner = GetSafeHwnd();
		bi.pidlRoot = NULL;
		bi.pszDisplayName = pszBuffer;
		bi.lpszTitle = _T("Select a directory");
		bi.ulFlags = BIF_RETURNFSANCESTORS | BIF_RETURNONLYFSDIRS;
		bi.lpfn = NULL;
		bi.lParam = 0;
		// This next call issues the dialog box.
		if ((pidl = ::SHBrowseForFolder(&bi)) != NULL) {
			if (::SHGetPathFromIDList(pidl, pszBuffer)) { 
				SetDlgItemText(IDC_REG, nicifyDirPath(pszBuffer).c_str());
			}
			// Free the PIDL allocated by SHBrowseForFolder.
			pMalloc->Free(pidl);
		}
		// Release the shell's allocator.
		pMalloc->Release();
	} 
}
