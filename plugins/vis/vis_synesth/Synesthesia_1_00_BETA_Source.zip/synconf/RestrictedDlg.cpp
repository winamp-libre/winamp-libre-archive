// RestrictedDlg.cpp : implementation file
//

#include "stdafx.h"
#include "synconfig.h"
#include "RestrictedDlg.h"
#include "Logger.h"
#include "MyString.h"
#include "MyVector.h"
#include "Settings.h"
#include "Utility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRestrictedDlg dialog


CRestrictedDlg::CRestrictedDlg(Settings& s, CWnd* pParent /*=NULL*/)
	: CDialog(CRestrictedDlg::IDD, pParent), m_settings(s)
{
	FunctionLogger flog("CRestrictedDlg::CRestrictedDlg(Settings&, CWnd*)", Logger::guifunc);

	//{{AFX_DATA_INIT(CRestrictedDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CRestrictedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRestrictedDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRestrictedDlg, CDialog)
	//{{AFX_MSG_MAP(CRestrictedDlg)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRestrictedDlg message handlers

void CRestrictedDlg::OnOK() 
{
	FunctionLogger flog("CRestrictedDlg::OnOK()", Logger::guifunc);

	// Copy the list box's contents into the settings
	CListBox *restrictlist = (CListBox *) GetDlgItem(IDC_RESTRICTLIST);

	int num = restrictlist->GetCount();
	vector<string> restrict(num);

	for (int i = 0; i < num; ++i) {
		int size = restrictlist->GetTextLen(i);
		char *buf = new char[size + 1];
		restrictlist->GetText(i, buf);
		restrict[i] = string(buf);
		delete[] buf;
	}

	m_settings.setRestricted(restrict);
	m_settings.updatePlugins();
	
	CDialog::OnOK();
}

void CRestrictedDlg::OnAdd() 
{
	FunctionLogger flog("CRestrictedDlg::OnAdd()", Logger::guifunc);

	CFileDialog dialog(TRUE, ".svp", 0, OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR,
		"Sonique Visualisation Plugins (*.svp)|*.svp|All files|*||", this);

	if (dialog.DoModal() == IDOK) {
		CString path = dialog.GetPathName();
		CListBox *rlist = (CListBox *) GetDlgItem(IDC_RESTRICTLIST);
		rlist->AddString(separate(path.GetBuffer(0)).second.c_str());
	}
}

void CRestrictedDlg::OnRemove() 
{
	FunctionLogger flog("CRestrictedDlg::OnRemove()", Logger::guifunc);

	CListBox *rlist = (CListBox *) GetDlgItem(IDC_RESTRICTLIST);
	rlist->DeleteString(rlist->GetCurSel());		
}

BOOL CRestrictedDlg::OnInitDialog() 
{
	FunctionLogger flog("CRestrictedDlg::OnInitDialog()", Logger::guifunc);

	CDialog::OnInitDialog();

	CListBox *rlist = (CListBox *) GetDlgItem(IDC_RESTRICTLIST);
	rlist->ResetContent();

	for (vector<string>::const_iterator i = m_settings.getRestricted().begin();
		i != m_settings.getRestricted().end();
		++i) 
		rlist->AddString(i->c_str());
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
