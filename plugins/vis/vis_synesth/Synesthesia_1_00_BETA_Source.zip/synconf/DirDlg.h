#if !defined(AFX_DIRCONFIG_H__71318F9E_46F1_42E3_823E_35AEF6DB48A2__INCLUDED_)
#define AFX_DIRCONFIG_H__71318F9E_46F1_42E3_823E_35AEF6DB48A2__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DirDlg.h : header file
//

#include "Resource.h"

class Settings;

/////////////////////////////////////////////////////////////////////////////
// dirconfig dialog

class CDirDlg : public CDialog
{
	Settings& m_settings;

	void refreshDirList();
	void refreshInstallDir();

// Construction
public:
	CDirDlg(Settings& settings, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDirDlg)
	enum { IDD = IDD_DIRDIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDirDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDirDlg)
	afx_msg void OnReset();
	afx_msg void OnRemove();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnFind();
	afx_msg void OnAdd();
	afx_msg void OnFindreg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIRCONFIG_H__71318F9E_46F1_42E3_823E_35AEF6DB48A2__INCLUDED_)
