#if !defined(AFX_RESTRICTED_H__111D1A55_262F_454B_B6EF_E3613EC26590__INCLUDED_)
#define AFX_RESTRICTED_H__111D1A55_262F_454B_B6EF_E3613EC26590__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// RestrictedDlg.h : header file
//

class Settings;

/////////////////////////////////////////////////////////////////////////////
// CRestricted dialog

class CRestrictedDlg : public CDialog
{
	Settings& m_settings;
	
// Construction
public:
	CRestrictedDlg(Settings& s, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRestrictedDlg)
	enum { IDD = IDD_RESTRICTED };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRestrictedDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRestrictedDlg)
	virtual void OnOK();
	afx_msg void OnAdd();
	afx_msg void OnRemove();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RESTRICTED_H__111D1A55_262F_454B_B6EF_E3613EC26590__INCLUDED_)
