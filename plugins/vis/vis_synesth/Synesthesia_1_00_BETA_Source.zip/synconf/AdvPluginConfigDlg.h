#if !defined(AFX_ADVPLUGINCONFIG_H__161BB442_4438_4B17_B1A4_7E6750E1A2F1__INCLUDED_)
#define AFX_ADVPLUGINCONFIG_H__161BB442_4438_4B17_B1A4_7E6750E1A2F1__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// AdvPluginConfigDlg.h : header file
//

#include "PluginIdent.h"

class Settings;


/////////////////////////////////////////////////////////////////////////////
// CAdvPluginConfigDlg dialog

class CAdvPluginConfigDlg : public CDialog
{
	Settings& m_settings;
	PluginIdent m_pi;

// Construction
public:
	CAdvPluginConfigDlg(Settings& s, PluginIdent pi, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAdvPluginConfigDlg)
	enum { IDD = IDD_ADVPLUGINCONFIG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAdvPluginConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAdvPluginConfigDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADVPLUGINCONFIG_H__161BB442_4438_4B17_B1A4_7E6750E1A2F1__INCLUDED_)
