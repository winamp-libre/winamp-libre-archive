// synconfig.h : main header file for the SYNCONFIG application
//

#if !defined(AFX_SYNCONFIG_H__66EA7260_9078_4D74_B9C8_0DE0EC18162E__INCLUDED_)
#define AFX_SYNCONFIG_H__66EA7260_9078_4D74_B9C8_0DE0EC18162E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

class Settings;

/////////////////////////////////////////////////////////////////////////////
// CSynConfigApp:
// See synconfig.cpp for the implementation of this class
//

class CSynConfigApp : public CWinApp
{
	Settings *m_settings;

public:
	CSynConfigApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSynConfigApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSynConfigApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYNCONFIG_H__66EA7260_9078_4D74_B9C8_0DE0EC18162E__INCLUDED_)
