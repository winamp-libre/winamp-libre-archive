#include "windows.h"
#include "MyString.h"
#include "Paths.h"


string getMainDir() {
	char buf[FILENAME_MAX];
	GetModuleFileName(GetModuleHandle(0), buf, FILENAME_MAX);
	string md(buf);
	return string(md, 0, md.rfind('\\') + 1);
}


string getIniFile() {
	return getWinampDir() + "Plugins\\synesth.ini";
}


string getOtherIniFile() {
	return getWinampDir() + "Plugins\\synesth_distr.ini";
}


string getWinampDir() {
	return getMainDir();
}
