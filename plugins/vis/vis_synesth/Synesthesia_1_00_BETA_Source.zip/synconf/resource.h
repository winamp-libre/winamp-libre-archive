//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by synconfig.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SYNCONFIG_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_DIRDIALOG                   129
#define IDD_PLUGINCONFIG                130
#define IDD_RESTRICTED                  131
#define IDD_ADVPLUGINCONFIG             132
#define IDC_DISPMODES                   1000
#define IDC_FULLSCREEN                  1001
#define IDC_PLUGINS                     1002
#define IDC_DIRS                        1006
#define IDC_DIRLIST                     1007
#define IDC_ADD                         1008
#define IDC_REMOVE                      1009
#define IDC_RESET                       1010
#define IDC_PREVIEWFRAME                1011
#define IDC_PREVIEW                     1012
#define IDC_PREVON                      1013
#define IDC_VISINI                      1014
#define IDC_FIND                        1015
#define IDC_EDIT                        1017
#define IDC_RESTRICTED                  1019
#define IDC_RESTRICTLIST                1020
#define IDC_RELEVANT                    1023
#define IDC_ADVANCED                    1027
#define IDC_APIVER                      1028
#define IDC_DATAREQ                     1029
#define IDC_REG                         1031
#define IDC_FINDREG                     1032
#define IDC_EFFECTS                     1033
#define IDC_BLUR                        1034
#define IDC_BLURLEVEL                   1036
#define IDC_MOTION                      1038
#define IDC_MOTIONLEVEL                 1039
#define IDC_README                      1040

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
