// AdvPluginConfigDlg.cpp : implementation file
//

#include "stdafx.h"
#include "synconfig.h"
#include "AdvPluginConfigDlg.h"
#include "DLL.h"
#include "Logger.h"
#include "MyString.h"
#include "SoniqueMisc.h"
#include "Utility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdvPluginConfigDlg dialog


CAdvPluginConfigDlg::CAdvPluginConfigDlg(Settings& s, PluginIdent pi, CWnd* pParent /*=NULL*/)
	: CDialog(CAdvPluginConfigDlg::IDD, pParent), m_settings(s), m_pi(pi)
{
	FunctionLogger flog("CAdvPluginConfigDlg::CAdvPluginConfigDlg(Settings&, PluginIdent, CWnd*)", Logger::guifunc);
	//{{AFX_DATA_INIT(CAdvPluginConfigDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAdvPluginConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdvPluginConfigDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdvPluginConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CAdvPluginConfigDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdvPluginConfig message handlers

BOOL CAdvPluginConfigDlg::OnInitDialog() 
{
	FunctionLogger flog("CAdvPluginConfigDlg::OnInitDialog()", Logger::guifunc);

	CDialog::OnInitDialog();

	// Get the plugin info
	DLL lib(m_pi.Filename);
	QueryModuleFunc qmf = (QueryModuleFunc) lib.getFunction("QueryModule");
	SoniquePluginInfo *info = qmf();

	// Display API version
	SetDlgItemText(IDC_APIVER, toStr((int) info->version).c_str());
	
	// Display requirements
	string req;
	if (info->requires & 1) req += "Waveform\n";
	if (info->requires & 2) req += "Spectrum";
	if (req == "") req = "None";
	SetDlgItemText(IDC_DATAREQ, req.c_str());
	
	// Display effects influence
	if (info->requires & 4) SetDlgItemText(IDC_EFFECTS, "Yes");
	else SetDlgItemText(IDC_EFFECTS, "No");

	// Set window title
	SetWindowText(("Advanced Plugin Config: " + m_pi.DisplayName).c_str());

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
