// CPluginConfigDlgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "synconfig.h"
#include "PluginConfigDlg.h"
#include "AdvPluginConfigDlg.h"
#include "DLL.h"
#include "Effects.h"
#include "IniFile.h"
#include "Logger.h"
#include "MyList.h"
#include "MyString.h"
#include "Paths.h"
#include "Settings.h"
#include "SoniqueMisc.h"
#include "Utility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPluginConfigDlgDlg dialog


void CPluginConfigDlg::addSection(const IniFile& ini, string section, string& info) {
	FunctionLogger("CPluginConfigDlg::addSection(const IniFile&, string, string&)", Logger::guifunc);

	// Get the section from the ini file
	list< pair<string, string> > keyvals = ini.getSection(section);

	// Add it to the edit box
	info += "[" + section + "]\r\n";

	for (list< pair<string, string> >::const_iterator kv = keyvals.begin();
		kv != keyvals.end();
		++kv)
		info += kv->first + " = " + kv->second + "\r\n";

	info += "\r\n";
}


void CPluginConfigDlg::resetData() {
	FunctionLogger flog("CPluginConfigDlg::resetData()", Logger::guifunc);

	CEdit *edit = (CEdit *) GetDlgItem(IDC_EDIT);

	// Get the section headers in the ini file
	IniFile ini(m_settings.getVisIni());
	list<string> headers = ini.getHeaders();

	// Check the relevant check box
	CButton *relevant = (CButton *) GetDlgItem(IDC_RELEVANT);

	if (relevant->GetCheck()) {
		// Try to load the plugin file
		FILE *fp = fopen(m_pi.Filename.c_str(), "rb");

		if (fp != 0) {
			// Get the size of the file
			int size;

			fseek(fp, 0, SEEK_END);
			size = ftell(fp);
			fseek(fp, 0, SEEK_SET);
			
			// Allocate memory for it
			char *data = new char[size];

			if (data != 0) {
				// Read the plugin in
				int c = getc(fp);
				int n = 0;
				for (c = getc(fp); c != EOF; c = getc(fp), ++n)
					data[n] = (char) c;
				fclose(fp);

				// Create a string to accumulate the information
				string info;

				// Go through every header
				for (list<string>::const_iterator i = headers.begin();
					i != headers.end();
					++i) {
					if (*i != "") {
						// Go through every position in the file
						bool nextheader = false;
						for (int j = 0; j < size - i->length() + 1 && !nextheader; ++j) {
							// Go through every character in the header
							for (int k = 0; k < i->length() && data[j + k] == (*i)[k]; ++k);

							// If it's a match, add this section to the edit box
							if (k == i->length()) {
								addSection(ini, *i, info);
								nextheader = true;
							}
						}
					}
				}

				// Set the contents of the edit control
				edit->SetWindowText(info.c_str());

			} else {
				m_edit = false;
				edit->SetWindowText("Could not allocate memory to load plugin");
				fclose(fp);
			}
		}
		else {
			// If the file can't be opened, print a message
			m_edit = false;
			edit->SetWindowText("Plugin file could not be opened");
		}
	}
	else {	// Show all headers
		string info;

		for (list<string>::const_iterator i = headers.begin();
			i != headers.end();
			++i)
			addSection(ini, *i, info);

		edit->SetWindowText(info.c_str());
	}
}


CPluginConfigDlg::CPluginConfigDlg(Settings& s, PluginIdent pi, CWnd* pParent /*=NULL*/)
	: CDialog(CPluginConfigDlg::IDD, pParent), m_settings(s), m_pi(pi)
{
	FunctionLogger flog("CPluginConfigDlg::CPluginConfigDlg(Settings&, PluginIdent, CWnd*)", Logger::guifunc);

	//{{AFX_DATA_INIT(CPluginConfigDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPluginConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPluginConfigDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPluginConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CPluginConfigDlg)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_BN_CLICKED(IDC_RELEVANT, OnRelevant)
	ON_BN_CLICKED(IDC_ADVANCED, OnAdvanced)
	ON_BN_CLICKED(IDC_BLUR, OnBlur)
	ON_BN_CLICKED(IDC_MOTION, OnMotion)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_README, OnReadme)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPluginConfigDlg message handlers

BOOL CPluginConfigDlg::OnInitDialog() 
{
	FunctionLogger flog("CPluginConfigDlg::OnInitDialog()", Logger::guifunc);

	CDialog::OnInitDialog();
	
	// Set the tick box
	CButton *relevant = (CButton *) GetDlgItem(IDC_RELEVANT);
	relevant->SetCheck(1);
	
	// Put the data into the edit box
	if (m_settings.getVisIni() != "") resetData();
	else {
		m_edit = false;
		CEdit *edit = (CEdit *) GetDlgItem(IDC_EDIT);
		edit->SetWindowText("No vis.ini is selected");
		edit->EnableWindow(FALSE);
	}

	// Give a name to the dialog
	SetWindowText(("Configure plugin: " + m_pi.DisplayName).c_str());

	// Set up the effects settings
	Effects& fx = m_settings.getEffectsForPlugin(m_pi);

	CButton *blur = (CButton *) GetDlgItem(IDC_BLUR);
	blur->SetCheck(fx.Blur || fx.Motion);

	CScrollBar *blurlevel = (CScrollBar *) GetDlgItem(IDC_BLURLEVEL);
	blurlevel->SetScrollRange(1, 30, TRUE);
	blurlevel->SetScrollPos(31 - fx.BlurLevel);

	CButton *motion = (CButton *) GetDlgItem(IDC_MOTION);
	motion->SetCheck(fx.Motion);

	CScrollBar *motionlevel = (CScrollBar *) GetDlgItem(IDC_MOTIONLEVEL);
	motionlevel->SetScrollRange(1, 20, TRUE);
	motionlevel->SetScrollPos(fx.MotionSpeed);

	// Get plugin info
	DLL lib(m_pi.Filename);
	QueryModuleFunc qmf = (QueryModuleFunc) lib.getFunction("QueryModule");
	SoniquePluginInfo *info = qmf();

	// If the plugin doesn't support effects, disable the settings
	if (!(info->requires & 4)) {
		motion->EnableWindow(FALSE);
		motionlevel->EnableWindow(FALSE);
		blur->EnableWindow(FALSE);
		blurlevel->EnableWindow(FALSE);

		CWnd *effects = (CWnd *) GetDlgItem(IDC_EFFECTS);
		effects->EnableWindow(FALSE);
	}

	// If there are no readme files, disable the readme button
	list<string> texts = listDir(separate(m_pi.Filename).first, "*.txt", true, true, false, false, false);

	if (texts.empty()) {
		CButton *readme = (CButton *) GetDlgItem(IDC_README);
		readme->EnableWindow(FALSE);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPluginConfigDlg::OnReset() 
{
	FunctionLogger flog("CPluginConfigDlg::OnReset()", Logger::guifunc);
	resetData();	
}

void CPluginConfigDlg::OnOK() 
{
	FunctionLogger flog("CPluginConfigDlg::OnOK()", Logger::guifunc);

	// Get the info out of the edit box
	CEdit *edit = (CEdit *) GetDlgItem(IDC_EDIT);
	int len = edit->GetWindowTextLength();
	char *buf = new char[len + 1];
	edit->GetWindowText(buf, len + 1);
	string info(buf);
	delete[] buf;

	if (m_edit) {
		// Separate the string into lines
		list<string> lines;
		string current;
		for (int i = 0; i < info.length(); ++i) {
			if (info[i] != '\n' && info[i] != '\r') current += info[i];
			if (info[i] == '\n') {
				lines.push_back(current);
				current = "";
			}
		}

		// Load the old vis ini
		IniFile visini(m_settings.getVisIni());

		// Add the lines
		string section;
		for (list<string>::const_iterator j = lines.begin();
			j != lines.end();
			++j) {
			// Get the line
			string line = *j;

			// If the line is a section header, change the section
			if (line[0] == '[' && line[line.length() - 1] == ']')
				section = string(line, 1, line.length() - 2);
			else {
				// Otherwise get the key and value and write them
				string::size_type pos = line.find('=');
				if (pos != string::npos) {
					string key(line, 0, pos - 1);
					string val(line, pos + 2, line.length() - pos - 2);
					visini.writeString(section, key, val);
				}
			}
		}

		// Save the ini file
		visini.save();
	}

	// Make blur and smoke changes
	Effects& fx = m_settings.getEffectsForPlugin(m_pi);

	CButton *blur = (CButton *) GetDlgItem(IDC_BLUR);
	CButton *motion = (CButton *) GetDlgItem(IDC_MOTION);
	fx.Blur = (blur->GetCheck() == 1);
	fx.Motion = (motion->GetCheck() == 1);

	CScrollBar *blurlevel = (CScrollBar *) GetDlgItem(IDC_BLURLEVEL);
	CScrollBar *motionspeed = (CScrollBar *) GetDlgItem(IDC_MOTIONLEVEL);
	fx.BlurLevel = 31 - blurlevel->GetScrollPos();
	fx.MotionSpeed = motionspeed->GetScrollPos();

	CDialog::OnOK();
}

void CPluginConfigDlg::OnRelevant() 
{
	FunctionLogger("CPluginConfigDlg::OnRelevant()", Logger::guifunc);
	
	// Put the data into the edit box
	if (m_settings.getVisIni() != "") resetData();
	else {
		m_edit = false;
		CEdit *edit = (CEdit *) GetDlgItem(IDC_EDIT);
		edit->SetWindowText("No vis.ini is selected");
		edit->EnableWindow(FALSE);
	}	
}

void CPluginConfigDlg::OnAdvanced() 
{
	FunctionLogger flog("CPluginConfigDlg::OnAdvanced()", Logger::guifunc);

	Settings s(m_settings);
	CAdvPluginConfigDlg dlg(s, m_pi);
	int response = dlg.DoModal();
	if (response == IDOK) m_settings = s;
}

void CPluginConfigDlg::OnBlur() 
{
	FunctionLogger flog("CPluginConfigDlg::OnBlur()", Logger::guifunc);

	CButton *blur = (CButton *) GetDlgItem(IDC_BLUR);

	// If deactivating, remove motion as well
	if (blur->GetCheck() == 0) {
		CButton *motion = (CButton *) GetDlgItem(IDC_MOTION);
		motion->SetCheck(0);
	}
}

void CPluginConfigDlg::OnMotion() 
{
	FunctionLogger flog("CPluginConfigDlg::OnMotion()", Logger::guifunc);

	CButton *motion = (CButton *) GetDlgItem(IDC_MOTION);

	// If activating, active the blur as well
	if (motion->GetCheck() == 1) {
		CButton *blur = (CButton *) GetDlgItem(IDC_BLUR);
		blur->SetCheck(1);
	}
}

void CPluginConfigDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	FunctionLogger flog("CPluginConfigDlg::OnHScroll(UINT, UINT, CScrollBar*)", Logger::guifunc);

	int curpos = pScrollBar->GetScrollPos();

    switch (nSBCode) { 
	case SB_LINELEFT: curpos--; break; 
    case SB_LINERIGHT: curpos++; break; 
    case SB_PAGELEFT: curpos -= 5; break; 
    case SB_PAGERIGHT: curpos += 5; break; 
    case SB_THUMBPOSITION:
    case SB_THUMBTRACK: 
        curpos = nPos;
		break;
    } 

	pScrollBar->SetScrollPos(curpos);
	
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CPluginConfigDlg::OnReadme() 
{
	FunctionLogger flog("CPluginConfigDlg::OnReadme()", Logger::guifunc);

	// Bring up notepad on every text file in the directory
	list<string> texts = listDir(separate(m_pi.Filename).first, "*.txt", true, true, false, false, true);

	for (list<string>::const_iterator i = texts.begin();
		i != texts.end();
		++i)
		WinExec(("notepad " + *i).c_str(), SW_SHOW);
}
