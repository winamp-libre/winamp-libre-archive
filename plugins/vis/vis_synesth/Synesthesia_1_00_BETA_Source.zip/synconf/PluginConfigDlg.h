#if !defined(AFX_PLUGINCONFIG_H__DCD1E11E_C917_44BC_B00E_2D80CF2DE1A9__INCLUDED_)
#define AFX_PLUGINCONFIG_H__DCD1E11E_C917_44BC_B00E_2D80CF2DE1A9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PluginConfigDlg.h : header file
//

#include "MyString.h"
#include "PluginIdent.h"

class IniFile;
class Settings;

/////////////////////////////////////////////////////////////////////////////
// CPluginConfig dialog

class CPluginConfigDlg : public CDialog
{
	Settings &m_settings;
	PluginIdent m_pi;
	bool m_edit;

	void addSection(const IniFile& ini, string section, string& info);
	void resetData();

// Construction
public:
	CPluginConfigDlg(Settings& s, PluginIdent pi, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPluginConfigDlg)
	enum { IDD = IDD_PLUGINCONFIG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPluginConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPluginConfigDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnReset();
	virtual void OnOK();
	afx_msg void OnRelevant();
	afx_msg void OnAdvanced();
	afx_msg void OnBlur();
	afx_msg void OnMotion();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnReadme();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLUGINCONFIG_H__DCD1E11E_C917_44BC_B00E_2D80CF2DE1A9__INCLUDED_)
