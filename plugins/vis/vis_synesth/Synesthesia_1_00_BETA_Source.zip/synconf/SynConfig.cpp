// synconfig.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"

#include "Logger.h"
#include "Paths.h"
#include "Settings.h"
#include "synconfig.h"
#include "synconfigDlg.h"
#include "Utility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSynConfigApp

BEGIN_MESSAGE_MAP(CSynConfigApp, CWinApp)
	//{{AFX_MSG_MAP(CSynConfigApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSynConfigApp construction

CSynConfigApp::CSynConfigApp()
{
	FunctionLogger flog("CSynConfigApp::CSynConfigApp()", Logger::guifunc);
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSynConfigApp object

CSynConfigApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CSynConfigApp initialization

BOOL CSynConfigApp::InitInstance()
{
	FunctionLogger flog("CSynConfigApp::InitInstance()", Logger::guifunc);
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	Enable3dControls();			// Call this when using MFC in a shared DLL

	// Load the Synesthesia settings
	m_settings = new Settings();

	// If no display modes are known, get them from DirectX
	if (m_settings->getDispModes().size() == 0)
		m_settings->updateDisplayModes();

	// If no directories are known, put in the default one
	if (m_settings->getDirectories().size() == 0)
		m_settings->resetDirectories();

	m_settings->updatePlugins();

	// Save the simple changes we've (possibly) made 
	m_settings->save();

	CSynConfigDlg dlg(*m_settings);
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK) m_settings->save();

	// Clean away the dynamically allocated settings object 
	delete m_settings;

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
