// synconfigDlg.cpp : implementation file
//

#include <cmath>
#include "afxctl.h"
#include "stdafx.h"

#include "ClickConsole.h"
#include "DirDlg.h"
#include "Logger.h"
#include "Paths.h"
#include "PluginConfigDlg.h"
#include "RestrictedDlg.h"
#include "Settings.h"
#include "SoniquePlugin.h"
#include "SynConfig.h"
#include "SynConfigDlg.h"
#include "Utility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	FunctionLogger flog("CAboutDlg::CAboutDlg()", Logger::guifunc);

	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSynConfigDlg dialog

CSynConfigDlg::CSynConfigDlg(Settings& settings, CWnd* pParent /*=NULL*/)
	: CDialog(CSynConfigDlg::IDD, pParent), m_settings(settings)
{
	FunctionLogger flog("CSynConfigDlg::CSynConfigDlg(Settings&, CWnd*)", Logger::guifunc);

	// Set up the vis data
	m_prevd.waveform[0] = new unsigned char[576];
	m_prevd.waveform[1] = new unsigned char[576];
	m_prevd.spectrum[0] = new unsigned char[576];
	m_prevd.spectrum[1] = new unsigned char[576];

	//{{AFX_DATA_INIT(CSynConfigDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}


CSynConfigDlg::~CSynConfigDlg() {
	FunctionLogger flog("CSynConfigDlg::~CSynConfigDlg()", Logger::guifunc);

	delete[] m_prevd.waveform[0];
	delete[] m_prevd.waveform[1];
	delete[] m_prevd.spectrum[0];
	delete[] m_prevd.spectrum[1];
}


void CSynConfigDlg::refreshPluginList() {
	FunctionLogger flog("CSynConfigDlg::refreshPluginList()", Logger::guifunc);
	
	CListBox *Plugins = (CListBox *) GetDlgItem(IDC_PLUGINS);

	// Clear the box
	Plugins->ResetContent();

	// Add plugins to the box
	for (vector<PluginIdent>::const_iterator it2 = m_settings.getPlugins().begin();
		it2 != m_settings.getPlugins().end();
		++it2)
		Plugins->AddString(it2->DisplayName.c_str());

	// If a plugin is selected, select it in the list box
	for (int i = 0; i < m_settings.getSelPlugins().size(); ++i) {
		int n = Plugins->FindString(0, m_settings.getSelPlugins()[i].DisplayName.c_str());
		Plugins->SetSel(n, TRUE);
		Plugins->SetTopIndex(n);	// would be better done outside the loop, but i'm lazy
	}
}


void CSynConfigDlg::startPreview() {
	FunctionLogger flog("CSynConfigDlg::startPreview()", Logger::guifunc);

	if (m_settings.getSelPlugins().size() != 0 && m_settings.getVisIni() != "") {
		// Get the plugin ident of the focussed plugin
		CListBox *pluglist = (CListBox *) GetDlgItem(IDC_PLUGINS);
		int n = pluglist->GetCaretIndex();
		int len = pluglist->GetTextLen(n);
		char *buf = new char[len + 1];
		pluglist->GetText(n, buf);
		const PluginIdent& pi = m_settings.getPIByDisplayName(buf);
		delete[] buf;

		// Store the current directory
		char buf2[FILENAME_MAX];
		GetCurrentDirectory(FILENAME_MAX, buf2);
		
		// Set the current directory to that of the plugin
		SetCurrentDirectory(separate(pi.Filename).first.c_str());

		// Load the plugin
		m_preplug = new SoniquePlugin(pi, m_settings.getVisIni(), m_precc, 
			m_settings.getEffectsForPlugin(pi));
		SetTimer(1, 40, 0);

		// Set current directory back
		SetCurrentDirectory(buf2);

		// Set the preview state
		m_prevstate = PrevOn;
	}

	if (m_settings.getSelPlugins().size() == 0) {
		CStatic *preview = (CStatic *) GetDlgItem(IDC_PREVIEW);
		preview->SetWindowText("No plugins are selected");
		m_prevstate = NoPlugin;
	}

	if (m_settings.getVisIni() == "") {
		CStatic *preview = (CStatic *) GetDlgItem(IDC_PREVIEW);
		preview->SetWindowText("No vis.ini is selected");
		m_prevstate = NoVisIni;
	}
}


void CSynConfigDlg::stopPreview() {
	FunctionLogger flog("CSynConfigDlg::stopPreview()", Logger::guifunc);

	if (m_prevstate == PrevOn) {
		KillTimer(1);
		delete m_preplug;
	}
	
	m_prevstate = PrevOff;
}


void CSynConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSynConfigDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSynConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CSynConfigDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_FULLSCREEN, OnFullscreen)
	ON_LBN_SELCHANGE(IDC_DISPMODES, OnSelchangeDispmodes)
	ON_LBN_SELCHANGE(IDC_PLUGINS, OnSelchangePlugins)
	ON_BN_CLICKED(IDC_DIRS, OnDirs)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_PREVON, OnPrevCheck)
	ON_LBN_DBLCLK(IDC_PLUGINS, OnDblclkPlugins)
	ON_BN_CLICKED(IDC_RESTRICTED, OnRestricted)
	ON_BN_CLICKED(IDC_PREVIEW, OnPreview)
	ON_BN_CLICKED(IDC_README, OnReadme)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSynConfigDlg message handlers

BOOL CSynConfigDlg::OnInitDialog()
{
	FunctionLogger flog("CSynConfigDlg::OnInitDialog()", Logger::guifunc);
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Add display modes to the list box
	CListBox *DispModes = (CListBox *) GetDlgItem(IDC_DISPMODES);

	for (vector<DisplayMode>::const_iterator it = m_settings.getDispModes().begin();
		it != m_settings.getDispModes().end();
		++it)
		if (it->BPP == 32) DispModes->AddString(it->describe(false).c_str());

	// Refresh plugins
	refreshPluginList();

	// If a display mode is selected, select it in the list box
	if (m_settings.isSelDispMode())
		DispModes->SelectString(-1, m_settings.getSelDispMode().describe(false).c_str());

	// Set the fullscreen check box
	CButton *Fullscreen = (CButton *) GetDlgItem(IDC_FULLSCREEN);
	Fullscreen->SetCheck(m_settings.isFullscreen());

	// Create the console and start the preview
	m_precc = new ClickConsole(::GetDlgItem(m_hWnd, IDC_PREVIEW));

	CButton *prevon = (CButton *) GetDlgItem(IDC_PREVON);
	if (m_settings.isPreviewOn()) {
		prevon->SetCheck(1);
		startPreview();
	}
	else {
		prevon->SetCheck(0);
		m_prevstate = PrevOff;
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CSynConfigDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	FunctionLogger flog("CSynConfigDlg::OnSysCommand(UINT, LPARAM)", Logger::guifunc);
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}


// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSynConfigDlg::OnPaint() 
{
	FunctionLogger flog("CSynConfigDlg::OnPaint()", Logger::guifunc);
	if (IsIconic()) {
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else {
		CDialog::OnPaint();
	}
}


// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSynConfigDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CSynConfigDlg::OnFullscreen() 
{
	FunctionLogger flog("CSynConfigDlg::OnFullscreen()", Logger::guifunc);
	CButton *Fullscreen = (CButton *) GetDlgItem(IDC_FULLSCREEN);
	
	if (Fullscreen->GetCheck() == 0) m_settings.setFullscreen(false);
	else m_settings.setFullscreen(true);
}


void CSynConfigDlg::OnSelchangeDispmodes() 
{
	FunctionLogger flog("CSynConfigDlg::OnSelchangeDispmodes()", Logger::guifunc);
	CListBox *DispModes = (CListBox *) GetDlgItem(IDC_DISPMODES);

	int selnum = DispModes->GetCurSel();

	if (selnum == LB_ERR) m_settings.deselDispMode();
	else {
		int size = DispModes->GetTextLen(selnum);
		char *buf = new char[size + 1];
		DispModes->GetText(selnum, buf);
		m_settings.setSelDispMode(DisplayMode(string(buf)));
		delete[] buf;
	}
}


void CSynConfigDlg::OnSelchangePlugins() 
{
	FunctionLogger flog("CSynConfigDlg::OnSelchangePlugins()", Logger::guifunc);

	if (m_settings.isPreviewOn()) stopPreview();

	CListBox *Plugins = (CListBox *) GetDlgItem(IDC_PLUGINS);

	m_settings.deselAllPlugins();

	int num = Plugins->GetSelCount();
	int *sel = new int[num];
	Plugins->GetSelItems(num, sel);

	for (int i = 0; i < num; ++i) {
		int size = Plugins->GetTextLen(sel[i]);
		char *buf = new char[size + 1];
		Plugins->GetText(sel[i], buf);
		m_settings.addSelPluginByDisplayName(buf);
		delete[] buf;
	}		

	delete[] sel;

	if (m_settings.isPreviewOn()) startPreview();
}


void CSynConfigDlg::OnDirs() 
{
	FunctionLogger flog("CSynConfigDlg::OnDirs()", Logger::guifunc);
	Settings s(m_settings);
	CDirDlg dlg(s);
	int response = dlg.DoModal();
	if (response == IDOK) {
		if (m_settings.isPreviewOn()) stopPreview();
		m_settings = s;
		m_settings.updatePlugins();
		refreshPluginList();
		if (m_settings.isPreviewOn()) startPreview();
	}
}


void CSynConfigDlg::OnTimer(UINT nIDEvent) 
{
	//FunctionLogger flog("CSynConfigDlg::OnTimer(UINT)", Logger::guifunc);

	// Create some random vis data
	for (int i = 0; i < 576; ++i) {
		m_prevd.waveform[0][i] = 50 * sin(i * (GetTickCount() % 1000) * 0.000005 + (rand() % 200) / 100);
		m_prevd.waveform[1][i] = m_prevd.waveform[0][i];
		m_prevd.spectrum[0][i] = (1000 - GetTickCount() % 1000) / (i + 1);
		m_prevd.spectrum[1][i] = m_prevd.spectrum[0][i];
	}

	// Get the plugin to render it
	m_preplug->render(m_prevd);

	// Update the window
	CWnd *preview = (CWnd *) GetDlgItem(IDC_PREVIEW);
	preview->UpdateWindow();

	CDialog::OnTimer(nIDEvent);
}


void CSynConfigDlg::OnPrevCheck() 
{
	FunctionLogger flog("CSynConfigDlg::OnPrevCheck()", Logger::guifunc);

	CButton *prev = (CButton *) GetDlgItem(IDC_PREVON);

	m_settings.setPreview(prev->GetCheck() == 1);

	if (m_settings.isPreviewOn()) startPreview();
	else {
		stopPreview();
		m_precc->clear();
		CWnd *preview = (CWnd *) GetDlgItem(IDC_PREVIEW);
		preview->UpdateWindow();
	}
}

void CSynConfigDlg::OnDblclkPlugins() 
{
	FunctionLogger flog("CSynConfigDlg::OnDblclkPlugins()", Logger::guifunc);

	if (m_settings.isPreviewOn()) stopPreview();

	Settings s(m_settings);

	// Get the plugin ident of the most focussed plugin
	CListBox *pluglist = (CListBox *) GetDlgItem(IDC_PLUGINS);
	int n = pluglist->GetCaretIndex();
	int len = pluglist->GetTextLen(n);
	char *buf = new char[len + 1];
	pluglist->GetText(n, buf);
	const PluginIdent& pi = m_settings.getPIByDisplayName(buf);
	delete[] buf;

	// Configure the plugin
	CPluginConfigDlg dlg(s, pi);
	int response = dlg.DoModal();
	if (response == IDOK) m_settings = s;

	if (m_settings.isPreviewOn()) startPreview();
}

void CSynConfigDlg::OnRestricted() 
{
	FunctionLogger flog("CSynConfigDlg::OnDblclkPlugins()", Logger::guifunc);

	Settings s(m_settings);
	CRestrictedDlg dlg(s);
	int response = dlg.DoModal();
	if (response == IDOK) {
		if (m_settings.isPreviewOn()) stopPreview();
		m_settings = s;
		refreshPluginList();
		if (m_settings.isPreviewOn()) startPreview();
	}
}


void CSynConfigDlg::OnPreview() 
{
	FunctionLogger flog("void CSynConfigDlg::OnPreview()", Logger::guifunc);
}

void CSynConfigDlg::OnReadme() 
{
	FunctionLogger flog("CSynConfigDlg::OnReadme()", Logger::guifunc);
	WinExec(("notepad " + getWinampDir() + "Plugins\\syn_readme.txt").c_str(), SW_SHOW);
}

void CSynConfigDlg::OnOK() 
{
	FunctionLogger flog("CSynConfigDlg::OnOK()", Logger::guifunc);
	stopPreview();
	delete m_precc;
	CDialog::OnOK();
}

void CSynConfigDlg::OnCancel() 
{
	FunctionLogger flog("CSynConfigDlg::OnCancel()", Logger::guifunc);
	stopPreview();	
	delete m_precc;
	CDialog::OnCancel();
}
