#include "afxwin.h"
#include <cctype>
#include "IniFile.h"
#include "Logger.h"
#include "MyString.h"


bool IniFile::getLine(FILE *fp, string &s) {
	FunctionLogger flog("IniFile::getLine(FILE, string)", Logger::utilfunc);
	s.erase();
	int c = getc(fp);
	while (c != EOF && c != '\n') {
		s += (char) c;
		c = getc(fp);
	}

	if (c == EOF) return false;
	else return true;      
}


string IniFile::clearWhiteSpace(const string &s) {
	FunctionLogger flog("IniFile::clearWhiteSpace(const string)", Logger::utilfunc);
	string::size_type i = 0;
	while (isspace(s[i])) ++i;
	return string(s, i, string::npos);
}


IniFile::IniFile(string filename, bool fresh)
: m_filename(filename) {
	FunctionLogger flog("IniFile::IniFile(string)", Logger::utilfunc);
	string line, section;
	FILE *file;

	if (fresh) DeleteFile(filename.c_str());

	file = fopen(filename.c_str(), "r");

	if (file != 0) {

		while (getLine(file, line)) {

			line = clearWhiteSpace(line);

			if (line.length() > 0) {

				if (line[0] == '[') {

					string::size_type end = line.find(']');
					if (end == string::npos) end = line.length();

					section.assign(line, 1, end - 1);

				}
				else {

					string::size_type pos = line.find('=') + 1;

					if (pos != string::npos) {
						string key(line, 0, pos - 1);
						string val(line, pos, string::npos);

						writeString(section, key, val);
					}

				}

			}

		}

		fclose(file);

	}
}


IniFile::data::iterator IniFile::find(string section, string key) {
	FunctionLogger flog("IniFile::find(string, string)", Logger::utilfunc);
	pair<string, string> p(section, key);

	for (data::iterator i = m_data.begin(); i != m_data.end(); ++i)
		if (i->first == p) return i;

	throw NotPresent(__FILE__, __LINE__, "Cannot find key " + key + " under section " + section + " in .ini file");

	return i;
}


IniFile::data::const_iterator IniFile::find(string section, string key) const {
	FunctionLogger flog("IniFile::find(string, string) const", Logger::utilfunc);
	pair<string, string> p(section, key);

	for (data::const_iterator i = m_data.begin(); i != m_data.end(); ++i)
		if (i->first == p) return i;

	throw NotPresent(__FILE__, __LINE__, "Cannot find key " + key + " under section " + section + " in .ini file");

	return i;
}


IniFile::data::iterator IniFile::findsect(string section) {
	FunctionLogger flog("IniFile::findsect(string)", Logger::utilfunc);
	for (data::iterator i = m_data.begin(); i != m_data.end(); ++i)
		if (i->first.first == section) return i;

	throw NotPresent(__FILE__, __LINE__, "Cannot find section " + section + " in .ini file");

	return i;
}


IniFile::data::const_iterator IniFile::findsect(string section) const {
	FunctionLogger flog("IniFile::findsect(string section) const", Logger::utilfunc);
	for (data::const_iterator i = m_data.begin(); i != m_data.end(); ++i)
		if (i->first.first == section) return i;

	throw NotPresent(__FILE__, __LINE__, "Cannot find section " + section + " in .ini file");

	return i;
}

	
bool IniFile::checkKey(string section, string key) const {
	FunctionLogger flog("IniFile::checkKey(string, string) const", Logger::utilfunc);
	try {
		find(section, key);
		return true;
	}
	catch (NotPresent) {
		return false;
	}
}


string IniFile::getString(string section, string key) const {
	FunctionLogger flog("IniFile::getString(section, key) const", Logger::utilfunc);
	return find(section, key)->second;
}


int IniFile::getInt(string section, string key) const {
	FunctionLogger flog("IniFile::getInt(string, string) const", Logger::utilfunc);
	return atoi(getString(section, key).c_str());
}


bool IniFile::getBool(string section, string key) const {
	FunctionLogger flog("IniFile::getBool(string, string) const", Logger::utilfunc);
	return getString(section, key) != "0";
}


void IniFile::writeString(string section, string key, string val) {
	FunctionLogger flog("IniFile::writeString(string, string, string)", Logger::utilfunc);
	try {
		find(section, key)->second = val;
	}
	catch (NotPresent) {
		pair< pair< string, string>, string > p(make_pair(section, key), val);
		try {
			data::iterator i = findsect(section);
			m_data.insert(i, p);
		}
		catch (NotPresent) {
			m_data.push_back(p);
		}
	}
}


void IniFile::writeInt(string section, string key, int val) {
	FunctionLogger flog("IniFile::writeInt(string, string, int)", Logger::utilfunc);
	char buf[20];
	sprintf(buf, "%d", val);
	writeString(section, key, string(buf));
}


void IniFile::writeBool(string section, string key, bool val) {
	FunctionLogger flog("IniFile::writeBool(string, string, bool)", Logger::utilfunc);
	if (val) writeString(section, key, "1");
	else writeString(section, key, "0");
}


void IniFile::save() const {
	FunctionLogger flog("IniFile::save() const", Logger::utilfunc);
	FILE *file = fopen(m_filename.c_str(), "w");
	string section;

	if (m_data.size() > 0) {

		section = m_data.begin()->first.first;
		fprintf(file, "[%s]\n", m_data.begin()->first.first.c_str());

	}

	for (data::const_iterator i = m_data.begin(); i != m_data.end(); ++i) {

		if (i->first.first != section) {
			fprintf(file, "\n[%s]\n", i->first.first.c_str());
			section = i->first.first;
		}

		fprintf(file, "%s=%s\n", i->first.second.c_str(), i->second.c_str());

	}

	fclose(file);
}
         

list<string> IniFile::getHeaders() const {
	FunctionLogger flog("list<string> IniFile::getHeaders() const", Logger::utilfunc);

	list<string> headers;

	for (data::const_iterator i = m_data.begin();
		i != m_data.end();
		++i) {
		string section = i->first.first;

		for (list<string>::const_iterator j = headers.begin();
			j != headers.end();
			++j)
			if (section == *j) break;

		if (j == headers.end()) headers.push_back(section);
	}

	return headers;
}


list< pair<string, string> > IniFile::getSection(string section) const {
	FunctionLogger flog("list< pair<string, string> > IniFile::getSection(string) const", Logger::utilfunc);

	list< pair<string, string> > keyvals;

	for (data::const_iterator i = m_data.begin();
		i != m_data.end();
		++i) {
		if (i->first.first == section) 
			keyvals.push_back(make_pair(i->first.second, i->second));
	}

	return keyvals;
}


void IniFile::clear() {
	FunctionLogger flog("void IniFile::clear()", Logger::utilfunc);

	m_data.clear();
}