#include "MyString.h"


const string::size_type string::npos = -1;


string &string::assign(const string &s, size_type start, size_type n)
{
	// this works even if self-assigned

	if (n == npos) n = strlen(s.m_data) - start;

	char *temp = new char[n + 1];

	memcpy(temp, &(s.m_data[start]), n);
	temp[n] = '\0';

	delete[] m_data;
	m_data = temp;

	return *this;
}


string::size_type string::find(char c) const
{
	int n;

	for (n = 0; m_data[n] != '\0' && m_data[n] != c; ++n);

	if (m_data[n] == c)
		return n;

	return npos;
}


string::size_type string::rfind(char c) const
{
	int n;

	for (n = length() - 1; n > 0 && m_data[n] != c; --n);

	if (m_data[n] == c)
		return n;

	return npos;
}



string &string::operator =(const string &s)
{
	if (&s != this) {

		delete[] m_data;
		m_data = new char[strlen(s.m_data) + 1];
		strcpy(m_data, s.m_data);

	}

	return *this;
}


string &string::operator +=(const string &s)
{
	char *temp = new char[strlen(m_data) + strlen(s.m_data) + 1];

	strcpy(temp, m_data);
	strcat(temp, s.m_data);

	delete[] m_data;
	m_data = temp;

	return *this;
}


string &string::operator +=(char c)
{
	int len = strlen(m_data);
	char *temp = new char[len + 2];

	strcpy(temp, m_data);
	temp[len] = c;
	temp[len + 1] = '\0';

	delete[] m_data;
	m_data = temp;

	return *this;
}


const string operator +(const string &l, const string &r)
{
	string t = l;
	return t += r;
}


bool operator ==(const string &l, const string &r)
{
	return strcmp(l.m_data, r.m_data) == 0;
}


std::ostream operator <<(std::ostream &o, const string &s)
{
	o << s.m_data;
	return o;
}


bool operator !=(const string &l, const string &r)
{
	return !(l == r);
}
