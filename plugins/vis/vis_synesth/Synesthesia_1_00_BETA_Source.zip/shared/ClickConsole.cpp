#include "ClickConsole.h"
#include "DisplayMode.h"
#include "Logger.h"
#include "MyList.h"
#include "SynException.h"
#include "Utility.h"


HWND ClickConsole::createWindow(HINSTANCE hinst, HWND parent, DisplayMode dm, bool fullscreen, ClickConsole *me)
{
	FunctionLogger flog("ClickConsole::createWindow(HINSTANCE, HWND, DisplayMode, bool, ClickConsole *)", Logger::utilfunc);

	RECT rect;
	int x, y;
	DWORD style;

	if (fullscreen) {

		// fullscreen output style
		style = WS_POPUP;

		// window position
		x = y = 0;

		// setup window rect to cover the entire screen
		rect.left = 0;
		rect.top = 0;
		rect.right = GetSystemMetrics(SM_CXSCREEN);
		rect.bottom = GetSystemMetrics(SM_CYSCREEN);

	}
	else {

		// windowed output style
		style = WS_OVERLAPPEDWINDOW;

		// setup window position
		x = y = CW_USEDEFAULT;

		// setup client area rect
		rect.left = 0;
		rect.top = 0;
		rect.right = dm.Width;
		rect.bottom = dm.Height;

		// adjust window rect for window style
		AdjustWindowRect(&rect, style, 0);

	}

    // setup window class
    WNDCLASS wc;
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hinst;
    wc.hIcon = NULL;
    wc.hCursor = LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW));
    wc.hbrBackground = NULL;
    wc.lpszMenuName = NULL;
    wc.lpszClassName = "SYNESTH_WINDOW";

    // register window class
    RegisterClass(&wc);

    // create window
    HWND hWnd = CreateWindow(	"SYNESTH_WINDOW",
								"Synesthesia",
								WS_OVERLAPPEDWINDOW,
								x, y, rect.right-rect.left, rect.bottom-rect.top,
								parent, 0, hinst, 0);
    
    // check window was created successfully
    if (!hWnd) throw SynException(__FILE__, __LINE__, "Could not create window");

	// set user data
	SetWindowLong(hWnd, GWL_USERDATA, (LONG) me);

    // show the window
    ShowWindow(hWnd, SW_SHOW);

    // return window
    return hWnd;
}


LRESULT CALLBACK ClickConsole::WindowProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	ClickConsole *me = (ClickConsole *) GetWindowLong(hwnd, GWL_USERDATA);
    
	// message handler
    switch (msg)
    { 
        case WM_KEYDOWN:
        {
			Log("WM_KEYDOWN message");
            // handle keypress
            if (wparam == VK_ESCAPE)
            {
				Log("VK_ESCAPE key pressed", Logger::utilfunc);
                // exit on escape key
				DestroyWindow(hwnd);
				me->m_open = false;
            }
        }
		return 0;

		case WM_LBUTTONDOWN:
		{
			Log("WM_LBUTTONDOWN message");

			int x = LOWORD(lparam);
			int y = HIWORD(lparam);

			RECT r;
			GetClientRect(hwnd, &r);

			me->m_clicks.push_back(Click((double) x / (r.right - r.left), 
				(double) y / (r.bottom - r.top)));
		}
		return 0;

        case WM_CLOSE:
        {
			Log("WM_CLOSE message");
			DestroyWindow(hwnd);
			me->m_open = false;
        }
        return 0;
    }

	// default window action
    return DefWindowProc(hwnd, msg, wparam, lparam);
}	


ClickConsole::ClickConsole(HINSTANCE hinst, HWND parent, DisplayMode dm, bool fullscreen) {
	FunctionLogger flog("ClickConsole::ClickConsole(HINSTANCE, DisplayMode, bool)", Logger::synfunc);

	Format format(32, 0xff0000, 0xff00, 0xff);

	if (!fullscreen) option("windowed output");
	option("disable key buffering");

	m_hwnd = createWindow(hinst, parent, dm, fullscreen, this);
	open(m_hwnd, dm.Width, dm.Height, format);
	m_ownwindow = true;
	m_open = true;
}


ClickConsole::ClickConsole(HWND hwnd) {
	FunctionLogger flog("ClickConsole::ClickConsole(HWND)", Logger::synfunc);

	Format format(32, 0xff0000, 0xff00, 0xff);
	open(hwnd, format);
	m_ownwindow = false;
	m_open = true;
}


ClickConsole::~ClickConsole() {
	FunctionLogger flog("ClickConsole::~ClickConsole()", Logger::synfunc);

	close();
	if (m_ownwindow) DestroyWindow(m_hwnd);
}


Click ClickConsole::readClick() {
	FunctionLogger flog("Click ClickConsole::readClick()", Logger::synfunc);

	list<Click>::iterator i = m_clicks.begin();
	Click c = *i;
	m_clicks.erase(i);
	return c;
}


void ClickConsole::setTitle(string title) {
	FunctionLogger flog("void ClickConsole::setTitle(string)", Logger::synfunc);
	SetWindowText(m_hwnd, title.c_str());
}
