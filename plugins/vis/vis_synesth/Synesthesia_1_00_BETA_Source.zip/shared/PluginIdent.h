#ifndef PLUGIN_IDENT_HEADER_INCLUDED
#define PLUGIN_IDENT_HEADER_INCLUDED


#include "MyString.h"


class PluginIdent {
public:
	string Filename, DisplayName;

	PluginIdent() { }
	PluginIdent(string fname, string dname) 
		: Filename(fname), DisplayName(dname) { }
};


#endif	// PLUGIN_IDENT_HEADER_INCLUDED