#include "Logger.h"
#include "RegistryKey.h"
#include "Utility.h"
#include "afxwin.h"


RegistryKey::RegistryKey(HKEY key, string subkey, bool writeable)
{
	FunctionLogger flog("RegistryKey::RegistryKey(HKEY, string)", Logger::utilfunc);
	// If the key is writeable, we're prepared to create a new one if it's not already
	//	present (with no value). If not writeable, we return an error.
	if (writeable) {
		if (RegOpenKeyEx(key, subkey.c_str(), 0, KEY_READ | KEY_WRITE, &m_hkey) != ERROR_SUCCESS) {
			DWORD dis;
			if (RegCreateKeyEx(key, subkey.c_str(), 0, "", REG_OPTION_NON_VOLATILE, KEY_READ | KEY_WRITE, 
				0, &m_hkey, &dis) != ERROR_SUCCESS)
				throw RegKeyOpenException(__FILE__, __LINE__, "Cannot open registry key " + subkey + " for writing:\n" + getWinAPIError());
		}
	}
	else {
		if (RegOpenKeyEx(key, subkey.c_str(), 0, KEY_READ, &m_hkey) != ERROR_SUCCESS) 
			throw RegKeyOpenException(__FILE__, __LINE__, "Cannot open registry key " + subkey);
	}
}


RegistryKey::~RegistryKey()
{
	FunctionLogger flog("RegistryKey::~RegistryKey", Logger::utilfunc);
	RegCloseKey(m_hkey);
}


string RegistryKey::getString(string valname)
{
	FunctionLogger flog("RegistryKey::getString(string)", Logger::utilfunc);
	// Get size of required buffer first, and check data type
	DWORD datatype, bufsize;

	if (RegQueryValueEx(m_hkey, valname.c_str(), 0, &datatype, 0, &bufsize) != ERROR_SUCCESS) 
		throw GetValException(__FILE__, __LINE__, "Cannot get value " + valname + " size from registry");

	if (datatype != REG_SZ) 
		throw GetValException(__FILE__, __LINE__, "Registry value " + valname + " is not of string type");

	// Allocate space and get the string
	char *buffer = new char[bufsize];

	if (RegQueryValueEx(m_hkey, valname.c_str(), 0, &datatype, (BYTE *) buffer, &bufsize) != ERROR_SUCCESS) 
		throw GetValException(__FILE__, __LINE__, "Cannot get value " + valname + " from registry");

	string s(buffer);
	delete[] buffer;

	return s;
}
   
   
void RegistryKey::setString(string valname, string value) {
	FunctionLogger flog("void RegistryKey::setString(string, string)", Logger::utilfunc);

	unsigned char *buf = new unsigned char[value.length() + 1];
	memcpy(buf, value.c_str(), value.length() + 1);

	RegSetValueEx(m_hkey, valname.c_str(), 0, REG_SZ, buf, value.length() + 1);

	delete[] buf;
}