#include "MyString.h"
#include "SynException.h"
#include "Utility.h"


string SynException::describe() const { 
	return m_desc; 
}


string SynException::getError() const { 
	return m_file + " [" + toStr(m_line) + "] - " + m_desc; 
}
