#ifndef SETTINGS_HEADER_INCLUDED
#define SETTINGS_HEADER_INCLUDED


#include "DisplayMode.h"
#include "Effects.h"
#include "MyVector.h"
#include "PluginIdent.h"
#include "SynException.h"


class IniFile;


class Settings {
	vector<DisplayMode> m_dispModes;
	vector<PluginIdent> m_plugins;
	vector<PluginIdent> m_selPlugins;
	vector<Effects> m_effects;
	vector<string> m_dirs;
	vector<string> m_restricted;
	string m_visini;
	bool m_fullscreen;
	int m_selDispMode;
	bool m_preview;

	void initDisplayModes(const IniFile& ini);
	void saveDisplayModes(IniFile& ini) const;
	void initPlugins(const IniFile& ini);
	void savePlugins(IniFile& ini) const;
	void initEffects(const IniFile& ini);
	void saveEffects(IniFile& ini) const;
	void initDirectories(const IniFile& ini);
	void saveDirectories(IniFile& ini) const;
	void initSelections(const IniFile& ini);
	void saveSelections(IniFile& ini) const;
	void initRestricted(const IniFile& ini);
	void saveRestricted(IniFile& ini) const;

	void sortDispModes();
	bool leqDM(const DisplayMode& lhs, const DisplayMode& rhs) const;
	bool geqDM(const DisplayMode& lhs, const DisplayMode& rhs) const;

public:

	MAKE_EXCEPTION(DispModeNotSel, SynException, "No display mode is selected");
	MAKE_EXCEPTION(PluginNotSel, SynException, "No plugin is selected");

	Settings();
	~Settings();
	void save() const;

	const vector<PluginIdent>& getPlugins() const { return m_plugins; }
	const vector<PluginIdent>& getSelPlugins() const { return m_selPlugins; }
	void addSelPluginByDisplayName(string fn);
	const PluginIdent& getPIByDisplayName(string dn) const;
	void deselAllPlugins() { m_selPlugins.clear(); }
	const PluginIdent& selNextPlugin(int which);
	const PluginIdent& selPrevPlugin(int which);

	const vector<DisplayMode>& getDispModes() const { return m_dispModes; }
	bool isSelDispMode() const { return m_selDispMode != -1; }
	const DisplayMode& getSelDispMode() const { return m_dispModes[m_selDispMode]; }
	void setSelDispMode(DisplayMode dm);
	void deselDispMode() { m_selDispMode = -1; }

	bool isFullscreen() const { return m_fullscreen; }
	void setFullscreen(bool fs) { m_fullscreen = fs; }

	bool isPreviewOn() const { return m_preview; }
	void setPreview(bool on) { m_preview = on; }

	const vector<string>& getDirectories() const { return m_dirs; }
	void setDirectories(const vector<string>& dirs) { m_dirs = dirs; }

	string getVisIni() const { return m_visini; }
	void setVisIni(string vi) { m_visini = vi; }

	const vector<string>& getRestricted() const { return m_restricted; }
	void setRestricted(const vector<string>& res) { m_restricted = res; }

	Effects& getEffectsForPlugin(const PluginIdent& p);

	void updatePlugins();
	void resetDirectories();
	void updateDisplayModes();

	void reinitialise();
};


#endif	// SETTINGS_HEADER_INCLUDED