#ifndef UTILITY_HEADER_INCLUDED
#define UTILITY_HEADER_INCLUDED


#include "MyList.h"
#include "MyPair.h"
#include "MyString.h"


list<string> listDir(string path, string pattern = "*",
	bool longname = true, bool files = true, bool dirs = false,
	bool recurse = false, bool fullpath = false);
   
pair<string, string> separate(string filepath);

bool exists(string filepath, bool dir = false); 

string toStr(int n);
string toStr(bool b);

string nicifyDirPath(string path);

string stripWhiteSpace(string s);

string getWinAPIError();

double random(double min, double max);

void blurMMX(unsigned int *surface, int width, int heigth, 
			 int pitch, int blurlevel, int skip, int startat);

#endif	// UTILITY_HEADER_INCLUDED





