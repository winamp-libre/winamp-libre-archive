#ifndef EFFECTS_HEADER_INCLUDED
#define EFFECTS_HEADER_INCLUDED


class Effects {
public:
	bool isOn() const { return Blur || Motion; }
	bool Blur, Motion;
	int BlurLevel, MotionSpeed;
};


#endif	// EFFECTS_HEADER_INCLUDED