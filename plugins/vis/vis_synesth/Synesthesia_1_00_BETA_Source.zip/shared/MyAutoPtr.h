#ifndef AUTOPTR_HEADER_INCLUDED
#define AUTOPTR_HEADER_INCLUDED


template <class T> class auto_ptr {

	// Implementation

	T *m_pointer;

	//template<class U> friend class auto_ptr<U>;

public:

	// Constructors etc.

	explicit auto_ptr(T *p = 0) : m_pointer(p) { }
	template <class U> auto_ptr(auto_ptr<U> &rhs) : m_pointer(rhs.release()) { }
	~auto_ptr() { delete m_pointer; }

	template <class U> auto_ptr<T> &operator =(auto_ptr<U> &rhs) 
	{
		if (this != &rhs) reset(rhs.release());
		return *this;
	}

	// Interface functions

	T &operator *() const { return *m_pointer; }
	T *operator ->() const { return m_pointer; }

	T *get() const { return m_pointer; }

	T *release()
	{
		T *old = m_pointer;
		m_pointer = 0;
		return old;
	}

	void reset(T *p = 0)
	{
		if (m_pointer != p) {
			delete m_pointer;
			m_pointer = p;
		}
	}

};


#endif	// AUTOPTR_HEADER_INCLUDED