#ifndef DISPLAYMODE_HEADER_INCLUDED
#define DISPLAYMODE_HEADER_INCLUDED


#include "MyString.h"
#include "MyVector.h"


class DisplayMode {
public:
	int Width, Height, BPP;

	DisplayMode() { }
	explicit DisplayMode(string s);

	string describe(bool withbpp = true) const;

	bool operator ==(const DisplayMode &rhs) const;
	bool operator <(const DisplayMode &rhs) const;

	static vector<DisplayMode> listDisplayModes();
};
  
   
#endif	// DISPLAYMODE_HEADER_INCLUDED