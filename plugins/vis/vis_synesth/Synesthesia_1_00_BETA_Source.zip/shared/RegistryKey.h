#ifndef REGISTRYKEY_HEADER_INCLUDED
#define REGISTRYKEY_HEADER_INCLUDED


#include "SynException.h"
#include "afxwin.h"


class RegistryKey {
	HKEY m_hkey;

	RegistryKey();

public:

	MAKE_EXCEPTION(RegKeyOpenException, SynException, "Registry key could not be opened");
	MAKE_EXCEPTION(GetValException, SynException, "Registry value could not be retrieved");

	explicit RegistryKey(HKEY key, string subkey, bool writeable = false);
	~RegistryKey();

	string getString(string valname);
	void setString(string valname, string value);
};


#endif	// REGISTRYKEY_HEADER_INCLUDED