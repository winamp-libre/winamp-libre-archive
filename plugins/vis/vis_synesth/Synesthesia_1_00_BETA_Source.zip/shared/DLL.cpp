#include "DLL.h"
#include "Logger.h"
#include "MyString.h"
#include "afxwin.h"


void DLL::loadDLL()
{
	FunctionLogger flog("void DLL::loadDLL()", Logger::utilfunc);

	m_hlib = LoadLibrary(m_filename.c_str());

	if (m_hlib == 0) 
		throw DLLLoadException(__FILE__, __LINE__, "Could not load DLL " + m_filename);
}


DLL::DLL(string filename)
{
	FunctionLogger flog("DLL::DLL((string) " + filename + ")", Logger::utilfunc);
	m_filename = filename;
	loadDLL();
}


DLL::DLL(const DLL &dll)
{
	FunctionLogger flog("DLL::DLL(const DLL &)", Logger::utilfunc);
	m_filename = dll.m_filename;
	loadDLL();
}


DLL::~DLL()
{
	FunctionLogger flog("DLL::~DLL()", Logger::utilfunc);
	FreeLibrary(m_hlib);
}


DLL &DLL::operator =(const DLL &dll)
{
	FunctionLogger flog("DLL &DLL::operator =(const DLL &)", Logger::utilfunc);

	if (&dll != this) {

		FreeLibrary(m_hlib);
		m_filename = dll.m_filename;
		loadDLL();

	}

	return *this;
}


void *DLL::getFunction(string funcname)
{
	FunctionLogger flog("void *DLL::getFunction(string)", Logger::utilfunc);
	return GetProcAddress(m_hlib, funcname.c_str());
}


