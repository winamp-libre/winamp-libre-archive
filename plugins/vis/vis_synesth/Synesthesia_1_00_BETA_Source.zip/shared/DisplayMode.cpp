#include "afxwin.h"
#include "ddraw.h"
#include "DisplayMode.h"
#include "Logger.h"
#include "MyString.h"


namespace { 

	HRESULT CALLBACK enumDisplayModesCallback(LPDDSURFACEDESC pddsd, LPVOID pcon)
	{
		FunctionLogger flog("enumDisplayModesCallback(LPDDSURFACEDESC, LPVOID)", Logger::utilfunc);
		DisplayMode dm;

		dm.Width = pddsd->dwWidth;
		dm.Height = pddsd->dwHeight;
		dm.BPP = pddsd->ddpfPixelFormat.dwRGBBitCount;

		((vector<DisplayMode> *) pcon)->push_back(dm);

		return DDENUMRET_OK;
	}

}
   

string DisplayMode::describe(bool withbpp) const
{
	FunctionLogger flog("DisplayMode::describe() const", Logger::utilfunc);
	char buf[30];
	if (withbpp) sprintf(buf, "%d * %d, %d bit", Width, Height, BPP);
	else sprintf(buf, "%d * %d", Width, Height);
	return string(buf);
}


DisplayMode::DisplayMode(string s)
{
	FunctionLogger flog("DisplayMode::DisplayMode(string)", Logger::utilfunc);
	const char *buf = s.c_str();
	char store[10];
	int c;

	while (!isdigit(*buf)) buf++;
	for (c = 0; isdigit(*buf); ++buf, ++c) store[c] = *buf;
	store[c] = '\0';
	Width = atoi(store);
  
	while (!isdigit(*buf)) buf++;
	for (c = 0; isdigit(*buf); ++buf, ++c) store[c] = *buf;
	store[c] = '\0';
	Height = atoi(store);

	while (!isdigit(*buf)) buf++;
	for (c = 0; isdigit(*buf); ++buf, ++c) store[c] = *buf;
	store[c] = '\0';
	BPP = atoi(store);
}


bool DisplayMode::operator ==(const DisplayMode &rhs) const {
	FunctionLogger flog("DisplayMode::operator ==(const DisplayMode &rhs) const", Logger::utilfunc);

	return (Width == rhs.Width) && (Height == rhs.Height) && (BPP == rhs.BPP);
}


bool DisplayMode::operator <(const DisplayMode &rhs) const {
	FunctionLogger flog("bool operator <(const DisplayMode &rhs) const", Logger::utilfunc);

	return (Width < rhs.Width) || ((Width == rhs.Width) && (Height < rhs.Height));
}
     
      
vector<DisplayMode> DisplayMode::listDisplayModes()
{
	FunctionLogger flog("DisplayMode::listDisplayModes()", Logger::utilfunc);
	vector<DisplayMode> result;

	LPDIRECTDRAW pddraw;

	DirectDrawCreate(0, &pddraw, 0);
	pddraw->EnumDisplayModes(0, 0, &result, enumDisplayModesCallback);
	pddraw->Release();

	return result;
}


