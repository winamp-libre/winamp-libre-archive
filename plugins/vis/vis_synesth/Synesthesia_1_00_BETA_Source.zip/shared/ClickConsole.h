#ifndef CLICKCONSOLE_HEADER_INCLUDED
#define CLICKCONSOLE_HEADER_INCLUDED

#include "afxwin.h"
#include "DisplayMode.h"
#include "MyList.h"
#include "ptc.h"


class Click {
public:
	double x, y;

	Click(double xx, double yy) : x(xx), y(yy) { }
};


class ClickConsole : public Console {
	HWND createWindow(HINSTANCE InstanceHandle, HWND parent, DisplayMode dm, bool fullscreen, ClickConsole *ud);
	static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);

	list<Click> m_clicks;
	bool m_ownwindow;
	HWND m_hwnd;
	bool m_open;

public:
	ClickConsole(HINSTANCE hinst, HWND parent, DisplayMode dm, bool fullscreen);
	ClickConsole(HWND hwnd);
	~ClickConsole();
	virtual bool click() const { return !m_clicks.empty(); }
	virtual Click readClick();
	void setTitle(string title);
	bool isClosed() const { return !m_open; }
};


#endif	// CLICKCONSOLE_HEADER_INCLUDED