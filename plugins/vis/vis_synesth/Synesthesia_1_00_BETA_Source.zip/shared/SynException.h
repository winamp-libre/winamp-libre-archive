#ifndef SYNEXCEPTION_HEADER_INCLUDED
#define SYNEXCEPTION_HEADER_INCLUDED


#include "MyString.h"


#define MAKE_EXCEPTION(NAME, DERIVE, MSG)	class NAME : public DERIVE {						\
											public:												\
											NAME(string file, int line, string desc = (MSG))	\
											: DERIVE(file, line, desc) { }						\
											}


class SynException {

	string m_desc, m_file;
	int m_line;

public:

	SynException(string file, int line, string desc) 
	: m_desc(desc), m_file(file), m_line(line) { }
	virtual ~SynException() { }

	virtual string describe() const;
	virtual string getError() const;

};


#endif	// SYNEXCEPTION_HEADER_INCLUDED