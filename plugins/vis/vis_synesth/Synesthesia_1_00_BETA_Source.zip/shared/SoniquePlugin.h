#ifndef SONIQUEPLUGIN_HEADER_INCLUDED
#define SONIQUEPLUGIN_HEADER_INCLUDED


#include "DLL.h"
#include "Effects.h"
#include "MyString.h"
#include "PluginIdent.h"
#include "ptc.h"
#include "VisData.h"

class ClickConsole;
class QueryInterface;
class SoniquePluginInfo;


class SoniquePlugin {
	SoniquePluginInfo *m_info;
	DLL m_lib;
	QueryInterface *m_qi;
	ClickConsole *m_console;
	Surface m_surface;
	string m_visini;
	int m_width, m_height;
	Effects m_fx;
	int m_posx, m_posy;
	double m_vposx, m_vposy;
	double m_velx, m_vely;
	double m_destvelx, m_destvely;

	static int motionSize(int width, bool motion);
	void doMotion();

public:
	SoniquePlugin(PluginIdent p, string visini, ClickConsole *cc, Effects fx);
	~SoniquePlugin();

	bool render(const VisData& vd);
	void switchConsole(ClickConsole *newcc);
};


#endif	// SONIQUEPLUGIN_HEADER_INCLUDED