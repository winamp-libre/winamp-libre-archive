#ifndef SONIQUEMISC_HEADER_INCLUDED
#define SONIQUEMISC_HEADER_INCLUDED


#include "afxwin.h"


#pragma pack (push, 8)


class QueryInterface {
public:
	virtual bool queryInt(char *expr, int *value);
	virtual char *queryString(char *expr);
	virtual void freeString(char *s);
};


class SoniquePluginInfo {
public:

	class SoniqueVisData {
	public:
		unsigned long time;
		unsigned char waveform[2][512];
		unsigned char spectrum[2][256];
	};      

	unsigned long version;
	char *internalname;
	long requires;
	void (*initialise)();
	BOOL (*render)(unsigned long *surface, int width, int height, int pitch, SoniqueVisData *visdata);
	BOOL (*saveSettings)(const char *filename);
	BOOL (*loadSettings)(const char *filename);
	BOOL (*deInit)();
	BOOL (*clicked)(int x, int y, int buttons);
	BOOL (*receiveQueryInterface)(QueryInterface *qi);
};      


#pragma pack (pop, 8)


typedef SoniquePluginInfo *(WINAPI *QueryModuleFunc)();


#endif	// SONIQUEMISC_HEADER_INCLUDED