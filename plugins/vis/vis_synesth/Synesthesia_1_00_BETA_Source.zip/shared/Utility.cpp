#include "afxwin.h"
#include <cstdio>
#include <cstdlib>
#include <memory>
#include "Logger.h"
#include "MyList.h"
#include "MyString.h"
#include "Utility.h"


list<string> listDir(string path, string pattern, bool longname, bool files, bool dirs, bool recurse, bool fullpath)
{
	FunctionLogger flog("listDir(string, string, bool, bool, bool, bool, bool)", Logger::utilfunc);
	WIN32_FIND_DATA wfd;
	HANDLE h;
	list<string> result;

	// Do any necessary conversions to path

	int len = path.length();

	for (int i = 0; i < len; ++i)
		if (path[i] == '/')
	path[i] = '\\';

	if (path[len - 1] != '\\')
		path += '\\';

	// Build a search string

	string search = path;
	search += pattern;

	// Check that the search begins correctly

	if ((h = FindFirstFile(search.c_str(), &wfd)) != INVALID_HANDLE_VALUE) {

		// Now begin the search in earnest

		do {

			// Only write it out if it's the sort of thing we're looking for

			if (*(wfd.cFileName) != '.') {
				if (((wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && dirs) ||
					(!(wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && files)) {
					string fname;
					if (fullpath) fname += path;
					if (longname) fname += wfd.cFileName;
					else fname += wfd.cAlternateFileName;
					result.push_back(fname);
				}
			}

		} while (FindNextFile(h, &wfd));

		FindClose(h);

	}

	// If the search is meant to be recurse, we now need a list of directories
	// into which we look for further files/directories.

	if (recurse) {

		list<string> dirlist = listDir(path, "*", longname, false, true, false, false);

		for (list<string>::iterator vsi = dirlist.begin(); vsi != dirlist.end() ; ++vsi) {
			list<string> filelist = listDir(path + *vsi, pattern, longname, files, dirs, true, fullpath);
			result.splice(result.end(), filelist);
		}

	}

	// Return the list

	return result;
}


pair<string, string> separate(string filepath)
{
	FunctionLogger flog("separate(string)", Logger::utilfunc);
	string::size_type p = filepath.rfind('\\') + 1;

	string path(filepath, 0, p);
	string file(filepath, p, string::npos);

	return make_pair(path, file);
}


bool exists(string filepath, bool dir)
{
	FunctionLogger flog("exists(string, bool)", Logger::utilfunc);
	WIN32_FIND_DATA wfd;
	HANDLE h;

	if ((h = FindFirstFile(filepath.c_str(), &wfd)) == INVALID_HANDLE_VALUE)
		return false;

	FindClose(h);

	if ((wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && !dir) 
		return false;

	return true;
}   


string toStr(int n)
{
	FunctionLogger flog("toStr(int)", Logger::utilfunc);
	char buf[20];
	sprintf(buf, "%d", n);
	return string(buf);
}


string toStr(bool b) {
	FunctionLogger flog("toStr(bool)", Logger::utilfunc);
	if (b) return "true";
	else return "false";
}


string nicifyDirPath(string path) {
	FunctionLogger flog("nicifyDirPath(string)", Logger::utilfunc);
	if (path[path.length() - 1] != '\\') path += '\\';
	return path;
}


string stripWhiteSpace(string s) {
	FunctionLogger flog("stripWhiteSpace(string)", Logger::utilfunc);
	for (int start = 0; start < s.length() && isspace(s[start]); ++start);
	for (int end = s.length() - 1; end >= 0 && isspace(s[end]); ++end);
	return string(s, start, end - start + 1);
}


string getWinAPIError() {
	PVOID *buf = 0;
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, GetLastError(), 0, (char *) buf, 0, 0);
	string result((const char *) *buf);
	LocalFree(*buf);
	return result;
}


double random(double min, double max) {
	return (((double) rand() / RAND_MAX) * (max - min)) + min;
}


void blurMMX(unsigned int *surface, int width, int height, int pitch, int blurlevel, int skip, int startat) {
	width -= (width % 8);	// move back to nearest qword boundary

	int moveon = skip * pitch - width * 4;		// note only for 32 bit surfaces
	blurlevel *= skip;
	unsigned int blurmask = (blurlevel & 0xff) << 16
							| (blurlevel & 0xff) << 8
							| (blurlevel & 0xff);
	surface += (pitch / 4) * startat;

	__asm {
		pxor mm1, mm1
		movd mm0, blurmask	// put subtraction mask into mm0
		psllq mm0, 32
		movd mm1, blurmask
		por mm0, mm1
		mov eax, surface	// put pixel pointer into eax
		mov ebx, height		// put y counter into ebx
		
		LineLoop:
		mov ecx, width		// put x counter into ecx

		PixelLoop:
		movq mm1, [eax]		// perform 8-byte subtraction
		psubusb mm1, mm0
		movq [eax], mm1
		sub ecx, 2			// decrement x counter
		add eax, 8			// move pixel pointer on
		cmp ecx, 0			// loop if more pixels in line
		jnz PixelLoop

		add eax, moveon		// move to next line
		sub ebx, skip
		cmp ebx, 0
		jnz LineLoop

		emms				// go back to floating point mode
		finit
	}
}
