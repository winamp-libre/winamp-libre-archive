#ifndef PAIR_HEADER_INCLUDED
#define PAIR_HEADER_INCLUDED


template <class A, class B> class pair {
public:
	A first;
	B second;

	pair(A a, B b) : first(a), second(b) { }
};


template <class A, class B> pair<A, B> make_pair(const A &a, const B &b)
{
	return pair<A, B>(a, b);
}


template <class A, class B> bool operator ==(const pair<A, B> &l, const pair<A, B> &r)
{
	return (l.first == r.first) && (l.second == r.second);
}


#endif	// PAIR_HEADER_INCLUDED