#include "afxwin.h"
#include "Logger.h"
#include "SoniqueMisc.h"


bool QueryInterface::queryInt(char *expr, int *value)
{
	FunctionLogger flog("bool QueryInterface::queryInt(char *, int *)", Logger::synfunc);

	HWND hwndwinamp = FindWindow("Winamp v1.x", 0);

	if (strcmp(expr, "currentsonglength") == 0) {
		*value = SendMessage(hwndwinamp, WM_USER, 1, 105);
		return true;
	}

	if (strcmp(expr, "currentsongposition") == 0) {
		*value = SendMessage(hwndwinamp, WM_USER, 0, 105) / 1000;
		return true;
	}

	return false;
}


char *QueryInterface::queryString(char *expr)
{
	FunctionLogger("char *QueryInterface::queryString(char *)", Logger::synfunc);

	HWND hwndwinamp = FindWindow("Winamp v1.x", 0);

	if (strcmp(expr, "currentskinname") == 0) {
		char *b = new char[9];
		strcpy(b, "Original");
		return b;
	}

	if (strcmp(expr, "currentsongfilename") == 0) {
		char *b = new char[FILENAME_MAX];
		strcpy(b, (char *) SendMessage(hwndwinamp, WM_USER, SendMessage(hwndwinamp, WM_USER, 0, 125), 211));
		return b;
	}

	if (strcmp(expr, "currentsongtitle") == 0 || strcmp(expr, "currengsongdisplaystring") == 0) {
		char *b = new char[200];
		strcpy(b, (char *) SendMessage(hwndwinamp, WM_USER, SendMessage(hwndwinamp, WM_USER, 0, 125), 212));
		return b;
	}

	return false;
}      
      
      
void QueryInterface::freeString(char *s)
{
	FunctionLogger flog("void QueryInterface::freeString(char *)", Logger::synfunc);
	delete[] s;
}
