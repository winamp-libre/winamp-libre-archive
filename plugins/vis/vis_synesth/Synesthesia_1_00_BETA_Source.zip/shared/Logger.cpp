//#include "afxwin.h"
#include "windows.h"
#include <crtdbg.h>
#include <cstdio>
#include <ctime>
#include "Logger.h"
#include "MyString.h"
#include "Paths.h"
#include "SynException.h"


Logger Log(getMainDir() + "synesth.log", "Opening Synesthesia log", "Closing Synesthesia log");


string Logger::getTime(time_t t) const {
	char buf[100];

	strncpy(buf, asctime(localtime(&t)), 99);
	buf[99] = '\0';

	for (int i = strlen(buf); i >= 0; --i) {
		if (buf[i] == '\n') {
			buf[i] = '\0';
			break;
		}
	}

	return buf;
}


string Logger::makeIndent(int i) const {
	string result = "";
	while (i--) result += "   ";
	return result;
}


void Logger::writeString(string msg) {
	FILE *fp = fopen(m_logfile.c_str(), "a");
	if (!m_opened) {
		fprintf(fp, "%s : %s\n", getTime(time(0)).c_str(),
			m_openmsg);
		m_opened = true;
	}
	fprintf(fp, "%s", msg.c_str());
	fclose(fp);
}


void Logger::writePendingNL() {
	if (m_nlpending) {
		writeString("\n");
		m_nlpending = false;
	}
}


Logger::Logger(string logfile, string openmsg, string closemsg)
: m_logfile(logfile), m_openmsg(openmsg), m_closemsg(closemsg), m_opened(false), 
	m_opentime(time(0)), m_indent(0) {
	m_msgmask = (MsgType) (~utilfunc);
	remove(m_logfile.c_str());
}


Logger::~Logger() {
	if (m_opened) {
		FILE *fp = fopen(m_logfile.c_str(), "a");
		fprintf(fp, "%s : %s\n", getTime(time(0)).c_str(), m_closemsg.c_str());
		fclose(fp);
	}
}


void Logger::operator ()(string msg, MsgType msgt) {
	if (m_msgmask & msgt) {
		writePendingNL();
		writeString(getTime(time(0)) + " : " + makeIndent(m_indent) + msg + "\n");
	}
}


void Logger::operator ()(SynException ex, MsgType msgt) {
	operator ()(ex.describe(), msgt);
}


void Logger::startBlockMsg(string msg, MsgType msgt) {
	if (m_msgmask & msgt) {
		writePendingNL();
		writeString(getTime(time(0)) + " : " + makeIndent(m_indent) + msg);
		m_nlpending = true;
		indentMore();
	}
}


void Logger::endBlockMsg(string msg, MsgType msgt) {
	if (m_msgmask & msgt) {
		indentLess();
		if (m_nlpending) {
			writeString(msg);
			writePendingNL();
		}
		else {
			writeString(getTime(time(0)) + " : " + makeIndent(m_indent) + msg + "\n");
		}
	}
}


FunctionLogger::FunctionLogger(string func, Logger::MsgType msgtype)
: m_function(func), m_msgtype(msgtype) {
	Log.startBlockMsg(m_function + " { ", m_msgtype);
}


FunctionLogger::~FunctionLogger() {
	Log.endBlockMsg("}", m_msgtype);
}


string dbgStr(const char *s) {
	if (s) {
		if (_CrtIsValidPointer(s, 1, 0)) return string(s);
		else return "<invalid>";
	}
	else return "<null>";
}



