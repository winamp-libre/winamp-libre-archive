#ifndef MAINDIR_HEADER_INCLUDED
#define MAINDIR_HEADER_INCLUDED


#include "MyString.h"

string getMainDir();
string getIniFile();
string getOtherIniFile();
string getWinampDir();


#endif	// MAINDIR_HEADER_INCLUDED