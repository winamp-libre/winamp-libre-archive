#ifndef VECTOR_HEADER_INCLUDED
#define VECTOR_HEADER_INCLUDED


#include <cassert>
#include <cstring>
#include <iostream>


template <class T> class vector {

	// implementation

	T *m_data;
	int m_size;

	// useful functions

	void alloc() { m_data = new T[m_size]; assert(m_data != 0); }
	void copy(const vector &v);

public:

	// size_type for various operations
	
	typedef int size_type;

	// const_iterator
	
	class const_iterator {

		friend vector;

	protected:

		union {
			const T *cdata;
			T *vdata;
		};

		const_iterator() { }
		const_iterator(const T *t) : cdata(t) { }

	public:

		const_iterator &operator ++() { ++cdata; return *this; }
		const T &operator *() const { return *cdata; }
		const T *operator ->() const { return cdata; }
		bool operator ==(const const_iterator &i) const { return cdata == i.cdata; }
		bool operator !=(const const_iterator &i) const { return !(operator ==(i)); }

	};

	// iterator

	class iterator : public const_iterator {

		friend vector;

		iterator() { }
		iterator(T *t) { vdata = t; }

	public:

		iterator &operator ++() { ++vdata; return *this; }
		T &operator *() { return *vdata; }
		T *operator ->() { return vdata; }
		bool operator ==(const iterator &i) const { return vdata == i.vdata; }
		bool operator !=(const iterator &i) const { return !(operator ==(i)); }

	};

	// constructors and destructor

	explicit vector(size_type n = 0) : m_size(n) { alloc(); }
	vector(const vector &v) : m_size(v.m_size) { alloc(); copy(v); }
	~vector() { delete[] m_data; }

	// operators

	vector &operator =(const vector &v) { m_size = v.m_size; delete[] m_data; alloc(); copy(v); return *this; }
	T &operator [](size_type n) { return m_data[n]; }
	const T &operator [](size_type n) const { return m_data[n]; }

	// various useful functions

	size_type size() const { return m_size; }
	void resize(size_type n);
	void push_back(const T &t) { resize(m_size + 1); m_data[m_size - 1] = t; }
	void reserve(size_type n) { }
	void clear() { delete[] m_data; m_size = 0; alloc(); }

	// iterator functions

	iterator begin() { iterator i(m_data); return i; }
	iterator end() { iterator i(&(m_data[m_size])); return i; }
	const_iterator begin() const { const_iterator i(m_data); return i; }
	const_iterator end() const { const_iterator i(&(m_data[m_size])); return i; }
};


template <class T> void vector<T>::copy(const vector &v)
{
	for (int i = 0; i < v.m_size; ++i)
		m_data[i] = v.m_data[i];
}


template <class T> void vector<T>::resize(size_type n)
{
	T *t = new T[n];
	if (n < m_size) m_size = n;
	for (int i = 0; i < m_size; i++)
		t[i] = m_data[i];
	m_size = n;
	delete[] m_data;
	m_data = t;
}


#endif   // VECTOR_HEADER_INCLUDED
      
