#ifndef LIST_HEADER_INCLUDED
#define LIST_HEADER_INCLUDED


#include <cassert>


template <class T> class list {

private:

	// item objects group the stored object with pointers to the next
	//	and previous items

	class item {
	public:
		T *data;
		item *next;
		item *prev;
	};

public:

	// size_type is used to store numerical positions and sizes

	typedef unsigned int size_type;

	// const_iterator

	class const_iterator {

		friend list;
		
	protected:

		union {
			const item *cdata;
			item *vdata;
		};

		const_iterator() { }
		const_iterator(const item *data) : cdata(data) { }
	
	public:

		const_iterator &operator ++() { cdata = cdata->next; return *this; }
		const T &operator *() const { return *(cdata->data); }
		const T *operator ->() const { return cdata->data; }
		bool operator ==(const const_iterator &i) const { return cdata == i.cdata; }
		bool operator !=(const const_iterator &i) const { return !(operator ==(i)); }

	};

	// iterator is publicly derived from const_iterator to get the 
	//	correct iterator conversion

	class iterator : public const_iterator {

		friend list;

		iterator() { }
		iterator(item *data) { vdata = data; }

	public:

		iterator &operator ++() { vdata = vdata->next; return *this; }
		T &operator *() { return *(vdata->data); }
		T *operator ->() { return vdata->data; }
		bool operator ==(const iterator &i) const { return vdata == i.vdata; }
		bool operator !=(const iterator &i) const { return !(operator ==(i)); }

	};

private:

	// some useful auxiliary functions

	void init() { assert(m_head != 0); m_head->data = 0; m_head->next = m_head->prev = m_head; }
	void copy(const list<T> &l);

public:

	// constructors and destructor

	list() : m_head(new item), m_size(0) { init(); }
	list(const list<T> &l) : m_head(new item), m_size(0) { init(); copy(l); }
	~list() { clear(); delete m_head; }

	// assignment operator

	list<T> &operator =(const list<T> &l) { clear(); copy(l); return *this; }

	// other member functions

	void push_back(const T &t);
	void pop_back();
	iterator insert(iterator pos, const T &t);
	void erase(iterator pos);

	const_iterator begin() const { return const_iterator(m_head->next); }
	const_iterator end() const { return const_iterator(m_head); }
	iterator begin() { return iterator(m_head->next); }
	iterator end() { return iterator(m_head); }

	bool empty() const { return size() == 0; }
	size_type size() const { return m_size; }
	void clear() { while (m_size > 0) pop_back(); }

	void splice(iterator pos, list &x);

private:

	// implementation

	// invariant: following size indirections though next pointers
	//	returns us to head

	item *m_head;
	size_type m_size;

};


template <class T> void list<T>::copy(const list<T> &l)
{
	for (item *curr = l.m_head->next; curr != l.m_head; curr = curr->next)
		push_back(*(curr->data));
}


template <class T> void list<T>::push_back(const T &t)
{
	item *n = new item;		// TODO
	n->data = new T(t);		// TODO
	n->prev = m_head->prev;
	n->next = m_head;
	m_head->prev->next = n;
	m_head->prev = n;
	m_size++;
}


template <class T> void list<T>::pop_back()
{
	assert(m_size != 0);
	item *temp = m_head->prev;
	temp->prev->next = temp->next;
	temp->next->prev = temp->prev;
	delete temp->data;
	delete temp;
	m_size--;
}


template <class T> list<T>::iterator list<T>::insert(iterator pos, const T &t)
{
	item *n = new item;		// TODO
	n->data = new T(t);		// TODO
	n->prev = pos.vdata->prev;
	n->next = pos.vdata;
	pos.vdata->prev->next = n;
	pos.vdata->prev = n;
	m_size++;

	return iterator(n);
}


template <class T> void list<T>::erase(iterator pos)
{
	assert(m_size != 0);
	pos.vdata->prev->next = pos.vdata->next;
	pos.vdata->next->prev = pos.vdata->prev;
	delete pos.vdata->data;
	delete pos.vdata;
	m_size--;
}



template <class T> void list<T>::splice(list<T>::iterator pos, list<T> &x)
{
	if (x.m_size > 0) {

		// attach elements of x to this

		x.m_head->next->prev = pos.vdata->prev;
		x.m_head->prev->next = pos.vdata;

		// attach this to elements of x
		
		pos.vdata->prev->next = x.m_head->next;
		pos.vdata->prev = x.m_head->prev;

		// remove the elements from x

		x.m_head->next = x.m_head;
		x.m_head->prev = x.m_head;

		// adjust sizes

		m_size += x.m_size;
		x.m_size = 0;

	}
}


#endif	// LIST_HEADER_INCLUDED