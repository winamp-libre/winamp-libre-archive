#ifndef DLL_HEADER_INCLUDED
#define DLL_HEADER_INCLUDED


#include "afxwin.h"
#include "MyString.h"
#include "SynException.h"


class DLL {
	HINSTANCE m_hlib;
	string m_filename;

	DLL();

	void loadDLL();

public:

	MAKE_EXCEPTION(DLLLoadException, SynException, "Could not load DLL");

	explicit DLL(string filename);
	DLL(const DLL &dll);
	~DLL();

	DLL &operator =(const DLL &dll);

	void *getFunction(string funcname);
};


#endif	// DLL_HEADER_INCLUDED