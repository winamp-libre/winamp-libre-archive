#ifndef STRING_HEADER_INCLUDED
#define STRING_HEADER_INCLUDED


#include <cstring>
#include <iostream>


class string {

	char *m_data;

public:

	typedef int size_type;
	static const size_type npos;

	string() : m_data(new char[1]) { *m_data = '\0'; }
	string(const char *s) : m_data(new char[strlen(s) + 1]) { strcpy(m_data, s); }
	string(const string &s, size_type start, size_type n) : m_data(new char[1]) { assign(s, start, n); }
	string(const string &s) : m_data(new char[strlen(s.m_data) + 1]) { strcpy(m_data, s.m_data); }
	~string() { delete[] m_data; }

	void erase() { delete[] m_data; m_data = new char[1]; *m_data = '\0'; }
	string &assign(const string &s, size_type start, size_type n);

	size_type length() const { return strlen(m_data); }
	const char *c_str() const { return m_data; }
	size_type find(char c) const;
	size_type rfind(char c) const;

	string &operator =(const string &s);
	string &operator +=(const string &s);
	string &operator +=(char c);
	char &operator [](size_type n) { return m_data[n]; }
	const char &operator [](size_type n) const { return m_data[n]; }

	friend bool operator ==(const string &l, const string &r);
	friend std::ostream operator <<(std::ostream &o, const string &s);

};


const string operator +(const string &l, const string &r);
bool operator !=(const string &l, const string &r);


#endif	// STRING_HEADER_INCLUDED