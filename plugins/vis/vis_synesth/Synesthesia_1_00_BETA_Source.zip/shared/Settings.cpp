#include "DLL.h"
#include "Effects.h"
#include "IniFile.h"
#include "Logger.h"
#include "MyVector.h"
#include "Paths.h"
#include "RegistryKey.h"
#include "Settings.h"
#include "SoniqueMisc.h"
#include "Utility.h"


void Settings::initDisplayModes(const IniFile& ini) {
	FunctionLogger flog("Settings::initDisplayModes(const IniFile&)", Logger::synfunc);
	// Try to load the display modes data out of the file
	try {
		int num = ini.getInt("General Settings", "Number of display modes");

		for (int i = 0; i < num; ++i) {
			DisplayMode dm(ini.getString("Display Modes", "Mode " + toStr(i)));
			m_dispModes.push_back(dm);
		}
	}
	catch (IniFile::NotPresent) {
		Log("Couldn't find display modes in .ini file", Logger::recover);
		// Just leave the list empty
	}

	sortDispModes();
}


void Settings::saveDisplayModes(IniFile& ini) const {
	FunctionLogger flog("Settings::saveDisplayModes(IniFile&) const", Logger::synfunc);
	// Iterate over the display modes and add them to the file
	int n = 0;
	for (vector<DisplayMode>::const_iterator it = m_dispModes.begin();
		it != m_dispModes.end();
		++it, ++n)
		ini.writeString("Display Modes", "Mode " + toStr(n), it->describe());

	// Write the number of display modes
	ini.writeInt("General Settings", "Number of display modes", n);
}


void Settings::initPlugins(const IniFile& ini) {
	FunctionLogger flog("Settings::initPlugins(const IniFile&)", Logger::synfunc);

	// Try to get the data out of the ini file
	try {
		int num = ini.getInt("General Settings", "Number of plugins");

		for (int i = 0; i < num; ++i) {
			string filename = ini.getString("Plugins", "Filename " + toStr(i));
			string displayname = ini.getString("Plugins", "Display name " + toStr(i));
			PluginIdent pi(filename, displayname);
			m_plugins.push_back(pi);
		}
	}
	catch (IniFile::NotPresent) {
		Log("Couldn't find the plugins in the .ini file", Logger::recover);
		// Just leave the list empty
	}
}


void Settings::savePlugins(IniFile& ini) const {
	FunctionLogger flog("Settings::savePlugins(IniFile&) const", Logger::synfunc);

	// Iterate over the plugins
	int n = 0;
	for (vector<PluginIdent>::const_iterator it = m_plugins.begin();
		it != m_plugins.end();
		++it, ++n) {
		ini.writeString("Plugins", "Filename " + toStr(n), it->Filename);
		ini.writeString("Plugins", "Display name " + toStr(n), it->DisplayName);
	}

	// Write the number of plugins
	ini.writeInt("General Settings", "Number of plugins", n);
}


void Settings::initEffects(const IniFile& ini) {
	FunctionLogger flog("Settings::initEffects(const IniFile&)", Logger::synfunc);

	// The plugins must be set up before this will work

	m_effects.resize(m_plugins.size());

	for (int i = 0; i < m_plugins.size(); ++i) {
		string pname = m_plugins[i].DisplayName;
		Effects fx;
		try {
			fx.Blur = ini.getBool(pname, "Blur");
			fx.BlurLevel = ini.getInt(pname, "Blur level");
			fx.Motion = ini.getBool(pname, "Motion");
			fx.MotionSpeed = ini.getInt(pname, "Motion speed");
		}
		catch (IniFile::NotPresent) {
			fx.Blur = 0;
			fx.BlurLevel = 20;
			fx.Motion = 0;
			fx.MotionSpeed = 10;
		}
		m_effects[i] = fx;
	}
}


void Settings::saveEffects(IniFile& ini) const {
	FunctionLogger flog("Settings::saveEffects(IniFile&) const", Logger::synfunc);

	for (int i = 0; i < m_plugins.size(); ++i) {
		string pname = m_plugins[i].DisplayName;
		ini.writeBool(pname, "Blur", m_effects[i].Blur);
		ini.writeInt(pname, "Blur level", m_effects[i].BlurLevel);
		ini.writeBool(pname, "Motion", m_effects[i].Motion);
		ini.writeInt(pname, "Motion speed", m_effects[i].MotionSpeed);
	}
}


void Settings::initDirectories(const IniFile& ini) {
	FunctionLogger flog("Settings::initDirectories(const IniFile&)", Logger::synfunc);

	// Try to get the directories from the ini file
	try {
		int num = ini.getInt("General Settings", "Number of directories");

		for (int i = 0; i < num; ++i) {
			string filename = ini.getString("Directories", "Directory " + toStr(i));
			m_dirs.push_back(filename);
		}

		m_visini = ini.getString("General Settings", "vis.ini path");

		if (!exists(m_visini)) m_visini.erase();
	}
	catch (IniFile::NotPresent) {
		// Leave it for now...
	}
}


void Settings::saveDirectories(IniFile& ini) const {
	FunctionLogger flog("Settings::saveDirectories(IniFile&) const", Logger::synfunc);

	// Iterate over the directories
	int n = 0;
	for (vector<string>::const_iterator it = m_dirs.begin();
		it != m_dirs.end();
		++it, ++n) {
		ini.writeString("Directories", "Directory " + toStr(n), *it);
	}

	// Write the number of plugins
	ini.writeInt("General Settings", "Number of directories", n);

	// Write the vis ini path
	ini.writeString("General Settings", "vis.ini path", m_visini);
}


void Settings::initSelections(const IniFile& ini) {
	FunctionLogger flog("Settings::initSelections(const IniFile&)", Logger::synfunc);

	// Try to read the selections from the ini file
	try {
		m_fullscreen = ini.getBool("General Settings", "Fullscreen");
		m_selDispMode = ini.getInt("General Settings", "Selected display mode");

		// Load the selected plugins
		int numplugs = ini.getInt("General Settings", "Number of selected plugins");

		for (int i = 0; i < numplugs; ++i) {
			string filename = ini.getString("Selected Plugins", "Plugin " + toStr(i));

			// Check the plugin exists in the plugin list
			for (int j = 0; j < m_plugins.size(); ++j)
				if (m_plugins[j].Filename == filename) break;

				if (j != m_plugins.size()) m_selPlugins.push_back(m_plugins[j]);
		}

		m_preview = ini.getBool("General Settings", "Preview");
	}
	catch (IniFile::NotPresent) {
		// Make up some sensible defaults
		Log("Couldn't find the selections in the .ini file", Logger::recover);
		m_fullscreen = false;
		m_selDispMode = -1;
		m_selPlugins.clear();
		m_preview = true;
	}

	// Sanity check the values
	if (m_selDispMode < -1 || m_selDispMode >= m_dispModes.size())
		m_selDispMode = -1;
}


void Settings::saveSelections(IniFile& ini) const {
	FunctionLogger flog("Settings::saveSelections(IniFile&) const", Logger::synfunc);

	// Write the selections data
	ini.writeBool("General Settings", "Fullscreen", m_fullscreen);
	ini.writeInt("General Settings", "Selected display mode", m_selDispMode);
	ini.writeInt("General Settings", "Number of selected plugins", m_selPlugins.size());

	for (int i = 0; i < m_selPlugins.size(); ++i)
		ini.writeString("Selected Plugins", "Plugin " + toStr(i), m_selPlugins[i].Filename);

	ini.writeBool("General Settings", "Preview", m_preview);
}


void Settings::initRestricted(const IniFile& ini) {
	FunctionLogger flog("Settings::initRestricted(const IniFile&)", Logger::synfunc);

	// Try to read them from the ini file
	try {
		int num = ini.getInt("General Settings", "Number of restricted plugins");
		m_restricted.resize(num);

		for (int i = 0; i < num; ++i)
			m_restricted[i] = ini.getString("Restricted Plugins", "Plugin " + toStr(i));
	}
	catch (IniFile::NotPresent) {
		Log("Couldn't find restricted list in ini file");
		m_restricted.clear();
	}
}


void Settings::saveRestricted(IniFile& ini) const {
	FunctionLogger flog("Settings::saveRestricted(IniFile&) const", Logger::synfunc);

	ini.writeInt("General Settings", "Number of restricted plugins", m_restricted.size());

	int n = 0;
	for (vector<string>::const_iterator i = m_restricted.begin();
		i != m_restricted.end();
		++i, ++n)
		ini.writeString("Restricted Plugins", "Plugin " + toStr(n), *i);
}


void Settings::sortDispModes() {
	FunctionLogger flog("void Settings::sortDispModes()", Logger::synfunc);

	bool done = false;

	while (!done) {
		done = true;
		for (int i = 0; i < m_dispModes.size() - 1; ++i) {
			if (geqDM(m_dispModes[i], m_dispModes[i + 1])) {
				DisplayMode t = m_dispModes[i];
				m_dispModes[i] = m_dispModes[i + 1];
				m_dispModes[i + 1] = t;
				done = false;
			}
		}
	}
}


bool Settings::leqDM(const DisplayMode& lhs, const DisplayMode& rhs) const {
	return (lhs < rhs) || (lhs == rhs);
}


bool Settings::geqDM(const DisplayMode& lhs, const DisplayMode& rhs) const {
	return !(lhs < rhs);
}









Settings::Settings() {
	FunctionLogger flog("Settings::Settings()", Logger::synfunc);

	// Open the ini files and load settings from them
	IniFile ini(getIniFile());
	IniFile ini2(getOtherIniFile());

	// Check the version information
	try {
		if (ini.getInt("General Settings", "Version") != 1) {
			Log("synesth.ini has wrong version number");
			ini.clear();
		}
	}
	catch (...) {
		Log("synesth.ini has no version number");
		ini.clear();
	}
	
	try {
		if (ini2.getInt("General Settings", "Version") != 1) {
			Log("synesth_distr.ini has wrong version number");
			ini2.clear();
		}
	}
	catch (...) {
		Log("synesth_distr.ini has no version number");
		ini2.clear();
	}

	// Initialise
	initDisplayModes(ini);
	initDirectories(ini);
	initPlugins(ini);
	initEffects(ini);
	initSelections(ini);
	initRestricted(ini2);
}


Settings::~Settings() { 
	FunctionLogger flog("Settings::~Settings()", Logger::synfunc);
}


void Settings::save() const {
	FunctionLogger flog("Settings::save() const", Logger::synfunc);

	// Create ini files
	IniFile ini(getIniFile(), true);
	IniFile ini2(getOtherIniFile(), true);

	// Save settings
	saveDisplayModes(ini);
	saveDirectories(ini);
	savePlugins(ini);
	saveEffects(ini);
	saveSelections(ini);
	saveRestricted(ini2);

	// Save version
	ini.writeInt("General Settings", "Version", 1);
	ini2.writeInt("General Settings", "Version", 1);

	// Save the ini file object as an actual file
	ini.save();
	ini2.save();
}


void Settings::setSelDispMode(DisplayMode dm) {
	FunctionLogger flog("Settings::selDispMode(DisplayMode)", Logger::synfunc);

	dm.BPP = 32;

	int n = 0;
	for (vector<DisplayMode>::const_iterator it = m_dispModes.begin();
		it != m_dispModes.end();
		++it, ++n) {
		if (dm == *it) {
			m_selDispMode = n;
			return;
		}
	}

	m_selDispMode = -1;
}


void Settings::addSelPluginByDisplayName(string p) {
	FunctionLogger flog("Settings::addSelPluginByDisplayName(string)", Logger::synfunc);

	int n = 0;
	for (vector<PluginIdent>::const_iterator it = m_plugins.begin();
		it != m_plugins.end();
		++it, ++n) {
		if (p == it->DisplayName) {
			m_selPlugins.push_back(*it);
			return;
		}
	}
}


const PluginIdent& Settings::getPIByDisplayName(string dn) const {
	FunctionLogger flog("Settings::getPIByDisplayName(string)", Logger::synfunc);

	for (int i = 0; i < m_plugins.size(); ++i) {
		if (m_plugins[i].DisplayName == dn) return m_plugins[i];
	}

	return PluginIdent();		// dodgy
}


const PluginIdent& Settings::selNextPlugin(int which) {
	FunctionLogger flog("Settings::selNextPlugin(int)", Logger::synfunc);

	// Find the plugin in the list
	for (int i = 0; i < m_plugins.size(); ++i) {
		if (m_selPlugins[which].Filename == m_plugins[i].Filename) break;
	}

	// Cycle on
	i = (i + 1) % m_plugins.size();
	m_selPlugins[which] = m_plugins[i];
	return m_plugins[i];
}


const PluginIdent& Settings::selPrevPlugin(int which) {
	FunctionLogger flog("Settings::selPrevPlugin(int)", Logger::synfunc);

	// Find the plugin in the list
	for (int i = 0; i < m_plugins.size(); ++i) {
		if (m_selPlugins[which].Filename == m_plugins[i].Filename) break;
	}

	// Cycle back
	i = (i + m_plugins.size() - 1) % m_plugins.size();
	m_selPlugins[which] = m_plugins[i];
	return m_plugins[i];
}


Effects& Settings::getEffectsForPlugin(const PluginIdent& p) {
	FunctionLogger flog("Settings::getEffectsForPlugin(const PluginIdent& p)", Logger::synfunc);

	for (int i = 0; i < m_plugins.size(); ++i)
		if (p.Filename == m_plugins[i].Filename) break;

	if (i != m_plugins.size()) return m_effects[i];
	else {
		Effects fx;
		fx.Blur = false;
		return fx;
	}
}


void Settings::resetDirectories() {
	FunctionLogger flog("Settings::updateDirectories()", Logger::synfunc);

	m_dirs.clear();
	m_visini.erase();

	try {
		string dir = nicifyDirPath(getWinampDir());
		m_dirs.push_back(dir + "vis\\");
		m_visini = dir + "vis.ini";
	}
	catch (...) {
		// Nothing we can do - leave the list empty
	}
}


void Settings::updateDisplayModes() {
	FunctionLogger flog("Settings::updateDisplayModes()", Logger::synfunc);

	// Store the currently selected one
	DisplayMode olddm = m_dispModes[m_selDispMode];

	// List all supported display modes
	vector<DisplayMode> dms = DisplayMode::listDisplayModes();
	
	// Get the ones with 32 bpp
	vector<DisplayMode> dms32;
	for (vector<DisplayMode>::const_iterator it = dms.begin(); 
		it != dms.end();
		++it)
		if (it->BPP == 32) dms32.push_back(*it);
	
	// Set them
	m_dispModes = dms32;

	// Sort them
	sortDispModes();

	// Restore old selection
	m_selDispMode = -1;
	int n = 0;
	for (vector<DisplayMode>::const_iterator it2 = m_dispModes.begin();
		it2 != m_dispModes.end();
		++it2, ++n) {
		if (*it2 == olddm) {
			m_selDispMode = n;
			break;
		}
	}
}


void Settings::updatePlugins() {
	FunctionLogger flog("Settings::updatePlugins()", Logger::synfunc);
	
	int i, j, k;

	// Create a copy of the previous plugins list, and the previous effects list
	vector<PluginIdent> oldplugins = m_plugins;
	vector<Effects> oldeffects = m_effects;
	vector<PluginIdent> oldsel = m_selPlugins;

	// Clear the list
	m_plugins.clear();

	// Go through each directory, listing the plugins in it
	for (i = 0; i < m_dirs.size(); ++i) {

		// List the svp files under that directory
		list<string> svplist = listDir(m_dirs[i], "*.svp", true, true, false, true, true);

		// Go through the list adding each svp
		for (list<string>::const_iterator svpit = svplist.begin();
			svpit != svplist.end();
			++svpit) {

			// Check restricted plugins
			for (j = 0; j < m_restricted.size(); ++j)
				if (separate(*svpit).second == m_restricted[j]) break;

			if (j == m_restricted.size()) {
				// Load the library to get its internal name
				DLL lib(*svpit);
				QueryModuleFunc qmf = (QueryModuleFunc) lib.getFunction("QueryModule");
				SoniquePluginInfo *info = qmf();
				string dname = info->internalname;

				// Check plugin not already present
				int count = 1;
				for (k = 0; k < m_plugins.size(); ++k) {
					string tname = string(m_plugins[k].DisplayName, 0, dname.length());
					if (tname == dname) ++count;
				}

				// Add the plugin to the list
				if (count == 1)
					m_plugins.push_back(PluginIdent(*svpit, info->internalname));
				else 
					m_plugins.push_back(PluginIdent(*svpit, string(info->internalname) 
						+ " (" + toStr(count) + ")"));
			}

		}

	}

	// Clear the effects list
	m_effects.clear();

	// Match up the new plugins with the old effects
	for (i = 0; i < m_plugins.size(); ++i) {
		for (int j = 0; j < oldplugins.size(); ++j)
			if (oldplugins[j].DisplayName == m_plugins[i].DisplayName) break;

		if (j != oldplugins.size()) m_effects.push_back(oldeffects[j]);
		else {
			DLL lib(m_plugins[i].Filename);
			QueryModuleFunc qmf = (QueryModuleFunc) lib.getFunction("QueryModule");
			SoniquePluginInfo *info = qmf();

			Effects fx;
			fx.Blur = ((info->requires & 4) != 0);
			fx.BlurLevel = 10;
			fx.Motion = ((info->requires & 4) != 0);
			fx.MotionSpeed = 10;

			m_effects.push_back(fx);
		}
	}
	
	// Check the previously selected plugins still exist
	m_selPlugins.clear();

	for (i = 0; i < oldsel.size(); ++i) {
		for (j = 0; j < m_plugins.size(); ++j) {
			if (m_plugins[j].Filename == oldsel[i].Filename) {
				m_selPlugins.push_back(m_plugins[j]);
				break;
			}
		}
	}
}


void Settings::reinitialise() {
	FunctionLogger flog("void Settings::reinitialise()", Logger::synfunc);

	// Clear the current settings
	m_dispModes.clear();
	m_plugins.clear();
	m_selPlugins.clear();
	m_effects.clear();
	m_dirs.clear();
	m_restricted.clear();
	m_visini.erase();

	// Open ini files and load settings from them
	IniFile ini(getIniFile());
	IniFile ini2(getOtherIniFile());

	// Check the version information
	try {
		if (ini.getInt("General Settings", "Version") != 1) {
			Log ("synesth.ini has wrong version number");
			ini.clear();
		}
	}
	catch (...) {
		Log ("synesth.ini has no version number");
		ini.clear();
	}
	
	try {
		if (ini2.getInt("General Settings", "Version") != 1) {
			Log ("synesth_distr.ini has wrong version number");
			ini2.clear();
		}
	}
	catch (...) {
		Log ("synesth_distr.ini has no version number");
		ini2.clear();
	}

	initDisplayModes(ini);
	initDirectories(ini);
	initPlugins(ini);
	initEffects(ini);
	initSelections(ini);
	initRestricted(ini2);
}
