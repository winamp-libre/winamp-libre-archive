#ifndef LOGGER_HEADER_INCLUDED
#define LOGGER_HEADER_INCLUDED


#include <cstdio>
#include <ctime>
#include "SynException.h"
#include "MyString.h"


class Logger {
public:
	//	fatal = fatal error
	//	user = user recoverable error
	//	synfunc = Synesthesia function call
	//	utilfunc = utility function call
	//	general = general debug message
	//	recover = program recoverable error
	//	winfunc = Winamp interface function
	//	guifunc = user interface function
	enum MsgType { fatal = 1, user = 2, synfunc = 4, utilfunc = 8, 
		general = 16, recover = 32, winfunc = 64, guifunc = 128 };

private:
	string m_logfile;
	string m_openmsg, m_closemsg;
	bool m_opened;
	time_t m_opentime;
	MsgType m_msgmask;
	int m_indent;
	bool m_nlpending;

	string getTime(time_t t) const;
	string makeIndent(int i) const;
	void writeString(string s);
	void writePendingNL();

	void indentMore() { ++m_indent; }
	void indentLess() { --m_indent; }

public:

	Logger(string logfile, string openmsg, string closemsg);
	~Logger();

	void operator ()(string msg, MsgType msgt = general);
	void operator ()(SynException ex, MsgType msgt = fatal);

	void startBlockMsg(string msg, MsgType msgt = general);
	void endBlockMsg(string msg, MsgType msgt = general);

};


extern Logger Log;


class FunctionLogger {
	string m_function;
	Logger::MsgType m_msgtype;

public:
	FunctionLogger(string func, Logger::MsgType msgtype);
	~FunctionLogger();
};


string dbgStr(const char *s);


#endif   // LOGGER_HEADER_INCLUDED
