#ifndef INIFILE_HEADER_INCLUDED
#define INIFILE_HEADER_INCLUDED


#include "MyList.h"
#include "MyPair.h"
#include "MyString.h"
#include "SynException.h"


class IniFile {
	//                        section  key     value
	typedef list< pair< pair< string, string>, string > > data;

	data m_data;
	string m_filename;

	data::iterator find(string section, string key);
	data::const_iterator find(string section, string key) const;
	data::iterator findsect(string section);
	data::const_iterator findsect(string section) const;

	bool getLine(FILE *fp, string &s);
	string clearWhiteSpace(const string &s);

public:

	MAKE_EXCEPTION(NotPresent, SynException, "Could not find part of ini file");

	explicit IniFile(string filename, bool fresh = false);

	bool checkKey(string section, string key) const;

	string getString(string section, string key) const;
	int getInt(string section, string key) const;
	bool getBool(string section, string key) const;

	void writeString(string section, string key, string val);
	void writeInt(string section, string key, int val);
	void writeBool(string section, string key, bool val);

	list<string> getHeaders() const;
	list< pair<string, string> > getSection(string section) const;

	void clear();

	void save() const;
}; 


#endif	// INIFILE_HEADER_INCLUDED