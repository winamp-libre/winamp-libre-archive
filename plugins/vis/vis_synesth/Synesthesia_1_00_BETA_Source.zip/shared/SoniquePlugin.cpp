#include "ClickConsole.h"
#include "Logger.h"
#include "SoniqueMisc.h"
#include "SoniquePlugin.h"
#include "Utility.h"


int SoniquePlugin::motionSize(int height, bool motion) {
	FunctionLogger flog("SoniquePlugin::motionSize(int, bool)", Logger::synfunc);
	if (motion) return height * 3;
	else return height;
}


void SoniquePlugin::doMotion() {
	// Add velocity to position hints
	m_vposx += m_velx;
	m_vposy += m_vely;

	// Bring the position "hints" within -1 and 1 by updating the positions themselves
	int velx, vely;
	velx = vely = 0;

	if (m_vposx > 1.0 || m_vposx < 1.0) {
		velx = (int) m_vposx;
		m_posx += velx;
		m_vposx -= velx;
	}
	if (m_vposy > 1.0 || m_vposy < 1.0) {
		vely = (int) m_vposy;
		m_posy += vely;
		m_vposy -= vely;
	}
	
	// Update drawing region
	if (m_posx > m_width * 2 || m_posx < 0 || m_posy > m_height * 2 || m_posy < 0) {
		// If the drawing region has hit the edge of the surface, it needs to be moved back to a corner
		m_posx -= velx;
		m_posy -= vely;

		// Calculate the area to move it to - this will be the corner opposing it's current velocity
		int dx, dy;

		if (m_velx > 0) {
			if (m_vely > 0) {
				dx = 0;
				dy = 0;
			}
			else {
				dx = 0;
				dy = m_height * 2;
			}
		}
		else {
			if (m_vely > 0) {
				dx = m_width * 2;
				dy = 0;
			}
			else {
				dx = m_width * 2;
				dy = m_height * 2;
			}
		}
		
		// Copy the surface, and reset the positions (for some reason, PTC has weird Hermes problems
		//	with this copy procedure, so we do it manually)
		unsigned long *p = (unsigned long *) m_surface.lock();
		int pitch = m_surface.pitch() / 4;
		for (int i = 0; i < m_height; ++i)
			memcpy(&(p[(dy + i) * pitch + dx]), &(p[(m_posy + i) * pitch + m_posx]), m_width * 4);
		m_surface.unlock();

		m_posx = dx;
		m_posy = dy;

		// Now move
		m_posx += velx;
		m_posy += vely;
	}

	// The new parts of the drawing region need to be blanked
	Area clside, cltb;

	// Calculate the new parts (there will be one on the side, and one at the top/bottom)
	if (velx > 0)
		clside = Area(m_posx + m_width - velx, m_posy, m_posx + m_width, m_posy + m_height);
	else
		clside = Area(m_posx, m_posy, m_posx - velx, m_posy + m_height);

	if (vely > 0)
		cltb = Area(m_posx, m_posy + m_height - vely, m_posx + m_width, m_posy + m_height);
	else
		cltb = Area(m_posx, m_posy, m_posx + m_width, m_posy - vely);

	// Blank the new regions
	m_surface.clear(Color(0, 0, 0), clside);
	m_surface.clear(Color(0, 0, 0), cltb);

	// Update the motion vector
	double acc = m_fx.MotionSpeed / 100.0;
	if (m_velx < m_destvelx - acc) m_velx += acc;
	else if (m_velx > m_destvelx + acc) m_velx -= acc;
	else m_destvelx = random(-m_fx.MotionSpeed, m_fx.MotionSpeed);

	if (m_vely < m_destvely - acc) m_vely += acc;
	else if (m_vely > m_destvely + acc) m_vely -= acc;
	else m_destvely = random(-m_fx.MotionSpeed, m_fx.MotionSpeed);
}


SoniquePlugin::SoniquePlugin(PluginIdent p, string visini, ClickConsole *cc, Effects fx)
:	m_lib(p.Filename), 
	m_qi(new QueryInterface),
	m_console(cc), 
	m_surface(motionSize(cc->width(), fx.Motion), motionSize(cc->height(), fx.Motion), Format(32, 0xff0000, 0xff00, 0xff)), 
	m_visini(visini),
	m_fx(fx)
{
	FunctionLogger flog("SoniquePlugin::SoniquePlugin(PluginIdent, string, ClickConsole *, Effects fx)", Logger::synfunc);

	m_width = cc->width();
	m_height = cc->height();

	// Initialise the plugin
	QueryModuleFunc qmf = (QueryModuleFunc) m_lib.getFunction("QueryModule");
	m_info = qmf();
	m_info->loadSettings(m_visini.c_str());

	m_info->initialise();

	if (m_info->version >= 1)
		m_info->receiveQueryInterface(m_qi);

	// Set up motion defaults
	m_posx = 0;
	m_posy = 0;
	m_vposx = 0;
	m_vposy = 0;
	m_velx = random(-m_fx.MotionSpeed, m_fx.MotionSpeed);
	m_vely = random(-m_fx.MotionSpeed, m_fx.MotionSpeed);
	m_destvelx = random(-m_fx.MotionSpeed, m_fx.MotionSpeed);
	m_destvely = random(-m_fx.MotionSpeed, m_fx.MotionSpeed);
}


SoniquePlugin::~SoniquePlugin() {
	FunctionLogger flog("SoniquePlugin::~SoniquePlugin()", Logger::synfunc);

	if (m_info->version >= 1) m_info->deInit();
	m_info->saveSettings(m_visini.c_str());

	delete m_qi;
}


bool SoniquePlugin::render(const VisData& vd) {
	//FunctionLogger flog("SoniquePlugin::render(const VisData& vd)", Logger::synfunc);

	static SoniquePluginInfo::SoniqueVisData svd;

	svd.time = GetTickCount();

	// If the plugin needs waveform info, copy it
	if ((m_info->requires) & 1) {
		memcpy(svd.waveform[0], vd.waveform[0], 512);
		memcpy(svd.waveform[1], vd.waveform[1], 512);
	}

	// If the plugin needs spectrum data, copy that too
	if ((m_info->requires) & 2) {
		int j = 0;
		for (int i = 0; i < 256; ++i, j += 2) {
			svd.spectrum[0][i] = vd.spectrum[0][j] / 2;
			svd.spectrum[1][i] = vd.spectrum[1][j] / 2;
		}
	}

	// If the plugin expects effects, but there aren't any in use, clear the screen
	if ((m_info->requires & 4) && !m_fx.Blur && !m_fx.Motion) m_surface.clear();

	// Lock the surface
	int pitch = m_surface.pitch() / 4;
	unsigned long *drawat = ((unsigned long *) m_surface.lock()) + pitch * m_posy + m_posx;

	// Do the render, unlock the surface, and copy to the console
	BOOL result = m_info->render(drawat, m_width, m_height, pitch, &svd);
	m_surface.unlock();
	m_surface.copy(*m_console, Area(m_posx, m_posy, m_posx + m_width, m_posy + m_height),
		Area(0, 0, m_console->width(), m_console->height()));
	m_console->update();

	// Update movement
	if (m_fx.Motion) doMotion();

	// Do blur
	if (m_fx.Blur || m_fx.Motion) {
		unsigned int *p = ((unsigned int *) m_surface.lock()) + pitch * m_posy + m_posx; 
		blurMMX(p, m_width, m_height, m_surface.pitch(), m_fx.BlurLevel, 1, 0);
		m_surface.unlock();
	}

	// Check for mouse clicks
	if (m_info->version >= 1) {
		while (m_console->click()) {
			Click c = m_console->readClick();
			m_info->clicked((int) (c.x * m_width), (int) (c.y * m_height), 1);
		}
	}
      
	return (result == TRUE);
}


void SoniquePlugin::switchConsole(ClickConsole *newcc) {
	FunctionLogger flog("void SoniquePlugin::switchConsole(ClickConsole *)", Logger::synfunc);
	m_console = newcc;
}