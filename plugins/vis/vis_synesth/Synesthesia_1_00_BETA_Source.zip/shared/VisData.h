#ifndef VISDATA_HEADER_INCLUDED
#define VISDATA_HEADER_INCLUDED


class VisData {
public:
	unsigned char *waveform[2];   // [576]
	unsigned char *spectrum[2];   // [576]
};


#endif	// VISDATA_HEADER_INCLUDED