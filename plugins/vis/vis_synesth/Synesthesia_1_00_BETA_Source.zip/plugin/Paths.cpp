#include "windows.h"
#include "MyString.h"
#include "Paths.h"


string getMainDir() {
	return getWinampDir() + "Plugins\\";
}


string getIniFile() {
	return getMainDir() + "synesth.ini";
}


string getOtherIniFile() {
	return getMainDir() + "synesth_distr.ini";
}


string getWinampDir() {
	char buf[FILENAME_MAX];
	GetModuleFileName(GetModuleHandle(0), buf, FILENAME_MAX);
	string md(buf);
	return string(md, 0, md.rfind('\\') + 1);
}
