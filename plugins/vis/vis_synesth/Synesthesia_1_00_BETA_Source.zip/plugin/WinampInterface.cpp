#include "afxwin.h"
#include "ClickConsole.h"
#include "Logger.h"
#include "Paths.h"
#include "Settings.h"
#include "SoniquePlugin.h"
#include "Utility.h"
#include "WinampInterface.h"


const char VisName[] = "Synesthesia v1.00 beta";


Settings &getSettings() {
	static Settings s;
	return s;
}


vector<ClickConsole *> pccs;
vector<SoniquePlugin *> psps;


void configure(WinampVisModule *thismod) {
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	FunctionLogger flog("configure(WinampVisModule *thismod)", Logger::winfunc);

	try {
		// you're not meant to use WinExec these days - CreateProcess is the modern
		//	way to do it, but it's sooooo complicated that i can't be bothered.
		WinExec((getWinampDir() + "synconfig.exe").c_str(), SW_SHOW);
	}
	catch (SynException &ex) {
		Log(ex);
		MessageBox(thismod->HWndParent, ex.describe().c_str(), "Synesthesia Error", MB_OK);
	}
	catch (Error &err) {
		Log(err.message());
		MessageBox(thismod->HWndParent, err.message(), "Synesthesia Error", MB_OK);
	}
}


SoniquePlugin *startPlugin(PluginIdent p, ClickConsole *cc) {
	FunctionLogger flog("startPlugin(PluginIdent, ClickConsole *)", Logger::winfunc);

	Log("Getting current directory");
	char buf[FILENAME_MAX];
	GetCurrentDirectory(FILENAME_MAX, buf);

	Log("Setting current directory to plugin directory");
	SetCurrentDirectory(separate(p.Filename).first.c_str());

	Log("Getting settings object");
	Settings& s = getSettings();

	Log("Starting Sonique plugin: " + p.DisplayName);
	SoniquePlugin *sp = new SoniquePlugin(p, s.getVisIni(), cc, s.getEffectsForPlugin(p));

	Log("Setting current directory back");
	SetCurrentDirectory(buf);

	Log("Setting title for plugin's window");
	cc->setTitle("Synesthesia: " + p.DisplayName);

	return sp;
}


int initialise(WinampVisModule *thismod) {
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	FunctionLogger flog("initialise(WinampVisModule *thismod)", Logger::winfunc);

	try {
		Log("Getting settings");
		Settings &s = getSettings();
		Log("Reinitialising settings");
		s.reinitialise();

		Log("Checking settings details");
		if (s.getSelPlugins().size() == 0) {
			Log("No plugins are selected", Logger::fatal);
			MessageBox(thismod->HWndParent, "No plugins are selected", "Synesthesia Error", MB_OK);
			configure(thismod);
			return 1;
		}

		if (s.getVisIni() == "" || !exists(s.getVisIni())) {
			Log("No vis.ini is configured", Logger::fatal);
			MessageBox(thismod->HWndParent, "No vis.ini is configured", "Synesthesia Error", MB_OK);
			configure(thismod);
			return 1;
		}

		if (!s.isSelDispMode()) {
			Log("No display mode is selected", Logger::fatal);
			MessageBox(thismod->HWndParent, "No display mode is selected", "Synesthesia Error", MB_OK);
			configure(thismod);
			return 1;
		}

		// Start all of the plugins
		Log("Starting plugins");
		for (int i = 0; i < s.getSelPlugins().size(); ++i) {
			const PluginIdent& pi = s.getSelPlugins()[i];

			if (exists(pi.Filename)) {
				Log("Starting " + s.getSelPlugins()[i].DisplayName);
				ClickConsole *cc = new ClickConsole(thismod->HDllInstance, thismod->HWndParent, s.getSelDispMode(), s.isFullscreen());
				SoniquePlugin *sp = startPlugin(pi, cc);
				pccs.push_back(cc);
				psps.push_back(sp);
				if (s.isFullscreen()) break;	// we can only do one plugin in fullscreen mode
			}
			else {
				MessageBox(thismod->HWndParent, ("Plugin " + pi.Filename + " doesn't exist").c_str(), "Synesthesia Error", MB_OK);
			}
		}
	}
	catch (SynException& ex) {
		Log(ex);
		MessageBox(thismod->HWndParent, ex.describe().c_str(), "Synesthesia Error", MB_OK);
		return 1;
	}
	catch (Error &err) {
		Log(err.message());
		MessageBox(thismod->HWndParent, err.message(), "Synesthesia Error", MB_OK);
		return 1;
	}

	if (psps.size() > 0) return 0;
	else return 1;					// possibly no plugins were initialised
}


int render(WinampVisModule *thismod) {
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	static VisData vd;

	try {
		// Go through each plugin
		for (int num = 0; num < psps.size(); ++num) {

			// If the console is closed, stop render
			if (pccs[num]->isClosed()) return 1;

			// Do the render
			vd.waveform[0] = thismod->Waveform[0];
			vd.waveform[1] = thismod->Waveform[1];
			vd.spectrum[0] = thismod->Spectrum[0];
			vd.spectrum[1] = thismod->Spectrum[1];
			psps[num]->render(vd);

			// Check for button presses
			if (pccs[num]->key()) {
				Key k = pccs[num]->read();
				Settings& s = getSettings();

				switch (k.code()) {
					case Key::DOWN: {
						delete psps[num];
						psps[num] = startPlugin(s.selNextPlugin(num), pccs[num]);
						s.save();
						break;
					}

					case Key::UP: {
						delete psps[num];
						psps[num] = startPlugin(s.selPrevPlugin(num), pccs[num]);
						s.save();
						break;
					}
				}
			}

		}
	}
	catch (SynException& ex) {
		Log(ex);
		MessageBox(thismod->HWndParent, ex.describe().c_str(), "Synesthesia Error", MB_OK);
		return 1;
	}
	catch (Error &err) {
		Log(err.message());
		MessageBox(thismod->HWndParent, err.message(), "Synesthesia Error", MB_OK);
		return 1;
	}

	return 0;
}


void quit(WinampVisModule *thismod) {
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	FunctionLogger flog("quit(WinampVisModule *thismod)", Logger::winfunc);

	try {
		for (int i = 0; i < psps.size(); ++i) {
			delete pccs[i];
			delete psps[i];
		}
	}
	catch (SynException& ex) {
		Log(ex);
		MessageBox(thismod->HWndParent, ex.describe().c_str(), "Synesthesia Error", MB_OK);
	}
	catch (Error &err) {
		Log(err.message());
		MessageBox(thismod->HWndParent, err.message(), "Synesthesia Error", MB_OK);
	}
}


WinampVisModule *getModule(int which) {
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	FunctionLogger flog("getModule(int)", Logger::winfunc);

	if (which != 0) return 0;

	static WinampVisModule wvm;
	memset(&wvm, 0, sizeof(WinampVisModule));
	wvm.Description = VisName;
	wvm.Latency = 50;
	wvm.Delay = 10;
	wvm.SpecNumChannels = 2;
	wvm.WaveNumChannels = 2;
	wvm.config = configure;
	wvm.init = initialise;
	wvm.render = render;
	wvm.quit = quit;

	return &wvm;
}


extern "C" __declspec(dllexport) WinampVisHeader *winampVisGetHeader() {
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	FunctionLogger flog("winampVisGetHeader()", Logger::winfunc);

	static WinampVisHeader hdr = { 
		VIS_HDRVER, 
		VisName, 
		getModule 
	};
	
	return &hdr;
}


