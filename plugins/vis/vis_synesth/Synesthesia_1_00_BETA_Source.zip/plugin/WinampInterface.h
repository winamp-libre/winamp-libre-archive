#ifndef WINAMP_INTERFACE_HEADER_INCLUDED
#define WINAMP_INTERFACE_HEADER_INCLUDED


#include "windows.h"


struct WinampVisModule {
	const char *Description;
	HWND HWndParent;
	HINSTANCE HDllInstance;
	int SampleRate;
	int NumChannels;
	int Latency;
	int Delay;

	int SpecNumChannels;
	int WaveNumChannels;
	unsigned char Spectrum[2][576];
	unsigned char Waveform[2][576];

	void (*config)(WinampVisModule *this_mod);
	int (*init)(WinampVisModule *this_mod);
	int (*render)(WinampVisModule *this_mod);
	void (*quit)(WinampVisModule *this_mod);

	void *UserData;
};


struct WinampVisHeader {
	int Version;
	const char *Description;
	WinampVisModule* (*getModule)(int which);
};


typedef WinampVisHeader* (*winampVisGetHeaderType)();


#define VIS_HDRVER 0x101


#endif	// WINAMP_INTERFACE_HEADER_INCLUDED
