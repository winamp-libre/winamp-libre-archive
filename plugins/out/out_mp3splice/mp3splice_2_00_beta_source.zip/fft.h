void fft(COMPLEX *a, DWORD n);
void ifft(COMPLEX *a, DWORD n);
