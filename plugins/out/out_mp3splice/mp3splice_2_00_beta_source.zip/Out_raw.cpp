#include <windows.h>
//#include <shlwapi.h>
//#include <shlobj.h>
#include <math.h>
#include <crtdbg.h>
#include "Datatypes.h"
#include "fft.h"
#include "out.h"
//#include "resource.h"
#include "config.h"
#include "Splice.h"
#include "Waveout.h"
#include "Fileout.h"



#define PI_VER "v1.0 (x86)"


int getwrittentime();
int canwrite();

//const bool do_splice=false;

Out_Module out;


HINSTANCE hApplicationInstance = NULL;

COut* curout;



void about(HWND hwnd)
{
    MessageBox(hwnd,"Open source\n"
                    "MP3-splice output plugin\n"
                    "version 2.00 BETA\n"
                    "Compiled on " __DATE__ "\n","About",MB_OK);
}

void init()
{
    _RPT0(_CRT_WARN,"init ");

}

void quit()                            
{
    _RPT0(_CRT_WARN,"quit ");
    
    config.quit();

    if (curout)
    {
        delete curout;
        curout= NULL;
    }
}



int open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms)
{
    _RPT0(_CRT_WARN,"open ");


    if (curout && config.changed)
    {
        delete curout;
        curout= NULL;
    }

    if (!curout)
    {
        if (config.outtype==2)
        {
            curout= NewFileout();
        }
        else
        {
            curout= NewWaveout();
        }
        config.changed = false;

    }


    WAVEFORMATEX wfex;

    wfex.wFormatTag= WAVE_FORMAT_PCM;
    wfex.nChannels= numchannels;
    wfex.nSamplesPerSec= samplerate;
    wfex.nBlockAlign= numchannels* ((bitspersamp==16)?2:1);    //------------------ WORK TODO
    wfex.wBitsPerSample= bitspersamp;
    wfex.nAvgBytesPerSec= wfex.nBlockAlign*samplerate;
    wfex.cbSize=0;

    int r=curout->open(&wfex);

    if (r == -1)
    {
        delete curout;
        curout= NULL;
    }

    return r;

}



void close()
{
    _RPT0(_CRT_WARN,"close ");
    if (curout)
    {
        if (!curout->close())
        {
            delete curout;
            curout= NULL;
        }
    }
}


int write(char *buf, int len)
{
    if (curout) return curout->write(buf, len);
    else return 1;
}

int canwrite()
{
    if (curout) return curout->canwrite();
    else return 0;
}

int isplaying()
{
    if (curout) curout->AllSent();
    return 0;
}

int pause(int pause)                     
{
    _RPT0(_CRT_WARN,"pause ");

    if (curout) return curout->pause(pause);
    else return 0;
}

void setvolume(int volume)         
{
    _RPT1(_CRT_WARN, "vol(%d)", volume);
    if (volume<0 || volume>255) return;  // why? -666 default ?
    if (curout) curout->setvolume(volume);
}

void setpan(int pan)
{
    if (curout) curout->setpan(pan);
}

void flush(int t)
{
    _RPT0(_CRT_WARN,"flush ");
    if (curout) curout->flush(t);
}
    
int getwrittentime()
{
    if (curout) return curout->getwrittentime();
    else return 0;
}

int getoutputtime()
{
    if (curout) return curout->getoutputtime();
    else return 0;
}


BOOL WINAPI DllMain(
    HINSTANCE hinstDLL,  // handle to DLL module
    DWORD fdwReason,     // reason for calling function
    LPVOID lpReserved )  // reserved
{
    // Perform actions based on the reason for calling.
    switch( fdwReason ) 
    { 
        case DLL_PROCESS_ATTACH:
            _RPT0(_CRT_WARN,"\nDLL_PROCESS_ATTACH ");

            hApplicationInstance = hinstDLL;
            // Initialize once for each new process.
         // Return FALSE to fail DLL load.
            break;

        case DLL_THREAD_ATTACH:
            _RPT0(_CRT_WARN,"\nDLL_THREAD_ATTACH ");
         // Do thread-specific initialization.
            break;

        case DLL_THREAD_DETACH:
            _RPT0(_CRT_WARN,"\nDLL_THREAD_DETACH ");
         // Do thread-specific cleanup.
            break;

        case DLL_PROCESS_DETACH:
            _RPT0(_CRT_WARN,"\nDLL_PROCESS_DETACH ");
         // Perform any necessary cleanup.
            break;
    }
    return TRUE;  // Successful DLL_PROCESS_ATTACH.
}


void show_config(HWND hwnd)
{
    config.show(hwnd);
}



extern "C" __declspec( dllexport ) Out_Module* winampGetOutModule()
{
    _RPT0(_CRT_WARN,"winampGetOutModule ");

    out.version= OUT_VER;
    out.description= "Pyramide Data, MP3-Splice";
    out.id=35515944; //TODO: change
    out.Config= show_config;
    out.About= about;
    out.Init= init;
    out.Quit= quit;
    out.Open= open;
    out.Close= close;
    out.Write= write;
    out.CanWrite= canwrite;
    out.IsPlaying= isplaying;
    out.Pause= pause;
    out.SetVolume= setvolume;
    out.SetPan= setpan;
    out.Flush= flush;
    out.GetOutputTime= getoutputtime;
    out.GetWrittenTime= getwrittentime;

    return &out;
}

