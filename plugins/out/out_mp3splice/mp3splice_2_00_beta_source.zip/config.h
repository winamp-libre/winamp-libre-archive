
class CConfig
{
private:
    void PassWaveouts(bool fillcombo);
    HWND hdialog;
    HKEY RegKey(bool close=false);
public:
    BOOL DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

    UINT waveout_id;
    char waveout_name[MAXPNAMELEN];
    DWORD outtype;

    bool changed;

    void quit();
    void show(HWND hwnd);
    CConfig();
    ~CConfig();
};


extern CConfig config;

