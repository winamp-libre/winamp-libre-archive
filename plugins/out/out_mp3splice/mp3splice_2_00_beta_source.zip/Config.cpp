#include <windows.h>
#include <shlwapi.h>
#include <shlobj.h>

#include "resource.h"
#include "Config.h"

extern HINSTANCE hApplicationInstance;

CConfig config;


CConfig::CConfig()
{
    {
        DWORD tp;
        DWORD l=sizeof(waveout_name);
        if (ERROR_SUCCESS!=RegQueryValueEx(RegKey(), "Waveout", 0, &tp, (LPBYTE)waveout_name, &l))
        {
            waveout_name[0]=0;
        }
        if (tp!=REG_SZ) waveout_name[0]=0;
    }

    PassWaveouts(false);

    {
        DWORD v=1;
        DWORD tp;
        DWORD l=sizeof(DWORD);
        RegQueryValueEx(RegKey(), "Outtype", 0, &tp, (LPBYTE)&v, &l);
        if (v<1 || v>3) v=1;
        outtype=v;
    }

    RegKey(true);
    changed = true;
}


CConfig::~CConfig()
{
}


HKEY CConfig::RegKey(bool close)
{
    static HKEY key=NULL;

    if (close)
    {
        if (key) RegCloseKey(key);
        key=NULL;
    }
    else
    {
        if (key==NULL)
        {
            if (ERROR_SUCCESS!=RegCreateKeyEx(HKEY_CURRENT_USER,"Software\\Winamp\\Open Source MP3Splice",0, NULL,
                   REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL,
                   &key, NULL))
            {
                key = NULL;
            }
            
        }
    }
    return key;
}






void CConfig::PassWaveouts(bool fillcombo)
{

    WAVEOUTCAPS woc;

    
    UINT numdevices= waveOutGetNumDevs();
    UINT n=WAVE_MAPPER;
    UINT new_id=WAVE_MAPPER;
    do
    {
        if (waveOutGetDevCaps(n, &woc, sizeof(WAVEOUTCAPS))==MMSYSERR_NOERROR)
        {
            int p=CB_ERR;
            if (fillcombo)
            {
                p=SendDlgItemMessage(hdialog, IDC_WAVEOUTCOMBO, CB_ADDSTRING, 0, (LPARAM)woc.szPname );
            }

            if (strcmp(woc.szPname, waveout_name)==0)
            {
                new_id = n;
                if (fillcombo) SendDlgItemMessage(hdialog, IDC_WAVEOUTCOMBO, CB_SETCURSEL, p, 0 );
            }
        }

        if (n==WAVE_MAPPER) n=0;
        else n++;
    } while (n<numdevices);
    waveout_id = new_id;
}


int CALLBACK BrowseCallbackProc(HWND hwnd,
        UINT uMsg, LPARAM lParam, LPARAM lpData)
{
    switch (uMsg) {
        case BFFM_INITIALIZED:
            /* change the selected folder. */
            SendMessage(hwnd, BFFM_SETSELECTION, TRUE, lpData);
            break;
        case BFFM_SELCHANGED:
            break;
        default:
            break;
    }
    return(0);
}

BOOL CALLBACK ConfigDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    return config.DialogProc(hwndDlg, uMsg, wParam, lParam);
}

    
BOOL CConfig::DialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch(uMsg)
    {
    case WM_INITDIALOG:
        config.hdialog= hwndDlg;
        PassWaveouts(true);

        {
            DWORD lst[3]={IDC_OUTTYPE1, IDC_OUTTYPE2, IDC_OUTTYPE3};
            CheckRadioButton(hdialog, IDC_OUTTYPE1, IDC_OUTTYPE3, lst[outtype-1]);
        }

        return TRUE;


    case WM_DESTROY:
        RegKey(true);
        config.hdialog= NULL;
        return TRUE;

    case WM_CLOSE:
        PostMessage(hwndDlg, WM_COMMAND, IDCANCEL, 0L);
        return TRUE;
   
    case WM_COMMAND:
        {
            switch(LOWORD(wParam))
            {
            case IDCLOSE:
            case IDOK:
            case IDCANCEL: EndDialog(hwndDlg, FALSE); return TRUE;

            case IDC_BROWSE:
                {
                    TCHAR displayname[MAX_PATH];
                    TCHAR path[MAX_PATH];
                    GetDlgItemText(hwndDlg, IDC_OUTPUTDIR, path, MAX_PATH);

                    BROWSEINFO bi = { hwndDlg, NULL, displayname, "Write wave-files to:",
                        BIF_RETURNONLYFSDIRS|0x0040,//BIF_NEWDIALOGSTYLE
                        (BFFCALLBACK)BrowseCallbackProc, (long)path, 0};


                    LPITEMIDLIST pidl = SHBrowseForFolder ( &bi );
                    if ( pidl != 0 )
                    {
                        // get the name of the folder
                        if ( SHGetPathFromIDList ( pidl, path ) )
                        {
                            SetDlgItemText(hwndDlg, IDC_OUTPUTDIR, path);
                        }

                        // free memory used
                        IMalloc * imalloc = 0;
                        if ( SUCCEEDED( SHGetMalloc ( &imalloc )) )
                        {
                            imalloc->Free ( pidl );
                            imalloc->Release ( );
                        }
                    }
                }

                return TRUE;

            case IDC_OUTTYPE1:
                outtype=1;
                RegSetValueEx(RegKey(), "Outtype", 0, REG_DWORD , (BYTE*)&outtype, sizeof(DWORD));
                changed = true;
                return TRUE;

            case IDC_OUTTYPE2:
                outtype=2;
                RegSetValueEx(RegKey(), "Outtype", 0, REG_DWORD , (BYTE*)&outtype, sizeof(DWORD));
                changed = true;
                return TRUE;

            case IDC_OUTTYPE3:
                outtype=3;
                RegSetValueEx(RegKey(), "Outtype", 0, REG_DWORD , (BYTE*)&outtype, sizeof(DWORD));
                changed = true;
                return TRUE;

            case IDC_WAVEOUTCOMBO:
                if (HIWORD(wParam)==CBN_SELCHANGE)
                {
                    int sel= SendDlgItemMessage(hdialog, IDC_WAVEOUTCOMBO, CB_GETCURSEL, 0, 0);
                    SendDlgItemMessage(hdialog, IDC_WAVEOUTCOMBO, CB_GETLBTEXT, sel, (LPARAM)waveout_name);
                    PassWaveouts(false);
    
                    RegSetValueEx(RegKey(),
                                  "Waveout",
                                  0,
                                  REG_SZ ,
                                  (BYTE*)waveout_name,
                                  strlen(waveout_name)+1);

                    changed = true;
                    return TRUE;
                }
                return FALSE;



            default:    
            return FALSE;
            }

/*
            case WM_TIMER:
                //obj->OnTimer();
                return TRUE;
*/          
        }
        return FALSE;
    default:
        return FALSE;
    }
}

void CConfig::quit()
{
    while (hdialog)
    {
        PostMessage(hdialog, WM_COMMAND, IDCANCEL, 0L);
        Sleep(100);
    }
}

void CConfig::show(HWND hwnd)
{
    DialogBox(hApplicationInstance , MAKEINTRESOURCE(IDD_DIALOG1), hwnd, &ConfigDialogProc);
}
