typedef struct { double r; double i; } COMPLEX;

