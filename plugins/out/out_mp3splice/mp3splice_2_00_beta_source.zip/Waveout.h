COut* NewWaveout();

