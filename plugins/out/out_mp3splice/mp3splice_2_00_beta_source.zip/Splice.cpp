#include <windows.h>
#include <math.h>
#include <crtdbg.h>

#include "Datatypes.h"
#include "fft.h"
#include "Splice.h"


COut::COut()
{
    last_pause=false;
    file_open=false;
    flushnow=false;
    playrest=false;
    mix_on=false;

    buffermutex=CreateMutex(NULL, FALSE, NULL);

    buf_free=0;
    buf_playing=0;
    buf_filled=0;
    buf_fileseperator=-1;
    buf_thissong=-1;
    message[0]=0;
}

COut::~COut()
{
    CloseHandle(buffermutex);
}


bool COut::CheckMessage()
{
    if (message[0])
    {
        MessageBox(NULL,message,"Error detected by MP3Splice",MB_OK|MB_ICONSTOP|MB_TASKMODAL);
        return true;
    }
    else return false;
}


void COut::SetMessage(LPCSTR str)
{
    strcpy(message, str);
}

void COut::SetDllErrorMessage()
{
    LPVOID lpMsgBuf;
    FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
            NULL,
            GetLastError(),
            MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
            (LPTSTR) &lpMsgBuf, 0,  NULL );
    strncpy(message, (LPCTSTR)lpMsgBuf, 256 );
    LocalFree( lpMsgBuf );
}

int COut::searchbuf(short* buf, int max, int step)
{
    int i;
    short* ptr=buf;
    int toremove=0;


    //---- find first side effect ----

    short* ptr1=ptr;
    int filter1=0;
    int filter2=0;
    for (i=0; i<max-SPLICE_SIDEEFFEKT; i++)
    {
        filter1=filter1/4+(ptr1[0]<<4);
        filter2=filter2/4+(ptr1[1]<<4);
        if (filter1>64 || filter1<-64 || filter2>64 || filter2<-64)
        {
            max=i+SPLICE_SIDEEFFEKT;
            break;
        }
        ptr1+=step;
    }

    //---- find max -------------

    int maxval=0;
    ptr1=ptr;

    for (i=0; i<max; i++)
    {
        maxval= __max(maxval, __max(abs(ptr1[0]), abs(ptr1[1])));
        ptr1+=step;
    }
    if (maxval==0) return 0;

    // ---- find jump ------------
    
    int hold0=1+maxval/10;
    int hold1=hold0;
    int jumpmax=0;
    int jump;
    int this3;
    
    int minlim=1+maxval/100;
    int maxlim=maxval/3;

    for (i=toremove; i<max-3; i++)
    {
        hold0=__max(hold0, abs(ptr[0]));
        hold1=__max(hold1, abs(ptr[1]));

        this3= abs(ptr[3*step+0]);
        if (this3>hold0 && this3>=minlim && hold0<maxlim)
        {
            jump= (this3<<8)/(hold0+10);
            if (jump>jumpmax) { jumpmax=jump; toremove=i+3; }
        }

        this3= abs(ptr[3*step+1]);
        if (this3>hold1 && this3>=minlim && hold1<maxlim)
        {
            jump= (this3<<8)/hold1;
            if (jump>jumpmax) { jumpmax=jump; toremove=i+3; }
        }

        ptr+=step;
    }

    _RPT1(_CRT_WARN,"maxsearch(%d)", max);

    return toremove;
}




#define PI 3.14159265359


// src points to 16bit buffer where it shall start
// dest r get the value, i is set to 0
// halfwin must be true if it should be sqrt sin = half window
void COut::GetFromBufferWindow(short* src,  COMPLEX* dest, bool halfwin, DWORD totlen, DWORD winlen)
{
    double dv, v;
    dv= PI / (winlen+1);
    v= dv;
    for (DWORD w=0; w<totlen; w++)
    {
        if (w<=winlen || w>=totlen-winlen)
        {
            if (halfwin) dest->r = sqrt(0.5 - 0.5*cos(v)) * *src;
            else         dest->r = (0.5 - 0.5*cos(v))     * *src;

            v+=dv;
        }
        else
        {
            dest->r = *src;
        }
        dest->i=0;

        src+=2;
        dest++;
    }
}

void COut::MixBack(short* dest, COMPLEX* src, DWORD totlen, DWORD winlen)
{
    double dv, v, val, c;
    dv= PI / (winlen+1);
    v= dv;
    for (DWORD w=0; w<totlen; w++)
    {
        if (w<=winlen || w>=totlen-winlen)
        {
            c= 0.5 - 0.5*cos(v);
            v+=dv;

            val = sqrt(c) * src->r + (1-c)* *dest;
        }
        else
        {
            val = src->r;
        }

        if (val>32767.0) val=32767.0;       // range check
        if (val<-32768.0) val=-32768.0;
        *dest= (short)floor(val+0.5);       // round

        dest+=2;
        src++;
    }
}



#define POWER(c) (c.i*c.i+c.r*c.r)


void COut::Reduce(COMPLEX* fftbuf, double* pwrtab, DWORD size)
{
    fftbuf[size/2].r=0;
    fftbuf[size/2].i=0;

    DWORD w;
    double d;

    for (w=0; w<size/2; w++)
    {
        d= POWER(fftbuf[w]);
        if (d>pwrtab[w])
        {
            d=(sqrt(pwrtab[w]/d));
            fftbuf[w].r *= d;
            fftbuf[w].i *= d;
            if (w!=0)
            {
                fftbuf[size-w].r *= d;
                fftbuf[size-w].i *= d;
            }
        }
    }
}



void COut::DeClick(short* data)
{
    COMPLEX fftbuf[FFT_SIZE];
    double pwrtab[FFT_SIZE/2];

    COMPLEX fftbufs[FFT_SIZE_S];
    double pwrtabs[FFT_SIZE_S/2];


    DWORD w;

    GetFromBufferWindow(data-2*(FFT_SIZE+SPLICE_HALFGAP), fftbuf, false, FFT_SIZE, WINLEN);     // Left
    fft(fftbuf, FFT_SIZE);
    for (w=0; w<FFT_SIZE/2; w++) pwrtab[w]=POWER(fftbuf[w]);

    GetFromBufferWindow(data+2*SPLICE_HALFGAP, fftbuf, false, FFT_SIZE, WINLEN);                // Right
    fft(fftbuf, FFT_SIZE);
    for (w=0; w<FFT_SIZE/2; w++) pwrtab[w]=__max(pwrtab[w], POWER(fftbuf[w]));




    GetFromBufferWindow(data-2*(FFT_SIZE_S+SPLICE_HALFGAP), fftbufs, false, FFT_SIZE_S, WINLEN_S);     // Left
    fft(fftbufs, FFT_SIZE_S);
    for (w=0; w<FFT_SIZE_S/2; w++) pwrtabs[w]=POWER(fftbufs[w]);

    GetFromBufferWindow(data+2*SPLICE_HALFGAP, fftbufs, false, FFT_SIZE_S, WINLEN_S);                // Right
    fft(fftbufs, FFT_SIZE_S);
    for (w=0; w<FFT_SIZE_S/2; w++) pwrtabs[w]=__max(pwrtabs[w], POWER(fftbufs[w]));

    GetFromBufferWindow(data-FFT_SIZE_S-2*SPLICE_HALFGAP, fftbufs, true, FFT_SIZE_S, WINLEN_S);        // Middle
    fft(fftbufs, FFT_SIZE_S);

    Reduce(fftbufs, pwrtabs, FFT_SIZE_S);

    ifft(fftbufs, FFT_SIZE_S);
    MixBack(data-FFT_SIZE_S-2*SPLICE_HALFGAP, fftbufs, FFT_SIZE_S, WINLEN_S);





    GetFromBufferWindow(data-FFT_SIZE-2*SPLICE_HALFGAP, fftbuf, true, FFT_SIZE, WINLEN);        // Middle
    fft(fftbuf, FFT_SIZE);

    Reduce(fftbuf, pwrtab, FFT_SIZE);

    ifft(fftbuf, FFT_SIZE);
    MixBack(data-FFT_SIZE-2*SPLICE_HALFGAP, fftbuf, FFT_SIZE, WINLEN);
}




void COut::mixnow()
{
    int oldsonglen= buf_thissong - buf_filled; if (oldsonglen<0) oldsonglen+=lenringbuffer;
    int newsonglen= buf_free - buf_thissong;   if (newsonglen<0) newsonglen+=lenringbuffer;
    int totsonglen= buf_free - buf_filled;     if (totsonglen<0) totsonglen+=lenringbuffer;

    if (oldsonglen+newsonglen != totsonglen )                        { _RPT0(_CRT_WARN,"\nNOMIX-1 "); return; }
    if (oldsonglen<4*(SPLICE_SEARCH_OLD+FFT_SIZE+SPLICE_HALFGAP))    { _RPT0(_CRT_WARN,"\nNOMIX-2 "); return; }
    if (newsonglen<4*(SPLICE_SEARCH_NEW+FFT_SIZE+SPLICE_HALFGAP))    { _RPT0(_CRT_WARN,"\nNOMIX-3 "); return; }
    
    int workstart=buf_thissong-4*(SPLICE_SEARCH_OLD+FFT_SIZE+SPLICE_HALFGAP);
    if (workstart<0) workstart+=lenringbuffer;

    
    int wrapfix;
    if (workstart+4*WORKLEN>=lenringbuffer) wrapfix=4*WORKLEN-(lenringbuffer-workstart); else wrapfix=0;

    if (wrapfix)
    {
        memcpy(ringbuffer+lenringbuffer, ringbuffer, wrapfix);
        if (buf_thissong<wrapfix) buf_thissong+=lenringbuffer;
        if (buf_free<wrapfix) buf_free+=lenringbuffer;
        _RPT0(_CRT_WARN,"\nWRAPFIX ");
    }

    int rem_old=searchbuf((short*)(ringbuffer+buf_thissong-4), SPLICE_SEARCH_OLD, -2);
    int rem_new=searchbuf((short*)(ringbuffer+buf_thissong), SPLICE_SEARCH_NEW, 2);
    _RPT2(_CRT_WARN,"\n old %d, new %d ", rem_old, rem_new);

    if (rem_old+rem_new!=0)
    {
        int dest= buf_thissong-4*rem_old;
        int src= dest + 4*(rem_old + rem_new); if (src>=lenringbuffer+wrapfix) src-=lenringbuffer;
        int len;
        while (len= buf_free - src)
        {
            if (len<0) len+=lenringbuffer;
            len = __min(len, lenringbuffer+wrapfix-dest);
            len = __min(len, lenringbuffer+wrapfix-src);
            memmove(ringbuffer+dest, ringbuffer+src, len);
            dest+=len; if (dest>=lenringbuffer+wrapfix) dest-=lenringbuffer;
            src+=len;  if (src>=lenringbuffer+wrapfix) src-=lenringbuffer;
        }
        
        buf_thissong-=4*rem_old;
        buf_free-= 4*(rem_old + rem_new);          
        if (buf_free<0) buf_free+=lenringbuffer;
    }
        
    DeClick((short*)(ringbuffer+buf_thissong));
    DeClick((short*)(ringbuffer+buf_thissong)+1);

    _RPT0(_CRT_WARN,"\nMIX-OK ");

    if (wrapfix)
    {
        memcpy(ringbuffer, ringbuffer+lenringbuffer, wrapfix);
        if (buf_thissong>=lenringbuffer) buf_thissong-=lenringbuffer;
        if (buf_free>=lenringbuffer) buf_free-=lenringbuffer;
    }
}


int COut::write(char *buf, int len)
{
    if (len>canwrite()) return 1; //No room in buffer
    if (len==0) return 0;

    WaitForSingleObject(buffermutex, INFINITE);
    _RPT0(_CRT_WARN,"+");

                                                        //update written millisec
    write_over+=len*1000;
    int this_ms=write_over/wfex.nAvgBytesPerSec;
    write_over-=this_ms*wfex.nAvgBytesPerSec;
    write_ms+=this_ms;
    




    if (buf_free+len>lenringbuffer)
    {
        int first=lenringbuffer-buf_free;
        memcpy(ringbuffer+buf_free, buf, first);
        memcpy(ringbuffer, buf+first, len-first);
    }
    else
    {
        memcpy(ringbuffer+buf_free, buf, len);
    }

    buf_free+=len; if (buf_free>=lenringbuffer) buf_free-=lenringbuffer;


    if (mix_on && buf_thissong!=-1)
    {
        int nthisfile= buf_free - buf_thissong;
        if (nthisfile<0) nthisfile+=lenringbuffer;

        if (nthisfile>=4*(SPLICE_SEARCH_NEW +FFT_SIZE+SPLICE_HALFGAP))
        {
            buf_fileseperator= buf_thissong;
            mixnow();

            buf_thissong=-1;   // we don't want to do this again
            mix_on=false;

        }
    }
    


    int filled=(buf_free - buf_playing);
    if (filled<0) filled+=lenringbuffer;
    if (filled*2>lenringbuffer) this_ms= this_ms*(2*filled-lenringbuffer)/lenringbuffer;
    else this_ms=0;


    ReleaseMutex(buffermutex);

    work();

    Sleep(this_ms);
    //_RPT1(_CRT_WARN,"Sleep(%d)", this_ms);

    return 0;
}

int COut::canwrite()
{
    WaitForSingleObject(buffermutex, INFINITE);
    int n=(buf_playing - buf_free -1);
    ReleaseMutex(buffermutex);

    if (n<0) n+=lenringbuffer;
    return n;
}

int COut::getwrittentime()
{
    return write_ms;
}

int COut::getoutputtime()
{
    WaitForSingleObject(buffermutex, INFINITE);
    _ASSERT(file_open);
    int n=(buf_free - buf_playing);
    int ms=write_ms;
    int time= (int)timeGetTime() - lastfreetime_ms;
    ReleaseMutex(buffermutex);

    if (n<0) n+=lenringbuffer;
    n=(n*1000)/wfex.nAvgBytesPerSec;
    //n=5000;

    if (time<0 || time > BUFFERLENMS/2) time=0;
    if (last_pause) time=0;

    if (n<ms)
    {
//      _RPT0(_CRT_WARN,"!");
        return ms-n+time;
    }

    else
    {
//      _RPT0(_CRT_WARN,"�");
        return 0;
    }
}

bool COut::close()
{
    file_open= false;
    if (playrest)
    {
        if (wfex.nChannels==2 &&
            wfex.wBitsPerSample==16 &&
            wfex.nSamplesPerSec>=32000 &&
            wfex.nSamplesPerSec<=48000) mix_on=true;
    }
    else
    {
        flushnow=true;
        work();
        while (flushnow) wait_for_work();
    }
    buf_thissong= -1;

    return !CheckMessage();
}




void COut::AllSent()
{
    playrest=true;
}


int COut::pause(int pause)
{
    bool t=last_pause;
    last_pause= pause!=0 ;

    work();

    return t?1:0;
}

void COut::work()
{
    _ASSERT(FALSE);
}

void COut::wait_for_work()
{
    _ASSERT(FALSE);
}

int COut::open(WAVEFORMATEX *new_wfex)
{
    _ASSERT(FALSE);
    return -1;
}

void COut::setvolume(int volume)
{
    _ASSERT(FALSE);
}

void COut::setpan(int pan)
{
    _ASSERT(FALSE);
}

void COut::flush(int t)
{
    _ASSERT(FALSE);
}



