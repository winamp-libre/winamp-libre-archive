#include <windows.h>
#include <math.h>
#include "Datatypes.h"
#include "fft.h"

void fft(COMPLEX *a, DWORD n)
{
    COMPLEX u,w,t;
    DWORD k,le,le1,i,j,nv2,nm1;
    COMPLEX *ip;
    
    const double pi=3.14159265359;
    
    nv2= n/2;
    nm1= n-1;
    
    j=0;
    for (i=0; i<nm1; i++)
    {
        if (i<j)
        {
            t=a[j];
            a[j]=a[i];
            a[i]=t;
        }
        k=nv2;
        while (k<=j)
        {
            j-=k;
            k/=2;
        }
        j+=k;
    }
    
    for (le=2; le<=n; le<<=1)
    {
        le1=le>>1;
        u.r= 1;
        u.i= 0;
        w.r= cos(pi/le1);
        w.i= -sin(pi/le1);
        for (j=0; j<le1; j++)
        {
            for (i=j; i<n; i+=le)
            {
                ip=a+i+le1;
                
                t.r= ip->r * u.r - ip->i * u.i;
                t.i= ip->i * u.r + ip->r * u.i;
                ip->r = a[i].r - t.r;
                ip->i = a[i].i - t.i;
                a[i].r += t.r;
                a[i].i += t.i;
            }
            t=u;
            u.r= t.r*w.r-t.i*w.i;
            u.i= t.r*w.i+t.i*w.r;
        }
    }
}



void ifft(COMPLEX *a, DWORD n)
{
    COMPLEX u,w,t;
    DWORD k,le,le1,i,j,nv2,nm1;
    COMPLEX *ip;
    
    const double pi=3.14159265359;
    
    nv2= n/2;
    nm1= n-1;
    
    j=0;
    for (i=0; i<nm1; i++)
    {
        if (i<j)
        {
            t=a[j];
            a[j]=a[i];
            a[i]=t;
        }
        k=nv2;
        while (k<=j)
        {
            j-=k;
            k/=2;
        }
        j+=k;
    }
    
    for (le=2; le<=n; le<<=1)
    {
        le1=le>>1;
        u.r= 1;
        u.i= 0;
        w.r= cos(-pi/le1);
        w.i= -sin(-pi/le1);
        for (j=0; j<le1; j++)
        {
            for (i=j; i<n; i+=le)
            {
                ip=a+i+le1;
                
                t.r= ip->r * u.r - ip->i * u.i;
                t.i= ip->i * u.r + ip->r * u.i;
                ip->r = a[i].r - t.r;
                ip->i = a[i].i - t.i;
                a[i].r += t.r;
                a[i].i += t.i;
            }
            t=u;
            u.r= t.r*w.r-t.i*w.i;
            u.i= t.r*w.i+t.i*w.r;
        }
    }
    for (i=0; i<n; i++)
    {
        a[i].r/=n;
        a[i].i/=n;
    }
}


