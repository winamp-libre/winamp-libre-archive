extern int config_whichdevice;
extern unsigned char config_panrev;
extern unsigned char config_altvolset;
extern unsigned char config_iot,config_volumeenabled;
extern unsigned char config_priority;
