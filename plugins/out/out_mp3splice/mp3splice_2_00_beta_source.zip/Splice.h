#ifndef DEFINEGLOBALS
#define DEFINEGLOBALS extern
#endif

#define BUFFERLENMS 5000


#define SPLICE_SEARCH_NEW  4000  // in samples
#define SPLICE_SEARCH_OLD  4000
#define SPLICE_HALFGAP        8
#define SPLICE_SIDEEFFEKT  1024

#define FFT_SIZE           1024
#define WINLEN       FFT_SIZE/4

#define FFT_SIZE_S          128
#define WINLEN_S   FFT_SIZE_S/4     

#define WORKLEN (SPLICE_SEARCH_NEW+SPLICE_SEARCH_OLD+2*(SPLICE_HALFGAP+FFT_SIZE))



class COut
{
public:
    COut();
    virtual ~COut();

    char message[256];

    int lenringbuffer;    //length in bytes
    LPSTR ringbuffer;     //pointer for buffer

                          // offset in buffer (in bytes)

    int buf_free;     // buf_free -> buf_playing       free to be filled (if this range =0 all buffers are free)
    int buf_playing;  // buf_playing -> buf_filled     is currently in mmsystem 
    int buf_filled;   // buf_filled -> buf_free        filled but not handled to mmsystem yet

    int buf_thissong; // where current song started, -1 if invalid
    int buf_fileseperator; // where current song started, -1 if invalid

    HANDLE buffermutex;
    WAVEFORMATEX wfex;

    volatile int  write_ms, write_over, lastfreetime_ms;
    volatile bool last_pause;
    volatile bool file_open;
    volatile bool flushnow;
    volatile bool playrest;
    volatile bool mix_on;
    
    virtual int open(WAVEFORMATEX *new_wfex);
    bool close();
    void AllSent();
    int pause(int pause);
    void mixnow();
    int write(char *buf, int len);
    int canwrite();
    int getwrittentime();
    int getoutputtime();
    virtual void setvolume(int volume);
    virtual void setpan(int pan);
    virtual void flush(int t);
    virtual void work();
    virtual void wait_for_work();

    void SetMessage(LPCSTR str);
    void SetDllErrorMessage();

    bool CheckMessage();


private:
    void DeClick(short* data);
    void COut::Reduce(COMPLEX* fftbuf, double* pwrtab, DWORD size);
    void MixBack(short* dest, COMPLEX* src, DWORD totlen, DWORD winlen);
    void GetFromBufferWindow(short* src,  COMPLEX* dest, bool halfwin, DWORD totlen, DWORD winlen);
    int searchbuf(short* buf, int max, int step);

};



