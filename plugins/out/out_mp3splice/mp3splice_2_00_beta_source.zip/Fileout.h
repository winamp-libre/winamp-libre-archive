COut* NewFileout();

