#include <windows.h>
#include <crtdbg.h>
#include <process.h>


#include "Datatypes.h"
#include "Splice.h"
#include "Config.h"


static HANDLE wavetrigger;
static HANDLE maintrigger;


class CFileout:public COut
{
public:
    void fileouttread();
    CFileout();
private:
    HANDLE file;
    volatile bool tread_on;
    volatile bool willclose;

    void OpenCloseFile(bool opennew);

    virtual ~CFileout();

    virtual void setvolume(int volume);
    virtual void setpan(int pan);
    virtual void flush(int t);
    virtual int open(WAVEFORMATEX *new_wfex);
    virtual void work();
    virtual void wait_for_work();
};

#pragma pack(push, 1)

void CFileout::OpenCloseFile(bool opennew)
{
    static int namecount=0;
    DWORD nwritten;

    struct
    {
        char c1[4];
        DWORD len1;
        char c2[4];
        char c3[4];
        DWORD len2;
        WORD  wFormatTag; 
        WORD  nChannels; 
        DWORD nSamplesPerSec; 
        DWORD nAvgBytesPerSec; 
        WORD  nBlockAlign; 
        WORD  wBitsPerSample;
        char c4[4];
        DWORD len3;


    } header = {
                  'R','I','F','F',
                  0,
                  'W','A','V','E',
                  'f','m','t',' ',
                  16,
                  WAVE_FORMAT_PCM, 2, 44100, 4*44100, 4, 16 ,

                  'd','a','t','a',
                  0
                };

    ;
    
    if (file!=INVALID_HANDLE_VALUE)
    {
        DWORD fs=GetFileSize(file, NULL);
        SetFilePointer (file, 0, NULL, FILE_BEGIN) ; 
        header.len1=fs-8;
        header.len3=fs-sizeof(header);
        WriteFile(file, &header, sizeof(header), &nwritten, NULL);
        CloseHandle(file);
        file=INVALID_HANDLE_VALUE;
    }

    if (opennew)
    {
        namecount++;

        char name[]="d:\\mm_dl\\winampplugtest_A.wav";
        name[24]+=namecount;

        file= CreateFile(name, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        header.len1=sizeof(header)-8;
        header.len3=0;
        WriteFile(file, &header, sizeof(header), &nwritten, NULL);

    }
}

#pragma pack(pop)


CFileout::CFileout()
{
    _RPT0(_CRT_WARN,"CFileout ");

    file= INVALID_HANDLE_VALUE;
    wavetrigger=CreateEvent(NULL, FALSE, FALSE, NULL);
    maintrigger=CreateEvent(NULL, FALSE, FALSE, NULL);
    tread_on=false;
    willclose=false;
}

void CFileout::work()
{
    SetEvent(wavetrigger);
}

void CFileout::wait_for_work()
{
    WaitForSingleObject(maintrigger, 500);
}


CFileout::~CFileout()
{
    willclose=true;
    while (tread_on) WaitForSingleObject(maintrigger, 500);

    CloseHandle(wavetrigger);
    CloseHandle(maintrigger);
}


 


void waveouttread2(void* obj)
{
    ((CFileout*)obj)->fileouttread();
}


void CFileout::fileouttread()
{
    bool cur_pause=true;



    //SetThreadPriority()
    _RPT0(_CRT_WARN,"tread ");

    ringbuffer= new char[lenringbuffer+4*WORKLEN];
    if (ringbuffer==NULL) return;
    
    
    tread_on=true;
    SetEvent(maintrigger);

    OpenCloseFile(true);    

    int timer = 0;

    while(true)
    {
        WaitForSingleObject(buffermutex, INFINITE);


        /*
        buf_playing+=???;
        if (buf_playing>=lenringbuffer) buf_playing-=lenringbuffer;
            
            SetEvent(maintrigger);
            _RPT0(_CRT_WARN,"f");
        */

        flushnow=false;


        // write buffer to file
        while(true)
        {
            int ntowrite= buf_free - buf_filled;
            if (ntowrite<0) ntowrite+=lenringbuffer;


            if (file_open)
            {
                timer = 0; // reset timer
            }

            if (timer++ <= 10 && !willclose)
            {
                if (ntowrite<=4*WORKLEN) break;   // protect the mix zone
                ntowrite-=4*WORKLEN;

                if (ntowrite< lenringbuffer/16) break;      // don't write less than 1/16 buffer at a time
            }


            if (ntowrite==0) break;

            ntowrite= __min(ntowrite, lenringbuffer-buf_filled); //don't cross the end of the buffer


            if (buf_fileseperator != -1)
            {
                if (buf_filled<=buf_fileseperator && buf_fileseperator<buf_filled+ntowrite)
                {
                    ntowrite= buf_fileseperator-buf_filled;

                }


            }

            DWORD written;
            WriteFile(file, ringbuffer+buf_filled, ntowrite, &written, NULL);


            buf_filled+=ntowrite; if (buf_filled>=lenringbuffer) buf_filled-=lenringbuffer;

            if (buf_fileseperator == buf_filled)
            {
                _RPT0(_CRT_WARN,"(filechange)");
                OpenCloseFile(true);
                buf_fileseperator=-1;
            }


            buf_playing= buf_filled; // data is 'played' imidiately


            _RPT0(_CRT_WARN,"w");
        }

        if (buf_free==buf_playing) // all free = no data
        {
            if (!file_open)
            {
                OpenCloseFile(false);

                mix_on=false;
                SetEvent(maintrigger);

                delete ringbuffer;

                ReleaseMutex(buffermutex);
                tread_on=false;
                return;
            }
        }


        if (cur_pause!=last_pause)
        {
            if (last_pause)
            {
                cur_pause=true;
            }
            else
            {
                int n=(buf_free - buf_playing);
                if (n<0) n+=lenringbuffer;
                n=(n*1000)/wfex.nAvgBytesPerSec;

                if (n>BUFFERLENMS/4 || !file_open)
                {
                    cur_pause=false;
                }
            }
        }

        ReleaseMutex(buffermutex);


        WaitForSingleObject(wavetrigger, 500);
    }
}

void CFileout::setvolume(int volume)         
{
}

void CFileout::setpan(int pan)
{
}

void CFileout::flush(int t)
{
    _RPT0(_CRT_WARN,"flush ups! ");
    write_ms=t;
}



int CFileout::open(WAVEFORMATEX *new_wfex)
{
    WaitForSingleObject(buffermutex, INFINITE);

    while (buf_fileseperator!=-1)   // wait if previous change is not saved
    {
        ReleaseMutex(buffermutex);
        while(buf_fileseperator!=-1) WaitForSingleObject(maintrigger, 500);
        WaitForSingleObject(buffermutex, INFINITE);
    }

    if ((new_wfex->nSamplesPerSec!=wfex.nSamplesPerSec)||
        (new_wfex->nChannels!=wfex.nChannels)||
        (new_wfex->wBitsPerSample!=wfex.wBitsPerSample)||
        !tread_on)
    {
        if (tread_on)   // wait for the thread to finish
        {
            ReleaseMutex(buffermutex);
            while(tread_on) WaitForSingleObject(maintrigger, 500);
            WaitForSingleObject(buffermutex, INFINITE);
        }


        wfex = *new_wfex;
        
        lenringbuffer=BUFFERLENMS*wfex.nSamplesPerSec*wfex.nBlockAlign/1000;

        buf_free=0;
        buf_playing=0;
        buf_filled=0;

        HANDLE tread= (HANDLE)_beginthread( ::waveouttread2, 0, this );
        SetThreadPriority(tread, THREAD_PRIORITY_HIGHEST);
        bool error=false;
        int w=0;
        while(!tread_on && !error)
        {
            WaitForSingleObject(maintrigger, 500);
            w++;
            if (w>10) SetMessage("Thread did not start. (Unknown reason)");
            error= CheckMessage();
        }
        if (error)
        {
            ReleaseMutex(buffermutex);
            return -1;
        }

    }

    file_open=true;
    playrest=false;
    write_ms = 0; write_over = 0;
    last_pause=false;
    lastfreetime_ms= timeGetTime();
    buf_thissong= buf_free;
    buf_fileseperator=-1;

    ReleaseMutex(buffermutex);
    return BUFFERLENMS+1;
}




COut* NewFileout()
{
    return new CFileout;
}
