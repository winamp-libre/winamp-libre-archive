#include <windows.h>
#include <crtdbg.h>
#include <process.h>


#include "Datatypes.h"
#include "Splice.h"
#include "Config.h"


static HANDLE wavetrigger;
static HANDLE maintrigger;


class CWaveout:public COut
{
public:
    void waveouttread();
    CWaveout();
private:
    int set_vol;
    int set_pan;
    volatile bool tread_on;


    virtual ~CWaveout();

    virtual void setvolume(int volume);
    virtual void setpan(int pan);
    virtual void flush(int t);
    virtual int open(WAVEFORMATEX *new_wfex);
    virtual void work();
    virtual void wait_for_work();
};


CWaveout::CWaveout()
{
    _RPT0(_CRT_WARN,"CWaveout ");

    wavetrigger=CreateEvent(NULL, FALSE, FALSE, NULL);
    maintrigger=CreateEvent(NULL, FALSE, FALSE, NULL);
    tread_on=false;
}

void CWaveout::work()
{
    SetEvent(wavetrigger);
}

void CWaveout::wait_for_work()
{
    WaitForSingleObject(maintrigger, 500);
}


CWaveout::~CWaveout()
{
    if (tread_on)
    {
        flushnow=true;
        SetEvent(wavetrigger);
        while (tread_on) WaitForSingleObject(maintrigger, 500);
    }

    CloseHandle(wavetrigger);
    CloseHandle(maintrigger);
}


void CALLBACK waveOutProc(HWAVEOUT hwo,UINT uMsg,DWORD dwInstance,DWORD dwParam1,DWORD dwParam2)
{
    if (uMsg==WOM_DONE)
    {
        ((WAVEHDR*)dwParam1)->dwUser= timeGetTime();
        SetEvent(wavetrigger);
    }
}
 


void waveouttread(void* obj)
{
    ((CWaveout*)obj)->waveouttread();
}


#define MMR(mmfunc)                                   \
{   if (!waserror) if (mmfunc !=MMSYSERR_NOERROR) {   \
    SetDllErrorMessage();                             \
    waserror= true; }                                 \
}

void CWaveout::waveouttread()
{
    int  cur_vol=0xFFFF;// imposible values
    int  cur_pan=0xFFFF;
    bool cur_pause=true;
    bool waserror=false;

    #define nhdr 32
    WAVEHDR wavehdr[nhdr];
    int ihdr1=0;
    int ihdr2=0;

    //SetThreadPriority()
    _RPT0(_CRT_WARN,"tread ");

    HWAVEOUT hwo;

    MMR(waveOutOpen(&hwo, config.waveout_id, &wfex, (DWORD)&waveOutProc, 0, CALLBACK_FUNCTION ))
    if (!hwo || waserror) return;

    MMR(waveOutPause(hwo));


    /*{
        WAVEOUTCAPS woc;
        waveOutGetDevCaps((int)hwo, &woc, sizeof(WAVEOUTCAPS));
    }*/


    ringbuffer= new char[lenringbuffer+4*WORKLEN];
    if (ringbuffer==NULL) return;
    
    
    tread_on=true;
    SetEvent(maintrigger);


    while(true)
    {
        WaitForSingleObject(buffermutex, INFINITE);

        if (flushnow)
        {
            MMR(waveOutReset(hwo));
            MMR(waveOutPause(hwo));
            cur_pause=true;

            buf_free= buf_filled; // reverting the pointer to free filled data without playing
            flushnow=false;
            SetEvent(maintrigger);
        }

        // chech for new free headers
        while ((ihdr1!=ihdr2)&&(wavehdr[ihdr2].dwFlags&WHDR_DONE))
        {
            MMR(waveOutUnprepareHeader(hwo, &wavehdr[ihdr2], sizeof(WAVEHDR)));
            if (waserror)
            {
                buf_playing= buf_free;
                break;
            }
            
            lastfreetime_ms = wavehdr[ihdr2].dwUser;
            if (lastfreetime_ms==0) lastfreetime_ms= timeGetTime();

            buf_playing+=wavehdr[ihdr2].dwBufferLength;
            _ASSERT(wavehdr[ihdr2].dwBufferLength);

            if (buf_playing>=lenringbuffer) buf_playing-=lenringbuffer;
            
            ihdr2++; if (ihdr2>=nhdr) ihdr2=0;
            SetEvent(maintrigger);

            _RPT0(_CRT_WARN,"f");
        }

        // write buffers to mmsystem
        while(true)
        {
            if (waserror)
            {
                buf_filled= buf_free; 
                break;
            }

            int ntowrite= buf_free - buf_filled;
            if (ntowrite<0) ntowrite+=lenringbuffer;

            int inmmsys= buf_filled - buf_playing;
            if (inmmsys<0) inmmsys+=lenringbuffer;

            if ((inmmsys>lenringbuffer/4)|| (file_open))
            {
                if (ntowrite<=4*WORKLEN) break; // protect the mix zone
                ntowrite-=4*WORKLEN;

                if (ntowrite< lenringbuffer/16) break;      // don't write less than 1/16 buffer at a time
            }
            else _RPT0(_CRT_WARN,"*");


            if (ntowrite==0) break;

            ntowrite= __min(ntowrite, lenringbuffer-buf_filled); //don't cross the end of the buffer

            if (ntowrite > (lenringbuffer/32)*6)                // more than 3/16 buffer to write ?
            {
                ntowrite=__min(ntowrite, (lenringbuffer/32)*4); // don't write more than 1/8 buffer at the time
            }


            wavehdr[ihdr1].dwFlags=0;
            wavehdr[ihdr1].lpData=ringbuffer+buf_filled;
            wavehdr[ihdr1].dwBufferLength= ntowrite;
            wavehdr[ihdr1].dwUser=0;
            MMR(waveOutPrepareHeader(hwo, &wavehdr[ihdr1],sizeof(WAVEHDR)));
            MMR(waveOutWrite(hwo, &wavehdr[ihdr1], sizeof(WAVEHDR)));

            ihdr1++; if (ihdr1>=nhdr) ihdr1=0;
            buf_filled+=ntowrite; if (buf_filled>=lenringbuffer) buf_filled-=lenringbuffer;

            _ASSERT(ihdr1!=ihdr2);

            _RPT0(_CRT_WARN,"w");
        }

        if (buf_free==buf_playing) // all free = no data
        {
            if (!file_open)
            {
                waveOutReset(hwo);
                waveOutClose(hwo);
                mix_on=false;
                tread_on=false;
                SetEvent(maintrigger);

                delete ringbuffer;

                ReleaseMutex(buffermutex);
                return;
            }
        }


        if (cur_pause!=last_pause)
        {
            if (last_pause)
            {
                cur_pause=true;
                MMR(waveOutPause(hwo));
            }
            else
            {
                int n=(buf_free - buf_playing);
                if (n<0) n+=lenringbuffer;
                n=(n*1000)/wfex.nAvgBytesPerSec;

                if (n>BUFFERLENMS/4 || !file_open)
                {
                    cur_pause=false;
                    MMR(waveOutRestart(hwo));
                }
            }
        }

        ReleaseMutex(buffermutex);

        if (set_vol!=cur_vol || set_pan!=cur_pan)
        {
            cur_vol= set_vol;
            cur_pan= set_pan;

            int l=0x0101/128*set_vol;
            int r=l;

            l*= (cur_pan>0)?(128-cur_pan):128; 
            r*= (cur_pan<0)?(128+cur_pan):128; 

            waveOutSetVolume(hwo, (r<<16)+l);
        }


        WaitForSingleObject(wavetrigger, 5000);
    }
}

void CWaveout::setvolume(int volume)         
{
    set_vol=volume;
    SetEvent(wavetrigger);
}

void CWaveout::setpan(int pan)
{
    set_pan=pan;
    _RPT1(_CRT_WARN, "pan(%d)", pan);
    SetEvent(wavetrigger);
}


void CWaveout::flush(int t)
{
    _RPT0(_CRT_WARN,"flush ");
    flushnow=true;
    SetEvent(wavetrigger);
    while (flushnow) WaitForSingleObject(maintrigger, 500);
    write_ms=t;
}



int CWaveout::open(WAVEFORMATEX *new_wfex)
{
    WaitForSingleObject(buffermutex, INFINITE);

    if ((new_wfex->nSamplesPerSec!=wfex.nSamplesPerSec)||
        (new_wfex->nChannels!=wfex.nChannels)||
        (new_wfex->wBitsPerSample!=wfex.wBitsPerSample)||
        !tread_on)
    {
        if (tread_on)   // wait for the thread to finish
        {
            ReleaseMutex(buffermutex);
            while(tread_on) WaitForSingleObject(maintrigger, 500);
            WaitForSingleObject(buffermutex, INFINITE);
        }


        wfex = *new_wfex;
        
        lenringbuffer=BUFFERLENMS*wfex.nSamplesPerSec*wfex.nBlockAlign/1000;

        buf_free=0;
        buf_playing=0;
        buf_filled=0;

        HANDLE tread= (HANDLE)_beginthread( ::waveouttread, 0, this );
        SetThreadPriority(tread, THREAD_PRIORITY_HIGHEST);

        bool error=false;
        int w=0;
        while(!tread_on && !error)
        {
            WaitForSingleObject(maintrigger, 500);
            w++;
            if (w>10) SetMessage("Thread did not start. (Unknown reason)");
            error= CheckMessage();
        }
        if (error)
        {
            ReleaseMutex(buffermutex);
            return -1;
        }

    }

    file_open=true;
    playrest=false;
    write_ms = 0; write_over = 0;
    last_pause=false;
    lastfreetime_ms= timeGetTime();
    buf_thissong= buf_free;

    ReleaseMutex(buffermutex);
    return BUFFERLENMS+1;
}




COut* NewWaveout()
{
    return new CWaveout;
}

