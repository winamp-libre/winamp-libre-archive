using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("nanocrew.net")]
[assembly: AssemblyProduct("JustePort")]
[assembly: AssemblyCopyright("Copyright (C) 2005 Jon Lech Johansen <jon@nanocrew.net>")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.2.*")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
