// This is the main DLL file.

#include "stdafx.h"
#include "Bridge.h"
#include "windows.h"

#define PI_VER2 "v1.0"
#ifdef __alpha
#define PI_VER PI_VER2 " (AXP)"
#else
#define PI_VER PI_VER2 " (x86)"
#endif

extern "C" {
#include <string.h>
}


#using "out_AirPort.dll"
using namespace System;
using namespace out_AirPort_ns;
				

extern "C"
{

void config(int hwnd)
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	oAirPort->Config(hwnd);
}

void about(int hwnd)
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	oAirPort->About(hwnd);
}

void init()
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	oAirPort->Init();
}

void quit()
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	oAirPort->Quit();
}

int open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms)
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	return oAirPort->Open(samplerate, numchannels, bitspersamp, bufferlenms, prebufferms);
}

void close()
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	oAirPort->Close();
}

int write(char *buf, int len)
{
	if (len > 0)
	{
		System::Byte buffer __gc[] = new System::Byte __gc[len];	
		System::Runtime::InteropServices::Marshal::Copy(buf, buffer, 0, len);

		out_AirPort __gc *oAirPort;
		oAirPort = new out_AirPort;
		return oAirPort->Write(buffer, len);
	}
	else
	{
		return 1;
	}
}

int canwrite()
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	int canwrite = oAirPort->CanWrite();
	return canwrite;
}

int isplaying()
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	return	oAirPort->IsPlaying();
}

int pause(int pause)
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	return	oAirPort->Pause(pause);
}

void setvolume(int volume)
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	return	oAirPort->SetVolume(volume);

}

void setpan(int pan)
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	return	oAirPort->SetPan(pan);

}

void flush(int t)
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	return	oAirPort->Flush(t);

}
	
int getwrittentime()
{
	out_AirPort __gc *oAirPort;
	oAirPort = new out_AirPort;
	return oAirPort->GetWrittenTime();
}

Out_Module out = {
	OUT_VER,
	"AirPort Streaming Plugin " PI_VER,
	33,
	0, // hmainwindow
	0, // hdllinstance
	config,
	about,
	init,
	quit,
	open,
	close,
	write,
	canwrite,
	isplaying,
	pause,
	setvolume,
	setpan,
	flush,
	getwrittentime,
	getwrittentime
};

__declspec( dllexport ) Out_Module * winampGetOutModule()
{
	return &out;
}
}