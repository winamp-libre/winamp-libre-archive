using System;
using System.Windows.Forms;
using Microsoft.Win32;
/// <summary>
/// Summary description for Class1.
/// </summary>
/// 
namespace out_AirPort_ns
{
	public class out_AirPort
	{
		static AirPort.RAOPClient at;
		static int srate;
		static int numchan;
		static int bps;
		static volatile int writtentime;
		static volatile int w_offset;
		static int last_pause = 0;
		static byte[] buffer;
		static string ip;
		
		static int startindex;
		static double _volume = 0;
		static System.Windows.Forms.Timer timer;

		public void About(IntPtr handle)
		{
			MessageBox.Show("AirPort PlugIn", "out_AirPort About", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		public void Config(IntPtr handle)
		{
			out_AirPort_ns.Config dlg = new out_AirPort_ns.Config();
			dlg.ShowDialog();
		}

		public void Init()
		{
			System.Diagnostics.Debug.WriteLine("Init");
			buffer = new byte[16384];
			timer = new System.Windows.Forms.Timer();
			timer.Tick += new EventHandler(timer_Tick);
			timer.Interval = 1000;
		}

		public void Close()
		{
			System.Diagnostics.Debug.WriteLine("Close");
		}

		public void Quit()
		{
			System.Diagnostics.Debug.WriteLine("Quit");
			if (at != null && at.Connected == true)
				at.Disconnect();
		}
		
		public int Open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms)
		{	
			if (samplerate != 44100)
			{
				MessageBox.Show("Samplerates other than 44100 are not supported", "Samplerate not support", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return 1;
			}
			if (numchannels != 2)
			{
				MessageBox.Show("At the moment, only playback in Stereo is supported", "Mono not supported", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return 1;
			}
			if (bitspersamp != 16)
			{
				MessageBox.Show("Only playback with 16 bits is supported", "Only 16-bit Samples are supported", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return 1;
			}
			try
			{
				// read the IP of the Airport from the registry
				RegistryKey regKey = Registry.LocalMachine;

				try
				{
					regKey = regKey.OpenSubKey("SOFTWARE\\Nullsoft\\Winamp");
					object regObj = regKey.GetValue("AirPort-IP");
					ip = (string)regObj;
				}
				catch(Exception)
				{
					MessageBox.Show("No IP Selected", "No IP Selected", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return 1;
				}
				if(ip == null || ip == "")
				{
					MessageBox.Show("No IP Selected", "No IP Selected", MessageBoxButtons.OK, MessageBoxIcon.Error);
					return 1;
				}
				out_AirPort_ns.Connecting dlg = new out_AirPort_ns.Connecting();
				dlg.ShowConnectingScreen("Connecting to AirPort " + ip);
				// RAOPClient(IP-Address)
				if (at == null)
				{
					at = new AirPort.RAOPClient(ip);
				}
				if (at.Connected == false)
				{
					at.Connect();
				}
				at.Volume = _volume;
				dlg.Close();
			}
			catch( Exception e )
			{
				MessageBox.Show(string.Format("Connect failed: {0}", e.Message) );
				return 1;
			}

			string s = String.Format( "JackStatus: {0}{1}JackType: {2}{3}",
				at.JackStatus == AirPort.RAOPClient.JACK_STATUS_CONNECTED ?
				"connected" : "disconnected", Environment.NewLine,
				at.JackType == AirPort.RAOPClient.JACK_TYPE_DIGITAL ?
				"digital" : "analog", Environment.NewLine );
			// Console.WriteLine( s );
			System.Diagnostics.Debug.WriteLine(s);
			
			
			w_offset = writtentime = 0;
			numchan = numchannels;
			srate = samplerate;
			bps = bitspersamp;
			startindex = 0;
			return 0;
		}

		public int Write(byte[] buf, int len)
		{
			if (at.Connected == false)
			{
				out_AirPort_ns.Connecting dlg = new out_AirPort_ns.Connecting();
				dlg.ShowConnectingScreen("Connecting to AirPort " + ip);
				at.Connect();
				dlg.Close();
			}
			
			writtentime += len;
			timer.Stop();
			timer.Start();
			Array.Copy(buf, 0, buffer, startindex, ((16384 - startindex)) >= len ? len : 16384 - startindex);
			startindex += len;

			if(startindex >= 16384)
			{
				byte[] alac = AirPort.JustePort.EncodeALAC(buffer);
				startindex -= 16384;
				int startpos = len - startindex;
				Array.Clear(buffer, 0, 16384);
				Array.Copy(buf, startpos, buffer, 0, startindex);
				try
				{
					at.SendSample(alac, 0, alac.Length);
				}
				catch(Exception ex)
				{
					MessageBox.Show(ex.Message);
				}
			}
			return 0;
		}

		public int CanWrite()
		{
			return last_pause != 0 ? 0 : 16384;
		}

		public int IsPlaying()
		{
			return 0;
		}

		public int Pause(int pause)
		{
			int t = last_pause;
			last_pause = pause;
			return t;			
		}

		public void SetVolume(int volume)
		{
			System.Diagnostics.Debug.WriteLine("SetVolume");
			_volume = 144 * (Math.Log10(254.0 * (double)volume / 255.0 + 1) / Math.Log10(255.0) - 1);
			if (at != null)
				at.Volume = _volume;

		}

		public void SetPan(int pan)
		{
			System.Diagnostics.Debug.WriteLine("SetPan");

		}

		public void Flush(int t)
		{
			System.Diagnostics.Debug.WriteLine("Flush");
		}
		
		public int GetWrittenTime()
		{
			int t = srate*numchan;
			int l;
			int ms = writtentime;
			
			l = ms % t;
			ms /= t;
			ms *= 1000;
			ms += (l * 1000) / 2;

			if (bps == 16) ms /= 2;

			return ms + w_offset;
		}

		private void timer_Tick(object sender, EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("timer_Tick");
			at.Disconnect();
		}
	}
}
