Code generation
===============

mixgen_io - input-to-output mixing functions for Mixer class
mixgen_io - inplace mixing functions for Mixer class
pcm2linear - format conversion functions for Converter class
linear2pcm - format conversion functions for Converter class
spk_tblgen - tables for Speakers class
