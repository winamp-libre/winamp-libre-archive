#ifndef DBESI0_H
#define DBESI0_H

#ifdef __cplusplus
extern "C" {
#endif

double dbesi0(double x);

#ifdef __cplusplus
}
#endif

#endif
