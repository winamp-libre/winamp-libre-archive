This directory contains some Win32-specific utils.

* CPUMeter (cpu.h): CPU usage measurement class. Measure time used by thread
  and calculates CPU usage.
* Thread (thread.h): Thread class, critical section and automatic lock.
* winspk.h: Fuctions to convert between Speakers and WAVEFORMAT.
