This directory contains LibA52 source code to compare its output
with AC3Parser. It was slightly modified for testing purposes 
(compare parser output on coeffitients level and without dithering).
A52Parser class provides standard parser interface.

