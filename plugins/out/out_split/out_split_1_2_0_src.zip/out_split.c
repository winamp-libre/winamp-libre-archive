#define STRICT
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <msacm.h>
#include "out.h"
#include "resource.h"

void Config(HWND);
void About(HWND);
void Init();
void Quit();
int Open(int, int, int, int, int);
void Close();
int Write(char*, int);
int CanWrite();
int IsPlaying();
int Pause(int);
void SetVolume(int);
void SetPan(int);
void Flush(int);
int GetOutputTime();
int GetWrittenTime();

Out_Module ThisModule =
{
    OUT_VER,
    "Split output plug-in 0.1",
    128,
    NULL,
    NULL,
    Config,
    About,
    Init,
    Quit,
    Open,
    Close,
    Write,
    CanWrite,
    IsPlaying,
    Pause,
    SetVolume,
    SetPan,
    Flush,
    GetOutputTime,
    GetWrittenTime
};

LPCTSTR      lpAppName = "Split output plug-in";
LPCTSTR      lpFileName = "winamp.ini";
TCHAR        lpLibWaveFileName[MAX_PATH] = "";
TCHAR        lpLibFileFileName[MAX_PATH] = "";
Out_Module*  WaveModule = NULL;
Out_Module*  FileModule = NULL;
HINSTANCE    hWaveDllInstance = NULL;
HINSTANCE    hFileDllInstance = NULL;

__declspec(dllexport) Out_Module* winampGetOutModule()
{
    return &ThisModule;
}

Out_Module* GetOutModuleFromDll(LPCSTR lpDllFileName, HINSTANCE* phDllInstance)
{
    Out_Module* (*_winampGetOutModule)(void);
	Out_Module* pRetVal;

	*phDllInstance = NULL;

	if ((*phDllInstance = LoadLibrary(lpDllFileName)) == NULL)
	{
		return NULL;
	}
    if ((_winampGetOutModule = (Out_Module* (*) (void)) GetProcAddress(*phDllInstance, "winampGetOutModule")) == NULL)
	{
		return NULL;
	}
    if ((pRetVal = _winampGetOutModule()) == NULL)
	{
		return NULL;
	}
	return pRetVal;
}



void SaveConfig(HWND hwnd)
{
	Edit_GetText(GetDlgItem(hwnd, IDC_PLUGIN1), lpLibWaveFileName, MAX_PATH);
	Edit_GetText(GetDlgItem(hwnd, IDC_PLUGIN2), lpLibFileFileName, MAX_PATH);

    WritePrivateProfileString(lpAppName, "Plugin1", lpLibWaveFileName, lpFileName);
    WritePrivateProfileString(lpAppName, "Plugin2", lpLibFileFileName, lpFileName);

	Init();
}

void Config_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	switch (id)
	{
	case IDOK:
		SaveConfig( hwnd);
		EndDialog(hwnd, 0); 
		break;
	case IDC_CONFIG1: 
		SaveConfig( hwnd);
		if (WaveModule != NULL)
		{
			WaveModule->Config(hwnd);
		}
		else
		{
			MessageBox(hwnd, "Plug-in 1 not loaded correctly", "Split Plug-in", MB_OK);
		}
		break;
	case IDC_CONFIG2: 
		SaveConfig(hwnd);
		if (FileModule != NULL)
		{
			FileModule->Config(hwnd);
		}
		else
		{
			MessageBox(hwnd, "Plug-in 2 not loaded correctly", "Split Plug-in", MB_OK);
		}
		break;
	case IDCANCEL: 
		EndDialog(hwnd, 0); 
		break;
	default:
		break;
	}
}

BOOL Config_OnInitDlg(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	Edit_SetText(GetDlgItem(hwnd, IDC_PLUGIN1), lpLibWaveFileName);
	Edit_SetText(GetDlgItem(hwnd, IDC_PLUGIN2), lpLibFileFileName);
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
BOOL WINAPI Config_DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

   switch (uMsg)
   {
      HANDLE_MSG(hwnd, WM_COMMAND, Config_OnCommand);
      HANDLE_MSG(hwnd, WM_INITDIALOG, Config_OnInitDlg);
   }
   return(FALSE);

}

void Config(HWND hwndParent)
{
	DialogBox(ThisModule.hDllInstance, MAKEINTRESOURCE(IDD_SPLITCONFIG),  NULL, Config_DlgProc);
}

void About(HWND hwndParent)
{
    if (WaveModule != NULL)
	{
		WaveModule->About(hwndParent);
	}
    if (FileModule != NULL)
	{
		FileModule->About(hwndParent);
	}
}

void Init()
{
    LPCSTR lpCmdLine = GetCommandLine();

	Quit();

	GetPrivateProfileString(lpAppName, "Plugin1", "Plugins\\out_wave.dll", lpLibWaveFileName, MAX_PATH, lpFileName);
	GetPrivateProfileString(lpAppName, "Plugin2", "Plugins\\out_wm.dll", lpLibFileFileName, MAX_PATH, lpFileName);

    if ((WaveModule = GetOutModuleFromDll(lpLibWaveFileName, &hWaveDllInstance)) == NULL)
	{
		goto error;
	}

    WaveModule->hMainWindow = ThisModule.hMainWindow;
    WaveModule->hDllInstance = hWaveDllInstance;
    WaveModule->Init();

    if ((FileModule = GetOutModuleFromDll(lpLibFileFileName, &hFileDllInstance)) == NULL)
	{
		goto error;
	}

    FileModule->hMainWindow = ThisModule.hMainWindow;
    FileModule->hDllInstance = hFileDllInstance;
    FileModule->Init();

    return;

error:
	Quit();
}

void Quit()
{

    if (WaveModule != NULL)
	{
		WaveModule->Quit();
	}

    if (FileModule != NULL)
	{
		FileModule->Quit();
	}

    if (hWaveDllInstance != NULL)
	{
		FreeLibrary(hWaveDllInstance);
		hWaveDllInstance = NULL;
	}
    if (hFileDllInstance != NULL)
	{
		FreeLibrary(hFileDllInstance);
		hFileDllInstance = NULL;
	}
}

int Open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms)
{
	int RetVal = -1;
	int RetVal2 = -1;

	if (WaveModule != NULL)
	{
		WaveModule->hMainWindow = ThisModule.hMainWindow;
		RetVal = WaveModule->Open(samplerate, numchannels, bitspersamp, bufferlenms, prebufferms);
	}

	/* Throw away the file plug-in return so that we can save streamed files */
    if (FileModule != NULL)
	{
		FileModule->hMainWindow = ThisModule.hMainWindow;
		RetVal2 = FileModule->Open(samplerate, numchannels, bitspersamp, bufferlenms, prebufferms);
	}
	return RetVal;
}

void Close()
{
    if (WaveModule != NULL)
	{
		WaveModule->Close();
	}
    if (FileModule != NULL)
	{
		FileModule->Close();
	}
}

int Write(char* buf, int len)
{
	int RetVal = -1;
	if (WaveModule != NULL)
	{
		RetVal = WaveModule->Write(buf, len);
	}
	if (FileModule != NULL)
	{
		RetVal = FileModule->Write(buf, len);
	}
	return RetVal;
}

int CanWrite()
{
    if (WaveModule != NULL)
	{
		return WaveModule->CanWrite();
	}
    else
	{
		return 0;
	}
}

int IsPlaying()
{
    if (WaveModule != NULL)
	{
		return WaveModule->IsPlaying();
	}
    else
	{
		return 0;
	}
}

int Pause(int pause)
{
	int RetVal = -1;
    if (WaveModule != NULL)
	{
		RetVal = WaveModule->Pause(pause);
	}
    if (FileModule != NULL)
	{
		RetVal = FileModule->Pause(pause);
	}
	return RetVal;
}

void SetVolume(int volume)
{
    if (WaveModule != NULL)
	{
		WaveModule->SetVolume(volume);
	}
    if (FileModule != NULL)
	{
		FileModule->SetVolume(volume);
	}
}

void SetPan(int pan)
{
    if (WaveModule != NULL)
	{
		WaveModule->SetPan(pan);
	}
    if (FileModule != NULL)
	{
		FileModule->SetPan(pan);
	}
}

void Flush(int t)
{
    if (WaveModule != NULL)
	{
		WaveModule->Flush(t);
	}
    if (FileModule != NULL)
	{
		FileModule->Flush(t);
	}
}

int GetOutputTime()
{
    if (WaveModule != NULL)
	{
		return WaveModule->GetOutputTime();
	}
    else
	{
		return 0;
	}
}

int GetWrittenTime()
{
    if (WaveModule != NULL)
	{
		return WaveModule->GetWrittenTime();
	}
    else
	{
		return 0;
	}
}
