#include "kssample.h"
#include "out.h"

#define PI_VER2 "v1.0 alpha"

#define PI_VER PI_VER2 " (x86)"

#define Zero(s)                     ZeroMemory(&s, sizeof(s))

int getwrittentime();

int srate, numchan, bps;
volatile int writtentime, w_offset;
extern Out_Module out;
static int last_pause=0;

// Kernel Streaming stuff

// this defines how many data packets we will use to stream data to the pin
//#define cPackets	4	// probably around 52.24489796 ms latency (depends on amount given to Write())
//#define cPackets	6	// probably around 78.36734694 ms latency (depends on amount given to Write())
//#define cPackets	8	// probably around 10.44897959 ms latency (depends on amount given to Write())
#define cPackets	10	// probably around 130.6122449 ms latency (depends on amount given to Write())

struct DATA_PACKET
{
    KSSTREAM_HEADER Header;
    OVERLAPPED      Signal;
};

HRESULT hr = S_OK;
PBYTE   pBuffer = NULL;
ULONG cbBuffer = 0;
HANDLE hStopEvent = NULL;
CKsAudRenFilter*    pFilter;
CKsAudRenPin*       pPin;

KSSTATE State = KSSTATE_STOP;

// data packet stuff
HANDLE      hEventPool[cPackets + 1];
DATA_PACKET Packets[cPackets];
//ULONG       cbPartialBuffer = cbBuffer / cPackets;
ULONG       cbPartialBuffer = 0;

// end KS stuff

BOOL WINAPI _DllMainCRTStartup(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH) DisableThreadLibraryCalls((HMODULE)hInst);
	return TRUE;
}

void config(HWND hwnd)
{
	MessageBox(hwnd, "No Config Yet - very simple plugin\n", "Config", MB_OK);
}

void about(HWND hwnd)
{
	MessageBox(hwnd,"Chun-Yu's Kernel Streaming Plug-in " PI_VER "\n"
					"Copyright (c) 2002 Chun-Yu Shei.\n\n"
					"Compiled on " __DATE__ "\n","About",MB_OK);
}

void init()
{
	hStopEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
}

void quit()
{
	CloseHandle(hStopEvent);
}

int open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms)
{
	// enumerate audio renderers
    CKsEnumFilters* pEnumerator = new CKsEnumFilters(&hr);
	if(pEnumerator == NULL)
	{
		MessageBox(out.hMainWindow, "Failed to allocate CKsEnumFilters", "Error!", MB_OK);
		return -1;
	}
	else if(!SUCCEEDED(pEnumerator))
	{
		MessageBox(out.hMainWindow, "Failed to create CKsEnumFilters", "Error!", MB_OK);
		return -1;
	}

    GUID  aguidEnumCats[] = { STATIC_KSCATEGORY_AUDIO, STATIC_KSCATEGORY_RENDER };

    hr = 
        pEnumerator->EnumFilters
        (
            eAudRen,            // create audio render filters ...
            aguidEnumCats,      // ... of these categories
            2,                  // There are 2 categories
            TRUE,               // While you're at it, enumerate the pins
            FALSE,              // ... but don't bother with nodes
            TRUE                // Instantiate the filters
        );

    if(!SUCCEEDED(hr))
	{
		MessageBox(out.hMainWindow, "CKsEnumFilters::EnumFilters failed", "Error!", MB_OK);
		return -1;
	}

	pEnumerator->m_listFilters.GetHead((CKsFilter**)&pFilter);	// just grab the first one we find
	/*	// picking a specific output device
	LISTPOS lp = pEnumerator->m_listFilters.GetHeadPosition();
	pEnumerator->m_listFilters.GetNext(lp, (CKsFilter**)&pFilter);	// once gives my WaveForce
	pEnumerator->m_listFilters.GetNext(lp, (CKsFilter**)&pFilter);	// do 2 times to get my Creative AudioPCI
	*/
    if(pFilter == NULL)
	{
		MessageBox(out.hMainWindow, "No filters available for rendering", "Error!", MB_OK);
		return -1;
	}

	// instantiate the pin
    // use WAVEFORMATEXTENSIBLE to describe wave format
    WAVEFORMATEXTENSIBLE wfx;
    wfx.Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
    wfx.Format.nChannels = numchannels;
    wfx.Format.nSamplesPerSec = samplerate;
    wfx.Format.nBlockAlign = numchannels*bitspersamp/8;	// I think
    wfx.Format.nAvgBytesPerSec = wfx.Format.nSamplesPerSec * wfx.Format.nBlockAlign;
    wfx.Format.wBitsPerSample = bitspersamp;
    wfx.Format.cbSize = sizeof(WAVEFORMATEXTENSIBLE)-sizeof(WAVEFORMATEX);
	wfx.Samples.wValidBitsPerSample = bitspersamp;
    wfx.dwChannelMask = KSAUDIO_SPEAKER_STEREO;
    wfx.SubFormat = KSDATAFORMAT_SUBTYPE_PCM;

    pPin = pFilter->CreateRenderPin(&wfx.Format, FALSE);

    if (!pPin)
    {
        // driver can't handle WAVEFORMATEXTENSIBLE, so fall back to
        // WAVEFORMATEX format descriptor and try again
        wfx.Format.wFormatTag = WAVE_FORMAT_PCM;
        // set unused members to zero
        wfx.Format.cbSize = 0;
        wfx.Samples.wValidBitsPerSample = 0;
        wfx.dwChannelMask = 0;
        wfx.SubFormat = GUID_NULL;

        pPin = pFilter->CreateRenderPin(&wfx.Format, FALSE);
    }

	// allocate cPackets 8192 byte buffers - should *always* work because Write() should never write more than 8192b
	cbBuffer = cPackets * 8192;
    pBuffer = new BYTE[cbBuffer];
	cbPartialBuffer = cbBuffer / cPackets;
	ZeroMemory(pBuffer, cbBuffer);

	// set up the data packets
    for(int i = 0; i < cPackets; i++)
    {
        Zero(Packets[i]);
        hEventPool[i] = CreateEvent(NULL, TRUE, TRUE, NULL);	// NO autoreset!

        Packets[i].Signal.hEvent = hEventPool[i];
        Packets[i].Header.Data = pBuffer + i * cbPartialBuffer;
        Packets[i].Header.FrameExtent = cbPartialBuffer;
        Packets[i].Header.DataUsed = cbPartialBuffer;  // if we were capturing, we would init this to 0
        Packets[i].Header.Size = sizeof(Packets[i].Header);
        Packets[i].Header.PresentationTime.Numerator = 1;
        Packets[i].Header.PresentationTime.Denominator = 1;
    }

	ResetEvent(hStopEvent);	// reset stop event - it isn't even used (yet?)
	hEventPool[cPackets] = hStopEvent;	// stop event

	// set new state
    State = KSSTATE_RUN;
    hr = pPin->SetState(State);
	if(!SUCCEEDED(hr))
	{
		MessageBox(out.hMainWindow, "Error in pPin->SetState(KSSTATE_RUN) !", "Error!", MB_OK);
		return -1;
	}

 	w_offset = writtentime = 0;
	numchan = numchannels;
	srate = samplerate;
	bps = bitspersamp;
	return 0;
}

void close()
{
	// stop the pin
    hr = pPin->SetState(KSSTATE_PAUSE);
    hr = pPin->SetState(KSSTATE_STOP);

	State = KSSTATE_STOP;

    // all done for this demo
    pPin->ClosePin();

    delete pFilter;

	if (pBuffer) delete [] pBuffer;

	for(int i = 0; i < cPackets; i++)
    {
        CloseHandle(hEventPool[i]);
	}
}

int write(char *buf, int len)
{
	// use cPackets buffers to flip between (later should use more)
	
	// see if a buffer is free
	DWORD dwWait = WaitForMultipleObjects(cPackets, hEventPool, FALSE, 0);
	// if not, tell input plugin that we aren't ready yet
	if((dwWait == WAIT_FAILED) || (dwWait == WAIT_TIMEOUT)) return 1;
	else dwWait -= WAIT_OBJECT_0;

	CopyMemory(Packets[dwWait].Header.Data, buf, len);

	Packets[dwWait].Header.FrameExtent = len;
	Packets[dwWait].Header.DataUsed = len;

	// key - no using autoreset events!!! (yes, I spent 3 hours figuring this out the *hard* way)
	ResetEvent(Packets[dwWait].Signal.hEvent);

	hr = pPin->WriteData(&Packets[dwWait].Header, &Packets[dwWait].Signal);
	if(!SUCCEEDED(hr)) return 1;	// or does it really matter?

	writtentime += len;

	return 0;
}

int canwrite()
{
	// see if we can write - just "peek" at the event and don't reset it!
	DWORD dwWait = WaitForMultipleObjects(cPackets, hEventPool, FALSE, 0);
	if(dwWait != WAIT_FAILED && dwWait != WAIT_TIMEOUT) return last_pause ? 0 : 8192;
	else return 0;
}

int isplaying()
{
	// check if BOTH (well, later ALL) packets are done
	DWORD result = WaitForMultipleObjects(cPackets, hEventPool, TRUE, 0);
	if(!(result - WAIT_OBJECT_0))	// I think...
	{
		return 0;	// neither of them timed out, so we must be done playing
	}
	else return 1;	// one of them isn't signaled yet - still playing
}

int pause(int pause)
{
	int t=last_pause;
	last_pause=pause;

	if(pause)	// pausing
	{
		if (State == KSSTATE_STOP)	// should *never* happen, but oh, well
		{
			for (int i = 0; i < cPackets; i++)
				SetEvent(hEventPool[i]);
		}

		// set new state
		State = KSSTATE_PAUSE;
		hr = pPin->SetState(State);
	}
	else	// unpausing
	{
		if (State == KSSTATE_STOP)	// should *never* happen, but oh, well
        {
            for (int i = 0; i < cPackets; i++)
                SetEvent(hEventPool[i]);
        }

        // set new state
        State = KSSTATE_RUN;
        hr = pPin->SetState(State);
	}

	return t;
}

void setvolume(int volume)
{
	// to be added later
}

void setpan(int pan)
{
	// to be added later
}

void flush(int t)
{
	int a;
	w_offset=0;
	a = t - getwrittentime();
	w_offset=a;
}
	
int getwrittentime()
{
	// should check output position, but I don't yet
	int t=srate*numchan,l;
	int ms=writtentime;

	l=ms%t;
	ms /= t;
	ms *= 1000;
	ms += (l*1000)/t;

	if (bps == 16) ms/=2;

	return ms + w_offset;
}

Out_Module out = {
	OUT_VER,
	"Simple Kernel Streaming Output",
	33,
	0, // hmainwindow
	0, // hdllinstance
	config,
	about,
	init,
	quit,
	open,
	close,
	write,
	canwrite,
	isplaying,
	pause,
	setvolume,
	setpan,
	flush,
	getwrittentime,
	getwrittentime
};

extern "C"
{
__declspec( dllexport ) Out_Module * winampGetOutModule()
{
	return &out;
}
}
