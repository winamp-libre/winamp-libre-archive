This mini SDK demonstrates the base structure of an output plug-in for Winamp.
Much like Disk Writer, RAW Writer takes an input file and converts it to the 
output format; in this case, the RAW format.  It bypasses playback and writes the 
output file as quickly as the input file can be decoded.  I hope this has helped.

-Denzil
