/*
 * Insomnia Visions waveOut Plug-in for Winamp 2.xx
 * ------------------------------------------------
 * Copyright (C)2002 David Overton <david@insomniavisions.com>
 *
 * This program is free software. Permission is granted to 
 * redistribute it or modify it provided that this header
 * remains in each file and the origin of this code is not
 * misrepresented. Modified binary distributions must also
 * be distributed with this licence agreement.
 *
 * This program is distributed without warrenty of any kind
 * and is not guaranteed to work on any system. You use this
 * program entirely at your own risk.
 */

#if !defined(__Plugin_H_)
#define __Plugin_H_

/*
 * buffer is 160 kilobytes in this configuration
 * which is substantially less than winamp's 320.
 * (gives us about 850 ms latency). You can go much
 * smaller but with the risk of buffer underrun.
 */
#define IVWAVE_BLOCK_COUNT 20
#define IVWAVE_BLOCK_SIZE  8192

#define IVWAVE_BLOCK_COUNT_MAX 50
#define IVWAVE_BLOCK_COUNT_MIN 2
#define IVWAVE_BLOCK_SIZE_MAX 65536
#define IVWAVE_BLOCK_SIZE_MIN 1024

#define IVWAVE_NAME "Insomnia Visions waveOut Plug-in"
#define IVWAVE_VER "v0.4"

/*
 * configuration structure
 */
typedef struct {
    int block_count;
    int block_size;
    int volume_enabled;
    int reverse_balance;
    int device;
    int pcmconv_enabled;
} config_t;

typedef struct {
    int srate;
    int bps;
    int nch;
    int conv;
} format_t;

typedef struct {
    int active;
    int total_buffer_size;
    int total_buffer_usage;
    int block_size;
    int block_usage;
    int block_count;
    int bytes_written;
    int bytes_played;
    int start_position;
    int latency;
    format_t format;
} stats_t;

/*
 * prototyes
 */
static void ivwave_config(HWND parent);
static void ivwave_about(HWND parent);
static void ivwave_init(void);
static void ivwave_quit(void);
static int  ivwave_open(int srate, int nch, int bps, int buflen, int prebuf);
static void ivwave_close(void);
static int  ivwave_write(void* buffer, int size);
static int  ivwave_can_write(void);
static int  ivwave_playing(void);
static int  ivwave_pause(int pause);
static void ivwave_set_volume(int volume);
static void ivwave_set_pan(int pan);
static void ivwave_flush(int time);
static int  ivwave_get_output_time(void);
static int  ivwave_get_written_time(void);
static void CALLBACK ivwave_waveout_callback(HWAVEOUT device, UINT msg, DWORD inst, DWORD parm1, DWORD parm2);

void ivwave_get_statistics(stats_t* stats);
void ivwave_get_config(config_t* config);
void ivwave_set_config(const config_t* config);
int  config_load(config_t* config);
void config_save(const config_t* config);
void config_set_defaults(config_t* config);
BOOL CALLBACK config_dialog_proc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);


#endif