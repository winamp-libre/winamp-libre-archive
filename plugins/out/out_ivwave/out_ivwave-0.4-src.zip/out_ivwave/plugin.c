/*
 * Insomnia Visions waveOut Plug-in for Winamp 2.xx
 * ------------------------------------------------
 * Copyright (C)2002 David Overton <david@insomniavisions.com>
 *
 * This program is free software. Permission is granted to 
 * redistribute it or modify it provided that this header
 * remains in each file and the origin of this code is not
 * misrepresented. Modified binary distributions must also
 * be distributed with this licence agreement.
 *
 * This program is distributed without warrenty of any kind
 * and is not guaranteed to work on any system. You use this
 * program entirely at your own risk.
 */

#include <windows.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <assert.h>
#include "out.h"
#include "plugin.h"
#include "resource.h"
#include "opt.h"

/*
 * private "members"
 */
static CRITICAL_SECTION ivwave_critical_section;
static HWAVEOUT         ivwave_device;
static WAVEHDR*         ivwave_headers;
static int              ivwave_current_header;
static int              ivwave_free_headers;
static int              ivwave_written;
static int              ivwave_output;
static int              ivwave_pos;
static int              ivwave_volume;
static int              ivwave_pan;
static int              ivwave_bytes_per_sec;
static int              ivwave_paused;
static config_t         ivwave_config_master;
static config_t         ivwave_config_current;
static format_t         ivwave_format;

/* 
 * the one and only plugin
 */
static Out_Module ivwave = {
    OUT_VER,
    IVWAVE_NAME" "IVWAVE_VER,
    165540,
    NULL,
    NULL,
    ivwave_config,
    ivwave_about,
    ivwave_init,
    ivwave_quit,
    ivwave_open,
    ivwave_close,
    ivwave_write,
    ivwave_can_write,
    ivwave_playing,
    ivwave_pause,
    ivwave_set_volume,
    ivwave_set_pan,
    ivwave_flush,
    ivwave_get_output_time,
    ivwave_get_written_time
};

/*
 * ivwave_config - called by the parent application to display
 * a configuration dialog box.
 */
static void ivwave_config(HWND parent)
{
    if(DialogBoxParam(
        ivwave.hDllInstance,
        MAKEINTRESOURCE(IDD_CONFIGDLG),
        parent,
        config_dialog_proc,
        0
    ) == IDOK) {
        if(ivwave_playing()) {
            MessageBox(
                parent, 
                "Changes will be applied when playback is next restarted.",
                "waveOut Configuration",
                MB_ICONINFORMATION
            );
        }
        else
            ivwave_config_current = ivwave_config_master;
    }
}

/*
 * ivwave_about - called by the parent application to display
 * some information about the plug-in.
 */
static void ivwave_about(HWND parent)
{
    MessageBox(
        parent,
        "Insomnia Visions waveOut Plug-in v0.4\n"
        "Copyright (C)2002 David Overton\n\n"
        "E-Mail: david@insomniavisions.com\n"
        "Website: http://www.insomniavisions.com",
        "About Insomnia Visions waveOut Plug-in",
        MB_ICONINFORMATION
    );
}

/*
 * ivwave_init - called once when the plug-in is loaded. this simply
 * initialises some static vars which are already initialised (if my
 * understanding of the C standard is correct).
 */
static void ivwave_init(void)
{
    ivwave_device = NULL;
    ivwave_headers = NULL;
    ivwave_volume = 255;
    ivwave_pan = 0;

    if(!config_load(&ivwave_config_master)) {
        /*
         * defaults
         */
        config_set_defaults(&ivwave_config_master);
    }
    else {
        /* 
         * validate configuration
         */
        if(ivwave_config_master.block_count < IVWAVE_BLOCK_COUNT_MIN)
            ivwave_config_master.block_count = IVWAVE_BLOCK_COUNT_MIN;
        else if(ivwave_config_master.block_count > IVWAVE_BLOCK_COUNT_MAX)
            ivwave_config_master.block_count = IVWAVE_BLOCK_COUNT_MAX;

        if(ivwave_config_master.block_size < IVWAVE_BLOCK_SIZE_MIN)
            ivwave_config_master.block_size = IVWAVE_BLOCK_SIZE_MIN;
        else if(ivwave_config_master.block_size > IVWAVE_BLOCK_SIZE_MAX)
            ivwave_config_master.block_size = IVWAVE_BLOCK_SIZE_MAX;

        if(ivwave_config_master.device > (int)waveOutGetNumDevs() - 1)
            ivwave_config_master.device = -1;
        else if(ivwave_config_master.device < -1)
            ivwave_config_master.device = -1;
    }

    /*
     * set up some bits to make the config display properly
     * before we've initiated playback. since the rest are static
     * we don't need to touch them.
     */
    ivwave_free_headers = ivwave_config_master.block_count;
    ivwave_config_current = ivwave_config_master;
}

/*
 * ivwave_quit - called on quit. this assert checks that the device
 * was properly closed before the application unloaded the plug-in.
 * does nothing in release mode.
 */
static void ivwave_quit(void)
{
    assert(ivwave_device == NULL);
}

/*
 * ivwave_open - open the device. srate = sampling rate, nch = number of
 * channels, bps = number of bits per sample. buflen and prebuf are 
 * ignored.
 */
static int ivwave_open(int srate, int nch, int bps, int buflen, int prebuf)
{
    WAVEFORMATEX wfx;
    MMRESULT result;
    unsigned char* buffer;
    int i;

    assert(ivwave_device == NULL);

    /*
     * copy the config so that we can modify the original during
     * playback without screwing anything up.
     */
    ivwave_config_current = ivwave_config_master;

    ivwave_format.bps       = bps;
    ivwave_format.nch       = nch;
    ivwave_format.srate     = srate;
    ivwave_format.conv      = 0;

    if(waveOutGetNumDevs() == 0) {
        MessageBox(
            ivwave.hMainWindow,
            "Playback cannot proceed because there are no valid wave devices\n"
            "present on this system. If you have a sound card and you are\n"
            "sure that the drivers are correctly installed, consider trying\n"
            "the DirectSound output plug-in instead.",
            IVWAVE_NAME" Error",
            MB_ICONERROR
        );
        return -1;

    }

    /*
     * set up format info stuff
     */
    wfx.cbSize = 0;
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = nch;
    wfx.nSamplesPerSec = srate;
    wfx.wBitsPerSample = bps;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) >> 3;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
    
    /*
     * open the wave output device
     */
    if((result = waveOutOpen(
        &ivwave_device, 
        ivwave_config_current.device, 
        &wfx, 
        (DWORD_PTR)ivwave_waveout_callback,
        (DWORD_PTR)&ivwave_free_headers, 
        CALLBACK_FUNCTION
    )) != MMSYSERR_NOERROR && ivwave_config_current.pcmconv_enabled) {
        /*
         * see http://www.microsoft.com/hwdev/tech/audio/multichaud.asp
         *
         * As well as supporting audio with > 2 channels it will
         * perform conversions on the data before writing it to the
         * card.
         */
        WAVEFORMATEXTENSIBLE wfex;

        /*
         * avoiding ks.h and ksmedia.h
         */ 
        GUID KSDATAFORMAT_SUBTYPE_PCM = {
            0x00000001,
            0x0000,
            0x0010,
            { 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71 }
        };

        wfex.Format = wfx;
        wfex.Format.cbSize = 22;
        wfex.Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
        wfex.Samples.wReserved = 0;
        wfex.dwChannelMask = 0;
        wfex.SubFormat = KSDATAFORMAT_SUBTYPE_PCM;

        result = waveOutOpen(
            &ivwave_device,
            ivwave_config_current.device,
            (WAVEFORMATEX*)&wfex,
            (DWORD_PTR)ivwave_waveout_callback,
            (DWORD_PTR)&ivwave_free_headers, 
            CALLBACK_FUNCTION
        );

        ivwave_format.conv = 1;
    }

    if(result != MMSYSERR_NOERROR) {
        WAVEOUTCAPS woc;
        char buffer[512];
        
        if(waveOutGetDevCaps(
            (UINT)ivwave_config_current.device,
            &woc,
            sizeof(WAVEOUTCAPS)
        )!=MMSYSERR_NOERROR)
            lstrcpy(woc.szPname, "[Invalid Device]");

        /*
         * argh
         */
        switch(result) {
        case WAVERR_BADFORMAT:
            wsprintf(
                buffer,
                "The \"%s\" device returned a Bad Format error (%d) during\n"
                "the waveOutOpen call. This is because the device does not support the\n"
                "following PCM format:\n\n"
                "Sample Rate:\t%d Hz\n"
                "Sample Size:\t%d bits (%s)\n"
                "Channels:\t%d\n\n"
                "%sinput plug-in has options for changing the output format\n"
                "try adjusting these to a format supported by your sound card.\n"
                "Consult your sound card manual for exact format specifications.",
                woc.szPname,
                result,
                wfx.nSamplesPerSec,
                wfx.wBitsPerSample,
                wfx.wBitsPerSample == 8 ? "unsigned" : "signed",
                wfx.nChannels,
                ivwave_config_current.pcmconv_enabled ?
                "If the current "
                :
                "You might be able to fix this problem by enabling the \"PCM Conversion\"\n"
                "option in the configuration for this plug-in. Alternatively, if the\ncurrent "
            );
            break;
        case MMSYSERR_BADDEVICEID:
            wsprintf(
                buffer,
                "The waveOut system returned a Bad Device ID error (%d) during\n"
                "the waveOutOpen call. The device identifier given was %d.\n"
                "Please ensure that you have a soundcard and that the drivers are\n"
                "installed correctly. If this is already the case, try selecting a\n"
                "different device from the \"Output Device\" section in the configuration\n"
                "for this plug-in\n",
                result,
                ivwave_config_current.device
            );
            break;
        default:
            wsprintf(
                buffer,
                "An MMSYSTEM error occurred while opening the wave device.\n\n"
                "Output device: %s\n"
                "Error code: %u\n\n",
                woc.szPname,
                result
            );
        }

        MessageBox(
            ivwave.hMainWindow,
            buffer,
            IVWAVE_NAME" Error",
            MB_ICONERROR
        );
        return -1;
    }

    /*
     * allocate memory for buffers, headers etc.
     */
    if((buffer = (unsigned char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, (sizeof(WAVEHDR) + ivwave_config_current.block_size) * ivwave_config_current.block_count)) == NULL) {
        waveOutClose(ivwave_device);
        ivwave_device = NULL;
        MessageBox(
            ivwave.hMainWindow,
            "Memory allocation error allocating wave buffer",
            IVWAVE_NAME" Error",
            MB_ICONERROR
        );
        return -1;
    }

    InitializeCriticalSection(&ivwave_critical_section);

    ivwave_headers          = (WAVEHDR*)buffer;
    ivwave_current_header   = 0;
    ivwave_free_headers     = ivwave_config_current.block_count;
    ivwave_written          = 0;
    ivwave_output           = 0;
    ivwave_pos              = 0;
    ivwave_bytes_per_sec    = nch * (bps >> 3) * srate;
    ivwave_paused           = 0;
    
    /*
     * set up buffer pointers
     */
    for(i = 0; i < ivwave_config_current.block_count; i++) {
        ivwave_headers[i].lpData = buffer + (sizeof(WAVEHDR) * ivwave_config_current.block_count) + (i * ivwave_config_current.block_size);
        ivwave_headers[i].dwBufferLength = ivwave_config_current.block_size;
    }
 
    /*
     * now actually set volume and pan in case they've been
     * set before the device was open
     */
    ivwave_set_pan(ivwave_pan);
    ivwave_set_volume(ivwave_volume);
        
    /*
     * return max amount of time it'll take to play through the buffer in ms
     * the +1 is a safety margin which adds approximately the time to play 1 
     * block to the total.
     */
    return MulDiv((ivwave_config_current.block_count + 1) * ivwave_config_current.block_size, 1000, ivwave_bytes_per_sec);
}

/*
 * ivwave_close - close the device if it is open. calling this with
 * the device closed will trigger an assert failure in debug mode.
 */
static void ivwave_close(void)
{
    int i;

    assert(ivwave_device != NULL);

    /*
     * unpause if paused
     */
    if(ivwave_paused) {
        waveOutRestart(ivwave_device);
        ivwave_paused = 0;
    }

    /*
     * reset the device
     */
    waveOutReset(ivwave_device);

    /*
     * wait for all buffers to complete
     */
    while(ivwave_free_headers != ivwave_config_current.block_count)
        Sleep(10);

    /* 
     * unprepare any prepared headers
     */
    for(i = 0; i < ivwave_config_current.block_count; i++) {
        if(ivwave_headers[i].dwFlags & WHDR_PREPARED)
            waveOutUnprepareHeader(ivwave_device, &ivwave_headers[i], sizeof(WAVEHDR));
    }

    DeleteCriticalSection(&ivwave_critical_section);

    /*
     * close the device
     */
    waveOutClose(ivwave_device);
    ivwave_device = NULL;

    /*
     * and finally free the used memory
     */
    HeapFree(GetProcessHeap(), 0, ivwave_headers);
    ivwave_headers = NULL;
}

/*
 * ivwave_write - this will actually block if you write too much
 * but the input plug-in should be smart enough to realise that it
 * should write 
 * a) no more than 8192 bytes and
 * b) no more than ivwave_can_write() returns. 
 * we could add another size check here but it's not really worth it.
 */
static int ivwave_write(void* buffer, int size)
{
    WAVEHDR* current;
    int remain;
    char* buf = (char*)buffer;

    assert(ivwave_device);
    assert(size <= 8192);

    current = &ivwave_headers[ivwave_current_header];

    assert(current);
    
    ivwave_written += size;
    
    while(size > 0) {
        /* 
         * first make sure the header we're going to use is unprepared
         */
        if(current->dwFlags & WHDR_PREPARED) 
            waveOutUnprepareHeader(ivwave_device, current, sizeof(WAVEHDR));

        if(size < (int)(ivwave_config_current.block_size - current->dwUser)) {
            memcpy(current->lpData + current->dwUser, buf, size);
            current->dwUser += size;
            
            break;
        }

        remain = ivwave_config_current.block_size - current->dwUser;
        memcpy(current->lpData + current->dwUser, buf, remain);
        size -= remain;
        buf += remain;
        current->dwBufferLength = ivwave_config_current.block_size;

        //ivwave_written += ivwave_config_current.block_size;
       
        waveOutPrepareHeader(ivwave_device, current, sizeof(WAVEHDR));
        waveOutWrite(ivwave_device, current, sizeof(WAVEHDR));
        
        /*
         * writing to ivwave_free_headers must be encased in 
         * Enter/LeaveCriticalSection calls since two different
         * threads write to it (reading should be ok though).
         */
        EnterCriticalSection(&ivwave_critical_section);
        ivwave_free_headers--;
        LeaveCriticalSection(&ivwave_critical_section);
        
        while(!ivwave_free_headers)
            Sleep(10);

        ivwave_current_header++;
        ivwave_current_header %= ivwave_config_current.block_count;

        current = &ivwave_headers[ivwave_current_header];
        current->dwUser = 0;
    }

    return 0;   
}

/*
 * ivwave_can_write - return number of bytes that can be written - 
 * 0 if device is closed - note that this can be called before playback
 * has been started.
 */
static int ivwave_can_write(void)
{
    WAVEHDR* current = &ivwave_headers[ivwave_current_header];

    if(!ivwave_device)
        return 0;
    
    return ivwave_free_headers * ivwave_config_current.block_size - current->dwUser;
}

/*
 * ivwave_playing - returns 1 if blocks are currently submitted
 * to the wave functions.
 */
static int ivwave_playing(void)
{
    if(!ivwave_device)
        return 0;

    return (ivwave_free_headers != ivwave_config_current.block_count);
}

/*
 * ivwave_pause - pause or resume playback
 */
static int ivwave_pause(int pause)
{
    assert(ivwave_device);
    
    if(pause) {
        waveOutPause(ivwave_device);
        ivwave_paused = 1;
    }
    else {
        waveOutRestart(ivwave_device);
        ivwave_paused = 0;
    }

    return !pause;
}

/*
 * ivwave_set_volume - set the volume (volume ranges from 0->255)
 */
static void ivwave_set_volume(int volume)
{
    unsigned short left;
    unsigned short right;

    /*
     * out of range so do the default (use what the system is set to)
     */
    if(volume < 0 || volume > 255) {
        return;
    }

    ivwave_volume = volume;

    /*
     * ivwave_set_volume can be called before the device
     * is open for defaults so check now.
     */ 
    if(!ivwave_device)
        return;
    
    if(ivwave_config_current.volume_enabled) {
        volume = volume * 0xffff / 0xff;
        left = (unsigned short)volume;
        right = (unsigned short)volume;
    
        /*
         * compensate for the pan setting
         */
        if(ivwave_pan > 0)
            left -= ivwave_pan * volume / 128;
        else if(ivwave_pan < 0)
            right -= -ivwave_pan * volume / 128;
                    
        /* 
         * and actually set the volume
         */
        if(ivwave_config_current.reverse_balance)
            waveOutSetVolume(ivwave_device, (right & 0xffff) | ((left & 0xffff) << 16));
        else
            waveOutSetVolume(ivwave_device, (left & 0xffff) | ((right & 0xffff) << 16));
    }
}

/*
 * ivwave_set_pan - set the pan (pan ranges from -128 to +128)
 */
static void ivwave_set_pan(int pan)
{
    /*
     * out of range so do the default (centre)
     */
    if(pan < -128 || pan > 128) {
        ivwave_pan = 0;
        return;
    }

    ivwave_pan = pan;

    /* 
     * ivwave_set_pan can be called before the
     * device is opened for setting the defaults
     */
    if(!ivwave_device)
        return;

    /*
     * windows waveOut uses waveOutSetVolume to set l&r
     * volumes together so leave the volume setter to deal
     * with it.
     */
    ivwave_set_volume(ivwave_volume);
}

/*
 * ivwave_flush - flush output buffers and continue playback from
 * 'time'.
 */
static void ivwave_flush(int time)
{
    WAVEHDR* current;
    assert(ivwave_device);

    current = &ivwave_headers[ivwave_current_header];
    
    /*
     * if the current buffer has some data in it then write it
     * anyway.
     */
    if(current->dwUser) {
        current->dwBufferLength = current->dwUser;
        current->dwUser = 0;
        
        waveOutPrepareHeader(ivwave_device, current, sizeof(WAVEHDR));
        waveOutWrite(ivwave_device, current, sizeof(WAVEHDR));
        
        EnterCriticalSection(&ivwave_critical_section);
        ivwave_free_headers--;
        LeaveCriticalSection(&ivwave_critical_section);
    }

    /*
     * reset the device - take note that the microsoft documentation
     * states that calling other waveOut functions from the callback
     * will cause a deadlock - well calling waveOutUnprepare header
     * doesn't until you call waveOutReset, at which point the app
     * will freeze (hence the lame arse implementation here).
     */
    waveOutReset(ivwave_device);
    
    /*
     * wait for all buffers to be returned by the reset
     */ 
    while(ivwave_free_headers != ivwave_config_current.block_count)
        Sleep(10);

    /*
     * point to the next block
     */
    ivwave_current_header++;
    ivwave_current_header %= ivwave_config_current.block_count;
    /*
     * reset positioning/statistics variables
     */
    ivwave_output = 0;
    ivwave_written = 0;
    ivwave_pos = time;

    /*
     * playback can now continue
     */
}

/*
 * ivwave_get_output_time - return the number of milliseconds of
 * audio that have actually been played.
 */
static int ivwave_get_output_time(void)
{
    MMTIME time;
    
    if(!ivwave_device)
        return 0;
    
    /*
     * want time in bytes as this is the most accurate
     */
    time.wType = TIME_BYTES;
    
    if(waveOutGetPosition(ivwave_device, &time, sizeof(MMTIME)) == MMSYSERR_NOERROR) {
        /*
         * waveOutGetPosition apparently can return any type of time it
         * feels like if the one you specified wasn't good enough for 
         * it... sorry, "not supported".
         */
        switch(time.wType) {
        case TIME_BYTES:
            return ivwave_pos + MulDiv(time.u.cb, 1000, ivwave_bytes_per_sec);
        case TIME_MS:
            return ivwave_pos + time.u.ms;
        case TIME_SAMPLES:
            return ivwave_pos + MulDiv(time.u.sample, 1000, ivwave_format.srate);
        default:
            break;
        }
    }

    /*
     * worst case - return our own stored value of the time. this value is
     * only accurate to the nearest block and is incremented in the callback
     * function. using this with particularly large blocks (ie > 8k) will 
     * cause the internal vis to become jumpy, ideally we want the above
     * to work.
     */
    return ivwave_pos + MulDiv(ivwave_output, 1000, ivwave_bytes_per_sec);
}

/*
 * ivwave_get_written_time - return the number of milliseconds of
 * audio that have been written to this plug-in but not necessarily
 * played (could be still buffered).
 */
static int ivwave_get_written_time(void)
{
    if(!ivwave_device)
        return 0;
    
    return ivwave_pos + MulDiv(ivwave_written, 1000, ivwave_bytes_per_sec);
}

/*
 * waveOut callback - don't call at all, ever. this is called by 
 * the windows waveOut subsystem thingy. and guess what - you really
 * can't call waveOut functions from this without deadlocking the
 * system (at some point). accurate MS documentation...
 *
 * it would be brilliant to be able to call waveOutUnprepareHeader here
 * since all headers passed to this have been played and are thus prepared.
 * the fact that you can't effectively renders using a callback function 
 * useless (well, almost).
 */
static void CALLBACK ivwave_waveout_callback(HWAVEOUT device, UINT msg, DWORD inst, DWORD parm1, DWORD parm2)
{
    WAVEHDR* current = (WAVEHDR*)parm1;
    
    if(msg == WOM_DONE) {
        assert(current);

        /*
         * we've now played current->dwBufferLength more bytes
         */
        ivwave_output += current->dwBufferLength;
        /*
         * update the number of free headers
         */
        EnterCriticalSection(&ivwave_critical_section);
        ivwave_free_headers++;
        LeaveCriticalSection(&ivwave_critical_section);
    }
}

/*
 * exported function - returns the address of the plug-in structure.
 */
Out_Module* winampGetOutModule(void)
{
    return &ivwave;
}

/*
 * ivwave_get_statistics - get some stats on the current playback
 */
void ivwave_get_statistics(stats_t* stats)
{
    assert(stats);

    stats->active = ivwave_playing();
    stats->block_count = ivwave_config_current.block_count;
    stats->block_usage = ivwave_config_current.block_count - ivwave_free_headers;
    stats->bytes_played = ivwave_output;
    stats->bytes_written = ivwave_written;
    stats->total_buffer_size = ivwave_config_current.block_count * ivwave_config_current.block_size;
    stats->total_buffer_usage = stats->total_buffer_size - ivwave_can_write();
    stats->latency = ivwave_get_written_time() - ivwave_get_output_time();
    stats->start_position = ivwave_pos;
    stats->block_size = ivwave_config_current.block_size;
    stats->format = ivwave_format;
}

/*
 * get the master configuration
 */
void ivwave_get_config(config_t* config)
{
    assert(config);
    *config = ivwave_config_master;
}

/*
 * set the master configuration
 */
void ivwave_set_config(const config_t* config)
{
    assert(config);
    ivwave_config_master = *config;
}
