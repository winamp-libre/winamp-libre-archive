/*
 * Insomnia Visions waveOut Plug-in for Winamp 2.xx
 * ------------------------------------------------
 * Copyright (C)2002 David Overton <david@insomniavisions.com>
 *
 * This program is free software. Permission is granted to 
 * redistribute it or modify it provided that this header
 * remains in each file and the origin of this code is not
 * misrepresented. Modified binary distributions must also
 * be distributed with this licence agreement.
 *
 * This program is distributed without warrenty of any kind
 * and is not guaranteed to work on any system. You use this
 * program entirely at your own risk.
 */

#include <windows.h>
#include "opt.h"

#ifdef _DEBUG
BOOL APIENTRY DllMain(
    HANDLE instance, 
    DWORD reason, 
    LPVOID reserved
)
#else
BOOL APIENTRY _DllMainCRTStartup(
    HANDLE instance, 
    DWORD reason, 
    LPVOID reserved
)
#endif
{
    if(reason == DLL_PROCESS_ATTACH)
        DisableThreadLibraryCalls(instance);

    return TRUE;
}

