//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by out_ivwave.rc
//
#define IDC_DEFAULTS                    3
#define IDD_CONFIGDLG                   101
#define IDC_COMBO_DEVICE                1000
#define IDC_CHECK_VOLUME                1001
#define IDC_CHECK_BALANCE               1002
#define IDC_SLIDER_SIZE                 1003
#define IDC_SLIDER_COUNT                1004
#define IDC_PROGRESS_USAGE              1005
#define IDC_LABEL_TOTAL                 1006
#define IDC_LABEL_BLOCKS                1007
#define IDC_LABEL_WRITTEN               1008
#define IDC_LABEL_PLAYED                1009
#define IDC_LABEL_START                 1010
#define IDC_LABEL_LATENCY               1011
#define IDC_LABEL_SIZE                  1012
#define IDC_LABEL_COUNT                 1013
#define IDC_LABEL_FORMAT                1014
#define IDC_LABEL_CONV                  1015
#define IDC_CHECK_DOWNMIX               1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
