/*
 * Insomnia Visions waveOut Plug-in for Winamp 2.xx
 * ------------------------------------------------
 * Copyright (C)2002 David Overton <david@insomniavisions.com>
 *
 * This program is free software. Permission is granted to 
 * redistribute it or modify it provided that this header
 * remains in each file and the origin of this code is not
 * misrepresented. Modified binary distributions must also
 * be distributed with this licence agreement.
 *
 * This program is distributed without warrenty of any kind
 * and is not guaranteed to work on any system. You use this
 * program entirely at your own risk.
 */

#include <windows.h>
#include <commctrl.h>
#include <assert.h>
#include "plugin.h"
#include "resource.h"
#include "opt.h"

#define DEFAULT_BLOCK_SIZE_INDEX 7
#define DEFAULT_BLOCK_COUNT_INDEX 6
#define WM_UPDATE_DISPLAY (WM_USER + 3)

/*
 * dialog temporary config
 */
static config_t dialog_config;

/*
 * conversion tables for sliders/values
 */ 
static int size_table[] = { 
    65536, 49170, 32768, 24576, 16384, 8192, 6144, 4096, 2048, 1024 
};
static int count_table[] = { 
    50, 40, 35, 30, 25, 20, 15, 10, 5, 2 
};

/*
 * convert slider value to a block size 
 */
static int index_to_block_size(int value) 
{
    if(value < 0)
        return size_table[0];
    if(value > 9)
        return size_table[9];

    return size_table[value];
}

/*
 * convert slider value to block count
 */
static int index_to_block_count(int value)
{
    if(value < 0)
        return count_table[0];
    if(value > 9)
        return count_table[9];

    return count_table[value];
}

/* 
 * convert block count to slider value
 */
static int block_count_to_index(int value) 
{
    int i;

    for(i=0;i<sizeof(count_table)/sizeof(count_table[0]);i++) {
        if(value == count_table[i])
            return i;
    }

    return DEFAULT_BLOCK_COUNT_INDEX;
}

/*
 * convert block size to slider value
 */
static int block_size_to_index(int value)
{
    int i;

    for(i=0;i<sizeof(size_table)/sizeof(size_table[0]);i++) {
        if(value == size_table[i])
            return i;
    }

    return DEFAULT_BLOCK_SIZE_INDEX;
} 

/*
 * dialog procedure for the configuration
 */ 
BOOL CALLBACK config_dialog_proc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    stats_t stats;
    static int timer_slow = 0;
    int i;
    int j;

    switch(uMsg) {
    case WM_INITDIALOG: {
        /*
         * initialise controls and set their respective ranges etc.
         */
        ivwave_get_config(&dialog_config);

        /*
         * fill the combo with the wave devices
         */
        i = (int)waveOutGetNumDevs();
        SendDlgItemMessage(hDlg, IDC_COMBO_DEVICE, CB_ADDSTRING, 0, (LONG)"Wave Mapper");
        for(j = 0; j < i; j++) {
            WAVEOUTCAPS woc;
            waveOutGetDevCaps(j, &woc, sizeof(WAVEOUTCAPS));
            SendDlgItemMessage(hDlg, IDC_COMBO_DEVICE, CB_ADDSTRING, 0, (LONG)woc.szPname);
        }
        
        /*
         * update the controls
         */
        SendMessage(hDlg, WM_UPDATE_DISPLAY, 0, 0);
            
        /*
         * begin stats update timer
         */
        timer_slow = 0;
        SetTimer(hDlg, 101, 100, NULL);
        break;
    }
    case WM_VSCROLL:
        if(LOWORD(wParam) >= TB_THUMBTRACK && LOWORD(wParam) <= TB_ENDTRACK) {
            char buf[64];
            
            dialog_config.block_size  = index_to_block_size(SendDlgItemMessage(hDlg, IDC_SLIDER_SIZE, TBM_GETPOS, 0, 0));
            dialog_config.block_count = index_to_block_count(SendDlgItemMessage(hDlg, IDC_SLIDER_COUNT, TBM_GETPOS, 0, 0));

            if((HWND)lParam == GetDlgItem(hDlg, IDC_SLIDER_SIZE)) {
                wsprintf(buf, "%d kB", dialog_config.block_size >> 10);
                SendDlgItemMessage(hDlg, IDC_LABEL_SIZE, WM_SETTEXT, 0, (LPARAM)buf);
            }
            else {
                wsprintf(buf, "%d", dialog_config.block_count);
                SendDlgItemMessage(hDlg, IDC_LABEL_COUNT, WM_SETTEXT, 0, (LPARAM)buf);
            }
        }
        break;
    case WM_TIMER: {
        char buffer[64];

        ivwave_get_statistics(&stats);

        wsprintf(buffer, "%d kB (%d x %d kB)", stats.total_buffer_size/1024, stats.block_count, stats.block_size / 1024);
        SendDlgItemMessage(hDlg, IDC_LABEL_TOTAL, WM_SETTEXT, 0, (LPARAM)buffer);
        wsprintf(buffer, "%d/%d", stats.block_usage, stats.block_count);
        SendDlgItemMessage(hDlg, IDC_LABEL_BLOCKS, WM_SETTEXT, 0, (LPARAM)buffer);
        
        if(stats.active) {
            wsprintf(buffer, "%d", stats.bytes_written);
            SendDlgItemMessage(hDlg, IDC_LABEL_WRITTEN, WM_SETTEXT, 0, (LPARAM)buffer);
            wsprintf(buffer, "%d", stats.bytes_played);
            SendDlgItemMessage(hDlg, IDC_LABEL_PLAYED, WM_SETTEXT, 0, (LPARAM)buffer);
            wsprintf(buffer, "%d ms", stats.start_position);
            SendDlgItemMessage(hDlg, IDC_LABEL_START, WM_SETTEXT, 0, (LPARAM)buffer);
            wsprintf(buffer, "%d ms", stats.latency);
            SendDlgItemMessage(hDlg, IDC_LABEL_LATENCY, WM_SETTEXT, 0, (LPARAM)buffer);
            wsprintf(buffer, "%d Hz, %dbit, %dch", stats.format.srate, stats.format.bps, stats.format.nch);
            SendDlgItemMessage(hDlg, IDC_LABEL_FORMAT, WM_SETTEXT, 0, (LPARAM)buffer);
            SendDlgItemMessage(hDlg, IDC_LABEL_CONV, WM_SETTEXT, 0, (LPARAM)(stats.format.conv ? "Active" : "Inactive"));
            SendDlgItemMessage(hDlg, IDC_PROGRESS_USAGE, PBM_SETRANGE32, 0, stats.total_buffer_size);
            SendDlgItemMessage(hDlg, IDC_PROGRESS_USAGE, PBM_SETPOS  , stats.total_buffer_usage, 0);
            
            if(timer_slow) {
                KillTimer(hDlg, 101);
                SetTimer(hDlg, 101, 100, NULL);
                timer_slow = 0;
            }
        }
        else {
            SendDlgItemMessage(hDlg, IDC_LABEL_WRITTEN, WM_SETTEXT, 0, (LPARAM)"0");
            SendDlgItemMessage(hDlg, IDC_LABEL_PLAYED, WM_SETTEXT, 0, (LPARAM)"0");
            SendDlgItemMessage(hDlg, IDC_LABEL_START, WM_SETTEXT, 0, (LPARAM)"0 ms");
            SendDlgItemMessage(hDlg, IDC_LABEL_LATENCY, WM_SETTEXT, 0, (LPARAM)"(Inactive)");
            SendDlgItemMessage(hDlg, IDC_LABEL_FORMAT, WM_SETTEXT, 0, (LPARAM)"(Inactive)");
            SendDlgItemMessage(hDlg, IDC_LABEL_CONV, WM_SETTEXT, 0, (LPARAM)"(Inactive)");
            SendDlgItemMessage(hDlg, IDC_PROGRESS_USAGE, PBM_SETPOS , 0, 0);

            if(!timer_slow) {
                KillTimer(hDlg, 101);
                SetTimer(hDlg, 101, 1000, NULL);
                timer_slow = 1;
            }
        }
        break;
    }
    /*
     * update display
     */
    case WM_UPDATE_DISPLAY:
        
        SendDlgItemMessage(hDlg, IDC_SLIDER_SIZE, TBM_SETRANGE, TRUE, MAKELONG(0, 9));
        SendDlgItemMessage(hDlg, IDC_SLIDER_COUNT, TBM_SETRANGE, TRUE, MAKELONG(0, 9));
        /*
         * set up controls based on config
         */
        SendDlgItemMessage(hDlg, IDC_COMBO_DEVICE, CB_SETCURSEL, dialog_config.device + 1, 0);
        SendDlgItemMessage(hDlg, IDC_SLIDER_SIZE, TBM_SETPOS, TRUE, block_size_to_index(dialog_config.block_size));
        SendDlgItemMessage(hDlg, IDC_SLIDER_COUNT, TBM_SETPOS, TRUE, block_count_to_index(dialog_config.block_count));
        SendDlgItemMessage(hDlg, IDC_CHECK_VOLUME, BM_SETCHECK, dialog_config.volume_enabled ? BST_CHECKED : BST_UNCHECKED, 0);
        SendDlgItemMessage(hDlg, IDC_CHECK_BALANCE, BM_SETCHECK, dialog_config.reverse_balance ? BST_CHECKED : BST_UNCHECKED, 0);
        SendDlgItemMessage(hDlg, IDC_CHECK_DOWNMIX, BM_SETCHECK, dialog_config.pcmconv_enabled ? BST_CHECKED : BST_UNCHECKED, 0);

        /*
         * update slider labels. yes this is a hack.
         */
        SendMessage(hDlg, WM_VSCROLL, TB_ENDTRACK, (LPARAM)GetDlgItem(hDlg, IDC_SLIDER_SIZE));
        SendMessage(hDlg, WM_VSCROLL, TB_ENDTRACK, (LPARAM)GetDlgItem(hDlg, IDC_SLIDER_COUNT));
        break;
    case WM_COMMAND:
        switch(LOWORD(wParam)) {
        case IDOK:
            /*
             * grab some various control states and save them back to our config struct
             */
            dialog_config.volume_enabled = SendDlgItemMessage(hDlg, IDC_CHECK_VOLUME, BM_GETCHECK, 0, 0) == BST_CHECKED ? 1 : 0;
            dialog_config.reverse_balance = SendDlgItemMessage(hDlg, IDC_CHECK_BALANCE, BM_GETCHECK, 0, 0) == BST_CHECKED ? 1 : 0;
            dialog_config.device = SendDlgItemMessage(hDlg, IDC_COMBO_DEVICE, CB_GETCURSEL, 0, 0) - 1;
            dialog_config.pcmconv_enabled = SendDlgItemMessage(hDlg, IDC_CHECK_DOWNMIX, BM_GETCHECK, 0, 0) == BST_CHECKED ? 1 : 0;

            /*
             * push the config struct back at the plugin. changes are updated when playback is next
             * started/restarted.
             */
            ivwave_set_config(&dialog_config);
            config_save(&dialog_config);
        case IDCANCEL:
            KillTimer(hDlg, 101);
            EndDialog(hDlg, LOWORD(wParam));
            break;
        case IDC_DEFAULTS:
            if(MessageBox(hDlg, "Are you sure you want to reset to the default settings?", "waveOut Configuration", MB_YESNO|MB_ICONQUESTION) == IDYES) {
                config_set_defaults(&dialog_config);
                SendMessage(hDlg, WM_USER + 3, 0 ,0);
            }
            break;
        default:
            return FALSE;
        }
    default:
        return FALSE;
    }

    return TRUE;
}

/*
 * get name of configuration file
 */
void config_get_filename(char* buffer, int size)
{
	char* p;

    assert(buffer);
    
    memset(buffer, 0, size);

    GetModuleFileName(NULL, buffer, size);
    p = buffer + lstrlen(buffer);

	while(p >= buffer && *p != '.') 
        p--;
    
    lstrcpy(p, ".ini");
}

/*
 * load configuration from a file and fill config with it
 */
int config_load(config_t* config)
{
    char buffer[MAX_PATH];

    assert(config);

    config_get_filename(buffer, sizeof(buffer));

    return GetPrivateProfileStruct("out_ivwave", "config", config, sizeof(config_t), buffer);
}

/*
 * save configuration to a file from config.
 */
void config_save(const config_t* config)
{
    char buffer[MAX_PATH];

    assert(config);

    config_get_filename(buffer, sizeof(buffer));
    WritePrivateProfileStruct("out_ivwave", "config", (void*)config, sizeof(config_t), buffer);
}

/*
 * fill config with the default settings
 */
void config_set_defaults(config_t* config)
{
    assert(config);
    config->block_count = IVWAVE_BLOCK_COUNT;
    config->block_size = IVWAVE_BLOCK_SIZE;
    config->device = -1;
    config->reverse_balance = 0;
    config->volume_enabled = 1;
    config->pcmconv_enabled = 1;
}
