#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <msacm.h>
#include <shlobj.h>
#include <shlobj.h>
#include "out.h"
#include "frontend.h"
#include "resource.h"

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "msacm32.lib")

#define BUFFERSIZE 16384

void Config(HWND);
void About(HWND);
void Init();
void Quit();
int Open(int, int, int, int, int);
void Close();
int Write(char*, int);
int CanWrite();
int IsPlaying();
int Pause(int);
void SetVolume(int);
void SetPan(int);
void Flush(int);
int GetOutputTime();
int GetWrittenTime();

unsigned short gnChannels;
long gnSamplesPerSec;
long gnAvgBytesPerSec;

Out_Module ThisModule =
{
    OUT_VER,
    "MP3 output plug-in 0.1",
    128,
    NULL,
    NULL,
    Config,
    About,
    Init,
    Quit,
    Open,
    Close,
    Write,
    CanWrite,
    IsPlaying,
    Pause,
    SetVolume,
    SetPan,
    Flush,
    GetOutputTime,
    GetWrittenTime
};

HINSTANCE    hDllInstance = NULL;
LPCTSTR      lpAppName = "MP3 output plug-in";
LPCTSTR      lpFileName = "winamp.ini";
HACMDRIVER had = NULL;
HACMSTREAM   has = NULL;
LPWAVEFORMATEX wfxOutput;
WAVEFORMATEX wfxInput;
LPBYTE       pbDst = NULL;
DWORD        cbDstLength;
DWORD        nSongStartTime;
double		 nOutputTime = 0;
double		 nWrittenTime = 0;
char szDir[MAX_PATH];
HANDLE hFile = NULL;
OFSTRUCT ofFile;

typedef struct
{
	HACMDRIVERID hadid;
	WORD wFormatTag;
} FIND_DRIVER_INFO;


void ErrorHandler(LPCSTR Function, MMRESULT ErrorCode)
{
	char Buff[2056];
	wsprintf(Buff, "Function %s failed with code %d", Function, ErrorCode);
	MessageBox(ThisModule.hMainWindow, Buff, "Recording Failure", MB_OK);
}

long IndexToBitRate(long BitRateIndex)
{
	switch(BitRateIndex)
	{
	case 0:
		return 1000;
	case 1:
		return 2000;
	case 2:
		return 2250;
	case 3:
		return 2500;
	case 4:
		return 3000;
	case 5:
		return 4000;
	case 6:
		return 6000;
	case 7:
		return 7000;
	case 8:
		return 8000;
	case 9:
		return 12000;
	case 10:
		return 12000;
	case 11:
		return 16000;
	case 12:
		return 20000;
	case 13:
		return 24000;
	case 14:
	default:
		return 32000;
	}
}

long BitRateToIndex(long BitRate)
{
	switch(BitRate)
	{
	case 1000:
		return 0;
	case 2000:
		return 1;
	case 2250:
		return 2;
	case 2500:
		return 3;
	case 3000:
		return 4;
	case 4000:
		return 5;
	case 6000:
		return 6;
	case 7000:
		return 7;
	case 8000:
		return 8;
	case 12000:
		return 9;
	case 14000:
		return 10;
	case 16000:
		return 11;
	case 20000:
		return 12;
	case 24000:
		return 13;
	case 32000:
	default:
		return 14;
	}
}

long IndexToSampleRate(long SampleIndex)
{
	switch(SampleIndex)
	{
	case 0:
		return 8000;
	case 1:
		return 11025;
	case 2:
		return 12000;
	case 3:
		return 16000;
	case 4:
		return 22050;
	case 5:
		return 24000;
	case 6:
		return 32000;
	case 7:
		return 44100;
	case 8:
	default:
		return 48000;
	}
}

long SampleRateToIndex(long SampleRate)
{
	switch(SampleRate)
	{
	case 8000:
		return 0;
	case 11025:
		return 1;
	case 12000:
		return 2;
	case 16000:
		return 3;
	case 22050:
		return 4;
	case 24000:
		return 5;
	case 32000:
		return 6;
	case 44100:
		return 7;
	case 48000:
	default:
		return 8;
	}
}

// callback function for format enumeration
BOOL CALLBACK find_format_enum(HACMDRIVERID hadid, LPACMFORMATDETAILS pafd, DWORD dwInstance, DWORD fdwSupport)
{
	FIND_DRIVER_INFO* pdi = (FIND_DRIVER_INFO*) dwInstance;
	if (pafd->dwFormatTag == (DWORD)pdi->wFormatTag)
	{
		// found it
		pdi->hadid = hadid;
		return FALSE; // stop enumerating
	}

	return TRUE; // continue enumerating
}

BOOL CALLBACK find_format_enum2(HACMDRIVERID hadid, LPACMFORMATDETAILS pafd, DWORD dwInstance, DWORD fdwSupport)
{
	FIND_DRIVER_INFO* pdi = (FIND_DRIVER_INFO*) dwInstance;
	if (pafd->dwFormatTag == (DWORD)pdi->wFormatTag &&
		pafd->pwfx->nChannels == 1 &&
		pafd->pwfx->nSamplesPerSec == 11025)
	{
		// found it
		pdi->hadid = hadid;
		return FALSE; // stop enumerating
	}

	return TRUE; // continue enumerating
}

// callback function for driver enumeration
BOOL CALLBACK find_driver_enum(HACMDRIVERID hadid, DWORD dwInstance, DWORD fdwSupport)
{
	FIND_DRIVER_INFO* pdi = (FIND_DRIVER_INFO*) dwInstance;
	DWORD dwSize = 0;
	ACMFORMATDETAILS fd;

	// open the driver
	HACMDRIVER had = NULL;
	MMRESULT mmr = acmDriverOpen(&had, hadid, 0);
	WAVEFORMATEX* pwf = NULL;
	if (mmr) {

		// some error
		return FALSE; // stop enumerating

	}

	// enumerate the formats it supports
	mmr = acmMetrics((HACMOBJ)had, ACM_METRIC_MAX_SIZE_FORMAT, &dwSize);
	if (dwSize < sizeof(WAVEFORMATEX)) dwSize = sizeof(WAVEFORMATEX); // for MS-PCM
	pwf = (WAVEFORMATEX*) malloc(dwSize);
	memset(pwf, 0, dwSize);
	pwf->cbSize = LOWORD(dwSize) - sizeof(WAVEFORMATEX);
	pwf->wFormatTag = pdi->wFormatTag;
	memset(&fd, 0, sizeof(fd));
	fd.cbStruct = sizeof(fd);
	fd.pwfx = pwf;
	fd.cbwfx = dwSize;
	fd.dwFormatTag = pdi->wFormatTag;
	mmr = acmFormatEnum(had, &fd, find_format_enum, (DWORD)(VOID*)pdi, 0);  
	free(pwf);
	acmDriverClose(had, 0);
	if (pdi->hadid || mmr) {
		// found it or some error
		return FALSE; // stop enumerating
	}

	return TRUE; // continue enumeration
}

// locate the first driver that supports a given format tag
HACMDRIVERID find_driver(WORD wFormatTag)
{
	FIND_DRIVER_INFO fdi;
	MMRESULT mmr;
	fdi.hadid = NULL;
	fdi.wFormatTag = wFormatTag;
	mmr = acmDriverEnum(find_driver_enum, (DWORD)(VOID*)&fdi, 0); 
	if (mmr) return NULL;
	return fdi.hadid;
}

// get a description of the first format supported for a given tag
WAVEFORMATEX* get_driver_format(HACMDRIVERID hadid, WORD wFormatTag)
{
	// open the driver
	DWORD dwSize = 0;
	HACMDRIVER had = NULL;
	WAVEFORMATEX* pwf = NULL;
	ACMFORMATDETAILS fd;
	MMRESULT mmr = acmDriverOpen(&had, hadid, 0);
	FIND_DRIVER_INFO fdi;

	if (mmr)
	{
		return NULL;
	}

	// allocate a structure for the info
	mmr = acmMetrics((HACMOBJ)had, ACM_METRIC_MAX_SIZE_FORMAT, &dwSize);
	if (dwSize < sizeof(WAVEFORMATEX)) dwSize = sizeof(WAVEFORMATEX); // for MS-PCM
	pwf = (WAVEFORMATEX*) malloc(dwSize);
	memset(pwf, 0, dwSize);
	pwf->cbSize = LOWORD(dwSize) - sizeof(WAVEFORMATEX);
	pwf->wFormatTag = wFormatTag;

	memset(&fd, 0, sizeof(fd));
	fd.cbStruct = sizeof(fd);
	fd.pwfx = pwf;
	fd.cbwfx = dwSize;
	fd.dwFormatTag = wFormatTag;

	// set up a struct to control the enumeration
	fdi.hadid = NULL;
	fdi.wFormatTag = wFormatTag;

	mmr = acmFormatEnum(had, &fd, find_format_enum2, (DWORD)(VOID*)&fdi, 0);  
	acmDriverClose(had, 0);
	if ((fdi.hadid == NULL) || mmr) 
	{
		free(pwf);
		return NULL;
	}
	
	return pwf;
}

__declspec(dllexport) Out_Module* winampGetOutModule()
{
    return &ThisModule;
}

BOOL WritePrivateProfileInt(LPCTSTR lpAppName, LPCTSTR lpKeyName, int nInteger, LPCTSTR lpFileName)
{
    TCHAR lpString[1024];

    wsprintf(lpString, "%d", nInteger);
    return WritePrivateProfileString(lpAppName, lpKeyName, lpString, lpFileName);
}

void SaveConfig(HWND hwnd)
{
	gnChannels = ComboBox_GetCurSel(GetDlgItem(hwnd, ID_CHANNELS)) + 1;
	gnSamplesPerSec = IndexToSampleRate(ComboBox_GetCurSel(GetDlgItem(hwnd, ID_SAMPLERATE)));
	gnAvgBytesPerSec = IndexToBitRate(ComboBox_GetCurSel(GetDlgItem(hwnd, ID_BITRATE)));

	WritePrivateProfileInt(lpAppName, "nChannels",      gnChannels,      lpFileName);
    WritePrivateProfileInt(lpAppName, "nSamplesPerSec", gnSamplesPerSec, lpFileName);
    WritePrivateProfileInt(lpAppName, "nAvgBytesPerSec", gnAvgBytesPerSec, lpFileName);
    WritePrivateProfileString(lpAppName, "OutDir", szDir, lpFileName);
}

///////////////////////////////////////////////////////////////////////////////
void Config_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
   switch (id)
   {
   case IDOK:
	  SaveConfig(hwnd);
      EndDialog(hwnd, 0); 
      break;
   case ID_OUTPUTDIR: 
	   {
			BROWSEINFO bi;
			LPITEMIDLIST pIdlList;
			IMalloc* pMalloc;

			CoInitialize(NULL);
			memset(&bi, 0, sizeof(BROWSEINFO));
			bi.hwndOwner = hwnd;
			bi.pszDisplayName = szDir;
			bi.ulFlags = BIF_RETURNONLYFSDIRS;
			bi.lpszTitle = "MP3 Output Directory";

			pIdlList = SHBrowseForFolder(&bi);
			SHGetPathFromIDList(pIdlList, szDir);

			SHGetMalloc(&pMalloc);
			IMalloc_Free(pMalloc, pIdlList);
			IMalloc_Release(pMalloc);

			Button_SetText(GetDlgItem(hwnd, ID_OUTPUTDIR), szDir);

			CoUninitialize();
	   }
      break;
   case IDCANCEL: 
      EndDialog(hwnd, 0); 
      break;
   default:
	   break;
   }
}

BOOL Config_OnInitDlg(HWND hwnd, HWND hwndFocus, LPARAM lParam)
{
	Button_SetText(GetDlgItem(hwnd, ID_OUTPUTDIR), szDir);

	ComboBox_ResetContent(GetDlgItem(hwnd, ID_CHANNELS));
	ComboBox_AddString(GetDlgItem(hwnd, ID_CHANNELS), "Mono");
	ComboBox_AddString(GetDlgItem(hwnd, ID_CHANNELS), "Stereo");
	ComboBox_SetCurSel(GetDlgItem(hwnd, ID_CHANNELS), gnChannels - 1);

	ComboBox_ResetContent(GetDlgItem(hwnd, ID_BITRATE));
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "8 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "16 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "18 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "20 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "24 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "32 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "48 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "56 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "64 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "96 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "112 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "128 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "160 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "192 kBit/s");
	ComboBox_AddString(GetDlgItem(hwnd, ID_BITRATE), "256 kBit/s");
	ComboBox_SetCurSel(GetDlgItem(hwnd, ID_BITRATE), BitRateToIndex(gnAvgBytesPerSec));

	ComboBox_ResetContent(GetDlgItem(hwnd, ID_SAMPLERATE));
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "8 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "11.025 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "12 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "16 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "22.05 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "24 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "32 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "44.1 kHz");
	ComboBox_AddString(GetDlgItem(hwnd, ID_SAMPLERATE), "48 kHz");
	ComboBox_SetCurSel(GetDlgItem(hwnd, ID_SAMPLERATE), SampleRateToIndex(gnSamplesPerSec));

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
BOOL WINAPI Config_DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

   switch (uMsg)
   {
      HANDLE_MSG(hwnd, WM_COMMAND, Config_OnCommand);
      HANDLE_MSG(hwnd, WM_INITDIALOG, Config_OnInitDlg);
   }
   return(FALSE);

}

void Config(HWND hwndParent)
{
	DialogBox(ThisModule.hDllInstance, MAKEINTRESOURCE(IDD_CONFIG),  NULL, Config_DlgProc);
}

void About(HWND hwndParent)
{
}

void Init()
{
    gnChannels = GetPrivateProfileInt(lpAppName, "nChannels", 2,      lpFileName);
    gnSamplesPerSec = GetPrivateProfileInt(lpAppName, "nSamplesPerSec", 44100, lpFileName);
    gnAvgBytesPerSec = GetPrivateProfileInt(lpAppName, "nAvgBytesPerSec", 12000, lpFileName);
	GetPrivateProfileString(lpAppName, "OutDir", "c:\\", szDir, MAX_PATH, lpFileName);
    return;
}

void Quit()
{
}

void ScanForIllegalChars(LPSTR FileName)
{
	while(*FileName != '\0')
	{
		switch(*FileName)
		{
		case ':':
			*FileName = ';';
			break;
		case '\\':
		case '/':
		case '>':
		case '<':
		case '|':
		case '?':
			*FileName = '!';
			break;
		case '\"':
			*FileName = '\'';
			break;
		case '*':
			*FileName = '+';
			break;
		default:
			break;
		}
		++FileName;
	}
}

LPCSTR MakeFileName(LPCSTR InFileName, int Counter)
{
	static char FileName[512];
	char Number[8];
	int StartOfFileName;


	strcpy(FileName, szDir);
	if(szDir[strlen(szDir) - 1] != '\\')
	{
		strcat(FileName, "\\");
	}
	StartOfFileName = strlen(FileName);
	strcat(FileName, InFileName);
	ScanForIllegalChars(FileName + StartOfFileName);
	
	if(strcmp(InFileName + strlen(InFileName) - 4, ".mp3") == 0)
	{
		FileName[strlen(FileName) - 4] = '\0';
	}
	if(Counter > 1)
	{
		strcat(FileName, " - ");
		wsprintf(Number, "%d", Counter);
		strcat(FileName, Number);
	}
	strcat(FileName, ".mp3");
	
	return FileName;
}

int Open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms)
{
	MMRESULT mmr;
	HACMDRIVERID hadid;
	char *Name;
	int Counter = 1;

	if(samplerate != gnSamplesPerSec)
	{
		MessageBox(ThisModule.hMainWindow, "Sample Rates Different", "Open Failure", MB_OK);
		goto error;
	}

	wfxInput.nChannels      = numchannels;
	wfxInput.nSamplesPerSec = samplerate;
	wfxInput.wBitsPerSample = bitspersamp;

	wfxInput.wFormatTag      = WAVE_FORMAT_PCM;
	wfxInput.nBlockAlign     = wfxInput.nChannels * ((wfxInput.wBitsPerSample + 7) >> 3);
	wfxInput.nAvgBytesPerSec = wfxInput.nSamplesPerSec * wfxInput.nBlockAlign;
	wfxInput.cbSize          = 0;

	hadid = find_driver(WAVE_FORMAT_MPEGLAYER3);
	if(hadid == NULL)
	{
		MessageBox(ThisModule.hMainWindow, "No MP3 CODEC Found", "Open Failure", MB_OK);
		goto error;
	}

	wfxOutput = get_driver_format(hadid, WAVE_FORMAT_MPEGLAYER3);
	if(wfxOutput == NULL)
	{
		MessageBox(ThisModule.hMainWindow, "Could not create the format you requested", "Open Failure", MB_OK);
		goto error;
	}

    wfxOutput->nChannels      = gnChannels;
    wfxOutput->nSamplesPerSec = gnSamplesPerSec;
    wfxOutput->nAvgBytesPerSec = gnAvgBytesPerSec;

	wfxOutput->wBitsPerSample = 0;
	wfxOutput->nBlockAlign = 1;

	if((mmr = acmDriverOpen(&had, hadid, 0)) != MMSYSERR_NOERROR)
	{
		ErrorHandler("acmDriverOpen", mmr);
		goto error;
	}

	nOutputTime = 0;
	nWrittenTime = 0;

	if ((mmr = acmStreamOpen(&has, had, &wfxInput, wfxOutput, NULL, 0, 0, ACM_STREAMOPENF_NONREALTIME)) != MMSYSERR_NOERROR)
	{
		ErrorHandler("acmStreamOpen", mmr);
		goto error;
	}
	if (acmStreamSize(has, BUFFERSIZE, &cbDstLength, ACM_STREAMSIZEF_SOURCE) != MMSYSERR_NOERROR)
	{
		ErrorHandler("acmStreamSize", mmr);
		goto error;
	}
	if ((pbDst = (BYTE*)GlobalAllocPtr(GPTR, cbDstLength)) == NULL)
	{
		ErrorHandler("GlobalAllocPtr", 0);
		goto error;
	}


	Name = (char *)SendMessage(ThisModule.hMainWindow,WM_WA_IPC, SendMessage(ThisModule.hMainWindow,WM_WA_IPC,0,IPC_GETLISTPOS),IPC_GETPLAYLISTTITLE);

	hFile = INVALID_HANDLE_VALUE;
	Counter = 1;

	while(Counter < 10 && hFile == INVALID_HANDLE_VALUE)
	{
		hFile = CreateFile(MakeFileName(Name, Counter),
							GENERIC_WRITE,
							FILE_SHARE_READ,
							NULL,
							CREATE_NEW,
							FILE_ATTRIBUTE_NORMAL,
							NULL);
		++Counter;
	}
	if(hFile == INVALID_HANDLE_VALUE)
	{
		MessageBox(ThisModule.hMainWindow, "Could not create a output file", "Open Failure", MB_OK);
		goto error;
	}

	// if we do this the input plug-in will think we are a wave plug-in
	// and let us record
    return 1997;

error:

    if (pbDst != NULL)
	{
		GlobalFreePtr(pbDst);
		pbDst = NULL;
	}

    if (has != NULL)
	{
		acmStreamClose(has, 0);
		has = NULL;
	}

    return -1;
}

void Close()
{
	MMRESULT mmr;
    if (pbDst != NULL) 
	{
		GlobalFreePtr(pbDst);
		pbDst = NULL;
	}

    if (has != NULL)
	{
		mmr = acmStreamClose(has, 0);
		has = NULL;
	}
    if (had != NULL)
	{
		mmr = acmDriverClose(had, 0);
		had = NULL;
	}
	nOutputTime = 0;
	nWrittenTime = 0;
	CloseHandle(hFile);
}

int Write(char* buf, int len)
{
	MMRESULT mmr;
    ACMSTREAMHEADER ash;

	if(len == 0)
	{
		// we sometimes get passed an empty buffer to tell us we have finished
		// so we must reset nOutputTime so that IsPlaying will return FALSE
		nOutputTime = 0;
		nWrittenTime = 0;
		return 0;
	}
	ZeroMemory(&ash, sizeof(ACMSTREAMHEADER));
	ash.cbStruct            = sizeof(ACMSTREAMHEADER);
	ash.pbSrc               = (BYTE*)buf;
	ash.cbSrcLength         = len;
	ash.cbSrcLengthUsed     = len;
	ash.pbDst               = pbDst;
	ash.cbDstLength         = cbDstLength;

	nOutputTime += len * 1000 / wfxInput.nAvgBytesPerSec;

	if ((mmr = acmStreamPrepareHeader(has, &ash, 0)) != MMSYSERR_NOERROR)
	{
		ErrorHandler("acmStreamPrepareHeader", mmr);
		goto error;
	}
	if ((mmr = acmStreamConvert(has, &ash, 0)) != MMSYSERR_NOERROR)
	{
		ErrorHandler("acmStreamConvert", mmr);
		goto error;
	}
	if ((mmr = acmStreamUnprepareHeader(has, &ash, 0)) != MMSYSERR_NOERROR)
	{
		ErrorHandler("acmStreamUnprepareHeader", mmr);
		goto error;
	}

	if(ash.cbDstLengthUsed > 0)
	{
		DWORD bw;
		WriteFile(hFile, ash.pbDst, ash.cbDstLengthUsed, &bw, NULL);
	}

	nWrittenTime += ash.cbDstLengthUsed * 1000 / wfxOutput->nAvgBytesPerSec;

	return 0;

error:
	if (ash.fdwStatus & ACMSTREAMHEADER_STATUSF_PREPARED)
	{
		acmStreamUnprepareHeader(has, &ash, 0);
	}

	return 1;
}

int CanWrite()
{
    DWORD dwOutputBytes;

	if (acmStreamSize(has, BUFFERSIZE, &dwOutputBytes, ACM_STREAMSIZEF_SOURCE) == MMSYSERR_NOERROR)
	{
		return BUFFERSIZE;
	}
	else
	{
		return 0;
	}
}

int IsPlaying()
{
	// this is called to find out if we have finished playing
	// before the input plug-in will call close
    return (nOutputTime != 0);
}

int Pause(int pause)
{
	return pause;
}

void SetVolume(int volume)
{
}

void SetPan(int pan)
{
}

void Flush(int t)
{
}

int GetOutputTime()
{
	return (int)nOutputTime;
}

int GetWrittenTime()
{
	return (int)nWrittenTime;
}

