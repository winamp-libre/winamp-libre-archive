
DWORD	_WaitForSingleObject(const HANDLE hHandle, const DWORD dwMilliseconds = INFINITE);
DWORD	_WaitForSingleObjectEx(
							const HANDLE hHandle,
							const DWORD dwMilliseconds = INFINITE,
							const bool bAlertable = true);

