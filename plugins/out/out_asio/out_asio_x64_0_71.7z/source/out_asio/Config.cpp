
#define	STRICT

#include <windows.h>

#include "out_asio.h"
#include "Config.h"

extern PARAM_GLOBAL	ParamGlobal;

const char*	List_ProcessPriority[] =
{"Normal", "High", "Realtime"};

const char*	List_ThreadPriority[] =
{"Normal", "Above normal", "Highest", "Time critical"};

const int	List_Resampling_SampleRate[] =
{11025, 22050, 24000, 32000, 44100, 48000, 88200, 96000, 176400, 192000};

const char*	List_Resampling_Quality[] =
{"Low", "Normal", "High", "Top", "Ultra"};

DialogOption::DialogOption(const HWND hParentWnd) : SDialog(hParentWnd, IDD_CONFIG)
{
}

DialogOption::~DialogOption(void)
{
	delete Device;
	delete ProcessPriority;
	delete ThreadPriority;
	delete BufferSizeUpDown;
	delete ShiftChannelsUpDown;
	delete GaplessMode;
	delete Convert1chTo2ch;
	delete DirectInputMonitor;
	delete Resampling_Enable;
	delete Resampling_ThreadPriority;
	delete Resampling_SampleRate;
	delete Resampling_Quality;
}

bool
DialogOption::WmInitDialog(Org_Mes* OrgMes, HWND hwnd, LONG lInitParam)
{
	OrgMes->ExecMessage = true;
	SDialog::WmInitDialog(OrgMes, hwnd, lInitParam);

	HWND	hParentParentWindow = ::GetParent(HParentWindow);

	MoveWindowCenter(hParentParentWindow ? hParentParentWindow : HParentWindow);

	Device = new SComboBox(this, IDC_DEVICE);
	ProcessPriority = new SComboBox(this, IDC_PROCESS_PRIORITY);
	ThreadPriority = new SComboBox(this, IDC_THREAD_PRIORITY);
	BufferSizeUpDown = new SUpDown(this, IDC_BUFFER_SIZE_UPDOWN);
	ShiftChannelsUpDown = new SUpDown(this, IDC_SHIFT_CHANNELS_UPDOWN);
	GaplessMode = new SButton(this, IDC_GAPLESS_MODE, BS_CHECKBOX);
	Convert1chTo2ch = new SButton(this, IDC_CONVERT_1CH_TO_2CH, BS_CHECKBOX);
	DirectInputMonitor = new SButton(this, IDC_DIRECT_INPUT_MONITOR, BS_CHECKBOX);
	Resampling_Enable = new SButton(this, IDC_RESAMPLING_ENABLE);
	Resampling_ThreadPriority = new SComboBox(this, IDC_RESAMPLING_THREAD_PRIORITY);
	Resampling_SampleRate = new SComboBox(this, IDC_RESAMPLING_SAMPLE_RATE);
	Resampling_Quality = new SComboBox(this, IDC_RESAMPLING_QUALITY);

	const int	MaxDriver = ParamMsg(0, MSG_GET_NUM_DEVICE).Call();

	for(int Idx = 0; Idx < MaxDriver; Idx++) {
		const int	DriverNameLen = SERVER_INDEX;
		char	DriverName[DriverNameLen];

		ParamMsg(0, MSG_GET_DRIVER_NAME, Idx).Call(DriverName);
		Device->AddString(DriverName);
	}

	Device->SetCurSel(ParamGlobal.Device);

	for(int Idx = 0; Idx < 3; Idx++) {
		ProcessPriority->AddString(List_ProcessPriority[Idx]);
	}

	ProcessPriority->SetCurSel(ParamGlobal.ProcessPriority);

	for(int Idx = 0; Idx < 4; Idx++) {
		ThreadPriority->AddString(List_ThreadPriority[Idx]);
	}

	ThreadPriority->SetCurSel(ParamGlobal.ThreadPriority);

	BufferSizeUpDown->SetRange(0, 63);
	BufferSizeUpDown->SetPos(ParamGlobal.BufferSize);

	ShiftChannelsUpDown->SetRange(0, 99);
	ShiftChannelsUpDown->SetPos(ParamGlobal.ShiftChannels);

	if(ParamGlobal.GaplessMode) {
		GaplessMode->Check();
	}

	if(ParamGlobal.Convert1chTo2ch) {
		Convert1chTo2ch->Check();
	}

	if(ParamGlobal.DirectInputMonitor) {
		DirectInputMonitor->Check();
	}

	if(ParamGlobal.Resampling_Enable) {
		Resampling_Enable->Check();
	}

	for(int Idx = 0; Idx < 4; Idx++) {
		Resampling_ThreadPriority->AddString(List_ThreadPriority[Idx]);
	}

	Resampling_ThreadPriority->SetCurSel(ParamGlobal.Resampling_ThreadPriority);

	for(int Idx = 0; Idx < 10; Idx++) {
		char	StrSampleRate[8];

		_itoa_s(List_Resampling_SampleRate[Idx], StrSampleRate, sizeof StrSampleRate, 10);
		Resampling_SampleRate->AddString(StrSampleRate);

		if(List_Resampling_SampleRate[Idx] == ParamGlobal.Resampling_SampleRate) {
			Resampling_SampleRate->SetCurSel(Idx);
		}
	}

	for(int Idx = 0; Idx < 5; Idx++) {
		Resampling_Quality->AddString(List_Resampling_Quality[Idx]);
	}

	Resampling_Quality->SetCurSel(ParamGlobal.Resampling_Quality);

	return true;
}

void
DialogOption::CmOk(void)
{
	bool	New = false;
	int		Param;

	Param = Device->GetCurSel();
	if(ParamGlobal.Device != Param) {
		ParamGlobal.Device = Param;
		New = true;
	}

	Param = ProcessPriority->GetCurSel();
	if(ParamGlobal.ProcessPriority != Param) {
		ParamGlobal.ProcessPriority = Param;
		New = true;
	}

	Param = ThreadPriority->GetCurSel();
	if(ParamGlobal.ThreadPriority != Param) {
		ParamGlobal.ThreadPriority = Param;
		New = true;
	}

	Param = BufferSizeUpDown->GetPos();
	if(ParamGlobal.BufferSize != Param) {
		ParamGlobal.BufferSize = Param;
		New = true;
	}

	Param = ShiftChannelsUpDown->GetPos();
	if(ParamGlobal.ShiftChannels != Param) {
		ParamGlobal.ShiftChannels = Param;
		New = true;
	}

	Param = GaplessMode->GetCheck() == BF_CHECKED;
	if(ParamGlobal.GaplessMode != Param) {
		ParamGlobal.GaplessMode = Param;
		New = true;
	}

	Param = Convert1chTo2ch->GetCheck() == BF_CHECKED;
	if(ParamGlobal.Convert1chTo2ch != Param) {
		ParamGlobal.Convert1chTo2ch = Param;
		New = true;
	}

	Param = DirectInputMonitor->GetCheck() == BF_CHECKED;
	if(ParamGlobal.DirectInputMonitor != Param) {
		ParamGlobal.DirectInputMonitor = Param;
		New = true;
	}

	Param = Resampling_Enable->GetCheck() == BF_CHECKED;
	if(ParamGlobal.Resampling_Enable != Param) {
		ParamGlobal.Resampling_Enable = Param;
		New = true;
	}

	Param = Resampling_ThreadPriority->GetCurSel();
	if(ParamGlobal.Resampling_ThreadPriority != Param) {
		ParamGlobal.Resampling_ThreadPriority = Param;
		New = true;
	}

	Param = List_Resampling_SampleRate[Resampling_SampleRate->GetCurSel()];
	if(ParamGlobal.Resampling_SampleRate != Param) {
		ParamGlobal.Resampling_SampleRate = Param;
		New = true;
	}

	Param = Resampling_Quality->GetCurSel();
	if(ParamGlobal.Resampling_Quality != Param) {
		ParamGlobal.Resampling_Quality = Param;
		New = true;
	}

	if(New) {
		ParamMsg(
			0,
			MSG_SET_OPTION,
			NULL,
			ParamGlobal.Device,
			ParamGlobal.ProcessPriority,
			ParamGlobal.ThreadPriority,
			ParamGlobal.BufferSize,
			ParamGlobal.ShiftChannels,
			ParamGlobal.GaplessMode,
			ParamGlobal.Convert1chTo2ch,
			ParamGlobal.DirectInputMonitor,
			ParamGlobal.Resampling_Enable,
			ParamGlobal.Resampling_ThreadPriority,
			ParamGlobal.Resampling_SampleRate,
			ParamGlobal.Resampling_Quality).Call();
		ParamMsg(0, MSG_SET_RE_OPEN).Call();
	}

	SDialog::CmOk();
}

