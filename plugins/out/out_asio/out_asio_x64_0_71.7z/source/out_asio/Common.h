
#define	VER								"0.71 AMD64"
#define	NAME							"ASIO output"
#define	NAME2							NAME " (x64 version) v" VER
#define	INI_NAME						"ASIO output (x64 version)"

#define	MAX_PATHLEN						512

#define	DLL_NAME						"out_asio(x64).dll"
#define	EXE_NAME						"out_asio(x64).exe"

#define	COMMON_BUFFER_SIZE				16777216

#define	FILE_MAPPING_COMMON_BUFFER		"out_asio(x64) Common_Buff"

#define	SERVER_INDEX					64

#define	EVENT_SERVER_MSG				"out_asio(x64) Server_Msg"
#define	EVENT_SERVER_RETMSG				"out_asio(x64) Server_RetMsg"
#define	EVENT_SERVER_REALTIME_MSG		"out_asio(x64) Server_RealTime_Msg"
#define	EVENT_SERVER_REALTIME_RETMSG	"out_asio(x64) Server_RealTime_RetMsg"

#define	EVENT_CLIENT_READY_SERVER		"out_asio(x64) Client_ReadyServer"

enum
{
	MSG_GET_NUM_DEVICE,
	MSG_GET_DRIVER_NAME,
	MSG_QUIT,
	MSG_SET_OPTION,
	MSG_SET_RE_OPEN,
	MSG_OPEN,
	MSG_CLOSE,
	MSG_CAN_WRITE,
	MSG_WRITE,
	MSG_IS_PLAYING,
	MSG_PAUSE,
	MSG_FLUSH,
	MSG_GET_OUTPUT_TIME,
	MSG_GET_WRITTEN_TIME,
};

