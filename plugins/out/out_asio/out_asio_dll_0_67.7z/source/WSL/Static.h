
class
SStatic : public SControl
{
public:
	SStatic(SWindow* parent, int id);
	~SStatic(void);
};

