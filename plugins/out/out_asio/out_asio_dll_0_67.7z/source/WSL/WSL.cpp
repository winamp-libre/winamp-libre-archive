
#define	STRICT

#include <windows.h>

#include "WSL.h"

