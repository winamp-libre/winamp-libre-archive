
#define	VER			"0.67"
#define	NAME		"ASIO output (dll version) v" VER
#define	INI_NAME	"ASIO output (dll version)"

