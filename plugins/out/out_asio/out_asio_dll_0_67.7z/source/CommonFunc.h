
//
//  �ėp�֐�(�w�b�_)
//
//  Written by Otachan
//  http://otachan.com/
//

void	CutPathFileName(
					const char* FullFileName,
					char* FileNamePath,
					const size_t FileNamePathSize,
					char* FileName = NULL,
					const size_t FileNameSize = 0);

