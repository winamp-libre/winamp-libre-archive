
void	GetWindowsPlatformType(void);
DWORD	_SignalObjectAndWait(
						const HANDLE hObjectToSignal,
						const HANDLE hObjectToWaitOn,
						const DWORD dwMilliseconds = INFINITE,
						const bool bAlertable = false);

