
#include "OUT.H"
#include "wa_ipc.h"

#include "SignalObjectAndWait.h"
#include "CommonFunc.h"

#include "Common.h"

LRESULT CALLBACK	HookProc(int nCode, WPARAM wParam, LPARAM lParam);

void	ReadProfile(void);
void	WriteProfile(void);

void __cdecl	Config(HWND hwndParent);
void __cdecl	About(HWND hwndParent);
void __cdecl	Init(void);
void __cdecl	Quit(void);
bool	OpenServer(const HWND hParentWnd);
int __cdecl	Open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms);
void __cdecl	Close(void);
int __cdecl	Write(char *buf, int len);
int __cdecl	CanWrite(void);
int __cdecl	IsPlaying(void);
int __cdecl	Pause(int pause);
void __cdecl	SetVolume(int volume);
void __cdecl	SetPan(int pan);
void __cdecl	Flush(int t);
int __cdecl	GetOutputTime(void);
int __cdecl	GetWrittenTime(void);

struct
PARAM_GLOBAL
{
	char	IniFileName[MAX_PATHLEN];
	int		Device;
	int		ProcessPriority;
	int		ThreadPriority;
	int		BufferSize;
	int		ShiftChannels;
	int		GaplessMode;
	int		Convert1chTo2ch;
	int		DirectInputMonitor;
	int		Resampling_Enable;
	int		Resampling_ThreadPriority;
	int		Resampling_SampleRate;
	int		Resampling_Quality;
};

class
ParamMsg
{
public:
	ParamMsg(const int _Index, const int Msg);
	ParamMsg(const int _Index, const int Msg, const int Param1);
	ParamMsg(const int _Index, const int Msg, const int Param1, const int Param2, const int Param3);
	ParamMsg(
		const int _Index,
		const int Msg,
		const HWND Param1,
		const int Param2,
		const int Param3,
		const int Param4,
		const int Param5,
		const int Param6,
		const int Param7,
		const int Param8,
		const int Param9,
		const int Param10,
		const int Param11,
		const int Param12,
		const int Param13);
	ParamMsg(const int _Index, const int Msg, const int Param1, unsigned char* Buff);

	int		Call(void);
	void	Call(char* RetBuff);

private:
	int		Index;

	void	EnterCriticalSection(const int _Index);
};

