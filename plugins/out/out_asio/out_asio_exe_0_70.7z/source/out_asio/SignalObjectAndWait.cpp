
#define	STRICT

#include <windows.h>

#include "SignalObjectAndWait.h"

DWORD	WindowsPlatformId;

void
GetWindowsPlatformType(void)
{
	OSVERSIONINFO	VersionInformation;

	VersionInformation.dwOSVersionInfoSize = sizeof VersionInformation;

	::GetVersionEx(&VersionInformation);

	WindowsPlatformId = VersionInformation.dwPlatformId;
}

DWORD
_SignalObjectAndWait(
				const HANDLE hObjectToSignal,
				const HANDLE hObjectToWaitOn,
				const DWORD dwMilliseconds,
				const bool bAlertable)
{
	DWORD	RetCode;

	if(WindowsPlatformId == VER_PLATFORM_WIN32_NT) {
		RetCode = ::SignalObjectAndWait(hObjectToSignal, hObjectToWaitOn, dwMilliseconds, bAlertable);
	} else {
		::SetEvent(hObjectToSignal);
		RetCode = ::WaitForSingleObject(hObjectToWaitOn, dwMilliseconds);
	}

	return RetCode;
}

