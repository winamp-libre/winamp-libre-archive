+-----------------------------------------------------------------+
|                                                                 |
|                          out_FAAC Readme                        |
|                          ---------------                        |
|                                                                 |
+-----------------------------------------------------------------+

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY.

----------------------------------------------------------------------------

out_AAC is an encoder plugin for Winamp 2 and 5 to export .aac/.mp4 files.

To use it:
----------

1) put FAAC and FAAD2 packages into the same folder;
2) open the project, set "Active Configuration = FAAC - win32 Release" and compile;
3) copy out_AAC.dll into Winamp\plugins folder.

----------------------------------------------------------------------------

For suggestions, bugs report, etc., you can contact me at
ntnfrn_email-temp@yahoo.it
