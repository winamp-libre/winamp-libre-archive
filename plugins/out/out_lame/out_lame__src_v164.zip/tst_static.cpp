// this file is to make a static build of the appli and debug it in the debugger

#if !defined(STRICT)
#define STRICT
#endif // !defined(STRICT)

#include <windows.h>
#include <windowsx.h>

#include "out.h"

#include "tststatic.h"

/////////////

static Out_Module * module = NULL;
extern "C" {
	Out_Module * winampGetOutModule();
}

static INT CALLBACK DialogProc(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
  )
{
	INT bResult = FALSE;

	switch (uMsg) {

		case WM_INITDIALOG:
			if (module != NULL)
			{
				module->hMainWindow = hwndDlg;
				if (module->Init != NULL)
					module->Init();
			}
			break;


		case WM_COMMAND:
			UINT command;
			command = GET_WM_COMMAND_ID(wParam, lParam);
			if ((IDOK == command) || (IDCANCEL == command))
			{
				::EndDialog(hwndDlg, 1);
			}
			else if (IDC_BUTTON_ABOUT == command)
			{
				if (module != NULL)
					module->About(hwndDlg);
			}
			else if (IDC_BUTTON_CONFIG == command)
			{
				if (module != NULL)
					module->Config(hwndDlg);
			}
			else if (IDC_BUTTON_ENCODE == command)
			{
				if (module->Open != NULL)
					// start the encoding
					if (module->Open( 44100, 2, 16, 0, 0 ) != -1)
					{
						// encode some data
						char * fake_buf = (char *) module; // (oh !)
						if (module->Write != NULL)
							for (int i=0;i<20;i++)
								module->Write( fake_buf, 1000);
						// close the encoding
						if (module->Close != NULL)
							module->Close( );
					}
			}
			bResult = FALSE;
			break;

		case WM_CLOSE:
			if (module != NULL && module->Quit != NULL)
				module->Quit();
			break;

		case WM_USER:
			if (lParam == 211)
			{
				SetWindowLong( hwndDlg, DWL_MSGRESULT ,(LPARAM) "c:\\10.mp3");
				bResult = TRUE;
			}
			else if (lParam == 212)
			{
				SetWindowLong( hwndDlg, DWL_MSGRESULT ,(LPARAM) "10.mp3");
				bResult = TRUE;
			}
			break;

	}

	return bResult;
}

int WINAPI WinMain(
  HINSTANCE hInstance,      // handle to current instance
  HINSTANCE hPrevInstance,  // handle to previous instance
  LPSTR lpCmdLine,          // command line
  int nCmdShow              // show state
)
{
	module = winampGetOutModule();

	if (module == NULL)
		return -1;

	module->hDllInstance = ::LoadLibrary("out_lame.dll");
	if (module->hDllInstance == NULL)
		return -2;

	::DialogBox( hInstance, MAKEINTRESOURCE(IDD_DIALOG_TST) , NULL, ::DialogProc);
	::FreeLibrary(module->hDllInstance);

	return 0;
}