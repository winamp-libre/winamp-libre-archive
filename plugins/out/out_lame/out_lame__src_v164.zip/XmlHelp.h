bool GetBoolFromElementAttribute(const TiXmlElement* parentElement, const char* element, const char* attribute, bool bDefault);
bool GetBoolFromAttribute(const TiXmlElement* element, const char* attribute, bool bDefault);
int GetIntFromAttribute(const TiXmlElement* element, const char* attribute, int nDefault);
void SetAttributeBool(TiXmlElement* the_elt,const std::string& the_string, const bool the_value);
