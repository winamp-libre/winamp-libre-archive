/************************************************************************
BSD License post 1999 : 

Copyright (c) 2001, Steve Lhomme
Copyright (c) 2005, Mike Lynch
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met: 

- Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

- Redistributions in binary form must reproduce the above copyright notice, 
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution. 

- The name of the author may not be used to endorse or promote products derived
from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE. 
************************************************************************/


/*

newer versions from http://out-lame.sourceforge.net

$Id: ADbg.h,v 1.4 2001/12/27 17:52:32 robux4 Exp $ 


$Log: ADbg.h,v $
Revision 1.4  2001/12/27 17:52:32  robux4
Update with a new todo

Revision 1.3  2001/08/11 09:31:57  robux4
Updated for version 1.4.0

Revision 1.2  2001/07/31 18:49:39  robux4
Initial Doxygen doc support


*/

#if !defined(_DBG_H__INCLUDED_)
#define _DBG_H__INCLUDED_

#include <windows.h>

static const int MAX_PREFIX_LENGTH = 128;

#if !defined(NDEBUG)
// define the working debugging class

/**
	\file 
	\class ADbg ADbg.h 
  \brief The ADbg class a debugging class for Windows (might be ported to anything else).
  \note The debug informations can be output into the Windows Message debug (OutputDebugSrting()) or in a file.
  \remarks If NDEBUG is defined the class won't display or compute anything (but will still produce some code).
*/
class ADbg  
{
public:
	/**
		\brief The default constructor.

		\param level indicate the minimum level to display. -1 display also internal ADbg messages.
	*/
	ADbg(int level = 0);

	/**
		\brief The default destructor.
	*/
	virtual ~ADbg();

	/**
		\brief Ouput a debug message of a specified level and format

		\param level The level for which the message should be used (if lower than the default, it won't be processed).
		\param format The string format, same as in printf().
		\param ... The parameters corresponding to the format
		\todo make an inline function to test the level first and the process
	*/
	int OutPut(int level, const char * format,...);

	/**
		\brief Ouput a debug message for a specified format (always processed)
		
		\param format The string format, same as in printf().
		\param ... The parameters corresponding to the format
	*/
	int OutPut(const char * format,...);

	/**
		\brief Change the debug level to the specified level
		
		\return the previous level used
	*/
	inline int setLevel(const int level) {
		int prev_level = my_level;
		my_level = level;
		return prev_level;
	}

	/**
		\brief Specified if the output must include the current UTC time

		\return the previous include value
	*/
	inline bool setIncludeTime(const bool included = true) {
		bool prev_include = my_time_included;
		my_time_included = included;
		return prev_include;
	}

	/**
		\brief Set the name of the filename that might be used to output the debug messages

		\return true if the file can be used to output the debug data
	*/
	bool setDebugFile(const char * NewFilename);

	/**
		\brief Unset the file use
		\note If the file was opened, it will be closed

		\return true if everything went fine
	*/
	bool unsetDebugFile();

	/**
		\brief Specified if the output must done to the file or the Windows Debug Messages

		\return the previous use value
	*/
	inline bool setUseFile(const bool usefile = true) {
		bool prev_use = my_use_file;
		my_use_file = usefile;
		return my_use_file;
	}

	/**
		\brief Set a prefix string that will be used at every output. This is usefull to check what part of the code is talking.

		\return the number of chars that will be used
	*/
	inline const char * setPrefix(const char * string) {
		return strncpy(prefix, string, MAX_PREFIX_LENGTH);
	}

private:
	int my_level;
	bool my_time_included;
	bool my_use_file;
	bool my_debug_output;

	int _OutPut(const char * format,va_list params);

	char prefix[MAX_PREFIX_LENGTH];

	HANDLE hFile;
};

#else // !defined(NDEBUG)

// define a class that does nothing (no output)

class ADbg  
{
public:
	ADbg(int level = 0){}
	virtual ~ADbg() {}

	inline int OutPut(int level, const char * format,...) {
		return 0;
	}

	inline int OutPut(const char * format,...) {
		return 0;
	}

	inline int setLevel(const int level) {
		return level;
	}

	inline bool setIncludeTime(const bool included = true) {
		return true;
	}

	inline bool setDebugFile(const char * NewFilename) {
		return true;
	}

	inline bool unsetDebugFile() {
		return true;
	}

	inline bool setUseFile(const bool usefile = true) {
		return true;
	}

	inline const char * setPrefix(const char * string) {
		return string;
	}
};

#endif // !defined(NDEBUG)

#endif // !defined(_DBG_H__INCLUDED_)
