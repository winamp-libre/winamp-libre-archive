/*

	$Id: ALameDLL.h,v 1.7 2001/08/16 20:00:33 robux4 Exp $ 


	$Log: ALameDLL.h,v $
	Revision 1.7  2001/08/16 20:00:33  robux4
	Added the encoding DLL location in the abuot box
	
	Revision 1.6  2001/08/01 19:40:16  robux4
	Updated with complete documentation support
	
	Revision 1.5  2001/07/31 18:49:39  robux4
	Initial Doxygen doc support
	
	Revision 1.4  2001/07/27 16:42:39  robux4
	Updated CVS tags

	Revision 1.3  2001/07/26 19:28:49  robux4
	Added CVS tags

*/

#if !defined(_ALAMEDLL_H__INCLUDED_)
#define _ALAMEDLL_H__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <windows.h>
#include <assert.h>

#include "BladeMP3EncDLL.h"

#include "ADbg/ADbg.h"

/** \class ALameDLL ALameDLL.h
    \brief AlameDLL is the class that handle all the accesses to the fucntions contained in the lame DLL
*/
class ALameDLL
{
public:
	/**
		\brief The default constructor
	*/
	ALameDLL();

	/**
		\brief The default destructor
	*/
	virtual ~ALameDLL();

	/**
		\brief Load the DLL at the location specified

		\param DllLocation A NULL terminated string corresponding to the DLL Location (with PATH as for LoadLibrary)
		\return true if the DLL is successfully loaded in memory (false otherwise)
	*/
	bool Load(const char * DllLocation);

	/**
		\brief Free the DLL if it was loaded
	*/
	void Free(void);

	/**
		\brief Init the MP3 stream
		
		\note This function is the first to call before starting an encoding stream

		\param pbeConfig Pointer at the struct containing encoder settings
		\param dwSamples Pointer at double word where number of samples to send to each beEncodeChunk() is returned
		\param dwBufferSize Pointer at double word where minimum size in bytes of output buffer is returned

		\return BE_ERR_SUCCESSFUL if successfull
	*/
	inline BE_ERR ALameDLL::InitStream(PBE_CONFIG pbeConfig, PDWORD dwSamples, PDWORD dwBufferSize) const
	{
		if (beInitStream != NULL)
			return beInitStream(pbeConfig, dwSamples, dwBufferSize, (PHBE_STREAM) &hbeStream);
		else
			return BE_ERR_INVALID_HANDLE;
	}

	/**
		\brief Encode some audio data in the MP3 stream

		\note If you have set the output to generate mono MP3 files you must feed EncodeChunk() with mono samples !

		\param nSamples Number of samples to be encoded for this call. This should be identical to what is returned by InitStream(), unless you are encoding the last chunk, which might be smaller
		\param pSamples Pointer at the 16-bit signed samples to be encoded. These should be in stereo when encoding a stereo MP3 and mono when encoding a mono MP3
		\param pOutput Where to write the encoded data. This buffer should be at least of the minimum size returned by InitStream().
		\param pdwOutput Where to return number of bytes of encoded data written. The amount of data written might vary from chunk to chunk

		\return BE_ERR_SUCCESSFUL if successfull
	*/
	inline BE_ERR ALameDLL::EncodeChunk(DWORD nSamples, PSHORT pSamples, PBYTE pOutput, PDWORD pdwOutput ) const
	{
		if (beEncodeChunk != NULL)
			return beEncodeChunk(hbeStream, nSamples, pSamples, pOutput, pdwOutput);
		else
			return BE_ERR_INVALID_HANDLE;
	}


	/**
		\brief DeInit the MP3 stream
		\note This function should be called after encoding the last chunk in order to flush the encoder.
		      It writes any encoded data that still might be left inside the encoder to the output buffer.
			  This function should NOT be called unless you have encoded all of the chunks in your stream

		\param pOutput Where to write the encoded data. This buffer should be at least of the minimum size returned by InitStream()
		\param pdwOutput Where to return number of bytes of encoded data written

		\return BE_ERR_SUCCESSFUL if successfull
	*/
	inline BE_ERR ALameDLL::DeinitStream(PBYTE pOutput, PDWORD pdwOutput ) const
	{
		if (beDeinitStream != NULL)
			return beDeinitStream( hbeStream, pOutput, pdwOutput);
		else
			return BE_ERR_INVALID_HANDLE;
	}

	/**
		\brief Close the MP3 stream
		\note Last function to be called when finished encoding a stream. 
		     Should unlike DeinitStream() also be called if the encoding is canceled

		\return BE_ERR_SUCCESSFUL if successfull
	*/
	inline BE_ERR ALameDLL::CloseStream() const
	{
		if (beCloseStream != NULL)
			return beCloseStream( hbeStream );
		else
			return BE_ERR_INVALID_HANDLE;
	}

	/**
		\brief Write the VBR/Xing header in the MP3 file

		\warning Make sure that the MP3 file is closed, and the the beConfig.format.LHV1.bWriteVBRHeader has been set to TRUE.
		\note    In addition, it is always safe to call beWriteVBRHeader after the encoding has been finished, 
				 even when the beConfig.format.LHV1.bWriteVBRHeader is not set to TRUE

		\param pszMP3FileName The filename where the VBR stats should be written
				
	*/
	inline void ALameDLL::WriteVBRHeader(LPCSTR pszMP3FileName ) const
	{
		if (beWriteVBRHeader != NULL)
			beWriteVBRHeader(pszMP3FileName);
	}

	/**
		\brief Retreive the informations about the loaded DLL

		\note Returns information like version numbers (both of the DLL and encoding engine), 
		      release date and URL for lame_enc's homepage. 
			  All this information should be made available to the user of your product through a dialog box or something similar

		\param ver Pointer at struct where version number, release date and URL for homepage is returned
	*/
	inline void ALameDLL::Version(BE_VERSION * ver) const
	{
		assert(ver != NULL);

		if (beVersion != NULL)
			beVersion(ver);
	}

	/**
		\brief return wether the DLL is Loaded and have all the known functions inited
	*/
	inline bool IsLoaded() const {
		return ((LameDLL != NULL) && (beInitStream != NULL) && (beCloseStream != NULL) && (beEncodeChunk != NULL) && (beDeinitStream != NULL) && (beWriteVBRHeader != NULL) && (beVersion != NULL));
	}

	/**
		\brief Retreive the DLL full path

		\param output the buffer in which the location will be copied
		\param BufferSize the size of this buffer to fill

		\return the number of TCHAR succesfully copied (0 if any error  occur)
	*/
	inline DWORD ALameDLL::GetFullLocation(TCHAR * output, const int BufferSize) const {
		if (LameDLL != NULL)
		{
			return ::GetModuleFileName(LameDLL, output, BufferSize);
		}
		else return 0;
	}

private:
	HMODULE LameDLL;

	BEINITSTREAM     beInitStream;
	BECLOSESTREAM    beCloseStream;
	BEENCODECHUNK    beEncodeChunk;
	BEDEINITSTREAM   beDeinitStream;
	BEWRITEVBRHEADER beWriteVBRHeader;
	BEVERSION        beVersion;

	HBE_STREAM       hbeStream;
};

#endif // !defined(_ALAMEDLL_H__INCLUDED_)
