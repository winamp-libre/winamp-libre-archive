#include <string>
#include "tinyxml/tinyxml.h"
#include "XmlHelp.h"

bool GetBoolFromElementAttribute(const TiXmlElement* parentElement, const char* element, const char* attribute, bool bDefault)
{
	if (parentElement != NULL)
		return GetBoolFromAttribute(parentElement->FirstChildElement(element), attribute, bDefault);
	return bDefault;
}

bool GetBoolFromAttribute(const TiXmlElement* element, const char* attribute, bool bDefault)
{
	if (element != NULL)
	{
		std::string tmpname(element->Attribute(attribute));
		if (tmpname.size() > 0)
			return tmpname.compare("true") == 0;
	}
	return bDefault;
}

int GetIntFromAttribute(const TiXmlElement* element, const char* attribute, int nDefault)
{
	if (element != NULL)
	{
		std::string tmpname(element->Attribute(attribute));
		if (tmpname.size() > 0)
			return atoi(tmpname.c_str());
	}
	return nDefault;
}

void SetAttributeBool(TiXmlElement* the_elt,const std::string& the_string, const bool the_value)
{
	if (the_value == false)
		the_elt->SetAttribute(the_string, "false");
	else
		the_elt->SetAttribute(the_string, "true");
}
