/**

$Id: main.cpp,v 1.4 2001/08/13 18:44:42 robux4 Exp $ 


$Log: main.cpp,v $
Revision 1.4  2001/08/13 18:44:42  robux4
Initial support for free borland compiler

Revision 1.3  2001/07/27 16:42:39  robux4
Updated CVS tags

Revision 1.2  2001/07/26 19:28:49  robux4
Added CVS tags
 

*/

#include <windows.h>

#include "AOut.h"

static AOut the_output;

extern "C"
{
#ifdef __BORLANDC__
	__declspec (dllexport) Out_Module * __stdcall winampGetOutModule()
#else // MSVC
	__declspec (dllexport) Out_Module * winampGetOutModule()
#endif
	{
		return the_output.GetOutModule();
	}
}

