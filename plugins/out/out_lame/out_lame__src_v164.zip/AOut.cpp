/*

$Id: AOut.cpp,v 1.22 2005/01/08 00:17:55 prowler7 Exp $ 


$Log: AOut.cpp,v $
Revision 1.22  2005/01/08 00:17:55  prowler7
added writing tag info using Get/Set Extended File Info

Revision 1.21  2005/01/06 23:48:43  prowler7
Fixed bug - getoutputtime() now uses 64-bit math to avoid the overflow that would typically happen at ~48sec of encoding stereo 44.1kHz.
Added feature to write custom tag information using Winamp's IPC_WRITE_EXTENDED_FILE_INFO, still need to expose this in the config GUI.

Revision 1.20  2004/12/08 04:10:39  prowler7
Version 1.6.2
- Fixed bug: Xing/Lame frame was never being written
- Fixed bug: Lame DLL location was not being saved
- Added all presets in Lame 3.96
- Option to always write the Xing/Lame frame (since Lame uses an extension of the Xing frame it applies to CBR too)
- Added explicit setting of psycho acoustic Quality (-q)
- About dialog now shows Lame alpha/beta revision and if MMX is supported

Revision 1.19  2001/09/05 18:39:48  robux4
No more dependency on the Winamp exe

Revision 1.18  2001/09/05 18:35:13  robux4
Corrected the 4 chars filename bug, improved the Winamp interaction

Revision 1.17  2001/09/04 18:41:25  robux4
ABR now correctly working

Revision 1.16  2001/09/03 20:56:27  robux4
Corrected a buffer overlapping bug with the static build

Revision 1.15  2001/08/31 16:40:28  robux4
Added initial support for a static build to debug

Revision 1.14  2001/08/29 22:12:19  robux4
Few corrections on ABR mode

Revision 1.13  2001/08/29 21:41:38  robux4
Added ABR support

Revision 1.12  2001/08/21 18:40:38  robux4
Added for safe ID3v2 keeping and no overwrite

Revision 1.11  2001/08/16 20:00:33  robux4
Added the encoding DLL location in the abuot box

Revision 1.10  2001/08/15 17:21:50  robux4
Added force channel support

Revision 1.9  2001/08/13 18:44:42  robux4
Initial support for free borland compiler

Revision 1.8  2001/08/11 10:20:24  robux4
Dialog boxes now display the DLL version

Revision 1.7  2001/08/01 19:40:16  robux4
Updated with complete documentation support

Revision 1.6  2001/07/31 18:50:53  robux4
Moved the version handling in the ALameDLL class

Revision 1.5  2001/07/27 16:38:49  robux4
Unified the MessageBox handling

Revision 1.3  2001/07/26 19:28:49  robux4
Added CVS tags
 

*/

#if !defined(STRICT)
#define STRICT
#endif // !defined(STRICT)

#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <intshcut.h>
#include <strstream>
#include <algorithm>
#include "wa_ipc.h"

#include "resource.h"

#include "AOut.h"

/*
#ifdef __alpha
#define PI_VER " (AXP)"
#else
#define PI_VER " (x86)"
#endif
*/

/*
	\fn AboutProc
*/
static BOOL CALLBACK AboutProc(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
  )
{
	static HBRUSH hBrushStatic;
	static LOGFONT lf;  // structure for font information  
	static HFONT hfnt;
	BOOL bResult;
	static HCURSOR hcOverCursor;

	switch (uMsg) {

		case WM_COMMAND:
			UINT command;
			command = GET_WM_COMMAND_ID(wParam, lParam);
			if ((IDOK == command) || (IDCANCEL == command))
			{
				::DeleteObject(hfnt);

				::EndDialog(hwndDlg, (IDOK == command));
			} 
			bResult = FALSE;
			break;

		case WM_INITDIALOG:

			::GetObject(::GetStockObject(DEFAULT_GUI_FONT), sizeof(LOGFONT), &lf); 
			lf.lfUnderline = TRUE;

			hfnt = ::CreateFontIndirect(&lf);

			::SendMessage(::GetDlgItem(hwndDlg,IDC_ABOUT_HOMEPAGE), WM_SETFONT, (WPARAM) hfnt, TRUE);
			::SendMessage(::GetDlgItem(hwndDlg,IDC_ABOUT_BSD), WM_SETFONT, (WPARAM) hfnt, TRUE);

			::SetDlgItemText(hwndDlg, IDC_ABOUT_VERSION, AOut::GetVersion());

			BE_VERSION	Version;
			if (AOut::GetLameVersion(&Version))
			{

				SetDlgItemText(hwndDlg, IDC_DLL_HOMEPAGE, Version.zHomepage);

				char toto[20];
				
				wsprintf(toto,"%u.%02u (%02u/%02u/%04u)",Version.byDLLMajorVersion, Version.byDLLMinorVersion, Version.byDay, Version.byMonth, Version.wYear);
				SetDlgItemText(hwndDlg, IDC_DLL_VERSION, toto);

				// ML: added MMX and alpha/beta version display
				char *mmx = Version.byMMXEnabled ? "MMX" : "No MMX";
				char titi[32];
				if(Version.byBetaLevel > 0)
					wsprintf(titi,"%u.%02u.%ub %s",Version.byMajorVersion, Version.byMinorVersion, Version.byBetaLevel, mmx);
				else if(Version.byAlphaLevel > 0)
					wsprintf(titi,"%u.%02u.%ua %s",Version.byMajorVersion, Version.byMinorVersion, Version.byAlphaLevel, mmx);
				else
					wsprintf(titi,"%u.%02u %s",Version.byMajorVersion, Version.byMinorVersion, mmx);
				::SetDlgItemText(hwndDlg, IDC_DLL_ENGINE, titi);

				/* ML: I guess this was a TODO, but never done since IDC_DLL_MMX resource does not exist */
				/*if (Version.byMMXEnabled)
					::SetDlgItemText(hwndDlg, IDC_DLL_MMX, "MMX enabled");
				else
					::SetDlgItemText(hwndDlg, IDC_DLL_MMX, "No MMX");*/

				::SendMessage(::GetDlgItem(hwndDlg,IDC_DLL_HOMEPAGE), WM_SETFONT, (WPARAM) hfnt, TRUE);

				char output[MAX_PATH];
				if (!AOut::LameDLL().GetFullLocation(output,MAX_PATH) != 0)
				{
					::LoadString(AOut::GetInstance(),IDS_STRING_PROMPT_REPLACE_CURRENT,output,MAX_PATH);
				}
				::SetDlgItemText(hwndDlg, IDC_EDIT_ABOUT_DLL_LOCATION, output);
			}
			else
			{
				char output[MAX_PATH];
				::LoadString(AOut::GetInstance(),IDS_STRING_ABOUT_DLL_NOT_FOUND,output,MAX_PATH);
				::SetDlgItemText(hwndDlg, IDC_EDIT_ABOUT_DLL_LOCATION, output);
				::SetDlgItemText(hwndDlg, IDC_DLL_HOMEPAGE, "");
				::SetDlgItemText(hwndDlg, IDC_DLL_VERSION, "0.00");
				::SetDlgItemText(hwndDlg, IDC_DLL_ENGINE, "0.00");
			}

			/**
				\todo move that somewhere else ?
			*/
			hBrushStatic = ::CreateSolidBrush(::GetSysColor (COLOR_BTNFACE));

			hcOverCursor = ::LoadCursor(NULL,(LPCTSTR)IDC_CROSS); 

			bResult = TRUE;
			break;

		case WM_CTLCOLORSTATIC:
			/**
				\todo only if there are URLs
			*/
			if ((HWND)lParam == ::GetDlgItem(hwndDlg,IDC_DLL_HOMEPAGE) ||
				(HWND)lParam == ::GetDlgItem(hwndDlg,IDC_ABOUT_HOMEPAGE) ||
				(HWND)lParam == ::GetDlgItem(hwndDlg,IDC_ABOUT_BSD))
			{
				::SetTextColor((HDC)wParam, ::GetSysColor (COLOR_HIGHLIGHT));
				::SetBkColor((HDC)wParam, ::GetSysColor (COLOR_BTNFACE));

				return (LRESULT) hBrushStatic;
			}
			else
				return (LRESULT) NULL;

		case WM_MOUSEMOVE:
			{
				POINT pnt;
				::GetCursorPos(&pnt);

				RECT rctBSD;
				::GetWindowRect( ::GetDlgItem(hwndDlg,IDC_ABOUT_BSD), &rctBSD);

				RECT rctDLLurl;
				::GetWindowRect( ::GetDlgItem(hwndDlg,IDC_DLL_HOMEPAGE), &rctDLLurl);

				RECT rctMYurl;
				::GetWindowRect( ::GetDlgItem(hwndDlg,IDC_ABOUT_HOMEPAGE), &rctMYurl);

				if (  ::PtInRect(&rctBSD,pnt) 
					|| (::PtInRect(&rctDLLurl,pnt) && AOut::LameDLL().IsLoaded())
					|| ::PtInRect(&rctMYurl,pnt) )
				{
					::SetCursor(hcOverCursor);
				}


			}
			break;

		case WM_LBUTTONUP:
			{
				POINT pnt;
				::GetCursorPos(&pnt);

				RECT rctBSD;
				::GetWindowRect( ::GetDlgItem(hwndDlg,IDC_ABOUT_BSD), &rctBSD);

				RECT rctDLLurl;
				::GetWindowRect( ::GetDlgItem(hwndDlg,IDC_DLL_HOMEPAGE), &rctDLLurl);

				RECT rctMYurl;
				::GetWindowRect( ::GetDlgItem(hwndDlg,IDC_ABOUT_HOMEPAGE), &rctMYurl);

				TCHAR Url[200];
				bool bUrl = false;
				if (::PtInRect(&rctBSD,pnt))
				{
					::LoadString(AOut::GetInstance(),IDS_STRING_BSD_LICENCE_URL,Url,200);
					bUrl = true;
				}
				else if (::PtInRect(&rctDLLurl,pnt) && AOut::LameDLL().IsLoaded())
				{
					::GetWindowText(::GetDlgItem(hwndDlg,IDC_DLL_HOMEPAGE),Url,sizeof(Url));
					bUrl = true;
				}
				else if (::PtInRect(&rctMYurl,pnt))
				{
					::GetWindowText(::GetDlgItem(hwndDlg,IDC_ABOUT_HOMEPAGE),Url,sizeof(Url));
					bUrl = true;
				}		

				if (bUrl)
				{
					LPSTR tmpStr;
					HRESULT hresult = ::TranslateURL(Url, TRANSLATEURL_FL_GUESS_PROTOCOL|TRANSLATEURL_FL_GUESS_PROTOCOL, &tmpStr);
					if (hresult == S_OK)
						::ShellExecute(hwndDlg,"open",tmpStr,NULL,"",SW_SHOWMAXIMIZED );
					else if (hresult == S_FALSE)
						::ShellExecute(hwndDlg,"open",Url,NULL,"",SW_SHOWMAXIMIZED );
				}

			}
			break;

		default:
			bResult = FALSE; // will be treated by DefWindowProc
	}
	return bResult;
}

//////////////////////////////////////////////////////////////////////
// Variables
//////////////////////////////////////////////////////////////////////
/**
	\class AOut
*/

/**
	\todo remove Output[10000] and only use the size of the buffer needed to encode
*/
static unsigned char Output[10000];

AOut *         AOut::the_AOut = NULL;
ADbg           AOut::the_Debug;
DWORD          AOut::the_SamplesPerBlock;
//char         * AOut::the_WorkingBuffer = NULL;
char           AOut::the_WorkingBuffer[3000];
char           the_TmpOutbufBuffer[3000];
unsigned int   AOut::the_WorkingBufferUseSize = 0;
DWORD          AOut::the_SamplesUsed = 0;
DWORD          AOut::the_SamplesPerSec;
DWORD          AOut::the_Channels;
DWORD          AOut::the_MaxBuffer;
HANDLE         AOut::the_OutputFile = INVALID_HANDLE_VALUE;
ALameDLL       AOut::the_LameDLL;
AEncodeProperties AOut::my_Properties;
bool AOut::bCopiedTag = false;
std::string    AOut::my_Filename = "";
char           AOut::the_complete_name[31];
char           AOut::the_version_name[10];
#ifdef ENABLE_RAWOUTPUT
static HANDLE the_RawOutputFile;
#endif // ENABLE_RAWOUTPUT

Out_Module AOut::the_Module = {
	OUT_VER,
	the_complete_name,
	44444,
	0, // hmainwindow
	0, // hdllinstance
	config,
	about,
	init,
	quit,
	open,
	close,
	write,
	canwrite,
	isplaying,
	pause,
	setvolume,
	setpan,
	flush,
	getoutputtime,
	getwrittentime
};

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

AOut::AOut()
{
	the_Debug.setPrefix("Winamp MP3 output");

	the_AOut = this;
}

AOut::~AOut()
{
	the_AOut = NULL;
}

//////////////////////////////////////////////////////////////////////
// Methods
//////////////////////////////////////////////////////////////////////

Out_Module * AOut::GetOutModule()
{
	DWORD val, size = 0;
	char right_path[MAX_PATH];

	HMODULE htmp;
	htmp = LoadLibrary("plugins\\out_lame.dll");
	if (htmp == NULL)
	{
		htmp = LoadLibrary("out_lame.dll");
	}
	if (htmp != NULL)
	{
		::GetModuleFileName(htmp, right_path, MAX_PATH);
		::FreeLibrary(htmp);

		size = ::GetFileVersionInfoSize(right_path,&val);
	}

	bool bSet = false;

	if (size != 0)
	{
		HANDLE  hMem;
		char * tmpInfo;

		hMem = GlobalAlloc(GMEM_MOVEABLE, size);
		tmpInfo  = (char *)GlobalLock(hMem);
            

		if (tmpInfo != NULL)
		{
			::GetFileVersionInfo( right_path, NULL, size, tmpInfo);

			unsigned int tmpSize;
			DWORD *infos;
			if (::VerQueryValue(tmpInfo, "\\VarFileInfo\\Translation", (LPVOID *)&infos, &tmpSize))
			{
				TCHAR tmpStr[100];
				TCHAR * version;
				wsprintf(tmpStr,"\\StringFileInfo\\%04X%04X\\ProductVersion",LOWORD(infos[0]),HIWORD(infos[0])); // first language : english ?
				::VerQueryValue(tmpInfo, tmpStr, (LPVOID *)&version, &tmpSize);
				wsprintf(the_version_name,"%s",version);
				wsprintf(the_complete_name,"%s%s","Lame MP3 Writer plug-in v", version);
				bSet = true;
			}
		}

		if (tmpInfo != 0)
		{
			::GlobalUnlock(hMem);
			::GlobalFree(hMem);
		}
	}
	
	if (!bSet)
	{
		wsprintf(the_version_name,"%s","?.?.?");
		wsprintf(the_complete_name,"%s","Lame MP3 Writer plug-in");
	}

	return &the_Module;
}

void AOut::config(const HWND hwndParent) { 
	the_Debug.OutPut("config");

	my_Properties.Config(the_Module.hDllInstance, hwndParent);
}

void AOut::about(const HWND hwndParent) { 
	the_Debug.OutPut("about");

	int ret = ::DialogBox(the_Module.hDllInstance, MAKEINTRESOURCE(IDD_ABOUT), hwndParent, ::AboutProc);
	if (ret == -1)
	{
		LPVOID lpMsgBuf;
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
		);
		// Process any inserts in lpMsgBuf.
		// ...
		// Display the string.
		MyMessageBox( (LPCTSTR)lpMsgBuf, MB_OK | MB_ICONINFORMATION );
		// Free the buffer.
		LocalFree( lpMsgBuf );	
	}
}

void AOut::init() { 
	the_Debug.OutPut("init");

	my_Properties.ParamsRestore();
}

void AOut::quit() { 
	the_Debug.OutPut("quit");

	my_Properties.ParamsSave();
}

int  AOut::open(const int samplerate, const int numchannels, const int bitspersamp, const int bufferlenms, const int prebufferms)
{ 
	the_Debug.OutPut("open, samplerate = %d / numchannels = %d / bitspersamp =%d / bufferlenms = %d / prebufferms = %d", samplerate, numchannels, bitspersamp, bufferlenms, prebufferms);

	int result = -1;

	if (bitspersamp != 16) // only 16 bits supported at the moment
		return result;

	bool bDllLoaded;

	if (!the_LameDLL.IsLoaded())
	{

		bDllLoaded = the_LameDLL.Load(my_Properties.GetDllLocation());

	}
	else
		bDllLoaded = true;

	if (!bDllLoaded)
	{
		CloseHandle(the_OutputFile);
		the_OutputFile = INVALID_HANDLE_VALUE;
	}
	else
	{
		// set current date
		my_Properties.SetCurrentDate();

		// for the given sampling freq/bitpersamp/bitrate (config)
		//  we must compute the max latency (it will be one frame -> 576/1152 samples)

		// Init the MP3 Stream
		BE_CONFIG	beConfig;
		BE_ERR		err;
		
		memset(&beConfig,0,sizeof(beConfig));					// clear all fields

		// use the LAME config structure
		beConfig.dwConfig = BE_CONFIG_LAME;

		// this are the default settings for testcase.wav
		beConfig.format.LHV1.dwStructVersion	= 1;
		beConfig.format.LHV1.dwStructSize		= sizeof(beConfig);		
		beConfig.format.LHV1.dwSampleRate		= samplerate;							// INPUT FREQUENCY

		if (my_Properties.GetResampleMode())
			beConfig.format.LHV1.dwReSampleRate		= my_Properties.GetResampleFreq();	// RESAMPLE
		else
			beConfig.format.LHV1.dwReSampleRate		= 0;								// DON'T RESAMPLE

the_Debug.OutPut("GetResampleMode = %s / GetResampleFreq = %d / dwReSampleRate = %d",my_Properties.GetResampleMode()?"TRUE":"FALSE",my_Properties.GetResampleFreq(),beConfig.format.LHV1.dwReSampleRate);

		if (my_Properties.GetForceChannelMode())
		{
			beConfig.format.LHV1.nMode			= my_Properties.GetChannelModeValue();	// OUTPUT IN DESIRED MODE
		}
		else
		{
			if (numchannels < 2)
				beConfig.format.LHV1.nMode			= BE_MP3_MODE_MONO;						// OUTPUT IN MONO
			else
			{
				if (my_Properties.GetChannelModeValue() == BE_MP3_MODE_MONO)
					beConfig.format.LHV1.nMode			= BE_MP3_MODE_STEREO;	// force STEREO when Mono is selected
				else
					beConfig.format.LHV1.nMode			= my_Properties.GetChannelModeValue();	// OUTPUT IN DESIRED MODE
			}
		}
		
		if (beConfig.format.LHV1.dwReSampleRate == 0) // no resampling
		{
			if (samplerate < 32000)
				beConfig.format.LHV1.dwMpegVersion		= MPEG2;							// MPEG VERSION (I or II)
			else
				beConfig.format.LHV1.dwMpegVersion		= MPEG1;							// MPEG VERSION (I or II)
		}
		else
		{
			if (beConfig.format.LHV1.dwReSampleRate < 32000)
				beConfig.format.LHV1.dwMpegVersion		= MPEG2;							// MPEG VERSION (I or II)
			else
				beConfig.format.LHV1.dwMpegVersion		= MPEG1;							// MPEG VERSION (I or II)
		}

		int bitrateOK = my_Properties.GetBitrateValue(beConfig.format.LHV1.dwBitrate, beConfig.format.LHV1.dwMpegVersion);

		if (my_Properties.GetVBRUseMode())
		{
			// the VBR parameters are automatically
			bitrateOK = 0;
		}

		if (bitrateOK < 0)
		{
			TCHAR output[250];
			::LoadString(GetInstance(),IDS_STRING_BITRATE_HIGH,output,250);
			AOut::MyMessageBox( output, MB_OK|MB_ICONEXCLAMATION);

			the_LameDLL.Free();
		}
		else if (bitrateOK > 0)
		{
			TCHAR output[250];
			::LoadString(GetInstance(),IDS_STRING_BITRATE_SMALL,output,250);
			AOut::MyMessageBox( output, MB_OK|MB_ICONEXCLAMATION);

			the_LameDLL.Free();
		}
		else
		{
			// Get the current played file
// not clean			HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
			// try with the plugin hMainWindow (tested successfully with 2.74)
			HWND hwndWinamp = AOut::GetOutModule()->hMainWindow;
			int index = SendMessage(hwndWinamp, WM_WA_IPC, 0, IPC_GETLISTPOS);

			// get title to use as output filename
			char *name = (char *)SendMessage(hwndWinamp, WM_WA_IPC, index, IPC_GETPLAYLISTTITLE);
			std::string tmpFilename2 = name;

			// strip the known extensions
			std::string tmpCase = tmpFilename2;
			std::transform(tmpCase.begin(), tmpCase.end(), tmpCase.begin(), tolower);
			if (tmpCase.length() >= 4)
			{
				if (tmpCase.substr(tmpCase.length()-4).compare(".wav") == 0)
					tmpFilename2.erase( tmpFilename2.length()-4, 4);
				else if (tmpCase.substr(tmpCase.length()-4).compare(".mp3") == 0)
					tmpFilename2.erase( tmpFilename2.length()-4, 4);
			}

			// replace forbidden chars
			replaceAllChar(tmpFilename2,'\\','-');
			replaceAllChar(tmpFilename2,'/','-');
			replaceAllChar(tmpFilename2,':','_');
			replaceAllChar(tmpFilename2,'*','x');
			replaceAllChar(tmpFilename2,'?','.');
			replaceAllChar(tmpFilename2,'"','\'');
			replaceAllChar(tmpFilename2,'<','.');
			replaceAllChar(tmpFilename2,'>','.');
			replaceAllChar(tmpFilename2,'|','_');

			const char * dir = my_Properties.GetOutputDirectory();

			std::string base_file;

			base_file = dir;
			if (dir[strlen(dir)-1] != '\\')
				base_file += '\\';
			base_file += tmpFilename2;

			
			my_Filename = base_file + ".mp3";

			the_OutputFile = CreateFile(my_Filename.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL );
#ifdef ENABLE_RAWOUTPUT
			std::string tmpName = my_Filename + ".raw";
			the_RawOutputFile = CreateFile(tmpName.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
#endif // ENABLE_RAWOUTPUT
			
			// no overwrite support
			if (the_OutputFile == INVALID_HANDLE_VALUE )
			{
				int i=0;
				base_file += "-";
				while (the_OutputFile == INVALID_HANDLE_VALUE && i < 1000 ) // over 1000 there must really be another problem
				{
					std::strstream sstream;
					std::string tmpStr;
					sstream << i;
					sstream >> tmpStr;
					my_Filename = base_file + tmpStr + ".mp3";;
					i++;

					the_OutputFile = CreateFile(my_Filename.c_str(), GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL );
				}
			}

			if (the_OutputFile == INVALID_HANDLE_VALUE)
			{
				the_LameDLL.Free();
			}
			else
			{

				beConfig.format.LHV1.nPreset			= my_Properties.GetPresetModeValue();	// QUALITY PRESET SETTING

				beConfig.format.LHV1.dwPsyModel			= 0;									// USE DEFAULT PSYCHOACOUSTIC MODEL 
				beConfig.format.LHV1.dwEmphasis			= 0;									// NO EMPHASIS TURNED ON
				beConfig.format.LHV1.bOriginal			= my_Properties.GetOriginalMode();		// SET ORIGINAL FLAG
				beConfig.format.LHV1.bCRC				    = my_Properties.GetCRCMode();			// INSERT CRC
				beConfig.format.LHV1.bCopyright			= my_Properties.GetCopyrightMode();		// SET COPYRIGHT FLAG	
				beConfig.format.LHV1.bPrivate		  	= my_Properties.GetPrivateMode();		// SET PRIVATE FLAG
				beConfig.format.LHV1.bNoRes			  	= my_Properties.GetNoBiResMode();		// No Bit resorvoir
				beConfig.format.LHV1.nQuality			= my_Properties.GetQualityValue();		// ML: set Quality

				// USE VBR
				beConfig.format.LHV1.nVbrMethod     = my_Properties.GetVBRValue( beConfig.format.LHV1.dwMaxBitrate,     // MAXIMUM BIT RATE
					                                                                beConfig.format.LHV1.nVBRQuality,      // SET VBR QUALITY
					                                                                beConfig.format.LHV1.dwVbrAbr_bps,     // AVERAGE BITRATE (if applicable)
																					                                beConfig.format.LHV1.bWriteVBRHeader,  // YES, WRITE THE XING VBR HEADER
																					                                beConfig.format.LHV1.dwMpegVersion);

				if (beConfig.format.LHV1.nVbrMethod == VBR_METHOD_NONE)
					beConfig.format.LHV1.bEnableVBR = false;
				else
					beConfig.format.LHV1.bEnableVBR = true;
				
				err = the_LameDLL.InitStream(&beConfig, &the_SamplesPerBlock, &the_MaxBuffer);

				// Check result
				if(err != BE_ERR_SUCCESSFUL)
				{
					the_Debug.OutPut("Error opening encoding stream (%lu)", err);
					result = -1;
				}
				else
				{
					the_Debug.OutPut("Inited stream, the_SamplesPerBlock = %d (the_MaxBuffer = %d)", the_SamplesPerBlock, the_MaxBuffer);
//					the_WorkingBuffer = new char[the_SamplesPerBlock];
					the_WorkingBufferUseSize = 0;
					the_SamplesUsed = 0;
					the_Channels = numchannels;
					the_SamplesPerSec = samplerate;

//					result = 0;
					result =  the_SamplesPerBlock * 1000 / (the_SamplesPerSec * the_Channels);

					name = (char *)SendMessage(hwndWinamp, WM_WA_IPC, index, IPC_GETPLAYLISTFILE);

					// default to no tag copied
					bCopiedTag = false;
					// save the ID3 information that should be at the beginning
					HANDLE input_file = ::CreateFile(name, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
					if (input_file != INVALID_HANDLE_VALUE)
					{
						char Header[10];
						DWORD bytesRead;
						if (::ReadFile(input_file, Header, 10, &bytesRead, NULL) && bytesRead == 10)
						{
							// check if this is a valid ID3v2 tag
							if (   Header[0] == 'I'
								&& Header[1] == 'D'
								&& Header[2] == '3'
								&& Header[3] != 0xFF
								&& Header[4] != 0xFF
								&& Header[6] <  0x80
								&& Header[7] <  0x80
								&& Header[8] <  0x80
								&& Header[9] <  0x80)
							{
								// seems to be a valid tag
								
								// assume it will be copied
								bCopiedTag = true;
								
								// get the size
								bool bFooter = (Header[5] & 0x10) == 0x10;
								UINT32 TagSize = (Header[6] << 21) | (Header[7] << 14) | (Header[8] << 7) | Header[9];
								TagSize += 10; // the header

								if (bFooter)
									TagSize += 10;

								// save the data from the original file to the new one
								DWORD bytesWritten;
								UINT32 i;
								::SetFilePointer( input_file, 0, NULL, FILE_BEGIN );
								for (i=TagSize;i>0;i -= bytesWritten)
								{
									if (!::ReadFile(input_file, Header, 10, &bytesRead, NULL))
									{
										break;
									}

									if (!::WriteFile( the_OutputFile, Header, (bytesRead>i?i:bytesRead), &bytesWritten, NULL)
										|| bytesWritten != (bytesRead>i?i:bytesRead))
									{
										break;
									}
								}

								if (i != 0)
								{
									// there was a problem, forget that ID3 tag
									::SetFilePointer( the_OutputFile, 0, NULL, FILE_BEGIN );
									bCopiedTag = false;
								}
							}
						}
						::CloseHandle(input_file);
					}
					// read metadata from source if no tag copied
					if(!bCopiedTag)
						my_Properties.ReadMetadata(hwndWinamp, name);
				}
			}
		}
	}

	return result;
}


void AOut::close() {
	the_Debug.OutPut("close");

	DWORD EncodedSize = 0;

	// encode the remaining data
//the_Debug.OutPut("the_WorkingBufferUseSize = %d",the_WorkingBufferUseSize);
	if (the_WorkingBufferUseSize != 0)
	{
		BE_ERR err = the_LameDLL.EncodeChunk(the_WorkingBufferUseSize / 2, (PSHORT)the_WorkingBuffer, (PBYTE)Output, &EncodedSize); // 2 for 16bits<->8bits
		if (err == BE_ERR_SUCCESSFUL)
		{
			do {
				DWORD BytesWritten;
				WriteFile(the_OutputFile, Output, EncodedSize, &BytesWritten , NULL); // TODO : better handling
//the_Debug.OutPut("written %d bytes in file for %d byes encoded", BytesWritten, EncodedSize);
				EncodedSize -= BytesWritten;
			} while (EncodedSize != 0);
		}
	}


	the_LameDLL.DeinitStream( (PBYTE)Output, &EncodedSize);

	do {
		DWORD BytesWritten;
		WriteFile(the_OutputFile, Output, EncodedSize, &BytesWritten , NULL); // TODO : better handling
//the_Debug.OutPut("written %d bytes in file for %d byes encoded", BytesWritten, EncodedSize);
		EncodedSize -= BytesWritten;
	} while (EncodedSize != 0);

	if (the_OutputFile != INVALID_HANDLE_VALUE)
		CloseHandle(the_OutputFile);
	the_OutputFile = INVALID_HANDLE_VALUE;
#ifdef ENABLE_RAWOUTPUT
CloseHandle(the_RawOutputFile);
#endif // ENABLE_RAWOUTPUT

	// ML: Note: stream must be closed before the Xing/Lame frame can be written
	// LAME uses an extension of the Xing frame so write the frame if set
	the_LameDLL.CloseStream( );

	if (my_Properties.GetXingFrameMode())
		the_LameDLL.WriteVBRHeader(my_Filename.c_str());

	// if no tag copied, write the set metadata
	if(!bCopiedTag)
		my_Properties.SetMetadata(the_Module.hMainWindow, my_Filename.c_str());

	my_Filename.erase();

	the_LameDLL.Free();

//	if (the_WorkingBuffer != NULL)
//		delete the_WorkingBuffer;
//	the_WorkingBuffer = NULL;
	the_MaxBuffer = 0;
}

int  AOut::write(char *buf, const int len) {
	BE_ERR		err;

DWORD EncodedSize = 0;

	char * OriginBuffer = buf;
	DWORD lenToUse = len;

	if (my_Properties.GetForceChannelMode())
	{
		assert(the_Channels == 1 || the_Channels == 2);

		if (the_Channels == 1)
		{
			if (my_Properties.GetChannelModeValue() != BE_MP3_MODE_MONO)
			{
				// turn mono into stereo
				assert(2*len <= sizeof(the_TmpOutbufBuffer)/sizeof(the_TmpOutbufBuffer[0]));
				OriginBuffer = the_TmpOutbufBuffer;
				UpMixToStereo( (SHORT*) buf, (SHORT*) OriginBuffer, len);
				lenToUse = len*2;
			}
		}
		else
		{
			if (my_Properties.GetChannelModeValue() == BE_MP3_MODE_MONO)
			{
					assert(len/2 <= sizeof(the_TmpOutbufBuffer)/sizeof(the_TmpOutbufBuffer[0]));
					OriginBuffer = the_TmpOutbufBuffer;
				// turn stereo into mono
				MixToMono( (SHORT*) buf, (SHORT*) OriginBuffer, len/2);
				lenToUse = len/2;
			}
		}
	}

#ifdef ENABLE_RAWOUTPUT
DWORD RawBytesWritten;
WriteFile(the_RawOutputFile, OriginBuffer, lenToUse, &RawBytesWritten , NULL); // TODO : better handling
#endif // ENABLE_RAWOUTPUT

#ifndef DISABLE_MP3OUTPUT
	// we have to encode OriginBuffer which is lenToUse big
	// the data wiil be copied to the_WorkingBuffer to be the source encoding buffer
	// we will get the remaining data from the previous encoding
	// add enough data to get the_SamplesPerBlock samples
	// then, encode the_SamplesPerBlock samples each time
	// until we don't have enough data

	int TotalLen = lenToUse;
	while (lenToUse + the_WorkingBufferUseSize >= the_SamplesPerBlock) // 2 for 16bits<->8bits
	{
		// the_WorkingBuffer may have some remaining data from a block
		// fill the remaining part of the block to encode
		memcpy(&the_WorkingBuffer[the_WorkingBufferUseSize], &OriginBuffer[TotalLen - lenToUse], the_SamplesPerBlock - the_WorkingBufferUseSize); // 2 for 16bits<->8bits

		err = the_LameDLL.EncodeChunk(the_SamplesPerBlock / 2, (PSHORT)the_WorkingBuffer, (PBYTE)Output, &EncodedSize); // 2 for 16bits<->8bits
		if (err != BE_ERR_SUCCESSFUL)
		{
			return -1;
		}
		
		// TODO no more while
		do {
			DWORD BytesWritten;
			WriteFile(the_OutputFile, Output, EncodedSize, &BytesWritten , NULL); // TODO : better handling
			EncodedSize -= BytesWritten;
		} while (EncodedSize != 0);

		the_SamplesUsed += the_SamplesPerBlock;
		lenToUse += the_WorkingBufferUseSize - the_SamplesPerBlock;
		the_WorkingBufferUseSize = 0;
	} // while

	memcpy(&the_WorkingBuffer[the_WorkingBufferUseSize], &OriginBuffer[TotalLen - lenToUse], lenToUse );
	the_WorkingBufferUseSize += lenToUse;
#endif // DISABLE_MP3OUTPUT

	return 0;
}

int  AOut::canwrite() { 
	the_Debug.OutPut("canwrite (%d)",the_MaxBuffer);
//	return 1152; // TODO : 576 is different cases
	if (the_LameDLL.IsLoaded())
		return 16*1024*1024; // TODO : 576 is different cases
	else
		return 0;
//	return the_MaxBuffer * 2 / the_Channels;
//	return the_MaxBuffer * 2 / the_Channels;
}

int  AOut::isplaying() { 
	the_Debug.OutPut("isplaying");
	return 0;
}

int  AOut::pause(const int) { 
	the_Debug.OutPut("pause");
	return 0;
}

void AOut::setvolume(const int volume) { 
	the_Debug.OutPut("setvolume at %d (not used yet)",volume);
	// -666 is the default volume... (nothing to do)
}

void AOut::setpan(const int pan) { 
	the_Debug.OutPut("setpan at %d (not used yet)", pan);
}

void AOut::flush(const int) { 
	the_Debug.OutPut("flush");
}

int  AOut::getoutputtime() { 
	the_Debug.OutPut("getoutputtime");
//	return 0;
	return getwrittentime();
}

int  AOut::getwrittentime() { 
	// SamplesUsed is actually a count of bytes used
	// so time in MS = (SamplesUsed * 1000) / (SamplesPerSec * (channels + bytes_per_sample))
	// note the plugin only supports 16bit input (2 bytes per sample)
	// to save the add, 1000 ms/s / 2 bytes_per_sample = 500
	// note that 32bit integer math should be avoided, since the value would overflow
	//int nTimeMs = (int)((double)the_SamplesUsed * 500.0 / ((double)the_SamplesPerSec * (double)the_Channels));
	int nTimeMs = (int)((__int64)the_SamplesUsed * 500 / (__int64)(the_SamplesPerSec * the_Channels));

	the_Debug.OutPut("getwrittentime = %d ms ", nTimeMs);
	
	return nTimeMs;
}


inline void AOut::UpMixToStereo(SHORT* psData,SHORT* psOutData,DWORD dwNumSamples)
{
	for (int dwSample=0; dwSample < dwNumSamples; dwSample++)
	{
		psOutData[2*dwSample+1] = psOutData[2*dwSample] = psData[dwSample];
	}
}

inline void AOut::MixToMono(SHORT* psData,SHORT* psOutData,DWORD dwNumSamples)
{
	for (int dwSample=0; dwSample < dwNumSamples; dwSample++)
	{
		psOutData[dwSample] = (psData[2*dwSample] >> 1) + (psData[2*dwSample+1] >> 1);
	}
}


void AOut::replaceAllChar(std::string & the_string, const char src, const char dst)
{
	std::string aSrc;
	aSrc = src;

	while (the_string.find( aSrc ) != std::string::npos)
	{
		std::string a_tmpStr = the_string.substr(0,the_string.find( aSrc ));
		a_tmpStr += dst;
		a_tmpStr += the_string.substr(the_string.find( aSrc ) + 1);
		the_string = a_tmpStr;
	}
}

int AOut::MyMessageBox(const char * the_output, const UINT the_type, const HWND the_parent)
{
	std::string str;
	str = "MP3 Output v";
	str += the_version_name;
	return MessageBox( the_parent, the_output, str.c_str() ,the_type);
}

bool AOut::GetLameVersion(BE_VERSION * ver)
{
	assert(ver != NULL);

	if (!the_LameDLL.Load(my_Properties.GetDllLocation()))
		return false;

	the_LameDLL.Version(ver);
	return true;
}
