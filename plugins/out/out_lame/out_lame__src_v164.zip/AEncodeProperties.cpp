/**

AEncodeProperties.cpp: implementation of the AEncodeProperties class.

$Id: AEncodeProperties.cpp,v 1.19 2005/10/06 02:58:23 prowler7 Exp $ 


$Log: AEncodeProperties.cpp,v $
Revision 1.19  2005/10/06 02:58:23  prowler7
- Fixed bit reservoir check box to properly report the state
- cleaned up a bit of the XML config code

Revision 1.18  2005/10/04 02:40:40  prowler7
Version 1.6.4
- Updated TinyXml to 2.3.4

Revision 1.17  2005/01/08 00:17:55  prowler7
added writing tag info using Get/Set Extended File Info

Revision 1.16  2005/01/06 23:48:42  prowler7
Fixed bug - getoutputtime() now uses 64-bit math to avoid the overflow that would typically happen at ~48sec of encoding stereo 44.1kHz.
Added feature to write custom tag information using Winamp's IPC_WRITE_EXTENDED_FILE_INFO, still need to expose this in the config GUI.

Revision 1.15  2004/12/08 04:10:38  prowler7
Version 1.6.2
- Fixed bug: Xing/Lame frame was never being written
- Fixed bug: Lame DLL location was not being saved
- Added all presets in Lame 3.96
- Option to always write the Xing/Lame frame (since Lame uses an extension of the Xing frame it applies to CBR too)
- Added explicit setting of psycho acoustic Quality (-q)
- About dialog now shows Lame alpha/beta revision and if MMX is supported

Revision 1.14  2001/09/04 18:49:49  robux4
Added r3mix support and very high qulity

Revision 1.13  2001/09/04 18:41:25  robux4
ABR now correctly working

Revision 1.12  2001/08/31 16:40:28  robux4
Added initial support for a static build to debug

Revision 1.11  2001/08/29 22:12:19  robux4
Few corrections on ABR mode

Revision 1.10  2001/08/29 21:41:38  robux4
Added ABR support

Revision 1.9  2001/08/13 18:44:42  robux4
Initial support for free borland compiler

Revision 1.8  2001/08/11 15:52:35  robux4
Better support of the having different configs

Revision 1.7  2001/08/11 15:26:14  robux4
Added possibility to rename and delete configurations

Revision 1.6  2001/08/11 09:34:15  robux4
Added better automatic config saving

Revision 1.5  2001/08/01 19:40:16  robux4
Updated with complete documentation support

Revision 1.4  2001/07/27 16:25:01  robux4
Update to fit tinyXML 1.2.3 (no more modifications)

Revision 1.3  2001/07/26 19:28:49  robux4
Added CVS tags
 

*/

#if !defined(STRICT)
#define STRICT
#endif // !defined(STRICT)

#include <windows.h>
#include <windowsx.h>
#include <shlobj.h>
#include <assert.h>

#include "wa_ipc.h"
typedef struct {
  const char *filename;
  const char *metadata;
  const char *ret;
  int retlen;
} cextendedFileInfoStruct;

#ifdef _MSC_VER
// no problem with unknown pragmas
#pragma warning(disable: 4068)
#endif

#include "resource.h"
#include "AOut.h"
//#include "AParameters/AParameters.h"
#include "AEncodeProperties.h"
#include "XmlHelp.h"

const unsigned int AEncodeProperties::the_Bitrates[18] = {320, 256, 224, 192, 160, 144, 128, 112, 96, 80, 64, 56, 48, 40, 32, 24, 16, 8 };
const unsigned int AEncodeProperties::the_MPEG1_Bitrates[14] = {320, 256, 224, 192, 160, 128, 112, 96, 80, 64, 56, 48, 40, 32 };
const unsigned int AEncodeProperties::the_MPEG2_Bitrates[14] = {160, 144, 128, 112, 96, 80, 64, 56, 48, 40, 32, 24, 16, 8};
const unsigned int AEncodeProperties::the_ChannelModes[] = {BE_MP3_MODE_MONO, BE_MP3_MODE_STEREO, BE_MP3_MODE_JSTEREO, BE_MP3_MODE_DUALCHANNEL };
// keep presets in sync with AEncodeProperties::GetPresetModeString()
const LAME_QUALITY_PRESET AEncodeProperties::the_Presets[THE_PRESETS_COUNT] = {LQP_NOPRESET, LQP_NORMAL_QUALITY, LQP_LOW_QUALITY, LQP_HIGH_QUALITY, LQP_VERYHIGH_QUALITY, LQP_MEDIUM, LQP_FAST_MEDIUM, LQP_STANDARD, LQP_FAST_STANDARD, LQP_EXTREME, LQP_FAST_EXTREME, LQP_INSANE, LQP_ABR, LQP_CBR, LQP_R3MIX, LQP_PHONE, LQP_SW, LQP_AM, LQP_FM, LQP_VOICE, LQP_VOICE_QUALITY, LQP_RADIO, LQP_TAPE, LQP_HIFI, LQP_CD, LQP_STUDIO};
const unsigned int AEncodeProperties::the_SamplingFreqs[9] = { 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000 };

//int AEncodeProperties::tst = 0;


#pragma argsused
static UINT CALLBACK DLLFindCallback(
  HWND hdlg,      // handle to child dialog box
  UINT uiMsg,     // message identifier
  WPARAM wParam,  // message parameter
  LPARAM lParam   // message parameter
  )
{
	UINT result = 0;

	switch (uiMsg)
	{
		case WM_NOTIFY:
			OFNOTIFY * info = (OFNOTIFY *)lParam;
			if (info->hdr.code == CDN_FILEOK)
			{
				result = 1; // by default we don't accept the file

				// Check if the selected file is a valid DLL with all the required functions
				ALameDLL * tstFile = new ALameDLL;
				if (tstFile != NULL)
				{
					if (tstFile->Load(info->lpOFN->lpstrFile))
					{
						result = 0;
					}

					delete tstFile;
				}

				if (result == 1)
				{
					TCHAR output[250];
					::LoadString(AOut::GetInstance(),IDS_STRING_DLL_UNRECOGNIZED,output,250);
					AOut::MyMessageBox( output, MB_OK|MB_ICONEXCLAMATION, hdlg);
					SetWindowLong(hdlg, DWL_MSGRESULT , -100);
				}
			}
	}

	return result;
}

#pragma argsused
static int CALLBACK BrowseFolderCallbackroc(
    HWND hwnd,
    UINT uMsg,
    LPARAM lParam,
    LPARAM lpData
    )
{
	AEncodeProperties * the_prop;
	the_prop = (AEncodeProperties *) lpData;


	if (uMsg == BFFM_INITIALIZED)
	{
//		char FolderName[MAX_PATH];
//		SHGetPathFromIDList((LPITEMIDLIST) lParam,FolderName);
//ADbg tst;
//tst.OutPut("init folder to %s ",the_prop->GetOutputDirectory());
//		CreateFile();
		::SendMessage(hwnd, BFFM_SETSELECTION, (WPARAM)TRUE, (LPARAM)the_prop->GetOutputDirectory());
	}/* else if (uMsg == BFFM_SELCHANGED)
	{
		// verify that the folder is writable
//		::SendMessage(hwnd, BFFM_ENABLEOK, 0, (LPARAM)0); // disable
		char FolderName[MAX_PATH];
		SHGetPathFromIDList((LPITEMIDLIST) lParam, FolderName);
		
//		if (CreateFile(FolderName,STANDARD_RIGHTS_WRITE,0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL) == INVALID_HANDLE_VALUE)
		if ((GetFileAttributes(FolderName) & FILE_ATTRIBUTE_DIRECTORY) != 0)
			::SendMessage(hwnd, BFFM_ENABLEOK, 0, (LPARAM)1); // enable
		else
			::SendMessage(hwnd, BFFM_ENABLEOK, 0, (LPARAM)0); // disable
//ADbg tst;
//tst.OutPut("change folder to %s ",FolderName);
	}*/

	return 0;
}

#pragma argsused
static BOOL CALLBACK ConfigProc(
  HWND hwndDlg,  // handle to dialog box
  UINT uMsg,     // message
  WPARAM wParam, // first message parameter
  LPARAM lParam  // second message parameter
  )
{
	BOOL bResult;
	AEncodeProperties * the_prop;
	the_prop = (AEncodeProperties *) GetProp(hwndDlg, "AEncodeProperties-Config");

	switch (uMsg) {
		case WM_COMMAND:
			if (the_prop != NULL)
			{
				bResult = the_prop->HandleDialogCommand( hwndDlg, wParam, lParam);
			}
			break;
		case WM_INITDIALOG:
			assert(the_prop == NULL);

			the_prop = (AEncodeProperties *) lParam;

			assert(the_prop != NULL);

			SetProp(hwndDlg, "AEncodeProperties-Config", the_prop);

			the_prop->InitConfigDlg(hwndDlg);

			bResult = TRUE;
			break;
		case WM_HSCROLL:
			// check if it's the Quality slider
			if ((HWND)lParam == GetDlgItem(hwndDlg,IDC_SLIDER_QUALITY))
			{
				UINT VbrQuality = SendMessage(GetDlgItem( hwndDlg, IDC_SLIDER_QUALITY), TBM_GETPOS, NULL, NULL);
				char tmp[2];
				wsprintf(tmp,"%d",VbrQuality);
				::SetWindowText(GetDlgItem( hwndDlg, IDC_CONFIG_QUALITY), tmp);
			}
			else if ((HWND)lParam == GetDlgItem(hwndDlg,IDC_SLIDER_QQUALITY))
			{
				// -q quality
				UINT Quality = SendMessage(GetDlgItem( hwndDlg, IDC_SLIDER_QQUALITY), TBM_GETPOS, NULL, NULL);
				char tmp[2];
				wsprintf(tmp,"%d",Quality);
				::SetWindowText(GetDlgItem( hwndDlg, IDC_CONFIG_QQUALITY), tmp);
			}
			break;
		default:
			bResult = FALSE; // will be treated by DefWindowProc
	}
	return bResult;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
/**
	\class AEncodeProperties
*/


const char * AEncodeProperties::GetChannelModeString(int a_channelID) const
{
	assert(a_channelID < sizeof(the_ChannelModes));

	switch (a_channelID) {
		case 0:
			return "Mono";
		case 1:
			return "Stereo";
		case 2:
			return "Joint-stereo";
		default:
			return "Dual Channel";
	}
}

const int AEncodeProperties::GetBitrateString(char * string, int string_size, int a_bitrateID) const
{
	assert(a_bitrateID < sizeof(the_Bitrates));
	assert(string != NULL);

	if (string_size >= 4)
		return wsprintf(string,"%d",the_Bitrates[a_bitrateID]);
	else
		return -1;
}

const unsigned int AEncodeProperties::GetChannelModeValue() const
{
	assert(nChannelIndex < sizeof(the_ChannelModes));

	return the_ChannelModes[nChannelIndex];
}

// get quality value in LAME WORD format, high byte is NOT low byte
const WORD AEncodeProperties::GetQualityValue() const
{
	return bUseQuality ? MAKEWORD((BYTE)Quality, ~((BYTE)Quality)) : 0;
}

const unsigned int AEncodeProperties::GetBitrateValue() const
{
	assert(nMinBitrateIndex < sizeof(the_Bitrates));

	return the_Bitrates[nMinBitrateIndex];
}

inline const int AEncodeProperties::GetBitrateValueMPEG2(DWORD & bitrate) const
{
	int i;

	for (i=0;i<sizeof(the_MPEG2_Bitrates)/sizeof(unsigned int);i++)
	{
		if (the_MPEG2_Bitrates[i] == the_Bitrates[nMinBitrateIndex])
		{
			bitrate = the_MPEG2_Bitrates[i];
			return 0;
		}
		else if (the_MPEG2_Bitrates[i] < the_Bitrates[nMinBitrateIndex])
		{
			bitrate = the_MPEG2_Bitrates[i];
			return -1;
		}
	}
	
	bitrate = 160;
	return -1;
}

inline const int AEncodeProperties::GetBitrateValueMPEG1(DWORD & bitrate) const
{
	int i;

	for (i=sizeof(the_MPEG1_Bitrates)/sizeof(unsigned int)-1;i>=0;i--)
	{
		if (the_MPEG1_Bitrates[i] == the_Bitrates[nMinBitrateIndex])
		{
			bitrate = the_MPEG1_Bitrates[i];
			return 0;
		}
		else if (the_MPEG1_Bitrates[i] > the_Bitrates[nMinBitrateIndex])
		{
			bitrate = the_MPEG1_Bitrates[i];
			return 1;
		}
	}
	
	bitrate = 32;
	return 1;
}

const int AEncodeProperties::GetBitrateValue(DWORD & bitrate, const DWORD MPEG_Version) const
{
	assert((MPEG_Version == MPEG1) || (MPEG_Version == MPEG2));
	assert(nMinBitrateIndex < sizeof(the_Bitrates));

	if (MPEG_Version == MPEG2)
		return GetBitrateValueMPEG2(bitrate);
	else
		return GetBitrateValueMPEG1(bitrate);
}

// add all presets, make sure this is in sync with the_Presets[]
const char * AEncodeProperties::GetPresetModeString(const int a_presetID) const
{
	assert(a_presetID < GetPresetLentgh());

	switch (a_presetID) {
		case 1:
			return "Normal";
		case 2:
			return "Low";
		case 3:
			return "High";
		case 4:
			return "Very High";
		case 5:
			return "AP Medium";
		case 6:
			return "AP Fast Medium";
		case 7:
			return "AP Standard";
		case 8:
			return "AP Fast Standard";
		case 9:
			return "AP Extreme";
		case 10:
			return "AP Fast Extreme";
		case 11:
			return "AP Insane";
		case 12:
			return "AP ABR";
		case 13:
			return "AP CBR";
		case 14:
			return "r3mix";
		case 15:
			return "Phone";
		case 16:
			return "SW";
		case 17:
			return "AM";
		case 18:
			return "FM";
		case 19:
			return "Voice";
		case 20:
			return "Voice Quality";
		case 21:
			return "Radio";
		case 22:
			return "Tape";
		case 23:
			return "Hi-Fi";
		case 24:
			return "CD";
		case 25:
			return "Studio";
		default:
			return "None";
	}
}

const LAME_QUALITY_PRESET AEncodeProperties::GetPresetModeValue() const
{
	assert(nPresetIndex < GetPresetLentgh());

	return the_Presets[nPresetIndex];
}

bool AEncodeProperties::Config(const HINSTANCE Hinstance, const HWND HwndParent)
{
	//WM_INITDIALOG ?

	// remember the instance to retreive strings
	hDllInstance = Hinstance;

	int ret = ::DialogBoxParam(Hinstance, MAKEINTRESOURCE(IDD_CONFIG), HwndParent, ::ConfigProc, (LPARAM) this);
	if (ret == -1)
	{
		LPVOID lpMsgBuf;
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
		);
		// Process any inserts in lpMsgBuf.
		// ...
		// Display the string.
		AOut::MyMessageBox( (LPCTSTR)lpMsgBuf, MB_OK | MB_ICONINFORMATION );
		// Free the buffer.
		LocalFree( lpMsgBuf );	
		return false;
	}
	
	return true;
}

bool AEncodeProperties::InitConfigDlg(HWND HwndDlg)
{
	// get all the required strings
//	TCHAR Version[5];
//	LoadString(hDllInstance, IDS_STRING_VERSION, Version, 5);

	int i;

	// Add required channel modes
	SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_CHANNELS), CB_RESETCONTENT , NULL, NULL);
	for (i=0;i<GetChannelLentgh();i++)
		SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_CHANNELS), CB_ADDSTRING, NULL, (LPARAM) GetChannelModeString(i));

	// Add all possible re-sampling freq
	SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SAMPLEFREQ), CB_RESETCONTENT , NULL, NULL);
	char tmp[10];
	for (i=0;i<sizeof(the_SamplingFreqs)/sizeof(unsigned int);i++)
	{
		wsprintf(tmp, "%d", the_SamplingFreqs[i]);
		SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SAMPLEFREQ), CB_ADDSTRING, NULL, (LPARAM) tmp );
	}
	

	// Add required bitrates
	SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_BITRATE), CB_RESETCONTENT , NULL, NULL);
	for (i=0;i<GetBitrateLentgh();i++)
	{
		GetBitrateString(tmp, 5, i);
		SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_BITRATE), CB_ADDSTRING, NULL, (LPARAM) tmp );
	}

	// Add bitrates to the VBR combo box too
	SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_MAXBITRATE), CB_RESETCONTENT , NULL, NULL);
	for (i=0;i<GetBitrateLentgh();i++)
	{
		GetBitrateString(tmp, 5, i);
		SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_MAXBITRATE), CB_ADDSTRING, NULL, (LPARAM) tmp );
	}

	// Add VBR Quality Slider
	SendMessage(GetDlgItem( HwndDlg, IDC_SLIDER_QUALITY), TBM_SETRANGE, TRUE, MAKELONG(0,9));

	// set Quality Slider range
	SendMessage(GetDlgItem( HwndDlg, IDC_SLIDER_QQUALITY), TBM_SETRANGE, TRUE, MAKELONG(0,9));

	// Add presets
	SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_PRESET), CB_RESETCONTENT , NULL, NULL);
	for (i=0;i<GetPresetLentgh();i++)
		SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_PRESET), CB_ADDSTRING, NULL, (LPARAM) GetPresetModeString(i));

	UpdateConfigs(HwndDlg);

	UpdateDlgFromValue(HwndDlg);

	return true;
}

bool AEncodeProperties::UpdateDlgFromValue(HWND HwndDlg)
{
	// get all the required strings
//	TCHAR Version[5];
//	LoadString(hDllInstance, IDS_STRING_VERSION, Version, 5);

	int i;

	// Check boxes if required
	::CheckDlgButton( HwndDlg, IDC_CHECK_CRC,          GetCRCMode()      ?BST_CHECKED:BST_UNCHECKED );
	::CheckDlgButton( HwndDlg, IDC_CHECK_ORIGINAL,     GetOriginalMode() ?BST_CHECKED:BST_UNCHECKED );
	::CheckDlgButton( HwndDlg, IDC_CHECK_PRIVATE,      GetPrivateMode()  ?BST_CHECKED:BST_UNCHECKED );
	::CheckDlgButton( HwndDlg, IDC_CHECK_COPYRIGHT,    GetCopyrightMode()?BST_CHECKED:BST_UNCHECKED );
	::CheckDlgButton( HwndDlg, IDC_CHECK_RESERVOIR,    !GetNoBiResMode() ?BST_CHECKED:BST_UNCHECKED );
	::CheckDlgButton( HwndDlg, IDC_CHECK_XINGVBR,      GetXingFrameMode()?BST_CHECKED:BST_UNCHECKED );
	::CheckDlgButton( HwndDlg, IDC_CHECK_RESAMPLE,     GetResampleMode() ?BST_CHECKED:BST_UNCHECKED );
	::CheckDlgButton( HwndDlg, IDC_CHECK_CHANNELFORCE, bForceChannel     ?BST_CHECKED:BST_UNCHECKED );
	::CheckDlgButton( HwndDlg, IDC_CHECK_QQUALITY,     bUseQuality       ?BST_CHECKED:BST_UNCHECKED );
	
	// Add required channel modes
	for (i=0;i<GetChannelLentgh();i++)
	{
		if (i == nChannelIndex)
		{
			SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_CHANNELS), CB_SETCURSEL, i, NULL);
			break;
		}
	}

	// Add all possible re-sampling freq
	SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SAMPLEFREQ), CB_SETCURSEL, nSamplingFreqIndex, NULL);
	

	// Add required bitrates
	for (i=0;i<GetBitrateLentgh();i++)
	{
		if (i == nMinBitrateIndex)
		{
			SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_BITRATE), CB_SETCURSEL, i, NULL);
			break;
		}
	}

	// Add bitrates to the VBR combo box too
	for (i=0;i<GetBitrateLentgh();i++)
	{
		if (i == nMaxBitrateIndex)
		{
			SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_MAXBITRATE), CB_SETCURSEL, i, NULL);
			break;
		}
	}

	// Add VBR Quality
//	SendMessage(GetDlgItem( HwndDlg, IDC_SLIDER_QUALITY), TBM_SETRANGE, TRUE, MAKELONG(0,9));

	char tmp[3];
	wsprintf(tmp,"%d",VbrQuality);
	SetWindowText(GetDlgItem( HwndDlg, IDC_CONFIG_QUALITY), tmp);
	SendMessage(GetDlgItem( HwndDlg, IDC_SLIDER_QUALITY), TBM_SETPOS, TRUE, VbrQuality);

	// enable quality settings
	wsprintf(tmp,"%d",Quality);
	SetWindowText(GetDlgItem( HwndDlg, IDC_CONFIG_QQUALITY), tmp);
	SendMessage(GetDlgItem( HwndDlg, IDC_SLIDER_QQUALITY), TBM_SETPOS, TRUE, Quality);
	::EnableWindow(::GetDlgItem( HwndDlg, IDC_SLIDER_QQUALITY), bUseQuality);
	::EnableWindow(::GetDlgItem( HwndDlg, IDC_CONFIG_QQUALITY), bUseQuality);
	::EnableWindow(::GetDlgItem( HwndDlg, IDC_STATIC_QQUALITY_LOW), bUseQuality);
	::EnableWindow(::GetDlgItem( HwndDlg, IDC_STATIC_QQUALITY_HIGH), bUseQuality);

	wsprintf(tmp,"%d",AverageBitrate);
	SetWindowText(GetDlgItem( HwndDlg, IDC_EDIT_AVERAGE), tmp);
	
	// Display VBR settings if needed
	AEncodeProperties::DisplayVbrOptions(HwndDlg, mBRmode);

	// Display Resample settings if needed
	if (GetResampleMode())
	{
		::EnableWindow(::GetDlgItem(HwndDlg,IDC_COMBO_SAMPLEFREQ), TRUE);
	}
	else
	{
		::EnableWindow(::GetDlgItem(HwndDlg,IDC_COMBO_SAMPLEFREQ), FALSE);
	}


	// Add presets
	for (i=0;i<GetPresetLentgh();i++)
	{
		if (i == nPresetIndex)
		{
			SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_PRESET), CB_SETCURSEL, i, NULL);
			break;
		}
	}

	// Add User configs
//	SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SETTINGS), CB_RESETCONTENT , NULL, NULL);
	::SetWindowText(::GetDlgItem( HwndDlg, IDC_EDIT_OUTPUTDIR), OutputDir.c_str());

	/**
		\todo Select the right saved config
	*/
#ifdef OLD
	AParameters prms;

	prms.Attach("SOFTWARE\\MUKOLI\\out_lame\\Configs");

	char currentName[MAX_PATH];
	unsigned long DSize = MAX_PATH;
	prms.QueryValue("current", currentName, DSize);

	char string[MAX_PATH];

//	int i=0;
	while (prms.NextSubKey( string, MAX_PATH) == AParameters::KEY_FOUND)
	{
		AParameters * tmpkey = prms.GetSubKey(string);

		char string2[MAX_PATH];
		unsigned long DSize = MAX_PATH;

		tmpkey->QueryValue("Name", string2, DSize);
//		SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SETTINGS), CB_ADDSTRING, NULL, (LPARAM) string2);
		prms.ReleaseSubKey(tmpkey);

		if (strcmp(string,currentName) == 0)
		{
			SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SETTINGS), CB_SETCURSEL, i, NULL);
			break;
		}

		i++;
	}

	prms.Detach();
#endif // OLD

	return true;
}

bool AEncodeProperties::UpdateValueFromDlg(HWND HwndDlg)
{
	nChannelIndex      = SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_CHANNELS),   CB_GETCURSEL, NULL, NULL);
	nMinBitrateIndex   = SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_BITRATE),    CB_GETCURSEL, NULL, NULL);
	nMaxBitrateIndex   = SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_MAXBITRATE), CB_GETCURSEL, NULL, NULL);
	nPresetIndex       = SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_PRESET),     CB_GETCURSEL, NULL, NULL);
	VbrQuality         = SendMessage(GetDlgItem( HwndDlg, IDC_SLIDER_QUALITY), TBM_GETPOS , NULL, NULL);
	Quality            = SendMessage(GetDlgItem( HwndDlg, IDC_SLIDER_QQUALITY), TBM_GETPOS , NULL, NULL);
	nSamplingFreqIndex = SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SAMPLEFREQ), CB_GETCURSEL, NULL, NULL);

	bCRC          = (::IsDlgButtonChecked( HwndDlg, IDC_CHECK_CRC)          == BST_CHECKED);
	bCopyright    = (::IsDlgButtonChecked( HwndDlg, IDC_CHECK_COPYRIGHT)    == BST_CHECKED);
	bOriginal     = (::IsDlgButtonChecked( HwndDlg, IDC_CHECK_ORIGINAL)     == BST_CHECKED);
	bPrivate      = (::IsDlgButtonChecked( HwndDlg, IDC_CHECK_PRIVATE)      == BST_CHECKED);
	bNoBitRes     =!(::IsDlgButtonChecked( HwndDlg, IDC_CHECK_RESERVOIR)    == BST_CHECKED);
	bXingFrame    = (::IsDlgButtonChecked( HwndDlg, IDC_CHECK_XINGVBR)      == BST_CHECKED);
	bResample     = (::IsDlgButtonChecked( HwndDlg, IDC_CHECK_RESAMPLE)     == BST_CHECKED);
	bForceChannel = (::IsDlgButtonChecked( HwndDlg, IDC_CHECK_CHANNELFORCE) == BST_CHECKED);
	bUseQuality   = (::IsDlgButtonChecked( HwndDlg, IDC_CHECK_QQUALITY)  == BST_CHECKED);

	char tmpPath[MAX_PATH];
	::GetWindowText( ::GetDlgItem( HwndDlg, IDC_EDIT_OUTPUTDIR), tmpPath, MAX_PATH);
	OutputDir = tmpPath;

	if (::IsDlgButtonChecked(HwndDlg, IDC_RADIO_BITRATE_CBR) == BST_CHECKED)
		mBRmode = BR_CBR;
	else if (::IsDlgButtonChecked(HwndDlg, IDC_RADIO_BITRATE_VBR) == BST_CHECKED)
		mBRmode = BR_VBR;
	else
		mBRmode = BR_ABR;
	
	::GetWindowText( ::GetDlgItem( HwndDlg, IDC_EDIT_AVERAGE), tmpPath, MAX_PATH);
	AverageBitrate = atoi(tmpPath);
	if (AverageBitrate < 8)
		AverageBitrate = 8;
	if (AverageBitrate > 320)
		AverageBitrate = 320;

	return true;
}

VBRMETHOD AEncodeProperties::GetVBRValue(DWORD & MaxBitrate, int & Quality, DWORD & AbrBitrate, BOOL & VBRHeader, const DWORD MPEG_Version) const
{
	assert((MPEG_Version == MPEG1) || (MPEG_Version == MPEG2));
	assert(nMaxBitrateIndex < sizeof(the_Bitrates));

	// always set xing frame
	VBRHeader = bXingFrame;
	if (mBRmode == BR_VBR)
	{
		MaxBitrate = the_Bitrates[nMaxBitrateIndex];

		if (MPEG_Version == MPEG1)
			MaxBitrate = MaxBitrate>the_MPEG1_Bitrates[sizeof(the_MPEG1_Bitrates)/sizeof(unsigned int)-1]?MaxBitrate:the_MPEG1_Bitrates[sizeof(the_MPEG1_Bitrates)/sizeof(unsigned int)-1];
		else
			MaxBitrate = MaxBitrate<the_MPEG2_Bitrates[0]?MaxBitrate:the_MPEG2_Bitrates[0];

		Quality = VbrQuality;
		AbrBitrate = 0;

		return VBR_METHOD_DEFAULT; // for the moment
	} 
	else if (mBRmode == BR_ABR)
	{
		MaxBitrate = the_Bitrates[nMaxBitrateIndex];

		if (MPEG_Version == MPEG1)
			MaxBitrate = MaxBitrate>the_MPEG1_Bitrates[sizeof(the_MPEG1_Bitrates)/sizeof(unsigned int)-1]?MaxBitrate:the_MPEG1_Bitrates[sizeof(the_MPEG1_Bitrates)/sizeof(unsigned int)-1];
		else
			MaxBitrate = MaxBitrate<the_MPEG2_Bitrates[0]?MaxBitrate:the_MPEG2_Bitrates[0];

		Quality = 0;
		AbrBitrate = AverageBitrate*1000;
		return VBR_METHOD_ABR;
	}
	else
	{
		return VBR_METHOD_NONE;
	}
}

void AEncodeProperties::ParamsRestore()
{
	// use these default parameters in case one is not found
	bCopyright    = true;
	bCRC          = true;
	bOriginal     = true;
	bPrivate      = true;
	bNoBitRes     = false; // enable bit reservoir
	bXingFrame    = true;
	bResample     = false;
	bForceChannel = false;
	bUseQuality   = false; // no quality setting by default

	nChannelIndex = 2; // joint-stereo
	mBRmode       = BR_CBR;
	nMinBitrateIndex = 6; // 128 kbps (works for both MPEGI and II)
	nMaxBitrateIndex = 4; // 160 kbps (works for both MPEGI and II)
	nPresetIndex = 0; // None
	VbrQuality = 1; // Quite High
	Quality = 2; // high quality by default
	AverageBitrate = 128; // a bit lame
	nSamplingFreqIndex = 1; // 44100

	OutputDir = "c:\\";

	DllLocation = "plugins\\lame_enc.dll";

	// get the values from the saved file if possible
	if (my_stored_data.LoadFile(my_store_location))
	{
		TiXmlNode* node;

		node = my_stored_data.FirstChild("out_lame");

		TiXmlElement* CurrentNode = node->FirstChildElement("configs");

		std::string CurrentConfig = "";

		if (CurrentNode->Attribute("default") != NULL)
		{
			CurrentConfig = CurrentNode->Attribute("default");
		}

		// output parameters
		TiXmlElement* iterateElmt = node->FirstChildElement("DLL");
		if (iterateElmt != NULL)
		{
			const char* tmpname = iterateElmt->Attribute("location");
			if (tmpname != NULL)
			{
				DllLocation = tmpname;
			}
		}

		GetValuesFromKey(CurrentConfig, *CurrentNode);
	}
	else
	{
		/**
			\todo save the data in the file !
		*/
	}
}

void AEncodeProperties::ParamsSave()
{
/*


	save the current parameters in the corresponding subkey
	



	HKEY OssKey;

	if (RegCreateKeyEx ( HKEY_LOCAL_MACHINE, "SOFTWARE\\MUKOLI\\out_lame", 0, "", REG_OPTION_NON_VOLATILE, KEY_WRITE , NULL, &OssKey, NULL ) == ERROR_SUCCESS) {

		if (RegSetValueEx(OssKey, "DLL Location", 0, REG_EXPAND_SZ, (CONST BYTE *)DllLocation, strlen(DllLocation)+1 ) != ERROR_SUCCESS)
			return;
		
		RegCloseKey(OssKey); 
	}
*/
}

void AEncodeProperties::DisplayVbrOptions(const HWND hDialog, const BRMode the_mode)
{
	bool bVBR = false;
	bool bABR = false;

	switch ( the_mode )
	{
		case BR_CBR:
			::CheckRadioButton(hDialog, IDC_RADIO_BITRATE_CBR, IDC_RADIO_BITRATE_ABR, IDC_RADIO_BITRATE_CBR);
			break;
		case BR_VBR:
			::CheckRadioButton(hDialog, IDC_RADIO_BITRATE_CBR, IDC_RADIO_BITRATE_ABR, IDC_RADIO_BITRATE_VBR);
			bVBR = true;
			break;
		case BR_ABR:
			::CheckRadioButton(hDialog, IDC_RADIO_BITRATE_CBR, IDC_RADIO_BITRATE_ABR, IDC_RADIO_BITRATE_ABR);
			bABR = true;
			break;

	}

	if(bVBR|bABR)
	{
		::SetWindowText(::GetDlgItem(hDialog,IDC_STATIC_MINBITRATE), "Min Bitrate");
	}
	else
	{
		::SetWindowText(::GetDlgItem(hDialog,IDC_STATIC_MINBITRATE), "Bitrate");
	}

	// always allow Xing/lame frame
	//::EnableWindow(::GetDlgItem( hDialog, IDC_CHECK_XINGVBR), bVBR|bABR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_COMBO_MAXBITRATE), bVBR|bABR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_STATIC_MAXBITRATE), bVBR|bABR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_SLIDER_QUALITY), bVBR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_CONFIG_QUALITY), bVBR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_STATIC_VBRQUALITY), bVBR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_STATIC_VBRQUALITY_LOW), bVBR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_STATIC_VBRQUALITY_HIGH), bVBR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_STATIC_ABR), bABR);

	::EnableWindow(::GetDlgItem( hDialog, IDC_EDIT_AVERAGE), bABR);
}

AEncodeProperties::AEncodeProperties()
{
	std::string path = "";
	HMODULE htmp = LoadLibrary("out_lame.dll");
	if (htmp != NULL)
	{
		char output[MAX_PATH];
		::GetModuleFileName(htmp, output, MAX_PATH);
		::FreeLibrary(htmp);

		path = output;
	}
	my_store_location = path.substr(0,path.find_last_of('\\')+1);
	my_store_location += "out_lame.xml";
//	::OutputDebugString(my_store_location.c_str());

	// make sure the XML file is present
	HANDLE hFile = ::CreateFile(my_store_location.c_str(), 0, FILE_SHARE_READ|FILE_SHARE_WRITE, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_ARCHIVE, NULL );
	::CloseHandle(hFile);
}

// Save the values to the right XML saved config
void AEncodeProperties::SaveValuesToStringKey(const std::string & config_name)
{
	// get the current data in the file to keep them
	if (my_stored_data.LoadFile(my_store_location))
	{
		// check if the Node corresponding to the config_name already exist.
		TiXmlNode* node = my_stored_data.FirstChild("out_lame");

		if (node != NULL)
		{
			TiXmlElement* ConfigNode = node->FirstChildElement("configs");

			if (ConfigNode != NULL)
			{
				// look all the <config> tags
				TiXmlElement* tmpNode = ConfigNode->FirstChildElement("config");
				while (tmpNode != NULL)
				{
					const std::string tmpname(tmpNode->Attribute("name"));
					if (tmpname.compare(config_name) == 0)
					{
						break;
					}
					tmpNode = tmpNode->NextSiblingElement("config");
				}

				if (tmpNode == NULL)
				{
					// Create the node
					tmpNode = new TiXmlElement("config");
					tmpNode->SetAttribute("name",config_name);

					// save data in the node
					SaveValuesToElement(tmpNode);

					ConfigNode->InsertEndChild(*tmpNode);
				}
				else
				{
					// save data in the node
					SaveValuesToElement(tmpNode);
				}


				// and save the file
				my_stored_data.SaveFile(my_store_location);
			}
		}
	}
}

// Save the DLL location to the XML
void AEncodeProperties::SaveDLLlocation()
{
	// get the current data in the file to keep them
	if (my_stored_data.LoadFile(my_store_location))
	{
		// check if the Node corresponding to the config_name already exist.
		TiXmlNode* node = my_stored_data.FirstChild("out_lame");

		if (node != NULL)
		{
			// save DLL location
			TiXmlElement* DllNode = node->FirstChildElement("DLL");
			if (DllNode != NULL)
				DllNode->SetAttribute("location", DllLocation);

			// and save the file
			my_stored_data.SaveFile(my_store_location);
		}
	}
}

void AEncodeProperties::GetValuesFromKey(const std::string & config_name, const TiXmlNode & parentNode)
{
	const TiXmlElement* tmpElt;
	const TiXmlElement* iterateElmt;

	// find the config that correspond to CurrentConfig
	iterateElmt = parentNode.FirstChildElement("config");
	while (iterateElmt != NULL)
	{
		const std::string tmpname(iterateElmt->Attribute("name"));
		if (tmpname.compare(config_name) == 0)
		{
			break;
		}
		iterateElmt = iterateElmt->NextSiblingElement("config");
	}

	if (iterateElmt != NULL)
	{
		// get all the parameters saved in this Element
		std::string tmpname;

		// Copyright parameter
		bCopyright = GetBoolFromElementAttribute(iterateElmt, "Copyright", "use", bCopyright);

		// Copyright parameter
		bCRC = GetBoolFromElementAttribute(iterateElmt, "CRC", "use", bCRC);

		// Copyright parameter
		bOriginal = GetBoolFromElementAttribute(iterateElmt, "Original", "use", bOriginal);

		// Copyright parameter
		bPrivate = GetBoolFromElementAttribute(iterateElmt, "Private", "use", bPrivate);

		// Copyright parameter
		bNoBitRes = !GetBoolFromElementAttribute(iterateElmt, "Bit_reservoir", "use", !bNoBitRes);

		// bitrates
		tmpElt = iterateElmt->FirstChildElement("bitrate");
		tmpname = tmpElt->Attribute("min");
		if (tmpname.size() > 0)
		{
			unsigned int uitmp = atoi(tmpname.c_str());
			for (int i=0;i<sizeof(the_Bitrates)/sizeof(unsigned int);i++)
			{
				if (the_Bitrates[i] == uitmp)
				{
					nMinBitrateIndex = i;
					break;
				}
			}
		}

		tmpname = tmpElt->Attribute("max");
		if (tmpname.size() > 0)
		{
			unsigned int uitmp = atoi(tmpname.c_str());
			for (int i=0;i<sizeof(the_Bitrates)/sizeof(unsigned int);i++)
			{
				if (the_Bitrates[i] == uitmp)
				{
					nMaxBitrateIndex = i;
					break;
				}
			}
		}

		// quality
		tmpElt = iterateElmt->FirstChildElement("Quality");
		if (tmpElt != NULL)
		{
			bUseQuality = GetBoolFromAttribute(tmpElt, "use", bUseQuality);
			Quality = GetIntFromAttribute(tmpElt, "value", Quality);
		}

		// resampling parameters
		tmpElt = iterateElmt->FirstChildElement("resampling");
		if (tmpElt != NULL)
		{
			bResample = GetBoolFromAttribute(tmpElt, "use", bResample);

			unsigned int uitmp = atoi(tmpElt->Attribute("freq"));
			for (int i=0;i<sizeof(the_SamplingFreqs)/sizeof(unsigned int);i++)
			{
				if (the_SamplingFreqs[i] == uitmp)
				{
					nSamplingFreqIndex = i;
					break;
				}
			}
		}

		// VBR parameters
		tmpElt = iterateElmt->FirstChildElement("VBR");
		if (tmpElt != NULL)
		{
			tmpname = tmpElt->Attribute("use");
			if (tmpname.size() > 0)
			{
				if (tmpname.compare("ABR") == 0)
					mBRmode = BR_ABR;
				else if (tmpname.compare("true") == 0)
					mBRmode = BR_VBR;
				else
					mBRmode = BR_CBR;
			}

			bXingFrame = GetBoolFromAttribute(tmpElt, "header", bXingFrame);
			VbrQuality = GetIntFromAttribute(tmpElt, "quality", VbrQuality);
			AverageBitrate = GetIntFromAttribute(tmpElt, "average", AverageBitrate);
		}

		// output parameters
		tmpElt = iterateElmt->FirstChildElement("output");
		if (tmpElt != NULL)
		{
			OutputDir = tmpElt->Attribute("path");
		}

		// Channel mode parameter
		tmpElt = iterateElmt->FirstChildElement("Channel");
		if (tmpElt != NULL)
		{
			std::string tmpStr(tmpElt->Attribute("mode"));
			for (int i=0;i<GetChannelLentgh();i++)
			{
				if (tmpStr.compare(GetChannelModeString(i)) == 0)
				{
					nChannelIndex = i;
					break;
				}
			}

			bForceChannel = GetBoolFromAttribute(tmpElt, "force", bForceChannel);
		}

		// Preset parameter
		tmpElt = iterateElmt->FirstChildElement("Preset");
		if (tmpElt != NULL)
		{
			const std::string tmpStr(tmpElt->Attribute("type"));
			for (int i=0;i<GetPresetLentgh();i++)
			{
				if (tmpStr.compare(GetPresetModeString(i)) == 0)
				{
					nPresetIndex = i;
					break;
				}
			}
		}

		// ID3 tag - metadata
		vMetadata.clear();
		tmpElt = iterateElmt->FirstChildElement("tag");
		if (tmpElt != NULL)
		{
			std::string pstr(tmpElt->Attribute("autoyear"));
			if(pstr.size() > 0)
				bTagAutoYear = pstr.compare("true") == 0;
			else
				bTagAutoYear = false;

			const TiXmlElement *ptxeMeta = tmpElt->FirstChildElement("metadata");
			while(ptxeMeta) {
				const std::string pstrField(ptxeMeta->Attribute("field"));
				const std::string pstrValue(ptxeMeta->Attribute("value"));
				if(pstrField.size() > 0 && pstrValue.size() > 0)
				{
					MetadataItem mdi;
					mdi.strField = pstrField.c_str();
					mdi.strValue = pstrValue.c_str();
					if(!mdi.strField.empty() && !mdi.strValue.empty()) {
						vMetadata.push_back(mdi);
						if(mdi.strField.compare("title") == 0) {
							pstr = ptxeMeta->Attribute("appenddate");
							if(pstr.size() > 0)
								bTagDateTitle = pstr.compare("true") == 0;
							else
								bTagDateTitle = false;
						}
					}
				}
				ptxeMeta = ptxeMeta->NextSiblingElement("metadata");
			}
		}

	}
}

/**
	\todo save the parameters
*/
void AEncodeProperties::SaveParams(const HWND hParentWnd)
{
	char string[MAX_PATH];
	int nIdx = SendMessage(::GetDlgItem( hParentWnd ,IDC_COMBO_SETTINGS ), CB_GETCURSEL, NULL, NULL);
	::SendMessage(::GetDlgItem( hParentWnd ,IDC_COMBO_SETTINGS ), CB_GETLBTEXT , nIdx, (LPARAM) string);

#ifdef OLD
	AParameters prms;

	prms.Attach("SOFTWARE\\MUKOLI\\out_lame\\Configs");
	prms.ResetSubKey();

	bool bFound = false;
	char keystring[MAX_PATH];
	AParameters * subkey;
	char keyName[MAX_PATH];
	while (prms.NextSubKey(keystring, MAX_PATH) == AParameters::KEY_FOUND)
	{
		subkey = prms.GetSubKey(keystring);
		unsigned long DSize = MAX_PATH;
		subkey->QueryValue("Name", keyName, DSize);

		if (strcmp(keyName,string) == 0)
		{
/*			AEncodeProperties * the_prop;
			the_prop = (AEncodeProperties *) GetProp(hwndDlg, "AEncodeProperties-Config");

			the_prop->GetValuesFromKey(*subkey);
			the_prop->UpdateDlgFromValue(hwndDlg);
			prms.ReleaseSubKey(subkey);
			break;*/
//			prms.ReleaseSubKey(subkey);
			bFound = true;
			break;
		}

		prms.ReleaseSubKey(subkey);
	}

	assert(bFound);

	// update the "current" string in Registry with keystring
	prms.SetValueString("current",keystring);
		
//	prms.ReleaseSubKey(subkey);

//	prms.Detach();

	// if we are working with the 'current' key, just save it
	// otherwise prompt the user to save the parameters in the current key
	// if they are different from what is saved...
	if (strcmp(keystring,"Current") != 0)
	{
		AEncodeProperties tmpProperties; // used to compare with current values
		tmpProperties.GetValuesFromKey(*subkey);

		assert(should not use the subkey of another class...);

		if (tmpProperties != this)
		{
			TCHAR tmpout[250],output[250];
			::LoadString(AOut::GetInstance(),IDS_STRING_SAVE_PARAMS,tmpout,250);
			wsprintf(output,"%s\"%s\" ?",tmpout,keyName);
			if (AOut::MyMessageBox( output, MB_YESNO|MB_ICONQUESTION|MB_APPLMODAL, hParentWnd) != IDYES)
			{
				// save in the 'current' key
				prms.SetValueString("current","Current");

				subkey = prms.GetSubKey("Current");
			}

			SaveValuesToKey(*subkey);
		}
tmpProperties.output();
this->output();

	}
	else
	{
		SaveValuesToKey(*subkey);
	}
	prms.ReleaseSubKey(subkey);

	prms.Detach();
#endif // OLD
}

// added quality settings
bool AEncodeProperties::operator !=(const AEncodeProperties & the_instance) const
{
/*
	::OutputDebugString(bCopyright != the_instance.bCopyright?"1":"-");
	::OutputDebugString(bCRC != the_instance.bCRC            ?"2":"-");
	::OutputDebugString(bOriginal != the_instance.bOriginal  ?"3":"-");
	::OutputDebugString(bPrivate != the_instance.bPrivate    ?"4":"-");
	::OutputDebugString(bNoBitRes != the_instance.bNoBitRes  ?"5":"-");
	::OutputDebugString(mBRmode != the_instance.mBRmode      ?"6":"-");
	::OutputDebugString(bXingFrame != the_instance.bXingFrame?"7":"-");
	::OutputDebugString(bForceChannel != the_instance.bForceChannel?"8":"-");
	::OutputDebugString(bResample != the_instance.bResample  ?"9":"-");
	::OutputDebugString(nChannelIndex != the_instance.nChannelIndex?"10":"-");
	::OutputDebugString(nMinBitrateIndex != the_instance.nMinBitrateIndex?"11":"-");
	::OutputDebugString(nMaxBitrateIndex != the_instance.nMaxBitrateIndex?"12":"-");
	::OutputDebugString(nPresetIndex != the_instance.nPresetIndex?"13":"-");
	::OutputDebugString(VbrQuality != the_instance.VbrQuality?"14":"-");
	::OutputDebugString(AverageBitrate != the_instance.AverageBitrate?"15":"-");
	::OutputDebugString(nSamplingFreqIndex != the_instance.nSamplingFreqIndex?"16":"-");
	::OutputDebugString(OutputDir.compare(the_instance.OutputDir) != 0?"17":"-");

	std::string tmp = "";
	char tmpI[10];
	_itoa(AverageBitrate,tmpI,10);
	tmp += tmpI;
	tmp += " != ";
	_itoa(the_instance.AverageBitrate,tmpI,10);
	tmp += tmpI;
	::OutputDebugString(tmp.c_str());
*/
	return ((bCopyright != the_instance.bCopyright)
		 || (bCRC != the_instance.bCRC)
		 || (bOriginal != the_instance.bOriginal)
		 || (bPrivate != the_instance.bPrivate)
		 || (bNoBitRes != the_instance.bNoBitRes)
		 || (mBRmode != the_instance.mBRmode)
		 || (bXingFrame != the_instance.bXingFrame)
		 || (bForceChannel != the_instance.bForceChannel)
		 || (bResample != the_instance.bResample)
		 || (bUseQuality != the_instance.bUseQuality)
		 || (nChannelIndex != the_instance.nChannelIndex)
		 || (nMinBitrateIndex != the_instance.nMinBitrateIndex)
		 || (nMaxBitrateIndex != the_instance.nMaxBitrateIndex)
		 || (Quality != the_instance.Quality)
		 || (nPresetIndex != the_instance.nPresetIndex)
		 || (VbrQuality != the_instance.VbrQuality)
		 || (AverageBitrate != the_instance.AverageBitrate)
		 || (nSamplingFreqIndex != the_instance.nSamplingFreqIndex)
		 || (OutputDir.compare(the_instance.OutputDir) != 0)
		);
}

void AEncodeProperties::SelectSavedParams(const std::string the_string)
{
	// get the values from the saved file if possible
	if (my_stored_data.LoadFile(my_store_location))
	{
		TiXmlNode* node;

		node = my_stored_data.FirstChild("out_lame");

		TiXmlElement* CurrentNode = node->FirstChildElement("configs");

		if (CurrentNode != NULL)
		{
			CurrentNode->SetAttribute("default",the_string);
			GetValuesFromKey(the_string, *CurrentNode);
			my_stored_data.SaveFile(my_store_location);
		}
	}
}

void AEncodeProperties::SaveValuesToElement(TiXmlElement * the_element) const
{
	// get all the parameters saved in this Element
	TiXmlElement * tmpElt;

	// Bit Reservoir parameter
	tmpElt = the_element->FirstChildElement("Bit_reservoir");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("Bit_reservoir");
		SetAttributeBool(tmpElt, "use", !bNoBitRes);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		SetAttributeBool(tmpElt, "use", !bNoBitRes);
	}

	// Copyright parameter
	tmpElt = the_element->FirstChildElement("Copyright");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("Copyright");
		SetAttributeBool( tmpElt, "use", bCopyright);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		SetAttributeBool( tmpElt, "use", bCopyright);
	}

	// CRC parameter
	tmpElt = the_element->FirstChildElement("CRC");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("CRC");
		SetAttributeBool( tmpElt, "use", bCRC);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		SetAttributeBool( tmpElt, "use", bCRC);
	}

	// Original parameter
	tmpElt = the_element->FirstChildElement("Original");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("Original");
		SetAttributeBool( tmpElt, "use", bOriginal);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		SetAttributeBool( tmpElt, "use", bOriginal);
	}

	// Private parameter
	tmpElt = the_element->FirstChildElement("Private");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("Private");
		SetAttributeBool( tmpElt, "use", bPrivate);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		SetAttributeBool( tmpElt, "use", bPrivate);
	}

	// Channel Mode parameter
	tmpElt = the_element->FirstChildElement("Channel");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("Channel");
		tmpElt->SetAttribute("mode", GetChannelModeString(nChannelIndex));
		SetAttributeBool( tmpElt, "force", bForceChannel);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		tmpElt->SetAttribute("mode", GetChannelModeString(nChannelIndex));
		SetAttributeBool( tmpElt, "force", bForceChannel);
	}

	// Preset parameter
	tmpElt = the_element->FirstChildElement("Preset");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("Preset");
		tmpElt->SetAttribute("type", GetPresetModeString(nPresetIndex));
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		tmpElt->SetAttribute("type", GetPresetModeString(nPresetIndex));
	}

	// Bitrate parameter
	tmpElt = the_element->FirstChildElement("bitrate");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("bitrate");
		tmpElt->SetAttribute("min", the_Bitrates[nMinBitrateIndex]);
		tmpElt->SetAttribute("max", the_Bitrates[nMaxBitrateIndex]);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		tmpElt->SetAttribute("min", the_Bitrates[nMinBitrateIndex]);
		tmpElt->SetAttribute("max", the_Bitrates[nMaxBitrateIndex]);
	}

	// Quality parameter
	tmpElt = the_element->FirstChildElement("Quality");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("Quality");
		SetAttributeBool( tmpElt, "use", bUseQuality);
		tmpElt->SetAttribute("value", Quality);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		tmpElt->SetAttribute("value", Quality);
		SetAttributeBool( tmpElt, "use", bUseQuality);
	}

	// Output Directory parameter
	tmpElt = the_element->FirstChildElement("output");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("output");
		tmpElt->SetAttribute("path", OutputDir);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		tmpElt->SetAttribute("path", OutputDir);
	}

	// Resampling parameter
	tmpElt = the_element->FirstChildElement("resampling");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("resampling");
		SetAttributeBool( tmpElt, "use", bResample);
		tmpElt->SetAttribute("freq", the_SamplingFreqs[nSamplingFreqIndex]);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		SetAttributeBool( tmpElt, "use", bResample);
		tmpElt->SetAttribute("freq", the_SamplingFreqs[nSamplingFreqIndex]);
	}

	// VBR parameter
	tmpElt = the_element->FirstChildElement("VBR");
	if (tmpElt == NULL)
	{
		tmpElt = new TiXmlElement("VBR");
		
		if (mBRmode == BR_ABR)
			tmpElt->SetAttribute("use", "ABR");
		else
			SetAttributeBool( tmpElt, "use", (mBRmode != BR_CBR));

		SetAttributeBool( tmpElt, "header", bXingFrame);
		tmpElt->SetAttribute("quality", VbrQuality);
		tmpElt->SetAttribute("average", AverageBitrate);
		the_element->InsertEndChild(*tmpElt);
	}
	else
	{
		if (mBRmode == BR_ABR)
			tmpElt->SetAttribute("use", "ABR");
		else
			SetAttributeBool( tmpElt, "use", (mBRmode != BR_CBR));

		SetAttributeBool( tmpElt, "header", bXingFrame);
		tmpElt->SetAttribute("quality", VbrQuality);
		tmpElt->SetAttribute("average", AverageBitrate);
	}

	// ID3 tag - metadata
	if(vMetadata.size() > 0)
	{
		tmpElt = the_element->FirstChildElement("tag");
		// remove old tag
		if (tmpElt)
		{
			the_element->RemoveChild(tmpElt);
			tmpElt = NULL;
		}

		// create new tag
		tmpElt = new TiXmlElement("tag");
		TiXmlElement *ptxeTag = the_element->InsertEndChild(*tmpElt)->ToElement();
		delete tmpElt;
		
		if (ptxeTag != NULL)
		{
			SetAttributeBool(ptxeTag, "autoyear", bTagAutoYear);
			for(int i = 0; i < vMetadata.size(); i++)
			{
				TiXmlElement *ptxeMeta = new TiXmlElement("metadata");
				ptxeMeta->SetAttribute("field", vMetadata[i].strField);
				if(vMetadata[i].strField.compare("title") == 0)
					SetAttributeBool(ptxeMeta, "appenddate", bTagDateTitle);
				ptxeMeta->SetAttribute("value", vMetadata[i].strValue);
				ptxeTag->InsertEndChild(*ptxeMeta);
				delete ptxeMeta;
			}
		}
	}
}

bool AEncodeProperties::HandleDialogCommand(const HWND parentWnd, const WPARAM wParam, const LPARAM lParam)
{
	UINT command;
	command = GET_WM_COMMAND_ID(wParam, lParam);

	switch (command)
	{
	case IDOK :
	{
		bool bShouldEnd = true;

		// save parameters
		char string[MAX_PATH];
		::GetWindowText(::GetDlgItem( parentWnd, IDC_COMBO_SETTINGS), string, MAX_PATH);

		AEncodeProperties tmpDlgProps;
		tmpDlgProps.UpdateValueFromDlg(parentWnd);

		AEncodeProperties tmpSavedProps;
		tmpSavedProps.SelectSavedParams(string);
		tmpSavedProps.ParamsRestore();
		// check if the values from the DLG are the same as the one saved in the config file
		// if yes, just do nothing
		if (tmpDlgProps != tmpSavedProps)
		{
			int save;

			if (strcmp(string,"Current") == 0)
			{
				// otherwise, prompt the user if he wants to overwrite the settings
				TCHAR tmpStr[250];
				::LoadString(AOut::GetInstance(),IDS_STRING_PROMPT_REPLACE_CURRENT,tmpStr,250);

				save = AOut::MyMessageBox( tmpStr, MB_OKCANCEL|MB_ICONQUESTION, parentWnd);
			}
			else
			{
				// otherwise, prompt the user if he wants to overwrite the settings
				TCHAR tmpStr[250];
				::LoadString(AOut::GetInstance(),IDS_STRING_PROMPT_REPLACE_SETING,tmpStr,250);
				TCHAR tmpDsp[500];
				wsprintf(tmpDsp,tmpStr,string);

				save = AOut::MyMessageBox( tmpDsp, MB_YESNOCANCEL|MB_ICONQUESTION, parentWnd);
			}

			if (save == IDCANCEL)
				bShouldEnd = false;
			else if (save == IDNO)
			{
				// save the values in 'current'
				UpdateValueFromDlg(parentWnd);
				SaveValuesToStringKey("Current");
				SelectSavedParams("Current");
			}
			else
			{
				// do so and save in XML
				UpdateValueFromDlg(parentWnd);
				SaveValuesToStringKey(string);
			}
		}
		SaveParams(parentWnd);

		if (bShouldEnd)
		{
			RemoveProp(parentWnd, "AEncodeProperties-Config");
		
			EndDialog(parentWnd, true);
		}
	}
	break;

	case IDCANCEL:
		RemoveProp(parentWnd, "AEncodeProperties-Config");
        EndDialog(parentWnd, false);
		break;

	case IDC_FIND_DLL:
	{
		OPENFILENAME file;
		char DllLocation[512];
		wsprintf(DllLocation,"%s",GetDllLocation());

		memset(&file, 0, sizeof(file));
		file.lStructSize = sizeof(file); 
		file.hwndOwner  = parentWnd;
		file.Flags = OFN_FILEMUSTEXIST | OFN_NODEREFERENCELINKS | OFN_ENABLEHOOK | OFN_EXPLORER ;
///				file.lpstrFile = AOut::the_AOut->DllLocation;
		file.lpstrFile = DllLocation;
		file.lpstrFilter = "Lame DLL (lame_enc.dll)\0LAME_ENC.DLL\0DLL (*.dll)\0*.DLL\0All (*.*)\0*.*\0";
		file.nFilterIndex = 1;
		file.nMaxFile  = sizeof(DllLocation);
		file.lpfnHook  = DLLFindCallback; // use to validate the DLL chosen

		// if no error, save DLL location to XML file now
		if(GetOpenFileName(&file))
		{
			SetDllLocation(DllLocation);
			SaveDLLlocation();
		}
		// use this filename if necessary
	}
	break;

	case IDC_BUTTON_OUTPUT:
	{
#ifndef SIMPLE_FOLDER
		BROWSEINFO info;
		memset(&info,0,sizeof(info));

		char FolderName[MAX_PATH];

		info.hwndOwner = parentWnd;
		info.pszDisplayName  = FolderName;
		info.lpfn = BrowseFolderCallbackroc;
		info.lParam = (LPARAM) this;

		// get the localised window title
		TCHAR output[250];
		::LoadString(AOut::GetInstance(),IDS_STRING_DIR_SELECT,output,250);
		info.lpszTitle = output;

#ifdef BIF_EDITBOX
		info.ulFlags |= BIF_EDITBOX;
#else // BIF_EDITBOX
		info.ulFlags |= 0x0010;
#endif // BIF_EDITBOX

#ifdef BIF_VALIDATE
		info.ulFlags |= BIF_VALIDATE;
#else // BIF_VALIDATE
		info.ulFlags |= 0x0020;
#endif // BIF_VALIDATE

#ifdef BIF_NEWDIALOGSTYLE
		info.ulFlags |= BIF_NEWDIALOGSTYLE;
#else // BIF_NEWDIALOGSTYLE
		info.ulFlags |= 0x0040;
#endif // BIF_NEWDIALOGSTYLE

		ITEMIDLIST *item = SHBrowseForFolder(&info);

    	if (item != NULL)
		{
			char tmpOutputDir[MAX_PATH];
			wsprintf(tmpOutputDir,"%s",GetOutputDirectory());

			SHGetPathFromIDList( item,tmpOutputDir );
			SetOutputDirectory( tmpOutputDir );
			::SetWindowText(GetDlgItem( parentWnd, IDC_EDIT_OUTPUTDIR), tmpOutputDir);
//					wsprintf(OutputDir,FolderName);
		}
#else // SIMPLE_FOLDER
		OPENFILENAME file;

		memset(&file, 0, sizeof(file));
		file.lStructSize = sizeof(file); 
		file.hwndOwner  = parentWnd;
		file.Flags = OFN_FILEMUSTEXIST | OFN_NODEREFERENCELINKS | OFN_ENABLEHOOK | OFN_EXPLORER ;
//				file.lpstrFile = GetDllLocation();
//				file.lpstrFile = GetOutputDirectory();
		file.lpstrInitialDir = GetOutputDirectory();
		file.lpstrFilter = "A Directory\0.*\0";
//				file.nFilterIndex = 1;
		file.nMaxFile  = MAX_PATH;
//				file.lpfnHook  = DLLFindCallback; // use to validate the DLL chosen
//				file.Flags = OFN_ENABLESIZING | OFN_NOREADONLYRETURN | OFN_HIDEREADONLY;
		file.Flags = OFN_NOREADONLYRETURN | OFN_HIDEREADONLY | OFN_EXPLORER;

		TCHAR output[250];
		::LoadString(AOut::GetInstance(),IDS_STRING_DIR_SELECT,output,250);
		file.lpstrTitle = output;

		GetSaveFileName(&file);
#endif // SIMPLE_FOLDER
	}
	break;

	case IDC_RADIO_BITRATE_CBR:
		AEncodeProperties::DisplayVbrOptions(parentWnd, AEncodeProperties::BR_CBR);
		break;

	case IDC_RADIO_BITRATE_VBR:
		AEncodeProperties::DisplayVbrOptions(parentWnd, AEncodeProperties::BR_VBR);
		break;

	case IDC_RADIO_BITRATE_ABR:
		AEncodeProperties::DisplayVbrOptions(parentWnd, AEncodeProperties::BR_ABR);
		break;

	case IDC_CHECK_RESAMPLE:
	{
		bool tmp_bResampleUsed = (::IsDlgButtonChecked( parentWnd, IDC_CHECK_RESAMPLE) == BST_CHECKED);
		if (tmp_bResampleUsed)
		{
			::EnableWindow(::GetDlgItem(parentWnd,IDC_COMBO_SAMPLEFREQ), TRUE);
		}
		else
		{
			::EnableWindow(::GetDlgItem(parentWnd,IDC_COMBO_SAMPLEFREQ), FALSE);
		}
	}
	break;

	// enable/disable quality controls
	case IDC_CHECK_QQUALITY:
	{
		bool tmp_bQuality = (::IsDlgButtonChecked( parentWnd, IDC_CHECK_QQUALITY) == BST_CHECKED);
		::EnableWindow(::GetDlgItem( parentWnd, IDC_SLIDER_QQUALITY), tmp_bQuality);
		::EnableWindow(::GetDlgItem( parentWnd, IDC_CONFIG_QQUALITY), tmp_bQuality);
		::EnableWindow(::GetDlgItem( parentWnd, IDC_STATIC_QQUALITY_LOW), tmp_bQuality);
		::EnableWindow(::GetDlgItem( parentWnd, IDC_STATIC_QQUALITY_HIGH), tmp_bQuality);
	}
	break;

	case IDC_COMBO_SETTINGS:
//				if (CBN_SELCHANGE == GET_WM_COMMAND_CMD(wParam, lParam))
		if (CBN_SELENDOK == GET_WM_COMMAND_CMD(wParam, lParam))
		{
			char string[MAX_PATH];
			int nIdx = SendMessage(HWND(lParam), CB_GETCURSEL, NULL, NULL);
			SendMessage(HWND(lParam), CB_GETLBTEXT , nIdx, (LPARAM) string);

			// get the info corresponding to the new selected item
			SelectSavedParams(string);
			UpdateDlgFromValue(parentWnd);
		}
		break;

	case IDC_BUTTON_CONFIG_SAVE:
	{
		// save the data in the current config
		char string[MAX_PATH];
		::GetWindowText(::GetDlgItem( parentWnd, IDC_COMBO_SETTINGS), string, MAX_PATH);

		UpdateValueFromDlg(parentWnd);
		SaveValuesToStringKey(string);
		SelectSavedParams(string);
		UpdateConfigs(parentWnd);
		UpdateDlgFromValue(parentWnd);
	}
	break;

	case IDC_BUTTON_CONFIG_RENAME:
	{
		char string[MAX_PATH];
		::GetWindowText(::GetDlgItem( parentWnd, IDC_COMBO_SETTINGS), string, MAX_PATH);

		if (RenameCurrentTo(string))
		{
			// Update the names displayed
			UpdateConfigs(parentWnd);
		}

	}
	break;

	case IDC_BUTTON_CONFIG_DELETE:
	{
		char string[MAX_PATH];
		::GetWindowText(::GetDlgItem( parentWnd, IDC_COMBO_SETTINGS), string, MAX_PATH);
		
		if (DeleteConfig(string))
		{
			// Update the names displayed
			UpdateConfigs(parentWnd);
			UpdateDlgFromValue(parentWnd);
		}
	}
	break;
	}
	
    return FALSE;
}

bool AEncodeProperties::RenameCurrentTo(const std::string & new_config_name)
{
	bool bResult = false;

	// display all the names of the saved configs
	// get the values from the saved file if possible
	if (my_stored_data.LoadFile(my_store_location))
	{
		TiXmlNode* node;

		node = my_stored_data.FirstChild("out_lame");

		TiXmlElement* CurrentNode = node->FirstChildElement("configs");

		if (CurrentNode->Attribute("default") != NULL)
		{
			std::string CurrentConfigName = CurrentNode->Attribute("default");

			// no rename possible for Current
			if (CurrentConfigName == "")
			{
				bResult = true;
			}
			else if (CurrentConfigName != "Current")
			{
				// find the config that correspond to CurrentConfig
				TiXmlElement* iterateElmt = CurrentNode->FirstChildElement("config");
//				int Idx = 0;
				while (iterateElmt != NULL)
				{
					const std::string tmpname(iterateElmt->Attribute("name"));
					/**
						\todo support language names
					*/
					if (tmpname.size() > 0)
					{
						if (tmpname.compare(CurrentConfigName) == 0)
						{
							iterateElmt->SetAttribute("name",new_config_name);	
							bResult = true;
							break;
						}
					}
//					Idx++;
					iterateElmt = iterateElmt->NextSiblingElement("config");
				}
			}

			if (bResult)
			{
				CurrentNode->SetAttribute("default",new_config_name);

				my_stored_data.SaveFile(my_store_location);
			}
		}
	}

	return bResult;
}

bool AEncodeProperties::DeleteConfig(const std::string & config_name)
{
	bool bResult = false;

	if (config_name != "Current")
	{
		// display all the names of the saved configs
		// get the values from the saved file if possible
		if (my_stored_data.LoadFile(my_store_location))
		{
			TiXmlNode* node;

			node = my_stored_data.FirstChild("out_lame");

			TiXmlElement* CurrentNode = node->FirstChildElement("configs");

			TiXmlElement* iterateElmt = CurrentNode->FirstChildElement("config");
//			int Idx = 0;
			while (iterateElmt != NULL)
			{
				const std::string tmpname(iterateElmt->Attribute("name"));
				/**
					\todo support language names
				*/
				if (tmpname.size() > 0)
				{
					if (tmpname.compare(config_name) == 0)
					{
						CurrentNode->RemoveChild(iterateElmt);
						bResult = true;
						break;
					}
				}
//				Idx++;
				iterateElmt = iterateElmt->NextSiblingElement("config");
			}
		}

		if (bResult)
		{
			my_stored_data.SaveFile(my_store_location);

			// select a new default config : "Current"
			SelectSavedParams("Current");

		}
	}

	return bResult;
}

void AEncodeProperties::SetCurrentDate()
{
	GetLocalTime(&stTime);
}

void AEncodeProperties::ReadMetadata(HWND hwndWinamp, LPCSTR szFilename)
{
	vReadMetadata.clear();
	bool bWroteData = false;
	char *szMetaData[] = {"album", "artist", "comment", "disk", "genre", "title", "track", "year", NULL};
	char *szField = szMetaData[0];
	int nField = 0;
	cextendedFileInfoStruct efi;
	efi.filename = szFilename;
	while(szField)
	{
		efi.metadata = szField;
		char szBuf[4096];
		efi.ret = szBuf;
		efi.retlen = sizeof(szBuf);
		if(1 == SendMessage(hwndWinamp, WM_WA_IPC, (WPARAM)&efi, IPC_GET_EXTENDED_FILE_INFO))
		{
			MetadataItem mdi;
			mdi.strField = szField;
			mdi.strValue = efi.ret;
			vReadMetadata.push_back(mdi);
		}
		szField = szMetaData[++nField];
	}
}

void AEncodeProperties::SetMetadata(HWND hwndWinamp, LPCSTR szFilename)
{
	// TODO: what should have priority, xml metadata, or source file metadata?
	// would be nice to make the xml act as defaults, but use any value read from
	// source file
	if(vMetadata.size() > 0)
	{
		cextendedFileInfoStruct efi;
		efi.filename = szFilename;
		// add year
		if(bTagAutoYear)
		{
			char szYear[16];
			efi.metadata = "year";
			efi.ret = itoa(stTime.wYear, szYear, 10);
			SendMessage(hwndWinamp, WM_WA_IPC, (WPARAM)&efi, IPC_SET_EXTENDED_FILE_INFO);
		}
		// add other metadata
		for(int i = 0; i < vMetadata.size(); i++)
		{
			char *szDateTitle = NULL;
			efi.metadata = vMetadata[i].strField.c_str();
			efi.ret = vMetadata[i].strValue.c_str();
			if(vMetadata[i].strField.compare("title") == 0 && bTagDateTitle)
			{
				szDateTitle = new char[vMetadata[i].strValue.length() + 16];
				if(szDateTitle)
				{
					sprintf(szDateTitle, "%s %u/%02u/%02u", vMetadata[i].strValue.c_str(), stTime.wYear, stTime.wMonth, stTime.wDay);
					efi.ret = szDateTitle;
				}
			}
			SendMessage(hwndWinamp, WM_WA_IPC, (WPARAM)&efi, IPC_SET_EXTENDED_FILE_INFO);
			delete szDateTitle;
		}
		// commit metadata to file
		SendMessage(hwndWinamp, WM_WA_IPC, 0, IPC_WRITE_EXTENDED_FILE_INFO);
	}
	else if(vReadMetadata.size() > 0)
	{
		cextendedFileInfoStruct efi;
		efi.filename = szFilename;
		for(int i = 0; i < vReadMetadata.size(); i++)
		{
			efi.metadata = vReadMetadata[i].strField.c_str();
			efi.ret = vReadMetadata[i].strValue.c_str();
			SendMessage(hwndWinamp, WM_WA_IPC, (WPARAM)&efi, IPC_SET_EXTENDED_FILE_INFO);
		}
		// commit metadata to file
		SendMessage(hwndWinamp, WM_WA_IPC, 0, IPC_WRITE_EXTENDED_FILE_INFO);
	}
}

void AEncodeProperties::UpdateConfigs(const HWND HwndDlg)
{
	// Add User configs
	SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SETTINGS), CB_RESETCONTENT , NULL, NULL);

	// display all the names of the saved configs
	// get the values from the saved file if possible
	if (my_stored_data.LoadFile(my_store_location))
	{
		TiXmlNode* node;

		node = my_stored_data.FirstChild("out_lame");

		TiXmlElement* CurrentNode = node->FirstChildElement("configs");

		std::string CurrentConfig = "";

		if (CurrentNode->Attribute("default") != NULL)
		{
			CurrentConfig = CurrentNode->Attribute("default");
		}

		TiXmlElement* iterateElmt;

		// find the config that correspond to CurrentConfig
		iterateElmt = CurrentNode->FirstChildElement("config");
		int Idx = 0;
		while (iterateElmt != NULL)
		{
			const std::string tmpname(iterateElmt->Attribute("name"));
			/**
				\todo support language names
			*/
			if (tmpname.size() > 0)
			{
				SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SETTINGS), CB_ADDSTRING, NULL, (LPARAM) tmpname.c_str());
				if (tmpname.compare(CurrentConfig) == 0)
				{
					SendMessage(GetDlgItem( HwndDlg, IDC_COMBO_SETTINGS), CB_SETCURSEL, Idx, NULL);
				}
			}
			Idx++;
			iterateElmt = iterateElmt->NextSiblingElement("config");
		}
	}
}
