//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDS_STRING_BITRATE_SMALL        1
#define IDS_STRING_BITRATE_HIGH         2
#define IDS_STRING_DIR_SELECT           3
#define IDS_STRING_DLL_UNRECOGNIZED     4
#define IDS_STRING_REGISTRY_LOCKED      5
#define IDS_STRING_CONF_CURRENT         6
#define IDS_STRING_BSD_LICENCE_URL      7
#define IDS_STRING_SAVE_PARAMS          8
#define IDS_STRING_PROMPT_REPLACE_SETING 9
#define IDS_STRING_PROMPT_REPLACE_CURRENT 10
#define IDS_STRING_ABOUT_DLL_NOT_FOUND  11
#define IDD_CONFIG                      101
#define IDD_ABOUT                       102
#define IDC_FIND_DLL                    1000
#define IDC_DLL_HOMEPAGE                1001
#define IDC_DLL_VERSION                 1002
#define IDC_DLL_ENGINE                  1003
#define IDC_DLL_MMX                     1005
#define IDC_CHECK_RESAMPLE              1007
#define IDC_COMBO_SAMPLEFREQ            1008
#define IDC_COMBO_BITRATE               1009
#define IDC_COMBO_CHANNELS              1010
#define IDC_COMBO_PRESET                1011
#define IDC_CHECK_COPYRIGHT             1012
#define IDC_CHECK_CRC                   1013
#define IDC_CHECK_ORIGINAL              1014
#define IDC_CHECK_PRIVATE               1015
#define IDC_CHECK_RESERVOIR             1017
#define IDC_COMBO_MAXBITRATE            1018
#define IDC_CHECK_CHANNELFORCE          1019
#define IDC_COMBO_SETTINGS              1020
#define IDC_CHECK_XINGVBR               1021
#define IDC_STATIC_MAXBITRATE           1022
#define IDC_COMBO_VBRQUALITY            1023
#define IDC_CHECK_QQUALITY              1023
#define IDC_STATIC_VBRQUALITY           1024
#define IDC_STATIC_MINBITRATE           1025
#define IDC_BUTTON_OUTPUT               1026
#define IDC_ABOUT_VERSION               1027
#define IDC_ABOUT_BSD                   1028
#define IDC_ABOUT_HOMEPAGE              1029
#define IDC_SLIDER_QUALITY              1030
#define IDC_CONFIG_QUALITY              1031
#define IDC_STATIC_VBRQUALITY_HIGH      1032
#define IDC_STATIC_VBRQUALITY_LOW       1033
#define IDC_BUTTON_CONFIG_SAVE          1034
#define IDC_BUTTON_CONFIG_RENAME        1035
#define IDC_BUTTON_CONFIG_DELETE        1036
#define IDC_EDIT_OUTPUTDIR              1037
#define IDC_SLIDER_QQUALITY             1038
#define IDC_EDIT_ABOUT_DLL_LOCATION     1039
#define IDC_STATIC_QQUALITY_HIGH        1039
#define IDC_RADIO_BITRATE_CBR           1040
#define IDC_RADIO_BITRATE_VBR           1041
#define IDC_RADIO_BITRATE_ABR           1042
#define IDC_STATIC_QQUALITY_LOW         1043
#define IDC_STATIC_ABR                  1044
#define IDC_CONFIG_QQUALITY             1045
#define IDC_EDIT_AVERAGE                1046

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
