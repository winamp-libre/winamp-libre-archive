/*

$Id: AEncodeProperties.h,v 1.14 2005/10/06 02:58:23 prowler7 Exp $ 


$Log: AEncodeProperties.h,v $
Revision 1.14  2005/10/06 02:58:23  prowler7
- Fixed bit reservoir check box to properly report the state
- cleaned up a bit of the XML config code

Revision 1.13  2005/01/08 00:17:55  prowler7
added writing tag info using Get/Set Extended File Info

Revision 1.12  2005/01/06 23:48:43  prowler7
Fixed bug - getoutputtime() now uses 64-bit math to avoid the overflow that would typically happen at ~48sec of encoding stereo 44.1kHz.
Added feature to write custom tag information using Winamp's IPC_WRITE_EXTENDED_FILE_INFO, still need to expose this in the config GUI.

Revision 1.11  2004/12/08 04:10:39  prowler7
Version 1.6.2
- Fixed bug: Xing/Lame frame was never being written
- Fixed bug: Lame DLL location was not being saved
- Added all presets in Lame 3.96
- Option to always write the Xing/Lame frame (since Lame uses an extension of the Xing frame it applies to CBR too)
- Added explicit setting of psycho acoustic Quality (-q)
- About dialog now shows Lame alpha/beta revision and if MMX is supported

Revision 1.10  2001/09/04 18:49:49  robux4
Added r3mix support and very high qulity

Revision 1.9  2001/09/04 18:41:25  robux4
ABR now correctly working

Revision 1.8  2001/08/29 21:41:38  robux4
Added ABR support

Revision 1.7  2001/08/11 15:26:14  robux4
Added possibility to rename and delete configurations

Revision 1.6  2001/08/11 09:34:15  robux4
Added better automatic config saving

Revision 1.5  2001/08/01 19:40:16  robux4
Updated with complete documentation support

Revision 1.4  2001/07/27 16:25:01  robux4
Update to fit tinyXML 1.2.3 (no more modifications)

Revision 1.3  2001/07/26 19:28:49  robux4
Added CVS tags
 

*/

#if !defined(_AENCODEPROPERTIES_H__INCLUDED_)
#define _AENCODEPROPERTIES_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <windows.h>
#include <string>
#include <vector>

#include "BladeMP3EncDLL.h"
#include "tinyxml/tinyxml.h"
//#include "AParameters/AParameters.h"

// ML: presets constant to ensure consistancy
#define THE_PRESETS_COUNT 26

/**
  \struct MetadataItem
  \brief metadata item
*/
struct MetadataItem
{
	std::string strField;
	std::string strValue;
};

/**
  \class AEncodeProperties
  \brief the AEncodeProperties class is responsible for handling all the encoding properties
*/
class AEncodeProperties  
{
public:
	/**
		\brief default constructor
	*/
	AEncodeProperties();

	/**
		\brief default destructor
	*/
	virtual ~AEncodeProperties() {}

	/**
		\enum BRMode
		\brief A bitrate mode (CBR, VBR, ABR)
	*/
	enum BRMode { BR_CBR, BR_VBR, BR_ABR };

	/**
		\brief Handle all the commands that occur in the Config dialog box
	*/
	bool HandleDialogCommand(const HWND parentWnd, const WPARAM wParam, const LPARAM lParam);
	/**
		\brief check wether 2 instances are equal, ie have the same encoding parameters
	*/
	bool operator != (const AEncodeProperties & the_instance) const;

	/**
		\brief Check wether the Encode process should use the Copyright bit
	*/
	inline const bool GetCopyrightMode() const { return bCopyright; }
	/**
		\brief Check wether the Encode process should use the CRC bit
	*/
	inline const bool GetCRCMode() const { return bCRC; }
	/**
		\brief Check wether the Encode process should use the Original bit
	*/
	inline const bool GetOriginalMode() const { return bOriginal; }
	/**
		\brief Check wether the Encode process should use the Private bit
	*/
	inline const bool GetPrivateMode() const { return bPrivate; }

	/**
		\brief Check wether the Encode process shouldn't use the Bit Reservoir
	*/
	inline const bool GetNoBiResMode() const { return bNoBitRes; }

	/**
		\brief Check wether the Encode process should force the channel mode (stereo or mono resampling)
	*/
	inline const bool GetForceChannelMode() const { return bForceChannel; }

	/**
		\brief Check wether the Encode process should use the VBR mode
	*/
	inline const BRMode GetVBRUseMode() const { return mBRmode; }
	/**
		\brief Check wether the Encode process should use the Xing frame in the VBR mode
		\note the Xing frame is a silent frame at the beginning that contain VBR statistics about the file.
	*/
	inline const bool GetXingFrameMode() const { return bXingFrame; }

	/**
		\brief Check wether the Encode process should resample before encoding
	*/
	inline const bool GetResampleMode() const { return bResample; }
	
	/**
		\brief Set wether the Encode process should use the Copyright bit
	*/
	inline void SetCopyrightMode(const bool bMode) { bCopyright = bMode; }
	/**
		\brief Set wether the Encode process should use the CRC bit
	*/
	inline void SetCRCMode(const bool bMode) { bCRC = bMode; }
	/**
		\brief Set wether the Encode process should use the Original bit
	*/
	inline void SetOriginalMode(const bool bMode) { bOriginal = bMode; }
	/**
		\brief Set wether the Encode process should use the Private bit
	*/
	inline void SetPrivateMode(const bool bMode) { bPrivate = bMode; }

	/**
		\brief Set wether the Encode process shouldn't use the Bit Reservoir
	*/
	inline void SetNoBiResMode(const bool bMode) { bNoBitRes = bMode; }
	
	/**
		\brief Set wether the Encode process should force the channel mode (stereo or mono resampling)
	*/
	inline void SetForceChannelMode(const bool bMode) { bForceChannel = bMode; }
	
	/**
		\brief Set wether the Encode process should use the VBR mode
	*/
	inline void SetVBRUseMode(const BRMode mode) { mBRmode = mode; }

	/**
		\brief Set wether the Encode process should use the Xing frame in the VBR mode
		\note the Xing frame is a silent frame at the beginning that contain VBR statistics about the file.
	*/
	inline void SetXingFrameMode(const bool bMode) { bXingFrame = bMode; }

	/**
		\brief Get the quality setting
		\note This Quality setting will over-ride a quality setting in a preset. /
		Quality Setting, HIGH BYTE should be NOT LOW byte, otherwhise quality is set to 5. /
		This is done to be backward compatible. /
		So to set quality to 3, you have to set the nQuality parameter to 0xFC03.
	*/
	const WORD GetQualityValue() const;

	/**
		\brief CBR : Get the bitrate to use         / 
		       VBR : Get the minimum bitrate value
	*/
	const unsigned int GetBitrateValue() const;

	/**
		\brief Get the current (VBR:min) bitrate for the specified MPEG version

		\param bitrate the data that will be filled with the bitrate
		\param MPEG_Version The MPEG version (MPEG1 or MPEG2)

		\return 0 if the bitrate is not found, 1 if the bitrate is found
	*/
	const int GetBitrateValue(DWORD & bitrate, const DWORD MPEG_Version) const;
	/**
		\brief Get the current (VBR:min) bitrate for MPEG I

		\param bitrate the data that will be filled with the bitrate

		\return 0 if the bitrate is not found, 1 if the bitrate is found
	*/
	const int GetBitrateValueMPEG1(DWORD & bitrate) const;
	/**
		\brief Get the current (VBR:min) bitrate for MPEG II

		\param bitrate the data that will be filled with the bitrate

		\return 0 if the bitrate is not found, 1 if the bitrate is found
	*/
	const int GetBitrateValueMPEG2(DWORD & bitrate) const;

	/**
		\brief Get the current (VBR:min) bitrate in the form of a string

		\param string the string that will be filled
		\param string_size the size of the string

		\return -1 if the bitrate is not found, and the number of char copied otherwise
	*/
	inline const int GetBitrateString(char * string, int string_size) const {return GetBitrateString(string,string_size,nMinBitrateIndex); }

	/**
		\brief Get the (VBR:min) bitrate corresponding to the specified index in the form of a string

		\param string the string that will be filled
		\param string_size the size of the string
		\param a_bitrateID the index in the Bitrate table

		\return -1 if the bitrate is not found, and the number of char copied otherwise
	*/
	const int GetBitrateString(char * string, int string_size, int a_bitrateID) const;

	/**
		\brief Get the number of possible bitrates
	*/
	inline const int GetBitrateLentgh() const { return sizeof(the_Bitrates) / sizeof(unsigned int); }
	/**
		\brief Get the number of possible sampling frequencies
	*/
	inline const unsigned int GetResampleFreq() const { return the_SamplingFreqs[nSamplingFreqIndex]; }

	/**
		\brief Get the VBR attributes for a specified MPEG version

		\param MaxBitrate receive the maximum bitrate possible in the VBR mode
		\param Quality receive the quality value (0 to 9 see Lame doc for more info)
		\param VBRHeader receive the value that indicates wether the VBR/Xing header should be filled
		\param MPEG_Version The MPEG version (MPEG1 or MPEG2)

		\return the VBR mode (Old, New, ABR, MTRH, Default or None)
	*/
	VBRMETHOD GetVBRValue(DWORD & MaxBitrate, int & Quality, DWORD & AbrBitrate, BOOL & VBRHeader, const DWORD MPEG_Version) const;

	/**
		\brief Get the Lame DLL Location
	*/
	const char * GetDllLocation() const { return DllLocation.c_str(); }
	/**
		\brief Set the Lame DLL Location
	*/
	void SetDllLocation( const char * the_string ) { DllLocation = the_string; }

	/**
		\brief Get the output directory for encoding
	*/
	const char * GetOutputDirectory() const { return OutputDir.c_str(); }
	/**
		\brief Set the output directory for encoding
	*/
	void SetOutputDirectory( const char * the_string ) { OutputDir = the_string; }

	/**
		\brief Get the current channel mode to use
	*/
	const unsigned int GetChannelModeValue() const;
	/**
		\brief Get the current channel mode in the form of a string
	*/
	inline const char * GetChannelModeString() const {return GetChannelModeString(nChannelIndex); }
	/**
		\brief Get the channel mode in the form of a string for the specified Channel mode index

		\param a_channelID the Channel mode index (see GetChannelLentgh())
	*/
	const char * GetChannelModeString(const int a_channelID) const;
	/**
		\brief Get the number of possible channel mode
	*/
	inline const int GetChannelLentgh() const { return sizeof(the_ChannelModes) / sizeof(unsigned int); }

	/**
		\brief Get the current preset to use, see lame documentation/code for more info on the possible presets
	*/
	const LAME_QUALITY_PRESET GetPresetModeValue() const;
	/**
		\brief Get the preset in the form of a string for the specified Channel mode index

		\param a_presetID the preset index (see GetPresetLentgh())
	*/
	const char * GetPresetModeString(const int a_presetID) const;
	/**
		\brief Get the number of possible presets
	*/
	inline const int GetPresetLentgh() const { return sizeof(the_Presets) / sizeof(LAME_QUALITY_PRESET); }

	/**
		\brief Start the user configuration process (called by AOut::config())
	*/
	bool Config(const HINSTANCE hInstance, const HWND HwndParent);

	/**
		\brief Init the config dialog box with the right texts and choices
	*/
	bool InitConfigDlg(HWND hDialog);

	/**
		\brief Update the instance parameters from the config dialog box
	*/
	bool UpdateValueFromDlg(HWND hDialog);
	/**
		\brief Update the config dialog box from the instance parameters
	*/
	bool UpdateDlgFromValue(HWND hDialog);

	/**
		\brief Update the config dialog box with the BitRate mode
	*/
	static void DisplayVbrOptions(const HWND hDialog, const BRMode the_mode);

	/**
		\brief Handle the saving of parameters when something has changed in the config dialog box
	*/
	void SaveParams(const HWND hDialog);

	/**
		\brief Save the current parameters (current config in use)
	*/
	void ParamsSave(void);
	/**
		\brief Load the parameters (current config in use)
	*/
	void ParamsRestore(void);

	/**
		\brief Select the specified config name as the new default one
	*/
	void SelectSavedParams(const std::string config_name);
	/**
		\brief Save the current parameters to the specified config name
	*/
	void SaveValuesToStringKey(const std::string & config_name);
	/**
		\brief Save the DLL location to the XML
	*/
	void SaveDLLlocation();
	/**
		\brief Rename the current config name to something else
	*/
	bool RenameCurrentTo(const std::string & new_config_name);
	/**
		\brief Delete the config name from the saved configs
	*/
	bool DeleteConfig(const std::string & config_name);

	/**
		\brief Set current date to be written to tag
	*/
	void SetCurrentDate();

	/**
		\brief Read metadata from source file
	*/
	void ReadMetadata(HWND hwndWinamp, LPCSTR szFilename);
	/**
		\brief Write metadata to file
	*/
	void SetMetadata(HWND hwndWinamp, LPCSTR szFilename);

private:

	bool bCopyright;
	bool bCRC;
	bool bOriginal;
	bool bPrivate;
	bool bNoBitRes;
	BRMode mBRmode;
	bool bXingFrame;
	bool bForceChannel;
	bool bResample;
	bool bUseQuality; // ML: use quality flag

	int VbrQuality;
	int Quality;	// ML: quality setting
	int AverageBitrate;
	bool bTagAutoYear;
	bool bTagDateTitle;
	SYSTEMTIME stTime;	// auto date
	std::vector<MetadataItem> vMetadata;
	std::vector<MetadataItem> vReadMetadata;

	static const unsigned int the_ChannelModes[4];
	int nChannelIndex;

	static const unsigned int the_Bitrates[18];
	static const unsigned int the_MPEG1_Bitrates[14];
	static const unsigned int the_MPEG2_Bitrates[14];
	int nMinBitrateIndex; // CBR and VBR
	int nMaxBitrateIndex; // only used in VBR mode

	static const unsigned int the_SamplingFreqs[9];
	int nSamplingFreqIndex;

	static const LAME_QUALITY_PRESET the_Presets[THE_PRESETS_COUNT];
	int nPresetIndex;

//	char DllLocation[512];
	std::string DllLocation;
//	char OutputDir[MAX_PATH];
	std::string OutputDir;

//	AParameters my_base_parameters;
	TiXmlDocument my_stored_data;
	std::string my_store_location;
	std::string my_current_config;

	HINSTANCE hDllInstance;

	void SaveValuesToElement(TiXmlElement * the_element) const;
	void UpdateConfigs(const HWND HwndDlg);

	/**
		\brief

		\param config_name
		\param parentNode
	*/
	void GetValuesFromKey(const std::string & config_name, const TiXmlNode & parentNode);
};

#endif // !defined(_AENCODEPROPERTIES_H__INCLUDED_)
