/*

	$Id: ALameDLL.cpp,v 1.4 2001/07/31 18:49:39 robux4 Exp $ 


	$Log: ALameDLL.cpp,v $
	Revision 1.4  2001/07/31 18:49:39  robux4
	Initial Doxygen doc support
	
	Revision 1.4  2001/07/27 16:42:39  robux4
	Updated CVS tags

	Revision 1.3  2001/07/26 19:28:49  robux4
	Added CVS tags

*/

#include "ALameDLL.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
ALameDLL::ALameDLL():
	LameDLL(NULL),
	beInitStream(NULL),
	beCloseStream(NULL),
	beEncodeChunk(NULL),
	beDeinitStream(NULL),
	beWriteVBRHeader(NULL),
	beVersion(NULL)
{
}

ALameDLL::~ALameDLL()
{
	if (LameDLL != NULL)
		FreeLibrary(LameDLL);
}

bool ALameDLL::Load(const char * DllLocation)
{
	bool result = false;

	if (LameDLL == NULL)
	{
		LameDLL = LoadLibrary(DllLocation);
	}

	if (LameDLL != NULL)
	{
		beInitStream	 = (BEINITSTREAM)     GetProcAddress(LameDLL, TEXT_BEINITSTREAM);
		beCloseStream	 = (BECLOSESTREAM)    GetProcAddress(LameDLL, TEXT_BECLOSESTREAM);
		beEncodeChunk	 = (BEENCODECHUNK)    GetProcAddress(LameDLL, TEXT_BEENCODECHUNK);
		beDeinitStream	 = (BEDEINITSTREAM)   GetProcAddress(LameDLL, TEXT_BEDEINITSTREAM);
		beWriteVBRHeader = (BEWRITEVBRHEADER) GetProcAddress(LameDLL, TEXT_BEWRITEVBRHEADER);
		beVersion        = (BEVERSION)        GetProcAddress(LameDLL, TEXT_BEVERSION);

		result = IsLoaded();
	}
	else
	{
		beInitStream     = NULL;
		beCloseStream    = NULL;
		beEncodeChunk    = NULL;
		beDeinitStream   = NULL;
		beWriteVBRHeader = NULL;
		beVersion        = NULL;
	}

	return result;
}

void ALameDLL::Free()
{
	if (LameDLL != NULL)
	{
		FreeLibrary(LameDLL);
	}

	LameDLL = NULL;
	
	// just in case (without any bug, it shouldn't be necessary)
	beInitStream     = NULL;
	beCloseStream    = NULL;
	beEncodeChunk    = NULL;
	beDeinitStream   = NULL;
	beWriteVBRHeader = NULL;
	beVersion        = NULL;
}

