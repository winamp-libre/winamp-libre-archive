/*

	$Id: AOut.h,v 1.10 2005/01/06 23:48:43 prowler7 Exp $ 


	$Log: AOut.h,v $
	Revision 1.10  2005/01/06 23:48:43  prowler7
	Fixed bug - getoutputtime() now uses 64-bit math to avoid the overflow that would typically happen at ~48sec of encoding stereo 44.1kHz.
	Added feature to write custom tag information using Winamp's IPC_WRITE_EXTENDED_FILE_INFO, still need to expose this in the config GUI.
	
	Revision 1.9  2001/08/21 18:40:38  robux4
	Added for safe ID3v2 keeping and no overwrite
	
	Revision 1.8  2001/08/16 20:00:33  robux4
	Added the encoding DLL location in the abuot box
	
	Revision 1.7  2001/08/15 17:21:50  robux4
	Added force channel support
	
	Revision 1.6  2001/08/01 19:40:16  robux4
	Updated with complete documentation support
	
	Revision 1.5  2001/07/31 18:50:53  robux4
	Moved the version handling in the ALameDLL class

	Revision 1.4  2001/07/27 16:38:49  robux4
	Unified the MessageBox handling

	Revision 1.3  2001/07/26 19:28:49  robux4
	Added CVS tags

*/

#if !defined(_AOUT_H__INCLUDED_)
#define _AOUT_H__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <windows.h>
#include <string>

// used classes/types
#include "Out.h"

// used internal classes/types
#include "ADbg/ADbg.h"
#include "AEncodeProperties.h"
#include "ALameDLL.h"

/** \class AOut AOut.h
    \brief AOut is the main class of the Output plugin. It handles all the actions trigered by Winamp.
*/
class AOut  
{
public:
	/**
		\brief The default constructor
	*/
	AOut();

	/**
		\brief The default constructor
	*/
	virtual ~AOut();

	// used as function pointers by the plugin
	/**
		\brief The plugin config handler

		\param hwndParent the parent Window of the dialog box
	*/
	static void config(HWND hwndParent);
	/**
		\brief The plugin about handler

		\param hwndParent the parent Window of the dialog box
	*/
	static void about(HWND hwndParent);
	/**
		\brief The plugin init handler
	*/
	static void init();
	/**
		\brief The plugin quit handler
	*/
	static void quit();
	/**
		\brief The plugin open handler
	*/
	static int  open(int samplerate, int numchannels, int bitspersamp, int bufferlenms, int prebufferms);
	/**
		\brief The plugin close handler
	*/
	static void close();
	/**
		\brief The plugin write handler
	*/
	static int  write(char *buf, int len);
	/**
		\brief The plugin canwrite handler
	*/
	static int  canwrite();
	/**
		\brief The plugin isplaying handler
	*/
	static int  isplaying();
	/**
		\brief The plugin pause handler
	*/
	static int  pause(int pause);
	/**
		\brief The plugin setvolume handler
	*/
	static void setvolume(int volume);
	/**
		\brief The plugin setpan handler
	*/
	static void setpan(int pan);
	/**
		\brief The plugin flush handler
	*/
	static void flush(int t);
	/**
		\brief The plugin getoutputtime handler
	*/
	static int  getoutputtime();
	/**
		\brief The plugin getwrittentime handler
	*/
	static int  getwrittentime();

	/**
		\brief The plugin structure retrieval, called by Winamp after loading the DLL (see winampGetOutModule())
	*/
	static Out_Module * GetOutModule();

	/**
		\brief The (thread?) instance which the DLL is run in
		\return the (thread ?) instance used by the plugin
	*/
	static inline HINSTANCE GetInstance() { return the_Module.hDllInstance; }

	/**
		\brief The global function used to retrieve the version of this plugin (ie x.y.z)
	*/
	static inline const char * GetVersion() {return the_version_name;}

	/**
		\brief The global function used to retrieve the information about the Lame DLL in use
	*/
	static bool GetLameVersion(BE_VERSION * ver);

	/**
		\brief The global entry point to output messages to the user
	*/
	static int MyMessageBox(const char * the_output, const UINT the_type, const HWND the_parent = NULL);

	/**
		\brief Return a non modifiable version of the Lame DLL object
	*/
	static const ALameDLL & LameDLL() { return the_LameDLL; }

private:
	/**
		\brief The encoding properties instance
	*/
	static AEncodeProperties my_Properties;
	static bool bCopiedTag;

	static int my_EncodingChannels;

	static ADbg         the_Debug;
	static HANDLE       the_OutputFile;
	static DWORD        the_MaxBuffer;
	static DWORD        the_Channels;
	static DWORD        the_SamplesPerSec;
	static unsigned int the_WorkingBufferUseSize;
//	static char*        the_WorkingBuffer;
	static char         the_WorkingBuffer[];
	static DWORD        the_SamplesPerBlock;
	static DWORD        the_SamplesUsed;
	static Out_Module   the_Module;
	static ALameDLL     the_LameDLL;
	static std::string  my_Filename;

	/**
		\brief The version name (ie x.y.z)
	*/
	static char the_version_name[10];
	static char the_complete_name[31];

	/**
		\brief replace all the instace of the char src by dst in the string
	*/
	static void replaceAllChar(std::string & the_string, const char src, const char dst);

	/**
		\brief Transform a mono buffer into a stereo buffer
	
		\param dwNumSamples the number of samples in the output buffer
	*/
	static void UpMixToStereo(SHORT* psData,SHORT* psOutData,DWORD dwNumSamples);

	/**
		\brief Transform a stereo buffer into a mono buffer
	
		\param dwNumSamples the number of samples in the output buffer
	*/
	static void MixToMono(SHORT* psData,SHORT* psOutData,DWORD dwNumSamples);

	/**
		\brief The only instance of the class
		\note not a problem for a DLL
	*/
	static AOut * the_AOut;

};

#endif // !defined(_AOUT_H__INCLUDED_)
