#ifndef _DEBUG
// release optimizations
// /Og (global optimizations), /Os (favor small code), /Oy (no frame pointers)
//#pragma optimize("gsy",on)
#pragma comment(linker,"/RELEASE")
// set the 512-byte alignment (only in VC6+)
#if _MSC_VER >= 1200
#pragma comment(linker,"/opt:nowin98")
#endif
#endif

#define STRICT
#include <windows.h>
#include "out.h"

extern Out_Module mod;

#define OUT_WAVE_VER "v2.0.2a"

#define NAME "waveOut output "OUT_WAVE_VER

#define WM_WA_MPEG_EOF (WM_USER+2)
