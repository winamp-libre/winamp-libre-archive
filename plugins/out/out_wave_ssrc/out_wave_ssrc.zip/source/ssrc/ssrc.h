class Buffer
{
private:
	char * buffer;
	unsigned int buf_size,buf_data;
public:
	_inline Buffer() {buf_size=0;buf_data=0;buffer=0;}
	_inline ~Buffer() {if (buffer) free(buffer);}
	_inline void * GetBuffer(unsigned int * siz) {*siz=buf_data;return buffer;}
	_inline unsigned int Size() {return buf_data;}
	void Read(unsigned int size);
	void Write(void * ptr,unsigned int size);
};

#ifndef HIGHPREC
typedef float REAL;
#else
typedef double REAL;
#endif

class Shaper;

class Resampler_base
{
public:
	class CONFIG
	{
	public:
		int sfrq,dfrq,bps,dbps,nch,dither,pdf,fast,use_float;
		_inline CONFIG(int _sfrq,int _dfrq,int _bps,int _dbps,int _nch,int _dither,int _pdf,int _fast=1,int _use_float=0)
		{
			sfrq=_sfrq;
			dfrq=_dfrq;
			bps=_bps;
			dbps=_dbps;
			nch=_nch;
			dither=_dither;
			pdf=_pdf;
			fast=_fast;
			use_float=_use_float;
		}	
	};

private:
	Buffer in,out;
	void bufloop(int finish);
protected:
	
	Resampler_base(CONFIG & c);

	void _inline __output(void * ptr,int size)
	{
		out.Write(ptr,size);
	};
	virtual unsigned int Resample(unsigned char * input,unsigned int size,int ending)=0;
	double peak;
	int nch,sfrq,dfrq,bps,dbps;
	Shaper * shaper;
	double gain;
	int use_float;
	

	double AA,DF;
	int FFTFIRLEN;

	void make_outbuf(int nsmplwrt2,REAL * outbuf);
	void make_inbuf(int nsmplread,int inbuflen,unsigned char * rawinbuf,REAL * inbuf,int toberead);

public:
	double GetPeak() {return peak;}//havent tested if this actually still works
	
	void Write(void * input,unsigned int size);
	_inline void Finish() {bufloop(1);}
	
	_inline void * GetBuffer(unsigned int * s) {return out.GetBuffer(s);}
	_inline void Read(unsigned int s) {out.Read(s);}

	unsigned int GetLatency();//returns amount of audio data in in/out buffers in milliseconds

	_inline unsigned int GetDataInInbuf() {return in.Size();}

	virtual ~Resampler_base() {}

	static Resampler_base * Create(CONFIG & c);
};

#define SSRC_create(sfrq,dfrq,bps,dbps,nch,dither,pdf,fast,use_float) \
	Resampler_base::Create(Resampler_base::CONFIG(sfrq,dfrq,bps,dbps,nch,dither,pdf,fast,use_float))

/*
USAGE:
Resampler_base::Create() / SSRC_create with your resampling params (see source for exact info what they do)

 loop:
Write() your PCM data to be resampled
GetBuffer() to get pointer to buffer with resampled data and amount of resampled data available (in bytes)
(note: SSRC operates on blocks, don't expect it to return any data right after your first Write() )

Read() to tell the resampler how much data you took from the buffer ( <= size returned by GetBuffer )

you can use GetLatency() to get amount of audio data (in ms) currently being kept in resampler's buffers
(quick hack for determining current output time without extra stupid counters)

Finish() to force-convert remaining PCM data after last Write() (warning: never Write() again after Flush() )

delete when done

*/
