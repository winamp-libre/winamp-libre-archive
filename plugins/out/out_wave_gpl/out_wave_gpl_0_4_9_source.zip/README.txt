GPL waveOut Plug-in
===================

Contents
--------

 - About/Author
 - Obtaining the Source Code
 - Installation/Uninstallation
 - Configuration Editor

About/Author
------------

This plug-in is a replacement for the Winamp waveOut plug-in. It supports
some features that the default plug-in does not have (and lacks some :).
This plug-in may also be connected to applications other than Winamp if
you so desire.

The GPL waveOut Plug-in was written by

    David Overton <david@insomniavisions.com>

If you have any comments or suggestions about the plug-in please feel
free to send me an email.


Obtaining the Source Code
-------------------------

This plug-in is distributed under the GPL. This means that you are free to
download and modify the source code. A copy of the licence is available
in the source code package, which is available from:

	http://www.insomniavisions.com/software

Installation/Uninstallation
---------------------------

Installing the plug-in is a case of copying the file (out_wave_gpl.dll) to
your *:\Program Files\Winamp\Plugins directory (where * is the letter of
the drive you have installed Winamp into, usually C).

To uninstall the plug-in, simply delete out_wave_gpl.dll from the directory
it is installed to (ensure Winamp is not running when you do this).

Configuration Editor 
--------------------

This section lists the controls in the configuration editor and describes
what each one does and how adjusting it will affect playback.

Output Device:

 This combo box lists the sound devices you have on your system. Use it
 to select which sound device you want the plug-in to use. Note that there
 will be two devices even if you only have one sound card. This "extra" 
 device is called "Wave Mapper" or "Microsoft Sound Mapper" and points to 
 the default sound device (ie the one Windows plays beeps through etc.).


Volume Control:

 Enable          - If enabled you can adjust the output volume using
                   Winamp's volume control. If disabled the system
                   waveOut volume is used instead. This is enabled by
                   default.

 Reverse Balance - If enabled the Winamp balance control biases output
                   in the opposite direction to which you move the 
                   balance slider. Enable this if you have your speakers
                   connected the wrong way round or if you want some fun.
                   This is disabled by default (most people connect their
                   speakers up correctly).


Buffering:

 Block Size      - Wave (PCM) data is written to the sound device in blocks
                   rather than as individual bytes. This setting controls the
                   size of the blocks (in kilobytes). The default setting is 
                   9 kilobytes. If you experience regular gaps during playback 
		   try increasing this value.

 Block Count     - This is the number of blocks to allocate for buffering. The
                   higher this number the less likely playback is to skip when
                   you are doing other things. The default number of blocks is
                   20. If you experience gaps in the output while doing other
                   things (such as compiling programs or whatever you do) try
                   increasing this number.


PCM Conversion:

 Enable this if you want the plug-in to support more PCM formats than your sound
 card drivers to. This will enable support for more than 2 channels and sample size
 conversion (if your card doesn't already support it). Enabling this is considered
 a good thing.

 Disable it if you want to see exactly what your sound card is capable of or if you
 have a really good sound card and don't need the conversion (although it won't 
 incur any additional overhead if it's enabled).


Statistics:

 Total Buffer Size  - This displays the sum of the block count and size as chosen
                      under the buffering section.

 Total Buffer Usage - This is how much of the buffer is actually is queued to the 
                      sound device. This should be 90% or more during normal playback.
                      If the buffer empties you will experience gaps in the output.
                      If the usage seems low you might want to try changing the block
                      size/count.

 Used Blocks        - This is similar to the above but displays the usage as a number
                      of blocks that are queued as opposed to the number of bytes.

 Bytes Written      - This displays the number of bytes written to the wave device
                      (after downmixing) since playback began or a seek occurred.

 Bytes Played       - This displays the number of bytes that have been played by the
                      wave device.

 Start Position     - This indicates the position in milliseconds where playback began
                      from. Normally this will be 0 but if you have seeked this will
                      be the time you seeked to.
 
 Latency            - This displays the time (in milliseconds) between Winamp writing
                      to the plug-in and you actually hearing anything. This value is
                      used for synchronising the visualisation (although Winamp 
                      calculates it separately). Generally speaking, the lower this number
                      the more quickly DSP plug-ins will appear to take effect, however
                      if it is too low you may experience gappy output.

 Format             - This displays the sampling rate, sample size and number of channels
                      that the input plug-in opened the device with.

 PCM Conversion     - This will read "Active" or "Inactive" or "(Inactive)" depending on whether
                      PCM is being converted before played, not being converted, or the plug-in
                      is not in use respectively.


OK, Cancel, Defaults Buttons:

 OK       - Clicking this will save settings. If you are currently playing a song the 
            settings will not take effect until playback is restarted.

 Cancel   - Clicking this will discard any changes made to the configuration.

 Defaults - Clicking this will prompt you to reset the settings to their
            original values.

                      
 

