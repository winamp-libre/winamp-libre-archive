#ifndef MMREG_MINGW_H
#define MMREG_MINGW_H
	
#ifdef __MINGW32__	


/*
 * The code below is needed cause MinGW does
 * not come with <mmreg.h> yet.
 */
#define WAVE_FORMAT_EXTENSIBLE 0xFFFE

typedef struct
{
	WAVEFORMATEX Format;
	union
	{
		WORD wValidBitsPerSample;
		WORD wSamplesPerBlock;
		WORD wReserved;
	}
	Samples;
	DWORD dwChannelMask;
	GUID SubFormat;
} WAVEFORMATEXTENSIBLE;


#endif // __MINGW32__

#endif // MMREG_MINGW_H
