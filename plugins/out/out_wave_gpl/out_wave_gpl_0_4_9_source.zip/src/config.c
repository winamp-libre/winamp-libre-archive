/*
 * GPL waveOut Plug-in for Winamp 2.xx
 * -----------------------------------
 * Copyright (C)2002, 2006 David Overton <daveo@rmbx.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include <windows.h>
#include <commctrl.h>
#include <assert.h>
#include "config.h"
#include "plugin.h"
#include "resource.h"

static INT_PTR CALLBACK config_dialog_proc(
	HWND dialog, 
	UINT msg, 
	WPARAM wparam, 
	LPARAM lparam
);

/*
 * Dialog temporary configuration. This is used while the configuration
 * dialog box is active. It can be optionally transferred back to the 
 * master configuration once the box has been dismissed.
 */
static config_t config_current;

/*
 * This value is used to control timer speed. When playback is not active
 * we slow the timer right down to minimise flickering.
 */
static int config_timer_slow;

/*
 * Conversion tables for sliders/values
 */ 
static unsigned int size_table[] = { 
	64512, 48384, 29952, 
	18432, 11520, 9216, 
	6912,  4608,  2304, 
	1152
};

static unsigned int count_table[] = { 
	50, 40, 35, 30, 25, 
	20, 15, 10, 5,  2 
};

/*
 * index_to_block_size - Convert slider value to a block size.
 */
static unsigned int index_to_block_size(unsigned int value) 
{
	if(value < 0)
		value = 0;
	if(value >= TABLE_SIZE(size_table))
		value = TABLE_SIZE(size_table) - 1;

	return size_table[value];
}

/*
 * index_to_block_count - Convert slider value to block count.
 */
static unsigned int index_to_block_count(unsigned int value)
{
	if(value < 0)
		value = count_table[0];
	if(value >= TABLE_SIZE(count_table))
		value = TABLE_SIZE(count_table) - 1;

	return count_table[value];
}

/* 
 * block_count_to_index - Convert block count to slider value.
 */
static unsigned int block_count_to_index(unsigned int value) 
{
	int i;

	for(i = 0; i < TABLE_SIZE(count_table); i++) {
		if(value == count_table[i])
			return i;
	}

	return DEFAULT_BLOCK_COUNT_INDEX;
}

/*
 * block_size_to_index - Convert block size to slider value.
 */
static unsigned int block_size_to_index(unsigned int value)
{
	unsigned int u;

	for(u = 0; u < TABLE_SIZE(count_table); u++) {
		if(value >= size_table[u])
			return u;
	}

	return DEFAULT_BLOCK_SIZE_INDEX;
} 

/*
 * config_dialog - Display the configuration dialog. The dialog box resource
 * must exist within 'instance'. Returns zero if the user clicked OK on the
 * dialog, and non-zero otherwise. Updates 'config' with the new values.
 */
int config_dialog(config_t *config, HINSTANCE instance, HWND parent)
{
	return DialogBoxParam(
		instance, 
		MAKEINTRESOURCE(IDD_CONFIGDLG),
		parent, 
		config_dialog_proc, 
		(LPARAM)config
	) != IDOK;
}

/*
 * config_dialog_proc - Callback procedure for the configuration dialog box.
 * FIXME: This whole function needs splitting into many smaller functions to
 * remove the crazy indenting and line wrapping currently present.
 */ 
static INT_PTR CALLBACK config_dialog_proc(
	HWND dialog, 
	UINT msg, 
	WPARAM wparam, 
	LPARAM lparam
)
{
	stats_t stats;
	config_t *config;
	unsigned int devs;
	unsigned int u;
	char buf[64];

	switch(msg) {
	case WM_INITDIALOG:
		config = (config_t*)lparam;
		config_current = *config;

		SetWindowLongPtr(dialog, DWLP_USER, (LONG_PTR)config);

		SendDlgItemMessage(dialog, IDC_COMBO_DEVICE, CB_ADDSTRING, 0, 
				   (LPARAM)DEFAULT_WAVE_DEVICE);

		devs = waveOutGetNumDevs();
		for(u = 0; u < devs; u++) {
			WAVEOUTCAPS woc;
			waveOutGetDevCaps(u, &woc, sizeof(WAVEOUTCAPS));
			SendDlgItemMessage(dialog, IDC_COMBO_DEVICE, 
					   CB_ADDSTRING, 0, 
					   (LPARAM)woc.szPname);
		}
		
		config_timer_slow = 0;
		SetTimer(dialog, CONFIG_TIMER_ID, 100, NULL);
		SendMessage(dialog, WM_UPDATE_DISPLAY, 0, 0);
		break;
	case WM_VSCROLL:
		if(LOWORD(wparam) < TB_THUMBTRACK || 
		   LOWORD(wparam) > TB_ENDTRACK)
			break;

		config_current.block_size = index_to_block_size(
			(unsigned int)SendDlgItemMessage(dialog, IDC_SLIDER_SIZE, 
					   TBM_GETPOS, 0, 0));
		config_current.block_count = index_to_block_count(
			(unsigned int)SendDlgItemMessage(dialog, IDC_SLIDER_COUNT,
					   TBM_GETPOS, 0, 0));

		if(lparam == (LPARAM)GetDlgItem(dialog, IDC_SLIDER_SIZE)) {
			wsprintf(buf, "%d kB", config_current.block_size / 1024);
			SendDlgItemMessage(dialog, IDC_LABEL_SIZE, WM_SETTEXT, 
					   0, (LPARAM)buf);
		} else {
			wsprintf(buf, "%d", config_current.block_count);
			SendDlgItemMessage(dialog, IDC_LABEL_COUNT, WM_SETTEXT,
					   0, (LPARAM)buf);
		}
		break;
	case WM_TIMER:
		/* FIXME: remove backreferences into plugin.c */
		ivwave_get_statistics(&stats);
		
		if(!stats.active)
			wsprintf(buf, "%u kB", stats.total_buffer_size / 1024);
		else {
			wsprintf(buf, "%d kB (%d ms)", 
				 stats.total_buffer_size / 1024,
				 MulDiv(stats.total_buffer_size, 1000, 
					stats.format.nch * stats.format.bps / 
					8 * stats.format.srate));
		}

		SendDlgItemMessage(dialog, IDC_LABEL_TOTAL, WM_SETTEXT, 
				   0, (LPARAM)buf);

		if(!stats.active)
			wsprintf(buf, "%u/%u", stats.block_usage, stats.block_count);
		else
			wsprintf(buf, "%u/%u (%u)", stats.block_usage, 
				 stats.block_count, stats.block_current);

		SendDlgItemMessage(dialog, IDC_LABEL_BLOCKS, WM_SETTEXT, 0, 
				   (LPARAM)buf);
		
		if(stats.active) {
			/* FIXME: Mess */
			wsprintf(buf, "%d", stats.bytes_written);
			SendDlgItemMessage(dialog, IDC_LABEL_WRITTEN, 
					   WM_SETTEXT, 0, (LPARAM)buf);
			wsprintf(buf, "%d", stats.bytes_played);
			SendDlgItemMessage(dialog, IDC_LABEL_PLAYED, 
					   WM_SETTEXT, 0, (LPARAM)buf);
			wsprintf(buf, "%d ms", stats.start_position);
			SendDlgItemMessage(dialog, IDC_LABEL_START, 
					   WM_SETTEXT, 0, (LPARAM)buf);
			wsprintf(buf, "%d ms", stats.latency);
			SendDlgItemMessage(dialog, IDC_LABEL_LATENCY, 
					   WM_SETTEXT, 0, (LPARAM)buf);
			wsprintf(buf, "%d Hz, %dbit, %dch", stats.format.srate, 
				 stats.format.bps, stats.format.nch);
			SendDlgItemMessage(dialog, IDC_LABEL_FORMAT, 
					   WM_SETTEXT, 0, (LPARAM)buf);

			SendDlgItemMessage(dialog, IDC_LABEL_CONV, WM_SETTEXT, 
					   0, (LPARAM)(stats.format.conv ? 
					   "Active" : "Inactive"));
			SendDlgItemMessage(dialog, IDC_PROGRESS_USAGE, 
					   PBM_SETRANGE32, 0, 
					   stats.total_buffer_size);
			SendDlgItemMessage(dialog, IDC_PROGRESS_USAGE, 
					   PBM_SETPOS, 
					   stats.total_buffer_usage, 0);
			
			if(config_timer_slow) {
				KillTimer(dialog, 101);
				SetTimer(dialog, 101, 100, NULL);
				config_timer_slow = 0;
			}
		} else {
			SendDlgItemMessage(dialog, IDC_LABEL_WRITTEN, 
					   WM_SETTEXT, 0, (LPARAM)"0");
			SendDlgItemMessage(dialog, IDC_LABEL_PLAYED, 
					   WM_SETTEXT, 0, (LPARAM)"0");
			SendDlgItemMessage(dialog, IDC_LABEL_START, 
					   WM_SETTEXT, 0, (LPARAM)"0 ms");
			SendDlgItemMessage(dialog, IDC_LABEL_LATENCY, 
					   WM_SETTEXT, 0, (LPARAM)"N/A");
			SendDlgItemMessage(dialog, IDC_LABEL_FORMAT, 
					   WM_SETTEXT, 0, (LPARAM)"N/A");
			SendDlgItemMessage(dialog, IDC_LABEL_CONV, WM_SETTEXT,
					   0, (LPARAM)"N/A");
			SendDlgItemMessage(dialog, IDC_PROGRESS_USAGE,
					   PBM_SETPOS, 0, 0);

			if(!config_timer_slow) {
				KillTimer(dialog, CONFIG_TIMER_ID);
				SetTimer(dialog, CONFIG_TIMER_ID, 1000, NULL);
				config_timer_slow = 1;
			}
		}
		break;
	case WM_UPDATE_DISPLAY:
		/* Set device. */
		SendDlgItemMessage(dialog, IDC_COMBO_DEVICE, CB_SETCURSEL, 
				   config_current.device + 1, 0);

		/* Set slider ranges. */
		SendDlgItemMessage(dialog, IDC_SLIDER_SIZE, TBM_SETRANGE, TRUE,
				   MAKELONG(0, TABLE_SIZE(size_table) - 1));
		SendDlgItemMessage(dialog, IDC_SLIDER_COUNT, TBM_SETRANGE, TRUE, 
				   MAKELONG(0, TABLE_SIZE(size_table) - 1));

		/* Set slider values. */
		SendDlgItemMessage(dialog, IDC_SLIDER_SIZE, TBM_SETPOS, TRUE, 
				   block_size_to_index(config_current.block_size));
		SendDlgItemMessage(dialog, IDC_SLIDER_COUNT, TBM_SETPOS, TRUE, 
				   block_count_to_index(config_current.block_count));

		/* Update slider labels. */
		SendMessage(dialog, WM_VSCROLL, TB_ENDTRACK, 
			    (LPARAM)GetDlgItem(dialog, IDC_SLIDER_SIZE));
		SendMessage(dialog, WM_VSCROLL, TB_ENDTRACK, 
			    (LPARAM)GetDlgItem(dialog, IDC_SLIDER_COUNT));

		/* Set check boxes. */
		SendDlgItemMessage(dialog, IDC_CHECK_VOLUME, BM_SETCHECK, 
				   config_current.volume_enabled ? BST_CHECKED : 
				   BST_UNCHECKED, 0);
		SendDlgItemMessage(dialog, IDC_CHECK_BALANCE, BM_SETCHECK, 
				   config_current.reverse_balance ? BST_CHECKED : 
				   BST_UNCHECKED, 0);
		SendDlgItemMessage(dialog, IDC_CHECK_DOWNMIX, BM_SETCHECK, 
				   config_current.pcmconv_enabled ? BST_CHECKED : 
				   BST_UNCHECKED, 0);
		break;
	case WM_COMMAND:
		switch(LOWORD(wparam)) {
		case IDOK:
			config_current.volume_enabled = SendDlgItemMessage(
				dialog, IDC_CHECK_VOLUME, BM_GETCHECK, 
				0, 0) == BST_CHECKED ? 1 : 0;

			config_current.reverse_balance = SendDlgItemMessage(
				dialog, IDC_CHECK_BALANCE, BM_GETCHECK, 
				0, 0) == BST_CHECKED ? 1 : 0;

			config_current.device = (int)SendDlgItemMessage(dialog, 
				IDC_COMBO_DEVICE, CB_GETCURSEL, 0, 0) - 1;

			config_current.pcmconv_enabled = SendDlgItemMessage(
				dialog, IDC_CHECK_DOWNMIX, 
				BM_GETCHECK, 0, 0) == BST_CHECKED ? 1 : 0;

			config = (config_t*)GetWindowLongPtr(dialog, DWLP_USER);
			assert(config);

			config_save(&config_current);
			*config = config_current;
			/* Note: Deliberate fall through to IDCANCEL here. */
		case IDCANCEL:
			KillTimer(dialog, 101);
			EndDialog(dialog, LOWORD(wparam));
			break;
		case IDC_DEFAULTS:
			if(MessageBox(
				dialog, 
				"Are you sure you want to reset to the default "
				"settings?", 
				IVWAVE_NAME " Configuration", 
				MB_YESNO | MB_ICONQUESTION
			) == IDYES) {
				config_load_defaults(&config_current);
				SendMessage(dialog, WM_UPDATE_DISPLAY, 0 ,0);
			}
			break;
		default:
			return FALSE;
		}
	default:
		return FALSE;
	}

	return TRUE;
}

/*
 * config_get_filename - Get name of configuration file.
 */
static void config_get_filename(char *buffer, int size)
{
	char* p = NULL;

	assert(buffer);
	ZeroMemory(buffer, size);

	GetModuleFileName(NULL, buffer, size);
	p = buffer + lstrlen(buffer);

	while(p >= buffer && *p != '.') 
		p--;
	
	lstrcpy(p, ".ini");
}

/*
 * config_load - Load configuration from a file. Returns zero on success
 * and non-zero on failure.
 */
int config_load(config_t *config)
{
	char filename[MAX_PATH];

	assert(config);
	config_get_filename(filename, sizeof(filename));

	return GetPrivateProfileStruct(
		IVWAVE_KEY, 
		"config", 
		config, 
		sizeof(config_t), 
		filename
	) == FALSE;
}

/*
 * config_save - Save configuration to file.
 */
void config_save(const config_t *config)
{
	char filename[MAX_PATH];

	assert(config);
	config_get_filename(filename, sizeof(filename));

	WritePrivateProfileStruct(
		IVWAVE_KEY, 
		"config", 
		(void*)config,
		sizeof(config_t), 
		filename
	);
}

/*
 * config_load_defaults - Fill 'config' with defeault configuration
 * values.
 */
void config_load_defaults(config_t* config)
{
	assert(config);
	config->block_count = count_table[DEFAULT_BLOCK_COUNT_INDEX];
	config->block_size = size_table[DEFAULT_BLOCK_SIZE_INDEX];
	config->device = -1;
	config->reverse_balance = 0;
	config->volume_enabled = 1;
	config->pcmconv_enabled = 1;
}

/*
 * config_compare - Compare two configuration structures to see if one has
 * changed. Returns 0 if they are the same, and non-zero of they differ.
 */
int config_compare(const config_t *config, const config_t *other)
{
	assert(config);
	assert(other);
	return memcmp(config, other, sizeof(config_t));
}

/*
 * config_validate - Check that the values in the given configuration 
 * structure are valid. Returns zero if they are, non-zero if they are not.
 */
int config_validate(const config_t *config)
{
	register unsigned int u = 0;

	for(u = 0; u < TABLE_SIZE(size_table); u++) {
		if(config->block_size == size_table[u])
			break;
	}
	if(u == TABLE_SIZE(size_table))
		return -1;

	for(u = 0; u < TABLE_SIZE(count_table); u++) {
		if(config->block_count == count_table[u])
			break;
	}
	if(u == TABLE_SIZE(count_table))
		return -1;

	if(config->device > (int)(waveOutGetNumDevs() & 0x7fffffff) - 1)
		return -1;

	return 0;
}
