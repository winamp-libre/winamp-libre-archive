/*
 * GPL waveOut Plug-in for Winamp 2.xx
 * -----------------------------------
 * Copyright (C)2002, 2006 David Overton <daveo@rmbx.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef CONFIG_H
#define CONFIG_H

# define DEFAULT_WAVE_DEVICE "Wave Mapper"
# define DEFAULT_BLOCK_SIZE_INDEX 5
# define DEFAULT_BLOCK_COUNT_INDEX 5
# define WM_UPDATE_DISPLAY (WM_USER + 3)
# define CONFIG_TIMER_ID 101

# define TABLE_SIZE(t) (sizeof(t) / sizeof((t)[0]))

typedef struct {
	unsigned int block_count;
	unsigned int block_size;
	int volume_enabled;
	int reverse_balance;
	int device;
	int pcmconv_enabled;
} config_t;

int config_load(config_t *config);
void config_load_defaults(config_t *config);
void config_save(const config_t *config);
int config_validate(const config_t *config);
int config_compare(const config_t *config, const config_t *other);
int config_dialog(config_t *config, HINSTANCE instance, HWND parent);

#endif /* CONFIG_H */
