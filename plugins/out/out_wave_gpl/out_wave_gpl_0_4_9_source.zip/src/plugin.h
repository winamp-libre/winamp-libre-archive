/*
 * GPL waveOut Plug-in for Winamp 2.xx
 * -----------------------------------
 * Copyright (C)2002, 2006 David Overton <daveo@rmbx.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef PLUGIN_H
#define PLUGIN_H

/*
 * These are the default block/buffer sizes. They must
 * tie in with the corresponding values in config.c.
 */
#define IVWAVE_NAME "GPL waveOut Plug-in"
#define IVWAVE_KEY "out_wave_gpl"
#define IVWAVE_VER_VER "v0.4.9"
#ifdef _DEBUG
# define IVWAVE_VER IVWAVE_VER_VER " DEBUG"
#else
# define IVWAVE_VER IVWAVE_VER_VER
#endif

typedef struct {
	int srate;
	int bps;
	int nch;
	int conv;
} format_t;

typedef struct {
	int active;
	unsigned int total_buffer_size;
	unsigned int total_buffer_usage;
	unsigned int block_size;
	unsigned int block_usage;
	unsigned int block_count;
	unsigned int block_current;
	int bytes_written;
	int bytes_played;
	int start_position;
	int latency;
	format_t format;
} stats_t;

void ivwave_get_statistics(stats_t *stats);

#endif /* PLUGIN_H */
