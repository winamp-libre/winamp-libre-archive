/*
 * GPL waveOut Plug-in for Winamp 2.xx
 * -----------------------------------
 * Copyright (C)2002, 2006 David Overton <daveo@rmbx.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include <windows.h>
#include <mmsystem.h>
#if defined(_MSC_VER)
# include <mmreg.h>
#else
# include "mmreg_mingw.h"
#endif
#include <assert.h>
#include "out.h"
#include "config.h"
#include "plugin.h"
#include "resource.h"

static void ivwave_config(HWND parent);
static void ivwave_about(HWND parent);
static void ivwave_init(void);
static void ivwave_quit(void);
static int ivwave_open(int srate, int nch, int bps, int buflen, int prebuf);
static void ivwave_close(void);
static int ivwave_write(char * buffer, int size);
static int ivwave_can_write(void);
static int ivwave_playing(void);
static int ivwave_pause(int pause);
static void ivwave_set_volume(int volume);
static void ivwave_set_pan(int pan);
static void ivwave_flush(int time);
static int ivwave_get_output_time(void);
static int ivwave_get_written_time(void);
static void CALLBACK ivwave_waveout_callback(HWAVEOUT device, UINT msg, 
						 DWORD instance, DWORD header, 
						 DWORD reserved);

static CRITICAL_SECTION ivwave_critical_section;
static HWAVEOUT ivwave_device;
static WAVEHDR *ivwave_blocks;
static int ivwave_current_block;
static volatile unsigned int ivwave_free_blocks;
static int ivwave_written;
static int ivwave_output;
static int ivwave_pos;
static int ivwave_volume;
static int ivwave_pan;
static int ivwave_bytes_per_sec;
static int ivwave_paused;
static config_t ivwave_config_master;
static config_t ivwave_config_current;
static format_t ivwave_format;

/* 
 * The one and only plugin.
 */
static Out_Module ivwave = {
	OUT_VER,
	IVWAVE_NAME" "IVWAVE_VER,
	165540,
	NULL,
	NULL,
	ivwave_config,
	ivwave_about,
	ivwave_init,
	ivwave_quit,
	ivwave_open,
	ivwave_close,
	ivwave_write,
	ivwave_can_write,
	ivwave_playing,
	ivwave_pause,
	ivwave_set_volume,
	ivwave_set_pan,
	ivwave_flush,
	ivwave_get_output_time,
	ivwave_get_written_time
};

/*
 * ivwave_config - Called by the parent application to display the
 * configuration dialog box.
 */
static void ivwave_config(HWND parent)
{
	if(config_dialog(&ivwave_config_master, ivwave.hDllInstance, 
			 parent) == 0) {
		if(ivwave_playing() && config_compare(
			&ivwave_config_current,
			&ivwave_config_master
		)!= 0) {
			MessageBox(
				parent, 
				"Changes will be applied when playback is "
				"next restarted.",
				IVWAVE_NAME " Configuration",
				MB_ICONINFORMATION
			);
		} 
	}
}

/*
 * ivwave_about - Called by the parent application to display
 * some information about the plug-in.
 */
static void ivwave_about(HWND parent)
{
	MessageBox(
		parent,
		IVWAVE_NAME " " IVWAVE_VER "\n"
		"Copyright (C)2002, 2006 David Overton\n\n"
		"E-Mail: daveo@rmbx.net\n"
		"Website: http://www.insomniavisions.com",
		"About " IVWAVE_NAME,
		MB_ICONINFORMATION
	);
}

/*
 * ivwave_init - Called once when the plug-in is loaded. This simply
 * initialises some static vars which are already initialised (if my
 * understanding of the C standard is correct).
 */
static void ivwave_init(void)
{
	ivwave_device = NULL;
	ivwave_blocks = NULL;
	ivwave_volume = 255;
	ivwave_pan = 0;

	if(config_load(&ivwave_config_master) != 0) {
		/* Load default configuration. */
		config_load_defaults(&ivwave_config_master);
	} else if(config_validate(&ivwave_config_master) != 0) {
		MessageBox(
			NULL,
			"It looks like the configuration for this plug-in has "
			"become corrupt. The configuration will be reset to "
			"the defaults.\n\n"
			"Please check the configuration of this plug-in and "
			"verify that it is satisfactory for your system.",
			IVWAVE_NAME " Configuration",
			MB_ICONEXCLAMATION
		);
		config_load_defaults(&ivwave_config_master);
	}
   

	/*
	 * Set up some bits to make the config display properly
	 * before we've initiated playback. since the rest are static
	 * we don't need to touch them.
	 */
	ivwave_free_blocks = ivwave_config_master.block_count;
	ivwave_config_current = ivwave_config_master;
}

/*
 * ivwave_quit - Called on quit. This assert checks that the device
 * was properly closed before the application unloaded the plug-in.
 * does nothing in release mode.
 */
static void ivwave_quit(void)
{
	assert(ivwave_device == NULL);
}

/*
 * ivwave_open - Open the device. srate = sampling rate, nch = number of
 * channels, bps = number of bits per sample. buflen and prebuf are 
 * ignored.
 */
static int ivwave_open(int srate, int nch, int bps, int buflen, int prebuf)
{
	WAVEFORMATEX wfx;
	MMRESULT result;
	unsigned char *buffer;
	unsigned int u;

	assert(ivwave_device == NULL);

	/*
	 * Copy the config so that we can modify the original during
	 * playback without screwing anything up.
	 */
	ivwave_config_current = ivwave_config_master;

	ivwave_format.bps = bps;
	ivwave_format.nch = nch;
	ivwave_format.srate = srate;
	ivwave_format.conv = 0;

	if(waveOutGetNumDevs() == 0) {
		MessageBox(
			ivwave.hMainWindow,
			"Playback cannot proceed because there are no valid wave devices\n"
			"present on this system. If you have a sound card and you are\n"
			"sure that the drivers are correctly installed, consider trying\n"
			"the DirectSound output plug-in instead.",
			IVWAVE_NAME" Error",
			MB_ICONERROR
		);
		return -1;

	}

	/*
	 * Set up format info.
	 */
	wfx.cbSize = 0;
	wfx.wFormatTag = WAVE_FORMAT_PCM;
	wfx.nChannels = nch;
	wfx.nSamplesPerSec = srate;
	wfx.wBitsPerSample = bps;
	wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) >> 3;
	wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
	
	/*
	 * Open the wave output device.
	 */
	if((result = waveOutOpen(
		&ivwave_device, 
		ivwave_config_current.device, 
		&wfx, 
		(DWORD_PTR)ivwave_waveout_callback,
		(DWORD_PTR)&ivwave_free_blocks, 
		CALLBACK_FUNCTION
	)) != MMSYSERR_NOERROR && ivwave_config_current.pcmconv_enabled) {
		/*
		 * See http://www.microsoft.com/whdc/device/audio/multichaud.mspx
		 *
		 * As well as supporting audio with > 2 channels it will
		 * perform conversions on the data before writing it to the
		 * card.
		 */
		WAVEFORMATEXTENSIBLE wfex;

		/*
		 * ...avoiding ks.h and ksmedia.h
		 */ 
		GUID KSDATAFORMAT_SUBTYPE_PCM = {
			0x00000001,
			0x0000,
			0x0010,
			{ 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71 }
		};

		wfex.Format = wfx;
		wfex.Format.cbSize = 22;
		wfex.Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE;
		wfex.Samples.wReserved = 0;
		wfex.dwChannelMask = 0;
		wfex.SubFormat = KSDATAFORMAT_SUBTYPE_PCM;

		result = waveOutOpen(
			&ivwave_device,
			ivwave_config_current.device,
			(WAVEFORMATEX*)&wfex,
			(DWORD_PTR)ivwave_waveout_callback,
			(DWORD_PTR)&ivwave_free_blocks, 
			CALLBACK_FUNCTION
		);

		ivwave_format.conv = 1;
	}

	if(result != MMSYSERR_NOERROR) {
		WAVEOUTCAPS woc;
		char buffer[512];
		
		if(waveOutGetDevCaps(
			(UINT)ivwave_config_current.device,
			&woc,
			sizeof(WAVEOUTCAPS)
		) != MMSYSERR_NOERROR)
			lstrcpy(woc.szPname, "[Invalid Device]");

		/*
		 * argh
		 */
		switch(result) {
		case WAVERR_BADFORMAT:
			wsprintf(
				buffer,
				"The \"%s\" device returned a Bad Format error (%d) during\n"
				"the waveOutOpen call. This is because the device does not support the\n"
				"following PCM format:\n\n"
				"Sample Rate:\t%d Hz\n"
				"Sample Size:\t%d bits (%s)\n"
				"Channels:\t%d\n\n"
				"%sinput plug-in has options for changing the output format\n"
				"try adjusting these to a format supported by your sound card.\n"
				"Consult your sound card manual for exact format specifications.",
				woc.szPname,
				result,
				wfx.nSamplesPerSec,
				wfx.wBitsPerSample,
				wfx.wBitsPerSample == 8 ? "unsigned" : "signed",
				wfx.nChannels,
				ivwave_config_current.pcmconv_enabled ?
				"If the current "
				:
				"You might be able to fix this problem by enabling the \"PCM Conversion\"\n"
				"option in the configuration for this plug-in. Alternatively, if the\ncurrent "
			);
			break;
		case MMSYSERR_BADDEVICEID:
			wsprintf(
				buffer,
				"The waveOut system returned a Bad Device ID error (%d) during\n"
				"the waveOutOpen call. The device identifier given was %d.\n"
				"Please ensure that you have a soundcard and that the drivers are\n"
				"installed correctly. If this is already the case, try selecting a\n"
				"different device from the \"Output Device\" section in the configuration\n"
				"for this plug-in\n",
				result,
				ivwave_config_current.device
			);
			break;
		default:
			wsprintf(
				buffer,
				"An MMSYSTEM error occurred while opening the wave device.\n\n"
				"Output device: %s\n"
				"Error code: %u\n\n",
				woc.szPname,
				result
			);
		}

		MessageBox(
			ivwave.hMainWindow,
			buffer,
			IVWAVE_NAME" Error",
			MB_ICONERROR
		);
		return -1;
	}

	/*
	 * allocate memory for buffers, headers etc.
	 */
	if((buffer = (unsigned char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, (sizeof(WAVEHDR) + ivwave_config_current.block_size) * ivwave_config_current.block_count)) == NULL) {
		waveOutClose(ivwave_device);
		ivwave_device = NULL;
		MessageBox(
			ivwave.hMainWindow,
			"Memory allocation error allocating wave buffer",
			IVWAVE_NAME" Error",
			MB_ICONERROR
		);
		return -1;
	}

	InitializeCriticalSection(&ivwave_critical_section);

	ivwave_blocks = (WAVEHDR*)buffer;
	ivwave_current_block = 0;
	ivwave_free_blocks = ivwave_config_current.block_count;
	ivwave_written = 0;
	ivwave_output = 0;
	ivwave_pos = 0;
	ivwave_bytes_per_sec = nch * (bps >> 3) * srate;
	ivwave_paused = 0;
	
	/*
	 * Set up block pointers and prepare headers.
	 */
	for(u = 0; u < ivwave_config_current.block_count; u++) {
		ivwave_blocks[u].lpData = buffer + (sizeof(WAVEHDR) * ivwave_config_current.block_count) + (u * ivwave_config_current.block_size);
		ivwave_blocks[u].dwBufferLength = ivwave_config_current.block_size;
		waveOutPrepareHeader(ivwave_device, &ivwave_blocks[u], sizeof(WAVEHDR));
	}
 
	/*
	 * Now actually set volume and pan in case they've been
	 * set before the device was open
	 */
	ivwave_set_pan(ivwave_pan);
	ivwave_set_volume(ivwave_volume);
		
	/*
	 * Return max amount of time it'll take to play through the buffer in ms
	 * the +1 is a safety margin which adds approximately the time to play 1 
	 * block to the total.
	 */
	return MulDiv((ivwave_config_current.block_count + 1) * ivwave_config_current.block_size, 1000, ivwave_bytes_per_sec);
}

/*
 * ivwave_close - close the device if it is open. calling this with
 * the device closed will trigger an assert failure in debug mode.
 */
static void ivwave_close(void)
{
	unsigned int u;

	assert(ivwave_device != NULL);

	/*
	 * unpause if paused
	 */
	if(ivwave_paused) {
		waveOutRestart(ivwave_device);
		ivwave_paused = 0;
	}

	/*
	 * reset the device
	 */
	waveOutReset(ivwave_device);

	/*
	 * wait for all buffers to complete
	 */
	while(ivwave_free_blocks != ivwave_config_current.block_count)
		Sleep(10);

	/* 
	 * Unprepare headers.
	 */
	for(u = 0; u < ivwave_config_current.block_count; u++) 
		waveOutUnprepareHeader(ivwave_device, &ivwave_blocks[u], sizeof(WAVEHDR));

	DeleteCriticalSection(&ivwave_critical_section);

	/*
	 * close the device
	 */
	waveOutClose(ivwave_device);
	ivwave_device = NULL;

	/*
	 * and finally free the used memory
	 */
	HeapFree(GetProcessHeap(), 0, ivwave_blocks);
	ivwave_blocks = NULL;
}

/*
 * ivwave_write - this will actually block if you write too much
 * but the input plug-in should be smart enough to realise that it
 * should write 
 * a) no more than 8192 bytes and
 * b) no more than ivwave_can_write() returns. 
 * we could add another size check here but it's not really worth it.
 */
static int ivwave_write(char *buffer, int size)
{
	WAVEHDR *current;
	unsigned int remain;

	assert(ivwave_device);
	assert(size <= 8192);

	current = &ivwave_blocks[ivwave_current_block];

	assert(current);
	
	while(size > 0) {
		if(size < (int)(ivwave_config_current.block_size - current->dwUser)) {
			memcpy(current->lpData + current->dwUser, buffer, size);
			current->dwUser += size;
			ivwave_written += size;
			break;
		}

		remain = ivwave_config_current.block_size - (unsigned int)current->dwUser;
		memcpy(current->lpData + current->dwUser, buffer, remain);
		size -= remain;
		buffer += remain;
		ivwave_written += remain;
		current->dwBufferLength = ivwave_config_current.block_size;

		waveOutWrite(ivwave_device, current, sizeof(WAVEHDR));
		
		EnterCriticalSection(&ivwave_critical_section);
		ivwave_free_blocks--;
		LeaveCriticalSection(&ivwave_critical_section);

		while(!ivwave_free_blocks)
			Sleep(10);

		ivwave_current_block++;
		ivwave_current_block %= ivwave_config_current.block_count;

		current = &ivwave_blocks[ivwave_current_block];
		current->dwUser = 0;
	}

	return 0;   
}

/*
 * ivwave_can_write - Return number of bytes that can be written - 
 * 0 if device is closed - note that this can be called before playback
 * has been started.
 */
static int ivwave_can_write(void)
{
	WAVEHDR* current = &ivwave_blocks[ivwave_current_block];

	if(!ivwave_device)
		return 0;
	
	/* XXX: possible race? */
	return ivwave_free_blocks * ivwave_config_current.block_size - (int)current->dwUser;
}

/*
 * ivwave_playing - Returns a non-zero value if playback is currently in
 * progress. This implementation works by seeing if all wave headers are
 * free. If they are, playback has stopped. Note that playback is considered
 * to be active even if output is paused.
 */
static int ivwave_playing(void)
{
	if(!ivwave_device)
		return 0;

	return (ivwave_free_blocks != ivwave_config_current.block_count);
}

/*
 * ivwave_pause - Pause or resume playback. Returns the previous paused
 * state i.e non-zero for paused, zero for playing.
 */
static int ivwave_pause(int pause)
{
	assert(ivwave_device);
	
	if(pause) {
		waveOutPause(ivwave_device);
		ivwave_paused = 1;
	} else {
		waveOutRestart(ivwave_device);
		ivwave_paused = 0;
	}

	return !pause;
}

/*
 * ivwave_set_volume - Set the volume (volume ranges from 0->255). Since the
 * volume and pan settings are intrinsicly linked for waveOut, this function
 * also handles the pan setting, and is also called by ivwave_set_pan().
 */
static void ivwave_set_volume(int volume)
{
	unsigned short left;
	unsigned short right;

	/*
	 * Out of range so do the default (use what the system is set to).
	 */
	if(volume < 0 || volume > 255) {
		/*
		 * XXX: Maybe we should call waveOutGetVolume() and set our internal
		 * values to that of the system?
		 */
		return;
	}

	ivwave_volume = volume;

	/*
	 * Input plug-ins often seem to call this function to effect a reset even
	 * before we have opened the device, so if this is the case, don't go any
	 * further.
	 */ 
	if(!ivwave_device)
		return;
	
	if(ivwave_config_current.volume_enabled) {
		volume += volume << 8;
		left = volume & 0xffff;
		right = volume & 0xffff;
	
		/*
		 * Compensate for the pan setting...
		 */
		if(ivwave_pan > 0)
			left -= ivwave_pan * volume / 128;
		else if(ivwave_pan < 0)
			right -= -ivwave_pan * volume / 128;
					
		/* 
		 * ...and actually set the volume.
		 */
		waveOutSetVolume(ivwave_device, ivwave_config_current.reverse_balance ?
				 (left << 16) | right : (right << 16) | left);
	}
}

/*
 * ivwave_set_pan - set the pan (pan ranges from -128 to +128)
 */
static void ivwave_set_pan(int pan)
{
	/*
	 * out of range so do the default (centre)
	 */
	if(pan < -128 || pan > 128) {
		ivwave_pan = 0;
		return;
	}

	ivwave_pan = pan;

	/* 
	 * ivwave_set_pan can be called before the
	 * device is opened for setting the defaults
	 */
	if(!ivwave_device)
		return;

	/*
	 * windows waveOut uses waveOutSetVolume to set l&r
	 * volumes together so leave the volume setter to deal
	 * with it.
	 */
	ivwave_set_volume(ivwave_volume);
}

/*
 * ivwave_flush - flush output buffers and continue playback from
 * 'time'.
 */
static void ivwave_flush(int time)
{
	WAVEHDR* current;
	assert(ivwave_device);

	current = &ivwave_blocks[ivwave_current_block];
	
	/*
	 * if the current buffer has some data in it then write it
	 * anyway.
	 */
	if(current->dwUser) {
		current->dwBufferLength = (DWORD)current->dwUser;
		current->dwUser = 0;
		
		waveOutWrite(ivwave_device, current, sizeof(WAVEHDR));
		
		EnterCriticalSection(&ivwave_critical_section);
		ivwave_free_blocks--;
		LeaveCriticalSection(&ivwave_critical_section);
	}

	waveOutReset(ivwave_device);
	
	/*
	 * Wait for all buffers to be returned by the reset
	 */ 
	while(ivwave_free_blocks < ivwave_config_current.block_count)
		Sleep(10);

	/*
	 * Point to the next block
	 */
	ivwave_current_block++;
	ivwave_current_block %= ivwave_config_current.block_count;
	/*
	 * Reset positioning/statistics variables.
	 */
	ivwave_output = 0;
	ivwave_written = 0;
	ivwave_pos = time;
}

/*
 * ivwave_get_output_time - return the number of milliseconds of
 * audio that have actually been played.
 */
static int ivwave_get_output_time(void)
{
	MMTIME time;
	
	if(!ivwave_device)
		return 0;
	
	/*
	 * want time in bytes as this is the most accurate
	 */
	time.wType = TIME_BYTES;
	
	if(waveOutGetPosition(ivwave_device, &time, sizeof(MMTIME)) == MMSYSERR_NOERROR) {
		/*
		 * waveOutGetPosition apparently can return any type of time it
		 * feels like if the one you specified wasn't good enough for 
		 * it... sorry, "not supported".
		 */
		switch(time.wType) {
		case TIME_BYTES:
			return ivwave_pos + MulDiv(time.u.cb, 1000, ivwave_bytes_per_sec);
		case TIME_MS:
			return ivwave_pos + time.u.ms;
		case TIME_SAMPLES:
			return ivwave_pos + MulDiv(time.u.sample, 1000, ivwave_format.srate);
		default:
			break;
		}
	}

	/*
	 * Worst case - return our own stored value of the time. this value is
	 * only accurate to the nearest block and is incremented in the callback
	 * function. using this with particularly large blocks (ie > 8k) will 
	 * cause the internal vis to become jumpy, ideally we want the above
	 * to work.
	 */
	return ivwave_pos + MulDiv(ivwave_output, 1000, ivwave_bytes_per_sec);
}

/*
 * ivwave_get_written_time - return the number of milliseconds of
 * audio that have been written to this plug-in but not necessarily
 * played (could be still buffered).
 */
static int ivwave_get_written_time(void)
{
	if(!ivwave_device)
		return 0;
	
	return ivwave_pos + MulDiv(ivwave_written, 1000, ivwave_bytes_per_sec);
}

/*
 * ivwave_waveout_callback - This function is called when a block has finished
 * playing and when the waveOut device is opened or closed. We use it here to
 * increment the free block counter and the number of bytes played.
 *
 * See the waveOutProc documentation in the Platform SDK for more information.
 */
static void CALLBACK ivwave_waveout_callback(HWAVEOUT device, UINT msg, 
					     DWORD instance, DWORD header, 
					     DWORD reserved)
{
	if(msg != WOM_DONE)
		return;

	/* We've now played some more bytes */
	ivwave_output += ((WAVEHDR*)header)->dwBufferLength;

	/* We also have another block available for use */
	EnterCriticalSection(&ivwave_critical_section);
	ivwave_free_blocks++;
	LeaveCriticalSection(&ivwave_critical_section);
}

/*
 * exported function - returns the address of the plug-in structure.
 */
Out_Module *winampGetOutModule(void)
{
	return &ivwave;
}

/*
 * ivwave_get_statistics - get some stats on the current playback
 */
void ivwave_get_statistics(stats_t *stats)
{
	assert(stats);

	stats->active = ivwave_playing();
	stats->block_count = ivwave_config_current.block_count;
	stats->block_usage = ivwave_config_current.block_count - ivwave_free_blocks;
	stats->block_current = ivwave_current_block;
	stats->bytes_played = ivwave_output;
	stats->bytes_written = ivwave_written;
	stats->total_buffer_size = ivwave_config_current.block_count * ivwave_config_current.block_size;
	stats->total_buffer_usage = stats->total_buffer_size - ivwave_can_write();
	stats->latency = ivwave_get_written_time() - ivwave_get_output_time();
	stats->start_position = ivwave_pos;
	stats->block_size = ivwave_config_current.block_size;
	stats->format = ivwave_format;
}

