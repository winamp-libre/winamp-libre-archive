//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resources.rc


#define DIALOG_CONNECT                       100
#define DIALOG_CONNECT_STRING                1000
#define DIALOG_CONNECT_PROGRESS              1001

#define DIALOG_DEVICE                        101
#define DIALOG_DEVICE_INPUT_NAME             1010
#define DIALOG_DEVICE_INPUT_TYPE             1011
#define DIALOG_DEVICE_INPUT_HOST             1012
#define DIALOG_DEVICE_INPUT_PORT             1013

#define DIALOG_OPTIONS                       102
#define DIALOG_OPTIONS_LISTBOX_SPEAKERS      1020
#define DIALOG_OPTIONS_CHECKBOX_VOLCONTROL   1021
#define DIALOG_OPTIONS_CHECKBOX_PLYCONTROL   1022
#define DIALOG_OPTIONS_CHECKBOX_RESETONPAUSE 1023

#define DIALOG_PASSWORD                      103
#define DIALOG_PASSWORD_STRING               1030
#define DIALOG_PASSWORD_TEXTBOX_PASSWORD     1031
#define DIALOG_PASSWORD_CHECKBOX_REMEMBER    1032

#define ICON_APX                             104
#define ICON_ATV                             105
#define ICON_AFS                             106
#define ICON_ASV                             107
#define ICON_AVR                             108
#define ICON_ANY                             109


// Next default values for new objects
#ifdef APSTUDIO_INVOKED
	#ifndef APSTUDIO_READONLY_SYMBOLS
		#define _APS_NEXT_RESOURCE_VALUE     110
		#define _APS_NEXT_COMMAND_VALUE      40001
		#define _APS_NEXT_CONTROL_VALUE      1040
		#define _APS_NEXT_SYMED_VALUE        100
	#endif
#endif
