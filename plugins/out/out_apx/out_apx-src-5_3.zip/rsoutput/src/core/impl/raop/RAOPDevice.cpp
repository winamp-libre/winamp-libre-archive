/* Copyright (c) 2014  Eric Milles <eric.milles@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "Debugger.h"
#include "Platform.h"
#include "Random.h"
#include "RAOPDevice.h"
#include "RAOPEngine.h"
#include "RTSPClient.h"
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstring>
#include <string>
#include <Poco/ByteOrder.h>
#include <Poco/Format.h>


using Poco::ByteOrder;
using Poco::Net::IPAddress;
using Poco::Net::SocketAddress;
using Poco::Net::StreamSocket;


static void dmapAppend(buffer_t& buf, const char* key, const void* val, const uint32_t len)
{
	assert(std::strlen(key) == 4);

	buffer_t::size_type idx = buf.size();

	// increase capacity of buffer to accommodate key, value length and value
	buf.resize(idx + 8 + len);

	std::memcpy(&buf[idx], key, 4);
	idx += 4;

	const uint32_t length = ByteOrder::toNetwork(len);
	std::memcpy(&buf[idx], &length, 4);
	idx += 4;

	if (len > 0)
	{
		std::memcpy(&buf[idx], val, len);
		idx += len;
	}

	assert(idx == buf.size());
}

template <typename integer_t>
inline void dmapAppend(buffer_t& buf, const char* key, integer_t val)
{
	val = ByteOrder::toNetwork(val);
	dmapAppend(buf, key, &val, sizeof(integer_t));
}

template <>
inline void dmapAppend(buffer_t& buf, const char* key, const int8_t val)
{
	dmapAppend(buf, key, &val, 1);
}

template <>
inline void dmapAppend(buffer_t& buf, const char* key, const uint8_t val)
{
	dmapAppend(buf, key, &val, 1);
}


//------------------------------------------------------------------------------


RAOPDevice::RAOPDevice(RAOPEngine& raopEngine,
	const int encryptionType, const byte_t metadataFlags)
:
	_encryptionType(encryptionType),
	_metadataFlags(metadataFlags),
	_raopEngine(raopEngine),
	_deviceVolume(0),
	_audioLatency(0)
{
	// generate DACP remote control identifier
	Random::fill(&_remoteControlId, sizeof(uint32_t));
}


RAOPDevice::~RAOPDevice()
{
	try
	{
		close();
	}
	CATCH_ALL
}


/**
 * Tests connection with remote speakers on specified socket.
 *
 * @param firstTime <code>true</code> if first initiation for remote speakers
 * @return zero on success; non-zero on failure
 */
int RAOPDevice::test(StreamSocket& socket, const bool firstTime)
{
	if (_rtspClient.get() == NULL || !_rtspClient->isReady())
	{
		_rtspClient.reset(new RTSPClient(socket, _remoteControlId));
	}

	// send options message to remote speakers
	int returnCode = _rtspClient->doOptions(
		secureDataStream() && firstTime ? _raopEngine.rsaKey() : NULL);
	if (returnCode != RTSP_STATUS_CODE_OK)
	{
		return returnCode;
	}

	return 0;
}


/**
 * Opens session with remote speakers on specified socket.
 *
 * @param audioJackStatus [out] status of remote speakers audio jack
 * @return zero on success; non-zero on failure
 */
int RAOPDevice::open(StreamSocket& socket, AudioJackStatus& audioJackStatus)
{
	const IPAddress remoteHost = socket.peerAddress().host();

	if (_rtspClient.get() == NULL || !_rtspClient->isReady())
	{
		_rtspClient.reset(new RTSPClient(socket, _remoteControlId));
	}

	// send announce message to remote speakers
	int returnCode = _rtspClient->doAnnounce(
		secureDataStream() ? _raopEngine._encodedKey : "",
		secureDataStream() ? _raopEngine._encodedIV : "");
	if (returnCode != RTSP_STATUS_CODE_OK)
	{
		return returnCode;
	}

	uint16_t serverPort = 0;
	uint16_t controlPort = _raopEngine.controlPort();
	uint16_t timingPort = _raopEngine.timingPort();

	// send setup message to remote speakers
	returnCode = _rtspClient->doSetup(
		serverPort, controlPort, timingPort, _audioLatency, audioJackStatus);
	if (returnCode != RTSP_STATUS_CODE_OK)
	{
		return returnCode;
	}

	_audioSocketAddr = SocketAddress(remoteHost, serverPort);
	_controlSocketAddr = SocketAddress(remoteHost, controlPort);
	_timingSocketAddr = SocketAddress(remoteHost, timingPort);

	// send record message to remote speakers
	returnCode = _rtspClient->doRecord(
		_raopEngine._rtpSeqNumOutgoing, _raopEngine._rtpTimeOutgoing, _audioLatency);
	if (returnCode != RTSP_STATUS_CODE_OK)
	{
		return returnCode;
	}

	_raopEngine.attach(this);

	return 0;
}


void RAOPDevice::close()
{
	_audioLatency = 0;
	_audioSocketAddr = _controlSocketAddr = _timingSocketAddr = SocketAddress();

	// ensure RTSP client is destroyed even if detach or teardown throw
	std::auto_ptr<RTSPClient> rtspClient(_rtspClient);

	_raopEngine.detach(this);

	if (rtspClient.get() != NULL && rtspClient->isReady())
	{
		// send teardown message to remote speakers
		rtspClient->doTeardown();
	}
}


bool RAOPDevice::isOpen(const bool pollConnection) const
{
	return (_rtspClient.get() != NULL && (!pollConnection || _rtspClient->isReady()));
}


void RAOPDevice::setPassword(const std::string& password)
{
	_rtspClient->setPassword(password);
}


float RAOPDevice::getVolume()
{
	try
	{
		assert(_rtspClient.get() != NULL && _rtspClient->isReady()); std::string vol;
		if (_rtspClient->doGetParameter("volume", vol) == RTSP_STATUS_CODE_OK)
		{
			return (_deviceVolume = float(std::atof(vol.c_str())));
		}
	}
	CATCH_ALL

	return _deviceVolume;
}


void RAOPDevice::putVolume(const float volume)
{
	_deviceVolume = std::min(std::max(volume, -100.0f), 0.0f);

	// reiterate volume to device; some wait for echo before changing levels
	_rtspClient->doSetParameter("volume", Poco::format("%hf", _deviceVolume));
}


void RAOPDevice::setVolume(const float absolute, const float relative)
{
	if ((_deviceVolume == 0.0 && relative == 0.0)
		|| std::fabs(_deviceVolume - (absolute - relative)) < 0.1f)
	{
		_deviceVolume = absolute;
	}
	else
	{
		_deviceVolume = std::min(float(_deviceVolume + relative), -9.0f);
	}

	float decibels(_deviceVolume);
	if (decibels > 0.0) decibels = 0.0;
	if (decibels <= -100.0) decibels = -144.0;

	assert(_rtspClient.get() != NULL && _rtspClient->isReady());
	_rtspClient->doSetParameter("volume", Poco::format("%hf", decibels));
}


void RAOPDevice::flush()
{
	assert(_rtspClient.get() != NULL && _rtspClient->isReady());
	_rtspClient->doFlush(_raopEngine._rtpSeqNumOutgoing, _raopEngine._rtpTimeOutgoing);
}


void RAOPDevice::updateMetadata(const OutputMetadata& metadata)
{
	const uint32_t rtpTime = _raopEngine._rtpTimeIncoming;

	if (_metadataFlags & MD_TEXT)
	{
		const std::string& title = metadata.title();
		const std::string& album = metadata.album();
		const std::string& artist = metadata.artist();

		// append metadata strings to DMAP tag buffer
		buffer_t tags;
		dmapAppend(tags, "mikd", int8_t(2));
	//	dmapAppend(tags, "miid", uint32_t(0));
		dmapAppend(tags, "minm", &title[0], title.length());
		dmapAppend(tags, "asal", &album[0], album.length());
		dmapAppend(tags, "asar", &artist[0], artist.length());
		dmapAppend(tags, "asdk", int8_t(metadata.length() > 0 ? 0 : 1));
		dmapAppend(tags, "astn", metadata.playlistPos().first);
		dmapAppend(tags, "astc", metadata.playlistPos().second);

		// wrap tags in metadata list container
		buffer_t mlit;
		dmapAppend(mlit, "mlit", &tags[0], tags.size());

		assert(_rtspClient.get() != NULL && _rtspClient->isReady());
		_rtspClient->doSetParameter("application/x-dmap-tagged", mlit, rtpTime);
	}

	if (_metadataFlags & MD_IMAGE)
	{
		// check size characteristics to prevent transmitting a dangerous image
		bool tooBig = (metadata.artworkData().size() > 262144); // 256 KB
		if (!tooBig)
		{
			const shorts_t dims = metadata.artworkDims();
			if (dims.first > 1000 || dims.second > 1000) tooBig = true;
		}

		const buffer_t& imageData = (!tooBig ? metadata.artworkData() : buffer_t());
		const std::string& imageType = (!tooBig ? metadata.artworkType() : "image/none");

		assert(_rtspClient.get() != NULL && _rtspClient->isReady());
		_rtspClient->doSetParameter(imageType, imageData, rtpTime);
	}
}


void RAOPDevice::updateProgress(const OutputInterval& interval)
{
	if (_metadataFlags & MD_PROGRESS)
	{
		const uint32_t beg = static_cast<uint32_t>(interval.first);
		const uint32_t end = static_cast<uint32_t>(interval.second);
		const uint32_t pos = _raopEngine._rtpTimeIncoming;

		assert(_rtspClient.get() != NULL && _rtspClient->isReady());
		_rtspClient->doSetParameter("progress", Poco::format("%u/%u/%u", beg, pos, end));
	}
}
