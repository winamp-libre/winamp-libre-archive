#include "main.h"
#include <commctrl.h>
#include "resource.h"

#pragma warning(disable:4800)

extern Out_Module mod;
extern UINT cfg_buf_ms,cfg_dev;
extern bool cfg_volume,cfg_altvol;

void get_waveout_state(char * z);

void _init();

BOOL WINAPI CfgProc(HWND wnd,UINT msg,WPARAM wp,LPARAM lp)
{
	switch(msg)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage(wnd,IDC_VOL_ENABLE,BM_SETCHECK,(long)cfg_volume,0);
		SendDlgItemMessage(wnd,IDC_ALT_VOL,BM_SETCHECK,(long)cfg_altvol,0);
		SendDlgItemMessage(wnd,IDC_SPIN1,UDM_SETRANGE,0,MAKELONG(0x7FFF,100));
		SetDlgItemInt(wnd,IDC_BUF_SIZE,cfg_buf_ms,0);
		{
			int dev;
			HWND w=GetDlgItem(wnd,IDC_DEV);
			UINT max=waveOutGetNumDevs();
			WAVEOUTCAPS caps;
			//SendMessage(w,CB_ADDSTRING,(long)"default device",0);
			for(dev=-1;dev<(int)max;dev++)
			{
				waveOutGetDevCaps((UINT)dev,&caps,sizeof(caps));
				SendMessage(w,CB_ADDSTRING,0,(long)caps.szPname);
			}
			SendMessage(w,CB_SETCURSEL,cfg_dev,0);

		}
		SetTimer(wnd,1,500,0);
		CfgProc(wnd,WM_TIMER,0,0);
		
		return 1;
	case WM_COMMAND:
		switch(wp)
		{
		case IDOK:
			KillTimer(wnd,1);
			cfg_dev=SendDlgItemMessage(wnd,IDC_DEV,CB_GETCURSEL,0,0);
			{
				UINT bs=GetDlgItemInt(wnd,IDC_BUF_SIZE,0,0);
				if (bs<100) bs=100;
				else if (bs>10000) bs=10000;
				cfg_buf_ms=bs;
			}
			cfg_volume=(bool)SendDlgItemMessage(wnd,IDC_VOL_ENABLE,BM_GETCHECK,0,0);
			cfg_altvol=(bool)SendDlgItemMessage(wnd,IDC_ALT_VOL,BM_GETCHECK,0,0);
			EndDialog(wnd,1);
			break;
		case IDCANCEL:
			KillTimer(wnd,1);
			EndDialog(wnd,0);
			break;
		}
		break;
	case WM_TIMER:
		{
			char poo[512];
			get_waveout_state(poo);
			SetDlgItemText(wnd,IDC_STATE,poo);
		}
		break;
	}
	return 0;
}

void Config(HWND w)
{
	_init();
	DialogBox(mod.hDllInstance,(char*)IDD_CONFIG,w,CfgProc);
}


#ifdef GAPLESS
static char CFG_NAME[]="OUT_WAVE_GAPLESS";
#else
static char CFG_NAME[]="OUT_WAVE";
#endif

static UINT atoui(char* s)
{
	int ret=0;
	while(*s>='0' && *s<='9') {ret=10*ret+(*s-'0');s++;}
	return ret;
}

static int _do_var(char* file,int v,char* n,bool s)
{
	if (s)
	{
		char tmp[32];
		wsprintf(tmp,"%u",v);
		WritePrivateProfileString(CFG_NAME,n,tmp,file);
		return v;
	}
	else
	{
		char tmp[64],tmp_s[32];
		wsprintf(tmp_s,"%u",v);
		GetPrivateProfileString(CFG_NAME,n,tmp_s,tmp,64,file);
		return atoui(tmp);
	}

}

#define do_var(V) {V=_do_var(inifile,V,#V,s);}

static void _do_string(char* file,char* string,char* n,bool s)
{
	if (s)
	{
		WritePrivateProfileString(CFG_NAME,n,string,file);
	}
	else
	{
		char tmp[MAX_PATH];
		strcpy(tmp,string);
		GetPrivateProfileString(CFG_NAME,n,tmp,string,MAX_PATH,file);
	}
}

#define do_string(V) _do_string(inifile,V,#V,s)


void do_cfg(bool s)
{
	char inifile[MAX_PATH];
	char *p;
	GetModuleFileName(0,inifile,sizeof(inifile));
	p=inifile+strlen(inifile);
	while (p >= inifile && *p != '.') p--;
	strcpy(++p,"ini");

	do_var(cfg_buf_ms);
	do_var(cfg_dev);
	do_var(cfg_volume);
	do_var(cfg_altvol);
}
