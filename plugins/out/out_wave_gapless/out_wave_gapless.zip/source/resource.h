//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by out_wave.rc
//
#define IDD_CONFIG                      101
#define IDC_GAPLESS                     1000
#define IDC_BUF_SIZE                    1001
#define IDC_SPIN1                       1002
#define IDC_PRIMARY                     1003
#define IDC_DEV                         1004
#define IDC_HACK                        1005
#define IDC_EXCLUSIVE                   1006
#define IDC_PREBUFFER                   1007
#define IDC_SPIN2                       1008
#define IDC_VOL_ENABLE                  1009
#define IDC_ALT_VOL                     1010
#define IDC_PREB_TEXT                   1012
#define IDC_STATE                       1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
