#ifndef _DEBUG
// release optimizations
// /Og (global optimizations), /Os (favor small code), /Oy (no frame pointers)
//#pragma optimize("gsy",on)
#pragma comment(linker,"/RELEASE")
// set the 512-byte alignment (only in VC6+)
#if _MSC_VER >= 1200
#pragma comment(linker,"/opt:nowin98")
#endif
#endif

#define STRICT
#include <windows.h>
#include "out.h"

extern Out_Module mod;

#define VER "v1.02"
#ifndef GAPLESS
#define NAME "Winamp2 waveOut plug-in "VER
#else
#define NAME "Gapless waveOut plug-in "VER
#endif