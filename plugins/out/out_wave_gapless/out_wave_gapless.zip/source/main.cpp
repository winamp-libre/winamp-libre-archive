#include "main.h"

#if 0

#include <ks.h>
#include <ksmedia.h>

#else

//quick hack to avoid dx8 sdk headers

#if defined(__cplusplus) && _MSC_VER >= 1100
#define DEFINE_GUIDSTRUCT(g, n) struct __declspec(uuid(g)) n
#define DEFINE_GUIDNAMED(n) __uuidof(struct n)
#else // !defined(__cplusplus)
#define DEFINE_GUIDSTRUCT(g, n) DEFINE_GUIDEX(n)
#define DEFINE_GUIDNAMED(n) n
#endif // !defined(__cplusplus)


#if !defined( DEFINE_WAVEFORMATEX_GUID )
#define DEFINE_WAVEFORMATEX_GUID(x) (USHORT)(x), 0x0000, 0x0010, 0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71
#endif


#define STATIC_KSDATAFORMAT_SUBTYPE_PCM\
    DEFINE_WAVEFORMATEX_GUID(WAVE_FORMAT_PCM)
DEFINE_GUIDSTRUCT("00000001-0000-0010-8000-00aa00389b71", KSDATAFORMAT_SUBTYPE_PCM);
#define KSDATAFORMAT_SUBTYPE_PCM DEFINE_GUIDNAMED(KSDATAFORMAT_SUBTYPE_PCM)


#ifndef _WAVEFORMATEXTENSIBLE_
#define _WAVEFORMATEXTENSIBLE_
typedef struct {
    WAVEFORMATEX    Format;
    union {
        WORD wValidBitsPerSample;       /* bits of precision  */
        WORD wSamplesPerBlock;          /* valid if wBitsPerSample==0 */
        WORD wReserved;                 /* If neither applies, set to zero. */
    } Samples;
    DWORD           dwChannelMask;      /* which channels are */
                                        /* present in stream  */
    GUID            SubFormat;
} WAVEFORMATEXTENSIBLE, *PWAVEFORMATEXTENSIBLE;
#endif // !_WAVEFORMATEXTENSIBLE_

#if !defined(WAVE_FORMAT_EXTENSIBLE)
#define  WAVE_FORMAT_EXTENSIBLE                 0xFFFE
#endif // !defined(WAVE_FORMAT_EXTENSIBLE)

#endif

#define WM_WA_MPEG_EOF (WM_USER+2)

#define HAVE_THREAD



static UINT fmt_nch,fmt_bps,fmt_sr,fmt_mul;
static int pos_delta;

void do_cfg(bool s);

static HWAVEOUT hWo;
static char * buffer;
static UINT buf_size,block_size;
static UINT data_written;
static UINT n_blocks;
static WAVEHDR *hdr;//[N_BLOCKS];
static int n_playing;
static UINT cur_block;
static int paused;
static __int64 total_written;//in samples
static UINT buf_used;
static UINT waveout_delta,waveout_last;

void flush();

UINT cfg_buf_ms=2000;
UINT cfg_dev=0,cfg_prebuf=10;
bool cfg_volume=1,cfg_altvol=0;
static DWORD old_volume;
static DWORD last_time,pause_time;
#define GET_TIME timeGetTime()
static bool starting;

#ifdef GAPLESS

//gapless instant stop hack from out_ds2

static WNDPROC wa_proc;

static bool gaphack_stop,gaphack_can_close=1;

static LRESULT WINAPI HackProc(HWND wnd,UINT msg,WPARAM wp,LPARAM lp)
{
	if (hWo)
	{
		if (msg==WM_WA_MPEG_EOF) gaphack_stop=1;
	}
	LRESULT r=CallWindowProc(wa_proc,wnd,msg,wp,lp);
	gaphack_stop=0;
	return r;
}

static void gaphack_init()
{
	if (!wa_proc)
	{
		wa_proc=(WNDPROC)SetWindowLong(mod.hMainWindow,GWL_WNDPROC,(long)HackProc);
		char dll[MAX_PATH];
		GetModuleFileName((HMODULE)mod.hDllInstance,dll,MAX_PATH);
		LoadLibrary(dll);//increase reference count to avoid crash on WM_DESTROY - dll stays in memory until the process dies
	}
}

#endif


#ifdef HAVE_THREAD
static HANDLE hThread;
static HWND hWnd;
#define _PostMessage(a,b,c) PostMessage(hWnd,a,b,c)
#define _SendMessage(a,b,c) SendMessage(hWnd,a,b,c)
#else
#define _PostMessage(a,b,c) MsgProc(a,b,c)
#define _SendMessage(a,b,c) MsgProc(a,b,c)
#endif

#define MSG_OPEN (WM_USER+1)
#define MSG_CLOSE (WM_USER+2)
#define MSG_DATA (WM_USER+3)
//#define MSG_GETOUTTIME (WM_USER+4)
#define MSG_PAUSE (WM_USER+5)
#define MSG_SETVOL (WM_USER+6)
#define MSG_FLUSH (WM_USER+7)
#define MSG_ISPLAYING (WM_USER+8)

typedef struct
{
	UINT sr,nch,bps;
} OPEN_PARAM;


static void do_MSG_FLUSH() {waveOutPause(hWo);flush();waveOutRestart(hWo);}

static int do_MSG_PAUSE(int new_state);

static int do_MSG_OPEN(OPEN_PARAM * p,char**);

static void do_MSG_CLOSE();

static int do_MSG_DATA(char * data,int size);

//static int do_MSG_GETOUTTIME();

static void do_MSG_SETVOL();

static int do_MSG_ISPLAYING();

/*

wondering why i added all the thread shiz ?

thread-less version worked fine, *but* playback was getting messed up
whenever the thread which called first waveOutWrite() died (ask gates why),
this generally happens only while stopping so nobody could notice it,
but it would surely screw up with some rare weird input plugins,
and gapless shit wasn't possible at all.
having all waveOut calls in one our thread is the only reason for all this mess.
blah.

*/
#ifdef HAVE_THREAD
static LRESULT WINAPI WndProc(HWND wnd,UINT msg,WPARAM wp,LPARAM lp)
#else
static LRESULT MsgProc(UINT msg,WPARAM wp,LPARAM lp)
#endif
{
	switch(msg)
	{
	case MSG_OPEN:
		return do_MSG_OPEN((OPEN_PARAM*)lp,(char**)wp);
	case MSG_CLOSE:
		do_MSG_CLOSE();
		break;
	case MSG_DATA:
		return do_MSG_DATA((char*)lp,wp);
/*	case MSG_GETOUTTIME:
		return do_MSG_GETOUTTIME();*/
	case WM_DESTROY:
		do_MSG_CLOSE();
		return 0;
	case MSG_PAUSE:
		return do_MSG_PAUSE(wp);
	case MSG_SETVOL:
		do_MSG_SETVOL();
		break;
	case MSG_FLUSH:
		do_MSG_FLUSH();
		break;
#ifdef GAPLESS
	case MM_WOM_DONE:
		if (gaphack_can_close) do_MSG_CLOSE();
		break;
#endif
	case MSG_ISPLAYING:
		return do_MSG_ISPLAYING();
		break;
	}
#ifdef HAVE_THREAD
	return DefWindowProc(wnd,msg,wp,lp);
#else
	return 0;
#endif
}

#ifdef HAVE_THREAD
static DWORD WINAPI ThreadProc(void*)
{
	WNDCLASS wc=
	{
		0,WndProc,0,0,mod.hDllInstance,0,0,0,0,
#ifdef GAPLESS
			"OUT_WAVE_WND_CLASS_BLAH2"	//blah conflict :(
#else
			"OUT_WAVE_WND_CLASS_BLAH1"
#endif
	};
	char * cl=(char*)RegisterClass(&wc);
	if (!cl)
	{
		OutputDebugString("out_wave warning: unable to register window class.\n");
		return 0;
	}
	hWnd=CreateWindow(cl,0,0,0,0,0,0,/*mod.hMainWindow*/0,0,mod.hDllInstance,0);
	if (!hWnd)
	{
		OutputDebugString("out_wave warning: unable to create window.\n");
		return 0;
	}
	MSG msg;
	while(GetMessage(&msg,0,0,0)) DispatchMessage(&msg);
	DestroyWindow(hWnd);
	hWnd=0;
	return 0;
}
#endif

static void CALLBACK waveOutProc(HWAVEOUT hWo,UINT msg,DWORD poo,DWORD p1,DWORD p2)
{
	if (msg==WOM_DONE)
	{
		if (n_playing)
		{
			n_playing--;
#ifdef GAPLESS
			if (!n_playing) _PostMessage(MM_WOM_DONE,0,0);
#endif
		}
		last_time=GET_TIME;
		buf_used-=((WAVEHDR *)p1)->dwBufferLength;
	}
}


void advance_block()
{
	hdr[cur_block].dwBytesRecorded=hdr[cur_block].dwBufferLength=data_written;
	n_playing++;
	waveOutPrepareHeader(hWo,&hdr[cur_block],sizeof(WAVEHDR));
	waveOutWrite(hWo,&hdr[cur_block],sizeof(WAVEHDR));	
	cur_block=(cur_block+1)%n_blocks;
	buf_used+=data_written;
	data_written=0;	
	if (starting) {last_time=GET_TIME;starting=0;}
}


void Config(HWND);
void About(HWND p)
{
	MessageBox(p,NAME"\n(c) 2001 Peter Pawlowski\nhttp://www.blorp.com/~peter/","About",MB_ICONINFORMATION);
}

void Init()
{
}

static int inited;

void Quit()
{
	if (inited)
	{
#ifdef HAVE_THREAD
		if (hWnd) _PostMessage(WM_QUIT,0,0);
		if (hThread && hThread!=INVALID_HANDLE_VALUE) WaitForSingleObject(hThread,INFINITE);
#endif
		do_cfg(1);
	}
}

static int volume=255,pan=0;

static void do_MSG_SETVOL()
{
	if (hWo && cfg_volume && !cfg_altvol)
	{
		DWORD left,right;
		left=right=volume|(volume<<8);
		if (pan<0) right=(right*(128+pan))>>7;
		else if (pan>0) left=(left*(128-pan))>>7;		
		waveOutSetVolume(hWo,left|(right<<16));
	}
}

static UINT _buf_ms;
static DWORD _dev;

static int test_config(OPEN_PARAM * p)
{
	return hWo && fmt_sr==p->sr && fmt_bps==p->bps && fmt_nch==p->nch && _buf_ms==cfg_buf_ms && _dev==cfg_dev;
}

int get_written_time();

static int do_MSG_OPEN(OPEN_PARAM * p,char ** error)
{
	if (test_config(p))
	{
		//already open, nothing to change
		pos_delta=-get_written_time();//hack for proper time display
#ifdef GAPLESS
		gaphack_can_close=0;
#endif
		return _buf_ms;
	}
	do_MSG_CLOSE();
	_buf_ms=cfg_buf_ms;
	_dev=cfg_dev;

	fmt_sr=p->sr;
	fmt_bps=p->bps;
	fmt_nch=p->nch;
	fmt_mul=(fmt_bps>>3)*fmt_nch*fmt_sr;
	WAVEFORMATEX wfx=
	{
		WAVE_FORMAT_PCM,
		fmt_nch,
		fmt_sr,
		fmt_mul,
		fmt_nch*(fmt_bps>>3),
		fmt_bps,
		0
	};
	MMRESULT mr;
zzz:
	mr=waveOutOpen(&hWo,_dev-1,&wfx,(DWORD)waveOutProc,0,CALLBACK_FUNCTION);
	if (mr==2 && _dev) {_dev=0;goto zzz;}
	if (mr==32)	//mmsystem32
	{
		WAVEFORMATEXTENSIBLE wfxe;
		wfxe.Format=wfx;
		wfxe.Format.wFormatTag=WAVE_FORMAT_EXTENSIBLE;
		wfxe.Format.cbSize=22;
		wfxe.Samples.wReserved=0;
		wfxe.dwChannelMask=0;
		wfxe.SubFormat=KSDATAFORMAT_SUBTYPE_PCM;
		mr=waveOutOpen(&hWo,_dev-1,(WAVEFORMATEX*)&wfxe,(DWORD)waveOutProc,0,CALLBACK_FUNCTION);
	}
	if (mr)
	{
		char full_error[1024],*_fe=full_error;
		char poo[MAXERRORLENGTH];
		char * e=poo;
		if (waveOutGetErrorText(mr,poo,MAXERRORLENGTH)!=MMSYSERR_NOERROR)
		{
			e="Unknown MMSYSTEM error.";
		}
		char * e2=0;
		switch(mr)
		{
		case 32:
			wsprintf(_fe,"Unsupported PCM format (%u Hz, %u bits per sample, %u channels). Please change format settings in input plug-in configuration or change output device in waveOut plug-in configuration.",fmt_sr,fmt_bps,fmt_nch);
			while(*_fe) _fe++;
			e2="";
			break;
		case 4:
			e2="Another program is using your soundcard. Please change output device (in waveOut plug-in configuration), switch to DirectSound output (in Winamp preferences / plug-ins / output) or get a soundcard which can play multiple streams.";
			break;
		case 2:
			e2="No sound devices found. Please buy a soundcard first (or install proper drivers if you think that you have one).\nMore info can be found at http://www.geocities.com/mmsystem002/";
			break;
		case 20:
			e2="Internal driver error; please reboot your computer.";
			break;
		case 7:
			e2="Please reinstall soundcard drivers.";
			break;
		}
		if (e2)
		{
			wsprintf(_fe,"%s\n\nError code: %u\nWindows error message: \n\"%s\"",e2,mr,e);
		}
		else
		{
			wsprintf(_fe,"%s\nError code: %u",e,mr);
		}
		*error=(char*)LocalAlloc(LMEM_FIXED,strlen(full_error+1));
		strcpy(*error,full_error);
		hWo=0;
		return -1;
	}

	if (cfg_volume && !cfg_altvol) waveOutGetVolume(hWo,&old_volume);
	
	buf_size=MulDiv(_buf_ms,fmt_mul,1000);
	n_blocks=_buf_ms/100;
	if (n_blocks<8) n_blocks=8;
	hdr=(WAVEHDR*)LocalAlloc(LMEM_FIXED|LMEM_ZEROINIT,n_blocks*sizeof(WAVEHDR));
	n_playing=0;
	buf_used=0;
	{
		UINT foo=n_blocks*(fmt_bps>>3)*fmt_nch;
		buf_size+=foo-1;
		buf_size-=buf_size%foo;
	}
	buffer = (char*)LocalAlloc(LMEM_FIXED|LMEM_ZEROINIT,buf_size);


	UINT n;
	block_size=buf_size/n_blocks;
	for(n=0;n<n_blocks;n++)
	{
		hdr[n].dwBytesRecorded=hdr[n].dwBufferLength=block_size;
		hdr[n].lpData=buffer+n*block_size;
	}

	waveOutRestart(hWo);


	paused=0;
	data_written=0;
	pos_delta=0;
	total_written=0;
#ifdef GAPLESS
	gaphack_can_close=0;
#endif
	
	waveout_delta=0;waveout_last=0;
	starting=1;

	return _buf_ms;
}

void _init()
{
	if (!inited)
	{
		inited=1;
		do_cfg(0);
		if (cfg_dev>waveOutGetNumDevs()) cfg_dev=0;
	}
}

int Open(int sr, int nch, int bps, int bufferlenms, int prebufferms)
{
	_init();
#ifdef HAVE_THREAD
	if (!hWnd)
	{
		DWORD id;
		hThread=CreateThread(0,0,ThreadProc,0,0,&id);
		SetThreadPriority(hThread,THREAD_PRIORITY_TIME_CRITICAL);
		while(!hWnd) Sleep(1);
	}
#endif
#ifdef GAPLESS
	gaphack_init();
	if (!test_config((OPEN_PARAM*)&sr))
	{
		while(n_playing) Sleep(1);
	}
#endif
	char * foo=0;
	int rv=_SendMessage(MSG_OPEN,(WPARAM)&foo,(LPARAM)&sr);
	if (foo)
	{
		MessageBox(mod.hMainWindow,foo,NAME" error",MB_ICONERROR);
		LocalFree(foo);
	}	
	return rv;
}

void _inline do_altvol(void * buf,UINT size)
{
	if (volume==255) return;
	switch(fmt_bps)
	{
	case 8:
		{
			BYTE * ptr=(BYTE*)buf;
			do
			{
				*ptr=(BYTE)(0x80+(((int)(*ptr)-0x80)*volume)/255);
				ptr++;
			} while(--size);
		}		
		break;
	case 16:
		{
			short * ptr=(short*)buf;
			size>>=1;
			do
			{
				*ptr=*ptr*volume/255;
				ptr++;
			}while(--size);
		}
		break;
	case 24:
		{
			BYTE * ptr=(BYTE*)buf;
			size/=3;
			do
			{
				int val=0;
				memcpy(&val,ptr,3);
				if (val&0x800000) val|=0xFF000000;
				val=MulDiv(val,volume,255);
				memcpy(ptr,&val,3);
				ptr+=3;
			} while(--size);
		}
		break;
	case 32:
		{
			long * ptr=(long*)buf;
			size>>=2;
			do
			{
				*ptr=MulDiv(*ptr,volume,255);
				ptr++;
			} while(--size);
		}
		break;
	}
}

int Write(char *data, int size)
{
/*this can completely ignore canwrite shit now,
could add evil mode for low-latency playback with canwrite returning const bigass numbers all time (unless puased)
already experimented with that, worked nice with 60ms buffer =)
wa3 version already does that (waiting on output side)
*/
	while(1)
	{
		int d=_SendMessage(MSG_DATA,size,(LPARAM)data);
		if (d<0) return 0;
		size-=d;
		data+=d;
		if (!size) break;
		Sleep(1);
	}
	return 0;
}

static int do_MSG_DATA(char * data,int size)
{
	if (!hWo) return -1;
	if (!size)//EOF
	{
		if (data_written) advance_block();
		return 0;
	}

	{
		int cw=(n_blocks-n_playing)*block_size-data_written;
		if (cw<size) size=cw;
	}

	int rv=size;

	UINT sd;
	while(size)
	{
		sd=block_size-data_written;
		if (!sd)
		{
			advance_block();
			if (hdr[cur_block].dwFlags & WHDR_PREPARED) waveOutUnprepareHeader(hWo,&hdr[cur_block],sizeof(WAVEHDR));
			sd=block_size;
		}
		if (sd>(UINT)size) sd=size;

		memcpy(hdr[cur_block].lpData+data_written,data,sd);
		if (cfg_altvol && cfg_volume)
		{
			do_altvol(hdr[cur_block].lpData+data_written,sd);
		}
		
		size-=sd;
		data+=sd;
		data_written+=sd;
		total_written+=sd/(fmt_nch*(fmt_bps>>3));
	}
	
	return rv;
}

static void do_MSG_CLOSE()
{
	if (hWo)
	{
		waveOutPause(hWo);
		flush();
		if (cfg_volume && !cfg_altvol && old_volume>0) waveOutSetVolume(hWo,old_volume);
		waveOutClose(hWo);
		hWo=0;
		n_playing=0;
		cur_block=0;
		buf_used=0;
	}
	if (buffer) {LocalFree(buffer);buffer=0;}
	if (hdr) {LocalFree(hdr);hdr=0;}
}

void Close()
{
#ifdef GAPLESS
	gaphack_can_close=1;
	if (!gaphack_stop)
#endif
		_SendMessage(MSG_CLOSE,0,0);
}

int CanWrite()
{
	return (paused || !hWo) ? 0 : (n_blocks-n_playing)*block_size-data_written;
}

int do_MSG_ISPLAYING()
{
	if (data_written) advance_block();
#ifdef GAPLESS
	return 0;//make input plugin think that we've already finished with current stream to make Winamp advance to next file without waiting for us
#else
	return (hWo && n_playing) ? 1 : 0;
#endif
}

int IsPlaying()
{
	return _SendMessage(MSG_ISPLAYING,0,0);
}

static int do_MSG_PAUSE(int new_state)
{
	int rv=paused;
	if (hWo)
	{
		if (new_state && !paused)
		{//pause
			waveOutPause(hWo);
			pause_time=GET_TIME;
		}
		else if (paused && !new_state)
		{//unpause
			waveOutReset(hWo);
			waveOutRestart(hWo);
			last_time += GET_TIME - pause_time;
		}
	}
	paused=new_state;
	return rv;
}

int Pause(int new_state)
{
	return _SendMessage(MSG_PAUSE,new_state,0);
}


void flush()
{
	if (hWo)
	{
		waveOutReset(hWo);
		UINT n;
		for(n=0;n<n_blocks;n++)
		{
			if (hdr[n].dwFlags & WHDR_PREPARED) waveOutUnprepareHeader(hWo,&hdr[n],sizeof(WAVEHDR));
		}
		cur_block=0;
		memset(buffer,0,buf_size);
		n_playing=0;
		buf_used=0;
		waveout_delta=0;waveout_last=0;
		starting=1;
	}
}

void Flush(int pos)
{
	_SendMessage(MSG_FLUSH,0,0);
	pos_delta=pos;
	total_written=0;
}

void SetVolume(int v)
{
	if (v!=-666)
	{
		volume=v;
	}
	_SendMessage(MSG_SETVOL,0,0);
	
}

void SetPan(int p)
{
	pan=p;
	_SendMessage(MSG_SETVOL,0,0);
}

#if 1
//keep max GetWrittenTime / GetOutputTime precision, avoid messups with long playback time as long as possible
_declspec(naked) int get_written_time()
{//little cute asm hack to avoid crt references with 64bit int operations
	_asm
	{
		//(total_written*1000/sr)
		mov eax,1000
		mul dword ptr [total_written]
		//eax:edx = low(total_written)*1000
		push eax
		mov ecx,edx
		mov eax,1000
		mul dword ptr [total_written+4]
		//eax:edx = hi(total_written)*1000, we can ignore edx
		lea edx,[ecx+eax]
		pop eax
		div dword ptr [fmt_sr]
//		add eax,dword ptr [pos_delta]
		ret
	}
}

#else
int get_written_time()//this ignores high 32bits of total_written
{
	return MulDiv(total_written,1000,fmt_sr);
}
#endif

int GetWrittenTime()
{
	return hWo ? pos_delta + get_written_time() : 0;
}

/*
//avoid evil shit
//waveOutGetPosition = troublemaker

static int do_MSG_GETOUTTIME()
{
	int rv;
	if (hWo)
	{
		MMTIME t;
		t.wType=TIME_SAMPLES;
		waveOutGetPosition(hWo,&t,sizeof(t));
		UINT waveout_pos=t.u.sample;
		if (waveout_pos+0x1000<waveout_last)
		{//wrap fuckup
			UINT s=1;
			while(s<waveout_last) s<<=1;
			waveout_delta+=s;
		}
		waveout_pos+=waveout_delta;
		waveout_last=t.u.sample;		
		rv=pos_delta+MulDiv(waveout_pos,1000,fmt_sr);
		if (rv<0) rv=0;
	}
	else rv=0;
	return rv;
}
*/
int GetOutputTime()
{
	int r=0;
	if (hWo && !starting)
	{
		DWORD time = paused ? pause_time : GET_TIME;
		r = MulDiv(buf_used,1000,(fmt_bps>>3)*fmt_nch*fmt_sr) - (time - last_time);
		if (r<0) r=0;
	}
	return GetWrittenTime()-r;//_SendMessage(MSG_GETOUTTIME,0,0);
}



Out_Module mod=
{
	OUT_VER,
	NAME,
#ifdef GAPLESS
	1093212558,//gapless
#else
#ifdef WAVEOUT_NO_THREAD
	4271612621,//threadless
#else
	663200322,//normal
#endif
#endif
	0,0,
	Config,
	About,

	Init,Quit,
	Open,
	
	Close,

	Write,

	CanWrite,
	
	IsPlaying,

	Pause,

	SetVolume,
	SetPan,

	Flush,

	GetOutputTime,
	GetWrittenTime,

};


BOOL APIENTRY DllMain(HANDLE hMod,DWORD r,void*)
{
	if (r==DLL_PROCESS_ATTACH) DisableThreadLibraryCalls((HMODULE)hMod);
    return TRUE;
}

extern "C"
{
	__declspec( dllexport ) Out_Module * winampGetOutModule()
	{
		return &mod;
	}
}


void get_waveout_state(char * z)
{
	if (hWo)
	{
		wsprintf(z,"Data format: \n  %u Hz\n  %u bits per sample\n  %u channel(s)\n",fmt_sr,fmt_bps,fmt_nch);
		while(*z) z++;
		wsprintf(z,"Buffer status:\n  %u bytes allocated\n  divided into %u blocks\n  %u blocks queued\n",buf_size,n_blocks,n_playing);
		while(*z) z++;
		wsprintf(z,"Latency: %u ms\n",GetWrittenTime()-GetOutputTime());
		while(*z) z++;
		wsprintf(z,"Data written: %u KB",MulDiv((int)total_written,(fmt_bps>>3)*fmt_nch,1024));
	}
	else strcpy(z,"Not active.");
}