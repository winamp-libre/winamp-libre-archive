/*
  LICENSE
  -------
  Copyright (C) 1999-2002 Nullsoft, Inc.

  This source code is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this source code or the software it produces.

  Permission is granted to anyone to use this source code for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this source code must not be misrepresented; you must not
     claim that you wrote the original source code.  If you use this source code
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original source code.
  3. This notice may not be removed or altered from any source distribution.
*/

#ifndef __NULLSOFT_DX8_EXAMPLE_PLUGIN_SUPPORT_H__
#define __NULLSOFT_DX8_EXAMPLE_PLUGIN_SUPPORT_H__ 1

#include <d3dx8.h>

void MakeWorldMatrix( D3DXMATRIX* pOut, 
                      float xpos, float ypos, float zpos, 
                      float sx,   float sy,   float sz, 
                      float pitch, float yaw, float roll);
void MakeProjectionMatrix( D3DXMATRIX* pOut,
                           const float near_plane, // Distance to near clipping plane
                           const float far_plane,  // Distance to far clipping plane
                           const float fov_horiz,  // Horizontal field of view angle, in radians
                           const float fov_vert);   // Vertical field of view angle, in radians
void PrepareFor3DDrawing(
        IDirect3DDevice8 *pDevice, 
        int viewport_width,
        int viewport_height,
        float fov_in_degrees, 
        float near_clip,
        float far_clip,
        D3DXVECTOR3* pvEye,
        D3DXVECTOR3* pvLookat,
        D3DXVECTOR3* pvUp
    );
void PrepareFor2DDrawing(IDirect3DDevice8 *pDevice);

// Define vertex formats you'll be using here:
typedef struct _MYVERTEX 
{
    float x, y;      // screen position    
    float z;         // Z-buffer depth    
    DWORD Diffuse;   // diffuse color    
    float tu1, tv1;  // texture coordinates for texture #0
    float tu2, tv2;  // texture coordinates for texture #1
        // note: even though tu2/tv2 aren't used when multitexturing is off,
        // they are still useful for padding the structure to 32 bytes,
        // which is good for random (indexed) access.
} MYVERTEX, *LPMYVERTEX; 

typedef struct _WFVERTEX 
{
    float x, y, z;
    DWORD Diffuse;   // diffuse color. also acts as filler; aligns struct to 16 bytes (good for random access/indexed prims)
} WFVERTEX, *LPWFVERTEX; 

typedef struct _SPRITEVERTEX 
{
    float x, y;      // screen position    
    float z;         // Z-buffer depth    
    DWORD Diffuse;   // diffuse color. also acts as filler; aligns struct to 16 bytes (good for random access/indexed prims)
    float tu, tv;    // texture coordinates for texture #0
} SPRITEVERTEX, *LPSPRITEVERTEX; 

// Also prepare vertex format descriptors for each 
//   of the 3 kinds of vertices we'll be using:
#define MYVERTEX_FORMAT     (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX2)
#define WFVERTEX_FORMAT     (D3DFVF_XYZ | D3DFVF_DIFFUSE              )
#define SPRITEVERTEX_FORMAT (D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1)

void    GetWinampSongTitle(HWND hWndWinamp, char *szSongTitle, int nSize);
void    GetWinampSongPosAsText(HWND hWndWinamp, char *szSongPos);
void    GetWinampSongLenAsText(HWND hWndWinamp, char *szSongLen);
float   GetWinampSongPos(HWND hWndWinamp);      // returns answer in seconds
float   GetWinampSongLen(HWND hWndWinamp);      // returns answer in seconds


#endif
