/*
  LICENSE
  -------
  Copyright (C) 1999-2002 Nullsoft, Inc.

  This source code is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this source code or the software it produces.

  Permission is granted to anyone to use this source code for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this source code must not be misrepresented; you must not
     claim that you wrote the original source code.  If you use this source code
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original source code.
  3. This notice may not be removed or altered from any source distribution.
*/

#ifndef __NULLSOFT_DX8_PLUGIN_SHELL_SHELL_DEFINES_H__
#define __NULLSOFT_DX8_PLUGIN_SHELL_SHELL_DEFINES_H__ 1

#include <windows.h>

#define DEFAULT_FULLSCREEN_WIDTH  640
#define DEFAULT_FULLSCREEN_HEIGHT 480
#define MAX_ICON_TEXTURES 8
#define ICON_TEXTURE_SIZE 256
#define DEFAULT_WINDOW_SIZE 0.625f      // as a portion of the width or height of the screen (whichever is smaller)
#define DESKTOP_MODE_KEYBOARD_INPUT_WINDOW_CLASSNAME "DESKTOP MODE KEYBOARD INPUT WINDOW"
#define BGR2RGB(x) (((x>>16)&0xFF) | (x & 0xFF00) | ((x<<16)&0xFF0000))

#define NUM_BASIC_FONTS 4 
#define  SYS_FONT 0
#define  DEC_FONT 1
#define  HELP_FONT 2
#define  DESK_FONT 3
#define MAX_EXTRA_FONTS 5
typedef enum
{
    SIMPLE_FONT = 0,  // aka 'system' font; should be legible
    DECORATIVE_FONT = 1,
    HELPSCREEN_FONT = 2,
    PLAYLIST_FONT = 3,
    EXTRA_1 = 4, 
    EXTRA_2 = 5,
    EXTRA_3 = 6,
    EXTRA_4 = 7,
    EXTRA_5 = 8
} 
eFontIndex;

// for m_screenmode:
typedef enum
{
    NOT_YET_KNOWN   = -1,
    FULLSCREEN      =  0,
    WINDOWED        =  1,
    FAKE_FULLSCREEN =  2,
    DESKTOP         =  3       // doesn't use overlays! =)
} 
eScrMode;

// embedding stuff
#define WM_WA_IPC WM_USER
#define IPC_GET_EMBEDIF 505 // pass an embedWindowState; returns an HWND embedWindow(embedWindowState *); if the data is NULL, otherwise returns the HWND directly
#define EMBED_FLAGS_NORESIZE 1 // set this bit in embedWindowState.flags to keep window from being resizable
typedef struct
{
  HWND me; //hwnd of the window
  int flags;
  RECT r;
  void *user_ptr; // for application use
  int extra_data[64]; // for internal winamp use
} 
embedWindowState;








#endif