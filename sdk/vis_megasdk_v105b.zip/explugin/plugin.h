/*
  LICENSE
  -------
  Copyright (C) 1999-2002 Nullsoft, Inc.

  This source code is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this source code or the software it produces.

  Permission is granted to anyone to use this source code for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this source code must not be misrepresented; you must not
     claim that you wrote the original source code.  If you use this source code
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original source code.
  3. This notice may not be removed or altered from any source distribution.
*/

#ifndef __NULLSOFT_DX8_EXAMPLE_PLUGIN_H__
#define __NULLSOFT_DX8_EXAMPLE_PLUGIN_H__ 1

#include "pluginshell.h"

class CPlugin : public CPluginShell
{
protected:
    
    //====[ 1. members added to create this specific example plugin: ]================================================

        // CONFIG PANEL SETTINGS THAT WE'VE ADDED (TAB #2)
        int   m_fog_enabled;
        int   m_initial_wave_mode;
        int   m_anim_speed_setting;

        // RUNTIME SETTINGS THAT WE'VE ADDED
        int   m_show_song;
        int   m_show_time;
        int   m_show_fps;
        int   m_textures;
        int   m_draw_flat;
        int   m_draw_wire;
        int   m_wave_mode;
        float m_cube_size;
        float m_anim_time;
        float m_prev_time;
        float m_cube_rotation_offset;
        float m_cube_position_offset;

        // OUR TEXTURE DATA
        IDirect3DTexture8 *m_object_tex;    

        // OUR GEOMETRY DATA
        IDirect3DVertexBuffer8 *m_object_vertex_buf;
        IDirect3DIndexBuffer8  *m_object_index_buf;

        // OUR CUSTOM SOUND ANALYSIS DATA
        int   m_is_beat;
        int   m_has_fallen;
        float m_thresh;
        float m_limit;
        float m_last_hit;
        float m_oldspec[2][NUM_FREQUENCIES];

    //====[ 2. methods added: ]=====================================================================================

        void Render3D();
        void RenderBands();
        void Render2DWave();
        void Render2DSpectraSimple(int bEvenPitch, int bBoxes, int bMirror);
        void Render2DSpectraFancy(int blending_window_span, int radial_solid, float amplitude);
        void DoAudioAnalysis();

    //====[ 3. virtual functions: ]===========================================================================

        virtual void OverrideDefaults();
        virtual void MyPreInitialize();
        virtual void MyReadConfig();
        virtual void MyWriteConfig();
        virtual int  AllocateMyNonDx8Stuff();
        virtual void  CleanUpMyNonDx8Stuff();
        virtual int  AllocateMyDX8Stuff();
        virtual void  CleanUpMyDX8Stuff(int final_cleanup);
        virtual void MyRenderFn(int redraw);
        virtual void MyRenderUI(int *upper_left_corner_y, int *upper_right_corner_y, int *lower_left_corner_y, int *lower_right_corner_y, int xL, int xR);
        virtual LRESULT MyWindowProc(HWND hWnd, unsigned uMsg, WPARAM wParam, LPARAM lParam);
        virtual BOOL    MyConfigTabProc(int nPage, HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam);

    //====[ 4. methods from base class: ]===========================================================================
    /*
        // 'GET' METHODS
        // ------------------------------------------------------------
        int       GetFrame();          // returns current frame # (starts at zero)
        float     GetTime();           // returns current animation time (in seconds) (starts at zero) (updated once per frame)
        float     GetFps();            // returns current estimate of framerate (frames per second)
        eScrMode  GetScreenMode();     // returns WINDOWED, FULLSCREEN, FAKE_FULLSCREEN, DESKTOP, or NOT_YET_KNOWN (if called before or during OverrideDefaults()).
        HWND      GetWinampWindow();   // returns handle to Winamp main window
        HINSTANCE GetInstance();       // returns handle to the plugin DLL module; used for things like loading resources (dialogs, bitmaps, icons...) that are built into the plugin.
        char*     GetPluginsDirPath(); // usually returns 'c:\\program files\\winamp\\plugins\\'
        char*     GetConfigIniFile();  // usually returns 'c:\\program files\\winamp\\plugins\\something.ini' - filename is determined from identifiers in 'defines.h'

        // GET METHODS THAT ONLY WORK ONCE DIRECTX IS READY
        // ------------------------------------------------------------
        //  The following 'Get' methods are only available after DirectX has been initialized.
        //  If you call these from OverrideDefaults, MyPreInitialize, or MyReadConfig, 
        //    they will fail and return NULL (zero).
        // ------------------------------------------------------------
        HWND         GetPluginWindow();      // returns handle to the plugin window.  NOT persistent; can change!  
        int          GetWidth();             // returns width of plugin window interior, in pixels.
        int          GetHeight();            // returns height of plugin window interior, in pixels.
        int          GetBitDepth();          // returns 8, 16, 24 (rare), or 32
        LPDIRECT3DDEVICE8  GetDevice();      // returns a pointer to the DirectX 8 Device.  NOT persistent; can change!
        D3DCAPS8*    GetCaps();              // returns a pointer to the D3DCAPS8 structer for the device.  NOT persistent; can change.
        D3DFORMAT    GetBackBufFormat();     // returns the pixelformat of the back buffer (probably D3DFMT_R8G8B8, D3DFMT_A8R8G8B8, D3DFMT_X8R8G8B8, D3DFMT_R5G6B5, D3DFMT_X1R5G5B5, D3DFMT_A1R5G5B5, D3DFMT_A4R4G4B4, D3DFMT_R3G3B2, D3DFMT_A8R3G3B2, D3DFMT_X4R4G4B4, or D3DFMT_UNKNOWN)
        D3DFORMAT    GetBackBufZFormat();    // returns the pixelformat of the back buffer's Z buffer (probably D3DFMT_D16_LOCKABLE, D3DFMT_D32, D3DFMT_D15S1, D3DFMT_D24S8, D3DFMT_D16, D3DFMT_D24X8, D3DFMT_D24X4S4, or D3DFMT_UNKNOWN)
        char*        GetDriverFilename();    // returns a text string with the filename of the current display adapter driver, such as "nv4_disp.dll"
        char*        GetDriverDescription(); // returns a text string describing the current display adapter, such as "NVIDIA GeForce4 Ti 4200"

        // FONTS & TEXT
        // ------------------------------------------------------------
        LPD3DXFONT   GetFont(eFontIndex idx);       // returns a D3DX font handle for drawing text; see shell_defines.h for the definition of the 'eFontIndex' enum.
        int          GetFontHeight(eFontIndex idx); // returns the height of the font, in pixels; see shell_defines.h for the definition of the 'eFontIndex' enum.

        // MISC
        // ------------------------------------------------------------
        td_soundinfo m_sound;                   // a structure always containing the most recent sound analysis information; defined in pluginshell.h.
        void         SuggestHowToFreeSomeMem(); // gives the user a 'smart' messagebox that suggests how they can free up some video memory.
    */
    //=====================================================================================================================

};





#endif