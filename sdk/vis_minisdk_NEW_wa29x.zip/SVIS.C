// Winamp test visualization library v1.0
// Copyright (C) 1997, Justin Frankel/Nullsoft
// Feel free to base any plugins on this "framework"...
// Updated by Saivert to show the basics of the new
// General Purpose Plugin Window system.
// Homepage -> http://members.tripod.com/files_saivert/
// E-Mail -> saivert@email.com

#include "c:\vcproj\AggressiveOptimize.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <math.h>
#include "vis.h"
#include "resource.h"

#include "wa_ipc.h"

#define WA_DLG_IMPLEMENT
#include "wa_dlg.h"

// makes a smaller DLL file
BOOL WINAPI _DllMainCRTStartup(HINSTANCE hModule, DWORD ul_reason_for_call, 
							   LPVOID lpReserved){return 1;}


// Define VIS_SHOWFPS if you wish to display framerate counter
//  #define VIS_SHOWFPS 1

winampVisModule* g_currentmod;

/*
** Two variables used to support the new
** General Purpose Plugin Window system.
** ispainting is TRUE when any of the render
** functions below is executed.
** ews is a pointer to an embedWindowState struct.
** This is dynamically allocated later.
*/
BOOL ispainting;
embedWindowState *ews;
HWND (*embedWindow)(embedWindowState *);

HWND g_hWinamp;
HWND g_hAboutDlg=0;

char szAppName[] = "SimpleVis"; // Our window class, etc

// configuration declarations
int config_x=50, config_y=50;	// screen X position and Y position, repsectively
int config_w=0, config_h=0;
void config_read(struct winampVisModule *this_mod);		// reads the configuration
void config_write(struct winampVisModule *this_mod);	// writes the configuration
void config_getinifn(struct winampVisModule *this_mod, char *ini_file); // makes the .ini file filename


// returns a winampVisModule when requested. Used in hdr, below
winampVisModule *getModule(int which);

// "member" functions
void config(struct winampVisModule *this_mod); // configuration dialog
int init(struct winampVisModule *this_mod);	   // initialization for module
int render1(struct winampVisModule *this_mod);  // rendering for module 1
int render2(struct winampVisModule *this_mod);  // rendering for module 2
int render3(struct winampVisModule *this_mod);  // rendering for module 3
void quit(struct winampVisModule *this_mod);   // deinitialization for module

// our window procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
// About Dialog Procedure
BOOL CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK PrefsDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
HWND hMainWnd; // main window handle

// Double buffering data
HDC memDC;		// memory device context
HBITMAP	memBM,  // memory bitmap (for memDC)
		oldBM;  // old bitmap (from memDC)


// Module header, includes version, description, and address of the module retriever function
winampVisHeader hdr = { VIS_HDRVER, "Nullsoft Test Visualization Library v1.0", getModule };

// first module (oscilliscope)
winampVisModule mod1 =
{
	"Oscilliscope",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	0,		// sRate
	0,		// nCh
	25,		// latencyMS
	25,		// delayMS
	0,		// spectrumNch
	2,		// waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config,
	init,
	render1, 
	quit
};

// second module (spectrum analyser)
winampVisModule mod2 =
{
	"Spectrum Analyser",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	0,		// sRate
	0,		// nCh
	25,		// latencyMS
	25,		// delayMS
	2,		// spectrumNch
	0,		// waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config,
	init,
	render2, 
	quit
};

// third module (VU meter)
winampVisModule mod3 =
{
	"VU Meter",
	NULL,	// hwndParent
	NULL,	// hDllInstance
	0,		// sRate
	0,		// nCh
	25,		// latencyMS
	25,		// delayMS
	0,		// spectrumNch
	2,		// waveformNch
	{ 0, },	// spectrumData
	{ 0, },	// waveformData
	config,
	init,
	render3, 
	quit
};


// this is the only exported symbol. returns our main header.
// if you are compiling C++, the extern "C" { is necessary, so we just #ifdef it
#ifdef __cplusplus
extern "C" {
#endif
__declspec( dllexport ) winampVisHeader *winampVisGetHeader()
{
	return &hdr;
}
#ifdef __cplusplus
}
#endif

// getmodule routine from the main header. Returns NULL if an invalid module was requested,
// otherwise returns either mod1, mod2 or mod3 depending on 'which'.
winampVisModule *getModule(int which)
{
	switch (which)
	{
		case 0: return &mod1;
		case 1: return &mod2;
		case 2: return &mod3;
		default: return NULL;
	}
}

// configuration. Passed this_mod, as a "this" parameter. Allows you to make one configuration
// function that shares code for all your modules (you don't HAVE to use it though, you can make
// config1(), config2(), etc...)
void config(struct winampVisModule *this_mod)
{
	HWND (*embedWindow)(embedWindowState *); // embedWindow function pointer
	RECT pr;
	MSG msg;
	embedWindowState* ews;

	if (g_hAboutDlg)
	{
		SetForegroundWindow(GetParent(g_hAboutDlg));
		return;
	}

	g_hWinamp = this_mod->hwndParent;

	*(void **)&embedWindow=(void*)SendMessage(this_mod->hwndParent,WM_WA_IPC,0,505);
// Allocate an embedWindowState struct.
	ews = (embedWindowState*) GlobalAlloc(GPTR, sizeof(embedWindowState));

// Set up the embedWindowStruct
	ews->flags = 1; // no resize
	GetWindowRect(GetForegroundWindow(), &pr);
	ews->r.top = pr.top;
	ews->r.left = pr.left;
	ews->r.right = pr.left + 320;
	ews->r.bottom = pr.top + 200;
	
// Call the embedWindow function to retrieve a new General Window
	embedWindow(ews);
	SetWindowText(ews->me, (LPCTSTR) "About");
	WADlg_init(this_mod->hwndParent);	

	g_hAboutDlg = CreateDialog(this_mod->hDllInstance, MAKEINTRESOURCE(IDD_ABOUTDLG), ews->me, AboutDlgProc);

	SendMessage(this_mod->hwndParent, WM_WA_IPC, 0xdeadbeef, IPC_ENABLEDISABLE_ALL_WINDOWS);
	ShowWindow(g_hAboutDlg, SW_SHOW);
	ShowWindow(ews->me, SW_SHOW);

	while (GetMessage(&msg, 0, 0, 0))
	{
		if (!IsDialogMessage(msg.hwnd, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	DestroyWindow(g_hAboutDlg);
	g_hAboutDlg = 0;
	SendMessage(this_mod->hwndParent, WM_WA_IPC, 0, IPC_ENABLEDISABLE_ALL_WINDOWS);
	DestroyWindow(ews->me);
	GlobalFree((HGLOBAL)ews);
	WADlg_close();
}


// initialization. Registers our window class, creates our window, etc. Again, this one works for
// both modules, but you could make init1() and init2()...
// returns 0 on success, 1 on failure.
int init(struct winampVisModule *this_mod)
{
	HWND (*embedWindow)(embedWindowState *); // embedWindow function pointer
	WNDCLASS wc;

	int width = (this_mod == &mod3)?256:576; // width and height are the same for mod1 and mod2,
	int height = (this_mod == &mod3)?83:256; // but mod3 is shaped differently

	g_hWinamp = this_mod->hwndParent;
	g_currentmod = this_mod;


/* Get the pointer to the embedWindow function.
** Calls SendMessage with IPC_GETEMBEDIF Winamp message.
*/
	*(void **)&embedWindow=(void*)SendMessage(this_mod->hwndParent,WM_WA_IPC,0,505);


	config_read(this_mod);
	if (config_w > 0) width = config_w;
	if (config_h > 0) height = config_h;

	{	// Register our window class
		memset(&wc,0,sizeof(wc));
		wc.lpfnWndProc = WndProc;				// our window procedure
		wc.hInstance = this_mod->hDllInstance;	// hInstance of DLL
		wc.lpszClassName = szAppName;			// our window class name
	
		if (!RegisterClass(&wc)) 
		{
			MessageBox(this_mod->hwndParent,"Error registering window class",this_mod->description,MB_OK);
			return 1;
		}
	}


// Allocate an embedWindowState struct.
	ews = (embedWindowState*) GlobalAlloc(GPTR, sizeof(embedWindowState));

// Set up the embedWindowStruct
	ews->flags = 0; // 0 = window is resizable; 1 = window can't be resized by user
	ews->r.top = config_y;
	ews->r.left = config_x;
	ews->r.right = config_x+width+20;
	ews->r.bottom = config_y+height+28;
	
// Call the embedWindow function to retrieve a new General Window
	embedWindow(ews);

// Create our own render window (will become child of the new General Window)
	hMainWnd = CreateWindowEx(0, szAppName, NULL, WS_CHILD|WS_VISIBLE,
		0,0, width,height,
		ews->me,
		NULL,// no menu/control id
		this_mod->hDllInstance,// hInstance of DLL
		0); // no window creation data

	if (!hMainWnd) 
	{
		MessageBox(this_mod->hwndParent,"Error creating window",this_mod->description,MB_OK);
		return 1;
	}

	SetWindowLong(hMainWnd, GWL_USERDATA, (LONG) this_mod);

	// create our doublebuffer
	memDC = CreateCompatibleDC(NULL);
	memBM = CreateCompatibleBitmap(GetDC(hMainWnd),width,height);
	oldBM = SelectObject(memDC,memBM);
	SelectObject(memDC, (HGDIOBJ) CreatePen(PS_SOLID, 0, RGB(0,196,0)));
	
	// show the window
	SetWindowText(ews->me, this_mod->description);
	ShowWindow(ews->me, SW_SHOW);

	return 0;
}

unsigned char prevVisData[2][576];

// render function for oscilliscope. Returns 0 if successful, 1 if visualization should end.
int render1(struct winampVisModule *this_mod)
{
	int x, y;
	RECT cr;
#ifdef VIS_SHOWFPS
	char string[256];
#endif
	DWORD thistick = GetTickCount();
	
	ispainting = TRUE;
	GetClientRect(hMainWnd, &cr);
	{
		HPEN oldPen;

		oldPen = (HPEN) SelectObject(memDC, GetStockObject(BLACK_PEN));

		// remove previous frame
		for (y = 0; y < this_mod->nCh; y ++)
		{
			MoveToEx(memDC,0,(y*256)>>(this_mod->nCh-1),NULL);
			for (x = 0; x < 576; x ++)
			{
				LineTo(memDC,x,(y*256 + prevVisData[y][x]^128)>>(this_mod->nCh-1));
			}
		}
		
		SelectObject(memDC, oldPen);
	}
	memcpy(prevVisData, this_mod->waveformData, sizeof(prevVisData));
		
	// draw oscilliscope
	for (y = 0; y < this_mod->nCh; y ++)
	{
		MoveToEx(memDC,0,(y*256)>>(this_mod->nCh-1),NULL);
		for (x = 0; x < 576; x ++)
		{
			LineTo(memDC,x,(y*256 + this_mod->waveformData[y][x]^128)>>(this_mod->nCh-1));
		}
	}
	this_mod->latencyMs = (GetTickCount() - thistick);
#ifdef VIS_SHOWFPS
	SetTextColor(memDC, 0x00FFCEFF);
	SetBkMode(memDC, TRANSPARENT);
	wsprintf(string, "[%d fps]", 1000/(this_mod->latencyMs>0?this_mod->latencyMs:1));
	TextOut(memDC, 0, 0, string, lstrlen(string));
#endif
	{ // copy doublebuffer to window
		HDC hdc = GetDC(hMainWnd);
		//StretchBlt(hdc,0,0,cr.right,cr.bottom,memDC,0,0,256,576,SRCCOPY);
		BitBlt(hdc,0,0,cr.right,cr.bottom,memDC,0,0,SRCCOPY);
		ReleaseDC(hMainWnd,hdc);
	}
	ispainting = FALSE;
	return 0;
}

// render function for analyser. Returns 0 if successful, 1 if visualization should end.
int render2(struct winampVisModule *this_mod)
{
	int x, y;
	RECT cr;
#ifdef VIS_SHOWFPS
	char string[256];
#endif
	DWORD thistick = GetTickCount();
	ispainting = TRUE;
	GetClientRect(hMainWnd, &cr);
	{
		HPEN oldPen;

		oldPen = (HPEN) SelectObject(memDC, GetStockObject(BLACK_PEN));

		// remove previous frame
		for (y = 0; y < this_mod->nCh; y ++)
		{
			for (x = 0; x < 576; x ++)
			{
				MoveToEx(memDC,x,(y*256+256)>>(this_mod->nCh-1),NULL);
				LineTo(memDC,x,(y*256 + 256 - prevVisData[y][x])>>(this_mod->nCh-1));
			}
		}
		
		SelectObject(memDC, oldPen);
	}
	memcpy(prevVisData, this_mod->spectrumData, sizeof(prevVisData));
	
	// draw analyser
	for (y = 0; y < this_mod->nCh; y ++)
	{
		for (x = 0; x < 576; x ++)
		{
			MoveToEx(memDC,x,(y*256+256)>>(this_mod->nCh-1),NULL);
			LineTo(memDC,x,(y*256 + 256 - this_mod->spectrumData[y][x])>>(this_mod->nCh-1));
		}
	}
	this_mod->latencyMs = (GetTickCount() - thistick);
#ifdef VIS_SHOWFPS
	SetTextColor(memDC, 0x00FFCEFF);
	SetBkMode(memDC, TRANSPARENT);
	wsprintf(string, "[%d fps]", 1000/(this_mod->latencyMs>0?this_mod->latencyMs:1));
	TextOut(memDC, 0, 0, string, lstrlen(string));
#endif
	{ // copy doublebuffer to window
		HDC hdc = GetDC(hMainWnd);
		BitBlt(hdc,0,0,cr.right,cr.bottom,memDC,0,0,SRCCOPY);
		ReleaseDC(hMainWnd,hdc);
	}
	ispainting = FALSE;
	return 0;
}

// render function for VU meter. Returns 0 if successful, 1 if visualization should end.
int render3(struct winampVisModule *this_mod)
{
	int x, y;
	RECT cr;
	int vert;
#ifdef VIS_SHOWFPS
	char string[256];
#endif
	DWORD thistick = GetTickCount();
	HBRUSH oldBrush, gbr;
	ispainting = TRUE;
	GetClientRect(hMainWnd, &cr);
	oldBrush = (HBRUSH)SelectObject(memDC, GetStockObject(BLACK_BRUSH));
	Rectangle(memDC, cr.left, cr.top, cr.right, cr.bottom);
	vert = ((cr.right-cr.left) < (cr.bottom-cr.top));
	if (!vert) {
		MoveToEx(memDC, 0, cr.bottom / 2, NULL);
		LineTo(memDC, cr.right, cr.bottom / 2);
	} else {
		MoveToEx(memDC, cr.right / 2, 0, NULL);
		LineTo(memDC, cr.right / 2, cr.bottom);
	}
	gbr = CreateSolidBrush(0x000000FF);
	SelectObject(memDC, gbr);
	// draw VU meter
	for (y = 0; y < 2; y ++)
	{
		int last=this_mod->waveformData[y][0];
		int total=0;
		for (x = 1; x < 576; x ++)
		{
			total += abs(last - this_mod->waveformData[y][x]);
			last = this_mod->waveformData[y][x];
		}

		total /= 288;
		if (!vert) {
			if (total > (cr.right-cr.left)) total = (cr.right-cr.left);
		} else {
			if (total > (cr.bottom-cr.top)) total = (cr.bottom-cr.top);
		}

		if (y) {
			if (!vert)
				Rectangle(memDC, 0, 0, total, cr.bottom / 2);
			else
				Rectangle(memDC, 0, (cr.bottom-total), cr.right / 2, cr.bottom);
		} else {
			if (!vert)
				Rectangle(memDC, 0, cr.bottom / 2, total, cr.bottom);
			else
				Rectangle(memDC, cr.right / 2, (cr.bottom-total), cr.right, cr.bottom);
		}
	}
	this_mod->latencyMs = (GetTickCount() - thistick);
#ifdef VIS_SHOWFPS
	SetTextColor(memDC, 0x00FFCEFF);
	SetBkMode(memDC, TRANSPARENT);
	wsprintf(string, "[%d fps]", 1000/(this_mod->latencyMs>0?this_mod->latencyMs:1));
	TextOut(memDC, 0, 0, string, lstrlen(string));
#endif
	{ // copy doublebuffer to window
		HDC hdc = GetDC(hMainWnd);
		BitBlt(hdc,0,0,cr.right,cr.bottom,memDC,0,0,SRCCOPY);
		ReleaseDC(hMainWnd,hdc);
	}
	SelectObject(memDC, oldBrush);
	DeleteObject(gbr);
	ispainting = FALSE;
	return 0;
}

// cleanup (opposite of init()). Destroys the window, unregisters the window class
void quit(struct winampVisModule *this_mod)
{
	RECT r;
	GetWindowRect(ews->me,&r);
	config_x = r.left;
	config_y = r.top;
	config_w = (r.right-r.left);
	config_h = (r.bottom-r.top);
	config_write(this_mod);		// write configuration
	SelectObject(memDC,oldBM);	// delete our doublebuffer
	DeleteObject(memDC);
	DeleteObject(memBM);	
	DestroyWindow(hMainWnd); // delete our window
	DestroyWindow(ews->me);
	UnregisterClass(szAppName,this_mod->hDllInstance); // unregister window class
	GlobalFree((HGLOBAL)ews);
}


// window procedure for our window
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_CREATE:		return 0;
		case WM_ERASEBKGND: return 0;
		case WM_PAINT:
			{ // update from doublebuffer
				PAINTSTRUCT ps;
				RECT r;
				HDC hdc = BeginPaint(hwnd,&ps);
				GetClientRect(hwnd,&r);
				BitBlt(hdc,0,0,r.right,r.bottom,memDC,0,0,SRCCOPY);
				EndPaint(hwnd,&ps);
				return 0;
			}
		case WM_DESTROY: PostQuitMessage(0); return 0;
		case WM_KEYDOWN: // pass keyboard messages to main winamp window (for processing)
		case WM_KEYUP:
			{	// get this_mod from our window's user data
				winampVisModule *this_mod = (winampVisModule *) GetWindowLong(hwnd,GWL_USERDATA);
				PostMessage(this_mod->hwndParent,message,wParam,lParam);
				return 0;
			}
		case WM_SIZE:
			{	// update size
				if (!ispainting)
				{
					RECT r;
					GetClientRect(hMainWnd,&r);
					DeleteObject(memBM);
					memBM = CreateCompatibleBitmap(GetDC(hMainWnd),r.right,r.bottom);
					SelectObject(memDC,memBM);
				}
			}
		case WM_RBUTTONUP: PostMessage(ews->me,message,wParam,lParam);
		return 0;
	}	
	return DefWindowProc(hwnd,message,wParam,lParam);
}

BOOL CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static char* url = "http://members.tripod.com/files_saivert/";

	switch (uMsg)
	{
	case WM_DISPLAYCHANGE:
		WADlg_init(g_hWinamp);
		break;
	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_CLOSEBTN)	PostQuitMessage(0);
		if (LOWORD(wParam) == IDC_URLBTN)
			ShellExecute(hDlg, "open", url,
			NULL, NULL, SW_SHOWNORMAL);
		break;
	case WM_CLOSE: PostQuitMessage(0); break;
	case WM_PAINT:
	{
		int tab[] = { IDC_HPEDIT|DCW_SUNKENBORDER};
		WADlg_DrawChildWindowBorders(hDlg,tab,1);
	} break;
	case WM_DRAWITEM:
		{
			DRAWITEMSTRUCT *di = (DRAWITEMSTRUCT *)lParam;
			if (di->CtlType != ODT_BUTTON) break;
			if (di->CtlID == IDC_URLBTN)
			{
				char ctxt[512];
				HFONT hf, oldfont;
				RECT tr;
				GetDlgItemText(hDlg, di->CtlID, ctxt, sizeof(ctxt));
				GetClientRect(GetDlgItem(hDlg, di->CtlID), &tr);
				FillRect(di->hDC, &tr, CreateSolidBrush(WADlg_getColor(WADLG_WNDBG)));
				if ((di->itemState & ODS_SELECTED) > 0)
					SetTextColor(di->hDC, WADlg_getColor(WADLG_WNDFG));
				else if ((di->itemState & ODS_FOCUS) > 0)
					SetTextColor(di->hDC, WADlg_getColor(WADLG_HILITE));
				else
					SetTextColor(di->hDC, WADlg_getColor(WADLG_ITEMFG));
				hf = CreateFont(-11,0,0,0,FW_NORMAL,0,TRUE,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,
					CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,NULL);
				oldfont = SelectObject(di->hDC, hf);
				SetBkMode(di->hDC, TRANSPARENT);
				DrawText(di->hDC, ctxt, strlen(ctxt), &tr, DT_CENTER | DT_SINGLELINE);
				SelectObject(di->hDC, oldfont);
				DeleteObject(hf);
				break;
			}
		}
	default:
	{
		BOOL a=WADlg_handleDialogMsgs(hDlg,uMsg,wParam,lParam);
		SetWindowLong(hDlg, DWL_MSGRESULT, a);
		if (a) return a;
	}

	}

	return FALSE;
}


#define FVERTSIZE 100
#define FHORZSIZE 100

void config_getinifn(struct winampVisModule *this_mod, char *ini_file)
{	// makes a .ini file in the winamp directory named "plugin.ini"
	char *p;
	GetModuleFileName(this_mod->hDllInstance,ini_file,MAX_PATH);
	p=ini_file+strlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	strcat(ini_file,"plugin.ini");
}


void config_read(struct winampVisModule *this_mod)
{
	char ini_file[MAX_PATH];
	config_getinifn(this_mod,ini_file);
	config_x = GetPrivateProfileInt(this_mod->description,"Screen_x",config_x,ini_file);
	config_y = GetPrivateProfileInt(this_mod->description,"Screen_y",config_y,ini_file);
	//Size
	config_w = GetPrivateProfileInt(this_mod->description,"Screen_w",config_w,ini_file);
	config_h = GetPrivateProfileInt(this_mod->description,"Screen_h",config_h,ini_file);

}

void config_write(struct winampVisModule *this_mod)
{
	char string[32];
	char ini_file[MAX_PATH];

	config_getinifn(this_mod,ini_file);

	wsprintf(string,"%d",config_x);
	WritePrivateProfileString(this_mod->description,"Screen_x",string,ini_file);
	wsprintf(string,"%d",config_y);
	WritePrivateProfileString(this_mod->description,"Screen_y",string,ini_file);

	//Size
	wsprintf(string,"%d",config_w);
	WritePrivateProfileString(this_mod->description,"Screen_w",string,ini_file);
	wsprintf(string,"%d",config_h);
	WritePrivateProfileString(this_mod->description,"Screen_h",string,ini_file);

}
