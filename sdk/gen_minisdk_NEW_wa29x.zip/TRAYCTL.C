/* Winamp general purpose plug-in mini-SDK
 * Copyright (C) 1997, Justin Frankel/Nullsoft
 *
 * Rewritten by Saivert to show how to use the
 * new Winamp v2.9x API
 *
 * The first thing it does is to put a new page in the
 * Winamp's preferences dialog. Second, it shows how
 * to modify the behaviour of the ligtning bolt
 * (Winamp icon) tray icon when clicked on.
 * It will if enabled in the prefs, pause/resume the
 * song depending on it's state (toggles between this).
 * To pop up Winamp (it's previous behaviour) you
 * must now double-click (last one does not work with Agent icon).
 *
 * All in all it's the same old gen_tray plugin SDK
 * sample with a few new bits and bolts..
 */

#include <windows.h>
#include <commctrl.h>

#include "wa_ipc.h"

#include "gen.h"
#include "resource.h"

#define ENABLE_PREV 1
#define ENABLE_PLAY 2
#define ENABLE_STOP 4
#define ENABLE_NEXT 8
#define ENABLE_EJECT 16
// new, added
#define ENABLE_TRAYMOD 32
int config_enabled=0;

HICON Icons[5];
char *tips[5] = {
	"Previous Track - Winamp",
	"Play/Pause - Winamp",
	"Stop - Winamp",
	"Next Track - Winamp",
	"Open File - Winamp"
};

// from systray.c
extern BOOL systray_add(HWND hwnd, UINT uID, HICON hIcon, LPSTR lpszTip);
extern BOOL systray_del(HWND hwnd, UINT uID);

BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam, LPARAM lParam);
void config(void);
void quit(void);
int init(void);
void config_write(void);
void config_read(void);
char szAppName[] = "Nullsoft Tray Control";



winampGeneralPurposePlugin plugin =
{
	GPPHDR_VER,
	"",
	init,
	config,
	quit,
};

prefsDlgRec prefsrec =
{
	0,
	IDD_DIALOG1,
	ConfigProc,
	"Tray Control",
	0,
};

void do_icons(void)
{
	static int l=0;
	int i;
	if (l == config_enabled) return;
	for (i = 4; i >= 0; i --)
	{
		if (l & (1<<i))
			systray_del(plugin.hwndParent,i);
	}
	l=config_enabled;	
	for (i = 4; i >= 0; i --)
	{
		if (config_enabled & (1<<i))
			systray_add(plugin.hwndParent,i,Icons[i],tips[i]);
	}
}


void config()
{
/* This is fairly complex, here goes...
 * 1) Locates the handle of the Tree View control in the prefs dlg.
 * 2) Enumerates all visible tree items until item with our text
 *    is found.
 * 3) Selects that item (changes the page in the prefs dlg).
 *
	HWND hTreeView;
	HTREEITEM hItem;
	TV_ITEM tvi;
	char retstr[256];
	
	ZeroMemory(retstr, sizeof(retstr));
	hTreeView = FindWindowEx(GetForegroundWindow(), 0, WC_TREEVIEW, NULL);
	hItem = (HTREEITEM)SendMessage(hTreeView, TVM_GETNEXTITEM, TVGN_ROOT, 0);
	while (1) {
		hItem = (HTREEITEM)SendMessage(hTreeView, TVM_GETNEXTITEM, TVGN_NEXTVISIBLE, (LPARAM)hItem);
		tvi.mask = TVIF_TEXT | TVIF_HANDLE;
		tvi.hItem = hItem;
		tvi.pszText = retstr;
		tvi.cchTextMax = 255;
		SendMessage(hTreeView, TVM_GETITEM, 0, (LPARAM)&tvi);
		if (!lstrcmpi(retstr, prefsrec.name)) break;
	}
	SendMessage(hTreeView, TVM_SELECTITEM, TVGN_CARET, (LPARAM)hItem);
*/

	/* or you can use this undocumented IPC message */
	SendMessage(plugin.hwndParent, WM_WA_IPC, prefsrec._id, 380);

	/* Old message box */
	//MessageBox(plugin.hwndParent,"Configuration is under \"Tray Control\" in the list to the left.", szAppName, 64);
}

void quit()
{
	config_write();
	config_enabled=0;
	do_icons();
}

#define WINAMP_BUTTONPLAY 40045
#define WINAMP_BUTTONPAUSE 40046

#define WASENDMSG(wp, lp) CallWindowProc((WNDPROC)lpWndProcOld, hwnd,WM_WA_IPC,wp,lp)
#define WASENDMSGNONIPC(msg, wp, lp) CallWindowProc((WNDPROC)lpWndProcOld, hwnd,msg,wp,lp)


WNDPROC lpWndProcOld;
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
/* Handle message sendt by tray to Winamp */
	if ((config_enabled & ENABLE_TRAYMOD) > 0)
	{
	if (message==WM_WA_SYSTRAY && lParam == WM_LBUTTONUP) {
		switch (WASENDMSG(0,IPC_ISPLAYING))
		{
		case 0: /* stopped */  WASENDMSGNONIPC(WM_COMMAND, WINAMP_BUTTONPLAY, 0); break; /* hit play */
		case 1: /* playing */  WASENDMSGNONIPC(WM_COMMAND, WINAMP_BUTTONPAUSE, 0); break; /* hit pause */
		case 3: /* paused  */  WASENDMSGNONIPC(WM_COMMAND, WINAMP_BUTTONPAUSE, 0); break; /* hit pause, again */
		}
		return 0;
	}
	if (message==WM_WA_SYSTRAY && lParam == WM_LBUTTONDBLCLK) {
		/* Instead of giving Mr. Winamp WndProc a left
		   button double-click we pass on a single-click. */
		CallWindowProc((WNDPROC)lpWndProcOld,hwnd,WM_WA_SYSTRAY,wParam,WM_LBUTTONUP);
	}
	} // if ((config....

// old stuff, handles button clicks on sepearate control tray icons
	if (message == WM_USER+27)
	{
		int which = LOWORD(wParam) - 1024,a;
		switch (LOWORD(lParam))
		{
			case WM_LBUTTONDOWN:
				switch (which)
				{
					case 0:
						if ((a=SendMessage(hwnd,WM_WA_IPC,0,IPC_ISPLAYING)) == 0) // not playing, let's
						{														  // hit prev
							SendMessage(hwnd,WM_COMMAND,40044,0);
						}
						else if (a != 3 && SendMessage(hwnd,WM_USER,0,105) > 2000) // restart
						{
							SendMessage(hwnd,WM_COMMAND,40045,0);
						} else { // prev
							SendMessage(hwnd,WM_COMMAND,40044,0);
						}
					return 0;
					case 1:
						if ((a=SendMessage(hwnd,WM_WA_IPC,0,IPC_ISPLAYING)) != 1) // not playing, let's 
						{									  	  	  // hit play
							SendMessage(hwnd,WM_COMMAND,40045,0);
						}
						else { // prev
							SendMessage(hwnd,WM_COMMAND,40046,0);
						}
					return 0;
					case 2:
						if (GetKeyState(VK_SHIFT) & (1<<15))
							SendMessage(hwnd,WM_COMMAND,40147,0);
						else
							SendMessage(hwnd,WM_COMMAND,40047,0);
					return 0;
					case 3:
						SendMessage(hwnd,WM_COMMAND,40048,0);
					return 0;
					case 4:
						SetForegroundWindow(hwnd);
						if (GetKeyState(VK_CONTROL) & (1<<15))
							SendMessage(hwnd,WM_COMMAND,40185,0);
						else if (GetKeyState(VK_SHIFT) & (1<<15))
							SendMessage(hwnd,WM_COMMAND,40187,0);
						else
							SendMessage(hwnd,WM_COMMAND,40029,0);
					return 0;
				}
			return 0;
		}
	}
	return CallWindowProc((WNDPROC)lpWndProcOld,hwnd,message,wParam,lParam);
}

int init()
{
	{
		static char c[512];
		char filename[512],*p;
		GetModuleFileName(plugin.hDllInstance,filename,sizeof(filename));
		p = filename+lstrlen(filename);
		while (p >= filename && *p != '\\') p--;
		wsprintf((plugin.description=c),"%s Plug-In v0.1 (%s)",szAppName,p+1);
	}
	config_read();
	{
		int i;
		for (i = 0; i < 5; i ++)
			Icons[i] = LoadIcon(plugin.hDllInstance,MAKEINTRESOURCE(IDI_ICON1+i));
	}


	prefsrec.hInst = plugin.hDllInstance;
	SendMessage(plugin.hwndParent, WM_USER, (int)&prefsrec, 332);

	lpWndProcOld = (WNDPROC) SetWindowLong(plugin.hwndParent,GWL_WNDPROC,(int) WndProc);

	do_icons();

	return 0;
}



BOOL CALLBACK ConfigProc(HWND hwndDlg,UINT uMsg,WPARAM wParam, LPARAM lParam)
{

	switch (uMsg)
	{
		case WM_INITDIALOG:
			{
				int i;
				for (i = 0; i < 5; i++)
					CheckDlgButton(hwndDlg,IDC_PREV+i,(config_enabled&(1<<i))?BST_CHECKED:BST_UNCHECKED);
				CheckDlgButton(hwndDlg,IDC_TRAYCLICKCB,((config_enabled & ENABLE_TRAYMOD) > 0)?BST_CHECKED:BST_UNCHECKED);
			}
		return FALSE;
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDC_PREV:
				case IDC_PREV2:
				case IDC_PREV3:
				case IDC_PREV4:
				case IDC_PREV5:
				case IDC_TRAYCLICKCB:
				config_enabled=0;
					{
						int i;
						for (i = 0; i < 5; i++)
							if (IsDlgButtonChecked(hwndDlg,IDC_PREV+i))
								config_enabled |= 1<<i;
					}
					do_icons();
					if (IsDlgButtonChecked(hwndDlg,IDC_TRAYCLICKCB))
						config_enabled |= ENABLE_TRAYMOD;
				break;
			}
	}
	return FALSE;
}

void config_read()
{
	char ini_file[MAX_PATH], *p;
	GetModuleFileName(plugin.hDllInstance,ini_file,sizeof(ini_file));
	p=ini_file+lstrlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	lstrcat(ini_file,"plugin.ini");

	config_enabled = GetPrivateProfileInt(szAppName,"ButtonsEnabled",config_enabled,ini_file);
}

void config_write()
{
	char ini_file[MAX_PATH], *p;
	char string[32];
	GetModuleFileName(plugin.hDllInstance,ini_file,sizeof(ini_file));
	p=ini_file+lstrlen(ini_file);
	while (p >= ini_file && *p != '\\') p--;
	if (++p >= ini_file) *p = 0;
	lstrcat(ini_file,"plugin.ini");

	wsprintf(string,"%d",config_enabled);
	WritePrivateProfileString(szAppName,"ButtonsEnabled",string,ini_file);
}

__declspec( dllexport ) winampGeneralPurposePlugin * winampGetGeneralPurposePlugin()
{
  return &plugin;
}
